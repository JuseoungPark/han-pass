const ansiRegex = require('ansi-regex')
const path = require('path')

module.exports = {
  productionSourceMap: false, //.map 파일을 만들지 않음
  lintOnSave: false,
  runtimeCompiler: true,
  configureWebpack: {
    resolve: {
      symlinks: false,
      alias: {
        '@': path.join(__dirname, 'src/')
      }
    },
    entry: ["@babel/polyfill", "./src/main.js"],
  },
  transpileDependencies: [
    '@coreui/utils', ansiRegex
  ],
  // use this option for production linking
  // publicPath: process.env.NODE_ENV === 'production' ? '/vue/demo/3.0.0' : '/'

  // amchart exporting build disable
  // externals: function (context, request, callback) {
  //   if (/xlsx|canvg|pdfmake/.test(request)) {
  //     return callback(null, "commonjs " + request);
  //   }
  //   callback()
  // },
}
