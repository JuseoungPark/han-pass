
<template>
  <div class="home-dashboard">
    


    <CCard>
      <CCardBody>
        <!-- <img src="img/homedashboard.png" alt=""> -->
        <CRow>
          <CCol lg="8">
            
            <GmapMap
              :center="center"
              :zoom="2"
              :options= options
              style="height: 100vh"
            >
              <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false">
                <CLink :href="infoLink" target="_blank">{{infoContent}}</CLink>
                <p>asdasdasdasd</p>
              </GmapInfoWindow>
              <GmapMarker
                :key="index"
                v-for="(m, index) in markers"
                :position="m.position"
                :label="m.label"
                :clickable="true"
                :draggable="m.draggable"
                :icon="{url: 'img/marker.png'}"
                @mouseover="InfoWindowOver(m, index)"
              />
                <!-- :title="m.title" -->
                <!-- @mouseout="InfoWindowOut(m, index)" -->
            </GmapMap>
          </CCol>
          <CCol lg="4">
            <ul class="site-list pl-0 mb-0">
              <li v-for="(list, idx) in siteList" :key="idx" class="d-flex" @click="siteLocation(list, idx)">
                <div class="img-wrap">
                  <CImg
                    :src="`img/${list.image}.png`"
                    block
                    class="image img-wrap-image"
                  />
                </div>
                <div class="text-wrap pl-2">
                  <strong class="text-wrap-name">{{ list.name }}</strong>
                  <div>
                    <CIcon name="cil-location-pin"/>
                    <span class="text-wrap-location ml-1">{{ list.location }}</span>
                  </div>
                  <ul class="info-list">
                    <li v-for="(item, index) in list.infoList" :key="index">{{item}}</li>
                  </ul>
                </div>
              </li>
            </ul>
          </CCol>
        </CRow>
      </CCardBody>
    </CCard>
    <CCard>
      <CCardHeader>
        <div class="d-flex align-items-center">
          <strong class="mr-2">site name-1</strong>
          <router-link to="/homedashboard">
            <CIcon name="cil-external-link"/>
          </router-link>
        </div>
      </CCardHeader>
      <CCardBody>
        <CRow>
          <CCol lg="9">
              <CCard class="mb-0">

                <WidgetsDropdown/>

              </CCard>
          </CCol>
          <CCol lg="3">
            <div class="info-detail-text">
              <strong class="title">Petrosea - KIDECO</strong>
              <div>
                <CIcon name="cil-location-pin" class="location" />
                <span class="text-wrap-location ml-1">Kalimantan, Indonesia</span>
              </div>
              <div>
                <CIcon name="cil-user" class="manager" />
                <span class="text-wrap-location ml-1">Teddy Kim</span>
              </div>
            </div>
          </CCol>
        </CRow>
      </CCardBody>
    </CCard>
  </div>
</template>

<script>
import WidgetsDropdown from '@/views/home/WidgetsDropdown'

// import * as VueGoogleMaps from 'vue2-google-maps'
// import Vue from 'vue'

// Vue.use(VueGoogleMaps, {
//   load: {
//     key: 'AIzaSyASyYRBZmULmrmw_P9kgr7_266OhFNinPA'
//     // key: ''
//     // To use the Google Maps JavaScript API, you must register your app project on the Google API Console and get a Google API key which you can add to your app
//     // v: 'OPTIONAL VERSION NUMBER',
//     // libraries: 'places', //// If you need to use place input
//   }
// })

export default {
  name: 'HomeDashboard',
  components: {
    WidgetsDropdown
  },
  data () {
    return {
      siteList: [
        {
          image: 'sample01',
          name: 'site name-1',
          location: 'Kalimantan, Indonesia',
          infoList:[
            'info list text -01',
            'info list text -01',
            'info list text -01',
          ]
        },
        {
          image: 'sample02',
          name: 'site name-2',
          location: 'Kalimantan, Indonesia',
          infoList:[
            'info list text -02',
          ]
        },
        {
          image: 'sample01',
          name: 'site name-3',
          location: 'Kalimantan, Indonesia',
          infoList:[
            'info list text -03',
            'info list text -03',
            'info list text -03',
          ]
        },
        {
          image: 'sample02',
          name: 'site name-4',
          location: 'Kalimantan, Indonesia',
          infoList:[
            'info list text -04',
            'info list text -04',
            'info list text -04',
          ]
        },
        {
          image: 'sample01',
          name: 'site name-5',
          location: 'Kalimantan, Indonesia',
          infoList:[
            'info list text -05',
            'info list text -05',
            'info list text -05',
          ]
        },
      ], // site list data

      // google map
      center: {lat: -2.212600, lng: 115.524612},
      markers: [{
        position: {lat: 37.532600, lng: 127.024612},
        // label: 'S',
        draggable: false,
        title: 'test',
        // www: 'https://www.stanford.edu/'
      }, {
        position: {lat: -30.532600, lng: 150.024612},
        // label: 'T',
        draggable: false,
        title: 'test',
        // www: 'https://www.tesla.com/'
      }, {
        position: {lat: 37.331681, lng: -122.030100},
        // label: 'A',
        draggable: false,
        title: 'test',
        // www: 'https://www.apple.com/'
      },{
        position: {lat: -2.212600, lng: 115.524612},
        // label: 'A',
        draggable: false,
        title: 'test',
        // www: 'https://www.apple.com/'
      },
      ],
      infoContent: '',
      infoLink: '',
      infoWindowPos: {
        lat: 0,
        lng: 0
      },
      infoWinOpen: false,
      currentMidx: null,
      // optional: offset infowindow so it visually sits nicely on top of our marker
      options: {
        streetViewControl: false,
        rotateControl: false,
        mapTypeControl: false,
        fullscreenControl: false,
        minZoom: 13,
        maxZoom: 20,
        mapTypeId: "satellite"
      },
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -35
        }
      },
      // google map
    }
  },
  methods: {
    InfoWindowOver (marker, idx) {
      this.infoWindowPos = marker.position
      this.infoContent = marker.title
      this.infoLink = marker.www

      this.currentMidx = idx
      if (this.currentMidx === idx) {
        console.log('open')
        this.infoWinOpen = !this.infoWinOpen
      }
      // else{
      // this.currentMidx = idx
      // this.infoWinOpen = false
      // }
    },
    // InfoWindowOut (marker, idx) {
    //   this.infoWindowPos = marker.position
    //   this.infoContent = marker.title
    //   this.infoLink = marker.www

    //   console.log('close')
    //   this.currentMidx = idx
    //   this.infoWinOpen = false
    // },

    siteLocation(list, idx) {
      //console.log('siteLocation >>>>', list, idx) 
    }
  }
}
</script>
