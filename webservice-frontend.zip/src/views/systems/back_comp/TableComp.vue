<template>
  <CCard>
    <CCardBody>
      <CDataTable
      :items="loadedItems"
      :fields="fields"

      :hover="hover"
      :striped="striped"
      :bordered="bordered"
      :small="small"
      :fixed="fixed"


      :table-filter="{ external: true, lazy: true, label: filterName }"
      :table-filter-value.sync="tableFilterValue"


  
      :loading="loading"

    >
      <template #c="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>
      <template #r="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>
      <template #u="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>
      <template #d="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>
      <template #p="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>
    </CDataTable>
    <!-- <CPagination
      class="mt-3"
      v-show="pages > 1"
      :pages="pages"
      :active-page.sync="activePage"
    /> -->
    <CDataTable
      class="d-none"
      ref="externalAgent"

      :items="items.slice(0)"
      :fields="fields"

      :table-filter-value="tableFilterValue"

      :hover="hover"
      :striped="striped"
      :bordered="bordered"
      :small="small"
      :fixed="fixed"
    />

    </CCardBody>
  </CCard>
</template>

<script>

export default {
  name: 'DataTableComp',
  props: {
    caption: {
      type: String,
      default: 'Table'
    },
    items: Array,
    hover: Boolean,
    striped: Boolean,
    bordered: Boolean,
    small: Boolean,
    fixed: Boolean,
    dark: Boolean,
    filterName :String,
  },
  data () {
    return {
      // rowClickData: {},
      fields: [],
      // sorterValue: { column: null, asc: true },
      // columnFilterValue: {},
      tableFilterValue: '',
      // activePage: 1,
      loadedItems: this.items.slice(0),
      loading: false,
      // pages: Math.ceil(this.items.length / 5)
    }
  },
  watch: {
    reloadParams () {
      this.onTableChange()
    }
  },
  computed: {
    reloadParams () {
      return [  
        // this.sorterValue,
        // this.columnFilterValue,
        this.tableFilterValue,
        // this.activePage
      ]
    }
  },
  mounted() {
    this.dataFields()
  },
  methods: {
    // onTableChange () {
    //   this.loading = true
    //   setTimeout(() => {
    //     this.loading = false
    //     const agent = this.$refs.externalAgent
    //     this.loadedItems = agent.currentItems
    //     this.pages = Math.ceil(agent.sortedItems.length / 5)
    //   }, 1000)
    // },
    dataFields() {
      let fields = this.loadedItems

      // console.log('====',Object.keys(fields[0]))
      return this.fields = Object.keys(fields[0])
    },
    check (item, idx) {
      console.log('check item', item.menuId, item.depth, item.menuName, item)
    },
  }
}
</script>
