<template>
  <CCard>
    <CCardBody>
      <CDataTable
      :items="loadedItems"
      :fields="fields"

      :hover="hover"
      :striped="striped"
      :bordered="bordered"
      :small="small"
      :fixed="fixed"

      :column-filter="{ external: true, lazy: true }"
      :column-filter-value.sync="columnFilterValue"
      :table-filter="{ external: true, lazy: true, label: filterName }"
      :table-filter-value.sync="tableFilterValue"
      :sorter="{ external: true, resetable: true }"
      :sorter-value.sync="sorterValue"

  
      :loading="loading"

      clickable-rows
      @row-clicked="rowClicked"
    >
      <template #langYn="{item}">
        <td>
          <CBadge :class="{yes : item.langYn == 'Y', no : item.langYn == 'N'}" >{{item.useYn}}</CBadge>
        </td>
      </template>
      <template #useYn="{item}">
        <td>
          <CBadge :class="{yes : item.useYn == 'Y', no : item.useYn == 'N'}" >{{item.useYn}}</CBadge>
        </td>
      </template>
    </CDataTable>
    <!-- <CPagination
      class="mt-3"
      v-show="pages > 1"
      :pages="pages"
      :active-page.sync="activePage"
    /> -->
    <CDataTable
      class="d-none"
      ref="externalAgent"

      :items="items.slice(0)"
      :fields="fields"

      :column-filter-value="columnFilterValue"
      :table-filter-value="tableFilterValue"
      :sorter-value="sorterValue"


      
      :hover="hover"
      :striped="striped"
      :bordered="bordered"
      :small="small"
      :fixed="fixed"
    />

    </CCardBody>
  </CCard>
</template>

<script>

export default {
  name: 'DataTableComp',
  props: {
    caption: {
      type: String,
      default: 'Table'
    },
    items: Array,
    hover: Boolean,
    striped: Boolean,
    bordered: Boolean,
    small: Boolean,
    fixed: Boolean,
    dark: Boolean,
    filterName :String,
  },
  data () {
    return {
      rowClickData: {},
      fields: [],
      sorterValue: { column: null, asc: true },
      columnFilterValue: {},
      tableFilterValue: '',
      activePage: 1,
      loadedItems: this.items.slice(0),
      loading: false,
      pages: Math.ceil(this.items.length / 5)
    }
  },
  watch: {
    reloadParams () {
      this.onTableChange()
    }
  },
  computed: {
    reloadParams () {
      return [  
        this.sorterValue,
        this.columnFilterValue,
        this.tableFilterValue,
        this.activePage
      ]
    }
  },
  mounted() {
    this.dataFields()
  },
  methods: {
    onTableChange () {
      this.loading = true
      setTimeout(() => {
        this.loading = false
        const agent = this.$refs.externalAgent
        this.loadedItems = agent.currentItems
        this.pages = Math.ceil(agent.sortedItems.length / 5)
      }, 1000)
    },
    dataFields() {
      let fields = this.loadedItems

      // console.log('====',Object.keys(fields[0]))
      return this.fields = Object.keys(fields[0])
    },
    rowClicked(item, index) {
      // console.log('>>>>', item, index)
      this.$emit('rowClick', item, index)
    }
  }
}
</script>
