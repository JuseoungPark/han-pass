const managementData = [
  { menuId: 'menu001', depth:'1', menuName:'Dashboard', c:'', r:'', u:'', d:'', p:''},
  { menuId: 'menu002', depth:'1', menuName:'Blast Library', c:'', r:'', u:'', d:'', p:''},
  { menuId: 'menu003', depth:'2', menuName:'Drilling', c:'', r:'', u:'', d:'', p:''},
]

export default managementData


