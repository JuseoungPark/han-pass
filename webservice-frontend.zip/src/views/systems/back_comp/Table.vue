<template>
  <CCard>
    <CCardBody>
      <CDataTable
        :hover="hover"
        :striped="striped"
        :bordered="bordered"
        :small="small"
        :fixed="fixed"
        :items="loadedItems"
        :fields="fields"
        :dark="dark"
      >
        <template #c="{item}">
        <td>
          <CInputCheckbox
            :checked="item._selected"
            @update:checked="() => check(item)"
            custom
          />
        </td>
      </template>

      </CDataTable>
    </CCardBody>
  </CCard>
</template>

<script>
export default {
  name: 'Table',
  props: {
    items: Array,
    caption: {
      type: String,
      default: 'Table'
    },
    hover: Boolean,
    striped: Boolean,
    bordered: Boolean,
    small: Boolean,
    fixed: Boolean,
    dark: Boolean
  },
  data () {
    return {
      fields: [],
      loadedItems: this.items.slice(0),
    }
  },
  mounted() {
    this.dataFields()
  },
  methods: {
    dataFields() {
      let fields = this.loadedItems

      // console.log('====',Object.keys(fields[0]))
      return this.fields = Object.keys(fields[0])
    },
    check (item) {
      console.log('check item', item)
    }
  }
}
</script>
