
<template>
  <div>

    <CCard>
      <CCardHeader>
        <strong>custom App Icons</strong>
      </CCardHeader>
      <CCardBody>
        <div>
            <app-icon name="face" size="s" color="red" fill class="mr-3"></app-icon>
            <app-icon name="face" size="m" fill class="mr-3"></app-icon>
            <app-icon name="face" size="l" fill></app-icon>
        </div>
      </CCardBody>
    </CCard>

    <CCard>
      <CCardHeader>
        <CIcon :content="$options.freeSet.cilHandPointDown"/> CoreUI Icons
        <CBadge color="info">New</CBadge>
        <div class="card-header-actions">
          <a
            href="https://github.com/coreui/coreui-icons"
            rel="noreferrer noopener"
            target="_blank"
            class="card-header-action"
          >
            <small class="text-muted">Github</small>
          </a>
        </div>
      </CCardHeader>
      <CCardBody>
        <CRow class="text-center">
          <template v-for="(icon, iconName) in $options.freeSet">
            <CCol
              class="mb-5"
              col="3"
              sm="2"
              :key="iconName"
            >
              <CIcon :height="42" :content="icon"/>
              <div>{{toKebabCase(iconName)}}</div>
            </CCol>
          </template>
        </CRow>
      </CCardBody>
    </CCard>
  </div>
</template>

<script>
import { freeSet } from '@coreui/icons'

import AppIcon from '../../components/AppIcon'

import(/* webpackChunkName: "svgicon-face" */ `../../components/icons`)

export default {
  name: 'CoreUIIcons',
  components: {
    AppIcon
  },
  freeSet,
  methods: {
    toKebabCase (str) {
      return str.replace(/([a-z])([A-Z0-9])/g, '$1-$2').toLowerCase()
    }
  }
}
</script>
