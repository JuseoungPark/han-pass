<template>
  <div>
    <CRow>
      <CCol lg="12">
        <CCard>
          <CCardBody class="line-none">
            <CTabs variant="tabs" :activeTab="tabs.activeMainTab" @update:activeTab="activeTab">
              <CTab v-for="main in mainTab"
                :key="main.index"
                :title="main.title"
                sm="3">
                <CTabs :activeTab="tabs.activeSubTab" v-if="main.subTabs && main.index === tabs.activeMainTab" variant="pills" class="mt-3" @update:activeTab="getEditMode">
                  <CTab v-for="sub in main.subTabs"
                    :key="sub.index"
                    :title="sub.title"
                    sm="3">
                    <component v-if="editMode === sub.editMode" v-bind:is="editMode"
                      :param="param"
                      @is-result="moveTab" />
                  </CTab>
                </CTabs>
              </CTab>
            </CTabs>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  </div>
</template>

<script>
export default {
  name: 'SystemSetting',
  components: { 
    codeGroupComp: () => import('@/views/admin/systemComp/codeManagement1Depth'),
    codeCommonComp: () => import('@/views/admin/systemComp/codeManagement2Depth'),
    menuManage1depthComp: () => import('@/views/admin/systemComp/menu-management-1depth'),
    menuManage2depthComp: () => import('@/views/admin/systemComp/menu-management-2depth'),
    authorityTypeComp: () => import('@/views/admin/systemComp/authorityType'),
    authorityMenuComp: () => import('@/views/admin/systemComp/authorityMenuSetting'),
    languageManagementComp: () => import('@/views/admin/systemComp/language-management'),
    siteComp: () => import('@/views/admin/systemComp/Site'),
    siteAdminComp: () => import('@/views/admin/systemComp/siteAdmin'),
    masterProductBulkComp: () => import('@/views/admin/systemComp/masterProductBulk'),
    masterProductCartridgeComp: () => import('@/views/admin/systemComp/masterProductCartridge'),
    masterProductDetonatorsComp: () => import('@/views/admin/systemComp/masterProductDetonators'),
    masterProductBoostersComp: () => import('@/views/admin/systemComp/masterProductBoosters')
  },
  data() {
    return {
      subComponent: 'codeGroupComp',
      param: null,
      tabs: {
        activeMainTab: 0,
        activeSubTab: 0,
      }
    }
  },
  computed: {
    editMode() {
      return this.subComponent
    },
    mainTab () {
      return [
          {
            index: 0, title: this.$t('systemSetting.tab.codeManagement.title'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.codeManagement.codeGroup'), editMode: 'codeGroupComp'},
              {index: 1, title: this.$t('systemSetting.tab.codeManagement.commonCode'), editMode: 'codeCommonComp'}
            ]
          },
          {
            index: 1, title: this.$t('systemSetting.tab.menuManagement.title'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.menuManagement.menu1Depth'), editMode: 'menuManage1depthComp'},
              {index: 1, title: this.$t('systemSetting.tab.menuManagement.menu2Depth'), editMode: 'menuManage2depthComp'}
            ]
          },
          {
            index: 2, title: this.$t('systemSetting.tab.authorityManagement.title'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.authorityManagement.authorityType'), editMode: 'authorityTypeComp'},
              {index: 1, title: this.$t('systemSetting.tab.authorityManagement.authorMenuSetting'), editMode: 'authorityMenuComp'}
            ]
          },
          {
            index: 3, title: this.$t('systemSetting.tab.multiLanguageManagement'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.multiLanguageManagement'), editMode: 'languageManagementComp'}
            ]
          },
          {
            index: 4, title: this.$t('systemSetting.tab.siteTab.title'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.siteTab.site'), editMode: 'siteComp'},
              {index: 1, title: this.$t('systemSetting.tab.siteTab.siteAdmin'), editMode: 'siteAdminComp'}
            ]
          },
          {
            index: 5, title: this.$t('systemSetting.tab.masterTab.title'),
            subTabs: [
              {index: 0, title: this.$t('systemSetting.tab.masterTab.bulk'), editMode: 'masterProductBulkComp'},
              {index: 1, title: this.$t('systemSetting.tab.masterTab.cartridge'), editMode: 'masterProductCartridgeComp'},
              {index: 2, title: this.$t('systemSetting.tab.masterTab.detonators'), editMode: 'masterProductDetonatorsComp'},
              {index: 3, title: this.$t('systemSetting.tab.masterTab.boosters'), editMode: 'masterProductBoostersComp'}
            ]
          }
      ]
    }
  },
  mounted() {
    //
  },
  methods : {
    moveTab(item) {
      this.activeTab(item.mainTab, item.subTab, item.item)
    },
    activeTab (index, subIndex = 0, item = null) {
      this.tabs.activeMainTab = index
      this.getEditMode(subIndex, item)
    },
    getEditMode (index, item = null) {
      this.param = item
      this.tabs.activeSubTab = index
      this.subComponent = ''
      this.$nextTick(() => {
        let tab = this.mainTab.find(s => s.index === this.tabs.activeMainTab).subTabs.find(s => s.index === index)
        if (tab) {
          this.subComponent = tab.editMode
        }
      })
    }
  }
}
</script>