<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.siteMapTab.structures')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.sitemap.structures.structureId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.structureId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.sitemap.structures.structureName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.structureName')])"
              type="text"
              name="structureName"
              v-model.trim="$v.form.structureName.$model"
              :isValid="$v.form.structureName.$dirty ? !$v.form.structureName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.structureName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.sitemap.structures.structureDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.structureDescription')])"
              rows="4"
              :maxlength="200"
              name="structureDescription"
              v-model.trim="$v.form.structureDescription.$model"
              :isValid="$v.form.structureDescription.$dirty ? !$v.form.structureDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.structureDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.sitemap.structures.vibrationTargetName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.vibrationTargetName')])"
              :value.sync="$v.form.vibrationTargetId.$model"
              :options="codes.vibrationTargetIds"
              :isValid="$v.form.vibrationTargetId.$dirty ? !$v.form.vibrationTargetId.$error : null"
              :invalidFeedback="$t('validation.required')"
              @update:value="updateVibrationTarget" />
            <CInput
              :label="$t('siteInformation.sitemap.structures.pvsValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.pvsValue')])"
              type="text"
              name="pvsValue"
              append="mm/s"
              v-model.trim="$v.form.pvsValue.$model"
              :isValid="$v.form.pvsValue.$dirty ? !$v.form.pvsValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.pvsValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.structures.ppvValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.ppvValue')])"
              type="text"
              name="ppvValue"
              append="mm/s"
              v-model.trim="$v.form.ppvValue.$model"
              :isValid="$v.form.ppvValue.$dirty ? !$v.form.ppvValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.ppvValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.structures.latitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.latitudeValue')])"
              type="text"
              name="latitudeValue"
              v-model.trim="$v.form.latitudeValue.$model"
              :isValid="$v.form.latitudeValue.$dirty ? !$v.form.latitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitudeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.structures.longitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.longitudeValue')])"
              type="text"
              name="longitudeValue"
              v-model.trim="$v.form.longitudeValue.$model"
              :isValid="$v.form.longitudeValue.$dirty ? !$v.form.longitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.longitudeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.structures.altitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.structures.altitudeValue')])"
              type="text"
              name="altitudeValue"
              append="m"
              v-model.trim="$v.form.altitudeValue.$model"
              :isValid="$v.form.altitudeValue.$dirty ? !$v.form.altitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.altitudeValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.sitemap.structures.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "SiteMapStructures",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        vibrationTargetIds: []
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'structureName', label:this.$t('siteInformation.sitemap.structures.structureName')},
        {key:'structureDescription', label:this.$t('siteInformation.sitemap.structures.structureDescription')},
        {key:'vibrationTargetName', label:this.$t('siteInformation.sitemap.structures.vibrationTargetName')},
        {key:'pvsValue', label:this.$t('siteInformation.sitemap.structures.pvsValue')},
        {key:'ppvValue', label:this.$t('siteInformation.sitemap.structures.ppvValue')},
        {key:'latitudeValue', label:this.$t('siteInformation.sitemap.structures.latitudeValue')},
        {key:'longitudeValue', label:this.$t('siteInformation.sitemap.structures.longitudeValue')},
        {key:'altitudeValue', label:this.$t('siteInformation.sitemap.structures.altitudeValue')},
        {key:'useYn', label:this.$t('siteInformation.sitemap.structures.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/structures`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      structureName: {
        required,
        byte: byte(64)
      },
      structureDescription: {
        byte: byte(256)
      },
      vibrationTargetId: {
        required,
      },
      pvsValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      ppvValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      latitudeValue: {
        required,
        decimal,
        between: between(-90, 90),
        decimalLimit: decimalLimit(7)
      },
      longitudeValue: {
        required,
        decimal,
        between: between(-180, 180),
        decimalLimit: decimalLimit(7)
      },
      altitudeValue: {
        required,
        decimal,
        between: between(-500, 9999),
        decimalLimit: decimalLimit(2)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getvibrationTarget()
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        structureName: '',
        structureDescription: '',
        vibrationTargetId: '',
        pvsValue: '',
        ppvValue: '',
        latitudeValue: '',
        longitudeValue: '',
        altitudeValue: '',
        useYn: 'Y',
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.structureId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    updateVibrationTarget (id) {
      let target = this.codes.vibrationTargetIds.find(s => s.value === id)
      if (target) {
        this.form.pvsValue = target.pvsValue
        this.form.ppvValue = target.ppvValue
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          structureId: this.form.structureId,
          structureName: this.form.structureName
        },
        payload : {
          keyword: 'structureName',
          keywordName: this.$t('siteInformation.sitemap.structures.structureName'),
        }
      }
      this.saveDataAction(d)
    }
  }
};
</script>
