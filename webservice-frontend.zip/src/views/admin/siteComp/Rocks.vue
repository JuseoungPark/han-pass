<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.rocksTab.rocks')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.rocks.rocks.rocksId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.rocksId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.rocks.rocks.rocksName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.rocksName')])"
              type="text"
              name="rockName"
              v-model.trim="$v.form.rockName.$model"
              :isValid="$v.form.rockName.$dirty ? !$v.form.rockName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rockName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.rocks.rocks.description')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.description')])"
              rows="4"
              :maxlength="200"
              name="description"
              v-model.trim="$v.form.description.$model"
              :isValid="$v.form.description.$dirty ? !$v.form.description.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.description" />
              </template>
            </CTextarea>
            <CInput
              :label="$t('siteInformation.rocks.rocks.densityValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.densityValue')])"
              type="text"
              name="densityValue"
              append="g/cm3"
              v-model.trim="$v.form.densityValue.$model"
              :isValid="$v.form.densityValue.$dirty ? !$v.form.densityValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.densityValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.uniaxialCompressiveStrengthValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.uniaxialCompressiveStrengthValue')])"
              type="text"
              name="uniaxialCompressiveStrengthValue"
              append="Mpa"
              v-model.trim="$v.form.uniaxialCompressiveStrengthValue.$model"
              :isValid="$v.form.uniaxialCompressiveStrengthValue.$dirty ? !$v.form.uniaxialCompressiveStrengthValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.uniaxialCompressiveStrengthValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.tensileStrengthValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.tensileStrengthValue')])"
              type="text"
              name="tensileStrengthValue"
              append="Mpa"
              v-model.trim="$v.form.tensileStrengthValue.$model"
              :isValid="$v.form.tensileStrengthValue.$dirty ? !$v.form.tensileStrengthValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.tensileStrengthValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.poissonsRatioValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.poissonsRatioValue')])"
              type="text"
              name="poissonsRatioValue"
              v-model.trim="$v.form.poissonsRatioValue.$model"
              :isValid="$v.form.poissonsRatioValue.$dirty ? !$v.form.poissonsRatioValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.poissonsRatioValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.youngsModulusValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.youngsModulusValue')])"
              type="text"
              name="youngsModulusValue"
              append="Gpa"
              v-model.trim="$v.form.youngsModulusValue.$model"
              :isValid="$v.form.youngsModulusValue.$dirty ? !$v.form.youngsModulusValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.youngsModulusValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.rockfactorValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.rockfactorValue')])"
              type="text"
              name="rockfactorValue"
              v-model.trim="$v.form.rockfactorValue.$model"
              :isValid="$v.form.rockfactorValue.$dirty ? !$v.form.rockfactorValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rockfactorValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.rmdValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.rmdValue')])"
              type="text"
              name="rmdValue"
              v-model.trim="$v.form.rmdValue.$model"
              :isValid="$v.form.rmdValue.$dirty ? !$v.form.rmdValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rmdValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.rdiValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.rdiValue')])"
              type="text"
              name="rdiValue"
              v-model.trim="$v.form.rdiValue.$model"
              :isValid="$v.form.rdiValue.$dirty ? !$v.form.rdiValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rdiValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.hfValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.hfValue')])"
              type="text"
              name="hfValue"
              v-model.trim="$v.form.hfValue.$model"
              :isValid="$v.form.hfValue.$dirty ? !$v.form.hfValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.hfValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.jsValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.jsValue')])"
              type="text"
              name="jsValue"
              v-model.trim="$v.form.jsValue.$model"
              :isValid="$v.form.jsValue.$dirty ? !$v.form.jsValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.jsValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.jaValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.jaValue')])"
              type="text"
              name="jaValue"
              v-model.trim="$v.form.jaValue.$model"
              :isValid="$v.form.jaValue.$dirty ? !$v.form.jaValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.jaValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.dipAngleValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.dipAngleValue')])"
              type="text"
              name="dipAngleValue"
              append="º"
              v-model.trim="$v.form.dipAngleValue.$model"
              :isValid="$v.form.dipAngleValue.$dirty ? !$v.form.dipAngleValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.dipAngleValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.rocks.rocks.dipDirectionValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.rocks.rocks.dipDirectionValue')])"
              type="text"
              name="dipDirectionValue"
              append="º"
              v-model.trim="$v.form.dipDirectionValue.$model"
              :isValid="$v.form.dipDirectionValue.$dirty ? !$v.form.dipDirectionValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.dipDirectionValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.rocks.rocks.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between, numeric } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Rocks",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'rockName', label:this.$t('siteInformation.rocks.rocks.rocksName')},
        {key:'description', label:this.$t('siteInformation.rocks.rocks.description')},
        {key:'densityValue', label:this.$t('siteInformation.rocks.rocks.densityValue')},
        {key:'uniaxialCompressiveStrengthValue', label:this.$t('siteInformation.rocks.rocks.uniaxialCompressiveStrengthValue')},
        {key:'tensileStrengthValue', label:this.$t('siteInformation.rocks.rocks.tensileStrengthValue')},
        {key:'poissonsRatioValue', label:this.$t('siteInformation.rocks.rocks.poissonsRatioValue')},
        {key:'youngsModulusValue', label:this.$t('siteInformation.rocks.rocks.youngsModulusValue')},
        {key:'rockfactorValue', label:this.$t('siteInformation.rocks.rocks.rockfactorValue')},
        {key:'useYn', label:this.$t('siteInformation.rocks.rocks.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/rocks`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      rockName: {
        required,
        byte: byte(64)
      },
      description: {
        byte: byte(256)
      },
      densityValue: {
        required,
        decimal,
        between: between(0, 99.999),
        decimalLimit: decimalLimit(3)
      },
      uniaxialCompressiveStrengthValue: {
        required,
        numeric,
        between: between(0, 99999),
      },
      tensileStrengthValue: {
        required,
        decimal,
        between: between(0, 9999.9),
        decimalLimit: decimalLimit(1)
      },
      poissonsRatioValue: {
        required,
        decimal,
        between: between(0, 0.50),
        decimalLimit: decimalLimit(2)
      },
      youngsModulusValue: {
        required,
        numeric,
        between: between(0, 99999),
      },
      rockfactorValue: {
        required,
        decimal,
        between: between(0, 30),
        decimalLimit: decimalLimit(2)
      },
      rmdValue: {
        required,
        decimal,
        between: between(10, 50),
        decimalLimit: decimalLimit(1)
      },
      rdiValue: {
        required,
        decimal,
        between: between(-50, 500),
        decimalLimit: decimalLimit(1)
      },
      hfValue: {
        required,
        decimal,
        between: between(0, 100),
        decimalLimit: decimalLimit(1)
      },
      jsValue: {
        required,
        decimal,
        between: between(10, 50),
        decimalLimit: decimalLimit(1)
      },
      jaValue: {
        required,
        decimal,
        between: between(20, 40),
        decimalLimit: decimalLimit(1)
      },
      dipDirectionValue: {
        required,
        numeric,
        between: between(0, 360)
      },
      dipAngleValue: {
        required,
        numeric,
        between: between(0, 90)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm() {
      return {
        rockName: '',
        description: '',
        densityValue: '2.700',
        uniaxialCompressiveStrengthValue: '150',
        tensileStrengthValue: '40.0',
        poissonsRatioValue: '0.25',
        youngsModulusValue: '55',
        rockfactorValue: '',
        rmdValue: '10.0',
        jsValue: '30.0',
        jaValue: '20.0',
        rdiValue: '12.5',
        hfValue: '30.0',
        dipDirectionValue: '0',
        dipAngleValue: '0',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.rockId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          rockId: this.form.rockId,
          rockName: this.form.rockName
        },
        payload : {
          keyword: 'rockName',
          keywordName: this.$t('siteInformation.rocks.rocks.rocksName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
