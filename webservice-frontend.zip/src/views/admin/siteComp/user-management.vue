<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.userTab.userRegistration')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.user.userInfo.userId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.userId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
              <!--
                @keyup.enter="isDuplicationEmail"
                :disabled="form.dataId || option.isEmail"
              -->
            <CInput
              :label="$t('siteInformation.user.userInfo.email')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.email')])"
              type="text"
              name="email"
              :disabled="form.dataId"
              @focusout="isDuplicationEmail"
              v-model.trim="$v.form.email.$model"
              :isValid="emailValid">
              <!-- <template #append v-if="!form.dataId && !option.isEmail">
                <CButton type="button" size="sm" variant="outline" color="warning" class="mx-1" @click="isDuplicationEmail">
                  <CIcon name="cil-check-circle" class="mr-1"/>
                  {{ $t("commonLabel.checkDuplication") }}
                </CButton>
              </template> -->
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.email" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.user.userInfo.userName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.userName')])"
              type="text"
              name="userName"
              v-model.trim="$v.form.userName.$model"
              :isValid="$v.form.userName.$dirty ? !$v.form.userName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.userName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.user.userInfo.cellphoneNo')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.cellphoneNo')])"
              type="text"
              name="cellphoneNo"
              v-model.trim="$v.form.cellphoneNo.$model"
              :isValid="$v.form.cellphoneNo.$dirty ? !$v.form.cellphoneNo.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.cellphoneNo" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.user.userInfo.companyName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.companyName')])"
              :value.sync="$v.form.companyId.$model"
              :options="codes.companyIds"
              :isValid="$v.form.companyId.$dirty ? !$v.form.companyId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.user.userInfo.userLanguageTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.userLanguageTypeName')])"
              :value.sync="$v.form.userLanguageType.$model"
              :options="codes.userLanguageTypes"
              :isValid="$v.form.userLanguageType.$dirty ? !$v.form.userLanguageType.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CTextarea
              :label="$t('siteInformation.user.userInfo.description')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.description')])"
              rows="4"
              :maxlength="200"
              name="description"
              v-model.trim="$v.form.description.$model"
              :isValid="$v.form.description.$dirty ? !$v.form.description.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.description" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.user.userInfo.workerPositionCodeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.workerPositionCodeName')])"
              :value.sync="$v.form.workerPositionCode.$model"
              :options="codes.workerPositionCodes"
              :isValid="$v.form.workerPositionCode.$dirty ? !$v.form.workerPositionCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CRow form>
              <label>{{$t('siteInformation.user.userInfo.roleSetting')}}</label>
            </CRow>
            <CRow>
              <CCol>
                <!-- <CCard> -->
                  <CCardBody class="px-1">
                    <CSelect
                      v-if="!currentUser"
                      class="mb-0"
                      :label="$t('siteInformation.user.userInfo.authorityName')"
                      :placeholder="$t('message.inputMessage', [$t('siteInformation.user.userInfo.authorityName')])"
                      :value.sync="option.authorityId"
                      :options="availableAuthIds">
                      <template #append>
                        <CButton @click="isAuthority()" type="button" class="mx-1 btn-custom-default hanwha outline">
                          {{ $t("commonLabel.submit") }}
                        </CButton>
                      </template>
                    </CSelect>
                    <CRow>
                      <CCol>
                        <div class="authority-list mb-3 mt-2" :class="{'icon-warning left is-invalid': !$v.form.siteAuthority.required}">
                          <ul v-if="form.siteAuthority.length === 0">
                            <li>
                              <span class="info-text">{{$t('message.notRole')}}</span>
                            </li>
                          </ul>
                          <ul v-else>
                            <template v-for="item in form.siteAuthority">
                              <li :key="item.siteId" v-if="item.type !== 'D'">
                                {{item.authorityName}}
                                <button v-if="!currentUser" type="button" class="btn-list-del" @click="deleteAuthority(item)">
                                  <CIcon name="cil-x" class="ml-1"/>
                                </button>
                              </li>
                            </template>
                          </ul>
                        </div>
                      </CCol>
                    </CRow>
                  </CCardBody>
                <!-- </CCard> -->
              </CCol>
            </CRow>
            <CRow form class="form-group">
              <CCol sm="4">
                {{$t('siteInformation.user.userInfo.themaType')}}
              </CCol>
              <CInputRadioGroup
                custom
                :options="codes.themaTypes"
                :inline="true"
                :label="$t('commonLabel.changePassword')"
                :checked.sync="$v.form.themaType.$model" />
            </CRow>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.user.userInfo.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing || (!form.dataId && !option.isEmail)"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CModal
      :show.sync="visible.siteAuthModel"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.authConfirm')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.siteAuthModel = false" class="text-white" />
      </template>
      <template #footer>
        <CButton @click="updateAuthority" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.siteAuthModel = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, email, sameAs } from "vuelidate/lib/validators"
import { byte, strongPass } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "userManagement",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      option: {
        authorityId: '',
        originalAuth: [],
        isEmail: false
      },
      visible: {
        loading: false,
        form: false,
        dangerModal: false,
        siteAuthModel: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        companyIds: [],
        authorityIds: [
          {value: '', label: this.$t('message.selectMessage', [this.$t('siteInformation.user.userInfo.siteAuthority')])}
        ],
        userLanguageTypes: utils.getOptionCode("multilingualType", true),
        themaTypes: ["dark", "white"],
        workerPositionCodes: utils.getOptionCode("workerPosition", true),
      },
      items: [],
      form: this.getEmptyForm()
    };
  },
  computed: {
    fields () {
      return [
        {key:'email', label:this.$t('siteInformation.user.userInfo.email')},
        {key:'userName', label:this.$t('siteInformation.user.userInfo.userName')},
        {key:'cellphoneNo', label:this.$t('siteInformation.user.userInfo.cellphoneNo')},
        {
          key:'companyName', label:this.$t('siteInformation.user.userInfo.companyName'),
          itemTemplate: (key, item) => {
            return (item.company || {}).companyName || '-'
          }
        },
        {key:'userLanguageTypeName', label:this.$t('siteInformation.user.userInfo.userLanguageTypeName')},
        {key:'themaType', label:this.$t('siteInformation.user.userInfo.themaType')},
        {key:'description', label:this.$t('siteInformation.user.userInfo.description')},
        {key:'useYn', label:this.$t('siteInformation.user.userInfo.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/users`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    currentUser () {
      return utils.getUserInformation().userId === this.form.dataId
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return (this.currentUser) ? false : this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    availableAuthIds () {
      return this.codes.authorityIds.filter(item => {
        if (!this.form.siteAuthority.find(s => s.authorityId === item.value)) {
          return item
        }
      })
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      email: {
        required,
        email,
        byte: byte(64)
      },
      userName: {
        required,
        byte: byte(64)
      },
      cellphoneNo: {
        required,
        byte: byte(20)
      },
      companyId: {
        required
      },
      description: {
        byte: byte(256)
      },
      userLanguageType: {
        required
      },
      themaType: {
        required
      },
      workerPositionCode: {
        required
      },
      siteAuthority: {
        required,
        $each: {
          authorityId: {
            required
          }
        }
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getCodes('companyIds', 'v1/select/company')
    await this.getCodes('authorityIds', 'v1/select/authority')
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.$nextTick(() => {
        this.visible.form = true
      })
    },
    getEmptyForm () {
      return {
        email: '',
        userName: '',
        cellphoneNo: '',
        companyId: '',
        description: '',
        userLanguageType: '',
        themaType: 'white',
        workerPositionCode: '',
        siteAuthority: [],
        useYn: 'Y'
      }
    },
    resetData(item) {
      this.option.authorityId = ''
      this.option.isEmail = false
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.option.originalAuth = JSON.parse(JSON.stringify(deepCopy.siteAuthority))
      this.form = deepCopy
      this.form.dataId = this.form.userId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    isAuthority () {
      if (this.option.authorityId !== '') {
        this.visible.siteAuthModel = true
      } else {
        utils.showToast(this.$t('message.noSelectAuth'))
      }
    },
    updateAuthority () {
      if (this.option.authorityId !== '') {
        this.form.siteAuthority = []
        this.form.siteAuthority.push({
          userSiteAuthorityMappingId: '',
          authorityId: this.option.authorityId,
          authorityName: this.codes.authorityIds.find(s => s.value === this.option.authorityId).label,
          type: 'I'
        })
        this.option.authorityId = ''
        this.visible.siteAuthModel = false
      }
    },
    deleteAuthority (auth) {
      this.form.siteAuthority = []
    },
    emailValid(){
      let valid = this.$v.form.email.$dirty ? !this.$v.form.email.$error : null
      if(!this.form.dataId) valid = this.option.isEmail
      return valid
    },
    async isDuplicationEmail () {
      if(!this.form.email) return false
      this.disabled.submit = true
      let d = {
        moduleName : this.moduleName,
        params: {
          email: this.form.email
        },
        payload: {
          keyword: 'email',
          keywordName: this.$t('siteInformation.user.userInfo.email'),
        }
      }
      let isDupl = await this.isDuplication(d)
      this.option.isEmail = isDupl
      this.disabled.submit = false
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      this.disabled.submit = true
      if (!this.form.dataId) {
        await this.isDuplicationEmail()
      } else {
        this.option.isEmail = true
      }

      if (this.option.isEmail) {
        if (this.option.originalAuth.length > 0) {
          this.option.originalAuth.map(item => {
            let compare = this.form.siteAuthority.find(s => {
              return s.authorityId === item.authorityId
            })
            if (compare) {
              compare.userSiteAuthorityMappingId = item.userSiteAuthorityMappingId
              compare.type = ''
            } else {
              item.type = 'D'
              this.form.siteAuthority.push(item)
            }
          })
        }

        let param = this.form
        if (!this.form.dataId) {
          let encrypt = utils.setPwEncrypt(this.form.email, this.form.email)
          param.password = encrypt.dbOriginPw
          param.pw = this.form.email
        }
        let d = {
          moduleName : this.moduleName,
          params : param
        }
        await this.setData(d)
        await this.getDataList()
        this.resetData()
      }
      this.disabled.submit = false
    }
  }
}
</script>