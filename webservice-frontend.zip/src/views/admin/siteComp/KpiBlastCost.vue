<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="handlerItems" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.kpiTab.blastCostTarget')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.kpi.drillBlastCostTarget.drillBlastCostTargetId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.drillBlastCostTarget.drillBlastCostTargetId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CSelect
              :label="$t('siteInformation.kpi.drillBlastCostTarget.yearSelect')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.drillBlastCostTarget.yearSelect')])"
              :value.sync="copyTargetId"
              :options="codes.copyYears">
              <template #append>
                <CButton @click="copyYear" type="button" class="btn-custom-default outline mx-1">
                  {{ $t("commonLabel.copy") }}
                </CButton>
              </template>
            </CSelect>
            <CSelect
              :label="$t('siteInformation.kpi.drillBlastCostTarget.year')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.drillBlastCostTarget.year')])"
              :value.sync="$v.form.year.$model"
              :disabled="form.dataId !== null"
              :options="codes.years"
              :isValid="$v.form.year.$dirty ? !$v.form.year.$error : null"
              :invalidFeedback="$t('validation.required')"
              @update:value="getYears" />
            <template v-for="month in $v.form.monthly.$each.$iter">
              <CInput :key="month.month"
                :label="$t(`siteInformation.kpi.drillBlastCostTarget.${codes.monthlys[month.$model.month]}`)"
                :placeholder="$t('message.inputMessage', [$t(`siteInformation.kpi.drillBlastCostTarget.${codes.monthlys[month.$model.month]}`)])"
                type="text"
                :name="codes.monthlys[month.$model.month]"
                :append="userSite.currencyName"
                v-model.trim="month.targetValue.$model"
                :isValid="month.targetValue.$dirty ? !month.targetValue.$error : null">
                <template slot="invalid-feedback">
                  <ValidFeedback :param="month.targetValue" />
                </template>
              </CInput>
            </template>
            <CTextarea
              :label="$t('siteInformation.kpi.drillBlastCostTarget.description')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.drillBlastCostTarget.description')])"
              rows="4"
              :maxlength="200"
              name="description"
              v-model.trim="form.description"
              :isValid="$v.form.description.$dirty ? !$v.form.description.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.description" />
              </template>
            </CTextarea>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.kpi.drillBlastCostTarget.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'

import { validationMixin } from "vuelidate"
import { required, between, numeric } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "KpiBlastCost",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      targetType: 'blastCost',
      copyTargetId: null,
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        monthlys: { '01': 'jan', '02': 'fed', '03': 'mar', '04': 'apr', '05': 'may', '06': 'jun', '07': 'jul', '08': 'aug', '09': 'sep', '10': 'oct', '11': 'nov', '12': 'dec'},
        copyYears: [],
        years: []
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'year', label:this.$t('siteInformation.kpi.drillBlastCostTarget.year')},
        {key:'jan', label:this.$t('siteInformation.kpi.drillBlastCostTarget.jan')},
        {key:'fed', label:this.$t('siteInformation.kpi.drillBlastCostTarget.fed')},
        {key:'mar', label:this.$t('siteInformation.kpi.drillBlastCostTarget.mar')},
        {key:'apr', label:this.$t('siteInformation.kpi.drillBlastCostTarget.apr')},
        {key:'may', label:this.$t('siteInformation.kpi.drillBlastCostTarget.may')},
        {key:'jun', label:this.$t('siteInformation.kpi.drillBlastCostTarget.jun')},
        {key:'jul', label:this.$t('siteInformation.kpi.drillBlastCostTarget.jul')},
        {key:'aug', label:this.$t('siteInformation.kpi.drillBlastCostTarget.aug')},
        {key:'sep', label:this.$t('siteInformation.kpi.drillBlastCostTarget.sep')},
        {key:'oct', label:this.$t('siteInformation.kpi.drillBlastCostTarget.oct')},
        {key:'nov', label:this.$t('siteInformation.kpi.drillBlastCostTarget.nov')},
        {key:'dec', label:this.$t('siteInformation.kpi.drillBlastCostTarget.dec')},
        {key:'description', label:this.$t('siteInformation.kpi.drillBlastCostTarget.description')},
        {key:'useYn', label:this.$t('siteInformation.kpi.drillBlastCostTarget.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/drillBlastCostTargets`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    handlerItems () {
      return this.items.map(item => {
        return {
          drillBlastCostTargetId: item.drillBlastCostTargetId,
          year: item.year,
          jan: item.monthly[0].targetValue,
          fed: item.monthly[1].targetValue,
          mar: item.monthly[2].targetValue,
          apr: item.monthly[3].targetValue,
          may: item.monthly[4].targetValue,
          jun: item.monthly[5].targetValue,
          jul: item.monthly[6].targetValue,
          aug: item.monthly[7].targetValue,
          sep: item.monthly[8].targetValue,
          oct: item.monthly[9].targetValue,
          nov: item.monthly[10].targetValue,
          dec: item.monthly[11].targetValue,
          description: item.description,
          useYn: item.useYn
        }
      }, [])
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      year: {
        required
      },
      monthly: {
        required,
        $each: {
          targetValue: {
            numeric,
            between: between(0, 9999999)
          }
        }
      },
      description: {
        byte: byte(256)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    this.getYears(this.$moment().format('YYYY'))
    await this.getDataList()
  },
  methods: {

    getYears (currentYear) {
      if (currentYear) {
        this.codes.years = []
        let sY = parseInt(currentYear, 10) - 10
        let eY = parseInt(currentYear, 10) + 10
        for (var i=sY; i<=eY; i++) {
          this.codes.years.push({
            value: i,
            label: `${i}${this.$t('siteInformation.kpi.drillBlastCostTarget.year')}`,
          })
        }
        this.form.year = null
        this.$nextTick(() => {
          this.form.year = parseInt(currentYear, 10)
        })
      }
    },
    async getDataList() {
      this.items = []
      this.codes.copyYears = []
      this._moduleName = this.moduleName
      this.params = { targetType: this.targetType, pagable: false }
      let res = await this.requestApiSync()
      this.items = res.content
      // year 복사 : TODO => 내가 나를 복사할 수 없도록 해줘야할까?
      this.items.map(item => {
        this.codes.copyYears.push({
          value: item.drillBlastCostTargetId,
          label: `${item.year}${this.$t('siteInformation.kpi.drillBlastCostTarget.year')}`,
        })
      })
    },
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        year: parseInt(this.$moment().format('YYYY'), 10),
        description: '',
        useYn: 'Y',
        monthly: [
          { monthlyTargetId: null, month: '01', targetValue: null },
          { monthlyTargetId: null, month: '02', targetValue: null },
          { monthlyTargetId: null, month: '03', targetValue: null },
          { monthlyTargetId: null, month: '04', targetValue: null },
          { monthlyTargetId: null, month: '05', targetValue: null },
          { monthlyTargetId: null, month: '06', targetValue: null },
          { monthlyTargetId: null, month: '07', targetValue: null },
          { monthlyTargetId: null, month: '08', targetValue: null },
          { monthlyTargetId: null, month: '09', targetValue: null },
          { monthlyTargetId: null, month: '10', targetValue: null },
          { monthlyTargetId: null, month: '11', targetValue: null },
          { monthlyTargetId: null, month: '12', targetValue: null },
        ]
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(
        JSON.stringify(
          (item) ? this.items.find(s => 
            s.drillBlastCostTargetId === item.drillBlastCostTargetId
          ) || this.getEmptyForm() : this.getEmptyForm()
        )
      )
      this.form = deepCopy
      this.form.dataId = this.form.drillBlastCostTargetId || null
      this.form.targetType = this.targetType
      this.getYears(this.form.year)
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    copyYear () {
      if (this.copyTargetId) {
        let deepCopy = JSON.parse(JSON.stringify(this.items.find(s => s.drillBlastCostTargetId === this.copyTargetId)))
        if (deepCopy) {
          deepCopy.drillBlastCostTargetId = this.form.drillBlastCostTargetId || null
          deepCopy.year = this.form.year
          this.form = deepCopy
          this.form.dataId = this.form.drillBlastCostTargetId || null
          this.form.targetType = this.targetType
          this.$v.form.$reset()
        }
      } else {
        utils.showToast(this.$t('siteInformation.kpi.drillBlastCostTarget.noSelectYear'))
      }
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.handlerItems.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          drillBlastCostTargetId: this.form.drillBlastCostTargetId,
          year: this.form.year,
          targetType: this.targetType
        },
        payload : {
          keyword: 'year',
          keywordName: this.$t('siteInformation.kpi.drillBlastCostTarget.year')
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>