<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.kpiTab.fragmentationTarget')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.kpi.fragmentationTarget.fragmentationTargetId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.fragmentationTargetId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.kpi.fragmentationTarget.ruleName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.ruleName')])"
              type="text"
              name="ruleName"
              class="mt-3"
              v-model.trim="$v.form.ruleName.$model"
              :isValid="$v.form.ruleName.$dirty ? !$v.form.ruleName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.ruleName" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.kpi.fragmentationTarget.fragmentationCriteriaTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.fragmentationCriteriaTypeName')])"
              :value.sync="$v.form.fragmentationCriteriaTypeCode.$model"
              :options="codes.fragmentationCriteriaTypeCodes"
              :isValid="$v.form.fragmentationCriteriaTypeCode.$dirty ? !$v.form.fragmentationCriteriaTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.kpi.fragmentationTarget.moreLessName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.moreLessName')])"
              append="mm"
              :value.sync="$v.form.moreLessCode.$model"
              :options="codes.moreLessCodes"
              :isValid="$v.form.moreLessCode.$dirty ? !$v.form.moreLessCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.kpi.fragmentationTarget.particleSize')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.particleSize')])"
              append="m"
              type="text"
              name="particleSize"
              class="mt-3"
              v-model.trim="$v.form.particleSize.$model"
              :isValid="$v.form.particleSize.$dirty ? !$v.form.particleSize.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.particleSize" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.kpi.fragmentationTarget.description')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.kpi.fragmentationTarget.description')])"
              rows="4"
              :maxlength="200"
              name="description"
              v-model.trim="$v.form.description.$model"
              :isValid="$v.form.description.$dirty ? !$v.form.description.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.description" />
              </template>
            </CTextarea>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.kpi.fragmentationTarget.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'

import { validationMixin } from "vuelidate"
import { required, between, decimal } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "KpiFragmentation",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data () {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        fragmentationCriteriaTypeCodes: utils.getOptionCode('FragmentationCriteriaType', true),
        moreLessCodes: utils.getOptionCode('MoreLess', true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'ruleName', label:this.$t('siteInformation.kpi.fragmentationTarget.ruleName')},
        {key:'fragmentationCriteriaTypeName', label:this.$t('siteInformation.kpi.fragmentationTarget.fragmentationCriteriaTypeName')},
        {key:'moreLessName', label:this.$t('siteInformation.kpi.fragmentationTarget.moreLessName')},
        {key:'particleSize', label:this.$t('siteInformation.kpi.fragmentationTarget.particleSize'), 
          itemTemplate: (key, item) => {
            let limit = this.$v.form[key].$params.decimalLimit.limit
            let psize = item.particleSize
            // 소수점일 경우만 뒤에 0을 자리수 만큼 추가
            if(isNaN(psize) === false && Number.isInteger(psize) === false){
              psize = parseFloat(psize).toFixed(limit)
            }  
            return psize
          }
        },
        {key:'description', label:this.$t('siteInformation.kpi.fragmentationTarget.description')},
        {key:'useYn', label:this.$t('siteInformation.kpi.fragmentationTarget.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/fragmentationTargets`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      ruleName: {
        required,
        byte: byte(64)
      },
      fragmentationCriteriaTypeCode: {
        required
      },
      moreLessCode: {
        required
      },
      particleSize: {
        required,
        decimal,
        between: between(0, 100),
        decimalLimit: decimalLimit(3)
        /*numeric,
        between: between(0, 9999),*/
      },
      description: {
        byte: byte(256)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {


    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        ruleName: '',
        fragmentationCriteriaTypeCode: '',
        moreLessCode: '',
        particleSize: '',
        description: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.fragmentationTargetId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      /*
      let useYnChk = this.items.filter((item) => item.useYn === 'Y').length
      if(this.form.useYn === 'Y'){
        if(this.form.dataId){
          let self = this.items.filter((item) => item.fragmentationTargetId !== this.form.dataId)
          useYnChk = self.filter((item) => item.useYn === 'Y').length
        }
        if(useYnChk > 0){
          utils.showToastRed(`You have a target to use.`)
          this.form.useYn = 'N'
          return false
        }
      }
      */
      let d = {
        moduleName: this.moduleName,
        params : {
          fragmentationTargetId: this.form.fragmentationTargetId,
          ruleName: this.form.ruleName
        },
        payload : {
          keyword: 'ruleName',
          keywordName: this.$t('siteInformation.kpi.fragmentationTarget.ruleName')
        }
      }
      await this.setFormValidate() // 소수점체크
      this.saveDataAction(d)
    }
  }
}
</script>
