<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.costTab.drillingCost')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.cost.drillingCost.drillCostId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.drillCostId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.cost.drillingCost.drillCostName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.drillCostName')])"
              type="text"
              name="drillCostName"
              v-model.trim="$v.form.drillCostName.$model"
              :isValid="$v.form.drillCostName.$dirty ? !$v.form.drillCostName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.drillCostName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.cost.drillingCost.drillCostDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.drillCostDescription')])"
              rows="4"
              :maxlength="200"
              name="drillCostDescription"
              v-model.trim="$v.form.drillCostDescription.$model"
              :isValid="$v.form.drillCostDescription.$dirty ? !$v.form.drillCostDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.drillCostDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.cost.drillingCost.diameterValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.diameterValue')])"
              append="mm"
              :value.sync="$v.form.diameterValue.$model"
              :options="codes.diameterValues"
              :isValid="$v.form.diameterValue.$dirty ? !$v.form.diameterValue.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.cost.drillingCost.costUnitCodeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.costUnitCodeName')])"
              :value.sync="$v.form.costUnitCode.$model"
              :options="codes.costUnitCodes"
              :isValid="$v.form.costUnitCode.$dirty ? !$v.form.costUnitCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.cost.drillingCost.drillCostValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.drillingCost.drillCostValue')])"
              type="text"
              name="drillCostValue"
              :append="userSite.currencyName"
              v-model.trim="$v.form.drillCostValue.$model"
              :isValid="$v.form.drillCostValue.$dirty ? !$v.form.drillCostValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.drillCostValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.cost.drillingCost.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              size="sm"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              size="sm"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              size="sm"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              size="sm"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "CostDrilling",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        costUnitCodes: utils.getOptionCode('costUnit', true),
        diameterValues: utils.getOptionCode('diamterValue', true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'drillCostName', label:this.$t('siteInformation.cost.drillingCost.drillCostName')},
        {key:'drillCostDescription', label:this.$t('siteInformation.cost.drillingCost.drillCostDescription')},
        {key:'diameterValue', label:this.$t('siteInformation.cost.drillingCost.diameterValue')},
        {key:'costUnitCodeName', label:this.$t('siteInformation.cost.drillingCost.costUnitCodeName')},
        {key:'drillCostValue', label:this.$t('siteInformation.cost.drillingCost.drillCostValue')},
        {key:'currencyName', label:this.$t('siteInformation.cost.drillingCost.currencyName')},
        {key:'useYn', label:this.$t('siteInformation.cost.drillingCost.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/drill-costs`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      drillCostName: {
        required,
        byte: byte(64)
      },
      drillCostDescription: {
        byte: byte(256)
      },
      diameterValue: {
        required
      },
      costUnitCode: {
        required
      },
      drillCostValue: {
        required,
        decimal,
        between: between(0, 9999999.99),
        decimalLimit: decimalLimit(2)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        drillCostName: '',
        drillCostDescription: '',
        diameterValue: '',
        costUnitCode: '',
        drillCostValue: '',
        currency: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      deepCopy.currency = this.userSite.currency
      this.form = deepCopy
      this.form.dataId = this.form.drillCostId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          drillCostId: this.form.drillCostId,
          drillCostName: this.form.drillCostName
        },
        payload : {
          keyword: 'drillCostName',
          keywordName: this.$t('siteInformation.cost.drillingCost.drillCostName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>

