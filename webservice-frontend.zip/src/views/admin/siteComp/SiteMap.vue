<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0 sticky-contents">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.siteMapTab.siteMap')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard>
        <CImg :src="fileInfo.filePath" block class="image data-image" />
        <CCardFooter class="img-select-footer d-flex justify-content-between align-items-center">
          <span class="select-text">{{fileInfo.fileName}}</span>
          <label v-if="isSave"
            for="mapFile" class="btn btn-custom-default outline btn-sm file-input-label mb-0">
            {{$t('commonLabel.fileSelect')}}
            <input type="file" name="mapFile" id="mapFile" v-on:change="processFile($event)" class="file-input" />
          </label>
        </CCardFooter>
      </CCard>
      <CCard class="mb-0">
        <CForm @submit.prevent enctype="multipart/form-data">
          <!-- <CCardBody class="site-form-wrap __isimage line-none form-group-wrap"> -->
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.siteMapId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.siteMapId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <div class="mb-3">
              <label for="siteMapDatetime" class="d-block">{{$t('siteInformation.sitemap.sitemap.siteMapDatetime')}}</label>
              <CDatePicker id="siteMapDatetime" :validForm.sync="$v.form.siteMapDatetime"
                type="datetime"
                valueType="YYYY-MM-DD HH:mm"
                format="YYYYMMDD HH:mm"
                :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.siteMapDatetime')])" />
            </div>
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.siteMapName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.siteMapName')])"
              type="text"
              name="siteMapName"
              v-model.trim="$v.form.siteMapName.$model"
              :isValid="$v.form.siteMapName.$dirty ? !$v.form.siteMapName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.siteMapName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.sitemap.sitemap.siteMapDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.siteMapDescription')])"
              rows="4"
              :maxlength="200"
              name="siteMapDescription"
              v-model.trim="$v.form.siteMapDescription.$model">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.siteMapDescription" />
              </template>
            </CTextarea>
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.latitude1Value')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.latitude1Value')])"
              type="text"
              name="latitude1Value"
              v-model.trim="$v.form.latitude1Value.$model"
              :isValid="$v.form.latitude1Value.$dirty ? !$v.form.latitude1Value.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitude1Value" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.longitude1Value')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.longitude1Value')])"
              type="text"
              name="longitude1Value"
              v-model.trim="$v.form.longitude1Value.$model"
              :isValid="$v.form.longitude1Value.$dirty ? !$v.form.longitude1Value.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.longitude1Value" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.latitude2Value')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.latitude2Value')])"
              type="text"
              name="latitude2Value"
              v-model.trim="$v.form.latitude2Value.$model"
              :isValid="$v.form.latitude2Value.$dirty ? !$v.form.latitude2Value.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitude2Value" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.sitemap.longitude2Value')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.sitemap.longitude2Value')])"
              type="text"
              name="longitude2Value"
              v-model.trim="$v.form.longitude2Value.$model"
              :isValid="$v.form.longitude2Value.$dirty ? !$v.form.longitude2Value.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.longitude2Value" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.sitemap.sitemap.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: 'SiteMap',
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback,
    CDatePicker
  },
  data () {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      fileInfo: {
        defaultPath: 'img/no-image.jpg',
        filePath: '',
        fileName: ''
      },
      items: [],
      form: this.getEmptyForm()
      }
    },
    computed: {
      fields () {
        return [
          {key:'fileName', label:this.$t('siteInformation.sitemap.sitemap.fileName'), itemTemplate: (key, item) => (item.file || {}).fileName || '-' },
          {key:'siteMapDatetime', label:this.$t('siteInformation.sitemap.sitemap.siteMapDatetime'), template: 'date', dateFormat: 'YYYYMMDD HH:mm'},
          {key:'siteMapName', label:this.$t('siteInformation.sitemap.sitemap.siteMapName')},
          {key:'siteMapDescription', label:this.$t('siteInformation.sitemap.sitemap.siteMapDescription')},
          {key:'latitude1Value', label:this.$t('siteInformation.sitemap.sitemap.latitude1Value')},
          {key:'longitude1Value', label:this.$t('siteInformation.sitemap.sitemap.longitude1Value')},
          {key:'latitude2Value', label:this.$t('siteInformation.sitemap.sitemap.latitude2Value')},
          {key:'longitude2Value', label:this.$t('siteInformation.sitemap.sitemap.longitude2Value')},
          {key:'useYn', label:this.$t('siteInformation.sitemap.sitemap.useYn'), template: 'ynBadge'}
        ]
      },
      moduleName () {
        return `v1/siteInfos/${this.userSite.siteId}/siteMaps`
      },
      saveTitle () {
        return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
      },
      userSite () {
        return utils.getUserInformation().selectedUserSite
      },
      permission () {
        return this.userSite.userPermissionList.split(',')
      },
      isSave () {
        let permissionType = 'createSiteInformationSettingAdmin'
        if (this.form.dataId) {
          permissionType = 'updateSiteInformationSettingAdmin'
        }

        return this.permission.includes(permissionType)
      },
      isReset () {
        return this.permission.includes('createSiteInformationSettingAdmin')
      },
      isDelete () {
        return this.permission.includes('deleteSiteInformationSettingAdmin')
      },
      isValid () {
        return !this.$v.form.$invalid
      },
      isEditing () {
        return (this.disabled.submit || this.disabled.delete)
      }
    },
    mixins: [validationMixin, apiMixin],
    validations: {
      form: {
        siteMapDatetime: {
          required
        },
        siteMapName: {
          required,
          byte: byte(64)
        },
        siteMapDescription: {
          byte: byte(256)
        },
        latitude1Value: {
          required,
          decimal,
          between: between(-90, 90),
          decimalLimit: decimalLimit(7)
        },
        longitude1Value: {
          required,
          decimal,
          between: between(-180, 180),
          decimalLimit: decimalLimit(7)
        },
        latitude2Value: {
          required,
          decimal,
          between: between(-90, 90),
          decimalLimit: decimalLimit(7)
        },
        longitude2Value: {
          required,
          decimal,
          between: between(-180, 180),
          decimalLimit: decimalLimit(7)
        },
        file: {},
        useYn: {
          required
        }
      }
    },
    async mounted() {
      await this.getDataList()
    },
    methods: {
      /*getDataList() {
        this.items = []
        this._moduleName = this.moduleName
        this.params = { pagable: false }
        this.requestApiAsync((res)=>{
          this.items = res.content
          this.items.forEach((item) => {
            item.fileName = item.file.fileName
          })
        })
      },*/
      rowClick(item, index) {
        this.resetData(item)
        this.visible.form = true
      },
      getEmptyForm () {
        return {
          siteMapName: '',
          siteMapDescription: '',
          siteMapDatetime: '',
          latitude1Value: '',
          longitude1Value: '',
          latitude2Value: '',
          longitude2Value: '',
          latitude3Value: '',
          longitude3Value: '',
          latitude4Value: '',
          longitude4Value: '',
          mapFile: '',
          file: '',
          useYn: 'Y'
        }
      },
      resetData(item) {
        let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
        if ((deepCopy.siteMapDatetime || '') !== '') {
          deepCopy.siteMapDatetime = this.$moment.utc(deepCopy.siteMapDatetime).format('YYYY-MM-DD HH:mm')
        }
        this.fileInfo.filePath = this.fileInfo.defaultPath
        this.fileInfo.fileName = ''
        if (deepCopy.file) {
          if (deepCopy.file.fileName !== '') {
            this.fileInfo.filePath = deepCopy.file.filePath
            this.fileInfo.fileName = deepCopy.file.fileName
          }
        }

        this.form = deepCopy
        this.form.dataId = this.form.siteMapId || null
        if (!this.form.dataId) {
        this.clearSelectedClass()
      }
        this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    processFile(e) {
      this.form.mapFile = e.target.files[0]
      this.fileInfo.filePath = URL.createObjectURL(this.form.mapFile)
      this.fileInfo.fileName = this.form.mapFile.name
    },
    async saveData() {
      let d = {
        type: 'file',
        moduleName: this.moduleName,
        params : {
          siteMapId: this.form.siteMapId,
          siteMapName: this.form.siteMapName
        },
        payload : {
          keyword: 'siteMapName',
          keywordName: this.$t('siteInformation.siteMap.siteMap.siteMapName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
