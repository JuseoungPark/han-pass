<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="true" :excelName="$t('siteInformation.tab.productTab.detonators')"
            :isPage="true"
            @rowClick="rowClick">
            <template slot="firstOverTable" v-if="isReset">
              <CDropdownItem @click="toggleComponent('masterDataPopup')">{{$t('commonLabel.addData')}}</CDropdownItem>
            </template>
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.product.detonators.detonatorId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.detonatorId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.product.detonators.detonatorName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.detonatorName')])"
              type="text"
              name="detonatorName"
              v-model.trim="$v.form.detonatorName.$model"
              :isValid="$v.form.detonatorName.$dirty ? !$v.form.detonatorName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.detonatorName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.product.detonators.detonatorDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.detonatorDescription')])"
              rows="4"
              :maxlength="200"
              name="detonatorDescription"
              v-model.trim="$v.form.detonatorDescription.$model"
              :isValid="$v.form.detonatorDescription.$dirty ? !$v.form.detonatorDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.detonatorDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.product.detonators.detonatorTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.detonatorTypeName')])"
              :value.sync="$v.form.detonatorTypeCode.$model"
              :options="codes.detonatorTypeCodes"
              :isValid="$v.form.detonatorTypeCode.$dirty ? !$v.form.detonatorTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')"
              @update:value="updateDetonatorType" />
            <CSelect
              :label="$t('siteInformation.product.detonators.detonatorSubTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.detonatorSubTypeName')])"
              :value.sync="$v.form.detonatorSubTypeCode.$model"
              :options="handlerSubTypeCodes"
              :isValid="$v.form.detonatorSubTypeCode.$dirty ? !$v.form.detonatorSubTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.product.detonators.makerName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.makerName')])"
              type="text"
              name="makerName"
              v-model.trim="$v.form.makerName.$model"
              :isValid="$v.form.makerName.$dirty ? !$v.form.makerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.makerName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.surfaceDelayTimeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.surfaceDelayTimeValue')])"
              type="text"
              name="surfaceDelayTimeValue"
              append="ms"
              v-model.trim="$v.form.surfaceDelayTimeValue.$model"
              :isValid="$v.form.surfaceDelayTimeValue.$dirty ? !$v.form.surfaceDelayTimeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.surfaceDelayTimeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.delayTimeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.delayTimeValue')])"
              type="text"
              name="delayTimeValue"
              append="ms"
              v-model.trim="$v.form.delayTimeValue.$model"
              :isValid="$v.form.delayTimeValue.$dirty ? !$v.form.delayTimeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.delayTimeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.accuracyValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.accuracyValue')])"
              type="text"
              name="accuracyValue"
              append="%"
              v-model.trim="$v.form.accuracyValue.$model"
              :isValid="$v.form.accuracyValue.$dirty ? !$v.form.accuracyValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.accuracyValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.wireLengthValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.wireLengthValue')])"
              type="text"
              name="wireLengthValue"
              append="m"
              v-model.trim="$v.form.wireLengthValue.$model"
              :isValid="$v.form.wireLengthValue.$dirty ? !$v.form.wireLengthValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.wireLengthValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.priceValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.priceValue')])"
              type="text"
              name="priceValue"
              :append="userSite.currencyName"
              v-model.trim="$v.form.priceValue.$model"
              :isValid="$v.form.priceValue.$dirty ? !$v.form.priceValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.priceValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.detonators.discountValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.detonators.discountValue')])"
              type="text"
              name="discountValue"
              append="%"
              v-model.trim="$v.form.discountValue.$model"
              :isValid="$v.form.discountValue.$dirty ? !$v.form.discountValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.discountValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.product.detonators.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default hanwha outline"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <component v-if="visible.masterModal" v-bind:is="editMode"
      :moduleName="moduleName"
      title="Detonators Info"
      :fields="fields.slice(0)"
      :noFields="['priceValue', 'discountValue', 'currencyName']"
      @is-close="toggleComponent"
      @is-result="componentEvent" />
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between, numeric } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "ProductDetonators",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback,
    masterDataPopup: () => import('@/views/admin/siteComp/MasterDataPopup'),
  },
  data() {
    return {
      subComponent: '',
      visible: {
        loading: false,
        form: false,
        dangerModal: false,
        masterModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        detonatorTypeCodes: utils.getOptionCode("detonatorType", true),
        detonatorSubTypeCodes: utils.getOptionCode("detonatorSubType", true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'detonatorName', label:this.$t('siteInformation.product.detonators.detonatorName')},
        {key:'detonatorTypeCodeName', label:this.$t('siteInformation.product.detonators.detonatorTypeName')},
        {key:'detonatorSubTypeCodeName', label:this.$t('siteInformation.product.detonators.detonatorSubTypeName')},
        {key:'detonatorDescription', label:this.$t('siteInformation.product.detonators.detonatorDescription')},
        {key:'makerName', label:this.$t('siteInformation.product.detonators.makerName')},
        {key:'surfaceDelayTimeValue', label:this.$t('siteInformation.product.detonators.surfaceDelayTimeValue')},
        {key:'delayTimeValue', label:this.$t('siteInformation.product.detonators.delayTimeValue')},
        {key:'accuracyValue', label:this.$t('siteInformation.product.detonators.accuracyValue')},
        {key:'wireLengthValue', label:this.$t('siteInformation.product.detonators.wireLengthValue')},
        {key:'priceValue', label:this.$t('siteInformation.product.detonators.priceValue')},
        {key:'discountValue', label:this.$t('siteInformation.product.detonators.discountValue')},
        {key:'currencyName', label:this.$t('siteInformation.product.detonators.currencyName')},
        {key:'useYn', label:this.$t('siteInformation.product.detonators.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/detonators`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    editMode() {
      return this.subComponent
    },
    handlerSubTypeCodes () {
      if ((this.form.detonatorTypeCode || '') === '') {
        return []
      } else {
        return this.codes.detonatorSubTypeCodes.filter(item => {
          let ea = this.codes.detonatorTypeCodes.find(s => s.value === this.form.detonatorTypeCode).extend_attribute1 || ''
          if (ea !== '') {
            return ea.split(',').includes(item.value)
          }
        }, [])
      }
    }
  },
  mixins: [validationMixin, apiMixin],
  validations () {
    let detonatorSubTypeCode = {
      required
    }

    if (this.handlerSubTypeCodes.length === 0) {
      detonatorSubTypeCode = {}
    }
    
    return {
      form: {
        detonatorName: {
          required,
          byte: byte(64)
        },
        detonatorTypeCode: {
          required
        },
        detonatorSubTypeCode: detonatorSubTypeCode,
        detonatorDescription: {
          byte: byte(256)
        },
        makerName: {
          required,
          byte: byte(64)
        },
        surfaceDelayTimeValue: {
          required,
          numeric,
          between: between(0, 99999)
        },
        delayTimeValue: {
          required,
          numeric,
          between: between(0, 99999)
        },
        accuracyValue: {
          required,
          decimal,
          between: between(0, 99.99),
          decimalLimit: decimalLimit(2)
        },
        wireLengthValue: {
          required,
          decimal,
          between: between(0, 999.9),
          decimalLimit: decimalLimit(1)
        },
        priceValue: {
          required,
          decimal,
          between: between(0, 9999999.99),
          decimalLimit: decimalLimit(2)
        },
        discountValue: {
          required,
          decimal,
          between: between(0, 99.99),
          decimalLimit: decimalLimit(2)
        },
        useYn: {
          required
        }
      }
    }
  },
  mounted() {
    this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        detonatorName: '',
        detonatorTypeCode: '',
        detonatorSubTypeCode: '',
        detonatorDescription: '',
        makerName: '',
        surfaceDelayTimeValue: '',
        delayTimeValue: '',
        accuracyValue: '',
        wireLengthValue: '',
        priceValue: '',
        discountValue: '0',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      deepCopy.currency = this.userSite.currency
      this.form = deepCopy
      this.form.dataId = this.form.detonatorId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    toggleComponent(type) {
      this.subComponent = ''
      if ((type || '') !== '') {
        this.$nextTick(() => {
          this.subComponent = type
          this.visible.masterModal = true
        })
      } else {
        this.visible.masterModal = false
      }
    },
    componentEvent(item) {
      let params = { detonatorIds: item.map(item => item.detonatorId) }
      this.productDataAdd(item, params)
    },
    updateDetonatorType () {
      this.form.detonatorSubTypeCode = ''
      this.$v.form.detonatorSubTypeCode.$reset()
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          detonatorId: this.form.detonatorId,
          detonatorName: this.form.detonatorName
        },
        payload : {
          keyword: 'detonatorName',
          keywordName: this.$t('siteInformation.product.detonators.detonatorName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
