<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.siteMapTab.coordinateSystem')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.coordinatesId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.coordinatesId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.coordinatesName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.coordinatesName')])"
              type="text"
              name="coordinatesName"
              v-model.trim="$v.form.coordinatesName.$model"
              :isValid="$v.form.coordinatesName.$dirty ? !$v.form.coordinatesName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.coordinatesName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.semiMajorAxis')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.semiMajorAxis')])"
              type="text"
              name="semiMajorAxis"
              v-model.trim="$v.form.semiMajorAxis.$model"
              @focusout="setDecimal"
              :isValid="$v.form.semiMajorAxis.$dirty ? !$v.form.semiMajorAxis.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.semiMajorAxis" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.semiMinorAxis')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.semiMinorAxis')])"
              type="text"
              name="semiMinorAxis"
              v-model.trim="$v.form.semiMinorAxis.$model"
              @focusout="setDecimal"
              :isValid="$v.form.semiMinorAxis.$dirty ? !$v.form.semiMinorAxis.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.semiMinorAxis" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.flattening')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.flattening')])"
              type="text"
              name="flattening"
              v-model.trim="$v.form.flattening.$model"
              @focusout="setDecimal"
              :isValid="$v.form.flattening.$dirty ? !$v.form.flattening.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.flattening" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.latitudeOrigin')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.latitudeOrigin')])"
              type="text"
              name="latitudeOrigin"
              v-model.trim="$v.form.latitudeOrigin.$model"
              @focusout="setDecimal"
              :isValid="$v.form.latitudeOrigin.$dirty ? !$v.form.latitudeOrigin.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitudeOrigin" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.centralMeridian')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.centralMeridian')])"
              type="text"
              name="centralMeridian"
              v-model.trim="$v.form.centralMeridian.$model"
              @focusout="setDecimal"
              :isValid="$v.form.centralMeridian.$dirty ? !$v.form.centralMeridian.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.centralMeridian" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.scaleFactor')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.scaleFactor')])"
              type="text"
              name="scaleFactor"
              v-model.trim="$v.form.scaleFactor.$model"
              @focusout="setDecimal"
              :isValid="$v.form.scaleFactor.$dirty ? !$v.form.scaleFactor.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.scaleFactor" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.falseNorthing')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.falseNorthing')])"
              type="text"
              name="falseNorthing"
              v-model.trim="$v.form.falseNorthing.$model"
              @focusout="setDecimal"
              :isValid="$v.form.falseNorthing.$dirty ? !$v.form.falseNorthing.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.falseNorthing" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.sitemap.coordinateSystem.falseEasting')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.sitemap.coordinateSystem.falseEasting')])"
              type="text"
              name="falseEasting"
              v-model.trim="$v.form.falseEasting.$model"
              @focusout="setDecimal"
              :isValid="$v.form.falseEasting.$dirty ? !$v.form.falseEasting.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.falseEasting" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.sitemap.coordinateSystem.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "SiteMapCoordinateSystem",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'coordinatesName', label:this.$t('siteInformation.sitemap.coordinateSystem.coordinatesName')},
        {key:'semiMajorAxis', label:this.$t('siteInformation.sitemap.coordinateSystem.semiMajorAxis')},
        {key:'semiMinorAxis', label:this.$t('siteInformation.sitemap.coordinateSystem.semiMinorAxis')},
        {key:'flattening', label:this.$t('siteInformation.sitemap.coordinateSystem.flattening')},
        {key:'latitudeOrigin', label:this.$t('siteInformation.sitemap.coordinateSystem.latitudeOrigin')},
        {key:'centralMeridian', label:this.$t('siteInformation.sitemap.coordinateSystem.centralMeridian')},
        {key:'scaleFactor', label:this.$t('siteInformation.sitemap.coordinateSystem.scaleFactor')},
        {key:'falseNorthing', label:this.$t('siteInformation.sitemap.coordinateSystem.falseNorthing')},
        {key:'falseEasting', label:this.$t('siteInformation.sitemap.coordinateSystem.falseEasting')},
        {key:'useYn', label:this.$t('siteInformation.sitemap.coordinateSystem.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/coordinates`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      coordinatesName: {
        required,
        byte: byte(64)
      },
      semiMajorAxis: {
        required,
        decimal,
        between: between(6250000.0000000, 6550000.0000000),
        decimalLimit: decimalLimit(7)
      },
      semiMinorAxis: {
        required,
        decimal,
        between: between(6250000.0000000, 6550000.0000000),
        decimalLimit: decimalLimit(7)
      },
      flattening: {
        required,
        decimal,
        between: between(0.0000000, 1.0000000),
        decimalLimit: decimalLimit(7)
      },
      latitudeOrigin: {
        required,
        decimal,
        between: between(-90.0000000, 90.0000000),
        decimalLimit: decimalLimit(7)
      },
      centralMeridian: {
        required,
        decimal,
        between: between(-180.0000000, 180.0000000),
        decimalLimit: decimalLimit(7)
      },
      scaleFactor: {
        required,
        decimal,
        between: between(0.0000000, 2.0000000),
        decimalLimit: decimalLimit(7)
      },
      falseNorthing: {
        required,
        decimal,
        between: between(0.0000000, 99999999.9999999),
        decimalLimit: decimalLimit(7)
      },
      falseEasting: {
        required,
        decimal,
        between: between(0.0000000, 99999999.9999999),
        decimalLimit: decimalLimit(7)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    setDecimal(e){
      // console.log(e.target.name, e.target.value)
      if(e.target.value) {
        let value = parseFloat(e.target.value)
        if(!isNaN(value)){
          let limit = (this.$v.form[e.target.name].$params.decimalLimit)? this.$v.form[e.target.name].$params.decimalLimit.limit : 0
          e.target.value = value.toFixed(limit)
        }
      }
    },
    getEmptyForm () {
      return {
        coordinatesName: '',
        semiMajorAxis: '',
        semiMinorAxis: '',
        flattening: '',
        latitudeOrigin: '',
        centralMeridian: '',
        scaleFactor: '',
        falseNorthing: '',
        falseEasting: '',
        useYn: 'Y',
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.coordinatesId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          coordinatesId: this.form.coordinatesId,
          coordinatesName: this.form.coordinatesName
        },
        payload : {
          keyword: 'coordinatesName',
          keywordName: this.$t('siteInformation.sitemap.coordinateSystem.structureName'),
        }
      }
      await this.setFormValidate() // 소수점체크
      await this.saveDataAction(d)
    }
  }
};
</script>
