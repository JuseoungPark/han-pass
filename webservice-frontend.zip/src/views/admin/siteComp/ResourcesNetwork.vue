<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.resourcesTab.network')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.resources.network.gatewayId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.gatewayId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.resources.network.gatewayName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.gatewayName')])"
              type="text"
              name="gatewayName"
              v-model.trim="$v.form.gatewayName.$model"
              :isValid="$v.form.gatewayName.$dirty ? !$v.form.gatewayName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.gatewayName" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.resources.network.gatewayTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.gatewayTypeName')])"
              :value.sync="$v.form.gatewayTypeCode.$model"
              :options="codes.gatewayTypeCodes"
              :isValid="$v.form.gatewayTypeCode.$dirty ? !$v.form.gatewayTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              class="mt-3"
              :label="$t('siteInformation.resources.network.latitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.latitudeValue')])"
              type="text"
              name="latitudeValue"
              v-model.trim="$v.form.latitudeValue.$model"
              :isValid="$v.form.latitudeValue.$dirty ? !$v.form.latitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitudeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.resources.network.longitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.longitudeValue')])"
              type="text"
              name="longitudeValue"
              v-model.trim="$v.form.longitudeValue.$model"
              :isValid="$v.form.longitudeValue.$dirty ? !$v.form.longitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.longitudeValue" />
              </template>
            </CInput>
            <CTextarea
              class="mt-3"
              :label="$t('siteInformation.resources.network.description')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.network.description')])"
              rows="4"
              :maxlength="200"
              name="description"
              v-model.trim="$v.form.description.$model"
              :isValid="$v.form.description.$dirty ? !$v.form.description.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.description" />
              </template>
            </CTextarea>
            <div class="d-flex align-items-center position-relative">
              <label for="networkSwitch" class="mr-1">
                {{$t('siteInformation.resources.network.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'

import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: 'ResourcesNetwork',
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data () {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        gatewayTypeCodes: utils.getOptionCode("gatewayType", true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        { key: 'gatewayName', label: this.$t('siteInformation.resources.network.gatewayName') },
        { key: 'gatewayTypeName', label: this.$t('siteInformation.resources.network.gatewayTypeName') },
        { key: 'latitudeValue', label: this.$t('siteInformation.resources.network.latitudeValue') },
        { key: 'longitudeValue', label: this.$t('siteInformation.resources.network.longitudeValue') },
        { key: 'altitudeValue', label: this.$t('siteInformation.resources.network.altitudeValue') },
        { key: 'description', label: this.$t('siteInformation.resources.network.description') },
        { key:'useYn', label:this.$t('siteInformation.resources.network.useYn'), template: 'ynBadge' }
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/gateways`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
        return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      gatewayName: {
        required,
        byte: byte(64)
      },
      gatewayTypeCode: {
        required
      },
      latitudeValue: {
        required,
        decimal,
        between: between(-90, 90),
        decimalLimit: decimalLimit(7)
      },
      longitudeValue: {
        required,
        decimal,
        between: between(-180, 180),
        decimalLimit: decimalLimit(7)
      },
      description: {
        byte: byte(256)
      },
      useYn: {
        required
      },
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {


    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        gatewayName: '',
        gatewayTypeCode: '',
        latitudeValue: '',
        longitudeValue: '',
        description: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.gatewayId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          gatewayId: this.form.gatewayId,
          gatewayName: this.form.gatewayName
        },
        payload : {
          keyword: 'gatewayName',
          keywordName: this.$t('siteInformation.resources.network.gatewayName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>


