<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.blastTab.geometry')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.blast.geometrys.geometryId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.geometryId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.blast.geometrys.geometryName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.geometryName')])"
              type="text"
              name="geometryName"
              v-model.trim="$v.form.geometryName.$model"
              :isValid="$v.form.geometryName.$dirty ? !$v.form.geometryName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.geometryName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.blast.geometrys.burdenValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.burdenValue')])"
              type="text"
              name="burdenValue"
              append="m"
              v-model.trim="$v.form.burdenValue.$model"
              :isValid="$v.form.burdenValue.$dirty ? !$v.form.burdenValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.burdenValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.blast.geometrys.spacingValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.spacingValue')])"
              type="text"
              name="spacingValue"
              append="m"
              v-model.trim="$v.form.spacingValue.$model"
              :isValid="$v.form.spacingValue.$dirty ? !$v.form.spacingValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.spacingValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.blast.geometrys.benchHeightValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.benchHeightValue')])"
              type="text"
              name="benchHeightValue"
              append="m"
              v-model.trim="$v.form.benchHeightValue.$model"
              :isValid="$v.form.benchHeightValue.$dirty ? !$v.form.benchHeightValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.benchHeightValue" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.blast.geometrys.holeDiameterValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.holeDiameterValue')])"
              append="mm"
              :value.sync="$v.form.holeDiameterValue.$model"
              :options="codes.holeDiameterCodes"
              :isValid="$v.form.holeDiameterValue.$dirty ? !$v.form.holeDiameterValue.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.blast.geometrys.powderFactorValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.powderFactorValue')])"
              type="text"
              name="holeDiameterValue"
              append="kg/m3"
              v-model.trim="$v.form.powderFactorValue.$model"
              :isValid="$v.form.powderFactorValue.$dirty ? !$v.form.powderFactorValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.powderFactorValue" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.blast.geometrys.blastPatternTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.blast.geometrys.blastPatternTypeName')])"
              :value.sync="$v.form.blastPatternTypeCode.$model"
              :options="codes.blastPatternTypeCodes"
              :isValid="$v.form.blastPatternTypeCode.$dirty ? !$v.form.blastPatternTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <div class="d-flex align-items-center position-relative">
              <label for="useYn" class="mr-1">
                {{ $t("siteInformation.blast.geometrys.useYn") }}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              size="sm"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              size="sm"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              size="sm"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              size="sm"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "BlastGeometry",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        holeDiameterCodes: utils.getOptionCode('diamterValue', true),
        blastPatternTypeCodes: utils.getOptionCode('blastPatternType', true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'geometryId', label:this.$t('siteInformation.blast.geometrys.geometryId')},
        {key:'geometryName', label:this.$t('siteInformation.blast.geometrys.geometryName')},
        {key:'burdenValue', label:this.$t('siteInformation.blast.geometrys.burdenValue')},
        {key:'spacingValue', label:this.$t('siteInformation.blast.geometrys.spacingValue')},
        {key:'benchHeightValue', label:this.$t('siteInformation.blast.geometrys.benchHeightValue')},
        {key:'holeDiameterValue', label:this.$t('siteInformation.blast.geometrys.holeDiameterValue')},
        {key:'powderFactorValue', label:this.$t('siteInformation.blast.geometrys.powderFactorValue')},
        {key:'blastPatternTypeName', label:this.$t('siteInformation.blast.geometrys.blastPatternTypeName')},
        {key:'useYn', label:this.$t('siteInformation.blast.geometrys.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/geometrys`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      geometryName: {
        required,
        byte: byte(64)
      },
      burdenValue: {
        required,
        decimal,
        between: between(0, 1000),
        decimalLimit: decimalLimit(2)
      },
      spacingValue: {
        required,
        decimal,
        between: between(0, 1000),
        decimalLimit: decimalLimit(2)
      },
      benchHeightValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      holeDiameterValue: {
        required
      },
      powderFactorValue: {
        required,
        decimal,
        between: between(0, 9.99),
        decimalLimit: decimalLimit(2)
      },
      blastPatternTypeCode: {
        required
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        geometryName: '',
        burdenValue: '',
        spacingValue: '',
        benchHeightValue: '',
        holeDiameterValue: '',
        powderFactorValue: '',
        blastPatternTypeCode: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.geometryId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          geometryId: this.form.geometryId,
          geometryName: this.form.geometryName
        },
        payload : {
          keyword: 'companyName',
          keywordName: this.$t('siteInformation.blast.geometrys.geometryName')
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
