<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.costTab.extraCost')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.cost.extraCost.extraCostId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.extraCost.extraCostId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.cost.extraCost.extraCostName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.extraCost.extraCostName')])"
              type="text"
              name="extraCostName"
              v-model.trim="$v.form.extraCostName.$model"
              :isValid="$v.form.extraCostName.$dirty ? !$v.form.extraCostName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.extraCostName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.cost.extraCost.extraCostDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.extraCost.extraCostDescription')])"
              rows="4"
              :maxlength="200"
              name="extraCostDescription"
              v-model.trim="$v.form.extraCostDescription.$model"
              :isValid="$v.form.extraCostDescription.$dirty ? !$v.form.extraCostDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.extraCostDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.cost.extraCost.costUnitCodeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.extraCost.costUnitCodeName')])"
              :value.sync="$v.form.costUnitCode.$model"
              :options="codes.costUnitCodes"
              :isValid="$v.form.costUnitCode.$dirty ? !$v.form.costUnitCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.cost.extraCost.extraCostValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.cost.extraCost.extraCostValue')])"
              type="text"
              name="extraCostValue"
              :append="userSite.currencyName"
              v-model.trim="$v.form.extraCostValue.$model"
              :isValid="$v.form.extraCostValue.$dirty ? !$v.form.extraCostValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.extraCostValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.cost.extraCost.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "ExpenseExtra",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        costUnitCodes: utils.getOptionCode('costUnit', true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'extraCostId', label:this.$t('siteInformation.cost.extraCost.extraCostId')},
        {key:'extraCostName', label:this.$t('siteInformation.cost.extraCost.extraCostName')},
        {key:'extraCostDescription', label:this.$t('siteInformation.cost.extraCost.extraCostDescription')},
        {key:'costUnitCodeName', label:this.$t('siteInformation.cost.extraCost.costUnitCodeName')},
        {key:'extraCostValue', label:this.$t('siteInformation.cost.extraCost.extraCostValue')},
        {key:'currencyName', label:this.$t('siteInformation.cost.extraCost.currencyName')},
        {key:'useYn', label:this.$t('siteInformation.cost.extraCost.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/extra-costs`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      extraCostName: {
        required,
        byte: byte(64)
      },
      extraCostDescription: {
        byte: byte(256)
      },
      costUnitCode: {
        required
      },
      extraCostValue: {
        required,
        decimal,
        between: between(0, 9999999.99),
        decimalLimit: decimalLimit(2)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        extraCostName: '',
        extraCostDescription: '',
        costUnitCode: '',
        extraCostValue: '',
        currency: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      deepCopy.currency = this.userSite.currency
      this.form = deepCopy
      this.form.dataId = this.form.extraCostId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          extraCostId: this.form.extraCostId,
          extraCostName: this.form.extraCostName
        },
        payload : {
          keyword: 'extraCostName',
          keywordName: this.$t('siteInformation.cost.extraCost.extraCostName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
