<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :isPage="true"
            :clickableRows="false"
            @rowClick="resetData">
            <template slot="download" slot-scope="props">
              <CButton @click.stop
                class="btn-custom-default outline"
                square
                size="sm"
                @click="download(props.item)">
                Download
              </CButton>
            </template>
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <span v-if="fileFullName !== ''">
              {{ fileFullName }}
            </span>
            <label v-if="isSave"
              for="file" class="btn btn-sm btn-custom-default hanwha outline file-input-label mb-0">
              {{$t('commonLabel.fileSelect')}}
              <input type="file" ref="file" name="file" id="file" v-on:change="processFile($event)" class="file-input" />
            </label>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="isEditing || fileFullName === ''"
              class="btn-custom-default hanwha outline">
              {{$t('commonLabel.submit')}}
            </CButton>
            <CButton type="reset"
              v-if="isSave"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import utils from '@/assets/js/utils'


import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "EnvironmentVibration",
  components: {
    CThemaCover,
    DataTable
  },
  data() {
    return {
      option: {
        maxSize: 1024 * 1024 * 5
      },
      visible: {
        loading: false,
        form: false
      },
      disabled: {
        submit: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'fileName', label:this.$t('siteInformation.environment.vibrationStandard.fileName')},
        {key:'fileSizeValue', label:this.$t('siteInformation.environment.vibrationStandard.fileSizeValue'), itemTemplate: (key, item) => {
          return utils.humanReadableSize(item.fileSizeValue)
        }},
        {key:'download', label:this.$t('siteInformation.environment.vibrationStandard.download'), isDrawing: true},
      ]
    },
    moduleName () {
       return `v1/files/${this.userSite.siteId}/standard`
    },
    saveTitle () {
      return this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isEditing () {
      return this.disabled.submit
    },
    fileFullName () {
      if ((this.form.uploadFile.name || '') !== '') {
        return `${this.form.uploadFile.name}(${utils.humanReadableSize(this.form.uploadFile.size)})`
      }
      return ''
    }
  },
  mixins: [apiMixin],
  async mounted() {
    await this.getDataList()
  },
  methods: {
    getEmptyForm () {
      return {
        uploadFile: {
          name: '',
          size: 0
        }
      }
    },
    resetData() {
      this.form = this.getEmptyForm()
      this.$refs.file.value = null
      this.visible.form = true
    },
    closeData() {
      this.visible.form = false
    },
    processFile(e) {
      this.form.uploadFile = e.target.files[0]
    },
    async download (item) {
      let req = {
        moduleName : `${this.moduleName}/download/${item.fileId}`,
        params : { fileName: item.fileName},
      }
      await this.requestApiDownload(req)
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      if (this.option.maxSize < this.form.uploadFile.size) {
        utils.showToast(this.$t('message.fileSizeCheck', [utils.humanReadableSize(this.option.maxSize)]))
        return
      }
      this.disabled.submit = true
      let d = {
        type: 'file',
        moduleName : this.moduleName,
        params : this.form
      }
      await this.setData(d)
      await this.getDataList()
      this.resetData()
      this.disabled.submit = false
    }
  }
}
</script>
