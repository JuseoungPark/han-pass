<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0 sticky-contents">
        <CCardBody class="line-none">
          <!-- :isNoItemClick="false" -->
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.blastTab.blast')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard>
        <CImage v-if="fileInfo.fileId" :siteId="userSite.siteId" fileType="blastmap" :fileId="fileInfo.fileId" />
        <CImg v-else :src="fileInfo.filePath" block class="image data-image" />
        <CCardFooter class="img-select-footer d-flex justify-content-between align-items-center">
          <span v-if="fileInfo.fileName" class="select-text">
              {{ fileInfo.fileName }}
          </span>
          <!-- <label v-if="isSave"
            for="file" class="btn btn-sm btn-custom-default outline file-input-label mb-0">
            {{$t('commonLabel.fileSelect')}}
            <input type="file" ref="file" name="file" id="file" v-on:change="processFile($event)" class="file-input" />
          </label> -->
        </CCardFooter>
      </CCard>
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.blast.blast.blastId')"
              :placeholder="$t('siteInformation.blast.blast.blastId')"
              :disabled="true"
              type="text"
              name="blastId"
              v-model.trim="form.blastId" />
            <CInput
              :label="$t('siteInformation.blast.blast.blastName')"
              :placeholder="$t('siteInformation.blast.blast.blastName')"
              :disabled="true"
              type="text"
              name="blastName"
              v-model.trim="form.blastName" />
            <CInput
              :label="$t('siteInformation.blast.blast.blastDate')"
              :placeholder="$t('siteInformation.blast.blast.blastDate')"
              :disabled="true"
              type="text"
              name="blastDate"
              v-model.trim="form.blastDate" />
            <CInput
              :label="$t('siteInformation.blast.blast.blastPlanDate')"
              :placeholder="$t('siteInformation.blast.blast.blastPlanDate')"
              :disabled="true"
              type="text"
              name="blastPlanDate"
              v-model.trim="form.blastPlanDate" />
            <CInput
              :label="$t('siteInformation.blast.blast.blastDesignerName')"
              :placeholder="$t('siteInformation.blast.blast.blastDesignerName')"
              :disabled="true"
              type="text"
              name="blastDesignerName"
              v-model.trim="form.blastDesignerName" />
            <CInput
              :label="$t('siteInformation.blast.blast.shotfirerName')"
              :placeholder="$t('siteInformation.blast.blast.shotfirerName')"
              :disabled="true"
              type="text"
              name="shotfirerName"
              v-model.trim="form.shotfirerName" />
            <CInput
              :label="$t('siteInformation.blast.blast.elevationValue')"
              :placeholder="$t('siteInformation.blast.blast.elevationValue')"
              :disabled="true"
              type="text"
              name="elevationValue"
              append="m"
              v-model.trim="form.elevationValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.weatherValue')"
              :placeholder="$t('siteInformation.blast.blast.weatherValue')"
              :disabled="true"
              type="text"
              name="weatherValue"
              v-model.trim="form.weatherValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.temperatureValue')"
              :placeholder="$t('siteInformation.blast.blast.temperatureValue')"
              :disabled="true"
              type="text"
              name="temperatureValue"
              append="ºC"
              v-model.trim="form.temperatureValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.pattenTypeName')"
              :placeholder="$t('siteInformation.blast.blast.pattenTypeName')"
              :disabled="true"
              type="text"
              name="pattenTypeName"
              v-model.trim="form.pattenTypeName" />
            <CInput
              :label="$t('siteInformation.blast.blast.geometryName')"
              :placeholder="$t('siteInformation.blast.blast.geometryName')"
              :disabled="true"
              type="text"
              name="geometryName"
              v-model.trim="form.geometryName" />
            <CInput
              :label="$t('siteInformation.blast.blast.geometryDataTypeName')"
              :placeholder="$t('siteInformation.blast.blast.geometryDataTypeName')"
              :disabled="true"
              type="text"
              name="geometryDataTypeName"
              v-model.trim="form.geometryDataTypeName" />
            <CInput
              :label="$t('siteInformation.blast.blast.burdenValue')"
              :placeholder="$t('siteInformation.blast.blast.burdenValue')"
              :disabled="true"
              type="text"
              name="burdenValue"
              append="m"
              v-model.trim="form.burdenValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.spacingValue')"
              :placeholder="$t('siteInformation.blast.blast.spacingValue')"
              :disabled="true"
              type="text"
              name="spacingValue"
              append="m"
              v-model.trim="form.spacingValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.benchHeightValue')"
              :placeholder="$t('siteInformation.blast.blast.benchHeightValue')"
              :disabled="true"
              type="text"
              name="benchHeightValue"
              append="mm"
              v-model.trim="form.benchHeightValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.holeDiameterValue')"
              :placeholder="$t('siteInformation.blast.blast.holeDiameterValue')"
              :disabled="true"
              type="text"
              name="holeDiameterValue"
              append="kg/m3"
              v-model.trim="form.holeDiameterValue" />
            <CInput
              :label="$t('siteInformation.blast.blast.pfValue')"
              :placeholder="$t('siteInformation.blast.blast.pfValue')"
              :disabled="true"
              type="text"
              name="pfValue"
              v-model.trim="form.pfValue" />
            <!-- <CInput
              :label="$t('siteInformation.blast.blast.useYn')"
              :placeholder="$t('siteInformation.blast.blast.useYn')"
              :disabled="true"
              type="text"
              name="useYn"
              v-model.trim="form.useYn" />   -->
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">{{$t('siteInformation.blast.blast.useYn')}}</label>
              <CSwitchYN :value.sync="form.useYn" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              size="sm"
              v-if="isSave"
              @click="saveData"
              :disabled="isEditing"
              class="btn-custom-default hanwha outline">
              {{$t('commonLabel.submit')}}
            </CButton>
            <!-- :disabled="isEditing || fileInfo.fileId === null || fileInfo.fileName === null" -->
            <CButton type="close"
              size="sm"
              @click="closeData"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CImage from '@/components/form/CImage'
import CSwitchYN from '@/components/form/CSwitchYN'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Blast",
  components: {
    CThemaCover,
    DataTable,
    CImage,
    CSwitchYN
  },
  data() {
    return {
      option: {
        maxSize: 1024 * 1024 * 5
      },
      visible: {
        loading: false,
        form: false
      },
      disabled: {
        submit: false
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'blastId', label:this.$t('siteInformation.blast.blast.blastId')},
        {key:'blastName', label:this.$t('siteInformation.blast.blast.blastName')},
        {key:'blastDate', label:this.$t('siteInformation.blast.blast.blastDate')},
        {key:'blastPlanDate', label:this.$t('siteInformation.blast.blast.blastPlanDate')},
        {key:'blastDesignerName', label:this.$t('siteInformation.blast.blast.blastDesignerName')},
        {key:'shotfirerName', label:this.$t('siteInformation.blast.blast.shotfirerName')},
        {key:'elevationValue', label:this.$t('siteInformation.blast.blast.elevationValue')},
        {key:'weatherValue', label:this.$t('siteInformation.blast.blast.weatherValue')},
        {key:'temperatureValue', label:this.$t('siteInformation.blast.blast.temperatureValue')},
        {key:'pattenTypeName', label:this.$t('siteInformation.blast.blast.pattenTypeName')},
        {key:'geometryName', label:this.$t('siteInformation.blast.blast.geometryName')},
        {key:'geometryDataTypeName', label:this.$t('siteInformation.blast.blast.geometryDataTypeName')},
        {key:'burdenValue', label:this.$t('siteInformation.blast.blast.burdenValue')},
        {key:'spacingValue', label:this.$t('siteInformation.blast.blast.spacingValue')},
        {key:'benchHeightValue', label:this.$t('siteInformation.blast.blast.benchHeightValue')},
        {key:'holeDiameterValue', label:this.$t('siteInformation.blast.blast.holeDiameterValue')},
        {key:'pfValue', label:this.$t('siteInformation.blast.blast.pfValue')},
        {key:'useYn', label:this.$t('siteInformation.blast.blast.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/blasts`
    },
    fileModuleName () {
       return `v1/files/${this.userSite.siteId}/blastmap`
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isEditing () {
      return this.disabled.submit
    },
    fileInfo () {
      if (this.form.file) {
        return this.form.file
      }
      return {
        fileId: null,
        fileName: null,
        filePath: 'img/no-image.jpg'
      }
    }
  },
  mixins: [apiMixin],
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item) {
      if(item){
        let deepCopy = JSON.parse(JSON.stringify(item))
        // deepCopy.uploadFile = deepCopy.file
        // delete deepCopy.file
        this.form = deepCopy
        // this.$refs.file.value = null
      }
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        blastId: '',
        blastName: '',
        blastDate: '',
        blastPlanDate: '',
        blastDesignerName: '',
        shotfirerName: '',
        elevationValue: '',
        weatherValue: '',
        temperatureValue: '',
        pattenTypeName: '',
        geometryName: '',
        geometryDataTypeName: '',
        burdenValue: '',
        spacingValue: '',
        benchHeightValue: '',
        holeDiameterValue: '',
        pfValue: '',
        uploadFile: null,
        useYn: 'Y'
      }
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    processFile(e) {
      this.form.uploadFile = e.target.files[0]
      this.form.uploadFile.fileId = null
      this.form.uploadFile.fileName = this.form.uploadFile.name
      this.form.uploadFile.filePath = URL.createObjectURL(this.form.uploadFile)
    },
    async saveData() {
      if (!this.dupClickChk()) return false
      if(this.form.uploadFile){
        if (this.option.maxSize < this.form.uploadFile.size) {
          utils.showToast(this.$t('message.fileSizeCheck', [utils.humanReadableSize(this.option.maxSize)]))
          return
        }
      }
      this.disabled.submit = true
      if(this.form.uploadFile){
        let d = {
          type: 'file',
          moduleName: `${this.fileModuleName}?blastId=${this.form.blastId}`,
          params : {
            //blastId: this.form.blastId,
            uploadFile: this.form.uploadFile
          }
        }
        await this.setData(d)  
      }
      let d = {
        moduleName: `${this.moduleName}/${this.form.blastId}`,
        params : {
          useYn: this.form.useYn
        }
      }
      await this.setData(d, 'put')
      await this.getDataList()
      this.disabled.submit = false
    }
  }
}
</script>
