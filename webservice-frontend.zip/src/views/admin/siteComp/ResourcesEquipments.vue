<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.resourcesTab.equipments')"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.resources.equpments.equipmentId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.equipmentId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.resources.equpments.equipmentName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.equipmentName')])"
              type="text"
              name="equipmentName"
              v-model.trim="$v.form.equipmentName.$model"
              :isValid="$v.form.equipmentName.$dirty ? !$v.form.equipmentName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.equipmentName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.resources.equpments.equipmentDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.equipmentDescription')])"
              rows="4"
              :maxlength="200"
              name="equipmentDescription"
              v-model.trim="$v.form.equipmentDescription.$model"
              :isValid="$v.form.equipmentDescription.$dirty ? !$v.form.equipmentDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.equipmentDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.resources.equpments.equipmentTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.equipmentTypeName')])"
              :value.sync="$v.form.equipmentTypeCode.$model"
              :options="codes.equipmentTypeCodes"
              :isValid="$v.form.equipmentTypeCode.$dirty ? !$v.form.equipmentTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.resources.equpments.makerName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.makerName')])"
              type="text"
              name="makerName"
              v-model.trim="$v.form.makerName.$model"
              :isValid="$v.form.makerName.$dirty ? !$v.form.makerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.makerName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.resources.equpments.modelName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.modelName')])"
              type="text"
              name="modelName"
              v-model.trim="$v.form.modelName.$model"
              :isValid="$v.form.modelName.$dirty ? !$v.form.modelName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.modelName" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.resources.equpments.operationCompanyName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.equpments.operationCompanyName')])"
              :value.sync="$v.form.operationCompanyId.$model"
              :options="codes.companyIds"
              :isValid="$v.form.operationCompanyId.$dirty ? !$v.form.operationCompanyId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.resources.equpments.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'

import { validationMixin } from "vuelidate"
import { required } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "ResourcesEquipments",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        equipmentTypeCodes: utils.getOptionCode("equipmentType", true),
        companyIds: []
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'equipmentName', label:this.$t('siteInformation.resources.equpments.equipmentName')},
        {key:'equipmentDescription', label:this.$t('siteInformation.resources.equpments.equipmentDescription')},
        {key:'equipmentTypeName', label:this.$t('siteInformation.resources.equpments.equipmentTypeName')},
        {key:'makerName', label:this.$t('siteInformation.resources.equpments.makerName')},
        {key:'modelName', label:this.$t('siteInformation.resources.equpments.modelName')},
        {key:'companyName', label:this.$t('siteInformation.resources.equpments.operationCompanyName')},
        {key:'useYn', label:this.$t('siteInformation.product.bulk.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/equipments`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      equipmentName: {
        required,
        byte: byte(64)
      },
      equipmentDescription: {
        byte: byte(256)
      },
      equipmentTypeCode: {
        required
      },
      makerName: {
        required,
        byte: byte(100)
      },
      modelName: {
        required,
        byte: byte(100)
      },
      operationCompanyId: {
        required
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getCompany()
    await this.getDataList()
  },
  methods: {

    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        equipmentName: '',
        equipmentDescription: '',
        equipmentTypeCode: '',
        makerName: '',
        modelName: '',
        operationCompanyId: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.equipmentId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          equipmentId: this.form.equipmentId,
          equipmentName: this.form.equipmentName
        },
        payload : {
          keyword: 'equipmentName',
          keywordName: this.$t('siteInformation.resources.equpments.equipmentName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>