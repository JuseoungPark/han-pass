<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="true" :excelName="$t('siteInformation.tab.productTab.bulk')"
            :isPage="true"
            @rowClick="rowClick">
            <template slot="firstOverTable" v-if="isReset">
              <CDropdownItem @click="toggleComponent('masterDataPopup')">{{$t('commonLabel.addData')}}</CDropdownItem>
            </template>
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.product.bulk.bulkId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.bulkId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.product.bulk.bulkName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.bulkName')])"
              type="text"
              name="bulkName"
              v-model.trim="$v.form.bulkName.$model"
              :isValid="$v.form.bulkName.$dirty ? !$v.form.bulkName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.bulkName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.product.bulk.bulkDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.bulkDescription')])"
              rows="4"
              :maxlength="200"
              name="bulkDescription"
              v-model.trim="$v.form.bulkDescription.$model"
              :isValid="$v.form.bulkDescription.$dirty ? !$v.form.bulkDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.bulkDescription" />
              </template>
            </CTextarea>
            <CInput
              :label="$t('siteInformation.product.bulk.makerName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.makerName')])"
              type="text"
              name="makerName"
              v-model.trim="$v.form.makerName.$model"
              :isValid="$v.form.makerName.$dirty ? !$v.form.makerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.makerName" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.effectiveEnergyValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.effectiveEnergyValue')])"
              type="text"
              name="effectiveEnergyValue"
              append="MJ/kg"
              v-model.trim="$v.form.effectiveEnergyValue.$model"
              :isValid="$v.form.effectiveEnergyValue.$dirty ? !$v.form.effectiveEnergyValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.effectiveEnergyValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.rwsValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.rwsValue')])"
              type="text"
              name="rwsValue"
              append="%"
              v-model.trim="$v.form.rwsValue.$model"
              :isValid="$v.form.rwsValue.$dirty ? !$v.form.rwsValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rwsValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.rbsValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.rbsValue')])"
              type="text"
              name="rbsValue"
              append="%"
              v-model.trim="$v.form.rbsValue.$model"
              :isValid="$v.form.rbsValue.$dirty ? !$v.form.rbsValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rbsValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.densityValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.densityValue')])"
              type="text"
              name="densityValue"
              append="g/cc"
              v-model.trim="$v.form.densityValue.$model"
              :isValid="$v.form.densityValue.$dirty ? !$v.form.densityValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.densityValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.vodValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.vodValue')])"
              type="text"
              name="vodValue"
              append="m/s"
              v-model.trim="$v.form.vodValue.$model"
              :isValid="$v.form.vodValue.$dirty ? !$v.form.vodValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.vodValue" />
              </template>
            </CInput>
            <!-- :append="userSite.currencyName"  -->
            <CInput
              :label="$t('siteInformation.product.bulk.priceValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.priceValue')])"
              type="text"
              name="priceValue"
              append="per ton"
              v-model.trim="$v.form.priceValue.$model"
              :isValid="$v.form.priceValue.$dirty ? !$v.form.priceValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.priceValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.product.bulk.discountValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.product.bulk.discountValue')])"
              type="text"
              name="discountValue"
              append="%"
              v-model.trim="$v.form.discountValue.$model"
              :isValid="$v.form.discountValue.$dirty ? !$v.form.discountValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.discountValue" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.product.bulk.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
      {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default hanwha outline"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <component v-if="visible.masterModal" v-bind:is="editMode"
      :moduleName="moduleName"
      title="Bulk Info"
      :fields="fields.slice(0)"
      :noFields="['priceValue', 'discountValue', 'currencyName']"
      @is-close="toggleComponent"
      @is-result="componentEvent" />
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between, numeric } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "ProductBulk",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback,
    masterDataPopup: () => import('@/views/admin/siteComp/MasterDataPopup'),
  },
  data() {
    return {
      subComponent: '',
      visible: {
        loading: false,
        form: false,
        dangerModal: false,
        masterModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'bulkName', label:this.$t('siteInformation.product.bulk.bulkName')},
        {key:'bulkDescription', label:this.$t('siteInformation.product.bulk.bulkDescription')},
        {key:'makerName', label:this.$t('siteInformation.product.bulk.makerName')},
        {key:'effectiveEnergyValue', label:this.$t('siteInformation.product.bulk.effectiveEnergyValue')},
        {key:'rwsValue', label:this.$t('siteInformation.product.bulk.rwsValue')},
        {key:'densityValue', label:this.$t('siteInformation.product.bulk.densityValue')},
        {key:'vodValue', label:this.$t('siteInformation.product.bulk.vodValue')},
        {key:'rbsValue', label:this.$t('siteInformation.product.bulk.rbsValue')},
        {key:'priceValue', label:this.$t('siteInformation.product.bulk.priceValue')},
        {key:'discountValue', label:this.$t('siteInformation.product.bulk.discountValue')},
        {key:'currencyName', label:this.$t('siteInformation.product.bulk.currencyName')},
        {key:'useYn', label:this.$t('siteInformation.product.bulk.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/bulks`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    editMode() {
      return this.subComponent
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      bulkName: {
        required,
        byte: byte(64)
      },
      bulkDescription: {
        byte: byte(256)
      },
      makerName: {
        required,
        byte: byte(64)
      },
      effectiveEnergyValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      rwsValue: {
        required,
        numeric,
        between: between(0, 999)
      },
      rbsValue: {
        required,
        numeric,
        between: between(0, 999)
      },
      densityValue: {
        required,
        decimal,
        between: between(0, 9.99),
        decimalLimit: decimalLimit(2)
      },
      vodValue: {
        required,
        numeric,
        between: between(0, 9999)
      },
      priceValue: {
        required,
        decimal,
        between: between(0, 9999999.99),
        decimalLimit: decimalLimit(2)
      },
      discountValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      useYn: {
        required
      }
    }
  },
  mounted() {
    this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        bulkName: '',
        bulkDescription: '',
        makerName: '',
        effectiveEnergyValue: '',
        rwsValue: '',
        densityValue: '',
        vodValue: '',
        rbsValue: '',
        priceValue: '',
        discountValue: '0',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      deepCopy.currency = this.userSite.currency
      this.form = deepCopy
      this.form.dataId = this.form.bulkId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    toggleComponent(type) {
      this.subComponent = ''
      if ((type || '') !== '') {
        this.$nextTick(() => {
          this.subComponent = type
          this.visible.masterModal = true
        })
      } else {
        this.visible.masterModal = false
      }
    },
    componentEvent(item) {
      let params = { bulkIds: item.map(item => item.bulkId) }
      this.productDataAdd(item, params)
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          bulkId: this.form.bulkId,
          bulkName: this.form.bulkName
        },
        payload : {
          keyword: 'bulkName',
          keywordName: this.$t('siteInformation.product.bulk.bulkName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>