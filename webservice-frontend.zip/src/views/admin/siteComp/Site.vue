<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :isNoItemClick="false"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.site.site.siteId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.siteId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.site.site.siteName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.siteName')])"
              type="text"
              name="siteName"
              :disabled="true"
              v-model.trim="form.siteName" />
            <CInput
              :label="$t('siteInformation.site.site.countryCodeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.countryCodeName')])"
              type="text"
              name="countryCodeName"
              :disabled="true"
              v-model.trim="form.countryCodeName" />
              <CSelect
              :label="$t('siteInformation.site.site.siteTimeZone')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.siteTimeZone')])"
              :value.sync="$v.form.timezoneType.$model"
              :options="codes.timezoneType"
              :isValid="$v.form.timezoneType.$dirty ? !$v.form.timezoneType.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.site.site.startDatetime')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.startDatetime')])"
              type="text"
              name="startDatetime"
              :disabled="true"
              v-model.trim="form.startDatetime" />
            <CSelect
              :label="$t('siteInformation.site.site.currencyName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.currencyName')])"
              :value.sync="$v.form.currencyUnitCode.$model"
              :options="codes.currencyUnitCodes"
              :isValid="$v.form.currencyUnitCode.$dirty ? !$v.form.currencyUnitCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.site.site.mineTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.mineTypeName')])"
              :value.sync="$v.form.mineTypeCode.$model"
              :options="codes.mineTypeCodes"
              :isValid="$v.form.mineTypeCode.$dirty ? !$v.form.mineTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.site.site.locationName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.locationName')])"
              type="text"
              name="locationName"
              class="mt-3"
              v-model.trim="$v.form.locationName.$model"
              :isValid="$v.form.locationName.$dirty ? !$v.form.locationName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.locationName" />
              </template>
            </CInput>
            <CSelect
              :label="$t('siteInformation.site.site.miningCompanyName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.miningCompanyName')])"
              :value.sync="$v.form.miningCompanyId.$model"
              :options="codes.companyIds"
              :isValid="$v.form.miningCompanyId.$dirty ? !$v.form.miningCompanyId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.site.site.contractorName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.contractorName')])"
              :value.sync="$v.form.contractorId.$model"
              :options="codes.companyIds"
              :isValid="$v.form.contractorId.$dirty ? !$v.form.contractorId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.site.site.subContractorName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.subContractorName')])"
              :value.sync="$v.form.subContractorId.$model"
              :options="codes.companyIds"
              :isValid="$v.form.subContractorId.$dirty ? !$v.form.subContractorId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('siteInformation.site.site.latitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.latitudeValue')])"
              type="text"
              name="latitudeValue"
              v-model.trim="$v.form.latitudeValue.$model"
              :isValid="$v.form.latitudeValue.$dirty ? !$v.form.latitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.latitudeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('siteInformation.site.site.longitudeValue')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.site.site.longitudeValue')])"
              type="text"
              name="longitudeValue"
              v-model.trim="$v.form.longitudeValue.$model"
              :isValid="$v.form.longitudeValue.$dirty ? !$v.form.longitudeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.longitudeValue" />
              </template>
            </CInput>
            <CRow form v-if="form.dataId">
              <CCol>
                <label>{{$t('systemSetting.site.site.siteAuthority')}}</label>
                <div class="card-header-actions" v-if="form.siteAuthority.length > 1">
                  <CLink class="card-header-action btn-minimize" @click="visible.manager = !visible.manager">
                    <!-- <CIcon :name="`cil-chevron-${visible.manager ? 'top' : 'bottom'}`"/> -->
                    <app-icon :name="`${visible.manager ? 'arrowTop' : 'arrowBottom'}`" size="sss" fill class="icon-arrow mr-2"/>
                  </CLink>
                </div>
              </CCol>
            </CRow>
            <CRow v-if="form.dataId">
              <CCol>
                <transition name="fade">
                  <CCard>
                    <CCollapse v-if="form.siteAuthority.length > 1" :show="visible.manager" :duration="400">
                      <CCardBody class="line-none">
                        <CListGroup>
                          <CListGroupItem v-for="auth in form.siteAuthority" :key="auth.userId">
                            {{auth.userName}}
                          </CListGroupItem>
                        </CListGroup>
                      </CCardBody>
                    </CCollapse>
                    <CCollapse :show="!visible.manager" :duration="400">
                      <CCardBody class="line-none">
                        <CListGroup>
                          <CListGroupItem v-if="form.siteAuthority.length > 1">
                            {{ $t('commonLabel.forCount', [form.siteAuthority[0].userName, form.siteAuthority.length - 1]) }}
                          </CListGroupItem>
                          <CListGroupItem v-else>
                            {{(form.siteAuthority[0] || {}).userName || '-'}}
                          </CListGroupItem>
                        </CListGroup>
                      </CCardBody>
                    </CCollapse>
                  </CCard>
                </transition>
              </CCol>
            </CRow>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.site.site.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: 'Site',
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    AppIcon,
    ValidFeedback
  },
  data () {
    return {
      visible: {
        loading: false,
        form: false,
        dangerModal: false,
        manager: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        currencyUnitCodes: utils.getOptionCode('currencyUnit', true),
        mineTypeCodes: utils.getOptionCode('mineType', true),
        timezoneType: utils.getOptionCode('timezoneType', true),
        companyIds: []
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields() {
      return [
        {key:'siteName', label:this.$t('siteInformation.site.site.siteName')},
        {key:'startDatetime', label:this.$t('siteInformation.site.site.startDatetime'), template: 'date'},
        {key:'countryCodeName', label:this.$t('siteInformation.site.site.countryCodeName')},
        {key:'timezoneType', label:this.$t('siteInformation.site.site.siteTimeZone')},
        {key:'currencyName', label:this.$t('siteInformation.site.site.currencyName')},
        {key:'mineTypeName', label:this.$t('siteInformation.site.site.mineTypeName'), template: 'badge'},
        {key:'locationName', label:this.$t('siteInformation.site.site.locationName')},
        {key:'miningCompanyName', label:this.$t('siteInformation.site.site.miningCompanyName')},
        {key:'contractorName', label:this.$t('siteInformation.site.site.contractorName')},
        {key:'subContractorName', label:this.$t('siteInformation.site.site.subContractorName')},
        {key:'latitudeValue', label:this.$t('siteInformation.site.site.latitudeValue')},
        {key:'longitudeValue', label:this.$t('siteInformation.site.site.longitudeValue')},
        {key:'useYn', label:this.$t('siteInformation.site.site.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
      return `v1/siteInfos/${this.userSite.siteId}/sites`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      return this.permission.includes('updateSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      currencyUnitCode: {
        required
      },
      mineTypeCode: {
        required
      },
      locationName: {
        required,
        byte: byte(200)
      },
      timezoneType: {
        required
      },
      miningCompanyId: {
        required
      },
      contractorId: {
        required
      },
      subContractorId: {
        required
      },
      latitudeValue: {
        required,
        decimal,
        between: between(-90, 90),
        decimalLimit: decimalLimit(7)
      },
      longitudeValue: {
        required,
        decimal,
        between: between(-180, 180),
        decimalLimit: decimalLimit(7)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getCompany()
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        siteName: '',
        countryCode: '',
        siteTimeZone: '',
        startDatetime: '',
        currencyUnitCode: '',
        mineTypeCode: '',
        locationName: '',
        miningCompanyId: '',
        contractorId: '',
        subContractorId: '',
        latitudeValue: '',
        longitudeValue: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      if ((deepCopy.startDatetime || '') !== '') {
        deepCopy.startDatetime = this.$moment(deepCopy.startDatetime).format('YYYY-MM-DD')
      }
      this.form = deepCopy
      this.form.dataId = this.form.siteId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.submit = true
      let d = {
        moduleName : this.moduleName,
        params: {
          currencyUnitCode: this.form.currencyUnitCode,
          mineTypeCode: this.form.mineTypeCode,
          locationName: this.form.locationName,
          miningCompanyId: this.form.miningCompanyId,
          contractorId: this.form.contractorId,
          subContractorId: this.form.subContractorId,
          latitudeValue: this.form.latitudeValue,
          longitudeValue: this.form.longitudeValue,
          useYn: this.form.useYn,
        }
      }
      await this.setData(d, 'put')
      await this.getDataList()
      this.disabled.submit = false
    }
  }
}
</script>