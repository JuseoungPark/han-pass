<template>
  <CRow class="mt-3">
    <CCol lg="12">
      <CCardBody class="blasts-select-wrap line-none d-flex align-items-center justify-content-end form-group-wrap">
        <CCol lg="4">
          <div class="form-row align-items-center">
            <span class="col-form-label col-sm-3">{{$t('siteInformation.user.userLog.dateRange')}}</span>
            <CDatePicker :dateForm.sync="search.date"
              class="col-sm-9"
              type="date"
              :range="true"
              :clearable="false"
              :editable="false"
              valueType="YYYY-MM-DD"
              format="YYYY-MM-DD"
              :placeholder="$t('message.selectMessage', [$t('siteInformation.user.userLog.searchDate')])" />
          </div>
        </CCol>
        <CButton
          type="submit"
          class="btn-apply btn-custom-default hanwha outline mr-3"
          @click="searchData">
          {{ $t('commonLabel.apply') }}
        </CButton>
      </CCardBody>
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.userTab.userLog')"
            :isNoItemClick="false"
            :clickableRows="false"
            :columnFilter="false" />
        </CCardBody>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading" />
  </CRow>
</template>
<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "userLogManagement",
  components: {
    CThemaCover,
    DataTable,
    CDatePicker
  },
  data() {
    return {
      visible: {
        loading: false
      },
      search: {
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().format('YYYY-MM-DD')
        ]
      },
      items: []
    }
  },
  mixins: [apiMixin],
  computed: {
    fields () {
      return [
        {key:'userId', label:this.$t('siteInformation.user.userLog.userId')},
        {key:'email', label:this.$t('siteInformation.user.userLog.email')},
        {key:'userName', label:this.$t('siteInformation.user.userLog.userName')},
        {key:'authorityName', label:this.$t('siteInformation.user.userLog.authorityName')},
        {key:'lastloginDate', label:this.$t('siteInformation.user.userLog.lastloginDate')},
        {key:'ipAddress', label:this.$t('siteInformation.user.userLog.ipAddress')},
        {key:'loginCnt', label:this.$t('siteInformation.user.userLog.loginCnt')}
      ]
    },
    moduleName () {
      return `v1/siteInfos/${this.userSite.siteId}/connect-log`
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    async searchData () {
      if(this.search.date.length > 0){
        if (!this.$moment(this.search.date[1]).isSameOrBefore(this.$moment(this.search.date[0]).add(3, 'months').subtract(1, 'days'))) {
          utils.showToast(this.$t('message.searchPeriodCheck', [this.$t('commonLabel.monthLabel', [3])]))
          return false
        }
      }
      await this.getDataList()
    },
    async getDataList() {
      this.items = []
      this._moduleName = this.moduleName
      this.params = {
        pagable: false,
        searchStartDate: this.search.date[0] || '',
        searchEndDate: this.search.date[1] || '',
      }
      this.requestApiAsync((res)=>{
        this.items = res.content  
      })
    }
  }
}
</script>