<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields"
            :tableSettingKey="$options.name" :overTable="false" :excelName="$t('siteInformation.tab.resourcesTab.trackers')"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('siteInformation.resources.trackers.trackerId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.trackerId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('siteInformation.resources.trackers.trackerName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.trackerName')])"
              type="text"
              name="trackerName"
              v-model.trim="$v.form.trackerName.$model"
              :isValid="$v.form.trackerName.$dirty ? !$v.form.trackerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.trackerName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('siteInformation.resources.trackers.trackerDescription')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.trackerDescription')])"
              rows="4"
              :maxlength="200"
              name="trackerDescription"
              v-model.trim="$v.form.trackerDescription.$model"
              :isValid="$v.form.trackerDescription.$dirty ? !$v.form.trackerDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.trackerDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('siteInformation.resources.trackers.mappingId')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.mappingId')])"
              :value.sync="$v.form.mappingId.$model"
              :options="codes.mappingIds"
              :isValid="$v.form.mappingId.$dirty ? !$v.form.mappingId.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CSelect
              :label="$t('siteInformation.resources.trackers.trackerTypeName')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.trackerTypeName')])"
              :value.sync="$v.form.trackerTypeCode.$model"
              :options="codes.trackerTypeCodes"
              :isValid="$v.form.trackerTypeCode.$dirty ? !$v.form.trackerTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />

            <CInput
              :label="$t('siteInformation.resources.trackers.trackerNid')"
              :placeholder="$t('message.inputMessage', [$t('siteInformation.resources.trackers.trackerNid')])"
              type="text"
              name="trackerNid"
              v-model.trim="$v.form.trackerNid.$model"
              :isValid="$v.form.trackerNid.$dirty ? !$v.form.trackerNid.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.trackerNid" />
              </template>
            </CInput>  
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('siteInformation.resources.trackers.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'

import { validationMixin } from "vuelidate"
import { required } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'

import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "ResourcesTracker",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      subComponent: '',
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        trackerTypeCodes: utils.getOptionCode("trackerType", true),
        mappingIds: []
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'trackerName', label:this.$t('siteInformation.resources.trackers.trackerName')},
        {key:'trackerDescription', label:this.$t('siteInformation.resources.trackers.trackerDescription')},
        {key:'equipmentName', label:this.$t('siteInformation.resources.trackers.equipmentName')},
        {key:'trackerTypeName', label:this.$t('siteInformation.resources.trackers.trackerTypeName')},
        {key:'trackerNid', label:this.$t('siteInformation.resources.trackers.trackerNid')},
        {key:'useYn', label:this.$t('siteInformation.resources.trackers.useYn'), template: 'ynBadge'}
      ]
    },
    moduleName () {
       return `v1/siteInfos/${this.userSite.siteId}/trackers`
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSiteInformationSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSiteInformationSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSiteInformationSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSiteInformationSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    editMode() {
      return this.subComponent
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      trackerName: {
        required,
        byte: byte(64)
      },
      trackerDescription: {
        byte: byte(256)
      },
      mappingId: {
        required
      },
      trackerTypeCode: {
        required
      },
      trackerNid :{
        required
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getMappingId()
    await this.getDataList()
  },
  methods: {

    async getMappingId() {
      this.codes.mappingIds = []
      this._moduleName = 'v1/select/equipment'
      this.params = { siteId: this.userSite.siteId }
      let res = await this.requestApiSync()
      this.codes.mappingIds = res.content.map(item => {
        return {
          value: item.value,
          label: item.option
        }
      })
    },
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        trackerName: '',
        trackerDescription: '',
        mappingId: '',
        trackerTypeCode: '',
        trackerNid: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.trackerId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          trackerId: this.form.trackerId,
          trackerName: this.form.trackerName
        },
        payload : {
          keyword: 'trackerName',
          keywordName: this.$t('siteInformation.resources.trackers.trackerName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>