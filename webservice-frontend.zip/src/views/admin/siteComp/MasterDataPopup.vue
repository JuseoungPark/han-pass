<template>
  <CModal
    :show="true"
    :no-close-on-backdrop="true"
    :centered="true"
    title="Modal title 2"
    size="lg"
    color="dark">
    <CCardBody class="pop-data-table line-none">
      <DataTable :items="items" :fields="handlerFields"
        :isPage="true"
        :loading="loading"
        :isMultiSelect="true"
        :isNoItemClick="false" />
    </CCardBody>
    <template #header>
      <h5 class="modal-title">{{ title }}</h5>
      <CButtonClose @click="$emit('is-close')" class="text-white" />
    </template>
    <template #footer>
      <CButton @click="edit" class="btn-custom-default hanwha outline rectangle">{{$t('commonLabel.submit')}}</CButton>
      <CButton @click="$emit('is-close')" class="btn-custom-default outline rectangle">{{$t('commonLabel.cancel')}}</CButton>
    </template>
  </CModal>
</template>

<script>
import DataTable from '@/components/table/DataTable'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "MasterDataPopup",
  mixins: [apiMixin],
  components: {
    DataTable
  },
  props: {
    moduleName: {
      type: String,
      default () {
        return ''
      }
    },
    title: {
      type: String,
      default () {
        return 'Master Data Info'
      }
    },
    fields: {
      type: Array,
      default () {
        return []
      }
    },
    noFields: {
      type: Array,
      default () {
        return []
      }
    }
  },
  data() {
    return {
      selectedUserSite: null,
      loading: false,
      items: []
    }
  },
  computed: {
    handlerFields () {
      let columns = this.fields.filter(item => {
        return !this.noFields.includes(item.key)
      })
      columns.push({
        key: 'version',
        label: this.$t('systemSetting.masterData.bulk.version')
      })
      return columns
    }
  },
  mounted() {
    this.selectedUserSite =  utils.getUserInformation().selectedUserSite
    this.viewList()
  },
  methods: {
    async viewList () {
      this.items = []
      this._moduleName = this.moduleName
      this.params = { type: 'master', pagable: false }
      this.requestApiAsync((res)=>{
        this.items = res.content  
      })
    },
    edit () {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      let selectItem = this.items.filter(item => {
        return item._selected === true
      })
      if (selectItem.length === 0) {
        utils.showToast(this.$t('message.noSelectItem'))
        return
      }
      this.$emit('is-result', selectItem)
    }
  }
}
</script>
