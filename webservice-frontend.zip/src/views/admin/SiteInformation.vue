 <template>
  <div>
    <CRow>
      <CCol lg="12">
        <CCard>
          <CCardBody class="line-none">
            <CTabs variant="tabs" :activeTab="tabs.activeMainTab" @update:activeTab="activeTab">
              <CTab v-for="main in mainTab"
                :key="main.index"
                :title="main.title"
                sm="3">
                <CTabs v-if="main.subTabs && main.index === tabs.activeMainTab" variant="pills" class="mt-3" @update:activeTab="getEditMode">
                  <CTab v-for="sub in main.subTabs"
                    :key="sub.index"
                    :title="sub.title"
                    sm="3">
                    <component v-if="editMode === sub.editMode" v-bind:is="editMode" />
                  </CTab>
                </CTabs>
              </CTab>
            </CTabs>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  </div>
</template>

<script>
export default {
  name: 'siteInformation',
  components: {
    siteCompanyComp: () => import('@/views/admin/siteComp/SiteCompany'),
    siteComp: () => import('@/views/admin/siteComp/Site'),
    sitePitComp: () => import('@/views/admin/siteComp/SitePit'),
    siteMapComp: () => import('@/views/admin/siteComp/SiteMap'),
    measuringPointComp: () => import('@/views/admin/siteComp/SiteMapMeasuringPoint'),
    structuresComp: () => import('@/views/admin/siteComp/SiteMapStructures'),
    coordinateSystemComp: () => import('@/views/admin/siteComp/SiteMapCoordinateSystem'),
    rocksComp: () => import('@/views/admin/siteComp/Rocks'),
    productBulkComp: () => import('@/views/admin/siteComp/ProductBulk'),
    productCartridgeComp: () => import('@/views/admin/siteComp/ProductCartridge'),
    productDetonatorsComp: () => import('@/views/admin/siteComp/ProductDetonators'),
    productBoostersComp: () => import('@/views/admin/siteComp/ProductBoosters'),
    environmentVibrationComp: () => import('@/views/admin/siteComp/EnvironmentVibration'),
    environmentAttenuationComp: () => import('@/views/admin/siteComp/EnvironmentAttenuation'),
    environmentClearanceComp: () => import('@/views/admin/siteComp/EnvironmentClearance'),
    KpiDrillMeter: () => import('@/views/admin/siteComp/KpiDrillMeter'),
    KpiBlastVolume: () => import('@/views/admin/siteComp/KpiBlastVolume'),
    KpiFragmentation: () => import('@/views/admin/siteComp/KpiFragmentation'),
    KpiVibration: () => import('@/views/admin/siteComp/KpiVibration'),
    KpiBlastCost: () => import('@/views/admin/siteComp/KpiBlastCost'),
    KpiDrillCost: () => import('@/views/admin/siteComp/KpiDrillCost'),
    costDrillingComp: () => import('@/views/admin/siteComp/CostDrilling'),
    expenseLaborComp: () => import('@/views/admin/siteComp/ExpenseLabor'),
    expenseExtraComp: () => import('@/views/admin/siteComp/ExpenseExtra'),
    resourcesEquipmentsComp: () => import('@/views/admin/siteComp/ResourcesEquipments'),
    resourcesTrackerComp: () => import('@/views/admin/siteComp/ResourcesTracker'),
    resourcesNetworkComp: () => import('@/views/admin/siteComp/ResourcesNetwork'),
    blastComp: () => import('@/views/admin/siteComp/Blast'),
    blastGeometryComp: () => import('@/views/admin/siteComp/BlastGeometry'),
    criteriaAnalysisComp: () => import('@/views/admin/siteComp/CriteriaAnalysis'),
    userManagementComp: () => import('@/views/admin/siteComp/user-management'),
    userLogComp: () => import('@/views/admin/siteComp/user-log')
  },
  data() {
    return {
      subComponent: 'siteCompanyComp',
      tabs: {
        activeMainTab: 0
      }
    }
  },
  computed: {
    editMode() {
      return this.subComponent
    },
    mainTab (){
      return [
          {
            index: 0, title: this.$t('siteInformation.tab.siteTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.siteTab.company'), editMode: 'siteCompanyComp'},
              {index: 1, title: this.$t('siteInformation.tab.siteTab.site'), editMode: 'siteComp'},
              {index: 2, title: this.$t('siteInformation.tab.siteTab.pit'), editMode: 'sitePitComp'}
            ]
          },
          {
            index: 1, title: this.$t('siteInformation.tab.siteMapTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.siteMapTab.siteMap'), editMode: 'siteMapComp'},
              {index: 1, title: this.$t('siteInformation.tab.siteMapTab.mesasuringPoint'), editMode: 'measuringPointComp'},
              {index: 2, title: this.$t('siteInformation.tab.siteMapTab.structures'), editMode: 'structuresComp'},
              {index: 3, title: this.$t('siteInformation.tab.siteMapTab.coordinateSystem'), editMode: 'coordinateSystemComp'}
            ]
          },
          {
            index: 2, title: this.$t('siteInformation.tab.rocksTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.rocksTab.rocks'), editMode: 'rocksComp'}
            ]
          },
          {
            index: 3, title: this.$t('siteInformation.tab.productTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.productTab.bulk'), editMode: 'productBulkComp'},
              {index: 1, title: this.$t('siteInformation.tab.productTab.cartridge'), editMode: 'productCartridgeComp'},
              {index: 2, title: this.$t('siteInformation.tab.productTab.detonators'), editMode: 'productDetonatorsComp'},
              {index: 3, title: this.$t('siteInformation.tab.productTab.boosters'), editMode: 'productBoostersComp'}
            ]
          },
          {
            index: 4, title: this.$t('siteInformation.tab.environmentTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.environmentTab.vibrationStandard'), editMode: 'environmentVibrationComp'},
              {index: 1, title: this.$t('siteInformation.tab.environmentTab.attenuationLaw'), editMode: 'environmentAttenuationComp'},
              {index: 2, title: this.$t('siteInformation.tab.environmentTab.clearanceZone'), editMode: 'environmentClearanceComp'}
            ]
          },
          {
            index: 5, title: this.$t('siteInformation.tab.kpiTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.kpiTab.drillMeterTarget'), editMode: 'KpiDrillMeter'},
              {index: 1, title: this.$t('siteInformation.tab.kpiTab.blastVolumeTarget'), editMode: 'KpiBlastVolume'},
              {index: 2, title: this.$t('siteInformation.tab.kpiTab.fragmentationTarget'), editMode: 'KpiFragmentation'},
              {index: 3, title: this.$t('siteInformation.tab.kpiTab.vibrationTarget'), editMode: 'KpiVibration'},
              {index: 4, title: this.$t('siteInformation.tab.kpiTab.blastCostTarget'), editMode: 'KpiBlastCost'},
              {index: 5, title: this.$t('siteInformation.tab.kpiTab.drillCostTarget'), editMode: 'KpiDrillCost'}
            ]
          },
          {
            index: 6, title: this.$t('siteInformation.tab.costTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.costTab.drillingCost'), editMode: 'costDrillingComp'},
              {index: 1, title: this.$t('siteInformation.tab.costTab.laborCost'), editMode: 'expenseLaborComp'},
              {index: 2, title: this.$t('siteInformation.tab.costTab.extraCost'), editMode: 'expenseExtraComp'}
            ]
          },
          {
            index: 7, title: this.$t('siteInformation.tab.resourcesTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.resourcesTab.equipments'), editMode: 'resourcesEquipmentsComp'},
              {index: 1, title: this.$t('siteInformation.tab.resourcesTab.trackers'), editMode: 'resourcesTrackerComp'},
              {index: 2, title: this.$t('siteInformation.tab.resourcesTab.network'), editMode: 'resourcesNetworkComp'}
            ]
          },
          {
            index: 8, title: this.$t('siteInformation.tab.blastTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.blastTab.blast'), editMode: 'blastComp'},
              {index: 1, title: this.$t('siteInformation.tab.blastTab.geometry'), editMode: 'blastGeometryComp'}
            ]
          },
          {
            index: 9, title: this.$t('siteInformation.tab.criteriaTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.criteriaTab.analysisQcCriteria'), editMode: 'criteriaAnalysisComp'}
            ]
          },
          {
            index: 10, title: this.$t('siteInformation.tab.userTab.title'),
            subTabs: [
              {index: 0, title: this.$t('siteInformation.tab.userTab.userRegistration'), editMode: 'userManagementComp'},
              {index: 1, title: this.$t('siteInformation.tab.userTab.userLog'), editMode: 'userLogComp'}
            ]
          }
      ]
    },
  },
  mounted() {
    //
  },
  methods : {
    activeTab (index) {
      this.tabs.activeMainTab = index
      this.getEditMode(0)
    },
    getEditMode (index) {
      this.subComponent = ''
      this.$nextTick(() => {
        let tab = this.mainTab.find(s => s.index === this.tabs.activeMainTab).subTabs.find(s => s.index === index)
        if (tab) {
          this.subComponent = tab.editMode
        }
      })
    }
  }
}
</script>