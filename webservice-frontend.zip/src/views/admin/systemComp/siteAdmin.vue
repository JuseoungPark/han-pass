<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :isExpand="true" :tableSettingKey="$options.name"
            @rowClick="rowClick">
            <template slot="expandLayer" slot-scope="props">
              <div @click.stop>
                <CCardBody>
                  <CListGroup>
                    <CListGroupItem>
                      <h4>
                        <CBadge v-if="props.item.siteAuthority.length === 0" color="warning">{{$t('message.noSiteAdminAuth')}}</CBadge>
                        <CBadge v-for="auth in props.item.siteAuthority" :key="auth.userId" class="siteinfo mr-1">{{ auth.siteName }}</CBadge>
                      </h4>
                    </CListGroupItem>
                  </CListGroup>
                </CCardBody>
              </div>
            </template>
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.site.siteAdmin.email')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.site.siteAdmin.email')])"
              type="text"
              name="email"
              :disabled="form.dataId"
              @focusout="isDuplicationEmail"
              v-model.trim="$v.form.email.$model"
              :isValid="emailValid">
              <!-- <template #append>
                <CButton
                  v-show="!form.dataId && !option.isEmail"
                  type="button" class="btn-custom-default hanwha outline mx-1"
                  @click="isDuplicationEmail">
                  {{ $t("commonLabel.checkDuplication") }}
                </CButton>
              </template> -->
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.email" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.site.siteAdmin.userName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.site.siteAdmin.userName')])"
              type="text"
              name="userName"
              v-model.trim="$v.form.userName.$model"
              :isValid="$v.form.userName.$dirty ? !$v.form.userName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.userName" />
              </template>
            </CInput>
            <CRow form>
              <label>{{$t('systemSetting.site.siteAdmin.roleSetting')}}</label>
            </CRow>
            <CRow>
              <CCol>
                <CCardBody class="px-1">
                  <CSelect
                    class="mb-0"
                    :label="$t('systemSetting.site.siteAdmin.siteName')"
                    :placeholder="$t('message.inputMessage', [$t('systemSetting.site.siteAdmin.siteName')])"
                    :value.sync="option.siteId"
                    :options="availableSiteIds">
                    <template #append>
                      <CButton @click="isAuthority()" type="button" class="mx-1 btn-custom-default hanwha outline">
                        {{ $t("commonLabel.add") }}
                      </CButton>
                    </template>
                  </CSelect>
                  <CRow>
                    <CCol>
                      <div class="authority-list mb-3 mt-2" :class="{'icon-warning left is-invalid': !$v.form.siteAuthority.required}">
                        <ul v-if="form.siteAuthority.length === 0">
                          <li>
                            <span class="info-text">{{$t('validation.siteName')}}</span>
                          </li>
                        </ul>
                        <ul v-else>
                          <template v-for="item in form.siteAuthority">
                            <li :key="item.siteId" v-if="item.type !== 'D'">
                              {{item.siteName}}
                              <button type="button" class="btn-list-del" @click="deleteAuthority(item)">
                                <CIcon name="cil-x" class="ml-1"/>
                              </button>
                            </li>
                          </template>
                        </ul>
                      </div>
                    </CCol>
                  </CRow>
                </CCardBody>
              </CCol>
            </CRow>
            <CSelect
              :label="$t('systemSetting.site.siteAdmin.userLanguageTypeName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.site.siteAdmin.userLanguageTypeName')])"
              :value.sync="$v.form.userLanguageType.$model"
              :options="codes.userLanguageTypes"
              :isValid="$v.form.userLanguageType.$dirty ? !$v.form.userLanguageType.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CRow form class="form-group">
              <CCol sm="4">
                <label>
                {{$t('systemSetting.site.siteAdmin.themaType')}}
                </label>
              </CCol>
              <CInputRadioGroup
                custom
                :options="codes.themaTypes"
                :inline="true"
                :checked.sync="$v.form.themaType.$model" />
            </CRow>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('systemSetting.site.siteAdmin.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing || (!form.dataId && !option.isEmail)"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CModal
      :show.sync="visible.siteAuthModel"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.siteAuthConfirm')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.siteAuthModel = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="updateAuthority" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.siteAuthModel = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, email, sameAs } from "vuelidate/lib/validators"
import { byte, strongPass } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "siteAdmin",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/users",
      option: {
        siteId: '',
        originalAuth: [],
        isEmail: false
      },
      visible: {
        loading: false,
        form: false,
        dangerModal: false,
        siteAuthModel: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        siteIds: [
          {value: '', label: this.$t('message.selectMessage', [this.$t('systemSetting.site.siteAdmin.siteName')])}
        ],
        userLanguageTypes: utils.getOptionCode("multilingualType", true),
        themaTypes: ["dark", "white"]
      },
      items: [],
      form: this.getEmptyForm()
    };
  },
  computed: {
    fields () {
      return [
        {key:'email', label:this.$t('systemSetting.site.siteAdmin.email')},
        {key:'userName', label:this.$t('systemSetting.site.siteAdmin.userName')},
        {key:'userLanguageTypeName', label:this.$t('systemSetting.site.siteAdmin.userLanguageTypeName')},
        {key:'themaType', label:this.$t('systemSetting.site.siteAdmin.themaType')},
        {
          key:'siteAuthorityLen', label:this.$t('systemSetting.site.siteAdmin.siteAuthority'),
          itemTemplate: (key, item) => {
            return this.$t('commonLabel.siteCount', [item.siteAuthority.length])
          }
        },
        {
          key:'companyName', label:this.$t('systemSetting.site.siteAdmin.companyName'),
          itemTemplate: (key, item) => {
            return (item.company || {}).companyName || '-'
          }
        },
        {key:'cellphoneNo', label:this.$t('systemSetting.site.siteAdmin.cellphoneNo')},
        {key:'useYn', label:this.$t('systemSetting.site.siteAdmin.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    availableSiteIds () {
      return this.codes.siteIds.filter(item => {
        if (!this.form.siteAuthority.find(s => s.siteId === item.value)) {
          return item
        }
      })
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      email: {
        required,
        email,
        byte: byte(64)
      },
      userName: {
        required,
        byte: byte(64)
      },
      userLanguageType: {
        required
      },
      themaType: {
        required
      },
      siteAuthority: {
        required,
        $each: {
          siteId: {
            required
          }
        }
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    this.getSiteIds()
    await this.getDataList()
  },
  methods: {
    async getSiteIds() {
      this._moduleName = 'v1/select/site'
      this.params = null
      let res = await this.requestApiSync()
      res.content.forEach(item => {
        this.codes.siteIds.push({
          value: item.value,
          label: item.option
        })
      })
    },
    rowClick(item, index) {
      this.resetData(item)
      this.$nextTick(() => {
        this.visible.form = true
      })
    },
    getEmptyForm () {
      return {
        email: '',
        userName: '',
        userLanguageType: '',
        themaType: 'white',
        siteAuthority: [],
        useYn: 'Y'
      }
    },
    resetData(item) {
      this.option.siteId = ''
      this.option.isEmail = false
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.option.originalAuth = JSON.parse(JSON.stringify(deepCopy.siteAuthority))
      this.form = deepCopy
      this.form.dataId = this.form.userId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    isAuthority () {
      if (this.option.siteId !== '') {
        this.visible.siteAuthModel = true
      } else {
        utils.showToast(this.$t('message.noSelectSite'))
      }
    },
    updateAuthority () {
      if (this.option.siteId !== '') {
        this.deleteAuthority({siteId: this.option.siteId})
        this.form.siteAuthority.push({
          userSiteAuthorityMappingId: '',
          siteId: this.option.siteId,
          siteName: this.codes.siteIds.find(s => s.value === this.option.siteId).label,
          type: 'I'
        })
        this.option.siteId = ''
        this.visible.siteAuthModel = false
      }
    },
    deleteAuthority (auth) {
      this.form.siteAuthority = this.form.siteAuthority.filter(item => {
        return item.siteId != auth.siteId
      })
    },
    emailValid(){
      let valid = this.$v.form.email.$dirty ? !this.$v.form.email.$error : null
      if(!this.form.dataId) valid = this.option.isEmail
      return valid
    },
    async isDuplicationEmail () {
      if(!this.form.email) return false
      this.disabled.submit = true
      let d = {
        moduleName : this.moduleName,
        params: {
          email: this.form.email
        },
        payload: {
          keyword: 'email',
          keywordName: this.$t('siteInformation.user.userInfo.email'),
        }
      }
      let isDupl = await this.isDuplication(d)
      this.option.isEmail = isDupl
      this.disabled.submit = false
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      this.disabled.submit = true
      if (!this.form.dataId) {
        await this.isDuplicationEmail()
      } else {
        this.option.isEmail = true
      }

      if (this.option.isEmail) {
        if (this.option.originalAuth.length > 0) {
          this.option.originalAuth.map(item => {
            let compare = this.form.siteAuthority.find(s => {
              return s.siteId === item.siteId
            })
            if (compare) {
              compare.userSiteAuthorityMappingId = item.userSiteAuthorityMappingId
              compare.type = ''
            } else {
              item.type = 'D'
              this.form.siteAuthority.push(item)
            }
          })
        }

        let param = this.form
        if (!this.form.dataId) {
          let encrypt = utils.setPwEncrypt(this.form.email, this.form.email)
          param.password = encrypt.dbOriginPw
          param.pw = this.form.email
        }
        let d = {
          moduleName : this.moduleName,
          params : param
        }
        await this.setData(d)
        await this.getDataList()
        this.resetData()
      }
      this.disabled.submit = false
    }
  }
}
</script>