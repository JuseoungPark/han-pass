<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="handlerItems" :fields="fields"
            :tableSettingKey="$options.name"
            :overTable="false"
            :overTableContents="['import']"
            :excelName="$t('systemSetting.tab.multiLanguageManagement')"
            @rowClick="rowClick">
            <!-- <template slot="lastOverTable" v-if="isSave">
              <CDropdownItem @click="toggleComponent('excelUploadPopup')">Excel Upload</CDropdownItem>
            </template> -->
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="sticky-top right-top135 mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap __large line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.multiLanguageManagement.languageIdType')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.multiLanguageManagement.languageIdType')])"
              type="text"
              name="languageIdType"
              :disabled="true"
              v-model.trim="(form || {}).languageIdType" />
            <CInput
              :label="$t('systemSetting.multiLanguageManagement.languageIdCode')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.multiLanguageManagement.languageIdCode')])"
              type="text"
              name="languageIdCode"
              :disabled="true"
              v-model.trim="(form || {}).languageIdCode" />
            <CInput
              :label="$t('systemSetting.multiLanguageManagement.langName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.multiLanguageManagement.langName')])"
              type="text"
              name="langName"
              :disabled="true"
              v-model.trim="(form || {}).langName" />
            <template v-for="label in (form || {}).languageLable">
              <CInput :key="label.type"
                :label="$t(`systemSetting.multiLanguageManagement.${label.type}`)"
                :placeholder="$t('message.inputMessage', [$t(`systemSetting.multiLanguageManagement.${label.type}`)])"
                type="text"
                :name="label.type"
                class="mt-3"
                v-model.trim="label.label" />
            </template>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="isEditing"
              class="btn-custom-default hanwha outline">
              {{$t('commonLabel.submit')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <component v-if="visible.modal" v-bind:is="editMode"
      :param="upload"
      @is-close="toggleComponent"
      @is-result="componentEvent" />
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "languageManagement",
  components: {
    CThemaCover,
    DataTable,
    excelUploadPopup: () => import('@/components/form/ExcelUpload')
  },
  data() {
    return {
      moduleName: "v1/admin/languages",
      subComponent: '',
      visible: {
        loading: false,
        form: false,
        modal: false
      },
      disabled: {
        submit: false
      },
      upload: {
        keys: {
          [this.$t('systemSetting.multiLanguageManagement.languageIdCode')]: 'languageIdCode',
          [this.$t('systemSetting.multiLanguageManagement.languageIdType')]: 'languageIdType',
          [this.$t('systemSetting.multiLanguageManagement.langName')]: 'langName',
          [this.$t('systemSetting.multiLanguageManagement.ko')]: 'ko',
          [this.$t('systemSetting.multiLanguageManagement.in')]: 'in',
          [this.$t('systemSetting.multiLanguageManagement.en')]: 'en'
        },
        sampleData: []
      },
      items: [],
      form: null
    }
  },
  computed: {
    fields () {
      return [
        {key:'languageIdType', label:this.$t('systemSetting.multiLanguageManagement.languageIdType')},
        {key:'languageIdCode', label:this.$t('systemSetting.multiLanguageManagement.languageIdCode')},
        {key:'langName', label:this.$t('systemSetting.multiLanguageManagement.langName')},
        {key:'ko', label:this.$t('systemSetting.multiLanguageManagement.ko')},
        {key:'in', label:this.$t('systemSetting.multiLanguageManagement.in')},
        {key:'en', label:this.$t('systemSetting.multiLanguageManagement.en')}
      ]
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      return this.permission.includes('updateSystemSettingAdmin')
    },
    isEditing () {
      return this.disabled.submit
    },
    handlerItems () {
      return this.items.map(item => {
        return {
          languageIdType: item.languageIdType,
          languageIdCode: item.languageIdCode,
          langName: item.langName,
          ko: item.languageLable[0].label,
          in: item.languageLable[1].label,
          en: item.languageLable[2].label
        }
      }, [])
    },
    editMode() {
      return this.subComponent
    }
  },
  mixins: [apiMixin],
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    resetData(item) {
      let deepCopy = JSON.parse(
        JSON.stringify(
          this.items.find(s => 
            s.languageIdCode === item.languageIdCode
          )
        )
      )
      this.form = deepCopy
      this.form.dataId = this.form.languageIdCode || null
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.handlerItems.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    toggleComponent(type) {
      this.subComponent = ''
      if ((type || '') !== '') {
        this.$nextTick(() => {
          this.upload.sampleData = this.items
          this.subComponent = type
          this.visible.modal = true
        })
      } else {
        this.visible.modal = false
      }
    },
    async componentEvent(item) {
      // if (item) {
      //   this.disabled.submit = true
      //   await this.saveDataAction({
      //     params : {
      //       bulkIds: item.map(item => {
      //         return item.bulkId
      //       })
      //     },
      //     moduleName : this.moduleName
      //   })
      //   await this.getDataList()
      //   this.resetData()
      //   this.visible.form = false
      //   this.toggleComponent('')
      //   this.disabled.submit = false
      // }
    },
   async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      let d = {
        params : this.form,
        // moduleName : `${this.moduleName}/${this.form.dataId}`
        moduleName : this.moduleName
      }
      await this.setData(d, 'put')
      await this.getDataList()
      // this.resetData()
      this.disabled.submit = false
    }
  }
}
</script>