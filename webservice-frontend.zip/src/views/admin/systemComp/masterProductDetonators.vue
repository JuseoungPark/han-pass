<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :tableSettingKey="$options.name"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.masterData.detonators.detonatorId')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.detonatorId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('systemSetting.masterData.detonators.detonatorName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.detonatorName')])"
              type="text"
              name="detonatorName"
              v-model.trim="$v.form.detonatorName.$model"
              :isValid="$v.form.detonatorName.$dirty ? !$v.form.detonatorName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.detonatorName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('systemSetting.masterData.detonators.detonatorDescription')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.detonatorDescription')])"
              rows="4"
              :maxlength="200"
              name="detonatorDescription"
              v-model.trim="$v.form.detonatorDescription.$model"
              :isValid="$v.form.detonatorDescription.$dirty ? !$v.form.detonatorDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.detonatorDescription" />
              </template>
            </CTextarea>
            <CSelect
              :label="$t('systemSetting.masterData.detonators.detonatorTypeName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.detonatorTypeName')])"
              :value.sync="$v.form.detonatorTypeCode.$model"
              :options="codes.detonatorTypeCodes"
              :isValid="$v.form.detonatorTypeCode.$dirty ? !$v.form.detonatorTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')"
              @update:value="updateDetonatorType" />
            <CSelect
              :label="$t('systemSetting.masterData.detonators.detonatorSubTypeName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.detonatorSubTypeName')])"
              :value.sync="$v.form.detonatorSubTypeCode.$model"
              :options="handlerSubTypeCodes"
              :isValid="$v.form.detonatorSubTypeCode.$dirty ? !$v.form.detonatorSubTypeCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('systemSetting.masterData.detonators.makerName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.makerName')])"
              type="text"
              name="makerName"
              v-model.trim="$v.form.makerName.$model"
              :isValid="$v.form.makerName.$dirty ? !$v.form.makerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.makerName" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.detonators.surfaceDelayTimeValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.surfaceDelayTimeValue')])"
              type="text"
              name="surfaceDelayTimeValue"
              append="ms"
              v-model.trim="$v.form.surfaceDelayTimeValue.$model"
              :isValid="$v.form.surfaceDelayTimeValue.$dirty ? !$v.form.surfaceDelayTimeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.surfaceDelayTimeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.detonators.delayTimeValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.delayTimeValue')])"
              type="text"
              name="delayTimeValue"
              append="ms"
              v-model.trim="$v.form.delayTimeValue.$model"
              :isValid="$v.form.delayTimeValue.$dirty ? !$v.form.delayTimeValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.delayTimeValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.detonators.accuracyValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.accuracyValue')])"
              type="text"
              name="accuracyValue"
              append="%"
              v-model.trim="$v.form.accuracyValue.$model"
              :isValid="$v.form.accuracyValue.$dirty ? !$v.form.accuracyValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.accuracyValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.detonators.wireLengthValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.wireLengthValue')])"
              type="text"
              name="wireLengthValue"
              append="m"
              v-model.trim="$v.form.wireLengthValue.$model"
              :isValid="$v.form.wireLengthValue.$dirty ? !$v.form.wireLengthValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.wireLengthValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.detonators.version')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.detonators.version')])"
              type="text"
              name="version"
              v-model.trim="$v.form.version.$model"
              :isValid="$v.form.version.$dirty ? !$v.form.version.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.version" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('systemSetting.masterData.detonators.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between, numeric } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "masterProductDetonators",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/detonators",
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {
        detonatorTypeCodes: utils.getOptionCode("detonatorType", true),
        detonatorSubTypeCodes: utils.getOptionCode("detonatorSubType", true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'detonatorName', label:this.$t('systemSetting.masterData.detonators.detonatorName')},
        {key:'detonatorTypeCodeName', label:this.$t('systemSetting.masterData.detonators.detonatorTypeName')},
        {key:'detonatorSubTypeCodeName', label:this.$t('systemSetting.masterData.detonators.detonatorSubTypeName')},
        {key:'detonatorDescription', label:this.$t('systemSetting.masterData.detonators.detonatorDescription')},
        {key:'makerName', label:this.$t('systemSetting.masterData.detonators.makerName')},
        {key:'surfaceDelayTimeValue', label:this.$t('systemSetting.masterData.detonators.surfaceDelayTimeValue')},
        {key:'delayTimeValue', label:this.$t('systemSetting.masterData.detonators.delayTimeValue')},
        {key:'accuracyValue', label:this.$t('systemSetting.masterData.detonators.accuracyValue')},
        {key:'wireLengthValue', label:this.$t('systemSetting.masterData.detonators.wireLengthValue')},
        {key:'version', label:this.$t('systemSetting.masterData.detonators.version')},
        {key:'useYn', label:this.$t('systemSetting.masterData.detonators.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    },
    handlerSubTypeCodes () {
      if ((this.form.detonatorTypeCode || '') === '') {
        return []
      } else {
        return this.codes.detonatorSubTypeCodes.filter(item => {
          let ea = this.codes.detonatorTypeCodes.find(s => s.value === this.form.detonatorTypeCode).extend_attribute1 || ''
          if (ea !== '') {
            return ea.split(',').includes(item.value)
          }
        }, [])
      }
    }
  },
  mixins: [validationMixin, apiMixin],
  validations () {
    let detonatorSubTypeCode = {
      required
    }

    if (this.handlerSubTypeCodes.length === 0) {
      detonatorSubTypeCode = {}
    }
    
    return {
      form: {
        detonatorName: {
          required,
          byte: byte(64)
        },
        detonatorTypeCode: {
          required
        },
        detonatorSubTypeCode: detonatorSubTypeCode,
        detonatorDescription: {
          byte: byte(256)
        },
        makerName: {
          required,
          byte: byte(64)
        },
        surfaceDelayTimeValue: {
          required,
          numeric,
          between: between(0, 99999)
        },
        delayTimeValue: {
          required,
          numeric,
          between: between(0, 99999)
        },
        accuracyValue: {
          required,
          decimal,
          between: between(0, 99.99),
          decimalLimit: decimalLimit(2)
        },
        wireLengthValue: {
          required,
          decimal,
          between: between(0, 999.9),
          decimalLimit: decimalLimit(1)
        },
        version: {
          byte: byte(16)
        },
        useYn: {
          required
        }
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        detonatorName: '',
        detonatorTypeCode: '',
        detonatorSubTypeCode: '',
        detonatorDescription: '',
        makerName: '',
        surfaceDelayTimeValue: '',
        delayTimeValue: '',
        accuracyValue: '',
        wireLengthValue: '',
        version: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.detonatorId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    updateDetonatorType () {
      this.form.detonatorSubTypeCode = ''
      this.$v.form.detonatorSubTypeCode.$reset()
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          detonatorId: this.form.detonatorId,
          detonatorName: this.form.detonatorName
        },
        payload : {
          keyword: 'detonatorName',
          keywordName: this.$t('systemSetting.masterData.detonators.detonatorName')
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
