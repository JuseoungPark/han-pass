<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :isExpand="true" :tableSettingKey="$options.name"
            @rowClick="rowClick">
            <template slot="expandLayer" slot-scope="props">
              <div @click.stop>
                <CCardBody>
                  <CListGroup>
                    <CListGroupItem>
                      <h4>
                        <CBadge v-if="props.item.siteAuthority.length === 0" color="warning">{{$t('message.noSiteAdmin')}}</CBadge>
                        <CBadge v-for="auth in props.item.siteAuthority" :key="auth.userId" class="siteinfo mr-1">{{ auth.userName }}</CBadge>
                      </h4>
                    </CListGroupItem>
                  </CListGroup>
                </CCardBody>
              </div>
            </template>
          </DataTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.site.site.siteName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.site.site.siteName')])"
              type="text"
              name="siteName"
              v-model.trim="$v.form.siteName.$model"
              :isValid="$v.form.siteName.$dirty ? !$v.form.siteName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.siteName" />
              </template>
            </CInput>
            <div class="mb-3">
              <label for="startDatetime" class="d-block">{{$t('systemSetting.site.site.startDatetime')}}</label>
              <CDatePicker id="startDatetime" :validForm.sync="$v.form.startDatetime"
                :placeholder="$t('message.inputMessage', [$t('systemSetting.site.site.startDatetime')])" />
            </div>
            <CSelect
              :label="$t('systemSetting.site.site.countryCodeName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.site.site.countryCodeName')])"
              :value.sync="$v.form.countryCode.$model"
              :options="codes.countryCodes"
              :isValid="$v.form.countryCode.$dirty ? !$v.form.countryCode.$error : null"
              :invalidFeedback="$t('validation.required')" />
            <CInput
              :label="$t('systemSetting.site.site.mineTypeName')"
              placeholder="-"
              type="text"
              name="mineTypeName"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.mineTypeName" />
            <CInput
              :label="$t('systemSetting.site.site.locationName')"
              placeholder="-"
              type="text"
              name="locationName"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.locationName" />
            <CInput
              :label="$t('systemSetting.site.site.miningCompanyName')"
              placeholder="-"
              type="text"
              name="miningCompanyName"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.miningCompanyName" />
            <CInput
              :label="$t('systemSetting.site.site.contractorName')"
              placeholder="-"
              type="text"
              name="contractorName"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.contractorName" />
            <CInput
              :label="$t('systemSetting.site.site.subContractorName')"
              placeholder="-"
              type="text"
              name="subContractorName"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.subContractorName" />
            <CInput
              :label="$t('systemSetting.site.site.latitudeValue')"
              placeholder="-"
              type="text"
              name="latitudeValue"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.latitudeValue" />
            <CInput
              :label="$t('systemSetting.site.site.longitudeValue')"
              placeholder="-"
              type="text"
              name="longitudeValue"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.longitudeValue" />
            <CRow form v-if="form.dataId">
              <CCol>
                <label>{{$t('systemSetting.site.site.siteAuthority')}}</label>
                <div class="card-header-actions" v-if="form.siteAuthority.length > 1">
                  <CLink class="card-header-action btn-minimize" @click="visible.manager = !visible.manager">
                    <CIcon :name="`cil-chevron-${visible.manager ? 'top' : 'bottom'}`"/>
                  </CLink>
                </div>
              </CCol>
            </CRow>
            <CRow v-if="form.dataId">
              <CCol>
                <transition name="fade">
                  <CCard>
                    <CCollapse v-if="form.siteAuthority.length > 1" :show="visible.manager" :duration="400">

                      <CListGroup>
                        <CListGroupItem v-for="auth in form.siteAuthority" :key="auth.userId" class="py-1">
                          {{auth.userName}}
                        </CListGroupItem>
                      </CListGroup>

                    </CCollapse>
                    <CCollapse :show="!visible.manager" :duration="400">

                      <CListGroup>
                        <CListGroupItem v-if="form.siteAuthority.length > 1" class="py-1">
                          {{ $t('commonLabel.forCount', [form.siteAuthority[0].userName, form.siteAuthority.length - 1]) }}
                        </CListGroupItem>
                        <CListGroupItem v-else class="py-1">
                          {{(form.siteAuthority[0] || {}).userName || '-'}}
                        </CListGroupItem>
                      </CListGroup>

                    </CCollapse>
                  </CCard>
                </transition>
              </CCol>
            </CRow>
            <div class="d-flex align-items-center position-relative">
              <label for="useYn" class="mr-1">
                {{$t('systemSetting.site.site.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CDatePicker from '@/components/form/CDatePicker'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: 'Site',
  components: {
    CThemaCover,
    DataTable,
    CDatePicker,
    CSwitchYN,
    ValidFeedback
  },
  data () {
    return {
      moduleName: 'v1/admin/sites',
      visible: {
        loading: false,
        form: false,
        manager: false
      },
      disabled: {
        submit: false
      },
      codes: {
        countryCodes: utils.getOptionCode('country', true)
      },
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'siteName', label:this.$t('systemSetting.site.site.siteName')},
        {key:'startDatetime', label:this.$t('systemSetting.site.site.startDatetime'), template: 'date'},
        {key:'countryCodeName', label:this.$t('systemSetting.site.site.countryCodeName')},
        {key:'siteAuthorityLen', label:this.$t('systemSetting.site.site.siteAuthority'), itemTemplate: (key, item) => {
          return this.$t('commonLabel.userCount', [item.siteAuthority.length])
        }},
        {key:'mineTypeName', label:this.$t('systemSetting.site.site.mineTypeName'), template: 'badge'},
        {key:'miningCompanyName', label:this.$t('systemSetting.site.site.miningCompanyName')},
        {key:'contractorName', label:this.$t('systemSetting.site.site.contractorName')},
        {key:'subContractorName', label:this.$t('systemSetting.site.site.subContractorName')},
        {key:'useYn', label:this.$t('systemSetting.site.site.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return this.disabled.submit
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      siteName: {
        required,
        byte: byte(64)
      },
      startDatetime: {
        required
      },
      countryCode: {
        required
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        siteName: '',
        startDatetime: '',
        countryCode: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      if ((deepCopy.startDatetime || '') !== '') {
        deepCopy.startDatetime = this.$moment(deepCopy.startDatetime).format('YYYY-MM-DD')
      }
      this.form = deepCopy
      this.form.dataId = this.form.siteId || null
      this.visible.manager = false
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          siteId: this.form.dataId,
          siteName: this.form.siteName
        },
        payload : {
          keyword: 'siteName',
          keywordName: this.$t('systemSetting.site.site.siteName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>