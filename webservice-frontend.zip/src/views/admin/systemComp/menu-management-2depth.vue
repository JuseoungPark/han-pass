<template>
  <CRow class="mt-3">
    <CCol lg="12">
      <transition name="fade">
        <CCard class="table-card-wrap">
          <CCardHeader>
            <CAlert show color="dark" class="mb-0">
              <strong v-if="master.key === ''">{{ $t('message.selectMessage', [$t('systemSetting.menuManagement.menu2Depth.upperMenuId')]) }}</strong>
              <strong v-else>
                {{`${master.name}(${master.key})`}}
              </strong>
            </CAlert>
          </CCardHeader>
          <CCollapse :show="visible.form" :duration="400">
            <CCardBody>
              <CForm @submit.prevent>
                <CCardBody class="line-none form-group-wrap">
                  <CRow>
                    <CCol lg="3" v-if="form.dataId">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.menuId')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.menuId')])"
                        type="text"
                        name="dataId"
                        :disabled="true"
                        v-model.trim="form.dataId" />
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.menuNm')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.menuNm')])"
                        type="text"
                        name="menuNm"
                        v-model.trim="$v.form.menuNm.$model"
                        :isValid="$v.form.menuNm.$dirty ? !$v.form.menuNm.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.menuNm" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.menuIconType')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.menuIconType')])"
                        type="text"
                        name="menuIconType"
                        v-model.trim="$v.form.menuIconType.$model"
                        :isValid="$v.form.menuIconType.$dirty ? !$v.form.menuIconType.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.menuIconType" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <div class="d-flex">
                        <div class="position-relative">
                          <label for="useYn" class="mb-3 d-block">
                            {{$t('systemSetting.menuManagement.menu2Depth.useYn')}}
                          </label>
                          <CSwitchYN :value.sync="$v.form.useYn.$model" />
                        </div>
                      </div>
                    </CCol>
                    <CCol lg="3" v-if="!form.dataId"></CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.menuUrl')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.menuUrl')])"
                        type="text"
                        name="menuUrl"
                        v-model.trim="$v.form.menuUrl.$model"
                        :isValid="$v.form.menuUrl.$dirty ? !$v.form.menuUrl.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.menuUrl" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.apiUrl')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.apiUrl')])"
                        type="text"
                        name="apiUrl"
                        v-model.trim="$v.form.apiUrl.$model"
                        :isValid="$v.form.apiUrl.$dirty ? !$v.form.apiUrl.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.apiUrl" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.programName')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.programName')])"
                        type="text"
                        name="programName"
                        v-model.trim="$v.form.programName.$model"
                        :isValid="$v.form.programName.$dirty ? !$v.form.programName.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.programName" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.menuManagement.menu2Depth.orderNo')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.orderNo')])"
                        type="text"
                        name="orderNo"
                        v-model.trim="$v.form.orderNo.$model"
                        :isValid="$v.form.orderNo.$dirty ? !$v.form.orderNo.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.orderNo" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol  lg="9">
                      <label for="actionType">
                        {{$t('systemSetting.menuManagement.menu2Depth.actionType')}}
                      </label>
                      <CMselect id="actionType" :validForm.sync="$v.form.actionType"
                        :options="codes.actionTypes"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu2Depth.actionType')])" />
                    </CCol>
                  </CRow>
                </CCardBody>
                <CCardFooter class="text-right">
                  <CButton type="submit"
                    v-if="isSave"
                    @click="saveData"
                    :disabled="!isValid || isEditing"
                    class="btn-custom-default hanwha outline">
                    {{ saveTitle }}
                  </CButton>
                  <CButton type="reset"
                    v-if="isReset"
                    @click.prevent="resetData(null)"
                    :disabled="isEditing"
                    class="btn-custom-default outline">
                    {{$t('commonLabel.reset')}}
                  </CButton>
                  <CButton  type="delete"
                    v-if="isDelete"
                    @click="visible.dangerModal = true"
                    :disabled="isEditing || !form.dataId"
                    class="btn-custom-default outline">
                    {{$t('commonLabel.delete')}}
                  </CButton>
                </CCardFooter>
              </CForm>
            </CCardBody>
          </CCollapse>
        </CCard>
      </transition>
    </CCol>
    <CCol :lg="!visible.subList ? 12 : 6">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="masterItems" :fields="masterFields" :tableSettingKey="`${$options.name}_1`"
            :isNoItemClick="false"
            @rowClick="masterRowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.subList" lg="6" class="lg-mt">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="subItems" :fields="subFields" :tableSettingKey="`${$options.name}_2`"
            @rowClick="subRowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import CMselect from '@/components/form/CMselect'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, numeric } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "codeManagement2depth",
  props: {
    param: {
      type: Object,
      default () {
        return null
      }
    }
  },
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    CMselect,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/menus",
      visible: {
        loading: false,
        subList: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      master: {
        key: '',
        name: ''
      },
      codes: {
        actionTypes: [
          { value: 'view', label: 'view' },
          { value: 'create', label: 'create' },
          { value: 'update', label: 'update' },
          { value: 'delete', label: 'delete' },
          { value: 'print', label: 'print' }
        ]
      },
      masterItems: [],
      subItems: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    masterFields () {
      return [
        {key:'menuIdCode', label:this.$t('systemSetting.menuManagement.menu1Depth.menuIdCode')},
        {key:'menuNm', label:this.$t('systemSetting.menuManagement.menu1Depth.menuNm')},
        {key:'menuCount', label:this.$t('systemSetting.menuManagement.menu1Depth.menuCount')},
        {key:'useYn', label:this.$t('systemSetting.menuManagement.menu1Depth.useYn'), template: 'ynBadge'}
      ]
    },
    subFields () {
      return [
        {key:'menuIdCode', label:this.$t('systemSetting.menuManagement.menu2Depth.menuIdCode')},
        {key:'menuNm', label:this.$t('systemSetting.menuManagement.menu2Depth.menuNm')},
        {key:'menuUrl', label:this.$t('systemSetting.menuManagement.menu2Depth.menuUrl')},
        {key:'programName', label:this.$t('systemSetting.menuManagement.menu2Depth.programName')},
        {key:'orderNo', label:this.$t('systemSetting.menuManagement.menu2Depth.orderNo')},
        {key:'actionType', label:this.$t('systemSetting.menuManagement.menu2Depth.actionType')},
        {key:'useYn', label:this.$t('systemSetting.menuManagement.menu2Depth.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      menuNm: {
        required,
        byte: byte(64)
      },
      menuIconType: {
        required,
        byte: byte(16)
      },
      menuUrl: {
        required,
        byte: byte(2000)
      },
      apiUrl: {
        byte: byte(255)
      },
      actionType: {
        required
      },
      programName: {
        required,
        byte: byte(100)
      },
      orderNo: {
        required,
        numeric
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.viewMasterList()
    if (this.param) {
      this.masterRowClick(this.param)
    }
  },
  methods: {
    async viewMasterList() {
      this.masterItems = []
      this.subItems = []
      this._moduleName = `${this.moduleName}/1`
      this.params = { pagable: false }
      let res = await this.requestApiSync()
      this.masterItems = res.content
    },
    async viewSubList() {
      this.subItems = []
      this._moduleName = `${this.moduleName}/${this.master.key}`
      this.params = { pagable: false }
      let res = await this.requestApiSync()
      this.subItems = res.content
    },
    async masterRowClick(item) {
      this.visible.loading = true
      this.master = {
        key: item.menuId,
        name: item.menuNm
      }
      await this.viewSubList()
      this.resetData()
      this.visible.form = true
      this.visible.subList = true
      this.visible.loading = false
    },
    subRowClick(item) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        menuNm: '',
        menuIconType: '',
        menuUrl: '',
        apiUrl: '',
        actionType: '',
        programName: '',
        orderNo: '',
        menuDepth: 1,
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.menuId || null
      this.form.upperMenuId = this.master.key || null
      this.form.actionType = (this.form.actionType || '').split(',').filter(item => {
        return item !== ''
      }).map(action => {
        return {
          value: action,
          label: action
        }
      })
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    clearSelectedClass () {
      let clickableRows = this.subItems.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.submit = true
      let d = {
        moduleName : `${this.moduleName}/${this.master.key}`,
        params: {
          menuId: this.form.menuId,
          menuNm: this.form.menuNm
        },
        payload: {
          keyword: 'menuNm',
          keywordName: this.$t('systemSetting.menuManagement.menu2Depth.menuNm')
        }        
      }
      let isDupl = await this.isDuplication(d)
      if (isDupl) {
        this.form.actionType = this.form.actionType.map(item => {
          return item.value
        }).join(',')
        d.params = this.form
        await this.setData(d)
        await this.viewSubList()
        this.resetData()
      }
      this.disabled.submit = false
    }, 
    async deleteData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.delete = true
      let d = {
        moduleName: `${this.moduleName}/${this.master.key}`,
        params: this.form
      }
      await this.setDataDel(d)
      await this.viewSubList()
      this.resetData()
      this.visible.dangerModal = false
      this.disabled.delete = false
    }
  }
}
</script>