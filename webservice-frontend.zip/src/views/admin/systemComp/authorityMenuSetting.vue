<template>
  <CRow class="mt-3">
    <CCol lg="12">
      <CCard>
        <CCardHeader>
          <CAlert show color="dark" class="mb-0">
            <strong v-if="master.key === ''">{{ $t('message.selectMessage', [$t('systemSetting.authorityManagement.authorityType.authorityIdCode')]) }}</strong>
            <strong v-else>
              {{`${master.name}(${master.key})`}}
            </strong>
          </CAlert>
        </CCardHeader>
      </CCard>
    </CCol>
    <CCol :lg="!visible.form ? 12 : 5">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="masterItems" :fields="masterFields" :tableSettingKey="`${$options.name}_1`"
            :isNoItemClick="false"
            @rowClick="masterRowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="7" class="lg-mt">
      <CCard class="table-card-wrap sticky-top right-top135 mb-0">
        <CCardBody class="line-none">
          <DataTable :items="subItems" :fields="subFields" :tableSettingKey="`${$options.name}_2`"
            :clickableRows="false"
            :column-filter="false"
            :sorter="false">
            <template slot="create" slot-scope="props">
              <menuRoleItem actionType="create" :permission="props.item.permission" />
            </template>
            <template slot="view" slot-scope="props">
              <menuRoleItem actionType="view" :permission="props.item.permission" />
            </template>
            <template slot="update" slot-scope="props">
              <menuRoleItem actionType="update" :permission="props.item.permission" />
            </template>
            <template slot="delete" slot-scope="props">
              <menuRoleItem actionType="delete" :permission="props.item.permission" />
            </template>
            <template slot="print" slot-scope="props">
              <menuRoleItem actionType="print" :permission="props.item.permission" />
            </template>
          </DataTable>
        </CCardBody>
        <CCardFooter align="right">
          <CButton type="submit"
            v-if="isSave"
            @click="saveData"
            :disabled="isEditing"
            class="btn-custom-default hanwha outline">
            {{$t('commonLabel.submit')}}
          </CButton>
          <CButton type="close"
            @click="closeData"
            :disabled="isEditing"
            class="btn-custom-default outline">
            {{$t('commonLabel.close')}}
          </CButton>
        </CCardFooter>
      </CCard>
    </CCol>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import menuRoleItem from './menuRoleItem'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'
export default {
  name: "menuAuthority",
  props: {
    param: {
      type: Object,
      default () {
        return null
      }
    }
  },
  components: {
    CThemaCover,
    DataTable,
    menuRoleItem
  },
  data() {
    return {
      moduleName: "v1/admin/authoritys",
      visible: {
        loading: false,
        form: false
      },
      disabled: {
        submit: false
      },
      master: {
        key: '',
        name: ''
      },
      masterItems: [],
      subItems: []
    }
  },
  computed: {
    masterFields () {
      return [
        {key:'authorityIdCode', label:this.$t('systemSetting.authorityManagement.authorityType.authorityIdCode')},
        {key:'authorityName', label:this.$t('systemSetting.authorityManagement.authorityType.authorityName')}
      ]
    },
    subFields () {
      return [
        {key:'menuName', label:this.$t('systemSetting.menuManagement.menu1Depth.menuNm')},
        {key:'create', label:this.$t('systemSetting.authorityManagement.authoritySetting.create'), isDrawing: true},
        {key:'view', label:this.$t('systemSetting.authorityManagement.authoritySetting.view'), isDrawing: true},
        {key:'update', label:this.$t('systemSetting.authorityManagement.authoritySetting.update'), isDrawing: true},
        {key:'delete', label:this.$t('systemSetting.authorityManagement.authoritySetting.delete'), isDrawing: true},
        {key:'print', label:this.$t('systemSetting.authorityManagement.authoritySetting.print'), isDrawing: true}
      ]
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      return this.permission.includes('updateSystemSettingAdmin')
    },
    isEditing () {
      return this.disabled.submit
    }
  },
  mixins: [apiMixin],
  async mounted() {
    await this.getDataList()
    if (this.param) {
      this.masterRowClick(this.param)
    }
  },
  methods: {
    async getDataList() {
      this.masterItems = []
      this._moduleName = this.moduleName
      this.params = { pagable: false }
      let res = await this.requestApiSync()
      this.masterItems = res.content
    },
    async viewSubList() {
      this.subItems = []
      this._moduleName = `${this.moduleName}/${this.master.key}/menus`
      this.params = { pagable: false }
      let res = await this.requestApiSync()
      this.subItems = res.content
      //this.subItems = res.content.filter(item => item.useYn === 'Y')
    },
    async masterRowClick(item) {
      this.master = {
        key: item.authorityId,
        name: item.authorityName
      }
      await this.viewSubList()
      this.visible.form = true
    },
    closeData() {
      this.master = {
        key: '',
        name: ''
      }
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.masterItems.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.submit = true
      let d = {
        moduleName : `${this.moduleName}/${this.master.key}/menus`,
        params : {content: this.subItems}
      }
      await this.setData(d, 'put')
      await this.viewSubList()
      this.disabled.submit = false
    }
  }
}
</script>