<template>
  <CInputCheckbox
    :checked.sync="checked"
    :disabled="disabled"
    @update:checked="checkFlag"
    custom />
</template>

<script>
export default {
  name: `menuRoleItem`,
  props: {
    permission: {
      type: Array,
      required: true
    },
    actionType: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      checked: (this.permission.find(s => s.actionType === this.actionType).checked === 'Y'),
      disabled: (this.permission.find(s => s.actionType === this.actionType).disabled === 'Y'),
    }
  },
  methods: {
    checkFlag () {
      this.permission.find(s => s.actionType === this.actionType).checked = (this.checked ? 'Y' : 'N')
    }
  }
}
</script>