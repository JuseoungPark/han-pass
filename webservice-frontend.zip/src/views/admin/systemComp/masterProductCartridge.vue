<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :tableSettingKey="$options.name"
            :isPage="true"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.masterData.cartridge.cartridgeId')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.cartridgeId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('systemSetting.masterData.cartridge.cartridgeName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.cartridgeName')])"
              type="text"
              name="cartridgeName"
              v-model.trim="$v.form.cartridgeName.$model"
              :isValid="$v.form.cartridgeName.$dirty ? !$v.form.cartridgeName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.cartridgeName" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('systemSetting.masterData.cartridge.cartridgeDescription')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.cartridgeDescription')])"
              rows="4"
              :maxlength="200"
              name="cartridgeDescription"
              v-model.trim="$v.form.cartridgeDescription.$model"
              :isValid="$v.form.cartridgeDescription.$dirty ? !$v.form.cartridgeDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.cartridgeDescription" />
              </template>
            </CTextarea>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.makerName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.makerName')])"
              type="text"
              name="makerName"
              v-model.trim="$v.form.makerName.$model"
              :isValid="$v.form.makerName.$dirty ? !$v.form.makerName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.makerName" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.diameterValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.diameterValue')])"
              type="text"
              name="diameterValue"
              append="mm"
              v-model.trim="$v.form.diameterValue.$model"
              :isValid="$v.form.diameterValue.$dirty ? !$v.form.diameterValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.diameterValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.lengthValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.lengthValue')])"
              type="text"
              name="lengthValue"
              append="mm"
              v-model.trim="$v.form.lengthValue.$model"
              :isValid="$v.form.lengthValue.$dirty ? !$v.form.lengthValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.lengthValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.weightValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.weightValue')])"
              type="text"
              name="weightValue"
              append="g"
              v-model.trim="$v.form.weightValue.$model"
              :isValid="$v.form.weightValue.$dirty ? !$v.form.weightValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.weightValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.effectiveEnergyValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.effectiveEnergyValue')])"
              type="text"
              name="effectiveEnergyValue"
              append="kJ/kg"
              v-model.trim="$v.form.effectiveEnergyValue.$model"
              :isValid="$v.form.effectiveEnergyValue.$dirty ? !$v.form.effectiveEnergyValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.effectiveEnergyValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.rwsValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.rwsValue')])"
              type="text"
              name="rwsValue"
              v-model.trim="$v.form.rwsValue.$model"
              :isValid="$v.form.rwsValue.$dirty ? !$v.form.rwsValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.rwsValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.densityValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.densityValue')])"
              type="text"
              name="densityValue"
              append="g/cm3"
              v-model.trim="$v.form.densityValue.$model"
              :isValid="$v.form.densityValue.$dirty ? !$v.form.densityValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.densityValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.vodValue')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.vodValue')])"
              type="text"
              name="vodValue"
              append="m/s"
              v-model.trim="$v.form.vodValue.$model"
              :isValid="$v.form.vodValue.$dirty ? !$v.form.vodValue.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.vodValue" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.masterData.cartridge.version')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.masterData.cartridge.version')])"
              type="text"
              name="version"
              v-model.trim="$v.form.version.$model"
              :isValid="$v.form.version.$dirty ? !$v.form.version.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.version" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('systemSetting.masterData.cartridge.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, decimal, between, numeric } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'
const systemSetting = 'systemSetting'

export default {
  name: "masterProductCartridge",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/cartridges",
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    };
  },
  computed: {
    fields () {
      return [
        {key:'cartridgeName', label:this.$t('systemSetting.masterData.cartridge.cartridgeName')},
        {key:'cartridgeDescription', label:this.$t('systemSetting.masterData.cartridge.cartridgeDescription')},
        {key:'makerName', label:this.$t('systemSetting.masterData.cartridge.makerName')},
        {key:'diameterValue', label:this.$t('systemSetting.masterData.cartridge.diameterValue')},
        {key:'lengthValue', label:this.$t('systemSetting.masterData.cartridge.lengthValue')},
        {key:'weightValue', label:this.$t('systemSetting.masterData.cartridge.weightValue')},
        {key:'effectiveEnergyValue', label:this.$t('systemSetting.masterData.cartridge.effectiveEnergyValue')},
        {key:'rwsValue', label:this.$t('systemSetting.masterData.cartridge.rwsValue')},
        {key:'densityValue', label:this.$t('systemSetting.masterData.cartridge.densityValue')},
        {key:'vodValue', label:this.$t('systemSetting.masterData.cartridge.vodValue')},
        {key:'version', label:this.$t('systemSetting.masterData.cartridge.version')},
        {key:'useYn', label:this.$t('systemSetting.masterData.cartridge.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      cartridgeName: {
        required,
        byte: byte(64)
      },
      cartridgeDescription: {
        byte: byte(256)
      },
      makerName: {
        required,
        byte: byte(64)
      },
      diameterValue: {
        required,
        numeric,
        between: between(0, 9999)
      },
      lengthValue: {
        required,
        numeric,
        between: between(0, 9999)
      },
      weightValue: {
        required,
        numeric,
        between: between(0, 99999)
      },
      effectiveEnergyValue: {
        required,
        decimal,
        between: between(0, 99.99),
        decimalLimit: decimalLimit(2)
      },
      rwsValue: {
        required,
        numeric,
        between: between(0, 999)
      },
      densityValue: {
        required,
        decimal,
        between: between(0, 9.99),
        decimalLimit: decimalLimit(2)
      },
      vodValue: {
        required,
        numeric,
        between: between(0, 9999)
      },
      version: {
        byte: byte(16)
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        cartridgeName: '',
        cartridgeDescription: '',
        makerName: '',
        diameterValue: '',
        lengthValue: '',
        weightValue: '',
        effectiveEnergyValue: '',
        rwsValue: '',
        densityValue: '',
        vodValue: '',
        version: '',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.cartridgeId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          cartridgeId: this.form.cartridgeId,
          cartridgeName: this.form.cartridgeName
        },
        payload : {
          keyword: 'cartridgeName',
          keywordName: this.$t('systemSetting.masterData.cartridge.bulkName'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
