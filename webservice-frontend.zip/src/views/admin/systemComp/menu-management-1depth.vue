<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :tableSettingKey="$options.name"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="sticky-top right-top135 mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap __large line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.menuManagement.menu1Depth.menuId')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu1Depth.menuId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('systemSetting.menuManagement.menu1Depth.menuNm')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu1Depth.menuNm')])"
              type="text"
              name="menuNm"
              v-model.trim="$v.form.menuNm.$model"
              :isValid="$v.form.menuNm.$dirty ? !$v.form.menuNm.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.menuNm" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.menuManagement.menu1Depth.orderNo')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.menuManagement.menu1Depth.orderNo')])"
              type="text"
              name="orderNo"
              v-model.trim="$v.form.orderNo.$model"
              :isValid="$v.form.orderNo.$dirty ? !$v.form.orderNo.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.orderNo" />
              </template>
            </CInput>
            <div class="d-flex align-items-center  position-relative">
              <label for="useYn" class="mr-1">
                {{$t('systemSetting.menuManagement.menu1Depth.useYn')}}
              </label>
              <CSwitchYN :value.sync="$v.form.useYn.$model" />
            </div>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, numeric } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "menuManagement1depth",
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/menus/1",
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    fields () {
      return [
        {key:'menuIdCode', label:this.$t('systemSetting.menuManagement.menu1Depth.menuIdCode')},
        {
          key:'menuNm', label:this.$t('systemSetting.menuManagement.menu1Depth.menuNm'),
          dblclick: (key, item) => {
            // 메뉴2Depth 탭 이동
            this.$emit('is-result', {
              mainTab: 1,
              subTab: 1,
              item: item
            })
          }
        },
        {key:'orderNo', label:this.$t('systemSetting.menuManagement.menu1Depth.orderNo')},
        {key:'menuCount', label:this.$t('systemSetting.menuManagement.menu1Depth.menuCount')},
        {key:'useYn', label:this.$t('systemSetting.menuManagement.menu1Depth.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      menuNm: {
        required,
        byte: byte(64)
      },
      orderNo: {
        required,
        numeric
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        menuNm: '',
        orderNo: '',
        menuDepth: 0,
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.menuId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          menuId: this.form.menuId,
          menuNm: this.form.menuNm
        },
        payload : {
          keyword: 'menuNm',
          keywordName: this.$t('systemSetting.menuManagement.menu1Depth.menuNm'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
