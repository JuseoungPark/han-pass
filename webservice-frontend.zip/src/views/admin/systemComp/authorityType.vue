<template>
  <CRow class="mt-3">
    <CCol :lg="!visible.form ? 12 : 8">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="items" :fields="fields" :tableSettingKey="$options.name"
            @rowClick="rowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.form" lg="4" class="lg-mt">
      <CCard class="sticky-top right-top135 mb-0">
        <CForm @submit.prevent>
          <CCardBody class="site-form-wrap __large line-none form-group-wrap">
            <CInput
              :label="$t('systemSetting.authorityManagement.authorityType.authorityId')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.authorityId')])"
              type="text"
              name="dataId"
              :disabled="true"
              v-if="form.dataId"
              v-model.trim="form.dataId" />
            <CInput
              :label="$t('systemSetting.authorityManagement.authorityType.authorityIdCode')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.authorityIdCode')])"
              type="text"
              name="authorityIdCode"
              :disabled="form.dataId"
              v-model.trim="$v.form.authorityIdCode.$model"
              :isValid="$v.form.authorityIdCode.$dirty ? !$v.form.authorityIdCode.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.authorityIdCode" />
              </template>
            </CInput>
            <CInput
              :label="$t('systemSetting.authorityManagement.authorityType.authorityName')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.authorityName')])"
              type="text"
              name="authorityName"
              v-model.trim="$v.form.authorityName.$model"
              :isValid="$v.form.authorityName.$dirty ? !$v.form.authorityName.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.authorityName" />
              </template>
            </CInput>
            <div class="mb-3">
              <label for="authorityExpiredDate" class="d-block">{{$t('systemSetting.authorityManagement.authorityType.authorityExpiredDate')}}</label>
              <CDatePicker id="authorityExpiredDate" :validForm.sync="$v.form.authorityExpiredDate"
                format="YYYY-MM-DD HH:mm:ss"
                :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.authorityExpiredDate')])" />
            </div>
            <CInput
              :label="$t('systemSetting.authorityManagement.authorityType.orderNo')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.orderNo')])"
              type="text"
              name="orderNo"
              v-model.trim="$v.form.orderNo.$model"
              :isValid="$v.form.orderNo.$dirty ? !$v.form.orderNo.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.orderNo" />
              </template>
            </CInput>
            <CTextarea
              :label="$t('systemSetting.authorityManagement.authorityType.authorityDescription')"
              :placeholder="$t('message.inputMessage', [$t('systemSetting.authorityManagement.authorityType.authorityDescription')])"
              rows="4"
              :maxlength="200"
              name="authorityDescription"
              v-model.trim="$v.form.authorityDescription.$model"
              :isValid="$v.form.authorityDescription.$dirty ? !$v.form.authorityDescription.$error : null">
              <template slot="invalid-feedback">
                <ValidFeedback :param="$v.form.authorityDescription" />
              </template>
            </CTextarea>
          </CCardBody>
          <CCardFooter>
            <CButton type="submit"
              v-if="isSave"
              @click="saveData"
              :disabled="!isValid || isEditing"
              class="btn-custom-default hanwha outline">
              {{ saveTitle }}
            </CButton>
            <CButton type="reset"
              v-if="isReset"
              @click.prevent="resetData(null)"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.reset')}}
            </CButton>
            <CButton  type="delete"
              v-if="isDelete"
              @click="visible.dangerModal = true"
              :disabled="isEditing || !form.dataId"
              class="btn-custom-default outline">
              {{$t('commonLabel.delete')}}
            </CButton>
            <CButton type="close"
              @click="closeData"
              :disabled="isEditing"
              class="btn-custom-default outline">
              {{$t('commonLabel.close')}}
            </CButton>
          </CCardFooter>
        </CForm>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import ValidFeedback from '@/components/form/ValidFeedback'
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, numeric } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "codeManagementAuthority",
  components: {
    CThemaCover,
    DataTable,
    CDatePicker,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/authoritys",
      visible: {
        loading: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      codes: {},
      items: [],
      form: this.getEmptyForm()
    }
  },
 computed: {
   fields () {
     return [
      {key:'authorityIdCode', label:this.$t('systemSetting.authorityManagement.authorityType.authorityIdCode')},
      {
        key:'authorityName', label:this.$t('systemSetting.authorityManagement.authorityType.authorityName'),
        dblclick: (key, item) => {
          this.$emit('is-result', {
            mainTab: 2,
            subTab: 1,
            item: item
          })
        }
      },
      {key:'authorityExpiredDate', label:this.$t('systemSetting.authorityManagement.authorityType.authorityExpiredDate')},
      {key:'orderNo', label:this.$t('systemSetting.authorityManagement.authorityType.orderNo')},
      {key:'authorityDescription', label:this.$t('systemSetting.authorityManagement.authorityType.authorityDescription')}
     ]
   },
   saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      authorityIdCode: {
        required,
        byte: byte(16)
      },
      authorityName: {
        required,
        byte: byte(100)
      },
      authorityExpiredDate: {
        required
      },
      authorityDescription: {
        byte: byte(1000)
      },
      orderNo: {
        required,
        numeric
      }
    }
  },
  async mounted() {
    await this.getDataList()
  },
  methods: {
    rowClick(item, index) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        authorityIdCode: '',
        authorityName: '',
        authorityDescription: '',
        authorityExpiredDate: '',
        orderNo: ''
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      if ((deepCopy.authorityExpiredDate || '') !== '') {
          // TODO => 날짜 관련 추후 정리해서 컴포넌트로 뺴자..
          deepCopy.authorityExpiredDate = this.$moment(deepCopy.authorityExpiredDate).format('YYYY-MM-DD HH:mm:ss')
        }
      this.form.dataId = this.form.authorityId || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    closeData() {
      this.clearSelectedClass()
      this.visible.form = false
    },
    clearSelectedClass () {
      let clickableRows = this.items.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },
    async saveData() {
      let d = {
        moduleName: this.moduleName,
        params : {
          authorityId: this.form.authorityId,
          authorityIdCode: this.form.authorityIdCode
        },
        payload : {
          keyword: 'authorityIdCode',
          keywordName: this.$t('systemSetting.authorityManagement.authorityType.authorityIdCode'),
        }
      }
      this.saveDataAction(d)
    }
  }
}
</script>
