<template>
  <CRow class="mt-3">
    <CCol lg="12">
      <transition name="fade">
        <CCard class="table-card-wrap">
          <CCardHeader>
            <CAlert show color="dark" class="mb-0">
              <strong v-if="master.key === ''">{{ $t('message.selectMessage', [$t('systemSetting.codeManagement.codeGroup.groupCode')]) }}</strong>
              <strong v-else>
                {{`${master.name}(${master.key})`}}
              </strong>
            </CAlert>
          </CCardHeader>
          <CCollapse :show="visible.form" :duration="400">
            <CCardBody class="form-group-wrap">
              <CForm @submit.prevent>
                <CCardBody class="line-none">
                  <CRow>
                    <CCol lg="3" v-if="form.dataId">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.commonCode')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.commonCode')])"
                        type="text"
                        name="dataId"
                        :disabled="true"
                        v-model.trim="form.dataId" />
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.commonCodeName')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.commonCodeName')])"
                        type="text"
                        name="commonCodeName"
                        v-model.trim="$v.form.commonCodeName.$model"
                        :isValid="$v.form.commonCodeName.$dirty ? !$v.form.commonCodeName.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.commonCodeName" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.orderNo')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.orderNo')])"
                        type="text"
                        name="orderNo"
                        v-model.trim="$v.form.orderNo.$model"
                        :isValid="$v.form.orderNo.$dirty ? !$v.form.orderNo.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.orderNo" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <div class="d-flex justify-content-around">
                        <div class="d-block position-relative">
                          <label for="multilingualUseYn" class="d-block mb-3">
                            {{$t('systemSetting.codeManagement.commonCode.multilingualUseYn')}}
                          </label>
                          <CSwitchYN id="multilingualUseYn" :value.sync="$v.form.multilingualUseYn.$model" />
                        </div>
                        <div class="d-block position-relative">
                          <label for="useYn" class="d-block mb-3">
                            {{$t('systemSetting.codeManagement.commonCode.useYn')}}
                          </label>
                          <CSwitchYN :value.sync="$v.form.useYn.$model" />
                        </div>
                      </div>
                    </CCol>
                    <CCol lg="3" v-if="!form.dataId"></CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.extendAttribute1')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.extendAttribute1')])"
                        type="text"
                        name="extendAttribute1"
                        v-model.trim="$v.form.extendAttribute1.$model"
                        :isValid="$v.form.extendAttribute1.$dirty ? !$v.form.extendAttribute1.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.extendAttribute1" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.extendAttribute2')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.extendAttribute2')])"
                        type="text"
                        name="extendAttribute2"
                        v-model.trim="$v.form.extendAttribute2.$model"
                        :isValid="$v.form.extendAttribute2.$dirty ? !$v.form.extendAttribute2.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.extendAttribute2" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.extendAttribute3')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.extendAttribute3')])"
                        type="text"
                        name="extendAttribute3"
                        v-model.trim="$v.form.extendAttribute3.$model"
                        :isValid="$v.form.extendAttribute3.$dirty ? !$v.form.extendAttribute3.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.extendAttribute3" />
                        </template>
                      </CInput>
                    </CCol>
                    <CCol lg="3">
                      <CInput
                        :label="$t('systemSetting.codeManagement.commonCode.extendAttribute4')"
                        :placeholder="$t('message.inputMessage', [$t('systemSetting.codeManagement.commonCode.extendAttribute4')])"
                        type="text"
                        name="extendAttribute4"
                        v-model.trim="$v.form.extendAttribute4.$model"
                        :isValid="$v.form.extendAttribute4.$dirty ? !$v.form.extendAttribute4.$error : null">
                        <template slot="invalid-feedback">
                          <ValidFeedback :param="$v.form.extendAttribute4" />
                        </template>
                      </CInput>
                    </CCol>
                  </CRow>
                </CCardBody>
                <CCardFooter class="text-right">
                  <CButton type="submit"
                    v-if="isSave"
                    @click="saveData"
                    :disabled="!isValid || isEditing"
                    class="btn-custom-default hanwha outline">
                    {{ saveTitle }}
                  </CButton>
                  <CButton type="reset"
                    v-if="isReset"
                    @click.prevent="resetData(null)"
                    :disabled="isEditing"
                    class="btn-custom-default outline">
                    {{$t('commonLabel.reset')}}
                  </CButton>
                  <CButton  type="delete"
                    v-if="isDelete"
                    @click="visible.dangerModal = true"
                    :disabled="isEditing || !form.dataId"
                    class="btn-custom-default outline">
                    {{$t('commonLabel.delete')}}
                  </CButton>
                </CCardFooter>
              </CForm>
            </CCardBody>
          </CCollapse>
        </CCard>
      </transition>
    </CCol>
    <CCol :lg="!visible.subList ? 12 : 6">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="masterItems" :fields="masterFields" :tableSettingKey="`${$options.name}_1`"
            :isNoItemClick="false"
            @rowClick="masterRowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CCol v-show="visible.subList" lg="6" class="lg-mt">
      <CCard class="table-card-wrap mb-0">
        <CCardBody class="line-none">
          <DataTable :items="subItems" :fields="subFields" :tableSettingKey="`${$options.name}_2`"
            @rowClick="subRowClick" />
        </CCardBody>
      </CCard>
    </CCol>
    <CModal
      :show.sync="visible.dangerModal"
      :no-close-on-backdrop="true"
      :centered="true"
      title="Modal title 2"
      size="sm"
      color="danger"
      class="modal-custom">
      <div class="text">
        {{$t('message.deleteConfirmMessage')}}
      </div>
      <template #header>
        <!-- <h6 class="modal-title">{{$t('commonLabel.confirm')}}</h6> -->
        <CButtonClose @click="visible.dangerModal = false" class="text-white"/>
      </template>
      <template #footer>
        <CButton @click="deleteData" class="btn-custom-default outline hanwha rectangle"> {{$t('commonLabel.ok')}}</CButton>
        <CButton @click="visible.dangerModal = false" class="btn-custom-default outline rectangle"> {{$t('commonLabel.cancel')}}</CButton>
      </template>
    </CModal>
    <CThemaCover v-if="visible.loading || isEditing" />
  </CRow>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import CSwitchYN from '@/components/form/CSwitchYN'
import ValidFeedback from '@/components/form/ValidFeedback'
import utils from '@/assets/js/utils'
import { validationMixin } from "vuelidate"
import { required, numeric } from "vuelidate/lib/validators"
import { byte } from '@/assets/js/validatorCustome'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "codeManagement2depth",
  props: {
    param: {
      type: Object,
      default () {
        return null
      }
    }
  },
  components: {
    CThemaCover,
    DataTable,
    CSwitchYN,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "v1/admin/codes",
      visible: {
        loading: false,
        subList: false,
        form: false,
        dangerModal: false
      },
      disabled: {
        submit: false,
        delete: false
      },
      master: {
        key: '',
        name: ''
      },
      masterItems: [],
      subItems: [],
      form: this.getEmptyForm()
    }
  },
  computed: {
    masterFields () {
      return [
        {key:'groupCode', label:this.$t('systemSetting.codeManagement.codeGroup.groupCode')},
        {key:'groupCodeName', label:this.$t('systemSetting.codeManagement.codeGroup.groupCodeName')},
        {key:'useCount', label:this.$t('systemSetting.codeManagement.codeGroup.multilingualUseYn')},
        {key:'useYn', label:this.$t('systemSetting.codeManagement.codeGroup.useYn'), template: 'ynBadge'}
      ]
    },
    subFields () {
      return [
        {key:'commonCode', label:this.$t('systemSetting.codeManagement.commonCode.commonCode')},
        {key:'commonCodeName', label:this.$t('systemSetting.codeManagement.commonCode.commonCodeName')},
        {key:'extendAttribute1', label:this.$t('systemSetting.codeManagement.commonCode.extendAttribute1')},
        {key:'extendAttribute2', label:this.$t('systemSetting.codeManagement.commonCode.extendAttribute2')},
        {key:'extendAttribute3', label:this.$t('systemSetting.codeManagement.commonCode.extendAttribute3')},
        {key:'extendAttribute4', label:this.$t('systemSetting.codeManagement.commonCode.extendAttribute4')},
        {key:'orderNo', label:this.$t('systemSetting.codeManagement.commonCode.orderNo')},
        {key:'multilingualUseYn', label:this.$t('systemSetting.codeManagement.commonCode.multilingualUseYn'), template: 'ynBadge'},
        {key:'useYn', label:this.$t('systemSetting.codeManagement.commonCode.useYn'), template: 'ynBadge'}
      ]
    },
    saveTitle () {
      return (this.form.dataId) ? this.$t('commonLabel.update') : this.$t('commonLabel.submit')
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    permission () {
      return this.userSite.userPermissionList.split(',')
    },
    isSave () {
      let permissionType = 'createSystemSettingAdmin'
      if (this.form.dataId) {
        permissionType = 'updateSystemSettingAdmin'
      }

      return this.permission.includes(permissionType)
    },
    isReset () {
      return this.permission.includes('createSystemSettingAdmin')
    },
    isDelete () {
      return this.permission.includes('deleteSystemSettingAdmin')
    },
    isValid () {
      return !this.$v.form.$invalid
    },
    isEditing () {
      return (this.disabled.submit || this.disabled.delete)
    }
  },
  mixins: [validationMixin, apiMixin],
  validations: {
    form: {
      commonCodeName: {
        required,
        byte: byte(64)
      },
      extendAttribute1: {
        byte: byte(100)
      },
      extendAttribute2: {
        byte: byte(100)
      },
      extendAttribute3: {
        byte: byte(100)
      },
      extendAttribute4: {
        byte: byte(100)
      },
      orderNo: {
        required,
        numeric
      },
      multilingualUseYn: {
        required
      },
      useYn: {
        required
      }
    }
  },
  async mounted() {
    await this.viewMasterList()
    if (this.param) {
      this.masterRowClick(this.param)
    }
  },
  methods: {
    async viewMasterList() {
      this.masterItems = []
      this.subItems = []
      this._moduleName = this.moduleName
      this.params = { pagable: false }
      let res = await this.requestApiSync()
      this.masterItems = res.content
    },
    async viewSubList() {
      this.subItems = []
      this._moduleName = `${this.moduleName}/${this.master.key}/common-codes`
      let res = await this.requestApiSync()
      this.subItems = res.content
    },
    async masterRowClick(item) {
      this.visible.loading = true
      this.master = {
        key: item.groupCode,
        name: item.groupCodeName
      }
      await this.viewSubList()
      this.resetData()
      this.visible.form = true
      this.visible.subList = true
      this.visible.loading = false
    },
    subRowClick(item) {
      this.resetData(item)
      this.visible.form = true
    },
    getEmptyForm () {
      return {
        commonCodeName: '',
        extendAttribute1: '',
        extendAttribute2: '',
        extendAttribute3: '',
        extendAttribute4: '',
        orderNo: '',
        remark: '',
        multilingualUseYn: 'Y',
        useYn: 'Y'
      }
    },
    resetData(item) {
      let deepCopy = JSON.parse(JSON.stringify(item || this.getEmptyForm()))
      this.form = deepCopy
      this.form.dataId = this.form.commonCode || null
      this.form.groupCode = this.master.key || null
      if (!this.form.dataId) {
        this.clearSelectedClass()
      }
      this.$v.form.$reset()
    },
    clearSelectedClass () {
      let clickableRows = this.subItems.find(s => typeof s._classes !== 'undefined')
      if (clickableRows) {
        this.$delete(clickableRows, '_classes')
      }
    },  
    async saveData() {
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.submit = true
      let d = {
        moduleName : `${this.moduleName}/${this.master.key}/common-codes`,
        params: {
          commonCode: this.form.commonCode,
          commonCodeName: this.form.commonCodeName
        },
        payload: {
          keyword: 'commonCodeName',
          keywordName: this.$t('systemSetting.codeManagement.commonCode.commonCodeName'), 
        }        
      }
      let isDupl = await this.isDuplication(d)
      if (isDupl) {
        d.params = this.form
        await this.setData(d)
        await this.viewSubList()
        this.resetData()
      }
      this.disabled.submit = false
    },
    async deleteData() {
      // 3초 이내 클릭 이벤트 체크
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      this.disabled.delete = true
      let d = {
        moduleName : `${this.moduleName}/${this.master.key}/common-codes`,
        params: this.form
      }
      await this.setDataDel(d)
      await this.viewSubList()
      this.resetData()
      this.visible.dangerModal = false
      this.disabled.delete = false
    }
  }
}
</script>