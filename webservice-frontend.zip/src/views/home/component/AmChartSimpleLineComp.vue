<template>
    <div class="am-line-chart" ref="chartdiv" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'SimpleLineSeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
        chartColor: String,
        targetValue: Number,
        bulletColor: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartdiv, am4charts.XYChart)
                chart.paddingRight = 20

                chart.data = addData.data

            // Create axes
            let dateAxis = chart.xAxes.push(new am4charts.DateAxis())
                dateAxis.dataFields.date = "date"
                dateAxis.renderer.inside = true
                dateAxis.renderer.labels.template.fontSize = 0
                dateAxis.renderer.baseGrid.disabled = true
                dateAxis.renderer.grid.template.disabled = true

            // Create value axis
            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
                // valueAxis.min = 0
                // valueAxis.max = this.targetValue + 0.05
                valueAxis.renderer.minGridDistance = 10
                // valueAxis.renderer.grid.template.disabled = true
                valueAxis.renderer.inside = true
                valueAxis.renderer.labels.template.fill = am4core.color("#fff")
                valueAxis.renderer.labels.template.fontSize = 0
                // valueAxis.renderer.baseGrid.disabled = true

            // target line
            let range = valueAxis.axisRanges.create()
                range.value = this.targetValue
                range.grid.stroke = am4core.color("red")
                range.grid.strokeWidth = 1
                range.grid.strokeOpacity = 1
                range.label.inside = true
                range.label.text = "target" + this.targetValue + "mm/s"
                range.label.fill = range.grid.stroke
                //range.label.align = "right"
                range.label.verticalCenter = "bottom"

            // Create series
            let lineSeries = chart.series.push(new am4charts.LineSeries())
                lineSeries.dataFields.valueY = "value"
                lineSeries.dataFields.dateX = "date"
                lineSeries.strokeWidth = 1
                lineSeries.stroke = am4core.color(this.chartColor)
                lineSeries.cloneTooltip = false // Tooltip off
                lineSeries.showOnInit = false // animation off
                lineSeries.tooltip.background.fill = am4core.color("rgba(255, 255, 255, 0.8)")
                lineSeries.tooltip.getFillFromObject = false

            let bullet = lineSeries.bullets.push(new am4core.Circle())
                bullet.radius = 3
                // bullet.fill = am4core.color("#333")
                bullet.fill = am4core.color( lineSeries.stroke )
                bullet.stroke = lineSeries.stroke
                bullet.strokeOpacity = 0.7
                bullet.strokeWidth = 1.5
                bullet.fillOpacity = 1
                bullet.tooltipText = "[bold;#f89b6c]target : " + this.targetValue + " mm/s[/]\n[#000]{dateX} : [bold;#000]{valueY}[/]"

                // chart.cursor = new am4charts.XYCursor()
                // chart.cursor.behavior = "panX"

                // chart.legend = new am4charts.Legend()
                // chart.legend.useDefaultMarker = false
                // chart.legend.position = "top"
                // chart.legend.contentAlign = "right"
                // chart.legend.marginBottom = 20
                // chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

            // let markerTemplate = chart.legend.markers.template
            //     markerTemplate.width = 15
            //     markerTemplate.height = 10
            //     markerTemplate.stroke = am4core.color("#ccc")

            this.chart = chart

        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-line-chart{
    width:100%;
    /* height:300px; */
}
</style>