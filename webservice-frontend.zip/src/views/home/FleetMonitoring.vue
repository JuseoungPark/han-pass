<template>
    <CRow class="align-items-center">
        <CCol lg="12">
            <CCardBody class="line-none pt-0 pb-3">
                <div class="blast-title-box">
                    <strong class="title">
                        <span class="name d-block font-weight-normal">Unit</span>
                        <span class="value">{{ fleetInfo.unit }}
                            <CLink v-show="fleetInfo.isLocation" @click="setFleetLocation(fleetInfo)">
                                <app-icon name="locationLink" size="sm" fill class="location-link dark-white ml-1" />
                            </CLink>
                        </span>
                    </strong>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="py-3">
                <div class="blast-title-box">
                    <ul class="info-list list-unstyled mb-0">
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="location" size="s" fill class="mr-1" />
                                    <span class="list-tit">Pit</span>
                                </div>
                                <span class="list-value ml-3">{{ fleetInfo.pitName }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="truck" size="s" fill class="mr-1" />
                                    <span class="list-tit">Model</span>
                                </div>
                                <span class="list-value ml-3">{{ fleetInfo.model }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="people" size="s" fill class="mr-1" />
                                    <span class="list-tit">Operator</span>
                                </div>
                                <span class="list-value ml-3">{{ fleetInfo.operator }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="calendar" size="s" fill class="mr-1" />
                                    <span class="list-tit">Time for Blasting</span>
                                </div>
                                <span class="list-value ml-3">{{ fleetInfo.fleetTime }}</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <CCardGroup class="flex-box-layout mb-0 h120">
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">Total Hole</span>
                        </div>
                        <span v-if="fleetInfo.totalHole == null" class="num"> - </span>
                        <span v-else class="num">{{ fleetInfo.totalHole }}</span>
                    </div>
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">{{ fleetInfo.title1 }}</span>
                        </div>
                        <span v-if="fleetInfo.drilledHole == null" class="num"> - </span>
                        <span v-else class="num">{{ fleetInfo.operationHole }}</span>
                    </div>
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">{{ fleetInfo.title2 }}</span>
                            <small class="unit">{{ fleetInfo.title3 }}</small>
                        </div>
                        <span v-if="fleetInfo.meterToDrill == null" class="num"> - </span>
                        <span v-else class="num">{{ fleetInfo.resultValue }}</span>
                    </div>
                </CCardGroup>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <div class="progress-box h120">
                    <ul class="step-text-wrap align-items-center list-unstyled">
                        <li>
                            <strong class="d-block text-center title">{{ fleetInfo.statusName }}</strong>
                        </li>
                        <li>
                            <div class="value-wrap text-center">
                                <span class="num bGreen d-block mt-0"
                                    :class="{'overValue' : fleetInfo.operationValue > 100}">{{ fleetInfo.operationHole }}</span>
                                <span class="num-ex d-block">/ {{ fleetInfo.totalHole }}</span>
                            </div>
                        </li>
                        <li>
                            <!-- https://www.npmjs.com/package/vue-radial-progress -->
                            <radial-progress-bar
                                :diameter="isMobile ? 110 : 100"
                                :strokeWidth="isMobile ? 18 : 16"
                                :innerStrokeWidth="isMobile ? 18 : 16"
                                :strokeLinecap="lineCap"
                                :completed-steps="fleetInfo.operationValue"
                                :total-steps="totalSteps"
                                startColor="#02d15e"
                                stopColor="#02d15e"
                                :innerStrokeColor="fleetInfo.operationValue > 100 ? '#018d4a' : $store.state.uxui.darkMode ? '#666' : '#eee'"
                            >
                                <p class="value-text">{{ fleetInfo.operationValue }}%</p>
                            </radial-progress-bar>
                        </li>
                    </ul>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <div class="progressbar-wrap info">
                    <span class="title d-block mb-2">Time Remaining</span>
                    <div class="flex-center-layout align-items-center justify-content-start">
                        <CProgress class="progress-xs flex-1 mr-2" color="emerald" :value="fleetInfo.remainingValue"/>
                        <div class="text-wrap flex-1">
                            <span class="mr-1" style="font-size:17px">{{ fleetInfo.remaininTime }}</span>
                        </div>
                    </div>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="checkbox-wrap single-line py-3">
                <div class="custom-control custom-checkbox">
                    <input
                        id="showPath"
                        type="checkbox"
                        class="custom-control-input drapdown-checkbox"
                        @click="showPathClick($event.target.checked)"
                    >
                    <label
                        for="showPath"
                        class="custom-control-label custom-label-text"
                    >
                        Show path
                    </label>
                </div>
            </CCardBody>
        </CCol>
    </CRow>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import RadialProgressBar from 'vue-radial-progress'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

const blastLibrary = 'blastLibrary'

export default {
    name: 'FleetMonitoring',
    components: {
        AppIcon,
        RadialProgressBar,
    },
    props: {
        fleetInfo: Object,
        isMobile: Boolean
    },
    data() {
        return {
            totalSteps: 100,
            lineCap: "0",
        }
    },
    watch: {
        fleetInfo: {
            immediate: true,
            async handler(data) {
                if (data.equipmentTypeCode == 'CODE0042') {
                    data.title1 = 'Drilled Hole'
                    data.title2 = 'Meter to Drill'
                    data.title3 = '(m)'
                } else {
                    data.title1 = 'Charged Hole'
                    data.title2 = 'Chargeed Weight'
                    data.title3 = '(kg)'
                }
            }
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    created() {
        this.fleetInfo.init = true
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        setFleetLocation(fleetInfo) {
            this.$emit('setFleetLocation', fleetInfo)
        },
        async showPathClick(e) {
            let that = this
            let siteId = that.fleetInfo.siteId
            let equipmentId = that.fleetInfo.equipmentId
            let polyLinePath = []

            if (e) {
                // 입력값 설정
                let params = new Array()
                let moduleName = "v1/dashboard/"+siteId+"/"+equipmentId+"/fleetRoute"
//console.log(moduleName)
                let payload = { params: params, moduleName: moduleName }
                await that.setDataListAction(payload)

                if (that.status == '200' && that.data.content.length > 0) {
                    that.data.content.forEach(function (el) {
                        polyLinePath.push({ lat: Number(el.lat), lng: Number(el.lng) })
                    })
                }
            }
//console.log('showPathClick...'+e)
//console.log(polyLinePath)
            this.$emit('showPath', e, polyLinePath)
        }
    }
}
</script>