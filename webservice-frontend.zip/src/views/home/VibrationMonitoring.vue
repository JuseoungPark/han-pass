<template>
    <CRow class="align-items-center">
        <CCol lg="12">
            <CCardBody class="line-none pt-0 pb-3">
                <div class="blast-title-box">
                    <strong class="title">
                        <span class="name d-block font-weight-normal">Unit</span>
                        <span class="value">{{ vibrationInfo.unit }}
                            <CLink v-show="vibrationInfo.isLocation" @click="setVibrationLocation(vibrationInfo)">
                                <app-icon name="locationLink" size="sm" fill class="location-link dark-white ml-1" />
                            </CLink>
                        </span>
                    </strong>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="py-3">
                <div class="blast-title-box">
                    <ul class="info-list long-width list-unstyled mb-0">
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="location" size="s" fill class="mr-1" />
                                    <span class="list-tit">Pit</span>
                                </div>
                                <span class="list-value text-wrap-location ml-3">
                                    <span class="mr-1">{{ vibrationInfo.pitName }}</span>
                                    (
                                        <span>{{ vibrationInfo.position.lat }}</span>,
                                        <span>{{ vibrationInfo.position.lng }}</span>
                                    )
                                </span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="truck" size="s" fill class="mr-1" />
                                    <span class="list-tit">Model</span>
                                </div>
                                <span class="list-value ml-3">{{ vibrationInfo.model }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <!-- icon 변경 예정 -->
                                    <app-icon name="serial" size="s" fill class="mr-1" />
                                    <span class="list-tit">Serial Number</span>
                                </div>
                                <span class="list-value ml-3">{{ vibrationInfo.serialNumber }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <!-- icon 변경 예정 -->
                                    <app-icon name="monitoring" size="s" fill class="mr-1" />
                                    <span class="list-tit">Monitoring Point type</span>
                                </div>
                                <span class="list-value ml-3">{{ vibrationInfo.monitoringPointType }}</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <CCardGroup class="flex-box-layout mb-0 h120">
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">PPV</span>
                            <small class="unit">(mm/s)</small>
                        </div>
                        <span class="num">{{ vibrationInfo.ppv }}</span>
                    </div>
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">PVS</span>
                            <small class="unit">(mm/s)</small>
                        </div>
                        <span class="num">{{ vibrationInfo.pvsValue }}</span>
                    </div>
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">Airblast</span>
                            <small class="unit">(dB)</small>
                        </div>
                        <span class="num">{{ vibrationInfo.airblastValue }}</span>
                    </div>
                </CCardGroup>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <div class="progress-box h120 d-flex align-items-center justify-content-end">
                    <div class="chart-wrap">
                        <div class="text-tit-wrap">
                            <div class="tit-wrap">
                                <span class="tit">PPV</span>
                                <!-- <span class="d-block">Standard : <span>1</span>MM</span> -->
                            </div>
                            <span class="num">{{ vibrationInfo.ppv }}<span class="unit"> mm/s</span></span>
                        </div>
                        <AmChartSimpleLineComp
                            chartColor="rgb(243, 155, 98)"
                            :bulletColor=" $store.state.uxui.darkMode ? '#333' : '#333' "
                            chartHeight="120"
                            :targetValue=vibrationInfo.ppv
                            :chartData=vibrationInfo.ppvData
                        />
                    </div>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <ul class="flex-box-layout vertical text-box-wrap list-unstyled p-4 mb-0 bg-light-gary">
                    <li class="text-list">
                        <span class="title">Recent Blast</span>
                        <span class="value">{{ vibrationInfo.recentBlast }}</span>
                    </li>
                    <li class="text-list">
                        <span class="title">Blast time</span>
                        <span class="value">{{ vibrationInfo.blastTime }}</span>
                    </li>
                    <li class="text-list">
                        <span class="title">Distance</span>
                        <span class="value">{{ vibrationInfo.distanceValue }} m</span>
                    </li>
                </ul>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="checkbox-wrap single-line py-3">
                <div class="custom-control custom-checkbox">
                    <input
                        id="vibrationRange"
                        type="checkbox"
                        class="custom-control-input drapdown-checkbox"
                        @click="vibrationRangeClick($event.target.checked)"
                    >
                    <label
                        for="vibrationRange"
                        class="custom-control-label custom-label-text"
                    >
                        Vibration range
                    </label>
                </div>
            </CCardBody>
        </CCol>
    </CRow>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import AmChartSimpleLineComp from './component/AmChartSimpleLineComp'
export default {
    name: 'VibrationMonitoring',
    components: {
        AppIcon,
        AmChartSimpleLineComp,
    },
    props: {
        vibrationInfo: Object,
        isMobile: Boolean
    },
    data() {
        return {
            //
        }
    },
    methods: {
        setVibrationLocation(vibrationInfo) {
            this.$emit('setVibrationLocation', vibrationInfo)
        },
        vibrationRangeClick(e) {
            let vibrationRangePath = []

            this.$emit('vibrationRange', vibrationRangePath)
        }
    }
}
</script>