<template>
    <CRow class="align-items-center">
        <CCol lg="12">
            <CCardBody class="line-none pt-0 pb-3">
                <div class="blast-title-box">
                    <strong class="title">
                        <span class="name d-block font-weight-normal">Blast</span>
                        <span class="value">{{ blastInfo.blastName }}
                            <CLink v-show="blastInfo.isLocation" @click="setBlastLocation(blastInfo)">
                                <app-icon name="locationLink" size="sm" fill class="location-link dark-white ml-1" />
                            </CLink>
                        </span>
                    </strong>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="py-3">
                <div class="blast-title-box">
                    <ul class="info-list list-unstyled mb-0">
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="location" size="s" fill class="mr-1" />
                                    <span class="list-tit">Pit</span>
                                </div>
                                <span class="list-value ml-3">{{ blastInfo.pitName }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="people" size="s" fill class="mr-1" />
                                    <span class="list-tit">Shot Firer</span>
                                </div>
                                <span class="list-value ml-3">{{ blastInfo.shotfirer }}</span>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex align-items-center justify-content-start">
                                <div class="info-tit-wrap">
                                    <app-icon name="calendar" size="s" fill class="mr-1" />
                                    <span class="list-tit">Time for Blasting</span>
                                </div>
                                <span class="list-value ml-3">{{ blastInfo.blastTime }}</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <CCardGroup class="flex-box-layout mb-0 h120">
                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">Total Hole</span>
                        </div>
                        <span v-if="blastInfo.totalHole == null" class="num"> - </span>
                        <span v-else class="num">{{ blastInfo.totalHole }}</span>
                    </div>

                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">Blasts Volume</span>
                            <small class="unit">(BCM)</small>
                        </div>
                        <span v-if="blastInfo.volume == null" class="num"> - </span>
                        <span v-else class="num">{{ blastInfo.volume }}</span>
                    </div>

                    <div class="list">
                        <div class="title-wrap">
                            <span class="title">Drill meter</span>
                            <small class="unit">(m)</small>
                        </div>
                        <span v-if="blastInfo.meter == null" class="num"> - </span>
                        <span v-else class="num">{{ blastInfo.meter }}</span>
                    </div>
                </CCardGroup>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <div class="progress-box h120">
                    <ul class="step-text-wrap list-unstyled">
                        <li>
                            <strong class="d-block text-center title">Drill hole</strong>
                            <div class="value-wrap text-center">
                                <span class="num green d-block"
                                    :class="{'overValue' : blastInfo.drillingValue > 100}">{{ blastInfo.drillHole }}</span>
                                <span class="num-ex d-block">/ {{ blastInfo.totalHole }}</span>
                            </div>
                        </li>
                        <li>
                            <strong class="d-block text-center title">Charged hole</strong>
                            <div class="value-wrap text-center">
                                <span class="num info d-block"
                                    :class="{'overValue' : blastInfo.chargingValue > 100}">{{ blastInfo.chargedHole }}</span>
                                <span class="num-ex d-block">/ {{ blastInfo.totalHole }}</span>
                            </div>
                        </li>
                        <li>
                            <strong class="d-block text-center title">Fired hole</strong>
                            <div class="value-wrap text-center">
                                <span class="num d-block"
                                    :class="{ 'orange' : blastInfo.firingValue === 100 }">{{ blastInfo.firingValue === 0 ? 'Standby' : 'Done' }}</span>
                            </div>
                        </li>
                    </ul>
                    <ul class="step-list-wrap list-unstyled mb-0">
                        <li class="step-list">
                        <!-- <li class="step-list" :class="{ 'bg-green' : blastInfo.drillingValue >= 100, 'bg-blue' :  blastInfo.drillingValue > 0 && blastInfo.drillingValue <= 99}"> -->
                            <!-- Drilling [ drillingProgressValue ( 0 ~ 100 ) value ]-->
                            <!-- <span class="progress" :style="`width:` + blastInfo.drillingValue + `%`" ></span>
                            <span class="text">Drilling</span> -->
                            <!-- https://www.npmjs.com/package/vue-radial-progress -->
                            <radial-progress-bar
                                :diameter="isMobile ? 110 : 100"
                                :strokeWidth="isMobile ? 18 : 16"
                                :innerStrokeWidth="isMobile ? 18 : 16"
                                :strokeLinecap="lineCap"
                                :completed-steps="blastInfo.drillingValue"
                                :total-steps="totalSteps"
                                startColor="#a8fe5b"
                                stopColor="#a8fe5b"
                                :innerStrokeColor="blastInfo.drillingValue > 100 ? '#01ad1a' : $store.state.uxui.darkMode ? '#666' : '#eee'"
                            >
                                <p class="value-text">{{ blastInfo.drillingValue }}%</p>
                            </radial-progress-bar>
                        </li>
                        <li class="step-list">
                        <!-- <li class="step-list" :class="{ 'bg-green' : blastInfo.chargingValue >= 100, 'bg-blue' :  blastInfo.chargingValue > 0 && blastInfo.chargingValue <= 99 }"> -->
                            <!-- Charging [ chargingProgressValue ( 0 ~ 100 ) value ] -->
                            <!-- <span class="progress" :style="`width:` + blastInfo.chargingValue + `%`"></span>
                            <span class="text">Charging</span> -->
                            <radial-progress-bar
                                :diameter="isMobile ? 110 : 100"
                                :strokeWidth="isMobile ? 18 : 16"
                                :innerStrokeWidth="isMobile ? 18 : 16"
                                :strokeLinecap="lineCap"
                                :completed-steps="blastInfo.chargingValue"
                                :total-steps="totalSteps"
                                startColor="#7cedfa"
                                stopColor="#7cedfa"
                                :innerStrokeColor="blastInfo.chargingValue > 100 ? '#28a0fc' : $store.state.uxui.darkMode ? '#666' : '#eee'"
                            >
                                <p class="value-text">{{ blastInfo.chargingValue }}%</p>
                            </radial-progress-bar>
                        </li>
                        <li class="step-list">
                        <!-- <li class="step-list" :class="{ 'bg-green' : blastInfo.firingValue >= 100, 'bg-blue' :  blastInfo.firingValue > 0 && blastInfo.firingValue <= 99 }"> -->
                            <!-- Firing [ firingProgressValue ( 0 ~ 100 ) value ] -->
                            <!-- <span class="progress" :style="`width:` + blastInfo.firingValue + `%`"></span>
                            <span class="text">Firing</span> -->
                            <radial-progress-bar
                                :animateSpeed="animateSpeed"
                                :diameter="isMobile ? 110 : 100"
                                :strokeWidth="isMobile ? 18 : 16"
                                :innerStrokeWidth="isMobile ? 18 : 16"
                                :strokeLinecap="lineCap"
                                :completed-steps="blastInfo.firingValue"
                                :total-steps="totalSteps"
                                startColor="#f27824"
                                stopColor="#f27824"
                                :innerStrokeColor="blastInfo.firingValue > 100 ? '#c94612' : $store.state.uxui.darkMode ? '#666' : '#eee'"
                            >
                                <p class="value-text">{{ blastInfo.firingValue }}%</p>
                            </radial-progress-bar>
                        </li>
                    </ul>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="single-line">
                <div class="progressbar-wrap info">
                    <span class="title d-block mb-2">Time Remaining</span>
                    <div class="flex-center-layout align-items-center justify-content-start">
                        <CProgress class="progress-xs flex-1 mr-2" color="emerald" :value="blastInfo.remainPer"/>
                        <div class="text-wrap flex-1">
                            <span class="mr-1" style="font-size:17px">{{ blastInfo.remainTime }}</span>
                        </div>
                    </div>
                </div>
            </CCardBody>
        </CCol>
        <CCol lg="12">
            <CCardBody class="checkbox-wrap single-line py-3">
                <div class="custom-control custom-checkbox">
                    <input
                        id="blastClearance"
                        type="checkbox"
                        class="custom-control-input drapdown-checkbox"
                        @click="clearanceZoneClick($event.target.checked)"
                    >
                    <label
                        for="blastClearance"
                        class="custom-control-label custom-label-text"
                    >
                        Clearance zone
                    </label>
                </div>
            </CCardBody>
        </CCol>
    </CRow>
</template>

<script>
import RadialProgressBar from 'vue-radial-progress'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastList',
    components: {
        AppIcon,
        RadialProgressBar
    },
    props: {
        blastInfo: Object,
        isMobile: Boolean
    },
    data() {
        return {
            animateSpeed: 500,
            totalSteps: 100,
            lineCap: "0",
        }
    },
    methods: {
        setBlastLocation(blastInfo) {
            this.$emit('setBlastLocation', blastInfo)
        },
        clearanceZoneClick(e) {
            let circlePath = []
            // circlePath.push({
            //     position: { lat: 37.552855, lng: 128.968973 },
            //     radius: 250,
            //     draggable: false,
            //     options: {
            //         strokeColor: 'red', strokeOpacity: 0.1, strokeWeight: 1
            //         , fillColor: 'red', fillOpacity: 0.2
            //     }
            // })
            // circlePath.push({
            //     position: { lat: 37.552855, lng: 128.968973 },
            //     radius: 100,
            //     draggable: false,
            //     options: {
            //         strokeColor: 'red', strokeOpacity: 0.1, strokeWeight: 1
            //         , fillColor: 'red', fillOpacity: 0.2
            //     }
            // })

            if (!e) circlePath = []

            this.$emit('clearanceZone', circlePath)
        },
    }
}
</script>