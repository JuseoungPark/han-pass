<template>
  <CRow>
    <CCol lg="12">
      <CCardGroup>
        
        <CWidgetDropdown 
          color="gradient-primary" 
          header="100" 
          text="Blasts"
        >
          <template #footer>
            <CChartLineSimple
              pointed
              class="mt-3 mx-3"
              style="height:70px"
              :data-points="[65, 59, 84, 84, 51, 55, 40]"
              point-hover-background-color="primary"
              label="Blasts"
              labels="months"
            />
          </template>
          <CIcon name="cil-brightness" height="36" class="blasts-icon" />
        </CWidgetDropdown>

        <CWidgetDropdown 
          color="gradient-info" 
          header="100" 
          text="No.of Holes"
        >
          <template #footer>
            <CChartLineSimple
              pointed
              class="mt-3 mx-3"
              style="height:70px"
              :data-points="[1, 18, 9, 17, 34, 22, 11]"
              point-hover-background-color="info"
              :options="{ elements: { line: { tension: 0.00001 }}}"
              label="No.of Holes"
              labels="months"
            />
          </template>
          <CIcon name="cil-scrubber" height="36" class="blasts-icon"/>
        </CWidgetDropdown>

        <CWidgetDropdown
          color="gradient-warning"
          header="100"
          text="Blasts Volume (BCM)"
          >
          <template #footer>
            <CChartLineSimple
              class="mt-3"
              style="height:70px"
              background-color="rgba(255,255,255,.2)"
              :data-points="[78, 81, 80, 45, 34, 12, 40]"
              :options="{ elements: { line: { borderWidth: 2.5 }}}"
              point-hover-background-color="warning"
              label="Blasts Volume (BCM)"
              labels="months"
            />
          </template>
          <CIcon name="cil-list-filter" height="36" class="blasts-icon"/>
        </CWidgetDropdown>

        <CWidgetDropdown
          color="gradient-danger"
          header="100"
          text="Drill Meter (m)"
          >
          <template #footer>
            <CChartBarSimple
              class="mt-3 mx-3"
              style="height:70px"
              background-color="rgb(250, 152, 152)"
              label="Drill Meter (m)"
              labels="months"
            />
          </template>
          <CIcon name="cil-line-spacing" height="36" class="blasts-icon"/>
        </CWidgetDropdown>
      </CCardGroup>
    </CCol>
  </CRow>
</template>

<script>
import { CChartLineSimple, CChartBarSimple } from '../charts/index.js'

export default {
  name: 'WidgetsDropdown',
  components: { CChartLineSimple, CChartBarSimple }
}
</script>
