<template>
  <div class="alert-login login-wrap">
    <CContainer>
      <CRow class="justify-content-center">
        <CCol md="8" class="px-0">
          <CCardGroup>
            <CCard class="form-wrap">
              <CCardBody class="line-none">
                <CForm  @submit.prevent>
                  <h1>Login</h1>
                  <p class="muted">Sign In to your account</p>
                  <CInput
                    placeholder="User Email"
                    v-model.trim="userEmail"
                    autocomplete="username email"
                  >
                    <template #prepend-content>
                      <app-icon name="loginUser" size="m" fill />
                    </template>
                  </CInput>
                  <CInput
                    placeholder="Password"
                    type="password"
                    v-model.trim="userPassword"
                    autocomplete="curent-password"
                    class="mb-1"
                  >
                    <template #prepend-content>
                      <app-icon name="pass" size="m" fill />
                    </template>
                  </CInput>
                  <span class="welcom">
                          Token is expired, Please Login again.
                          <!-- 토근이 만료되었습니다. 로그인이 필요합니다. -->
                  </span>
                  <CRow class="mt-2">

                    <CCol col="5" class="text-left pr-0">
                      <!-- <CButton color="link" class="px-0">Forgot password?</CButton> -->
                    </CCol>

                    <CCol col="7" class="btn-wrap text-right">
                      <CButton
                        class="btn-custom-default hanwha outline rectangle"
                        type='submit'
                        @click="onSubmit(userEmail, userPassword)"
                        >
                        Login
                      </CButton>

                      <button class="btn-custom-default outline rectangle" @click="$emit('popClose')" ><i class="fa fa-close"></i> Close</button>


                      <!-- <CButton color="link" class="d-lg-none" @click="goPageRegister">Register now!</CButton> -->
                    </CCol>
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
              <!-- color="primary" -->
            <CCard
              text-color="white"
              class="logo-wrap text-center d-md-down-none"

            >
              <CCardBody class="line-none">
                <!-- <h2>Sign up</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
                <CImg
                  :src="`img/${ $store.state.uxui.darkMode ? 'login-logo-b' : 'login-logo-w'}.png`"
                  block
                  class="login-logo"
                  />
                <!-- <CButton
                  color="light"
                  class="btn-register"
                  size="lg"
                  variant="outline"
                  @click="goPageRegister"
                >
                  Register
                </CButton> -->
              </CCardBody>
            </CCard>
          </CCardGroup>
        </CCol>
      </CRow>
    </CContainer>

  </div>
</template>


<script>

import axios from 'axios'
import env from '@/assets/js/config'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
// import utils from '@/assets/js/utils'

// import store from '@/store'
// const loginLogout = 'loginLogout'

export default {
  name: 'alertLoginCheck',
  components: {
    AppIcon
  },
  data() {
        return {
          userEmail:'',
          userPassword:'',
          email: '',
          password: '',
          msg: '',
          greeting: ''
        }
      },
      methods: {
        onSubmit(email, password) {
          //this.redirect();
          this.initToken()
          const TAG = '[Login,onSumit]'

          console.log(TAG, 'Login:', email, password);

          //LOGIN 액션 실행
          this.$store.dispatch('loginLogout/LOGIN', {email, password})
            .then(() => this.redirect())
            .catch(function(error){
                console.log(TAG, 'Login:', error);
                //utils.showToastRed('로그인 ID와 패스워드를 확인하세요',error);
            });
          //this.$emit('onSubmit')
        },
        redirect() {
          this.$emit('onSubmit')
        },
        getSelectedSchemeCheck() {
          return env.geSelectedScheme()
        },
        initToken() {
          axios.defaults.headers.common['Authorization'] = undefined
          // delete localStorage.accessToken
          // delete localStorage.isAuthenticated
          // delete localStorage.userName
          // delete localStorage.userLangType
          // delete localStorage.userCompany
          // delete localStorage.userSite
          // delete localStorage.expiration
          // delete localStorage.codeList
          // delete localStorage.selectedUserSite

          // delete localStorage.userCellphoneNo
          // delete localStorage.userId
          // delete localStorage.userThemaType


          // delete localStorage.userPermissionList
          // delete localStorage.userMenuList

          delete localStorage.dbs
        }
      },
      created() {
      }
}
</script>
