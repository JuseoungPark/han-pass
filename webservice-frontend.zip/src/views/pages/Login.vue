<template>
  <div class="c-app flex-row align-items-center login-wrap dark">
    <CContainer>
      <CRow class="justify-content-center">
        <CCol md="8">
          <CCardGroup>
            <CCard class="form-wrap">
              <CCardBody class="line-none">
                <CForm  @submit.prevent>
                  <h1>Login</h1>
                  <p class="muted">Sign In to your account</p>
                  <CInput
                    placeholder="User Email"
                    v-model.trim="$v.form.email.$model"
                    :isValid="$v.form.email.$dirty ? !$v.form.email.$error : null"
                    autocomplete="username email"
                  >
                    <template slot="invalid-feedback">
                      <ValidFeedback :param="$v.form.email" />
                    </template>
                    <template #prepend-content>
                      <app-icon name="loginUser" size="m" fill />
                    </template>
                  </CInput>
                  <CInput
                    placeholder="Password"
                    type="password"
                    v-model.trim="$v.form.password.$model"
                    :isValid="$v.form.password.$dirty ? !$v.form.password.$error : null"
                    autocomplete="curent-password"
                  >
                    <template slot="invalid-feedback">
                      <ValidFeedback :param="$v.form.password" />
                    </template>
                    <template #prepend-content>
                      <app-icon name="pass" size="m" fill />
                    </template>
                  </CInput>
                  <CRow>
                    <CCol col="5" class="text-left pr-0">
                      <!-- <CButton color="link" class="px-0">Forgot password?</CButton> -->
                      <!-- <CButton color="link" class="d-lg-none" @click="goPageRegister">Register now!</CButton> -->
                    </CCol>
                    <CCol col="7" class="btn-wrap text-right">
                      <!-- <CButton color="primary" class="px-4">Login</CButton> -->
                      <CButton
                        class="btn-custom-default hanwha outline rectangle"
                        type='submit'
                        @click="onSubmit()"
                        :disabled="!isValid"
                        >
                        Login
                        </CButton>
                    </CCol>
                  </CRow>
                </CForm>
              </CCardBody>
            </CCard>
              <!-- color="primary" -->
            <CCard
              text-color="white"
              class="logo-wrap text-center d-md-down-none"
            >
              <CCardBody class="line-none">
                <!-- <h2>Sign up</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
                <CImg
                  src="img/login-logo-b.png"
                  block
                  class="login-logo"
                  />
                <!-- <CButton
                  color="light"
                  class="btn-register"
                  size="lg"
                  variant="outline"
                  @click="goPageRegister"
                >
                  Register
                </CButton> -->
              </CCardBody>
            </CCard>
          </CCardGroup>
        </CCol>
      </CRow>
    </CContainer>
  </div>
</template>

<script>
import axios from 'axios'
import env from '@/assets/js/config'
import utils from '@/assets/js/utils'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
import { validationMixin } from "vuelidate"
import { required, email } from "vuelidate/lib/validators"
import ValidFeedback from '@/components/form/ValidFeedback'
// import store from '@/store'
// const loginLogout = 'loginLogout'

export default {
  name: 'Login',
  components: {
    AppIcon,
    ValidFeedback
  },
  mixins: [validationMixin],
  data() {
    return {
      form: {
        email:'',
        password:'',
      },
      email: '',
      password: '',
      msg: '',
      greeting: ''
    }
  },
  validations: {
    form: {
      email: {
        required,
        email
      },
      password:{
        required
      }
    }
  },
  computed: {
    isValid () {
      return !this.$v.form.$invalid
    }
  },
  methods: {
    onSubmit() {
      //LOGIN 액션 실행
      this.$store.dispatch('loginLogout/LOGIN', this.form)
        .then(() => this.redirect())
        .catch(function(error){
          console.log('Login:', error);
        });
    },
    redirect() {
      if(utils.getUserInformation()){
        let pathInfo = '/sitedashboard'
        let siteId = utils.getUserInformation().selectedUserSite.siteId
        if (siteId === undefined) pathInfo = '/homedashboard'
        else if (siteId == 0) pathInfo = '/admin/systemsetting'
        this.$router.push({ path: pathInfo })
      }
    },
    getSelectedSchemeCheck() {
      return env.geSelectedScheme()
    }
    },
    created() {
      axios.defaults.headers.common['Authorization'] = undefined
        // delete localStorage.accessToken
        // delete localStorage.isAuthenticated
        // delete localStorage.userName
        // delete localStorage.userLangType
        // delete localStorage.userCompany
        // delete localStorage.userSite
        // delete localStorage.expiration
        // delete localStorage.codeList
        // delete localStorage.selectedUserSite

        // delete localStorage.userCellphoneNo
        // delete localStorage.userId
        // delete localStorage.userThemaType

        // delete localStorage.userPermissionList
        // delete localStorage.userMenuList

      delete localStorage.dbs
    }
}
</script>
<style scoped>
.invalid-feedback {
  padding-left:40px;
}
</style>