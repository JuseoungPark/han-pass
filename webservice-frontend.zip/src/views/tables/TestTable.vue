<template>
    <CRow>
        <CCol sm="12">
            <CCard>
            <CTableWrapper
                :items="getShuffledUsersData()"
                :fields = thFields
                striped
                bordered
                small
                fixed
                dark
                @child="testClick"
                caption="test Table"
                />
            </CCard>
            <CCard>
                <SelectTable/>
            </CCard>
        </CCol>
    </CRow>
</template>

<script>
import CTableWrapper from './Table.vue'
import SelectTable from './SelectTable'
import usersData from '../users/UsersData'

export default {
    name: 'testTable',
    components: { 
        CTableWrapper,
        SelectTable,
    },
    data(){
        return{
            thFields : ['username', 'registered', 'role', 'status'],
            sorterValue: { column: null, asc: true },
            loading: false,

        }
    },
    methods: {
    shuffleArray (array) {
      for (let i = array.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1))
        let temp = array[i]
        array[i] = array[j]
        array[j] = temp
      }
      return array
    },

    getShuffledUsersData () {
      return this.shuffleArray(usersData.slice(0))
	},
	
	testClick() {
		// table row event
		alert('click test')
	}
  }   
}
</script>