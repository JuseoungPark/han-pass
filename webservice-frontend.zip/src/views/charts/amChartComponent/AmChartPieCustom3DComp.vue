<template>
    <div class="am-pie-chart" ref="chartPie"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'PieChart',
    data() {
        return {
            // chart: '',
        }
    },
    // props: {
    //     chartData: Object,
    // },
    // watch: {
    //     chartData: {
    //         handler: 'loadChart',
    //         deep: true
    //     }
    // },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData()
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartPie, am4charts.PieChart3D)
                chart.hiddenState.properties.opacity = 0 // this creates initial fade-in
                chart.data = [
                    {
                        "country": "Lithuania",
                        "litres": 501.9
                    }, {
                        "country": "Czechia",
                        "litres": 301.9
                    }, {
                        "country": "Ireland",
                        "litres": 201.1
                    }, {
                        "country": "Germany",
                        "litres": 165.8
                    }, {
                        "country": "Australia",
                        "litres": 139.9
                    }, {
                        "country": "Austria",
                        "litres": 128.3
                    }, {
                        "country": "UK",
                        "litres": 99
                    }, {
                        "country": "Belgium",
                        "litres": 60
                    }, {
                        "country": "The Netherlands",
                        "litres": 50
                    }
                ]

            chart.innerRadius = am4core.percent(40)
            chart.depth = 120

            chart.legend = new am4charts.Legend()
            chart.legend.position = "right"

            let pieSeries = chart.series.push(new am4charts.PieSeries3D())
                pieSeries.dataFields.value = "litres"
                pieSeries.dataFields.depthValue = "litres"
                pieSeries.dataFields.category = "country"
                pieSeries.slice.template.cornerRadius = 6 //?????
                pieSeries.colors.step = 3
            
            pieSeries.hiddenState.properties.endAngle = -90;
            // Add a legend
            chart.legend = new am4charts.Legend()

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-pie-chart{
    width:100%;
    height:250px;
}
</style>