<template>
    <div class="am-xy-chart" ref="chartxy"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'xySeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
            // console.log('======================', this.chartData.data.slice(0))
            // chart.data = data;
            chart.data = this.chartData.data

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())

            // Create series
            let series = chart.series.push(new am4charts.ColumnSeries())
                series.dataFields.valueY = "value"
                series.dataFields.categoryX = "category"
                series.columns.template.tooltipText = "{categoryX} : {valueY}"
            // Create value axis range
            // let range = categoryAxis.axisRanges.create()
            //     range.category = "B"
            //     range.endCategory = "D"
            //     range.axisFill.fill = am4core.color("#396478")
            //     range.axisFill.fillOpacity = 0.3
            //     range.label.disabled = true
            //     range.locations.category = 0.2
            //     range.locations.endCategory = 0.8

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>