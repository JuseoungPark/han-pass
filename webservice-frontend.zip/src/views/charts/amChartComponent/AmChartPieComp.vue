<template>
    <div class="am-pie-chart" ref="chartPie" :style="'height:'+ chartHeight + 'px'"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'PieChart',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData()
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartPie, am4charts.PieChart)

            chart.data = this.chartData.data;

            // Add and configure Series
            let pieSeries = chart.series.push(new am4charts.PieSeries())
            pieSeries.dataFields.value = "litres"
            pieSeries.dataFields.category = "country"

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-pie-chart{
    width:100%;
    /* height:250px; */
}
</style>