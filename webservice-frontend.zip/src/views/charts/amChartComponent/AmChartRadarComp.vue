<template>
    <div class="am-xy-radar" ref="chartRadar"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"
// import am4themes_kelly from "@amcharts/amcharts4/themes/kelly"

// am4core.useTheme(am4themes_animated)
// am4core.useTheme(am4themes_kelly)

export default {
    name: 'xySeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartRadar, am4charts.RadarChart)
            // console.log('======================', this.chartData.data.slice(0))
            // chart.data = data;
            chart.data = this.chartData.data

            /* Create axes */
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
                categoryAxis.dataFields.category = "country";

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

            /* Create and configure series */
            let series = chart.series.push(new am4charts.RadarSeries());
                series.dataFields.valueY = "litres";
                series.dataFields.categoryX = "country";
                series.name = "Sales";
                series.strokeWidth = 3;
                series.zIndex = 2;

            let series2 = chart.series.push(new am4charts.RadarColumnSeries());
                series2.dataFields.valueY = "units";
                series2.dataFields.categoryX = "country";
                series2.name = "Units";
                series2.strokeWidth = 0;
                series2.columns.template.fill = am4core.color("#CDA2AB");
                series2.columns.template.tooltipText = "Series: {name}\nCategory: {categoryX}\nValue: {valueY}";

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-xy-radar{
    width:100%;
    height:250px;
}
</style>