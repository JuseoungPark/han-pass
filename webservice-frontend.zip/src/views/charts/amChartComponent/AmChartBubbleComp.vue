<template>
    <div class="am-bubble-chart" ref="chartBubble"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
// am4core.options.queue = true
export default {
    name: 'StackedChart',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartBubble, am4charts.XYChart)
            chart.hiddenState.properties.opacity = 0 // this makes initial fade in effect

            // chart.data = data;
            chart.data = this.chartData.data

            let valueAxisX = chart.xAxes.push(new am4charts.ValueAxis());
                valueAxisX.renderer.ticks.template.disabled = true;
                valueAxisX.renderer.axisFills.template.disabled = true;

            let valueAxisY = chart.yAxes.push(new am4charts.ValueAxis());
                valueAxisY.renderer.ticks.template.disabled = true;
                valueAxisY.renderer.axisFills.template.disabled = true;

            let series = chart.series.push(new am4charts.LineSeries());
                series.dataFields.valueX = "x";
                series.dataFields.valueY = "y";
                series.dataFields.value = "value";
                series.strokeOpacity = 0;
                series.sequencedInterpolation = true;
                series.tooltip.pointerOrientation = "vertical";

            let bullet = series.bullets.push(new am4core.Circle());
                bullet.fill = am4core.color("#ff0000");
                bullet.propertyFields.fill = "color";
                bullet.strokeOpacity = 0;
                bullet.strokeWidth = 2;
                bullet.fillOpacity = 0.5;
                bullet.stroke = am4core.color("#ffffff");
                bullet.hiddenState.properties.opacity = 0;
                bullet.tooltipText = "[bold]{title}:[/]\nPopulation: {value.value}\nIncome: {valueX.value}\nLife expectancy:{valueY.value}";

            let outline = chart.plotContainer.createChild(am4core.Circle);
                outline.fillOpacity = 0;
                outline.strokeOpacity = 0.8;
                outline.stroke = am4core.color("#ff0000");
                outline.strokeWidth = 2;
                outline.hide(0);

            let blurFilter = new am4core.BlurFilter();
                

            bullet.events.on("over", function(event) {
                let target = event.target;
                outline.radius = target.pixelRadius + 2;
                outline.x = target.pixelX;
                outline.y = target.pixelY;
                outline.show();
            })

            bullet.events.on("out", function(event) {
                outline.hide();
            })

            let hoverState = bullet.states.create("hover");
                hoverState.properties.fillOpacity = 1;
                hoverState.properties.strokeOpacity = 1;

            series.heatRules.push({ target: bullet, min: 2, max: 60, property: "radius" });

            bullet.adapter.add("tooltipY", function (tooltipY, target) {
                return -target.radius;
            })

            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "zoomXY";
            chart.cursor.snapToSeries = series;

            // chart.scrollbarX = new am4core.Scrollbar();
            // chart.scrollbarY = new am4core.Scrollbar();
            

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-bubble-chart{
    width:100%;
    height:250px;
}
</style>