<template>
    <div class="am-xy-chart" ref="chartxy"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'xySeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
            // console.log('======================', this.chartData.data.slice(0))
            // chart.data = data;
            chart.data = this.chartData.data

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())

            // Create series
            let series1 = chart.series.push(new am4charts.ColumnSeries())
                series1.dataFields.valueY = "value"
                series1.dataFields.categoryX = "category"
                series1.columns.template.width = am4core.percent(50)
                series1.clustered = false
                series1.columns.template.dx = -20
                //series1.columns.template.align = "left"
                series1.name = "Series #1"
                series1.columns.template.tooltipText = "{valueY}"

            let series2 = chart.series.push(new am4charts.ColumnSeries())
                series2.dataFields.valueY = "value2"
                series2.dataFields.categoryX = "category"
                series2.columns.template.width = am4core.percent(50)
                series2.clustered = false
                series2.name = "Series #1"
                series2.columns.template.tooltipText = "{valueY}"

            let series3 = chart.series.push(new am4charts.ColumnSeries())
                series3.dataFields.valueY = "value3"
                series3.dataFields.categoryX = "category"
                series3.clustered = false
                series3.name = "Series #3"
                series3.columns.template.width = am4core.percent(50)
                series3.columns.template.dx = 20
                series3.columns.template.align = "left"
                series3.columns.template.tooltipText = "{valueY}"

            let label = series3.columns.template.createChild(am4core.Label)
                label.text = "{valueY}"
                label.valign = "center"
                label.strokeWidth = 0
                label.valign = "middle"
                label.align = "center"
                label.fill = am4core.color("#fff")

            chart.legend = new am4charts.Legend()
            chart.legend.useDefaultMarker = true

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>