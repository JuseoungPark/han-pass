<template>
    <div class="am-line-chart" ref="chartdiv"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'LineSeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
        series1Name: String,
        series2Name: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartdiv, am4charts.XYChart)
                chart.paddingRight = 20


                chart.data = this.chartData.data;

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30

            // Create value axis
            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())

            // Create series
            let lineSeries1 = chart.series.push(new am4charts.LineSeries())
                lineSeries1.dataFields.valueY = "value1"
                lineSeries1.dataFields.categoryX = "category"
                lineSeries1.name = this.series1Name
                lineSeries1.tooltipText = "{categoryX} : {valueY}"
                lineSeries1.strokeWidth = 1
            
            let lineSeries2 = chart.series.push(new am4charts.LineSeries())
                lineSeries2.dataFields.valueY = "value2"
                lineSeries2.dataFields.categoryX = "category"
                lineSeries2.name = this.series2Name
                lineSeries2.tooltipText = "{categoryX} : {valueY}"
                lineSeries2.strokeWidth = 1


                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = true
                chart.legend.position = "top"
            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 20
                markerTemplate.height = 2
                markerTemplate.stroke = am4core.color("#ccc")
            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-line-chart{
    width:100%;
    height:300px;
}
</style>