<template>
    <div class="am-xy-chart" ref="chartxy"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'xySeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
            // console.log('======================', this.chartData.data.slice(0))
            // chart.data = data;
            chart.data = this.chartData.data

            chart.colors.step = 2
            chart.padding = (0,0,0,0)

            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis()) 
                valueAxis.min = 0
                valueAxis.renderer.minWidth = 35
                valueAxis.tooltip.disabled = true

            let series1 = chart.series.push(new am4charts.ColumnSeries())
                series1.name = "Series 1"
                series1.dataFields.categoryX = "category"
                series1.dataFields.valueY = "value1"
                series1.stacked = true
                series1.tooltipText = "{valueY}"

            let series2 = chart.series.push(new am4charts.ColumnSeries())
                series2.name = "Series 2"
                series2.dataFields.categoryX = "category"
                series2.dataFields.valueY = "value2"
                series2.stacked = true
                series2.tooltipText = "{valueY}"

            let series3 = chart.series.push(new am4charts.ColumnSeries())
                series3.name = "Series 3"
                series3.dataFields.categoryX = "category"
                series3.dataFields.valueY = "value3"
                series3.stacked = true
                series3.tooltipText = "{valueY}"

            let series4 = chart.series.push(new am4charts.ColumnSeries())
                series4.name = "Series 4"
                series4.dataFields.categoryX = "category"
                series4.dataFields.valueY = "value4"
                series4.stacked = true
                series4.tooltipText = "{valueY}"

            /* Create a cursor */
            chart.cursor = new am4charts.XYCursor()
            chart.cursor.xAxis = categoryAxis
            chart.cursor.fullWidthLineX = true
            chart.cursor.lineX.strokeWidth = 0
            chart.cursor.lineX.fill = am4core.color("#000")
            chart.cursor.lineX.fillOpacity = 0.1
            chart.cursor.behavior = "selectX"
            chart.cursor.lineY.disabled = true

            chart.legend = new am4charts.Legend()

            chart.cursor.events.on("cursorpositionchanged", function(ev) {
                chart.cursor.triggerMove(ev.target.point, "soft")
            })

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>