<template>
    <div class="am-scatter-chart" ref="chartdiv"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'LineSeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
        series1Name: String,
        series2Name: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartdiv, am4charts.XYChart)

                chart.data = this.chartData.data

            // Create axes
            let valueAxisX = chart.xAxes.push(new am4charts.ValueAxis())
                valueAxisX.title.text = 'Scaled distance (kg/m)'
                valueAxisX.renderer.minGridDistance = 40

            // Create value axis
            let valueAxisY = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxisY.title.text = 'Peak particle  velocity (cm/s)'

            // Create series
            let lineSeries = chart.series.push(new am4charts.LineSeries())
                lineSeries.dataFields.valueY = "ay"
                lineSeries.dataFields.valueX = "ax"
                lineSeries.strokeOpacity = 0

            let lineSeries2 = chart.series.push(new am4charts.LineSeries())
                lineSeries2.dataFields.valueY = "by"
                lineSeries2.dataFields.valueX = "bx"
                lineSeries2.strokeOpacity = 0


            // Add a bullet
            let bullet = lineSeries.bullets.push(new am4charts.Bullet())

            // Add a triangle to act as am arrow
            let arrow = bullet.createChild(am4core.Triangle)
                arrow.horizontalCenter = "middle"
                arrow.verticalCenter = "middle"
                arrow.tooltipText = "{valueX} : [bold]{valueY}[/]"
                arrow.strokeWidth = 0
                arrow.fill = chart.colors.getIndex(0)
                arrow.direction = "top"
                arrow.width = 12
                arrow.height = 12

            // Add a bullet
            let bullet2 = lineSeries2.bullets.push(new am4charts.Bullet())

            // Add a triangle to act as am arrow
            let arrow2 = bullet2.createChild(am4core.Triangle)
                arrow2.horizontalCenter = "middle"
                arrow2.verticalCenter = "middle"
                arrow2.tooltipText = "{valueX} : [bold]{valueY}[/]"
                arrow2.rotation = 180
                arrow2.strokeWidth = 0
                arrow2.fill = chart.colors.getIndex(3)
                arrow2.direction = "top"
                arrow2.width = 12
                arrow2.height = 12

            //add the trendlines
            let trend = chart.series.push(new am4charts.LineSeries())
                trend.dataFields.valueY = "value2"
                trend.dataFields.valueX = "value"
                trend.strokeWidth = 2
                trend.stroke = chart.colors.getIndex(0)
                trend.strokeOpacity = 0.7
                trend.data = [
                    { "value": 1, "value2": 2 },
                    { "value": 12, "value2": 11 }
                ]

            let trend2 = chart.series.push(new am4charts.LineSeries())
                trend2.dataFields.valueY = "value2"
                trend2.dataFields.valueX = "value"
                trend2.strokeWidth = 2
                trend2.stroke = chart.colors.getIndex(3)
                trend2.strokeOpacity = 0.7
                trend2.data = [
                    { "value": 1, "value2": 1 },
                    { "value": 12, "value2": 19 }
                ]




                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = false
                chart.legend.position = "top"
                chart.legend.contentAlign = "right"
                chart.legend.marginBottom = 20
                chart.legend.fontSize = 11
                chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-scatter-chart{
    width:100%;
    height:300px;
}
</style>