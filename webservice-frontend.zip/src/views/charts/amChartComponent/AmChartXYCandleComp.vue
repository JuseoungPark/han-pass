<template>
    <div class="am-xy-chart" ref="chartxy"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'xySeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
            chart.paddingRight = 20;

            // chart.data = data;
            chart.data = this.chartData.data

            chart.dateFormatter.inputDateFormat = "yyyy-MM-dd"

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis())
            dateAxis.renderer.grid.template.location = 0
            dateAxis.renderer.minGridDistance = 60

            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
            valueAxis.tooltip.disabled = true

            var series = chart.series.push(new am4charts.CandlestickSeries())
            series.dataFields.dateX = "date"
            series.dataFields.valueY = "close"
            series.dataFields.openValueY = "open"
            series.dataFields.lowValueY = "low"
            series.dataFields.highValueY = "high"
            series.tooltipText = "Open: [bold]${openValueY.value}[/]\nLow: [bold]${lowValueY.value}[/]\nHigh: [bold]${highValueY.value}[/]\nClose: [bold]${valueY.value}[/]"

            chart.cursor = new am4charts.XYCursor()

            chart.scrollbarX = new am4core.Scrollbar()

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>