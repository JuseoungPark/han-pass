<template>
    <CRow>

        <CCol lg="12">
            <CCard>
                <CCardHeader>
                    <strong>LineSeries</strong>
                </CCardHeader>
                <CCardBody>

                    <AmChartLineComp
                        :chartData= lineChartData
                    />

                </CCardBody>
            </CCard>
            <CCard>
                <CCardHeader>
                    <strong>Multi LineSeries</strong>
                </CCardHeader>
                <CCardBody>

                    <AmChartMultitLineComp
                        series1Name="series 1"
                        series2Name="series 2"
                        :chartData= multiLineChartData 
                    />

                </CCardBody>
            </CCard>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Pie Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartPieComp
                            :chartData= pieChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Pie Chart Custom</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartPieCustomComp />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Pie Chart Custom (error)</strong>
                        </CCardHeader>
                        <CCardBody>

                            <!-- option error -->
                            <!-- <AmChartPieCustom3DComp /> -->

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Gauge Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartGaugeComp
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartXYComp
                                :chartData= xyChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Stick Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartCategoryComp
                                :chartData= categoryChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Stick + Line Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartCategoryLineComp
                                :chartData= categoryChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY double Chart</strong>
                        </CCardHeader>
                        <CCardBody>
                            <AmChartCategoryDoubleComp
                                :chartData= categoryDoubleChartData 
                            />
                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Horizontal Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartXYHorizontalComp
                                :chartData= xyHorizontalChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Overlaid Chart</strong>
                        </CCardHeader>
                        <CCardBody>
                            <AmChartXYOverlaidComp 
                                :chartData= overlaidChartData
                            />
                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>XY Candlestick Chart</strong>
                        </CCardHeader>
                        <CCardBody>
                            <AmChartXYCandleComp 
                                :chartData= candleChartData
                            />
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Radar Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartRadarComp
                                :chartData= radarChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Radar Dot Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartRadarDotComp 
                                :chartData= radarChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Stacked Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartStackedComp
                                :chartData= StackedChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>bubble Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartBubbleComp 
                                :chartData= bubbleChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>CandlePlot Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartXYCandlePlotComp
                                :chartData= CandlePlotChartData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Scatter Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartScatterComp 
                                :chartData= scattertData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Line Legend Custom Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartLineLegendCustomComp
                                :chartData= LineLegendCustomData 
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Line custom Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartLinecustomCompA
                                chartHeight="300"
                                dateAxisTitle="Time (sec)"
                                valueAxisYTitle="Tran Velocity (mm/s)"
                                lineColor="red"
                                :chartData= lineChartData2
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                

            </CRow>
        </CCol>
        <CCol lg="12">
            <CRow>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>simple line Custom Chart</strong>
                        </CCardHeader>
                        <CCardBody>
                            <div style="background:#eee">
                            <AmChartSimpleLineComp
                                targetValue="1.0"
                                chartColor="orange"
                                :chartData= SimpleLineCustomData 
                            />
                            </div>
                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol>
                    <CCard>
                        <CCardHeader>
                            <strong>Line custom Chart</strong>
                        </CCardHeader>
                        <CCardBody>

                            <AmChartLinecustomCompB
                                chartHeight="300"
                                valueAxisXTitle="Time (sec)"
                                valueAxisYTitle="Tran Velocity (mm/s)"
                                lineColor="red"
                                :chartData= lineChartData3
                            />

                        </CCardBody>
                    </CCard>
                </CCol>
                

            </CRow>
        </CCol>
    </CRow>
</template>
<script>
import AmChartLineComp from './amChartComponent/AmChartLineComp'
import AmChartMultitLineComp from './amChartComponent/AmChartMultitLineComp'
import AmChartPieComp from './amChartComponent/AmChartPieComp'
import AmChartPieCustomComp from './amChartComponent/AmChartPieCustomComp'
import AmChartPieCustom3DComp from './amChartComponent/AmChartPieCustom3DComp'
import AmChartGaugeComp from './amChartComponent/AmChartGaugeComp'
import AmChartXYComp from './amChartComponent/AmChartXYComp'
import AmChartXYOverlaidComp from './amChartComponent/AmChartXYOverlaidComp'
import AmChartXYHorizontalComp from './amChartComponent/AmChartXYHorizontalComp'
import AmChartCategoryComp from './amChartComponent/AmChartCategoryComp'
import AmChartCategoryDoubleComp from './amChartComponent/AmChartCategoryDoubleComp'
import AmChartCategoryLineComp from './amChartComponent/AmChartCategoryLineComp'
import AmChartRadarComp from './amChartComponent/AmChartRadarComp'
import AmChartRadarDotComp from './amChartComponent/AmChartRadarDotComp'

import AmChartXYCandleComp from './amChartComponent/AmChartXYCandleComp'
import AmChartXYCandlePlotComp from './amChartComponent/AmChartXYCandlePlotComp'
import AmChartStackedComp from './amChartComponent/AmChartStackedComp'
import AmChartBubbleComp from './amChartComponent/AmChartBubbleComp'
import AmChartScatterComp from './amChartComponent/AmChartScatterComp'
import AmChartLineLegendCustomComp from './amChartComponent/AmChartLineLegendCustomComp'

import AmChartLinecustomCompA from './amChartComponent/AmChartLinecustomCompA'
import AmChartLinecustomCompB from './amChartComponent/AmChartLinecustomCompB'
import AmChartSimpleLineComp from './amChartComponent/AmChartSimpleLineComp'

export default {
    name: 'AmChartsAll',
    components: {
        AmChartLineComp,
        AmChartMultitLineComp,
        AmChartPieComp,
        AmChartPieCustomComp,
        AmChartPieCustom3DComp,
        AmChartGaugeComp,
        AmChartXYComp,
        AmChartXYOverlaidComp,
        AmChartXYHorizontalComp,
        AmChartCategoryComp,
        AmChartCategoryDoubleComp,
        AmChartCategoryLineComp,
        AmChartRadarComp,
        AmChartRadarDotComp,
        AmChartXYCandleComp,
        AmChartXYCandlePlotComp,
        AmChartStackedComp,
        AmChartBubbleComp,
        AmChartScatterComp,
        AmChartLineLegendCustomComp,

        AmChartLinecustomCompA,
        AmChartLinecustomCompB,
        AmChartSimpleLineComp
    },
    data() {
        return{
            lineChartData: {
                data: []
            },
            lineChartData2: {
                data: []
            },
            lineChartData3: {
                data: []
            },
            multiLineChartData: {
                data: [{
                "category": "A",
                "value1": 90,
                "value2": 90,
                }, {
                "category": "B",
                "value1": 102,
                "value2": 122,
                }, {
                "category": "C",
                "value1": 65,
                "value2": 165,
                }, {
                "category": "D",
                "value1": 62,
                "value2": 162,
                }, {
                "category": "E",
                "value1": 55,
                "value2": 155,
                }, {
                "category": "F",
                "value1": 81,
                "value2": 181,
                }]
            },
            LineLegendCustomData: {
                data: [{
                    "y": 10,
                    "x": 14,
                    "value": 2,
                    "y2": 5,
                    "x2": 3,
                    "value2": 2,
                    "y3": 2,
                    "x3": 7,
                    "value3": 2,
                }, {
                    "y": 5,
                    "x": 3,
                    "value": 2,
                    "y2": 15,
                    "x2": 8,
                    "value2": 2,
                    "y3": 5,
                    "x3": 5,
                    "value3": 2,
                }, {
                    "y": 10,
                    "x": 8,
                    "value": 2,
                    "y2": 4,
                    "x2": 6,
                    "value2": 2,
                    "y3": 4,
                    "x3": 8,
                    "value3": 2,
                }, {
                    "y": 6,
                    "x": 5,
                    "value": 2,
                    "y2": 5,
                    "x2": 6,
                    "value2": 2,
                    "y3": 5,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 15,
                    "x": 4,
                    "value": 2,
                    "y2": 10,
                    "x2": 8,
                    "value2": 2,
                    "y3": 6,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 13,
                    "x": 6,
                    "value": 2,
                    "y2": 2,
                    "x2": 10,
                    "value2": 2,
                    "y3": 2,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 1,
                    "x": 6,
                    "value": 2,
                    "y2": 0,
                    "x2": 3,
                    "value2": 2,
                    "y3": 10,
                    "x3": 5,
                    "value3": 2,
                }]
            },
            pieChartData: {
                data:[{
                        "country": "Lithuania",
                        "litres": 501.9
                    }, {
                        "country": "Czechia",
                        "litres": 301.9
                    }, {
                        "country": "Ireland",
                        "litres": 201.1
                    }, {
                        "country": "Germany",
                        "litres": 165.8
                    }, {
                        "country": "Australia",
                        "litres": 139.9
                    }, {
                        "country": "Austria",
                        "litres": 128.3
                    }, {
                        "country": "UK",
                        "litres": 99
                    }, {
                        "country": "Belgium",
                        "litres": 60
                    }, {
                        "country": "The Netherlands",
                        "litres": 50
                    }
                ]
            },
            scattertData: {
                data:[{
                    "ax": 1,
                    "ay": 0.5,
                    "bx": 1,
                    "by": 2.2
                }, {
                    "ax": 2,
                    "ay": 1.3,
                    "bx": 2,
                    "by": 4.9
                }, {
                    "ax": 3,
                    "ay": 2.3,
                    "bx": 3,
                    "by": 5.1
                }, {
                    "ax": 4,
                    "ay": 2.8,
                    "bx": 4,
                    "by": 5.3
                }, {
                    "ax": 5,
                    "ay": 3.5,
                    "bx": 5,
                    "by": 6.1
                }, {
                    "ax": 6,
                    "ay": 5.1,
                    "bx": 6,
                    "by": 8.3
                }, {
                    "ax": 7,
                    "ay": 6.7,
                    "bx": 7,
                    "by": 10.5
                }, {
                    "ax": 8,
                    "ay": 8,
                    "bx": 8,
                    "by": 12.3
                }, {
                    "ax": 9,
                    "ay": 8.9,
                    "bx": 9,
                    "by": 14.5
                }, {
                    "ax": 10,
                    "ay": 9.7,
                    "bx": 10,
                    "by": 15
                }, {
                    "ax": 11,
                    "ay": 10.4,
                    "bx": 11,
                    "by": 18.8
                }, {
                    "ax": 12,
                    "ay": 11.7,
                    "bx": 12,
                    "by": 19
                }
                ]
            },
            xyChartData: {
                data:[{
                    "category": "One",
                    "value1": 1,
                    "value2": 5,
                    "value3": 3,
                    "value4": 3
                    }, {
                    "category": "Two",
                    "value1": 2,
                    "value2": 5,
                    "value3": 3,
                    "value4": 4
                    }, {
                    "category": "Three",
                    "value1": 3,
                    "value2": 5,
                    "value3": 4,
                    "value4": 4
                    }, {
                    "category": "Four",
                    "value1": 4,
                    "value2": 5,
                    "value3": 6,
                    "value4": 4
                    }, {
                    "category": "Five",
                    "value1": 3,
                    "value2": 5,
                    "value3": 4,
                    "value4": 4
                    }, {
                    "category": "Six",
                    "value1": 8,
                    "value2": 7,
                    "value3": 10,
                    "value4": 4
                    }, {
                    "category": "Seven",
                    "value1": 10,
                    "value2": 8,
                    "value3": 6,
                    "value4": 4
                }]
            },
            overlaidChartData: {
                data:[{
                    "category": "Research",
                    "value": 450,
                    "value2": 800,
                    "value3": 650
                    }, {
                    "category": "Marketing",
                    "value": 1200,
                    "value2": 900,
                    "value3": 1350
                    }, {
                    "category": "Distribution",
                    "value": 300,
                    "value2": 700,
                    "value3": 600
                }]
            },
            bubbleChartData: {
                data:[{
                    "title": "Afghanistan",
                    "id": "AF",
                    "color": "#eea638",
                    "continent": "asia",
                    "x": 1349.69694102398,
                    "y": 60.524,
                    "value": 33397058
                },
                {
                    "title": "Albania",
                    "id": "AL",
                    "color": "#d8854f",
                    "continent": "europe",
                    "x": 6969.30628256456,
                    "y": 77.185,
                    "value": 3227373
                },
                {
                    "title": "Algeria",
                    "id": "DZ",
                    "color": "#de4c4f",
                    "continent": "africa",
                    "x": 6419.12782939372,
                    "y": 70.874,
                    "value": 36485828
                },
                {
                    "title": "Angola",
                    "id": "AO",
                    "color": "#de4c4f",
                    "continent": "africa",
                    "x": 5838.15537582502,
                    "y": 51.498,
                    "value": 20162517
                },
                {
                    "title": "Argentina",
                    "id": "AR",
                    "color": "#86a965",
                    "continent": "south_america",
                    "x": 15714.1031814398,
                    "y": 76.128,
                    "value": 41118986
                },
                {
                    "title": "Armenia",
                    "id": "AM",
                    "color": "#d8854f",
                    "continent": "europe",
                    "x": 5059.0879636443,
                    "y": 74.469,
                    "value": 3108972
                },
                {
                    "title": "Australia",
                    "id": "AU",
                    "color": "#8aabb0",
                    "continent": "australia",
                    "x": 36064.7372768548,
                    "y": 82.364,
                    "value": 22918688
                },
                {
                    "title": "Austria",
                    "id": "AT",
                    "color": "#d8854f",
                    "continent": "europe",
                    "x": 36731.6287741081,
                    "y": 80.965,
                    "value": 8428915
                },
                {
                    "title": "Azerbaijan",
                    "id": "AZ",
                    "color": "#d8854f",
                    "continent": "europe",
                    "x": 9291.02626998762,
                    "y": 70.686,
                    "value": 9421233
                },
                {
                    "title": "Bahrain",
                    "id": "BH",
                    "color": "#eea638",
                    "continent": "asia",
                    "x": 24472.896235865,
                    "y": 76.474,
                    "value": 1359485
                },
                {
                    "title": "Bangladesh",
                    "id": "BD",
                    "color": "#eea638",
                    "continent": "asia",
                    "x": 1792.55023464123,
                    "y": 70.258,
                    "value": 152408774
                }]
            },
            xyHorizontalChartData: {
                data:[{
                    "category": "Research",
                    "value": 450
                    }, {
                    "category": "Marketing",
                    "value": 1200
                    }, {
                    "category": "Distribution",
                    "value": 1850
                }]
            },
            SimpleLineCustomData: {
                data:[{
                    "date": new Date(2020,10-1,23).getTime(),
                    "value": 0.1
                    }, {
                    "date": new Date(2020,10-1,24).getTime(),
                    "value": 0.5
                    }, {
                    "date": new Date(2020,10-1,25).getTime(),
                    "value": 0.3
                    }, {
                    "date": new Date(2020,10-1,26).getTime(),
                    "value": 1.2
                    }, {
                    "date": new Date(2020,10-1,27).getTime(),
                    "value": 0.8
                    }, {
                    "date": new Date(2020,10-1,28).getTime(),
                    "value": 1.8
                }]
            },
            categoryChartData: {
                data:[{
                    "category": "A",
                    "value": 500
                    }, {
                    "category": "B",
                    "value": 1200
                    }, {
                    "category": "C",
                    "value": 500
                    }, {
                    "category": "D",
                    "value": 1500
                    }, {
                    "category": "E",
                    "value": 1200
                    }, {
                    "category": "F",
                    "value": 800
                }]
            },
            categoryDoubleChartData: {
                data:[{
                    "category": "A",
                    "value": 500,
                    "value2": 1500,
                    }, {
                    "category": "B",
                    "value": 1200,
                    "value2": 700,
                    }, {
                    "category": "C",
                    "value": 500,
                    "value2": 1500,
                    }, {
                    "category": "D",
                    "value": 1500,
                    "value2": 500,
                    }, {
                    "category": "E",
                    "value": 1200,
                    "value2": 700,
                    }, {
                    "category": "F",
                    "value": 800,
                    "value2": 1800,
                }]
            },
            StackedChartData: {
                data:[{
                    "name": "The first",
                    "value": 354
                }, {
                    "name": "The second",
                    "value": 245
                }, {
                    "name": "The third",
                    "value": 187
                }, {
                    "name": "The fourth",
                    "value": 123
                }, {
                    "name": "The fifth",
                    "value": 87
                }, {
                    "name": "The sixth",
                    "value": 45
                }, {
                    "name": "The seventh",
                    "value": 23
                }]
            },
            radarChartData: {
                data:[{
                    "country": "Lithuania",
                    "litres": 501,
                    "units": 250
                    }, {
                    "country": "Czech Republic",
                    "litres": 301,
                    "units": 222
                    }, {
                    "country": "Ireland",
                    "litres": 266,
                    "units": 179
                    }, {
                    "country": "Germany",
                    "litres": 165,
                    "units": 298
                    }, {
                    "country": "Australia",
                    "litres": 139,
                    "units": 299
                    }, {
                    "country": "Austria",
                    "litres": 336,
                    "units": 185
                    }, {
                    "country": "UK",
                    "litres": 290,
                    "units": 150
                    }, {
                    "country": "Belgium",
                    "litres": 325,
                    "units": 382
                    }, {
                    "country": "The Netherlands",
                    "litres": 40,
                    "units": 172
                }]
            },
            candleChartData: {
                data:[ {
                    "date": "2018-08-01",
                    "open": "136.65",
                    "high": "136.96",
                    "low": "134.15",
                    "close": "136.49"
                    }, {
                    "date": "2018-08-02",
                    "open": "135.26",
                    "high": "135.95",
                    "low": "131.50",
                    "close": "131.85"
                    }, {
                    "date": "2018-08-05",
                    "open": "132.90",
                    "high": "135.27",
                    "low": "128.30",
                    "close": "135.25"
                    }, {
                    "date": "2018-08-06",
                    "open": "134.94",
                    "high": "137.24",
                    "low": "132.63",
                    "close": "135.03"
                    }, {
                    "date": "2018-08-07",
                    "open": "136.76",
                    "high": "136.86",
                    "low": "132.00",
                    "close": "134.01"
                    }, {
                    "date": "2018-08-08",
                    "open": "131.11",
                    "high": "133.00",
                    "low": "125.09",
                    "close": "126.39"
                    }, {
                    "date": "2018-08-09",
                    "open": "123.12",
                    "high": "127.75",
                    "low": "120.30",
                    "close": "125.00"
                    }, {
                    "date": "2018-08-12",
                    "open": "128.32",
                    "high": "129.35",
                    "low": "126.50",
                    "close": "127.79"
                    }, {
                    "date": "2018-08-13",
                    "open": "128.29",
                    "high": "128.30",
                    "low": "123.71",
                    "close": "124.03"
                    }, {
                    "date": "2018-08-14",
                    "open": "122.74",
                    "high": "124.86",
                    "low": "119.65",
                    "close": "119.90"
                    }, {
                    "date": "2018-08-15",
                    "open": "117.01",
                    "high": "118.50",
                    "low": "111.62",
                    "close": "117.05"
                    }, {
                    "date": "2018-08-16",
                    "open": "122.01",
                    "high": "123.50",
                    "low": "119.82",
                    "close": "122.06"
                    }, {
                    "date": "2018-08-19",
                    "open": "123.96",
                    "high": "124.50",
                    "low": "120.50",
                    "close": "122.22"
                    }, {
                    "date": "2018-08-20",
                    "open": "122.21",
                    "high": "128.96",
                    "low": "121.00",
                    "close": "127.57"
                    }, {
                    "date": "2018-08-21",
                    "open": "131.22",
                    "high": "132.75",
                    "low": "130.33",
                    "close": "132.51"
                    }, {
                    "date": "2018-08-22",
                    "open": "133.09",
                    "high": "133.34",
                    "low": "129.76",
                    "close": "131.07"
                    }, {
                    "date": "2018-08-23",
                    "open": "130.53",
                    "high": "135.37",
                    "low": "129.81",
                    "close": "135.30"
                    }, {
                    "date": "2018-08-26",
                    "open": "133.39",
                    "high": "134.66",
                    "low": "132.10",
                    "close": "132.25"
                    }, {
                    "date": "2018-08-27",
                    "open": "130.99",
                    "high": "132.41",
                    "low": "126.63",
                    "close": "126.82"
                    }, {
                    "date": "2018-08-28",
                    "open": "129.88",
                    "high": "134.18",
                    "low": "129.54",
                    "close": "134.08"
                    }, {
                    "date": "2018-08-29",
                    "open": "132.67",
                    "high": "138.25",
                    "low": "132.30",
                    "close": "136.25"
                    }, {
                    "date": "2018-08-30",
                    "open": "139.49",
                    "high": "139.65",
                    "low": "137.41",
                    "close": "138.48"
                    }, {
                    "date": "2018-09-03",
                    "open": "139.94",
                    "high": "145.73",
                    "low": "139.84",
                    "close": "144.16"
                    }, {
                    "date": "2018-09-04",
                    "open": "144.97",
                    "high": "145.84",
                    "low": "136.10",
                    "close": "136.76"
                    }, {
                    "date": "2018-09-05",
                    "open": "135.56",
                    "high": "137.57",
                    "low": "132.71",
                    "close": "135.01"
                    }, {
                    "date": "2018-09-06",
                    "open": "132.01",
                    "high": "132.30",
                    "low": "130.00",
                    "close": "131.77"
                    }, {
                    "date": "2018-09-09",
                    "open": "136.99",
                    "high": "138.04",
                    "low": "133.95",
                    "close": "136.71"
                    }, {
                    "date": "2018-09-10",
                    "open": "137.90",
                    "high": "138.30",
                    "low": "133.75",
                    "close": "135.49"
                    }, {
                    "date": "2018-09-11",
                    "open": "135.99",
                    "high": "139.40",
                    "low": "135.75",
                    "close": "136.85"
                    }, {
                    "date": "2018-09-12",
                    "open": "138.83",
                    "high": "139.00",
                    "low": "136.65",
                    "close": "137.20"
                    }, {
                    "date": "2018-09-13",
                    "open": "136.57",
                    "high": "138.98",
                    "low": "136.20",
                    "close": "138.81"
                    }, {
                    "date": "2018-09-16",
                    "open": "138.99",
                    "high": "140.59",
                    "low": "137.60",
                    "close": "138.41"
                }]
            },
            CandlePlotChartData: {
                data:[ {
                    "date": "2018-08-01",
                    "open": "136.65",
                    "high": "136.96",
                    "low": "134.15",
                    "close": "136.49"
                    }, {
                    "date": "2018-08-02",
                    "open": "135.26",
                    "high": "135.95",
                    "low": "131.50",
                    "close": "131.85"
                    }, {
                    "date": "2018-08-05",
                    "open": "132.90",
                    "high": "135.27",
                    "low": "128.30",
                    "close": "135.25"
                    }, {
                    "date": "2018-08-06",
                    "open": "134.94",
                    "high": "137.24",
                    "low": "132.63",
                    "close": "135.03"
                    }, {
                    "date": "2018-08-07",
                    "open": "136.76",
                    "high": "136.86",
                    "low": "132.00",
                    "close": "134.01"
                    }, {
                    "date": "2018-08-08",
                    "open": "131.11",
                    "high": "133.00",
                    "low": "125.09",
                    "close": "126.39"
                    }, {
                    "date": "2018-08-09",
                    "open": "123.12",
                    "high": "127.75",
                    "low": "120.30",
                    "close": "125.00"
                    }, {
                    "date": "2018-08-12",
                    "open": "128.32",
                    "high": "129.35",
                    "low": "126.50",
                    "close": "127.79"
                    }, {
                    "date": "2018-08-13",
                    "open": "128.29",
                    "high": "128.30",
                    "low": "123.71",
                    "close": "124.03"
                    }, {
                    "date": "2018-08-14",
                    "open": "122.74",
                    "high": "124.86",
                    "low": "119.65",
                    "close": "119.90"
                    }, {
                    "date": "2018-08-15",
                    "open": "117.01",
                    "high": "118.50",
                    "low": "111.62",
                    "close": "117.05"
                    }, {
                    "date": "2018-08-16",
                    "open": "122.01",
                    "high": "123.50",
                    "low": "119.82",
                    "close": "122.06"
                    }, {
                    "date": "2018-08-19",
                    "open": "123.96",
                    "high": "124.50",
                    "low": "120.50",
                    "close": "122.22"
                    }, {
                    "date": "2018-08-20",
                    "open": "122.21",
                    "high": "128.96",
                    "low": "121.00",
                    "close": "127.57"
                    }, {
                    "date": "2018-08-21",
                    "open": "131.22",
                    "high": "132.75",
                    "low": "130.33",
                    "close": "132.51"
                    }, {
                    "date": "2018-08-22",
                    "open": "133.09",
                    "high": "133.34",
                    "low": "129.76",
                    "close": "131.07"
                    }, {
                    "date": "2018-08-23",
                    "open": "130.53",
                    "high": "135.37",
                    "low": "129.81",
                    "close": "135.30"
                    }, {
                    "date": "2018-08-26",
                    "open": "133.39",
                    "high": "134.66",
                    "low": "132.10",
                    "close": "132.25"
                    }, {
                    "date": "2018-08-27",
                    "open": "130.99",
                    "high": "132.41",
                    "low": "126.63",
                    "close": "126.82"
                    }, {
                    "date": "2018-08-28",
                    "open": "129.88",
                    "high": "134.18",
                    "low": "129.54",
                    "close": "134.08"
                    }, {
                    "date": "2018-08-29",
                    "open": "132.67",
                    "high": "138.25",
                    "low": "132.30",
                    "close": "136.25"
                    }, {
                    "date": "2018-08-30",
                    "open": "139.49",
                    "high": "139.65",
                    "low": "137.41",
                    "close": "138.48"
                    }, {
                    "date": "2018-09-03",
                    "open": "139.94",
                    "high": "145.73",
                    "low": "139.84",
                    "close": "144.16"
                    }, {
                    "date": "2018-09-04",
                    "open": "144.97",
                    "high": "145.84",
                    "low": "136.10",
                    "close": "136.76"
                    }, {
                    "date": "2018-09-05",
                    "open": "135.56",
                    "high": "137.57",
                    "low": "132.71",
                    "close": "135.01"
                    }, {
                    "date": "2018-09-06",
                    "open": "132.01",
                    "high": "132.30",
                    "low": "130.00",
                    "close": "131.77"
                    }, {
                    "date": "2018-09-09",
                    "open": "136.99",
                    "high": "138.04",
                    "low": "133.95",
                    "close": "136.71"
                    }, {
                    "date": "2018-09-10",
                    "open": "137.90",
                    "high": "138.30",
                    "low": "133.75",
                    "close": "135.49"
                    }, {
                    "date": "2018-09-11",
                    "open": "135.99",
                    "high": "139.40",
                    "low": "135.75",
                    "close": "136.85"
                    }, {
                    "date": "2018-09-12",
                    "open": "138.83",
                    "high": "139.00",
                    "low": "136.65",
                    "close": "137.20"
                    }, {
                    "date": "2018-09-13",
                    "open": "136.57",
                    "high": "138.98",
                    "low": "136.20",
                    "close": "138.81"
                    }, {
                    "date": "2018-09-16",
                    "open": "138.99",
                    "high": "140.59",
                    "low": "137.60",
                    "close": "138.41"
                }]
            },
        }
    },
    mounted() {
        this.lineData()
        this.lineData2()
        this.lineData3()
    },
    methods: {
        lineData(){
            // sample line chart data

            let visits = 10
            for (let i = 1; i < 366; i++) {
                visits += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10);
                this.lineChartData.data.push({ date: new Date(2018, 0, i), name: "name" + i, value: visits });
            }
        },
        lineData2(){
            // sample line chart data
            let firstDate = new Date();
            // now set 500 minutes back
            firstDate.setMinutes(firstDate.getDate() - 500)
            
            let value  = 500
            for (let i = 0; i < 500; i++) {
                let newDate = new Date(firstDate);
                    // each time we add one minute
                    newDate.setMinutes(newDate.getMinutes() + i)
                // let date = new Date()
                    // date.setHours(0,0,0,0)
                    // date.setDate(i)

                value -= Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10);
                this.lineChartData2.data.push({date: newDate, value: value});
            }
        },
        lineData3(){
            let valueY  = 500
            for (let i = 0; i < 500; i++) {

                valueY -= Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10)
                this.lineChartData3.data.push({valueX: i, valueY: valueY})
            }
                console.log('============>',this.lineChartData3.data)
        }
    }
}
</script>