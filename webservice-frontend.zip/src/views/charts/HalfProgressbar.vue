<template>
    <div class="progress-wrap">
        <div class="progress-wrap-inner">
            <div class="progress-wrap-inner__bar" :style="rotateProgress"></div>
        </div>
        <span class="value-num left">0</span>
        <span class="value-num right">100</span>
        <span class="progress-wrap-count-num"><span>{{ countNumber }}</span>%</span>
    </div>
</template>
<script>
export default {
    name:'HalfProgressbar',
    props: {
        countNumber : Number,
    },
    data() {
        return{
            // countNumber: 0,  // min, maxium value ( 0 ~ 100 )
            rotateNumber: 45,
            
        }
    },
    computed: {
        rotateProgress () {
            return { transform: 'rotate(' + this.dataNumber + 'deg)'}
        },
        dataNumber() {
            // console.log('>>>', ( this.countNumber * 1.8 ) + this.rotateNumber)
            return ( this.countNumber * 1.8 ) + this.rotateNumber
        }
    }
}
</script>