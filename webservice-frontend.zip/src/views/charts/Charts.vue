<template>
  <div>
    <CCardGroup columns class="card-columns cols-2">
      <CCard>
        <CCardHeader>
          Line Chart
          <div class="card-header-actions">
            <a 
              href="https://coreui.io/vue/docs/components/charts" 
              class="card-header-action" 
              rel="noreferrer noopener" 
              target="_blank"
            >
              <small class="text-muted">docs</small>
            </a>
          </div>
        </CCardHeader>
        <CCardBody>
          <CChartLineExample/>
        </CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Bar Chart</CCardHeader>
        <CCardBody><CChartBarExample/></CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Doughnut Chart</CCardHeader>
        <CCardBody><CChartDoughnutExample/></CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Radar Chart</CCardHeader>
        <CCardBody><CChartRadarExample/></CCardBody>
      </CCard>
      <CCard>
         <CCardHeader>Pie Chart</CCardHeader>
        <CCardBody><CChartPieExample/></CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Polar Area Chart</CCardHeader>
        <CCardBody><CChartPolarAreaExample/></CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Simple line chart</CCardHeader>
        <CCardBody>
          <CChartLineSimple border-color="success" labels="months"/>
        </CCardBody>        
      </CCard>
      <CCard>
        <CCardHeader>Simple pointed chart</CCardHeader>
        <CCardBody><CChartLineSimple pointed border-color="warning"/></CCardBody>
      </CCard>
      <CCard>
        <CCardHeader>Simple bar chart</CCardHeader>
        <CCardBody><CChartBarSimple background-color="danger"/></CCardBody>        
      </CCard>
    </CCardGroup>

    <CRow>
      <CCol lg="4">
        <CCard>
          <CLineBarChart/>
        </CCard>
      </CCol>
      <CCol lg="4">
        <CCard>
          <CLineBarChart/>
        </CCard>
      </CCol>
      <CCol lg="4">
        <CCard>
          <CLineBarChart pointed border-color="success" background-color="danger"/>
        </CCard>
      </CCol>
    </CRow>

    <CRow>
      <CCol>
        <CCard>
          <CChartHorizontalBar 
            :dataPoints="testData"
          />
        </CCard>
      </CCol>
    </CRow>
    <CRow>
      <CCol lg="5">
        <CCard>
          <HalfProgressbar
          />
        </CCard>
      </CCol>
    </CRow>
  </div>
</template>

<script>
import * as Charts from './index.js'

import HalfProgressbar from './HalfProgressbar'

export default {
  name: 'Charts',
  components: {
    ...Charts,
    HalfProgressbar
  },
  data() {
    return{
      testData:[10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 20]
    }
  }
}
</script>
