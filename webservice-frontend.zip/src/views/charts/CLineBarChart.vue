<template>
    <CChartBar
        :datasets="computedDatasets"
        :options="computedOptions"
        :labels="labels"
    />
</template>

<script>
import { CChartBar } from '@coreui/vue-chartjs'
import { getColor, deepObjectsMerge } from '@coreui/utils/src'

export default {
name: 'CChartBarSimple',
components: { CChartBar },
props: {
    ...CChartBar.props,
    backgroundColor: {
        type: String,
        default: 'rgba(0,0,0,.2)'
    },
    borderColor: {
        type: String,
        default: 'rgba(0,0,0,.55)'
    },
    pointHoverBackgroundColor: String,
    dataPoints: {
        type: Array,
        default: () => [10, 22, 34, 46, 58, 70, 46, 23, 45, 78, 34, 12]
    },
    label: {
        type: String,
        default: 'Sales'
    },
    pointed: Boolean
},
computed: {
    defaultDatasets () {
        return [
            {
                label:'Low',
                data: this.dataPoints,
                backgroundColor: getColor(this.backgroundColor),
                pointHoverBackgroundColor: getColor(this.pointHoverBackgroundColor),
                label: this.label,
                barPercentage: 0.5,
                categoryPercentage: 1
            },
            {
                label:'High',
                data: [15, 25, 35, 45, 55, 75, 45, 25, 45, 75, 35, 15],
                backgroundColor: 'gray',
                pointHoverBackgroundColor: 'gray',
                label: this.label,
                barPercentage: 0.5,
                categoryPercentage: 1
            },
            {
                label: 'Line Dataset',
                data: this.dataPoints,
                borderColor: getColor(this.borderColor),
                fill: false,
                type: 'line',
                lineTension: 0.3,
            },
            {
                label: 'Line Dataset',
                data: [15, 25, 35, 45, 55, 75, 45, 25, 45, 75, 35, 15],
                borderColor: getColor(this.borderColor),
                fill: false,
                type: 'line',
                lineTension: 0.3,
            },
        ]
    },
    defaultOptions () {
        return {
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'top',
                align: 'start'
            },
            scales: {
                xAxes: [{
                    display: false,
                    stacked: true
                }],
                yAxes: [{
                    display: false,
                    stacked: true
                    }]
                }
            }
        },
        computedDatasets () {
            return deepObjectsMerge(this.defaultDatasets, this.datasets || {})
        },
        computedOptions () {
            return deepObjectsMerge(this.defaultOptions, this.options || {})
        }
    }
}
</script>
