<template>
  <div class="tooltip-style-wrap">
    <GmapMap
      :center="mapCenter"
      v-bind="gMap.option"
      class="gmap">
      <GmapInfoWindow
        :options="gMap.info.option"
        :position="gMap.info.position"
        :opened="gMap.info.opened"
        @closeclick="gMap.info.opened = false">
        <div class="map-tooltip-typeA">
          <div class="map-tooltip-contents">
            <div class="drill d-flex align-items-start justify-content-start">
              <app-icon name="drillPoint" size="l" fill class="ml-1" />

              <div class="info-text-wrap">
                <span class="name">{{gMap.info.data.equipmentName}}</span>
                <div class="value-wrap">
                  <span>{{$t('analytics.fleet.ststus')}}</span>
                  <span class="num">{{gMap.info.data.status}}</span>
                </div>
                <div class="value-wrap">
                  <span>{{$t('analytics.fleet.operator')}}</span>
                  <span class="num">{{gMap.info.data.operator}}</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      </GmapInfoWindow>
      <template v-for="marker in item">
        <GmapMarker :key="`marker_${marker.equipmentId}`"
          v-if="isShow(marker)"
          :position="marker.position"
          :clickable="true"
          :icon="{ url: 'img/gmap/marker.png' }"
          @mouseover="overMarker(marker)"
          @click="$emit('clickMarker', marker)" />
      </template>
      <GmapPolyline v-if="isShow()"
        :path.sync="router"
        :options="{ strokeColor: '#fd6402', strokeOpacity: 1, strokeWeight: 2 }" />

      <GmapMarker v-if="isShow() && history.marker !== null"
        :position="history.marker"
        :clickable="false"
        :icon="{ url: 'img/historyMarker.png' }" />
      <GmapPolyline v-if="isShow() && history.router.length"
        :path.sync="history.router"
        :options="{ strokeColor: '#f9b990', strokeOpacity: 0.7, strokeWeight: 2 }" />
    </GmapMap>
    <CCard class="mb-0 position-absolute legend-radio-wrap top-right none-shadow" v-if="item.length">
      <CCardHeader style="width:10.3125rem">
        <strong>Legend</strong>
        <div class="card-header-actions">
          <CLink class="card-header-action btn-minimize" @click="visible.legend = !visible.legend">
            <!-- <CIcon :name="`cil-chevron-${visible.legend ? 'top' : 'bottom'}`"/> -->
            <app-icon :name="`${visible.legend ? 'arrowTop' : 'arrowBottom'}`" size="s" fill class="icon-arrow color-hold"/>
          </CLink>
        </div>
      </CCardHeader>
      <transition name="fade">
        <CCollapse :show="visible.legend" :duration="400">
          <CCardBody class="line-none p-2" style="width:10.3125rem">
            <ul class="list-wrap list-unstyled mb-0">
                <li v-for="base in item" :key="base.equipmentId">
                  <CRow>
                    <CCol col="9">
                      <CInputCheckbox
                        :label="base.equipmentName"
                        :checked.sync="base._selected"
                        @update:checked="updateLegend"
                        custom>
                      </CInputCheckbox>
                    </CCol>
                    <CCol col="3">
                      <span @click="movePosition(base)">
                        <!-- <CIcon name="cil-location-pin" style="cursor: pointer;" /> -->
                        <app-icon name="locationPoint" size="s" fill class="color-hold" style="cursor: pointer;" />
                      </span>
                    </CCol>
                  </CRow>
                </li>
            </ul>
          </CCardBody>
        </CCollapse>
      </transition>
    </CCard>
    <div v-if="searchDate.length" class="map-progress horizontal absolute-layout">
      <vue-slider
        v-model="gMap.slider.val"
        v-bind="gMap.slider.option"
        :data="gMap.slider.item">
        <template v-slot:dot="{ focus }">
          <div :class="['custom-dot-2', { focus }]"></div>
        </template>
      </vue-slider>
    </div>
  </div>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
import utils from '@/assets/js/utils'
import VueSlider from "vue-slider-component"
import "vue-slider-component/theme/antd.css"
export default {
  name: `analyticsGmap`,
  components: {
    VueSlider,
    AppIcon
  },
  props: {
    id: {
      type: Number,
      default () {
        return null
      }
    },
    searchDate: {
      type: Array,
      required: true
    },
    item: {
      type: Array,
      required: true
    },
    router: {
      type: Array,
      required: true
    },
    mapOption: {
      type: Object,
      default() {
        return {}
      }
    },
    infoOption: {
      type: Object,
      default() {
        return {}
      }
    },
    sliderOption: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      visible: {
        legend: false
      },
      gMap: {
        center: null,
        option: Object.assign({
          options: {
            zoom: 13,
            streetViewControl: false,
            rotateControl: false,
            mapTypeControl: true,
            fullscreenControl: false,
            mapTypeId: "satellite",
            scrollwheel: true,
            controlSize: 21
          }
        }, this.mapOption),
        info: {
          option: Object.assign({
            pixelOffset: {
              width: 0,
              height: -35,
            }
          }, this.infoOption),
          opened: false,
          position: {
            lat: 0,
            lng: 0,
          },
          data: {}
        },
        slider: {
          val: 1,
          item: [],
          option: Object.assign({
            adsorb: true,
            process: true
          }, this.sliderOption)
        }
      }
    }
  },
  computed: {
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    mapCenter () {
      let center = { lat: 0, lng: 0 }
      if (this.gMap.center !== null) {
        center = this.gMap.center
      }else if (this.item.length) {
        center = this.item[0].position
      }else if (this.userSite.latitudeValue && this.userSite.longitudeValue) {
        // 사이트 기본 위도,경도
        center = { lat: parseFloat(this.userSite.latitudeValue), lng: parseFloat(this.userSite.longitudeValue) }
      }
      return center
    },
    history () {
      let history = {
        marker: null,
        router: []
      }
      if (this.router.length) {
        let standard = this.$moment(this.gMap.slider.val)
        history.router = this.router.filter(hisroty => {
          return this.$moment(hisroty.date).isSameOrBefore(standard)
        })

        let lastRoute = this.router.slice(-1)[0]
        if (standard.isSameOrBefore(this.$moment(lastRoute.date))) {
          history.marker = history.router.slice(-1)[0]
        }
      }
      
      return history
    }
  },
  watch: {
    searchDate: {
      deep: true,
      immediate: true,
      async handler(period) {
        this.gMap.center = null
        this.getSearchPeriod()
      }
    },
    mapCenter(val){
      if(typeof val.lat === 'number' && val.lat === 0 && val.lng === 0){
        this.gMap.option.options.zoom = 5
      }
    }
  },
  mounted() {
    
  },
  methods: {
    isShow (item) {
      if (typeof item === 'undefined') {
        item = {equipmentId: this.id}
      }
      return (this.item.find(s => s.equipmentId === item.equipmentId) || {})._selected
    },
    getSearchPeriod () {
      this.gMap.slider.item = []
      if (this.searchDate.length) {
        this.gMap.slider.val = this.searchDate[1]
        let start = this.$moment(this.searchDate[0])
        let end = this.$moment(this.searchDate[1])
        let difDay = end.diff(start, 'days')

        this.gMap.slider.item.push(this.searchDate[0])
        if (difDay > 0) {
          for (var i = 0; i < difDay; ++i) {
            this.gMap.slider.item.push(start.add(1, 'day').format('YYYY-MM-DD'))
          }
        }
      }
    },
    overMarker (item) {
      if(this.gMap.info.opened){
        this.gMap.info.opened = false
      }else{
        this.gMap.info.position = item.position
        this.gMap.info.data = item
        this.gMap.info.opened = true
      }
    },
    updateLegend () {
      if (this.gMap.info.opened) {
        if (!this.isShow(this.gMap.info.data)) {
          this.gMap.info.opened = false
        }
      }
    },
    movePosition (item) {
      this.gMap.center = null
      this.$nextTick(() => {
        this.gMap.center = this.item.find(s => s.equipmentId === item.equipmentId).position
      })
    }
  }
}
</script>