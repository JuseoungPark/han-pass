<template>
  <div class="tooltip-style-wrap">
    <GmapMap :center="mapCenter" v-bind="gMap.option" class="gmap analytics-vib">
      <GmapInfoWindow 
        :options="gMap.info.option" 
        :position="gMap.info.position" 
        :opened="gMap.info.opened" 
        @closeclick="gMap.info.opened = false">
        <div class="map-tooltip-typeA">
          <div class="map-tooltip-contents">
            <div class="vibration d-flex align-items-start justify-content-start">
              <app-icon name="vibrationPoint" size="l" fill class="ml-1" />
              <div class="info-text-wrap">
                <span class="name">{{gMap.info.data.geophoneName}}</span>

                <div class="value-wrap">
                  <span>{{$t('analytics.vibration.map.limitationPvs')}}</span>
                  <span class="num">{{gMap.info.data.pvsValue}}</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </GmapInfoWindow>
      <template v-for="marker in item">
        <GmapMarker :key="`marker_${marker.id}`"
          v-if="checkboxOpt[0].checked"
          :position="marker.position"
          :clickable="true"
          :icon="{ url: 'img/gmap/ic_vibration.png' }"
          @mouseover="overMarker(marker, 'info')"
          @click="$emit('clickMarker', marker)" />
      </template>
      <GmapInfoWindow
        :options="gMap.blastInfo.option"
        :position="gMap.blastInfo.position"
        :opened="gMap.blastInfo.opened"
        @closeclick="gMap.blastInfo.opened = false">
        <div class="map-tooltip-typeA">
          <div class="map-tooltip-contents">
            <div class="blast d-flex align-items-start justify-content-start">
              <app-icon name="blastPoint" size="l" fill class="ml-1" />

              <div class="info-text-wrap">
                <span class="name">{{gMap.blastInfo.data.blastName}}</span>
                <div class="value-wrap">
                  <span>{{$t('analytics.vibration.map.actualPvs')}}</span>
                  <span class="num">{{gMap.blastInfo.data.actualPvs}}</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      </GmapInfoWindow>
      <template v-for="blast in blasts">
        <GmapMarker :key="`blast_${blast.blastId}`"
          v-if="isShow(blast)"
          :position="blast.position"
          :clickable="true"
          :icon="{ url: 'img/gmap/ic_blast_now.png' }"
          @mouseover="overMarker(blast, 'blastInfo')"/>
      </template>
      <template v-for="ref in referenceLines" >
        <GmapPolyline :key="`referenceLine_${ref.blastId}`"
          v-if="checkboxOpt[2].checked"
          :path.sync="ref.referenceLines"
          :options="{ strokeColor: '#fd6402', strokeOpacity: 1, strokeWeight: 2 }" />
      </template>
      <GmapInfoWindow
        :options="gMap.structures.option"
        :position="gMap.structures.position"
        :opened="gMap.structures.opened"
        @closeclick="gMap.structures.opened = false">
        <div class="map-tooltip-typeA">
          <div class="map-tooltip-contents">
            <div class="blast d-flex align-items-start justify-content-start">
              <app-icon name="structurePoint" size="l" fill class="ml-1" />
              <div class="info-text-wrap">
                <span class="name">{{gMap.structures.data.structuresName}}</span>
                <div class="value-wrap">
                  <span>{{$t('siteInformation.sitemap.structures.structureDescription')}}</span>
                  <span class="num">{{gMap.structures.data.description}}</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      </GmapInfoWindow>
      <template v-for="(m, index) in structures" >
        <GmapMarker
            v-if="checkboxOpt[1].checked"
            :key="'structures-'+index"
            :position="m.position"
            :label="m.label"
            @mouseover="overMarker(m, 'structures')"
            :icon="{ url: 'img/gmap/ic_structure.png' }"/>
      </template>
    </GmapMap>
    <!-- mini map -->
    <div ref="miniMap" class="mini-map" @click="changeMapType">
      <GmapMap
        :center="mapCenter"
        :zoom="13"
        :options="gMap.option.miniMapOptions"
        style="height: 100%"
      >
      </GmapMap>
    </div>

    <CCard class="mb-0 position-absolute legend-radio-wrap top-right none-shadow" v-if="item.length">
      <CCardHeader style="min-width:10.3125rem">
        <span>Checkbox</span>
        <div class="card-header-actions">
          <CLink class="card-header-action btn-minimize" @click="visible.legend = !visible.legend">
            <!-- <CIcon :name="`cil-chevron-${visible.legend ? 'top' : 'bottom'}`"/> -->
            <app-icon :name="`${visible.legend ? 'arrowTop' : 'arrowBottom'}`" size="s" fill class="icon-arrow color-hold"/>
          </CLink>
        </div>
      </CCardHeader>
      <transition name="fade">
        <CCollapse :show="visible.legend" :duration="400">
          <CCardBody class="line-none p-2" style="min-width:10.3125rem">
            <ul class="list-wrap list-unstyled mb-0">
                <li v-for="(item, index) in checkboxOpt" :key="index">
                  <CRow>
                    <CCol col="12">
                      <CInputCheckbox
                        :label="item.label"
                        :checked.sync="item.checked"
                        @update:checked="updateLegend(item)"
                        custom>
                      </CInputCheckbox>
                    </CCol>
                  </CRow>
                </li>
            </ul>
            <!-- <ul class="list-wrap list-unstyled mb-0">
                <li v-for="base in item" :key="base.id">
                  <CRow>
                    <CCol col="10">
                      <CInputCheckbox
                        :label="base.name"
                        :checked.sync="base._selected"
                        @update:checked="updateLegend"
                        custom>
                      </CInputCheckbox>
                    </CCol>
                    <CCol col="2">
                      <span @click="movePosition(base)">
                        <app-icon name="locationPoint" size="s" fill class="color-hold" style="cursor: pointer;" />
                      </span>
                    </CCol>
                  </CRow>
                </li>
            </ul> -->
          </CCardBody>
        </CCollapse>
      </transition>
    </CCard>
  </div>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'
export default {
  name: `analyticsVibrationGmap`,
  components: {AppIcon},
  mixins: [apiMixin],
  props: {
    id: {
      type: Number,
      default () {
        return null
      }
    },
    item: {
      type: Array,
      required: true
    },
    blasts: {
      type: Array,
      default () {
        return []
      }
    },
    mapOption: {
      type: Object,
      default() {
        return {}
      }
    },
    infoOption: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      visible: {
        legend: false
      },
      gMap: {
        center: null,
        option: Object.assign({
          options: {
            zoom: 13,
            streetViewControl: false,
            rotateControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
            mapTypeId: "satellite",
            scrollwheel: true,
            controlSize: 21
          },
          miniMapOptions: {
            fullscreenControl: false,
            streetViewControl: false,
            rotateControl: false,
            scrollwheel: false,
            mapTypeControl: false,
            draggable: false,
            zoomControl: false,
            minZoom: 13,
            maxZoom: 13,
            mapTypeId: "roadmap",
          },
        }, this.mapOption),
        info: {
          option: Object.assign({
            pixelOffset: {
              width: 0,
              height: -35,
            }
          }, this.infoOption),
          opened: false,
          position: {
            lat: 0,
            lng: 0,
          },
          data: {}
        },
        blastInfo: {
          option: Object.assign({
            pixelOffset: {
              width: 0,
              height: -35,
            }
          }, this.infoOption),
          opened: false,
          position: {
            lat: 0,
            lng: 0,
          },
          data: {}
        },
        structures:{
          option: Object.assign({
            pixelOffset: {
              width: 0,
              height: -35,
            }
          }, this.infoOption),
          opened: false,
          position: {
            lat: 0,
            lng: 0,
          },
          data: {}
        }
      },
      structures:[],
      checkboxOpt: [
          { label: 'Monitoring point', checked: true },
          { label: 'Mine Structure', checked: true },
          { label: 'Distance', checked: true },
      ],
      checkbox: '',
    }
  },
  computed: {
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    mapCenter () {
      let center = { lat: 0, lng: 0 }
      if (this.gMap.center !== null) {
        center = this.gMap.center
      }
      else if (this.item.length) {
        center = this.item[0].position
      }else if (this.userSite.latitudeValue && this.userSite.longitudeValue) {
        // 사이트 기본 위도,경도
        center = { lat: parseFloat(this.userSite.latitudeValue), lng: parseFloat(this.userSite.longitudeValue) }
      }
      return center
    },
    referenceLines () {
      if (this.id) {
        let parentPosition = this.item.find(s => s.id === this.id).position
        return this.blasts.map(item => {
          return {
            id: item.geophoneId,
            blastId: item.blastId,
            referenceLines: [
              parentPosition,
              item.position
            ]
          }
        })
      }
      return []
    }
  },
  watch: {
    mapCenter(val){
      if(val.lat === 0 && val.lng === 0){
        this.gMap.option.options.zoom = 5
      }
    }
  },
  mounted() {
    this.getStructures()
  },
  methods: {
    isShow (item) {
      return this.item.find(s => s.id === (item.id || item.geophoneId))._selected
    },
    overMarker (item, type) {
      if(this.gMap[type].opened){
        this.gMap[type].opened = false
      }else{
        Object.keys(this.gMap).forEach((item)=>{
          if(this.gMap[item] && typeof this.gMap[item].opened !== 'undefined'){
            this.gMap[item].opened = false
          } 
        })
        this.gMap[type].position = item.position
        this.gMap[type].data = item
        this.gMap[type].opened = true
      }
    },
    updateLegend (item) {
      console.log(item)
    },
    /*updateLegend () {
      if (this.gMap.info.opened) {
        if (!this.isShow(this.gMap.info.data)) {
          this.gMap.info.opened = false
        }
      }
      if (this.gMap.blastInfo.opened) {
        if (!this.isShow(this.gMap.blastInfo.data)) {
          this.gMap.blastInfo.opened = false
        }
      }
    },*/
    movePosition (item) {
      this.gMap.center = null
      // TODO => 음 고민고민
      // return { lat: parseFloat(this.userSite.latitudeValue), lng: parseFloat(this.userSite.longitudeValue) }
      this.$nextTick(() => {
        this.gMap.center = this.item.find(s => s.id === item.id).position
      })
    },
    getStructures() {
      this.structures = []
      this._moduleName = `v1/siteInfos/${this.userSite.siteId}/structures/?pagable=false`
      this.params = { pagable: false }
      this.requestApiAsync((res)=>{
        let latValue = '' // 37.552855
        let lngValue = '' // 128.965973
        res.content.forEach((item) => {
          if (item.useYn === 'Y') {
            latValue = Number(item.latitudeValue)
            lngValue = Number(item.longitudeValue)
            this.structures.push({
                position: { lat: latValue, lng: lngValue },
                visibility: true,
                structuresName: item.structureName,
                description: item.structureDescription,
            })
          }
        })
        // console.log(this.structures)
      })
    },
    changeMapType() {
      // map type 변경
      // console.log('map change!!', this.gMap.option.options.mapTypeId)
      // console.log('map change!!', this.gMap.option.miniMapOptions.mapTypeId)
      this.gMap.option.options.mapTypeId === "satellite" ? this.gMap.option.options.mapTypeId = "roadmap" : this.gMap.option.options.mapTypeId = "satellite"
      this.gMap.option.miniMapOptions.mapTypeId === "roadmap" ? this.gMap.option.miniMapOptions.mapTypeId = 'satellite' : this.gMap.option.miniMapOptions.mapTypeId = 'roadmap'
    },
  }
}
</script>