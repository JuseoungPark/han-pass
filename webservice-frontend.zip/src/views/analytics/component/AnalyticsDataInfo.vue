<template>
  <CRow>
    <CCol lg="12">
      <CCardGroup>
        <template v-for="f in fields">
          <div :key="f.key" class="card box-unit typeA white-text large py-2">
            <!-- <CIcon :name="f.icon" /> -->
            <app-icon :name="f.icon" size="xl" fill :class="f.icon"/>
            <div class="text-wrap">
              <Strong class="main-text" v-text="f.label" />
              <span class="sub-text">
                <!-- {{info[f.key]}}<br/> -->
                {{ info[f.key] | NumUnitCutting }}
              </span>
            </div>
          </div>
        </template>
      </CCardGroup>
    </CCol>
  </CRow>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
  name: "AnalyticsDataInfo",
  components: {
    AppIcon
  },
  props: {
    info: {
      type: Object,
      default () {
        return {}
      }
    },
    fields: {
      type: Array,
      default () {
        return [
          {
            key: 'blasts',
            label: 'Blasts',
            class: '',
            icon: 'cil-brightness',
          }
        ]
      }
    }
  },
}
</script>
