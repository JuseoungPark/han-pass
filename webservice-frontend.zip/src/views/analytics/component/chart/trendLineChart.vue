<template>
  <div>
    <div v-show="item.length">
      <CRow><CCol><span>{{rowCalculation.value2}}</span></CCol></CRow>
      <CRow><CCol><span>{{rowCalculation.value}}</span></CCol></CRow>
      <div ref="am"
        :class="chartClass"
        v-bind:style="chartStyle" />
    </div>
    <div v-show="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import * as am4plugins_regression from '@amcharts/amcharts4/plugins/regression'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

export default {
  name: "trendLineChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '350px'
        }
      }
    }
  },
  data () {
    return {
      isSerices: false,
      rowCalculation: {
        value: '',
        value2: ''
      }
    }
  },
  methods: {
    async drawChart () {
      await this.initChart()
      this.chart.cursor.behavior = "none"
      // x 축
      let x = this.chart.xAxes.push(new am4charts.ValueAxis())
      // x.keepSelection = true
      // x.zoom({start:0,end:1})
      
      x.logarithmic = true
      x.treatZeroAs = 0.1
      x.title.text = 'Scaled distance (kg⅓/m)'
      x.renderer.minGridDistance = 20
      x.renderer.labels.template.fill = am4core.color('#777')
      x.renderer.labels.template.fontSize = 11
      x.renderer.labels.template.rotation = 270
      x.renderer.labels.template.horizontalCenter = "right"
      x.renderer.labels.template.verticalCenter = "middle"

      // y축
      let leftY = this.chart.yAxes.push(new am4charts.ValueAxis())
      // leftY.keepSelection = true
      // leftY.zoom({start:0,end:1})
      leftY.logarithmic = true
      leftY.treatZeroAs = 0.1
      leftY.title.text = 'Peak particle velocity (mm/s)'
      leftY.renderer.minGridDistance = 20
      leftY.renderer.labels.template.fill = am4core.color('#777')
      leftY.renderer.labels.template.fontSize = 11

      // Create Serices
      this.createSerices(this.chart, {x: 'scaledDistance',y: 'value2',name: 'Numerical results',rotation: 0,color: '#f9b990'})
      this.createSerices(this.chart, {x: 'scaledDistance',y: 'value',name: 'Test results',rotation: 45,color: '#f5854c'})

      // Create Trend
      this.createTrend(this.chart, {x: 'scaledDistance',y: 'value2',name: 'Numerical results',color: '#2f8eb5',labelY: 70})
      this.createTrend(this.chart, {x: 'scaledDistance',y: 'value',name: 'Test results',color: '#fe7676',labelY: 240})
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'top'
      this.chart.legend.contentAlign = 'right'
      this.chart.legend.marginBottom = 20
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 15
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    },
    createSerices (chart, option) {
      if(chart.series){
        let series = chart.series.push(new am4charts.LineSeries())
        series.dataFields.valueY = option.y
        series.dataFields.valueX = option.x
        series.strokeWidth = 0
        series.name = option.name
        series.cloneTooltip = false
        series.showOnInit = false

        let bullet = series.bullets.push(new am4charts.Bullet())
        let square = bullet.createChild(am4core.Rectangle)
        square.horizontalCenter = 'middle'
        square.verticalCenter = 'middle'
        square.rotation = option.rotation
        square.strokeWidth = 0
        square.tooltipText = `Scaled distance :  [bold]{valueX}[/] (kg⅓/m)\nPeak particle velocity :  [bold]{valueY}[/] (mm/s)`
        square.fill = am4core.color(option.color)
        // square.fill = chart.colors.getIndex(option.color)
        square.direction = 'top'
        square.width = 8
        square.height = 8
      }
    },
    createTrend(chart, option) {
      // var label = chart.tooltipContainer.createChild(am4core.Label)
      // label.x = am4core.percent(100)
      // label.marginRight = 30
      // label.y = option.labelY
      // label.align = 'right'
      // label.toFront()

      let trend = chart.series.push(new am4charts.LineSeries())
      trend.dataFields.valueY = option.y
      trend.dataFields.valueX = option.x
      trend.strokeWidth = 1
      trend.stroke = am4core.color(option.color)
      // trend.stroke = chart.colors.getIndex(option.color)
      trend.cloneTooltip = false
      trend.showOnInit = false
      trend.hiddenInLegend = true

      let regseries = trend.plugins.push(new am4plugins_regression.Regression())
      regseries.events.on('processed', (ev) => {
        let equation = ev.target.result.string.replace(/y/, "PPV").replace(/x/, "SD").replace(/\^2/, "²")
        let r = ev.target.result.r2
        this.rowCalculation[option.y] = `${option.name}: ${equation} / R²: ${r}`
        //label.text = `[bold]${option.name}:[/] ${equation}\n[bold]R²:[/] ${r}`
      })
    }
  },

}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>