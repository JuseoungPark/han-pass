<template>
  <div>
    <div ref="am"
      v-show="item.length"
      :class="chartClass"
      v-bind:style="chartStyle" />
    <div v-show="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

export default {
  name: "dateBubbleChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    search: {
      type: Object,
      default: () => {
        return {}
      }
    },
    date: {
      type: String,
      default () {
        return 'date'
      }
    },
    axisOption: {
      type: Object,
      default () {
        return {
          x: {
            minGridDistance: 120,
            min: undefined,
            max: undefined
          },
          leftY: {
            minGridDistance: 40,
            min: undefined,
            max: undefined
          }
        }
      }
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '300px'
        }
      }
    }
  },
  data() {
    return{
      colorList: [
        {"color": "#f4ceb5"},
        {"color": "#f9b990"},
        {"color": "#f89b6c"},
        {"color": "#f5854c"},
        {"color": "#f37321"},
        {"color": "#fd6402"},
        {"color": "#d24c02"},
        {"color": "#ce3723"},
        {"color": "#df4343"},
        {"color": "#d75c5c"},
        {"color": "#a93e3e"},
        {"color": "#9f2e38"},
        {"color": "#ac3964"},
        {"color": "#ac508f"},
        {"color": "#8869a0"},
      ]
    }
  },
  computed: {
    items() {
      return this.item.map((obj) => {
        let ritem = {};
        for (const [key, value] of Object.entries(obj)) {
          if(key === 'date') ritem[key] = value;
          else ritem[key.toUpperCase()] = value;
        }
        return ritem
      })
    },
    itemsKeys(){
      return [...new Set([].concat(
        ...this.items.map(obj => {
          return Object.keys(obj).filter((key)=> key !== this.date)
        })
      ))]
    }
  },
  methods: {
    async drawChart () {
      await this.initChart()

      // x 축
      await this.setDateAxis()

      // y축
      let leftY = this.chart.yAxes.push(new am4charts.ValueAxis())
      leftY.renderer.minGridDistance = this.axisOption.leftY.minGridDistance
      leftY.min = this.axisOption.leftY.min
      leftY.max = this.axisOption.leftY.max
      leftY.renderer.labels.template.fill = am4core.color('#777')
      leftY.renderer.labels.template.fontSize = 11
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'top'
      this.chart.legend.contentAlign = 'right'
      this.chart.legend.marginBottom = 20
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 10
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    },
    createSerices() {
      let num = 0
      this.itemsKeys.forEach(item => {
        num++

        if(num == this.colorList.length){
          num = 0
        }
        
        let line = this.chart.series.push(new am4charts.LineSeries())
        line.dataFields.valueY = item
        line.dataFields.dateX = this.date
        line.name = item
        line.tooltipText = `${item} : [bold]{valueY}[/] [font-size:0.6rem;#fff]`
        line.tooltip.background.fill = am4core.color(this.colorList[num].color)
        line.tooltip.getFillFromObject = false
        line.tooltip.pointerOrientation = "vertical"
        line.strokeWidth = 1
        line.cloneTooltip = false
        line.showOnInit = false

        line.stroke = am4core.color(this.colorList[num].color)

        let bullet = line.bullets.push(new am4core.Circle())
        bullet.radius = 4
        // bullet.tooltipText = "[bold]X : {valueX} \nY : {valueY}[/]"
        bullet.stroke = line.stroke
        bullet.fill = line.stroke
      })
    }
  },

}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>