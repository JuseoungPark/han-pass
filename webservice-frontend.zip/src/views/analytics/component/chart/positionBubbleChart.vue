<template>
  <div>
    <div ref="am"
      v-show="item.length"
      :class="chartClass"
      v-bind:style="chartStyle" />
    <div v-show="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

export default {
  name: "positionBubbleChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    xyCode: {
      type: Object,
      default () {
        return {
          x: 'x',
          y: 'y',
          count: 'count'
        }
      }
    },
    axisOption: {
      type: Object,
      default () {
        return {
          x: {
            minGridDistance: 120,
            min: undefined,
            max: undefined
          },
          leftY: {
            minGridDistance: 40,
            min: undefined,
            max: undefined
          }
        }
      }
    },
    guide: {
      type: [String, Number],
      default () {
        return null
      }
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '250px'
        }
      }
    }
  },
  data() {
    return{
      colorList: [
        {"color": "#f4ceb5"},
        {"color": "#f9b990"},
        {"color": "#f89b6c"},
        {"color": "#f5854c"},
        {"color": "#f37321"},
        {"color": "#fd6402"},
        {"color": "#d24c02"},
        {"color": "#ce3723"},
        {"color": "#df4343"},
        {"color": "#d75c5c"},
        {"color": "#a93e3e"},
        {"color": "#9f2e38"},
        {"color": "#ac3964"},
        {"color": "#ac508f"},
        {"color": "#8869a0"}
      ]
    }
  },
  methods: {
    initChart(){
      let chart = am4core.create(this.$refs.am, am4charts.XYChart)
      //chart.data = this.items
      chart.svgContainer.measure()
      chart.cursor = new am4charts.XYCursor()
      this.chart = chart
    },
    async drawChart () {
      await this.initChart()

      // x 축
      let x = this.chart.xAxes.push(new am4charts.ValueAxis())
      x.renderer.minGridDistance = this.axisOption.x.minGridDistance
      x.min = this.axisOption.x.min
      x.max = this.axisOption.x.max
      x.renderer.labels.template.fill = am4core.color('#777')
      x.renderer.labels.template.fontSize = 11

      // y축
      let leftY = this.chart.yAxes.push(new am4charts.ValueAxis())
      leftY.renderer.minGridDistance = this.axisOption.leftY.minGridDistance
      leftY.min = this.axisOption.leftY.min
      leftY.max = this.axisOption.leftY.max
      leftY.renderer.labels.template.fill = am4core.color('#777')
      leftY.renderer.labels.template.fontSize = 11

      // Guid
      if (this.guide) {
        let guide = leftY.axisRanges.create()
        guide.value = this.guide
        guide.grid.stroke = am4core.color('#5ea565')
        guide.grid.strokeWidth = 1
        guide.grid.strokeOpacity = 1
        guide.label.hidden = true
        //this.chartGuide = guide
      }
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'top'
      this.chart.legend.contentAlign = 'right'
      this.chart.legend.marginBottom = 20
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 10
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    },
    createSerices() {
      let num = -1
      this.items.forEach(item => {
        num++

        if(num == this.colorList.length){
          num = 0
        }
        let line = this.chart.series.push(new am4charts.StepLineSeries())
        line.dataFields.valueY = this.xyCode['y']
        line.dataFields.valueX = this.xyCode['x']
        line.dataFields.count = this.xyCode['count']
        line.name = item.name
        line.data = item.data
        line.strokeWidth = 0
        line.stroke = am4core.color(this.colorList[num].color)
        line.cloneTooltip = false
        line.showOnInit = false

        let bullet = line.bullets.push(new am4core.Circle())
        bullet.radius = 2
        bullet.tooltipText = `${item.name}\nX : [bold]{valueX}[/]   Y : [bold]{valueY}[/]\ncount : [bold]{count}[/]`
        bullet.stroke = line.stroke
        bullet.fill = line.stroke
      })
    }
  },

}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>