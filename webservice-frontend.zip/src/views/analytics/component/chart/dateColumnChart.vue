<template>
  <div>
    <div ref="am"
      v-show="item.length"
      :class="chartClass"
      v-bind:style="chartStyle" />
    <div v-show="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

export default {
  name: "dateColumnChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    search: {
      type: Object,
      default: () => {
        return {}
      }
    },
    date: {
      type: String,
      default () {
        return 'date'
      }
    },
    axisOption: {
      type: Object,
      default () {
        return {
          x: {
            minGridDistance: 120,
            min: undefined,
            max: undefined
          },
          leftY: {
            minGridDistance: 40,
            min: undefined,
            max: undefined
          }
        }
      }
    },
    isStacked: {
      type: Boolean,
      default () {
        return false
      }
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '250px'
        }
      }
    }
  },
  data() {
    return{
      colorList: [
        {"color": "#f9b990"},
        {"color": "#f37321"},
        {"color": "#dc4a09"},
        {"color": "#ce3723"},
      ]
    }
  },
  methods: {
    async drawChart () {
      await this.initChart()

      // x 축
      this.setDateAxis()

      // y축
      let leftY = this.chart.yAxes.push(new am4charts.ValueAxis())
      leftY.renderer.minGridDistance = this.axisOption.leftY.minGridDistance
      leftY.min = this.axisOption.leftY.min
      leftY.max = this.axisOption.leftY.max
      leftY.renderer.labels.template.fill = am4core.color('#777')
      leftY.renderer.labels.template.fontSize = 11
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'top'
      this.chart.legend.contentAlign = 'right'
      this.chart.legend.marginBottom = 20
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 15
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    },
    createSerices() {
      let num = -1
      this.itemsKeys.map(item => {
        if (item !== this.date) {
          num++

          if(num == this.colorList.length){
            num = 0
          }
          let column = this.chart.series.push(new am4charts.ColumnSeries())
          column.dataFields.valueY = item
          column.dataFields.dateX = this.date
          column.name = item
          column.stacked = this.isStacked
          column.tooltipText = `[bold]{dateX}[/]\n${item} : [bold;#fff]{valueY}[/]`
          column.columns.template.strokeWidth = 0
          column.cloneTooltip = false
          column.showOnInit = false
          column.columns.template.fill = am4core.color(this.colorList[num].color)
          column.tooltip.pointerOrientation = 'vertical'
        }
      })
    }
  },

}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>