<template>
  <div>
    <div ref="am"
      v-show="item.length"
      :class="chartClass"
      v-bind:style="chartStyle" />
    <div v-show="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

function am4themes_myTheme(target) {
    if (target instanceof am4core.ColorSet) {
        target.list = [
            am4core.color("#f9b990"),
            am4core.color("#f5854c"),
            am4core.color("#fd6402"),
            am4core.color("#a35732"),
            am4core.color("#d75c5c")
        ];
    }
}

am4core.useTheme(am4themes_myTheme)
export default {
  name: "pieChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    pieCode: {
      type: Object,
      default () {
        return {
          category: 'category',
          value: 'value'
        }
      }
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '250px'
        }
      }
    }
  },
  methods: {
    initChart(){
      let chart = am4core.create(this.$refs.am, am4charts.PieChart)
      chart.data = this.items
      chart.svgContainer.measure()
      this.chart = chart
    },
    async drawChart () {
      await this.initChart()
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'right'
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 15
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    },
    createSerices() {
      let pie = this.chart.series.push(new am4charts.PieSeries())
      pie.dataFields.value = this.pieCode.value
      pie.dataFields.category = this.pieCode.category
      // pie.slices.template.stroke = am4core.color("#fff")
      // pie.slices.template.strokeOpacity = 1
      pie.cloneTooltip = false
      pie.showOnInit = false
      pie.labels.template.disabled = true
    }
  },

}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>