<template>
  <div>
    <div ref="am"
      v-show="item.length > 0"
      :class="chartClass"
      v-bind:style="chartStyle" />
    <div v-if="!item.length" v-text="$t('message.noData')" />
    <CThemaCover v-if="item.length && chartLoading" :customeStyle="{ 'z-index': 9, position: 'absolate' }" />
  </div>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import chartMixin from '@/assets/js/chartMixin'
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
am4core.options.minPolylineStep = 5

export default {
  name: "complexChart",
  mixins: [chartMixin],
  props: {
    item: {
      type: Array,
      default () {
        return []
      }
    },
    search: {
      type: Object,
      default: () => {
        return {}
      }
    },
    seriesType: {
      type: String,
      required: true
    },
    chartClass: {
      type: String,
      default () {
        return 'am-chart'
      }
    },
    chartStyle: {
      type: Object,
      default () {
        return {
          height: '300px'
        }
      }
    }
  },
  data() {
    return {
      isSerices: false
    }
  },
  computed: {
    chartOption () {
      return {
        volumeCost: {
          column: [
            { key: 'volume', label: 'BCM', unit: 'BCM', color: '#f9b990' }
          ],
          line: [
            { key: 'cost', label: 'COST', unit: this.userSite.currencyName, color: '#2f8eb5' }
          ],
          stepLine: [
            { key: 'target', label: 'Target', color: '#5ea565' }
          ]
        },
        operation: {
          column: [
            { key: 'drillMeter', label: 'Drill meter', unit: 'm', color: '#f9b990' },
            { key: 'chargeWeight', label: 'Charge weight', unit: 'kg', color: '#f37321' }
          ],
          line: [
            { key: 'drillingAccuracy', label: 'Drilling Accuracy', unit: '%', color: '#2f8eb5' },
            { key: 'chargingAccuracy', label: 'Charging Accuracy', unit: '%', color: '#fe7676' }
          ]
        }
      }
    }
  },
  methods: {
    async drawChart () {
      await this.initChart()
      // x 축
      this.setDateAxis()

      // y축
      let leftY = this.chart.yAxes.push(new am4charts.ValueAxis())
      leftY.renderer.minGridDistance = 100
      leftY.renderer.labels.template.fill = am4core.color('#777')
      leftY.renderer.labels.template.fontSize = 11
      let rightY = this.chart.yAxes.push(new am4charts.ValueAxis())
      rightY.renderer.minGridDistance = 100
      rightY.renderer.opposite = true
      rightY.renderer.labels.template.fill = am4core.color('#777')
      rightY.renderer.labels.template.fontSize = 11

      // ColumnSeries Series
      this.chartOption[this.seriesType].column.map(item => {
        let column = this.chart.series.push(new am4charts.ColumnSeries())
        column.dataFields.valueY = item.key
        column.dataFields.dateX = 'date'
        column.name = item.label
        column.fill = am4core.color(item.color)
        column.tooltipText = `${item.label} : [bold]{valueY}[/] [font-size:0.6rem;#fff]${item.unit}`
        column.columns.template.strokeWidth = 0
        column.cloneTooltip = false
        column.showOnInit = false
        column.tooltip.pointerOrientation = 'vertical'
      })

      // LineSeries Series
      this.chartOption[this.seriesType].line.map(item => {
        let line = this.chart.series.push(new am4charts.LineSeries())
        line.dataFields.valueY = item.key
        line.dataFields.dateX = 'date'
        line.name = item.label
        line.tooltipText = `${item.label} : [bold]{valueY}[/] [font-size:0.6rem;#fff]${item.unit}`
        line.tooltip.background.fill = am4core.color(item.color)
        line.tooltip.getFillFromObject = false
        line.strokeWidth = 1
        line.cloneTooltip = false
        line.showOnInit = false
        line.stroke = am4core.color(item.color)
        line.yAxis = rightY
      })

      // StepLineSeries Series
      if ((this.chartOption[this.seriesType].stepLine || []).length) {
        this.chartOption[this.seriesType].stepLine.map(item => {
          let stepLine = this.chart.series.push(new am4charts.StepLineSeries())
          stepLine.dataFields.valueY = item.key
          stepLine.dataFields.dateX = 'date'
          stepLine.name = item.label
          stepLine.tooltipText = `${item.label} : [bold]{valueY}[/]`
          stepLine.tooltip.background.fill = am4core.color(item.color)
          stepLine.tooltip.getFillFromObject = false
          stepLine.strokeWidth = 1
          stepLine.cloneTooltip = false
          stepLine.showOnInit = false
          stepLine.stroke = am4core.color(item.color)
        })
      }
      
      // legend
      this.chart.legend = new am4charts.Legend()
      this.chart.legend.useDefaultMarker = false
      this.chart.legend.position = 'top'
      this.chart.legend.contentAlign = 'right'
      this.chart.legend.marginBottom = 20
      this.chart.legend.fontSize = 11
      // this.chart.legend.labels.template.propertyFields.fill = 'fill'
      // this.chart.legend.labels.template.propertyFields.fill = 'stroke'
      let markerTemplate = this.chart.legend.markers.template
      markerTemplate.width = 15
      markerTemplate.height = 10
      markerTemplate.stroke = am4core.color('#ccc')
    }
  }
  
}
</script>

<style scoped>
.am-chart {
  width: 100%;
}
</style>