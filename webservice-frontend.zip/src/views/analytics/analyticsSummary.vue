<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow>
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none d-flex align-items-center justify-content-end">
              <CCol lg="4" class="title-wrap">
                <h3 class="title mb-0">{{ $t("analytics.summary.title") }}</h3>
              </CCol>
              <CCol lg="4" class="lg-mt">
                <CSelect
                  :label="$t('analytics.common.analyzing')"
                  :value.sync="search.periodType"
                  :options="codes.dates"
                  @update:value="search.date = []"
                  class="mb-0 align-items-center"
                  horizontal />
              </CCol>
              <CCol lg="4">
                <div class="form-row align-items-center">
                  <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                  <CDatePicker
                    :dateForm.sync="search.date"
                    class="col-sm-9"
                    :type="codes.dateType[search.periodType]"
                    :range="true"
                    :clearable="false"
                    :editable="false"
                    :maxDate="maxDate"
                    valueType="YYYY-MM-DD"
                    format="YYYY-MM-DD"
                    :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                </div>
              </CCol>
              <CButton
                type="submit"
                class="btn-custom-default hanwha outline lg-mt-s mr-3"
                @click="searchData">
                {{ $t("commonLabel.apply") }}
              </CButton>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.summary.productivity") }}</strong>
              <small class="ml-2">{{$t("analytics.summary.productivitySub")}}</small>
            </CCardHeader>
            <CCardBody>
              <complexChart :item="items.volumeCost" :search="search" seriesType="volumeCost"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.summary.operation") }}</strong>
              <small class="ml-2">{{$t("analytics.summary.operationSub1")}}</small>
            </CCardHeader>
            <CCardBody>
              <complexChart :item="items.operation" :search="search" seriesType="operation"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.summary.workHour") }}</strong>
            </CCardHeader>
            <CCardBody>
              <dateLineChart :item="items.workhour" unit="hr" :search="search" :isStacked="true"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.summary.frag") }}</strong>
              <small class="ml-2">({{$t("analytics.summary.fragSub")}})</small>
            </CCardHeader>
            <CCardBody>
              <dateBubbleChart :item="items.fragmentation" :search="search"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.summary.vib") }}</strong>
              <small class="ml-2">({{$t("analytics.summary.vibSub")}})</small>
            </CCardHeader>
            <CCardBody>
              <dateBubbleChart :item="items.vibration" :search="search"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "AnalyticsSummary",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    complexChart: () => import(/* webpackChunkName: "SummaryCharts" */ "@/views/analytics/component/chart/complexChart"),
    dateLineChart: () => import(/* webpackChunkName: "SummaryCharts" */ "@/views/analytics/component/chart/dateLineChart"),
    dateBubbleChart: () => import(/* webpackChunkName: "SummaryCharts" */ "@/views/analytics/component/chart/dateBubbleChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      visible: {
        fullLoading: false
      },
      
      search: {
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'days').format('YYYY-MM-DD')
        ]
      },
      items: {
        info: {},
        volumeCost: [],
        operation: [],
        workhour: [],
        fragmentation: [],
        vibration: []
      }
    }
  },
  computed: {
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/blasts`
    },
    codes(){
      return {
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.summary.infoFields.blasts'), icon: 'blasts' },
          { key: 'noOfHoles', label: this.$t('analytics.summary.infoFields.noOfHoles'), icon: 'noOfHole' },
          { key: 'blastsVolume', label: this.$t('analytics.summary.infoFields.blastsVolume'), icon: 'volume' },
          { key: 'drillMeter', label: this.$t('analytics.summary.infoFields.drillMeter'), icon: 'meter' },
          { key: 'chargeWeight', label: this.$t('analytics.summary.infoFields.chargeWeight'), icon: 'weight' },
          { key: 'cost', label: this.$t('analytics.summary.infoFields.cost', [this.userSite.currencyName]), icon: 'cost' }
        ]
      }
    }
  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/volumeCost`, 
          `${this.moduleName}/operation`, 
          `${this.moduleName}/work-hour`, 
          `${this.moduleName}/fragmentation`, 
          `${this.moduleName}/vibration`
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        // console.log('res',res)
        this.items.info = res[0].content
        this.items.volumeCost = res[1].content || []
        this.items.operation = res[2].content || []
        this.items.workhour = res[3].content || []
        this.items.fragmentation = res[4].content || []
        this.items.vibration = res[5].content || []
      }, req)
    }
  }
}
</script>