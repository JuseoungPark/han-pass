<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow id="printPage">
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none">
              <div class="d-flex align-items-center justify-content-end mb-2">
                <h3 class="title text-right d-inline-block mb-0 mr-3">{{ $t("analytics.fleet.title") }}</h3>
                <CButton
                  type="submit"
                  class="btn-custom-default hanwha outline"
                  @click="searchData">
                  {{ $t("commonLabel.apply") }}
                </CButton>
              </div>
              <CRow>
                <CCol lg="4">
                  <CCol class="px-0">
                    <CSelect
                      :value.sync="search.fleetType"
                      :options="codes.equipments"
                      :label="$t('analytics.common.analyzing')"
                      class="mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="lg-mt-s d-flex align-items-center">
                  <CCol class="px-0">
                    <CSelect
                      :value.sync="search.periodType"
                      :options="codes.dates"
                      @update:value="search.date = []"
                      class="responsive-right-sort mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="flex-center-layout lg-mt-s">
                  <div class="flex-1 form-row align-items-center">
                    <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                    <CDatePicker
                      :dateForm.sync="search.date"
                      class="col-sm-9"
                      :type="codes.dateType[search.periodType]"
                      :range="true"
                      :clearable="false"
                      :editable="false"
                      :maxDate="maxDate"
                      valueType="YYYY-MM-DD"
                      format="YYYY-MM-DD"
                      :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                  </div>
                </CCol>
              </CRow>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol class="custom-class">
          <CRow>
            <CCol lg="5">
              <CCard class="mb-0">
                <AnalyticsGmap ref="gMap" class="position-relative radius025"
                  :id="fleet.equipmentId"
                  :searchDate="searchEnd.date"
                  :item="items.base"
                  :router="items.router"
                  @clickMarker="clickMarker" />
              </CCard>
            </CCol>
            <CCol lg="7" class="lg-mt">
              <CRow>
                <CCol xs="12" lg="12">
                  <CCard>
                    <CCardHeader>
                      <strong>{{ $t("analytics.fleet.workHour") }}</strong>
                    </CCardHeader>
                    <CCardBody>
                      <dateLineChart :item="items.workTiem" :search="search"
                        unit="hr" :isStacked="true" @setLoading="setLoading" />
                    </CCardBody>
                  </CCard>
                </CCol>
                <CCol xs="12" lg="12">
                  <CCard>
                    <CCardHeader>
                      <strong>{{$t(`analytics.fleet.${search.fleetType}`)}}</strong>
                    </CCardHeader>
                    <CCardBody>
                      <dateLineChart :item="items.workLoad" :search="search"
                        unit="m" :isStacked="true" @setLoading="setLoading" />
                    </CCardBody>
                  </CCard>
                </CCol>
              </CRow>
            </CCol>
            <CCol lg="12">
              <CTabLayer
                :tabs="items.base"
                class="lg-mt position-relative"
                :tabOption="{key: 'equipmentId',label: 'equipmentName'}"
                :activeTab="option.activeTab"
                @updateTab="updateTab">
                <CRow class="mt-20">
                  <CCol lg="6">
                    <CCard class="mb-0">
                      <CCardHeader>
                        <strong>{{$t("analytics.fleet.unitStatus")}}</strong>
                      </CCardHeader>
                      <CCardBody>
                        <pieChart :item="items.unitStatus"
                          :pieCode="{category: 'common_code_name', value: 'literes'}" @setLoading="setLoading"/>
                      </CCardBody>
                    </CCard>
                  </CCol>
                  <CCol lg="6" class="lg-mt">
                    <CCard class="mb-0">
                      <CCardHeader>
                        <strong>{{$t("analytics.fleet.unitoperation")}}</strong>
                      </CCardHeader>
                      <CCardBody>
                        <dateColumnChart :item="items.unitOperation" :search="search" @setLoading="setLoading"/>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
              </CTabLayer>
            </CCol>
          </CRow>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import CTabLayer from '@/components/form/CTabLayer'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Charging",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    CTabLayer,
    AnalyticsGmap: () => import(/* webpackChunkName: "FleetCharts" */ "@/views/analytics/component/analyticsFleetGmap"),
    dateLineChart: () => import(/* webpackChunkName: "FleetCharts" */ "@/views/analytics/component/chart/dateLineChart"),
    dateColumnChart: () => import(/* webpackChunkName: "FleetCharts" */ "@/views/analytics/component/chart/dateColumnChart"),
    pieChart: () => import(/* webpackChunkName: "FleetCharts" */ "@/views/analytics/component/chart/pieChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      option : {
        activeTab: null
      },
      visible: {
        fullLoading: false
      },
      search: {
        fleetType: 'Drill',
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ]
      },
      searchEnd: {
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ]
      },
      items: {
        info: {},
        base: [],
        router: [],
        workTiem: [],
        workLoad: [],
        unitStatus: [],
        unitOperation: []
      }
    }
  },
  computed: {
    codes () {
      return {
        equipments: ['Drill', 'MPU'],
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        infoFields: [
          { key: 'unit', label: this.$t('analytics.fleet.infoFields.unit'), icon: 'noOfUnit' },
          { key: 'blasts', label: this.$t('analytics.fleet.infoFields.blasts'), icon: 'blasts' },
          { key: 'holes', label: this.$t('analytics.fleet.infoFields.holes'), icon: 'noOfHole' },
          { key: 'meter', label: this.$t('analytics.fleet.infoFields.drill'), icon: 'meter' },
          { key: 'time', label: this.$t('analytics.fleet.infoFields.operation'), icon: 'operationTime' }
        ]
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/fleet`
    },
    fleet () {
      if (this.items.base.length) {
        return this.items.base.find(s => s.equipmentId === this.option.activeTab) || {}
      }
      return {}
    },
    // fleetId () {
    //   if (this.items.base.length) {
    //     return this.items.base[this.option.activeTab].equipmentId
    //   }
    //   return null
    // },

  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/equipment-info`,
          `${this.moduleName}/work-hour`,
          `${this.moduleName}/work-load`,
        ],
        params: param
      }
      let res = await this.requestApiMutiSync(req)
      this.items.info = res[0].content
      this.items.base = res[1].content || []
      this.items.workTiem = res[2].content || []
      this.items.workLoad = res[3].content || []

      if (this.items.base.length) {
        this.option.activeTab = this.items.base[0].equipmentId || null
        await this.searchDetail(this.search)
      } else {
        this.items.unitOperation = []
        this.items.unitStatus = []
        this.items.router = []
      }

      this.$nextTick(() => {
        this.searchEnd = JSON.parse(JSON.stringify(this.search))
      })
    },
    async searchDetail (search) {
      if (this.fleet.equipmentId) {
        let param = {
          ...search,
          startDate: this.search.date[0],
          endDate: this.search.date[1],
          equipmentId: this.fleet.equipmentId
        }
        delete param.date

        let req = {
          modules: [
            `${this.moduleName}/equipment-summary`, 
            `${this.moduleName}/equipment-status`,
            `${this.moduleName}/equipment-route`,
          ],
          params: param
        }
        this.requestApiMutiAsync((res) => {
          this.items.unitOperation = res[0].content || []
          this.items.unitStatus = res[1].content || []
          this.items.router = res[2].content || []
        }, req)
      }
    },
    async updateTab (item, mapMove = true) {
      this.option.activeTab = item.equipmentId
      await this.searchDetail(this.searchEnd)
      if (mapMove) this.$refs.gMap.movePosition(this.fleet)
    },
    clickMarker (item) {
      if (this.option.activeTab !== item.equipmentId) {
        this.updateTab(item, false)
      }
    }
  }
}
</script>
<style lang="scss">
.gmap {
  height: 795px;
}
@media screen and (max-width: 991px) {
  .gmap {
    height: 400px;
  }
}
</style>