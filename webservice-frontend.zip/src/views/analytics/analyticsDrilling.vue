<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow>
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none d-flex align-items-center justify-content-end">
              <CCol lg="4" class="title-wrap">
                <h3 class="title mb-0">{{ $t("analytics.drilling.title") }}</h3>
              </CCol>
              <CCol lg="4" class="lg-mt">
                <CSelect
                  :label="$t('analytics.common.analyzing')"
                  :value.sync="search.periodType"
                  :options="codes.dates"
                  @update:value="search.date = []"
                  class="mb-0 align-items-center"
                  horizontal />
              </CCol>
              <CCol lg="4">
                <div class="form-row align-items-center">
                  <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                  <CDatePicker
                    :dateForm.sync="search.date"
                    class="col-sm-9"
                    :type="codes.dateType[search.periodType]"
                    :range="true"
                    :clearable="false"
                    :editable="false"
                    :maxDate="maxDate"
                    valueType="YYYY-MM-DD"
                    format="YYYY-MM-DD"
                    :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                </div>
              </CCol>
              <CButton
                type="submit"
                class="btn-custom-default hanwha outline lg-mt-s mr-3"
                @click="searchData">
                {{ $t("commonLabel.apply") }}
              </CButton>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol lg="12">
          <CRow>
            <CCol xs="12" md="4">
              <CCard>
                <CCardHeader>
                  <strong>{{ $t("analytics.drilling.drillMeter") }}</strong>
                  <small><code>(m)</code></small>
                </CCardHeader>
                <CCardBody>
                  <dateColumnChart :item="items.drillMeter" :search="search" :axisOption="axisOption" />
                </CCardBody>
              </CCard>
            </CCol>
            <CCol xs="12" md="4">
              <CCard>
                <CCardHeader class="position-relative">
                  <div class="row">
                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                      <div>
                        <strong class="text-nowrap">{{$t("analytics.drilling.accuracy")}}</strong>
                        <small class="text-nowrap ml-1"><code>(Depth)</code></small>
                      </div>
                      <span class="text-right">
                        <CSelect
                          class="position-right-center right-1"
                          style="width: 80px"
                          :value.sync="intervalType.all"
                          :options="codes.intervals"
                          @change="changeStandrd('all')" />
                      </span>
                    </div>
                  </div>
                </CCardHeader>
                <CCardBody>
                  <categoryColumnChart :item="items.depthAccuracy"
                    category="accuracy" :guide="intervalType.all" :search="search"/>
                </CCardBody>
              </CCard>
            </CCol>
            <CCol xs="12" md="4">
              <CCard>
                <CCardHeader>
                  <strong>{{ $t("analytics.drilling.accuracy") }}</strong>
                  <small><code>(Horizontal)</code></small>
                </CCardHeader>
                <CCardBody>
                  <positionBubbleChart :item="items.collarAccuracy" :search="search"/>
                </CCardBody>
              </CCard>
            </CCol>
          </CRow>
        </CCol>
        <CCol lg="12">
          <CTabLayer
            :tabs="codes.tabs"
            :activeTab.sync="option.activeTab"
            @updateTab="updateTab">
            <template slot-scope="props">
              <CRow class="mt-20">
                <CCol xs="12" md="4">
                  <CCard class="mb-0">
                    <CCardHeader>
                      <strong>{{ $t("analytics.drilling.drillMeter") }}</strong>
                      <small><code>(m)</code></small>
                    </CCardHeader>
                    <CCardBody>
                      <dateColumnChart :item="items.subDrillMeter" :search="search" :isStacked="true"/>
                    </CCardBody>
                  </CCard>
                </CCol>
                <CCol xs="12" md="4">
                  <CCard class="mb-0 lg-mt-2">
                    <CCardHeader class="position-relative">
                      <div class="row">
                        <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                          <div>
                            <strong class="text-nowrap">{{$t("analytics.drilling.accuracy")}}</strong>
                            <small class="text-nowrap ml-1"><code>(Depth)</code></small>
                          </div>
                          <span class="text-right">
                            <CSelect
                              class="position-right-center right-1"
                              style="width: 80px"
                              :value.sync="intervalType[props.item]"
                              :options="codes.intervals"
                              @change="changeStandrd(props.item)" />
                          </span>
                        </div>
                      </div>
                    </CCardHeader>
                    <CCardBody>
                      <categoryColumnChart :item="items.subDepthAccuracy"
                       :search="search"
                        category="accuracy"
                        :isStacked="true"
                        :guide="intervalType[props.item]"/>
                    </CCardBody>
                  </CCard>
                </CCol>
                <CCol xs="12" md="4">
                  <CCard class="mb-0 lg-mt-2">
                    <CCardHeader>
                      <strong>{{ $t("analytics.drilling.accuracy") }}</strong>
                      <small><code>(Horizontal)</code></small>
                    </CCardHeader>
                    <CCardBody>
                        <positionBubbleChart :item="items.subCollarAccuracy" :search="search"/>
                    </CCardBody>
                  </CCard>
                </CCol>
              </CRow>
            </template>
          </CTabLayer>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import CTabLayer from '@/components/form/CTabLayer'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Drilling",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    CTabLayer,
    dateColumnChart: () => import(/* webpackChunkName: "DrillingCharts" */ "@/views/analytics/component/chart/dateColumnChart"),
    categoryColumnChart: () => import(/* webpackChunkName: "DrillingCharts" */ "@/views/analytics/component/chart/categoryColumnChart"),
    positionBubbleChart: () => import(/* webpackChunkName: "DrillingCharts" */ "@/views/analytics/component/chart/positionBubbleChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      option : {
        activeTab: 'pit'
      },
      visible: {
        fullLoading: false
      },
      intervalType: {
        all: '0.1',
        pit: '0.1',
        unit: '0.1',
        operator: '0.1'
      },
      search: {
        periodType: 'Daily',
        target: 'ALL',
        accuracy: '0.1',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ],
      },
      searchEnd: {},
      items: {
        info: {},
        drillMeter: [],
        depthAccuracy: [],
        collarAccuracy: [],
        subDrillMeter: [],
        subDepthAccuracy: [],
        subCollarAccuracy: []
      },
      axisOption:{
        x: {
          minGridDistance: 120,
          min: undefined,
          max: undefined
        },
        leftY: {
          minGridDistance: 40,
          min: undefined,
          max: undefined
        }
      }
    }
  },
  computed: {
    codes () {
      return {
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        intervals: [
          { value: '0.1', label: '0.1 m' },
          { value: '0.2', label: '0.2 m' },
          { value: '0.5', label: '0.5 m' },
          { value: '1.0', label: '1.0 m' },
          { value: '2.0', label: '2.0 m' },
          { value: '5.0', label: '5.0 m' }
        ],
        tabs: [
          { key: 'pit', label: this.$t('analytics.drilling.tab.pit') },
          { key: 'unit', label: this.$t('analytics.drilling.tab.unit') },
          { key: 'operator', label: this.$t('analytics.drilling.tab.operator') }
        ],
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.drilling.infoFields.blasts'), icon: 'blasts' },
          { key: 'noOfHoles', label: this.$t('analytics.drilling.infoFields.noOfHoles'), icon: 'noOfHole' },
          { key: 'blastsVolume', label: this.$t('analytics.drilling.infoFields.blastsVolume'), icon: 'volume' },
          { key: 'accuracy', label: this.$t('analytics.drilling.infoFields.accuracy'), icon: 'accuracy' },
          { key: 'cost', label: this.$t('analytics.drilling.infoFields.cost', [utils.getUserInformation().selectedUserSite.currencyName]), icon: 'cost' }
        ]
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/drilling`
    }
  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        accuracy: this.intervalType[this.option.activeTab]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/drill-meter`, 
          `${this.moduleName}/accuracy-depth`, 
          `${this.moduleName}/accuracy-horizontal`
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        // console.log('res',res)
        this.items.info = res[0].content
        this.items.drillMeter = res[1].content || []
        this.items.depthAccuracy = res[2].content || []
        this.items.collarAccuracy = res[3].content || []
      }, req)
      await this.searchDetail(this.search)

      this.$nextTick(() => {
        this.searchEnd = JSON.parse(JSON.stringify(this.search))
      })
    },
    async searchDetail (search) {
      let param = {
        ...search,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        target: this.option.activeTab.toUpperCase(),
        accuracy: this.intervalType[this.option.activeTab]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/drill-meter`, 
          `${this.moduleName}/accuracy-depth`, 
          `${this.moduleName}/accuracy-horizontal`
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        this.items.subDrillMeter = res[0].content || []
        this.items.subDepthAccuracy = res[1].content || []
        this.items.subCollarAccuracy = res[2].content || []
      }, req)
    },
    async updateTab () {
      await this.searchDetail(this.searchEnd)
    },
    async changeStandrd (target) {
      this._moduleName = `${this.moduleName}/accuracy-depth`
      this.params = {
        ...this.searchEnd,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        target: target.toUpperCase(),
        accuracy: this.intervalType[target]
      }
      delete this.params.date
      this.requestApiAsync((res)=>{
        if (target === 'all') {
          this.items.depthAccuracy = res.content || []
        } else {
          this.items.subDepthAccuracy = res.content || []
        }
      })
    }
  }
}
</script>