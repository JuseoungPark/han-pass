<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow>
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none">
              <div class="d-flex align-items-center justify-content-end mb-2">
                <h3 class="title text-right d-inline-block mb-0 mr-3">{{ $t("analytics.frag.title") }}</h3>
                <CButton
                  type="submit"
                  class="btn-custom-default outline hanwha"
                  @click="searchData">
                  {{ $t("commonLabel.apply") }}
                </CButton>
              </div>
              <CRow>
                <CCol lg="4">
                  <CCol class="px-0">
                    <CSelect
                      :label="$t('analytics.common.analyzing')"
                      :value.sync="search.fragmentationType"
                      :options="codes.frags"
                      class="mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="lg-mt-s d-flex align-items-center">
                  <CCol class="px-0">
                    <CSelect
                      :value.sync="search.periodType"
                      :options="codes.dates"
                      @update:value="search.date = []"
                      class="responsive-right-sort mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="flex-center-layout lg-mt-s">
                  <div class="flex-1 form-row align-items-center">
                    <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                    <CDatePicker
                      :dateForm.sync="search.date"
                      class="col-sm-9"
                      :type="codes.dateType[search.periodType]"
                      :range="true"
                      :clearable="false"
                      :editable="false"
                      :maxDate="maxDate"
                      valueType="YYYY-MM-DD"
                      format="YYYY-MM-DD"
                      :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                  </div>
                </CCol>
              </CRow>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol>
          <CRow>
            <CCol xs="12" md="4">
              <CCard class="mb-0">
                <CCardHeader>
                  <strong>{{ $t("analytics.frag.blast") }}</strong>
                </CCardHeader>
                <CCardBody>
                  <dateBubbleChart :item="items.blast" :search="search" @setLoading="setLoading"/>
                </CCardBody>
              </CCard>
            </CCol>
            <CCol xs="12" md="4">
              <CCard class="mb-0 lg-mt-2">
                <CCardHeader>
                  <strong>{{ $t("analytics.frag.pf") }}</strong>
                </CCardHeader>
                <CCardBody>
                  <positionBubbleChart :item="pfChartData" :search="search"
                    :xyCode="{x: 'powderFactor', y: 'fragmentation'}"
                    :chartStyle="{height: '300px'}" @setLoading="setLoading"/>
                </CCardBody>
              </CCard>
            </CCol>
            <CCol xs="12" md="4">
              <CCard class="mb-0 lg-mt-2">
                <CCardHeader>
                  <strong>{{ $t("analytics.frag.avg") }}</strong>
                </CCardHeader>
                <CCardBody>
                  <positionBubbleChart :item="reliefChartData" :search="search"
                    :xyCode="{x: 'relief', y: 'fragmentation'}"
                    :chartStyle="{height: '300px'}" @setLoading="setLoading"/>
                </CCardBody>
              </CCard>
            </CCol>
          </CRow>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Fragmentation",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    dateBubbleChart: () => import(/* webpackChunkName: "FragmentationCharts" */ "@/views/analytics/component/chart/dateBubbleChart"),
    positionBubbleChart: () => import(/* webpackChunkName: "FragmentationCharts" */ "@/views/analytics/component/chart/positionBubbleChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      visible: {
        fullLoading: false
      },
      fragTypeTit:'D20',
      search: {
        fragmentationType: 'D20',
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'days').format('YYYY-MM-DD')
        ]
      },
      items: {
        info: {},
        blast: [],
        pf: [],
        relief: []
      }
    }
  },
  computed: {
    codes () {
      return {
        frags: ["D20", "D50", "D80"],
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.frag.infoFields.blasts'), icon: 'blasts' },
          { key: 'targetAverage', label: this.$t('analytics.frag.infoFields.target', [this.fragTypeTit]), icon: 'targetAvg' },
          { key: 'average', label: this.$t('analytics.frag.infoFields.actual', [this.fragTypeTit]), icon: 'avg' },
          // { key: 'average', label: this.$t('analytics.frag.infoFields.average'), icon: 'avg' },
          { key: 'pfAverage', label: this.$t('analytics.frag.infoFields.pfAverage'), icon: 'avgPf' },
          { key: 'reliefAverage', label: this.$t('analytics.frag.infoFields.reliefAverage'), icon: 'avgRelief' }
        ],
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/fragmentation`
    },
    pfChartData () {
      if (this.items.pf.length) {
        return [
          {
            name: 'Blast',
            data: this.items.pf
          }
        ]
      }
      return []
    },
    reliefChartData () {
      if (this.items.relief.length) {
        return [
          {
            name: 'Blast',
            data: this.items.relief
          }
        ]
      }
      return []
    }
  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/blast-fragmentation`, 
          `${this.moduleName}/pf-fragmentation`, 
          `${this.moduleName}/relief-fragmentation`
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        this.items.info = res[0].content
        this.items.blast = res[1].content || []
        this.items.pf = res[2].content || []
        this.items.relief = res[3].content || []
        this.fragTypeTit = this.search.fragmentationType
      }, req)      
    }
  }
}
</script>