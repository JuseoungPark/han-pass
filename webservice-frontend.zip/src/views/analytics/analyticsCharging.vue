<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow>
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none d-flex align-items-center justify-content-end">
              <CCol lg="4" class="title-wrap">
                <h3 class="title mb-0">{{ $t("analytics.charg.title") }}</h3>
              </CCol>
              <CCol lg="4" class="lg-mt">
                <CSelect
                  :label="$t('analytics.common.analyzing')"
                  :value.sync="search.periodType"
                  :options="codes.dates"
                  @update:value="search.date = []"
                  class="mb-0 align-items-center"
                  horizontal />
              </CCol>
              <CCol lg="4">
                <div class="form-row align-items-center">
                  <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                  <CDatePicker
                    :dateForm.sync="search.date"
                    class="col-sm-9"
                    :type="codes.dateType[search.periodType]"
                    :range="true"
                    :clearable="false"
                    :editable="false"
                    :maxDate="maxDate"
                    valueType="YYYY-MM-DD"
                    format="YYYY-MM-DD"
                    :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                </div>
              </CCol>
              <CButton
                type="submit"
                class="btn-custom-default hanwha outline lg-mt-s mr-3"
                @click="searchData">
                {{ $t("commonLabel.apply") }}
              </CButton>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol>
          <CRow>
            <CCol xs="12" md="6">
              <CCard>
                <CCardHeader>
                  <strong>{{ $t("analytics.charg.chargeWeight") }}</strong>
                  <small><code>(kg)</code></small>
                </CCardHeader>
                <CCardBody>
                  <dateColumnChart :item="items.weight" :search="search" @setLoading="setLoading"/>
                </CCardBody>
              </CCard>
            </CCol>
            <CCol xs="12" md="6">
              <CCard>
                <CCardHeader class="position-relative">
                  <div class="row">
                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                      <div>
                        <strong class="text-nowrap">{{$t("analytics.drilling.accuracy")}}</strong>
                        <small class="text-nowrap ml-1"><code>({{$t("analytics.drilling.errorDistribution")}})</code></small>
                      </div>
                      <span class="text-right">
                        <CSelect
                          class="position-right-center right-1"
                          style="width: 80px"
                          :value.sync="intervalType.all"
                          :options="codes.intervals"
                          @change="changeStandrd('all')" />
                      </span>
                    </div>
                  </div>
                </CCardHeader>
                <CCardBody>
                  <categoryColumnChart :item="items.accuracy"  :search="search"
                    category="accuracy" :guide="intervalType.all" @setLoading="setLoading"/>
                </CCardBody>
              </CCard>
            </CCol>
          </CRow>
        </CCol>
        <CCol lg="12">
          <CTabLayer
            :tabs="codes.tabs"
            :activeTab.sync="option.activeTab"
            @updateTab="updateTab">
            <template slot-scope="props">
              <CRow class="mt-20">
                <CCol xs="12" md="6">
                  <CCard class="mb-0">
                    <CCardHeader>
                      <strong>{{ $t("analytics.charg.chargeWeight") }}</strong>
                      <small><code>(kg)</code></small>
                    </CCardHeader>
                    <CCardBody>
                      <dateColumnChart :item="items.subWeight" :search="search" :isStacked="true" @setLoading="setLoading"/>
                    </CCardBody>
                  </CCard>
                </CCol>
                <CCol xs="12" md="6">
                  <CCard class="mb-0 lg-mt-2">
                    <CCardHeader class="position-relative">
                      <div class="row">
                        <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                          <div>
                            <strong class="text-nowrap">{{$t("analytics.drilling.accuracy")}}</strong>
                            <small class="text-nowrap ml-1"><code>({{$t("analytics.drilling.errorDistribution")}})</code></small>
                          </div>
                          <span class="text-right">
                            <CSelect
                              class="position-right-center right-1"
                              style="width: 80px"
                              :value.sync="intervalType[props.item]"
                              :options="codes.intervals"
                              @change="changeStandrd(props.item)" />
                          </span>
                        </div>
                      </div>
                    </CCardHeader>
                    <CCardBody>
                      <categoryColumnChart :item="items.subAccuracy" :search="search"
                        category="accuracy"
                        :isStacked="true"
                        :guide="intervalType[props.item]" @setLoading="setLoading"/>
                    </CCardBody>
                  </CCard>
                </CCol>
              </CRow>
            </template>
          </CTabLayer>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import CTabLayer from '@/components/form/CTabLayer'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "Charging",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    CTabLayer,
    dateColumnChart: () => import(/* webpackChunkName: "ChargingCharts" */ "@/views/analytics/component/chart/dateColumnChart"),
    categoryColumnChart: () => import(/* webpackChunkName: "ChargingCharts" */ "@/views/analytics/component/chart/categoryColumnChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      option: {
        activeTab: 'pit'
      },
      visible: {
        fullLoading: false
      },
      
      intervalType: {
        all: '0.1',
        pit: '0.1',
        unit: '0.1',
        operator: '0.1'
      },
      search: {
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ]
      },
      searchEnd: {},
      items: {
        info: {},
        weight: [],
        accuracy: [],
        subWeight: [],
        subAccuracy: []
      }
    }
  },
  computed: {
    codes() {
      return {
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        intervals: [
          { value: '0.1', label: '0.1 m' },
          { value: '0.2', label: '0.2 m' },
          { value: '0.5', label: '0.5 m' },
          { value: '1.0', label: '1.0 m' },
          { value: '2.0', label: '2.0 m' },
          { value: '5.0', label: '5.0 m' }
        ],
        tabs: [
          { key: 'pit', label: this.$t('analytics.charg.tab.pit') },
          { key: 'unit', label: this.$t('analytics.charg.tab.unit') },
          { key: 'operator', label: this.$t('analytics.charg.tab.operator') }
        ],
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.charg.infoFields.blasts'), icon: 'blasts' },
          { key: 'noOfHoles', label: this.$t('analytics.charg.infoFields.noOfHoles'), icon: 'noOfHole' },
          { key: 'chargeWeight', label: this.$t('analytics.charg.infoFields.chargeWeight'), icon: 'weight' },
          { key: 'chargeAccuracy', label: this.$t('analytics.charg.infoFields.chargeAccuracy'), icon: 'chargeAccuracy' },
          { key: 'revenue', label: `${this.$t('analytics.charg.infoFields.revenue')} (${this.userSite.currencyName})`, icon: 'revenue' }
        ]
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/charging`
    },

  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        target: 'ALL',
        accuracy: this.intervalType.all
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/charge-weight`, 
          `${this.moduleName}/accuracy`, 
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        this.items.info = res[0].content
        this.items.weight = res[1].content || []
        this.items.accuracy = res[2].content || []
      }, req)

      await this.searchDetail(this.search)

      this.$nextTick(() => {
        this.searchEnd = JSON.parse(JSON.stringify(this.search))
        this.visible.fullLoading = false
      })
    },
    async searchDetail (search) {
      let param = {
        ...search,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        target: this.option.activeTab.toUpperCase(),
        accuracy: this.intervalType[this.option.activeTab]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/charge-weight`, 
          `${this.moduleName}/accuracy`, 
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        this.items.subWeight = res[0].content || []
        this.items.subAccuracy = res[1].content || []
      }, req)
    },
    async updateTab () {
      await this.searchDetail(this.searchEnd)
    },
    async changeStandrd (target) {
      this._moduleName = `${this.moduleName}/accuracy`
      this.params = {
        ...this.searchEnd,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
        target: target.toUpperCase(),
        accuracy: this.intervalType[target]
      }
      delete this.params.date
      this.requestApiAsync((res)=>{
        if (target === 'all') {
          this.items.accuracy = res.content || []
        } else {
          this.items.subAccuracy = res.content || []
        }
      })
    }
  }
}
</script>