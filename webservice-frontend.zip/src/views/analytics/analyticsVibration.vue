<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow id="printPage">
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none">
              <div class="d-flex align-items-center justify-content-end mb-2">
                <h3 class="title text-right d-inline-block mb-0 mr-3">{{ $t("analytics.vibration.title") }}</h3>
                <CButton
                  type="submit"
                  class="btn-custom-default hanwha outline"
                  @click="searchData">
                  {{ $t("commonLabel.apply") }}
                </CButton>
              </div>
              <CRow>
                <CCol lg="4">
                  <CCol class="px-0">
                    <CSelect
                      :value.sync="search.vibrationType"
                      :options="codes.vibrations"
                      :label="$t('analytics.common.analyzing')"
                      class="mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="lg-mt-s d-flex align-items-center">
                  <CCol class="px-0">
                    <CSelect
                      :value.sync="search.periodType"
                      :options="codes.dates"
                      @update:value="search.date = []"
                      class="responsive-right-sort mb-0 align-items-center"
                      horizontal />
                  </CCol>
                </CCol>
                <CCol lg="4" class="flex-center-layout lg-mt-s">
                  <div class="flex-1 form-row align-items-center">
                    <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                    <CDatePicker
                      :dateForm.sync="search.date"
                      class="col-sm-9"
                      :type="codes.dateType[search.periodType]"
                      :range="true"
                      :clearable="false"
                      :editable="false"
                      :maxDate="maxDate"
                      valueType="YYYY-MM-DD"
                      format="YYYY-MM-DD"
                      :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                  </div>
                </CCol>
              </CRow>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol>
          <CCard>
            <CCardBody class="line-none">
              <CRow>
                <CCol lg="6">
                  <CCard class="mb-0">
                    <AnalyticsGmap
                      ref="gMap"
                      class="position-relative radius025"
                      :id="vibration.id"
                      :item="items.base"
                      :blasts="items.blasts"
                      @clickMarker="clickMarker" />
                  </CCard>
                </CCol>
                <CCol lg="6" class="lg-mt">
                  <CTabLayer
                    v-if="items.base.length"
                    :tabs="items.base"
                    :tabOption="{key: 'id',label: 'name'}"
                    :activeTab="option.activeTab"
                    @updateTab="updateTab">
                    <div>
                      <ul class="list-unstyled half-layout align-items-stretch my-2 bg-light-gary">
                        <li>
                          <span class="list-tit">{{$t("analytics.vibration.monitoring.pointName")}} : </span> {{ vibration.geophoneName }}
                        </li>
                        <li>
                          <span class="list-tit">{{ $t("analytics.vibration.monitoring.type") }} : </span> {{ vibration.monitoringPointName }}
                        </li>
                        <li>
                          <span class="list-tit">{{$t("analytics.vibration.monitoring.model")}} : </span> {{ vibration.modelName }}
                        </li>
                        <li>
                          <span class="list-tit">{{$t("analytics.vibration.monitoring.serial")}} : </span> {{ vibration.serialNo }}
                        </li>
                        <li>
                          <span class="list-tit">{{ $t("analytics.vibration.monitoring.rate") }} : </span> {{ vibration.samplingRate }}
                        </li>
                        <li>
                          <span class="list-tit">{{$t("analytics.vibration.monitoring.level")}} : </span> {{ vibration.triggerLevel }}
                        </li>
                        <li>
                          <span class="list-tit">{{ $t("analytics.vibration.monitoring.pvs") }} : </span> {{ vibration.pvsValue }}
                        </li>
                        <li>
                          <span class="list-tit">{{ $t("analytics.vibration.monitoring.ppv") }} : </span> {{ vibration.ppvValue }}
                        </li>
                      </ul>
                      <div class="table-max-height300">
                        <DataTable :items="items.blasts" :fields="fields"
                          :striped="false" :isNoItemClick="false" :clickableRows="false"
                          :columnFilter="false" :sorter="false" :tableFilter="false">
                          <template slot="theadTop">
                            <tr>
                              <th scope="col" colspan="4">{{ $t("analytics.vibration.blast.no") }} : <span class="num">{{items.blasts.length}}</span></th>
                            </tr>
                          </template>
                        </DataTable>
                      </div>
                    </div>
                    <CTabs variant="pills" class="lg-mt position-relative"
                      :activeTab.sync="option.activeSubTab">
                      <CTab :title="$t('analytics.vibration.tab.blast.title')" sm="3">
                        <CRow class="mt-20">
                          <CCol>
                            <CCard class="mb-0">
                              <CCardHeader>
                                <strong>{{$t("analytics.vibration.tab.blast.sub")}}</strong>
                              </CCardHeader>
                              <CCardBody>
                                <dateLineChart :item="items.blastStatistics" :search="search" :chartStyle="{height:'350px'}" @setLoading="setLoading"/>
                              </CCardBody>
                            </CCard>
                          </CCol>
                        </CRow>
                      </CTab>
                      <CTab v-show="searchEnd.vibrationType !== 'Sound'" :title="$t('analytics.vibration.tab.statistics.title')" sm="3">
                        <CRow class="mt-20">
                          <CCol>
                            <CCard class="mb-0">
                              <CCardHeader>
                                <strong>{{$t("analytics.vibration.tab.statistics.sub")}}</strong>
                              </CCardHeader>
                              <CCardBody>
                                <positionBubbleChart :item="icChartData" :search="search"
                                  :guide="vibration.target"
                                  :xyCode="{x: 'mic', y: 'value'}"
                                  :chartStyle="{height: '350px'}" @setLoading="setLoading"/>
                              </CCardBody>
                            </CCard>
                          </CCol>
                        </CRow>
                      </CTab>
                      <CTab v-show="searchEnd.vibrationType !== 'Sound'" :title="$t('analytics.vibration.tab.relief.title')" sm="3">
                        <CRow class="mt-20">
                          <CCol>
                            <CCard class="mb-0">
                              <CCardHeader>
                                <strong>{{$t("analytics.vibration.tab.relief.sub")}}</strong>
                              </CCardHeader>
                              <CCardBody>
                                <positionBubbleChart :item="reliefChartData" :search="search"
                                  :guide="vibration.target"
                                  :xyCode="{x: 'reliefValue', y: 'value'}"
                                  :chartStyle="{height: '350px'}" @setLoading="setLoading"/>
                              </CCardBody>
                            </CCard>
                          </CCol>
                        </CRow>
                      </CTab>
                      <CTab v-show="searchEnd.vibrationType !== 'Sound'" :title="$t('analytics.vibration.tab.attenuation.title')" sm="3">
                        <CRow class="mt-20">
                          <CCol>
                            <CCard class="mb-0">
                              <CCardHeader>
                                <strong>{{$t("analytics.vibration.tab.attenuation.sub")}}</strong>
                              </CCardHeader>
                              <CCardBody>
                                <trendLineChart :item="items.attenuationLaw" :search="search" @setLoading="setLoading"/>
                              </CCardBody>
                            </CCard>
                          </CCol>
                        </CRow>
                      </CTab>
                    </CTabs>
                  </CTabLayer>
                  <div v-else>{{ $t("message.noData") }}</div>
                </CCol>
              </CRow>
            </CCardBody>
          </CCard>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import DataTable from '@/components/table/DataTable'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import CTabLayer from '@/components/form/CTabLayer'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'
import { parse } from '@babel/core'

export default {
  name: "Vibration",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    DataTable,
    CTabLayer,
    AnalyticsGmap: () => import(/* webpackChunkName: "VibrationCharts" */ "@/views/analytics/component/analyticsVibrationGmap"),
    dateLineChart: () => import(/* webpackChunkName: "VibrationCharts" */ "@/views/analytics/component/chart/dateLineChart"),
    positionBubbleChart: () => import(/* webpackChunkName: "VibrationCharts" */ "@/views/analytics/component/chart/positionBubbleChart"),
    trendLineChart: () => import(/* webpackChunkName: "VibrationCharts" */ "@/views/analytics/component/chart/trendLineChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      option : {
        activeTab: null,
        activeSubTab: 0,
      },
      visible: {
        fullLoading: false
      },
      search: {
        vibrationType: 'PVS',
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ]
      },
      searchEnd: {},
      items: {
        info: {},
        base: [],
        blasts: [],
        blastStatistics: [],
        icStatistics: [],
        reliefStatistics: [],
        attenuationLaw: []
      }
    }
  },
  computed: {
    codes () {
      return {
        vibrations: ['PVS', 'PPV-L', 'PPV-T', 'PPV-V', 'Sound'],
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.vibration.infoFields.blasts'), icon: 'blasts' },
          { key: 'target', label: this.$t('analytics.vibration.infoFields.target'), icon: 'targetAvg' },
          { key: 'average', label: this.$t('analytics.vibration.infoFields.average'), icon: 'avg' },
          { key: 'icAverage', label: this.$t('analytics.vibration.infoFields.icAverage'), icon: 'avgInstantaneous' },
          { key: 'reliefAverage', label: this.$t('analytics.vibration.infoFields.reliefAverage'), icon: 'avgRelief' }
        ]
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
      return `v1/analytics/${this.userSite.siteId}/vibration`
    },
    vibration () {
      if (this.items.base.length) {
        return this.items.base.find(s => s.id === this.option.activeTab) || {}
      }
      return {}
    },
    fields () {
      return [
        {key:'blastName', label:this.$t('analytics.vibration.blast.name')},
        {key:'distance', label:`${this.$t('analytics.vibration.blast.distance')} (m)`, template: 'decimal'},
        {key:'firedTime', label:this.$t('analytics.vibration.blast.firedTime'), template: 'date', dateFormat: 'YYYY-MM-DD hh:mm:ss'},
        {key:'vibration', label:this.searchEnd.vibrationType || ''}
      ]
    },
    icChartData () {
      if (this.items.icStatistics.length) {
        return [
          {
            name: 'MIC',
            data: this.items.icStatistics
          }
        ]
      }
      return []
    },
    reliefChartData () {
      if (this.items.reliefStatistics.length) {
        return [
          {
            name: 'Relief',
            data: this.items.reliefStatistics
          }
        ]
      }
      return []
    }
  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1]
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/geophone-info`
        ],
        params: param
      }
      let res = await this.requestApiMutiSync(req)
      this.items.info = res[0].content
      this.items.base = res[1].content || []
      if (this.items.base.length) {
        this.option.activeTab = this.items.base[0].id || null
        await this.searchDetail(this.search)
      } else {
        this.items.blasts = []
        this.items.blastStatistics = []
        this.items.icStatistics = []
        this.items.reliefStatistics = []
        this.items.attenuationLaw = []
      }

      this.$nextTick(() => {
        this.searchEnd = JSON.parse(JSON.stringify(this.search))
      })
    },
    async searchDetail (search) {
      if (this.vibration.id) {
        let param = {
          ...search,
          startDate: this.search.date[0],
          endDate: this.search.date[1],
          geophoneId: this.vibration.id
        }
        delete param.date        
        let req = {
          modules: [
            `${this.moduleName}/blast-list`, 
            `${this.moduleName}/blast-statistics`
          ],
          params: param
        }
        if (search.vibrationType !== 'Sound'){
          req.modules = req.modules.concat([
            `${this.moduleName}/ic-statistics`,
            `${this.moduleName}/relief-statistics`,
            `${this.moduleName}/attenuation-law`
          ])
        }else{
          this.option.activeSubTab = 0
        } 
        this.requestApiMutiAsync((res) => {
          this.items.blasts = res[0].content || []
          this.items.blastStatistics = res[1].content || []
          if (search.vibrationType !== 'Sound'){
            this.items.icStatistics = res[2].content || []
            this.items.reliefStatistics = res[3].content || []
            this.items.attenuationLaw = res[4].content || []
          }
        }, req)

      }
    },
    clickMarker (item) {
      if (this.option.activeTab !== item.id) {
        this.updateTab(item, false)
      }
    },
    async updateTab (item, mapMove = true) {
      this.option.activeTab = item.id
      await this.searchDetail(this.searchEnd)
      if (mapMove) this.$refs.gMap.movePosition(this.vibration)
    }
  }
}
</script>
<style lang="scss">
.gmap {
  &.analytics-vib{
    height: 979px;
  }
}
@media screen and (max-width: 991px) {
  .gmap {
    &.analytics-vib{
      height: 400px;
    }
  }
}
.list-tit{
    font-weight: 700;
}
</style>