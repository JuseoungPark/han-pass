<template>
  <CCard>
    <CCardBody class="line-none">
      <CRow>
        <CCol>
          <CCard class="header-card">
            <CCardBody class="blasts-select-wrap line-none d-flex align-items-center justify-content-end">
              <CCol lg="4" class="title-wrap">
                <h3 class="title mb-0">{{ $t("analytics.cost.title") }}</h3>
              </CCol>
              <CCol lg="4" class="lg-mt">
                <CSelect
                  :label="$t('analytics.common.analyzing')"
                  :value.sync="search.periodType"
                  :options="codes.dates"
                  @update:value="search.date = []"
                  class="mb-0 align-items-center"
                  horizontal />
              </CCol>
              <CCol lg="4">
                <div class="form-row align-items-center">
                  <span class="col-form-label col-sm-3">{{$t("analytics.common.datePeriod")}}</span>
                  <CDatePicker
                    :dateForm.sync="search.date"
                    class="col-sm-9"
                    :type="codes.dateType[search.periodType]"
                    :range="true"
                    :clearable="false"
                    :editable="false"
                    :maxDate="maxDate"
                    valueType="YYYY-MM-DD"
                    format="YYYY-MM-DD"
                    :placeholder="$t('message.selectMessage', [$t(`analytics.common.search${search.periodType}`)])" />
                </div>
              </CCol>
              <CButton
                type="submit"
                class="btn-custom-default hanwha outline lg-mt-s mr-3"
                @click="searchData">
                {{ $t("commonLabel.apply") }}
              </CButton>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol lg="12" class="mb-4">
          <AnalyticsDataInfo :fields="codes.infoFields" :info="items.info" />
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.cost.productivity") }}</strong>
              <small class="ml-2">{{$t("analytics.cost.productivitySub")}}</small>
            </CCardHeader>
            <CCardBody>
              <complexChart :item="items.productivity" :search="search" seriesType="volumeCost" @setLoading="setLoading"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.cost.blastVolume") }}</strong>
            </CCardHeader>
            <CCardBody>
              <dateColumnChart :item="items.blastVolume" :search="search" :axisOption="axisOption" :isStacked="true" @setLoading="setLoading"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol xs="12" lg="12">
          <CCard>
            <CCardHeader>
              <strong>{{ $t("analytics.cost.blastCost") }}</strong>
            </CCardHeader>
            <CCardBody>
              <dateLineChart :item="items.blastCost" :search="search" :isStacked="true" @setLoading="setLoading"/>
            </CCardBody>
          </CCard>
        </CCol>
        <CThemaCover v-if="visible.fullLoading" :customeStyle="{ 'z-index': 10, position: 'fixed' }" />
      </CRow>
    </CCardBody>
  </CCard>
</template>

<script>
import CThemaCover from '@/components/form/CThemaCover'
import AnalyticsDataInfo from "@/views/analytics/component/AnalyticsDataInfo"
import CDatePicker from '@/components/form/CDatePicker'
import utils from '@/assets/js/utils'
import apiMixin from '@/assets/js/apiMixin'

export default {
  name: "AnalyticsCost",
  components: {
    CThemaCover,
    AnalyticsDataInfo,
    CDatePicker,
    complexChart: () => import(/* webpackChunkName: "CostCharts" */ "@/views/analytics/component/chart/complexChart"),
    dateColumnChart: () => import(/* webpackChunkName: "CostCharts" */ "@/views/analytics/component/chart/dateColumnChart"),
    dateLineChart: () => import(/* webpackChunkName: "CostCharts" */ "@/views/analytics/component/chart/dateLineChart")
  },
  mixins: [apiMixin],
  data() {
    return {
      visible: {
        fullLoading: false
      },
      search: {
        periodType: 'Daily',
        date: [
          this.$moment().subtract(1, 'months').format('YYYY-MM-DD'),
          this.$moment().subtract(1, 'day').format('YYYY-MM-DD')
        ]
      },
      items: {
        info: {},
        productivity: [],
        blastVolume: [],
        blastCost: []
      },
      axisOption:{
        x: {
          minGridDistance: 30,
          min: undefined,
          max: undefined
        },
        leftY: {
          minGridDistance: 40,
          min: undefined,
          max: undefined
        }
      }
    }
  },
  computed: {
    codes () {
      return {
        dates: ['Daily', 'Weekly', 'Monthly'],
        dateType: {'Daily': 'date', 'Weekly': 'week', 'Monthly': 'month'},
        infoFields: [
          { key: 'blasts', label: this.$t('analytics.cost.infoFields.blasts'), icon: 'blasts' },
          { key: 'noOfHoles', label: this.$t('analytics.cost.infoFields.noOfHoles'), icon: 'noOfHole' },
          { key: 'blastsVolume', label: this.$t('analytics.cost.infoFields.blastsVolume'), icon: 'volume' },
          { key: 'drillMeter', label: this.$t('analytics.cost.infoFields.drillMeter'), icon: 'meter' },
          { key: 'cost', label: this.$t('analytics.cost.infoFields.cost'), icon: 'cost' }
        ]
      }
    },
    userSite () {
      return utils.getUserInformation().selectedUserSite
    },
    moduleName () {
       return `v1/analytics/${this.userSite.siteId}/cost`
    },

  },
  async mounted() {
    await this.searchData()
  },
  methods: {
    async searchData () {
      if(!this.dateVaildChk()) return false
      if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크

      let param = {
        ...this.search,
        startDate: this.search.date[0],
        endDate: this.search.date[1],
      }
      delete param.date
      let req = {
        modules: [
          `${this.moduleName}/summary`, 
          `${this.moduleName}/productivity`, 
          `${this.moduleName}/blast-volume`, 
          `${this.moduleName}/blast-cost`
        ],
        params: param
      }
      this.requestApiMutiAsync((res) => {
        this.items.info = res[0].content
        this.items.productivity = res[1].content || []
        this.items.blastVolume = res[2].content || []
        this.items.blastCost = res[3].content || []
      }, req)    
    }
  }
}
</script>