<template>
  <div class="gmap-dashboard-wrap home">
    <CCard class="mb-0">
      <CCardBody>
        <div class="gmap-dashboard position-relative radius025 tooltip-style-wrap">
          <GmapMap
            ref="mapRef"
            :center="center"
            :zoom="zoom"
            :options=options
            style="height: 70vh"
          >
            <!-- @center_changed="updateCenter" -->
            <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false">
              <div class="map-tooltip-typeC">
                <div class="map-tooltip-contents">
                  <div class="contents">
                    <div class="map-tooltip-header">
                      <span class="title"><CLink @click="updateSiteInfo(infoOptions.siteId)">{{ infoOptions.siteName }} &#160; </CLink></span>
                      <CLink @click="updateSiteInfo(infoOptions.siteId, !newTab)" target="_blank">
                        <app-icon name="link" size="s" fill />
                      </CLink>
                    </div>
                    <ul class="map-tooltip-list list-unstyled mb-0">
                      <li>
                        <app-icon name="locationPoint" size="s" fill class="color-hanwha" />
                        <span class="text-wrap-location">
                          <span class="color-hanwha">{{ infoOptions.address }}</span>
                          (
                            <span>{{ infoOptions.lat }}</span>,
                            <span>{{ infoOptions.lng }}</span>
                          )
                        </span>
                      </li>
                      <li>
                        <app-icon name="mine" size="s" fill />
                        <span class="text-wrap-location">
                          <span>{{ infoOptions.mineType }}</span>
                        </span>
                      </li>
                      <li>
                        <app-icon name="building" size="s" fill />
                        <span class="text-wrap-location">
                          <span>{{ infoOptions.company }}</span>
                        </span>
                      </li>
                      <li>
                        <app-icon name="people" size="s" fill />
                        <span class="text-wrap-location">
                          <span>{{ infoOptions.siteManager }}</span>
                        </span>
                      </li>
                      <li>
                        <app-icon name="calendar" size="s" fill />
                        <span class="text-wrap-location">
                          <span>{{ infoOptions.siteDate }}</span>
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </GmapInfoWindow>
            <GmapMarker
              :key="index"
              v-for="(m, index) in markers"
              :position="m.position"
              :label="m.label"
              :clickable="true"
              :draggable="m.draggable"
              :icon="{ url: 'img/gmap/marker.png' }"
              @mouseover="InfoWindowOver(m, index)"
            />
          </GmapMap>
          <!-- mini map -->
          <div ref="miniMap" class="mini-map" @click="changeMapType">
            <GmapMap
              :center="center"
              :zoom="0"
              :options=miniMapOptions
              style="height: 100%"
            >
            </GmapMap>
          </div>
          <div class="dropdown-pack-wrap">
                <div class="dropdown-pack-inner">
                  <!-- S : Site List -->
                  <div class="site-list-wrap position-absolute dropdown-00" tabindex="0" @blur="blurSiteList">
                    <div class="site-list-select form-control" :class="{ on : isSelectList }"  @click="selectSiteList">
                      <strong>Site List</strong>
                    </div>
                    <ul class="site-list pl-0 mb-0" :class="{ on : isSelectList }">
                      <VuePerfectScrollbar class="scroll-area list-unstyled" :settings="settings">
                      <li
                        class="home-list d-flex align-items-start"
                        :class="{ active : currentNumb == idx }"
                        v-for="(list, idx) in siteList"
                        :key="idx"
                        @click="siteLocation(list, idx)"
                      >
                        <div class="img-wrap">
                          <CImg :src="`${list.image}`"
                            block
                            class="image img-wrap-image"
                          />
                        </div>
                        <div class="text-wrap">
                          <span class="text-wrap-name">{{ list.siteName }}</span>
                          <ul class="list-unstyled">
                            <li>
                              <app-icon name="locationPoint" size="s" fill class="color-hanwha" />
                              <span class="text-wrap-location">
                                <span class="color-hanwha">{{ list.address }}</span>
                                (
                                  <span> {{ list.lat }}</span>,
                                  <span> {{ list.lng }}</span>
                                )
                              </span>
                            </li>
                            <li>
                              <app-icon name="mine" size="s" fill />
                              <span class="text-wrap-location">
                                <span> {{ list.mineType }}</span>
                              </span>
                            </li>
                            <li>
                              <app-icon name="building" size="s" fill />
                              <span class="text-wrap-location">
                                <span> {{ list.company }}</span>
                              </span>
                            </li>
                            <li>
                              <app-icon name="people" size="s" fill />
                              <span class="text-wrap-location">
                                <span> {{ list.siteManager }}</span>
                              </span>
                            </li>
                            <li>
                              <app-icon name="calendar" size="s" fill />
                              <span class="text-wrap-location">
                                <span> {{ list.siteDate }}</span>
                              </span>
                            </li>
                          </ul>
                        </div>
                      </li>
                      </VuePerfectScrollbar>
                    </ul>
                  </div>
                  <!-- E : Site List -->
                </div>
          </div>
        </div>
      </CCardBody>
    </CCard>
  </div>
</template>

<script>
import moment from 'moment'
import utils from '@/assets/js/utils'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import VuePerfectScrollbar from 'vue-perfect-scrollbar'

import { mapGetters, mapActions } from 'vuex'
const userInfo = 'loginLogout'

export default {
  name: 'HomeDashboard',
  components: {
    VuePerfectScrollbar,
    AppIcon
  },
  data () {
    return {
      newTab: false,
      settings: { // custom scroll
        maxScrollbarLength: 60
      },
      currentNumb: null,
      isSelectList: false, //site list selectbox status

      siteList: [],
      markers: [],

      // google map
      map: null,
      zoom: 2,
      center: {lat: -2.212600, lng: 115.524612},
      infoContent: '',
      infoLink: '',
      infoWindowPos: {
        lat: 0,
        lng: 0
      },
      infoWinOpen: false,
      currentMidx: null,
      options: {
        fullscreenControl: false,
        streetViewControl: false,
        rotateControl: false,
        scrollwheel: true,
        draggable: true,
        mapTypeControl: false,
        mapTypeId: "satellite",
        controlSize: 21,
        minZoom: 3,
        maxZoom: 23,
      },
      miniMapOptions: {
        fullscreenControl: false,
        streetViewControl: false,
        rotateControl: false,
        scrollwheel: false,
        mapTypeControl: false,
        draggable: false,
        zoomControl: false,
        // minZoom: 11,
        // maxZoom: 11,
        mapTypeId: "roadmap",
      },
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -32
        }
      },
      // google map
    }
  },
  computed: {
    ...mapGetters(userInfo, {
        userId: 'getUserId',
        userSite: 'getUserSite',
        selectedUserSite: 'getSelectedUserSite',
    }),
  },
  async created() {
    this.gmapInit()
  },
  async mounted() {
    // 맵에 대한 정보 획득 및 zoom 이벤트 주입
    this.$refs.mapRef.$mapPromise.then((map) => {
      this.map = map;
      google.maps.event.addListener(this.map, 'zoom_changed', () => {
        this.addMapZoomChanged()
      })
    })
  },
  methods: {
    ...mapActions(userInfo, {
        reSetUserInfo: 'reSetUserInfo',
        reSetSelectedPermissionList: 'reSetSelectedPermissionList',
        reSetSelectedSiteInfo: 'reSetSelectedSiteInfo',
        reSetSelectedMenuList: 'reSetSelectedMenuList',
        reSetUserData: 'reSetUserData',
    }),
    async gmapInit() {
      if (this.userId=='' || this.userId==null) {
        utils.showToastRed(this.$t('message.noLoginAuth'))
        this.$router.push({path:'/user/login'})
      }else{
        let that = this

        that.markers = []
        that.siteList = []

        if (this.userSite.length != 0) {
          for(let item of this.userSite) {
            let siteDate = moment(item.siteStartDateTime).format('YYYY-MM-DD HH:mm')

            that.markers.push({
              siteId: item.siteId,
              position: { lat: Number(item.latitudeValue), lng: Number(item.longitudeValue) },
              draggable: false,
              label: '',
              labelInfo: {
                siteId: item.siteId,
                siteName: item.siteName,
                address: item.address,
                lat: item.latitudeValue,
                lng: item.longitudeValue,
                mineType: item.mineTypeName,
                company: item.contracterName,
                siteManager: item.authorityName,
                siteDate: siteDate,
              }
            })

            let siteImage = 'img/no-image.jpg'
            if (item.sitemap != null) siteImage = item.sitemap

            that.siteList.push({
              //image: 'sample01',
              image: siteImage,
              siteId: item.siteId,
              siteName: item.siteName,
              address: item.address,
              lat: item.latitudeValue,
              lng: item.longitudeValue,
              mineType: item.mineTypeName,
              company: item.contracterName,
              siteManager: item.authorityName,
              siteDate: siteDate,
            })
          }
        }else{
          utils.showToastRed(this.$t('message.noSiteAdminAuth'))
          this.$router.push({path:'/sitedashboard'})
        }
      }
    },
    InfoWindowOver(marker) {
      this.infoWindowPos = marker.position
      this.infoOptions.siteId = marker.labelInfo.siteId
      this.infoOptions.siteName = marker.labelInfo.siteName
      this.infoOptions.address = marker.labelInfo.address
      this.infoOptions.lat = marker.labelInfo.lat
      this.infoOptions.lng = marker.labelInfo.lng
      this.infoOptions.mineType = marker.labelInfo.mineType
      this.infoOptions.company = marker.labelInfo.company
      this.infoOptions.siteManager = marker.labelInfo.siteManager
      this.infoOptions.siteDate = marker.labelInfo.siteDate

      this.infoWinOpen = true
      setTimeout(() => {
        this.infoWinOpen = false
      }, 10000); // 10초
    },
    updateCenter(newCenter) {
      // minimap과 전체map 위치 맞춤
console.log('center changed!!!')
      // console.log('center changed!!!', newCenter)

      // map drag slow 이슈 (소수점 값이너무많아 drag 느려짐)
      this.center = {
        lat: Number(newCenter.lat().toFixed(2)),
        lng: Number(newCenter.lng().toFixed(2))
      }
    },
    changeMapType() {
      // map type 변경
      console.log('map change!!', this.options.mapTypeId)

      this.options.mapTypeId === "satellite" ? this.options.mapTypeId = "roadmap" : this.options.mapTypeId = "satellite"
      this.miniMapOptions.mapTypeId === "roadmap" ? this.miniMapOptions.mapTypeId = 'satellite' : this.miniMapOptions.mapTypeId = 'roadmap'
    },
    siteLocation(list, idx) {
      let that = this

      let latitudeValue = Number(list.lat)
      let longitudeValue = Number(list.lng)

      this.zoom = 15
      this.center = { lat: latitudeValue, lng: longitudeValue }

      this.currentNumb = idx

      this.markers.forEach(function (el) {
        if (el.siteId == list.siteId) that.InfoWindowOver(el)
      })

    },
    updateSiteInfo(siteId, isNewWin) {
      let index = this.userSite.findIndex(y=>y.siteId == siteId)

      this.reSetSelectedMenuList(this.userSite[index].userMenuList)
      this.reSetSelectedPermissionList(this.userSite[index].userPermissionList)

      let selectedUserSite = {}
      selectedUserSite.id = index
      selectedUserSite.siteId = this.userSite[index].siteId
      selectedUserSite.siteName = this.userSite[index].siteName
      selectedUserSite.countryCodeName = this.userSite[index].countryCodeName
      selectedUserSite.currency = this.userSite[index].currency
      selectedUserSite.currencyName = this.userSite[index].currencyName

      selectedUserSite.userPermissionList = this.userSite[index].userPermissionList
      selectedUserSite.userMenuList = this.userSite[index].userMenuList
      //selectedUserSite.userMenuList = JSON.stringify(this.userSite[index].userMenuList)

      //선택된 데이터 별도 처리!!!
      this.reSetSelectedSiteInfo(selectedUserSite)
      this.reSetUserData(selectedUserSite)

      if( isNewWin ){
        // 새창 열림
        let route = this.$router.resolve({path:'/sitedashboard'})
  
        window.open(route.href, '_blank')
      }
      else{
        this.$router.push({path:'/sitedashboard'})
      }
    },
    selectSiteList() {
      this.isSelectList = !this.isSelectList
    },
    blurSiteList() {
      // list가 blur 되었을때 닫음
      if(this.isSelectList) this.isSelectList = !this.isSelectList
    },
    addMapZoomChanged() {
      // console.log('event.zoom_changed...')
    },
  }
}
</script>