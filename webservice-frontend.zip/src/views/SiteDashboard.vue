<template>
  <div>
    <CCard>
      <CCardBody class="line-none">
        <CRow id="printPage">
          <!-- spinner -->
          <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
              <div class="sk-wave-rect"></div>
              <div class="sk-wave-rect"></div>
              <div class="sk-wave-rect"></div>
              <div class="sk-wave-rect"></div>
              <div class="sk-wave-rect"></div>
            </div>
          </div>
          <CCol class="site-gmap layout-responsive site-dashboard tooltip-style-wrap">
            <div class="gmap-dashboard full-width position-relative radius025" @contextmenu="dfContextMenu($event)">
              <GmapMap
                ref="mapRef"
                class="gmap"
                :center="center"
                :zoom="zoom"
                :options=options
                style="height: 75vh"
                @click="hideContextMenu()"
                @rightclick="showContextMenu($event)"
              >
                <!-- @center_changed="updateCenter($refs.mapRef.$mapObject.getCenter())" -->
                <GmapInfoWindow :options="blastInfoOptions" :position="blastInfoWindowPos" :opened="blastInfoWinOpen" @closeclick="blastInfoWinOpen=false">
                  <div class="map-tooltip-typeA" :class="{active : blastInfoWinOpen}" @click="blastInfoListSelect">
                    <div class="map-tooltip-contents">
                      <div class="blast d-flex align-items-start justify-content-start">
                        <app-icon name="blastPoint" size="l" fill class="ml-1" />
                        <div class="info-text-wrap">
                          <span class="name">{{ blastInfoWindows.blastName }}</span>
                          <div class="value-wrap">
                            <span>Total Hole</span>
                            <span class="num">{{ blastInfoWindows.totalHole }}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </GmapInfoWindow>
                <GmapInfoWindow :options="fleetInfoOptions" :position="fleetInfoWindowPos" :opened="fleetInfoWinOpen" @closeclick="fleetInfoWinOpen=false">
                  <div class="map-tooltip-typeA" :class="{active : fleetInfoWinOpen}" @click="fleetInfoListSelect">
                    <div class="map-tooltip-contents">
                      <div class="drill d-flex align-items-start justify-content-start">
                        <app-icon v-if="fleetInfoWindows.mpu" name="mpuPoint" size="l" fill class="ml-1" style="height:1.8rem" />
                        <app-icon v-if="fleetInfoWindows.drill" name="drillPoint" size="l" fill class="ml-1" />
                        <div class="info-text-wrap">
                          <span class="name">{{ fleetInfoWindows.unit }}</span>
                          <div class="value-wrap">
                            <span class="num">{{ fleetInfoWindows.per }} %</span>
                          </div>
                          <div class="value-wrap">
                            <span class="num">{{ fleetInfoWindows.statusName }}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </GmapInfoWindow>
                <GmapInfoWindow :options="vibrationInfoOptions" :position="vibrationInfoWindowPos" :opened="vibrationInfoWinOpen" @closeclick="vibrationInfoWinOpen=false">
                  <div class="map-tooltip-typeA" :class="{active : vibrationInfoWinOpen}" @click="vibrationInfoListSelect">
                    <div class="map-tooltip-contents">
                      <div class="vibration d-flex align-items-start justify-content-start">
                        <app-icon name="vibrationPoint" size="l" fill class="ml-1" />
                        <div class="info-text-wrap">
                          <span class="name">{{ vibrationInfoWindows.unit }}</span>
                          <div class="value-wrap">
                            <span>PPV mm/s</span>
                            <span class="num">{{ vibrationInfoWindows.ppv }}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </GmapInfoWindow>
                <GmapMarker
                  :key="'blastBefore-'+index"
                  v-for="(m, index) in blastBeforeList"
                  :position="m.position"
                  :label="m.label"
                  :clickable="true"
                  :draggable="false"
                  :zIndex="9999"
                  :icon="{url: 'img/gmap/'+m.icon}"
                  @mouseover="InfoWindowOverBlast(m)"
                />
                <GmapMarker
                  :key="'blast-'+index"
                  v-for="(m, index) in blastList"
                  :position="m.position"
                  :label="m.label"
                  :clickable="true"
                  :draggable="false"
                  :zIndex="9990"
                  :icon="{url: 'img/gmap/ic_blast_now.png'}"
                  @click="InfoBlast(m)"
                  @mouseover="InfoWindowOverBlast(m)"
                />
                <GmapMarker
                  :key="'fleet-'+index"
                  v-for="(m, index) in fleetList"
                  :position="m.position"
                  :label="m.label"
                  :clickable="true"
                  :draggable="false"
                  :zIndex="9999"
                  :icon="{url: 'img/gmap/'+m.icon}"
                  @mouseover="InfoWindowOverFleet(m)"
                />
                <GmapMarker
                  :key="'vib-'+index"
                  v-for="(m, index) in vibrationList"
                  :position="m.position"
                  :label="m.label"
                  :clickable="true"
                  :draggable="false"
                  :zIndex="9990"
                  :icon="{url: 'img/gmap/ic_vibration.png'}"
                  @mouseover="InfoWindowOverVibration(m)"
                />
                <GmapMarker
                  :key="'hole-'+index"
                  v-for="(m, index) in holeMarkers"
                  :position="m.position"
                  :label="m.label"
                  :icon="m.icon"
                  :clickable="true"
                  :draggable="m.draggable"
                  :zIndex="m.zIndex"
                />
                <GmapCircle
                  v-for="(pin, index) in circle"
                  :key="'circle-'+index"
                  :center="pin.position"
                  :radius="pin.radius"
                  :visible="true"
                  :options="pin.options"
                  :zIndex="9800"
                  >
                </GmapCircle>
                <GmapPolyline
                  :key="'polyline-'+index"
                  v-for="(o, index) in polyline"
                  :path="o.path"
                  :options="o.options"
                  :zIndex="9600"
                  >
                </GmapPolyline>
                <GmapGroundOverlay
                  :key="'overlay-'+index"
                  v-for="(o, index) in groundOverlay"
                  :source="o.source"
                  :bounds="o.bounds"
                  :opacity="o.opacity"
                  :zIndex="9500"
                  >
                </GmapGroundOverlay>
              </GmapMap>

              <!-- mini map -->
              <div ref="miniMap" class="mini-map" @click="changeMapType">
                <GmapMap
                  :center="center"
                  :zoom="18"
                  :options=miniMapOptions
                  style="height: 100%"
                >
                </GmapMap>
              </div>

              <!-- context menu -->
              <!-- google map 거리측정 -->
              <!-- https://github.com/zhenyanghua/MeasureTool-GoogleMaps-V3/blob/master/docs/GUIDE.md -->
              <div
                v-if="isContextMenu"
                class="measure-wrap"
                :style="`left:${contextMenuLeft}px; top:${contextMenuTop}px`">
                <button @click="[measureTool.start(), isMeasureStart = true]" class="btn-custom-default outline rectangle">Start Measure</button>
                <button @click="[measureTool.end(), isMeasureStart = false]" class="btn-custom-default outline rectangle">Clear Measure</button>
                <button v-if="isMeasureStart" @click="measureTool.setOption('invertColor', isInverted = !isInverted)" class="btn-custom-default outline rectangle">Invert Color</button>
              </div>

              <div class="dropdown-pack-wrap">
                <div class="dropdown-pack-inner">
                  <!-- S : Blast List -->
                  <div
                    class="site-list-wrap position-absolute dropdown-03"
                    tabindex="0"
                    @blur="blurList"
                  >
                    <div
                      class="site-list-select form-control"
                      :class="{ on : isBlastSelectList }"
                      @click="selectBlastList"
                      >
                      <strong>Blast List
                        <span class="font-weight-normal">(<small>{{ blastList.length }}</small>)</span>
                      </strong>
                    </div>
                    <ul class="site-list pl-0 mb-0" :class="{ on : isBlastSelectList }">
                    <VuePerfectScrollbar class="scroll-area list-unstyled" :settings="settings">
                      <li
                        :class="{ active : blastCurrentNumb==idx }"
                        v-for="(list, idx) in blastList"
                        :key="idx"
                        @click="BlastLocation(list, idx)"
                      >
                        <!-- list title -->
                        <div class="site-list-title d-flex align-items-center justify-content-between">
                          <strong class="text-wrap-name">{{ list.blastName }}</strong>
                          <span class="status-text"><!-- In progress --></span>
                        </div>
                        <!-- //list title -->
                        <div class="text-wrap pl-2">
                          <div class="d-flex align-items-start justify-content-between">
                            <!-- progress bar -->
                            <!-- <span class="no-num d-block mb-1">-</span> -->
                            <ul class="list-unstyled item-progress-wrap clear">
                              <li class="d-flex align-items-center justify-content-between">
                                <!-- Progress title -->
                                <div class="tit-wrap">
                                  <span class="title blast">Drilling</span>
                                </div>
                                <div class="progressbar-wrap">
                                  <CProgress class="progress-xs" color="green" :value="list.drillingValue"/>
                                </div>
                                <span class="value-count-num"><span>{{ list.drillingValue }}</span>%</span>
                              </li>
                              <li class="d-flex align-items-center justify-content-between">
                                <!-- Progress title -->
                                <div class="tit-wrap">
                                  <span class="title blast">Charging</span>
                                </div>
                                <div class="progressbar-wrap">
                                  <CProgress class="progress-xs" color="info" :value="list.chargingValue"/>
                                </div>
                                <span class="value-count-num"><span>{{ list.chargingValue }}</span>%</span>
                              </li>
                              <li class="d-flex align-items-center justify-content-start">
                                <!-- Progress title -->
                                <div class="tit-wrap">
                                  <span class="title blast">Firing</span>
                                </div>
                                <span class="value-text"
                                  :class="{ 'done' : list.firingValue === 100 }">{{ list.firingValue === 0 ? 'Standby' : 'Done' }}</span>
                              </li>
                            </ul>
                            <!-- //progress bar -->
                            <ul class="blast-data-list list-unstyled">
                              <li class="d-flex align-items-center justify-content-end">
                                <span class="text-wrap-location big">{{ list.totalHole }}</span>
                                <app-icon name="holeTotal" size="s" fill class="color-hold ml-2" />
                              </li>
                              <li class="d-flex align-items-center justify-content-end">
                                <span class="text-wrap-location">{{ list.shotfirer }}</span>
                                <app-icon name="people" size="s" fill class="color-hold ml-2" />
                              </li>
                            </ul>
                          </div>
                        </div>
                      </li>
                      <li class="info-message" v-if="blastList.length==0">
                        <div class="d-flex align-items-center justify-content-center">
                          <span class="text d-inline-block p-3">No work in progress</span>
                        </div>
                      </li>
                      </VuePerfectScrollbar>
                    </ul>
                  </div>
                  <!-- E : Blast List -->

                  <!-- S : Fleet Monitoring -->
                  <div
                    class="site-list-wrap position-absolute dropdown-02"
                    tabindex="0"
                    @blur="blurList"
                  >
                    <div
                      class="site-list-select form-control"
                      :class="{ on : isFleetSelectList }"
                      @click="selectFleetList"
                      >
                      <strong>Fleet
                        <span class="font-weight-normal">(<small>{{fleetList.length}}</small>)</span>
                      </strong>
                    </div>
                    <ul class="site-list pl-0 mb-0" :class="{ on : isFleetSelectList }">
                      <VuePerfectScrollbar class="scroll-area list-unstyled" :settings="settings">
                        <li
                          :class="{ active : fleetCurrentNumb==idx }"
                          v-for="(list, idx) in fleetList"
                          :key="idx"
                          @click="FleetLocation(list, idx)"
                        >
                          <!-- list title -->
                          <div class="site-list-title d-flex align-items-center justify-content-between">
                            <strong class="text-wrap-name">{{ list.unit }}</strong>
                            <span class="status-text"><!-- In progress --></span>
                          </div>
                          <!-- //list title -->
                          <div class="text-wrap pl-2">
                            <div class="d-flex align-items-end justify-content-between">
                              <!-- progress bar -->
                              <!-- <span class="no-num d-block mb-1">-</span> -->
                              <ul class="list-unstyled item-progress-wrap not-calc clear">
                                <li class="d-flex align-items-center justify-content-between">
                                  <!-- Progress title -->
                                  <div class="tit-wrap">
                                    <span class="title fleet">{{ list.statusName }}</span>
                                  </div>
                                  <div class="progressbar-wrap">
                                    <CProgress class="progress-xs" color="green" :value="list.operationValue"/>
                                  </div>
                                    <span class="value-count-num fleet"><span>{{ list.operationValue }}</span>%</span>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                  <!-- Progress title -->
                                  <div class="tit-wrap">
                                    <span class="title fleet">Time Remaining</span>
                                  </div>
                                  <div class="progressbar-wrap info">
                                    <CProgress class="progress-xs" color="emerald" :value="list.remainingValue"/>
                                  </div>
                                    <span class="value-count-num fleet">
                                      <span class="mr-1" style="font-size:17px">{{ list.remaininTime }}</span>
                                    </span>
                                </li>
                              </ul>
                              <!-- //progress bar -->
                              <ul class="fleet-data-list list-unstyled">
                                <li class="d-flex align-items-center justify-content-end">
                                  <span class="text-wrap-location big">{{ list.model }}</span>
                                  <app-icon name="truck" size="s" fill class="color-hold ml-2" />
                                </li>
                                <li class="d-flex align-items-center justify-content-end">
                                  <span class="text-wrap-location">{{ list.operator }}</span>
                                  <app-icon name="people" size="s" fill class="color-hold ml-2" />
                                </li>
                              </ul>
                            </div>
                          </div>
                        </li>
                        <li class="info-message" v-if="fleetList.length==0">
                          <div class="d-flex align-items-center justify-content-center">
                            <span class="text d-inline-block p-3">No work in progress</span>
                          </div>
                        </li>
                      </VuePerfectScrollbar>
                    </ul>
                  </div>
                  <!-- E : Fleet Monitoring -->

                  <!-- S : Vibration Monitoring -->
                  <div
                    class="site-list-wrap position-absolute dropdown-01"
                    tabindex="0"
                    @blur="blurList"
                  >
                    <div
                      class="site-list-select form-control"
                      :class="{ on : isVibrationSelectList }"
                      @click="selectVibrationList"
                      >
                      <strong>Vibration
                        <span class="font-weight-normal">(<small>{{ vibrationList.length }}</small>)</span>
                      </strong>
                    </div>
                    <ul class="site-list pl-0 mb-0" :class="{ on : isVibrationSelectList }">
                      <VuePerfectScrollbar class="scroll-area list-unstyled" :settings="settings">
                        <li
                          :class="{ active : vibrationCurrentNumb==idx }"
                          v-for="(list, idx) in vibrationList"
                          :key="idx"
                          @click="VibrationLocation(list, idx)"
                        >
                          <!-- list title -->
                          <div class="site-list-title d-flex align-items-center justify-content-between">
                            <strong class="text-wrap-name">{{ list.unit }}</strong>
                            <span class="status-text"><!-- In progress --></span>
                          </div>
                          <!-- //list title -->
                          <div class="text-wrap pl-2">
                            <div class="d-flex align-items-end justify-content-between">
                              <ul class="list-unstyled item-text-wrap">
                                <li class="d-flex align-items-center justify-content-start">
                                  <span class="title vibration">PPV</span>
                                  <span class="value vibration big d-block">{{ list.ppv }} mm/s</span>
                                </li>
                                <li class="d-flex align-items-center justify-content-start">
                                  <span class="title vibration">Sound</span>
                                  <span class="value vibration d-block">{{ list.sound }} dB</span>
                                </li>
                              </ul>
                              <ul class="vibration-data-list list-unstyled">
                                <li class="d-flex align-items-center justify-content-end">
                                  <span class="text-wrap-location big">{{ list.model }}</span>
                                  <app-icon name="truck" size="s" fill class="color-hold ml-2" />
                                </li>
                                <li class="d-flex align-items-center justify-content-end">
                                  <span class="text-wrap-location text-uppercase">{{ list.vibrationTime }}</span>
                                  <app-icon name="calendar" size="s" fill class="color-hold ml-2" />
                                </li>
                                <li class="d-flex align-items-center justify-content-end">
                                  <span class="text-wrap-location">{{ list.distanceValue }} m</span>
                                  <app-icon name="distance" size="s" fill class="color-hold ml-2" />
                                </li>
                              </ul>
                            </div>
                          </div>
                        </li>
                        <li class="info-message" v-if="vibrationList.length==0">
                          <div class="d-flex align-items-center justify-content-center">
                            <span class="text d-inline-block p-3">No work in progress</span>
                          </div>
                        </li>
                      </VuePerfectScrollbar>
                    </ul>
                  </div>
                  <!-- E : Vibration Monitoring -->
                  </div>
                </div>
            </div>
          </CCol>
          <div class="site-data-info layout-fix position-relative lg-mt">
            <div class="info-text text-right">
              <span>Last updated : <span>{{ lastUpdate }}</span></span>
            </div>
            <!-- S : Blast List v-bind="retProps()"-->
            <blastListComp v-if="isBlastInfo"
              :isMobile=isMobile
              :blastInfo=blastInfo
              @clearanceZone="clearanceZone"
              @setBlastLocation="setBlastLocation"
            />
            <!-- E : Blast List -->
            <!-- S : Fleet Monitoring -->
            <fleetMonitoringComp v-if="isFleetInfo"
              :isMobile=isMobile
              :fleetInfo=fleetInfo
              @showPath="showPath"
              @setFleetLocation="setFleetLocation"
            />
            <!-- E : Fleet Monitoring -->
            <!-- S : Vibration Monitoring -->
            <vibrationMonitoring v-if="isVibrationInfo"
              :isMobile=isMobile
              :vibrationInfo=vibrationInfo
              @vibrationRange="vibrationRange"
              @setVibrationLocation="setVibrationLocation"
            />
            <!-- E : Vibration Monitoring -->
          </div>
        </CRow>
      </CCardBody>
    </CCard>
  </div>
</template>

<script>
import blastListComp from '@/views/home/BlastList'
import fleetMonitoringComp from '@/views/home/FleetMonitoring'
import vibrationMonitoring from '@/views/home/VibrationMonitoring'

import moment from 'moment'
import haversine from 'haversine'
import utils from '@/assets/js/utils'
import VuePerfectScrollbar from 'vue-perfect-scrollbar'
import { mapGetters, mapActions } from 'vuex'
import { MapElementFactory } from 'vue2-google-maps'
import { asyncForEach } from 'sequential-async-foreach'
import MeasureTool from 'measuretool-googlemaps-v3'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

const blastLibrary = 'blastLibrary'

export default {
  name: 'SiteDashboard',
  components: {
    VuePerfectScrollbar,
    AppIcon,
    blastListComp,
    fleetMonitoringComp,
    vibrationMonitoring,
    'GmapGroundOverlay': MapElementFactory({
        mappedProps: {
          'opacity': { opacity: 0 }
        },
        props: {
          'source': { type: String },
          'bounds': { type: Object },
        },
        events: ['click', 'dblclick'],
        name: 'groundOverlay',
        ctr: () => google.maps.GroundOverlay,
        ctrArgs: (options, {source, bounds}) => [source, bounds, options],
      })
  },
  data () {
    return {
      // context menu
      isContextMenu: false,
      contextMenuLeft: 0,
      contextMenuTop: 0,

      // google map 거리측정
      isMeasureStart: false,
      isInverted: false,
      measureTool: '',

      settings: { // custom scroll
        maxScrollbarLength: 60
      },
      isMobile: false, // mobile check
      spinnerFlag: false,

      isBlastInfo: false,
      isFleetInfo: false,
      isVibrationInfo: false,

      lastUpdate: '-',
      intervalTimer: '',

      blastBeforeList: [],

      // ground-overlay
      groundOverlay: [],

      // S :Blast list dropdown
      blastList: [],
      blastInfo: null,
      blastCurrentNumb: null,
      isBlastSelectList: false,
      // E :Blast list dropdown

      // S : Fleet Monitoring dropdown
      fleetList: [],
      fleetInfo: null,
      fleetCurrentNumb: null,
      isFleetSelectList: false,
      // E : Fleet Monitoring dropdown

      // S : Vibration Monitoring dropdown
      vibrationList: [],
      vibrationInfo: null,
      vibrationCurrentNumb: null,
      isVibrationSelectList: false,
      // E : Vibration Monitoring dropdown

      // google map start
      map: null,
      zoom: 2,
      center: { lat: 37.552855, lng: 128.968973 },
      // optional: offset infowindow so it visually sits nicely on top of our marker
      options: {
        fullscreenControl: false,
        streetViewControl: false,
        rotateControl: false,
        scrollwheel: true,
        draggable: true,
        mapTypeControl: false,
        minZoom: 3,
        maxZoom: 23,
        mapTypeId: "satellite",
        controlSize: 21,
      },
      miniMapOptions: {
        fullscreenControl: false,
        streetViewControl: false,
        rotateControl: false,
        scrollwheel: false,
        mapTypeControl: false,
        draggable: false,
        zoomControl: false,
        minZoom: 11,
        maxZoom: 11,
        mapTypeId: "roadmap",
      },
      // google map

      // blast infoWindow
      blastInfoOptions: {
        pixelOffset: {
          width: 0,
          height: -40
        }
      },
      blastInfoWindowPos: {
        lat: 0,
        lng: 0
      },
      blastInfoWindows: {
        name: '',
        hole: '',
      },
      blastInfoWinOpen: false,
      // fleet infoWindow
      fleetInfoOptions: {
        pixelOffset: {
          width: 0,
          height: -50
        }
      },
      fleetInfoWindowPos: {
        lat: 0,
        lng: 0
      },
      fleetInfoWindows: {
        unit: '',
        per: '',
      },
      fleetInfoWinOpen: false,
      // vibration infoWindow
      vibrationInfoOptions: {
        pixelOffset: {
          width: 0,
          height: -30
        }
      },
      vibrationInfoWindowPos: {
        lat: 0,
        lng: 0
      },
      vibrationInfoWindows: {
        unit: '',
        ppv: '',
      },
      vibrationInfoWinOpen: false,

      holeMarkers: [],
      circle: [],
      circePosition: '',
      circeRadius: '',
      circeOptions: '',
      polyline: []
    }
  },
  computed: {
    ...mapGetters(blastLibrary, {
      status: 'getStatus',
      data: 'getData',
      dataList: 'getDataList',
      selectedData: 'getSelectedData',
    }),
  },
  async created() {
    this.gmapInit()
  },
  destroyed() {
    clearInterval(this.intervalTimer)
  },
  async mounted() {
    // 맵에 대한 정보 획득 및 zoom 이벤트 주입
    this.$refs.mapRef.$mapPromise.then((map) => {
      this.map = map;
      google.maps.event.addListener(this.map, 'zoom_changed', () => {
        this.addMapZoomChanged()
      })

      // google map 거리측정
      this.measureTool = new MeasureTool(this.map, {
        showSegmentLength: true,
        tooltip: true,
        contextMenu: false,
        language: 'en',
        unit: MeasureTool.UnitTypeId.METRIC // or just use 'imperial'
        // unit: MeasureTool.UnitTypeId.IMPERIAL  // or just use 'imperial'
      })
    })

    window.onresize = () => {
      let winWidth = window.innerWidth
      // console.log('winWidth', winWidth)
      winWidth <= 991 ? this.isMobile = true : this.isMobile = false
    }
    // this.$refs.blastListComp.setBlastInfo(this.blastInfo)

    this.defaultView()
  },
  methods: {
    ...mapActions(blastLibrary, {
      setDataListAction: 'setDataList',
      setSelectedAction: 'setSelectedData',
    }),
    retProps() {
      return this.infoTest
    },
    async gmapInit() {
console.log('gmapInit...')
      let that = this
      this.spinnerFlag = true

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      // 접속 사이트 정보
      let moduleName = "v1/siteInfos/"+siteId+"/sites"
      let payload = { params: params, moduleName: moduleName }
      await this.setDataListAction(payload)

      if (this.status=='200' && this.data.content.length > 0) {
        let siteInfo = this.data.content[0]
        // 접속 사이트 맵 셋팅
        this.zoom = 17
        this.center = { lat: Number(siteInfo.latitudeValue), lng: Number(siteInfo.longitudeValue) }
      }

      // 접속 사이트 사이트맵
      moduleName = "v1/dashboard/"+siteId+"/siteMap"
      payload = { params: params, moduleName: moduleName }
      await this.setDataListAction(payload)

      if (this.status=='200' && this.data.content != null) {
        let siteInfo = this.data.content
        if (siteInfo.file != null && siteInfo.file.fileName != null) {
          let groundInfo = {}
          groundInfo.latitude1Value = siteInfo.latitude1Value
          groundInfo.latitude2Value = siteInfo.latitude2Value
          groundInfo.latitude3Value = siteInfo.latitude3Value
          groundInfo.latitude4Value = siteInfo.latitude4Value

          groundInfo.longitude1Value = siteInfo.longitude1Value
          groundInfo.longitude2Value = siteInfo.longitude2Value
          groundInfo.longitude3Value = siteInfo.longitude3Value
          groundInfo.longitude4Value = siteInfo.longitude4Value

          groundInfo.source = siteInfo.file.filePath
//console.log(groundInfo)
          //groundInfo.source = 'https://blast-map.s3.ap-northeast-2.amazonaws.com/28/benchmap/28_1612854769572.png'

          this.setGroundOverlay(groundInfo)
        }
      }

      that.blastBeforeList = []
      // benchmap
      moduleName = "v1/dashboard/"+siteId+"/benchmap"
      payload = { params: params, moduleName: moduleName }
      await this.setDataListAction(payload)
console.log('benchmap...')
//console.log(this.data)
      if (this.status=='200' && this.data.content != null) {
        let benchmapInfo = this.data.content
        benchmapInfo.forEach(function (el, index) {
          let blast = {}
          blast.blastId = el.blastId
          blast.blastName = el.blastName
          blast.totalHole = el.totalHole
          let centerLocation = el.centerLocation
          if (centerLocation != null && centerLocation != '') {
            centerLocation = centerLocation.split(',')
            blast.position = { lat: Number(centerLocation[0].trim()), lng: Number(centerLocation[1].trim()) }

            let iconType = 'ic_blast_now'
            if (el.blastStatusCode!=null) iconType = 'ic_blast_before'

            blast.icon = {
              url: 'img/gmap/'+iconType,
              labelOrigin: { x: 10, y: 28 }  // x: 27, y: 28
            }
          }
//console.log(blast.position.lat, blast.position.lng)
          // benchmap 은 모든 blast만, blast 위치아이콘 및 홀정보 아이콘은 진행중인 리스트만...
          //that.blastBeforeList.push(blast)

          if (el.benchmapfilePath != null && el.benchmapfilePath != null) {
            let groundInfo = {}
            groundInfo.latitude1Value = el.benchmapLatitude1Value
            groundInfo.latitude2Value = el.benchmapLatitude2Value
            groundInfo.latitude3Value = el.benchmapLatitude3Value
            groundInfo.latitude4Value = el.benchmapLatitude4Value

            groundInfo.longitude1Value = el.benchmapLongitude1Value
            groundInfo.longitude2Value = el.benchmapLongitude2Value
            groundInfo.longitude3Value = el.benchmapLongitude3Value
            groundInfo.longitude4Value = el.benchmapLongitude4Value

            groundInfo.source = el.benchmapfilePath
            //groundInfo.source = 'https://dbs-sitemap.s3.ap-northeast-2.amazonaws.com/thumb/28/28_1612767208863.jpg'

            that.setGroundOverlay(groundInfo)
          }
        })
      }

      this.spinnerFlag = false
    },
    setGroundOverlay(groundInfo) {
      if(!isNaN(groundInfo.latitude1Value) && !isNaN(groundInfo.latitude2Value)
        && !isNaN(groundInfo.latitude3Value) && !isNaN(groundInfo.latitude4Value)) {
          let latitude = []
          latitude.push(Number(groundInfo.latitude1Value))
          latitude.push(Number(groundInfo.latitude2Value))
          latitude.push(Number(groundInfo.latitude3Value))
          latitude.push(Number(groundInfo.latitude4Value))
          latitude.sort(function(a, b) { // 오름차순
            return a - b;
          });

          let longitude = []
          longitude.push(Number(groundInfo.longitude1Value))
          longitude.push(Number(groundInfo.longitude2Value))
          longitude.push(Number(groundInfo.longitude3Value))
          longitude.push(Number(groundInfo.longitude4Value))
          longitude.sort(function(a, b) { // 오름차순
            return a - b;
          });

          let bounds = {}
          bounds.north = latitude[3]
          bounds.south = latitude[0]
          bounds.east = longitude[3]
          bounds.west = longitude[0]

          this.groundOverlay.push(
            {
              source: groundInfo.source,
              bounds: bounds,
              opacity: 0.7,
            },
          )
      }
    },
    // S: Blast list selectbox
    async defaultView() {
      let that = this
      await this.intervalView()

      if (this.blastList.length > 0) {
        //that.selectBlastList()
        that.BlastLocation(this.blastList[0], 0)
      }

      this.intervalTimer = setInterval(async () => {
        await this.intervalView()
      }, 60000);  // 60초

      // this.blastInfo = this.blastList[0] // default view
      // this.blastCurrentNumb = 0 // default view list
      // this.isBlastInfo = true

console.log('defaultView...')
console.log(this.$route.query)
      let queryFlag = false
      let query = this.$route.query
      if (query != undefined) {
        if (query.gubun=='blast') {
          // if (this.blastList.length > 0) {
          //   that.selectBlastList()
          //   that.BlastLocation(this.blastList[0], 0)
          //   queryFlag = true
          // }
        }else if (query.gubun=='Vib') {
          this.vibrationList.forEach(function (el, index) {
            if (query.id==el.geophoneId) {
              that.selectVibrationList()
              that.VibrationLocation(el, index)
              queryFlag = true
            }
          })
        }else if (query.gubun=='Delay') {
          this.blastList.forEach(function (el, index) {
            if (query.id==el.blastId) {
              that.selectBlastList()
              that.BlastLocation(el, index)
              queryFlag = true
            }
          })
        }else if (query.gubun=='Cri') {
          this.fleetList.forEach(function (el, index) {
            if (query.id==el.equipmentId) {
              that.selectFleetList()
              that.FleetLocation(el, index)
              queryFlag = true
            }
          })
        }
      }else{
         if (this.blastList.length > 0) {
           that.selectBlastList()
           that.BlastLocation(this.blastList[0], 0)
         }
      }
    },
    async intervalView() {
      if (this.$route.path != '/sitedashboard') return

      let lastUpdate = moment(new Date()).format('YYYY-MM-DD HH:mm')
      if (lastUpdate != this.lastUpdate) {
console.log('intervalView...'+this.lastUpdate)
        await this.getBlastList()
        await this.getFleetList()
        await this.getVibrationList()
        await this.HoleMarker()

        this.lastUpdate = lastUpdate
      }
    },
    async getBlastList() {
console.log('getBlastList...')
      let that = this
      that.spinnerFlag = true

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      // 접속 사이트 정보
      let moduleName = "v1/dashboard/"+siteId+"/blast"
      let payload = { params: params, moduleName: moduleName }
      await that.setDataListAction(payload)

      if (that.status=='200' && that.data.content.length > 0) {
        that.blastList = []
        that.data.content.forEach(function (el) {
          let blast = {}
          blast.siteId = siteId
          blast.blastId = el.blastId
          blast.blastName = el.blastName
          blast.pitName = el.pitName

          let blastDate = ''
          if (el.blastDate != '') {
            blastDate = moment(el.blastDate).format('YYYY-MM-DD HH:mm')
          }
          blast.blastTime = blastDate

          blast.shotfirer = (el.shotfirer!=null?el.shotfirer:'-')
          blast.volume = (el.blastVolume!=null?el.blastVolume.toFixed(2):'-')
          blast.meter = (el.drillMeter!=null?el.drillMeter.toFixed(2):'-')
          blast.totalHole = el.totalHole
          blast.drillHole = el.drillHole
          blast.chargedHole = el.chargedHole
          blast.firedHole = el.firingCnt
          blast.drillingValue = Number(el.drillPer!=null?el.drillPer:0)
          blast.chargingValue = Number(el.chargePer!=null?el.chargePer:0)
          blast.firingValue = Number(el.firingPer!=null?el.firingPer:0)
          blast.remainPer = (el.remainPer!=null?el.remainPer:0)
          blast.remainTime = (el.remainTime!=null?el.remainTime:'-')
          if (Number(el.remainTimeSec)>0) blast.remainTime = '-' + blast.remainTime
          else blast.remainTime = '+' + blast.remainTime

          blast.isLocation = false
          let centerLocation = el.centerLocation
          if (centerLocation != null && centerLocation != '') {
            blast.isLocation = true
            centerLocation = centerLocation.split(',')
            blast.position = { lat: Number(centerLocation[0].trim()), lng: Number(centerLocation[1].trim()) }
          }

          that.blastList.push(blast)
        })

        if (this.blastCurrentNumb != null) {
          this.BlastLocation(this.blastList[this.blastCurrentNumb], this.blastCurrentNumb)
        }
      }

//console.log(that.blastList)
      that.spinnerFlag = false
    },
    async getFleetList() {
console.log('getFleetList...')
      let that = this
      that.spinnerFlag = true

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId
//    let blastId

      // 접속 사이트 정보
      //let moduleName = "v1/dashboard/"+siteId+"/"+blastId+"/fleet"
      let moduleName = "v1/dashboard/"+siteId+"/fleet"
      let payload = { params: params, moduleName: moduleName }
      await that.setDataListAction(payload)

      if (that.status=='200' && that.data.content.length > 0) {
        that.fleetList = []
        that.data.content.forEach(function (el) {
          let fleet = {}
          fleet.siteId = siteId
          fleet.unit = el.unitName
          fleet.pitName = el.pitName
          fleet.model = el.modelName
          fleet.equipmentId = el.equipmentId
          fleet.equipmentTypeCode = el.equipmentTypeCode
          fleet.totalHole = el.totalHole
          fleet.drilledHole = el.drilledHole
          fleet.meterToDrill = el.drillMeter
          fleet.operator = (el.operation.operator!=null?el.operation.operator:'-')
          fleet.statusName = (el.operation.statusName!=null?el.operation.statusName:'-')
          fleet.status  = (el.operation.status!=null?el.operation.status:'-')
          fleet.statusName  = (el.operation.statusName!=null?el.operation.statusName:'-')
          fleet.operationValue = (el.operationPer!=null?el.operationPer:0)
          fleet.remainingValue = (el.remainPer!=null?el.remainPer:0)
          fleet.remaininTime= (el.remainTime!=null?el.remainTime:'-')

          fleet.isLocation = false
          if (el.operation.lastLatitude != null && el.operation.lastLongitude != null) {
            fleet.isLocation = true
            fleet.position = { lat: Number(el.operation.lastLatitude), lng: Number(el.operation.lastLongitude) }
          }else{
            fleet.position = null
          }

          let fleetTime = el.blastDate
          if (fleetTime != null) {
            fleetTime = moment(fleetTime).format('YYYY-MM-DD HH:mm')
          }
          fleet.fleetTime = fleetTime

          let icon = ''
          if (el.equipmentTypeCode=='CODE0042') {
            fleet.operationHole = el.drilledHole
            fleet.resultValue = el.drillMeter
            icon = 'equip_drill_stabdby.png'
          } else {
            fleet.operationHole = el.chargedHole
            fleet.resultValue = el.chargeWeightValue
            icon = 'equip_mpu_standby.png'
          }
          fleet.icon = icon

          that.fleetList.push(fleet)
        })
//console.log(that.fleetList)
      }

      that.spinnerFlag = false
    },
    async getVibrationList() {
console.log('getVibrationList...')
      let that = this
      that.spinnerFlag = true

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      // 접속 사이트 정보
      let moduleName = "v1/dashboard/"+siteId+"/vibration"
      let payload = { params: params, moduleName: moduleName }
      await that.setDataListAction(payload)

      if (that.status=='200' && that.data.content.length > 0) {
        that.vibrationList = []
        that.data.content.forEach(function (el) {
          let vibration = {}
          vibration.siteId = siteId
          vibration.geophoneId = el.geophoneId
          vibration.unit = el.vibrationName
          vibration.pitName = (el.pitName!=null?el.pitName:'-')
          vibration.model = el.modelName
          vibration.serialNumber = el.serialNo
          vibration.ppv = Number(el.ppv!=null?el.ppv.toFixed(2):0)
          vibration.pvsValue = (el.pvs!=null?el.pvs.toFixed(2):0)
          vibration.sound = (el.sound!=null?el.sound.toFixed(2):0)
          vibration.airblastValue = (vibration.sound!=null?vibration.sound:'-')
          vibration.position = { lat: Number(el.latitudeValue), lng: Number(el.longitudeValue) }
          vibration.monitoringPointType = el.monitoringPointType

          let blastDate = ''
          let blastName = ''
          let vibrationTime = ''
          if (el.recentBlast.length > 0) {
            blastDate = el.recentBlast[0].blastDate
            vibrationTime = moment(blastDate).format('YYYY-MM-DD HH:mm')
            blastName = el.recentBlast[0].blastName
          }
          vibration.vibrationTime = vibrationTime
          vibration.recentBlast = blastName
          vibration.blastTime = vibrationTime

          vibration.isLocation = false

          let distanceValue = 0
          let blastCenterLocation = el.blastCenterLocation
          if (blastCenterLocation != null) {
            vibration.isLocation = true
            blastCenterLocation = blastCenterLocation.split(',')
            const start = {
              latitude: Number(blastCenterLocation[0].trim()),
              longitude: Number(blastCenterLocation[1].trim())
            }
            let end = {
              latitude: vibration.position.lat,
              longitude: vibration.position.lng
            }
            distanceValue = (haversine(start, end)*1000).toFixed(1)
          }
          vibration.distanceValue = distanceValue

          // ppv chart data
          let chartData = { data:[] }
          if (blastDate != '') {
            //let chartDate = new Date(blastDate)
            el.chart.forEach(function (el2, index2) {
              //let date = chartDate.setSeconds(chartDate.getSeconds() + index2)
              //date = moment(date).format('YYYY-MM-DD HH:mm:ss')
              chartData.data.push({
                date: moment(el2.blastDate).format('YYYY-MM-DD HH:mm:ss'),
                value: el2.ppv
              })
            })
          }
          vibration.ppvData = chartData

          that.vibrationList.push(vibration)
        })
      }

      that.spinnerFlag = false
    },
    BlastLocation(list, idx) {
      // list select 초기화
      this.fleetCurrentNumb = null
      this.vibrationCurrentNumb = null

      // right dashdoard components 변경
      this.isBlastInfo = true
      this.isFleetInfo = false
      this.isVibrationInfo = false

      this.blastCurrentNumb = idx // tab list select number

      this.blastInfo = list // tab list select Information

      if (this.blastInfo.position != null) {
        this.setGmapCenter(this.blastInfo.position)
        this.InfoWindowOverBlast(this.blastInfo)
      }else{
        utils.showToastRed(this.$t('message.noLocationInfo'))
      }

      //let blastId = this.blastInfo.blastId

      // let status = ''
      // if (this.blastInfo.drillingValue < 100) status = 'drill'
      // else if (this.blastInfo.chargingValue < 100) status = 'charging'
      // if (status != '') this.HoleMarker(status, blastId)
    },
    setBlastLocation(blastInfo) {
        this.setGmapCenter(blastInfo.position)
        this.InfoWindowOverBlast(blastInfo)
    },
    async HoleMarker() {
//console.log('************')
//console.log('HoleMaker...')
      let that = this
      that.spinnerFlag = true

      // 입력값 설정
      let params = new Array()
      let moduleName, payload

      let holeMarkersTemp = []
      //that.blastList.forEach(async function(el, index) {
      await asyncForEach(that.blastList, async (el, index) => {
        try {
          // hole정보를 가져오는 동안 로그아웃시 토큰이 없는 상태에서 api 실행시 401에러 발생으로 siteId 체크
          let siteId = utils.getUserInformation().selectedUserSite.siteId
          if (siteId != null && siteId != '') {
            moduleName = "v1/dashboard/"+siteId+"/"+el.blastId+"/hole"
            payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            that.data.content.forEach(async function(el) {
              let statusCode = el.holeStatus
              let iconType = 'map_designed.png'
              if(statusCode=='CODE0170') iconType = 'map_designed.png'
              else if(statusCode=='CODE0160') iconType  ='map_drilling.gif' // png > gif
              else if(statusCode=='CODE0161') iconType = 'map_drilled.png'
              else if(statusCode=='CODE0162') iconType = 'map_charging.gif' // png > gif
              else if(statusCode=='CODE0163') iconType = 'map_charged.png'
              else if(statusCode=='CODE0164') iconType = 'map_cancled.png'
              else if(statusCode=='CODE0165') iconType = 'map_fired.png'
              else if(statusCode=='CODE0169') iconType = 'map_extraHole.png'

              let zINdex = 9700
              if (statusCode!='CODE0170') zINdex = 9777

              holeMarkersTemp.push({
                holeId: el.holeId,
                position: { lat: el.pointXValue, lng: el.pointYValue },
                draggable: false,
                label: '',
                title: el.holeName,
                status: el.statusCode,
                zIndex: zINdex,
                icon: {
                  url: 'img/gmap/'+iconType,
                  labelOrigin: { x: 10, y: 28 } // x: 27, y: 28
                }
              })
            })
          }
        } catch (error) {
          console.log(error)
        }
      })

      that.holeMarkers = []
      that.holeMarkers = holeMarkersTemp

console.log('hole length = '+that.holeMarkers.length)
//console.log(that.holeMarkers)

      that.spinnerFlag = false
    },
    async HoleMarker_(status, blastId) {
//console.log('HoleMaker...'+status)
      let that = this
      that.spinnerFlag = true

      //let blastInfo = this.blastList[this.blastCurrentNumb]

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      let holeType = '/drillings/hole-tables'
      if (status=='drill') {
        holeType = '/drillings/hole-tables'
      }else if (status=='charging') {
        holeType = '/chargings/hole-charge-status'
      }

      let moduleName = "blast-library/"+siteId+"/"+blastId+holeType
      let payload = { params: params, moduleName: moduleName }
      await that.setDataListAction(payload)

      that.holeMarkers = []
      that.data.content.forEach(function (el) {
        let statusCode = el.drillHoleStatusCode
        let iconType = 'hole_etc.png'
        if (statusCode=='CODE0064') iconType = 'hole_good.png'
        else if (statusCode=='CODE0065') iconType = 'hole_out.png'
        else if (statusCode=='CODE0066') iconType = 'hole_canceled.png'
        else if (statusCode=='CODE0067') iconType = 'hole_etc.png'

        if (status=='drill') {
          that.holeMarkers.push({
            holeId: el.holeId,
            position: { lat: el.designPointXValue, lng: el.designPointYValue },
            draggable: false,
            label: '',
            title: el.holeName,
            status: el.drillHoleStatus,
            icon: {
              url: 'img/gmap/'+iconType,
              labelOrigin: { x: 10, y: 28 }  // x: 27, y: 28
            }
          })
        }else{ // charging
          that.holeMarkers.push({
            holeId: el.holeId,
            position: { lat: el.pointXValue, lng: el.pointYValue },
            draggable: false,
            label: '',
            title: el.holeName,
            status: el.chargeHoleStatus,
            icon: {
              url: 'img/gmap/'+iconType,
              labelOrigin: { x: 10, y: 28 }  // x: 27, y: 28
            }
          })
        }
      })

      that.spinnerFlag = false
    },
    selectBlastList() {
      //site list select box
      // dropbox open
      this.isBlastSelectList = !this.isBlastSelectList

      if(this.isFleetSelectList) this.isFleetSelectList = !this.isFleetSelectList
      if(this.isVibrationSelectList) this.isVibrationSelectList = !this.isVibrationSelectList
    },
    // E: Blast list selectbox
    // S: Fleet Monitoring selectbox
    FleetLocation(list, idx) {
      this.fleetCurrentNumb = idx
      // list select 초기화
      this.blastCurrentNumb = null
      this.vibrationCurrentNumb = null

      // right dashdoard components 변경
      this.fleetInfo = list

      this.isBlastInfo = false
      this.isFleetInfo = true
      this.isVibrationInfo = false

      if (this.fleetInfo.position != null) {
        this.setGmapCenter(this.fleetInfo.position)
        this.InfoWindowOverFleet(this.fleetInfo)
      }else{
        utils.showToastRed(this.$t('message.noLocationInfo'))
      }
// fleetInfo 에 blastId 확인필요
      //let blastId = this.fleetInfo.blastId
//blastId = 67
//console.log(this.fleetInfo)
//       let status = ''
//       if (this.fleetInfo.status=='CODE0146') {
//         if (this.fleetInfo.equipmentTypeCode=='CODE0042') status = 'drill'
//         else if (this.fleetInfo.equipmentTypeCode=='CODE0043') status = 'charging'
//       }
// status = 'drill'
//       if (status != '') this.HoleMarker(status, blastId)
    },
    setFleetLocation(fleetInfo) {
        this.setGmapCenter(fleetInfo.position)
        this.InfoWindowOverFleet(fleetInfo)
    },
    selectFleetList() {
      //Fleet list select box
      // dropbox open
      this.isFleetSelectList = !this.isFleetSelectList

      if(this.isVibrationSelectList) this.isVibrationSelectList = !this.isVibrationSelectList
      if(this.isBlastSelectList) this.isBlastSelectList = !this.isBlastSelectList
    },
    // E: Fleet Monitoring selectbox
    // S: Vibration Monitoring selectbox
    VibrationLocation(list, idx) {
      this.vibrationCurrentNumb = idx

      // list select 초기화
      this.blastCurrentNumb = null
      this.fleetCurrentNumb = null

      // right dashdoard components 변경
      this.vibrationInfo = list

      this.isBlastInfo = false
      this.isFleetInfo = false
      this.isVibrationInfo = true

      if (this.vibrationInfo.position != null) {
        this.setGmapCenter(this.vibrationInfo.position)
        this.InfoWindowOverVibration(this.vibrationInfo)
      }else{
        utils.showToastRed(this.$t('message.noLocationInfo'))
      }
    },
    setVibrationLocation(vibrationInfo) {
        this.setGmapCenter(vibrationInfo.position)
        this.InfoWindowOverVibration(vibrationInfo)
    },
    selectVibrationList() {
      //Vibration list select box
      // dropbox open
      this.isVibrationSelectList = !this.isVibrationSelectList

      if(this.isFleetSelectList) this.isFleetSelectList = !this.isFleetSelectList
      if(this.isBlastSelectList) this.isBlastSelectList = !this.isBlastSelectList
    },
    // E: Vibration Monitoring selectbox
    blurList() {
      // list가 blur 되었을때 닫음

      if(this.isFleetSelectList) this.isFleetSelectList = !this.isFleetSelectList
      if(this.isVibrationSelectList) this.isVibrationSelectList = !this.isVibrationSelectList
      if(this.isBlastSelectList) this.isBlastSelectList = !this.isBlastSelectList
    },
    blastInfoListSelect() {
      this.isBlastSelectList = true

      if(this.isFleetSelectList) this.isFleetSelectList = !this.isFleetSelectList
      if(this.isVibrationSelectList) this.isVibrationSelectList = !this.isVibrationSelectList
    },
    fleetInfoListSelect() {
      this.isFleetSelectList = true

      if(this.isVibrationSelectList) this.isVibrationSelectList = !this.isVibrationSelectList
      if(this.isBlastSelectList) this.isBlastSelectList = !this.isBlastSelectList
    },
    vibrationInfoListSelect() {
      this.isVibrationSelectList = true

      if(this.isFleetSelectList) this.isFleetSelectList = !this.isFleetSelectList
      if(this.isBlastSelectList) this.isBlastSelectList = !this.isBlastSelectList
    },
    InfoBlast(marker) {
//console.log('InfoBlast...')
//console.log(marker)
      let that = this
      this.blastList.forEach(function (el, index) {
        if (marker.blastId==el.blastId) {
          //that.selectBlastList()
          that.BlastLocation(el, index)
        }
      })
    },
    InfoWindowOverBlast(marker) {
      let flag = this.blastInfoWinOpen
      if (flag && this.blastInfoWindows.blastId==marker.blastId) flag = false
      else flag = true

      this.blastInfoWinOpen = flag
      this.InfoWindowOverClose('blast')

      this.blastInfoWindowPos = marker.position
      this.blastInfoWindows.blastId = marker.blastId
      this.blastInfoWindows.blastName = marker.blastName
      this.blastInfoWindows.totalHole = marker.totalHole

      //this.blastInfoWinOpen = true
      // setTimeout(() => {
      //   this.blastInfoWinOpen = false
      // }, 3000);
    },
    InfoWindowOverFleet(marker) {
      let flag = this.fleetInfoWinOpen
      if (flag && this.fleetInfoWindows.equipmentId==marker.equipmentId) flag = false
      else flag = true

      this.fleetInfoWinOpen = flag
      this.InfoWindowOverClose('fleet')

      this.fleetInfoWindowPos = marker.position
      this.fleetInfoWindows.equipmentId = marker.equipmentId
      this.fleetInfoWindows.unit = marker.unit
      this.fleetInfoWindows.per = marker.operationValue
      this.fleetInfoWindows.statusName = marker.statusName
      this.fleetInfoWindows.mpu = false
      this.fleetInfoWindows.drill = false

      if (marker.equipmentTypeCode=='CODE0042') this.fleetInfoWindows.drill = true
      else this.fleetInfoWindows.mpu = true

      //this.fleetInfoWinOpen = true
      // setTimeout(() => {
      //   this.fleetInfoWinOpen = false
      // }, 3000);
    },
    InfoWindowOverVibration(marker) {
      let flag = this.vibrationInfoWinOpen
      if (flag && this.vibrationInfoWindows.geophoneId==marker.geophoneId) flag = false
      else flag = true

      this.vibrationInfoWinOpen = flag
      this.InfoWindowOverClose('vibration')

      this.vibrationInfoWindowPos = marker.position
      this.vibrationInfoWindows.geophoneId = marker.geophoneId
      this.vibrationInfoWindows.unit = marker.unit
      this.vibrationInfoWindows.ppv = marker.ppv

      //this.vibrationInfoWinOpen = true
      // setTimeout(() => {
      //   this.vibrationInfoWinOpen = false
      // }, 3000);
    },
    InfoWindowOverClose(type) {
      if (type != 'blast') this.blastInfoWinOpen = false
      if (type != 'fleet') this.fleetInfoWinOpen = false
      if (type != 'vibration') this.vibrationInfoWinOpen = false
    },
    updateCenter(newCenter) {
      // minimap과 전체map 위치 맞춤
      console.log('center changed!!!')
      // console.log('center changed!!!', newCenter)

      // map drag slow 이슈 (소수점 값이너무많아 drag 느려짐)
      this.center = {
        lat: Number( newCenter.lat().toFixed(2) ),
        lng: Number( newCenter.lng().toFixed(2) )
      }
      // this.center = {
      //   lat: Math.round( newCenter.lat().toFixed(2) * 100 ) / 100,
      //   lng: Math.round( newCenter.lng().toFixed(2) * 100 ) / 100
      // }
    },
    changeMapType() {
      // map type 변경
      console.log('map change!!', this.options.mapTypeId)

      this.options.mapTypeId==="satellite" ? this.options.mapTypeId = "roadmap" : this.options.mapTypeId = "satellite"
      this.miniMapOptions.mapTypeId==="roadmap" ? this.miniMapOptions.mapTypeId = 'satellite' : this.miniMapOptions.mapTypeId = 'roadmap'
    },
    // google map zoom event
    addMapZoomChanged() {
console.log('event.zoom_changed...getZoom = '+this.map.getZoom())
    },
    setGmapCenter(position) {
      this.zoom = 21
      this.center = { lat: position.lat, lng: position.lng }
    },
    clearanceZone(circlePath) {
 console.log('main.clearanceZone...')
      // GmapCircle -----------------------------------------------------
      if (circlePath.length==0) {
        this.circle = []
      }else{
        let that = this
        circlePath.forEach(function (el) {
          that.circle.push(el)
        })
      }
    },
    showPath(e, polyLinePath) {
      if (e && polyLinePath.length==0) {
        utils.showToastRed(this.$t('message.noPathInfo'))
      }
      // GmapPolyline -----------------------------------------------------
      if (polyLinePath.length==0) {
        this.polyline = []
      }else{
        this.polyline.push({
          path: polyLinePath,
          options: { strokeColor:'#CD6155'}
        })
      }
    },
    vibrationRange(vibrationRangePath) {
      //
    },
    hideContextMenu(){
      console.log('+++   hide context menu!! +++')
      this.isContextMenu = false
    },
    showContextMenu(e){
      console.log('===show context menu!!===', e)

      this.isContextMenu = false

      if(e.domEvent.button==2){
        this.isContextMenu = true
        this.contextMenuLeft = e.pixel.x
        this.contextMenuTop = e.pixel.y
      }
    },
    dfContextMenu(e){
      // 브라우저 context menu hide
      e.preventDefault()
    }
  }
}
</script>