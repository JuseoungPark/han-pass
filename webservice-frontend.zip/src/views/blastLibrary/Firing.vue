<template>
<CCard class="print-firing">
    <CCardBody class="line-none">
        <CRow id="printPage">
            <!-- spinner -->
            <div class="spinner-wrap" v-if="spinnerFlag">
                <div class="sk-wave">
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                </div>
            </div>
            <!-- //spinner -->
            <CCol lg="12" class="position-relative">
                <div class="btn-page-event-wrap absolute-wrap">
                    <!-- <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton> -->
                    <CButton type="button" size="sm" color="dark" class="btn-print ml-1 d-md-down-none" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                </div>
                <!-- <CCard> -->
                    <div class="pb-4">
                        <CCol lg="12" class="px-0">
                        <!-- 공통 tab -->
                        <div class="tab-content blast-main-tabs firing">
                            <ul class="nav nav-tabs">
                                <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                    <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 3}">{{ item.name }}</a>
                                </li>
                            </ul>
                        </div>
                        <!-- // 공통 tab -->
                        </CCol>
                        <CRow class="value-info-wrap mt-4">
                            <!-- blast name -->
                            <CCol lg="3">
                                <!-- <CCard class="mb-0"> -->
                                    <div class="box-unit main large position-relative">
                                        <app-icon name="blasts" size="xl" fill />
                                        <div class="text-wrap">
                                            <Strong class="d-block main-text">Blast Name</Strong>
                                            <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                        </div>
                                        <div class="list-unit">
                                            <BlastNameLists
                                                @blastClick="blastClick"
                                            />
                                        </div>
                                    </div>
                                <!-- </CCard> -->
                            </CCol>
                            <!-- // blast name -->
                            <CCol lg="9" class="lg-mt">
                                <BlastDataInfoFiring :key="blastDataInfoFiringId"
                                    ref="blastDataInfoFiring"
                                    v-bind="blastInfo"
                                />
                            </CCol>
                        </CRow>
                    </div>
                <!-- </CCard> -->
            </CCol>
            <CCol>
                <CCard class="cont-wrap">
                    <CCardBody class="line-none">
                        <CRow>
                            <CCol lg="6">
                                <CCard class="mb-0">
                                    <div class="position-relative radius025 tooltip-style-wrap">
                                        <GmapMap
                                            ref="mapRef"
                                            :center="center"
                                            :zoom="zoom"
                                            :options="options"
                                            class="gmap"
                                        >
                                            <GmapInfoWindow
                                                :options="infoOptions"
                                                :position="infoWindowPos"
                                                :opened="infoWinOpen"
                                                @closeclick="infoWinOpen=false">
                                                <div class="map-tooltip-typeA">
                                                    <div class="map-tooltip-contents">
                                                        <div class="blast d-flex align-items-start justify-content-start">
                                                            <app-icon name="blastPoint" size="l" fill class="ml-1" />
                                                            <div class="info-text-wrap">
                                                                <div style="color:#fff">Hole ID : {{ infoWindows.holeName }}</div>
                                                                <div style="color:#fff">Firing time : {{ infoWindows.timing }}</div>
                                                                <div style="color:#fff">Shotfirer : {{ infoWindows.shotfirer }}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </GmapInfoWindow>
                                            <GmapMarker
                                                :key="'hole'+index"
                                                v-for="(m, index) in markers"
                                                :position="m.position"
                                                :label="m.label"
                                                :clickable="true"
                                                :draggable="m.draggable"
                                                :zIndex="9990"
                                                :icon="m.icon"
                                                @mouseover="InfoWindowOver(m, index)"
                                            />
                                            <GmapMarker
                                                :key="'hardness'+index"
                                                v-for="(m, index) in hardness"
                                                :position="m.position"
                                                :zIndex="9980"
                                                :icon="m.icon"
                                            />
                                            <GmapMarker
                                                :position="holePosition"
                                                :clickable="true"
                                                :draggable="false"
                                                :zIndex="9999"
                                                :icon="{ url: 'http://labs.google.com/ridefinder/images/mm_20_red.png' }"
                                                @mouseover="InfoWindowOverRow()"
                                            />
                                            <GmapMarker
                                                :position="shadowPosition"
                                                :clickable="false"
                                                :draggable="false"
                                                :zIndex="9998"
                                                :icon="{
                                                    url: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png',
                                                    anchor: { x:6, y:19 }
                                                }"
                                            />
                                        </GmapMap>

                                        <CCard class="mb-0 position-absolute legend-data-wrap" style="min-width:12.5rem;">
                                            <!-- <CCardHeader class="py-1">
                                                <strong>Legend</strong>
                                            </CCardHeader> -->
                                            <CCardBody class="line-none">
                                                <ul class="list-unstyled mb-0">
                                                    <li>
                                                        <CImg src="img/gmap/hole_good.png" class="ex-img"/>
                                                        <span>Good</span><small class="ml-2">{{ legend.good }}</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_cancled.png" class="ex-img"/>
                                                        <span>Ng</span><small class="ml-2">{{ legend.ng }}</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/hole_etc.png" class="ex-img"/>
                                                        <span>etc.</span><small class="ml-2">{{ legend.etc }}</small>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>

                                        <!-- Rock Hardness -->
                                        <CCard v-if="selectFiringOptions == 'Rock hardness'" class="mb-0 position-absolute legend-data-wrap" style="min-width:12.5rem;top:7.3125rem;">
                                            <CCardBody class="line-none">
                                                <ul class="hardness list-unstyled mb-0">
                                                    <li>
                                                        <CImg src="img/gmap/map_soft.jpg" class="ex-img"/>
                                                        <span>Soft</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_moderate.jpg" class="ex-img"/>
                                                        <span>Moderate</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_hard.jpg" class="ex-img"/>
                                                        <span>Hard</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>

                                        <CCard class="mb-0 position-absolute legend-radio-wrap">
                                            <!-- <CCardHeader class="py-1">
                                                <strong>Radio button</strong>
                                            </CCardHeader> -->
                                            <CCardBody class="line-none">
                                                <CInputRadioGroup
                                                    name="holeType"
                                                    :options="firingOptions"
                                                    :checked="$v.form.holeType.$model"
                                                    custom
                                                    v-model.trim="$v.form.holeType.$model"
                                                    @update:checked="holeRadioClick($event, firingOptions)"
                                                />
                                            </CCardBody>
                                        </CCard>
                                    </div>
                                </CCard>
                            </CCol>
                            <CCol lg="6">
                                <CTabs variant="pills" :active-tab="activeTab" class="lg-mt position-relative" @update:activeTab="updateActiveTab">
                                    <CTab title="Operation" sm="3">
                                        <FiringOperationTabComp :key="firingOperationTabCompId"
                                            ref="firingOperation"
                                            v-bind="blastInfo"
                                        />
                                    </CTab>
                                    <CTab title="Hole table" sm="3">
                                        <!-- excel download -->
                                        <!-- <a href="download/sample.xlsx" download class="btn btn-dark btn-sm position-absolute right-top" title="excel download">
                                            <CImg
                                                src="img/excel.png"
                                                class="icon-down"
                                            />
                                        </a> -->
                                        <div class="hole-table-wrap dark-thead">
                                            <FiringHoleTable :key="firingHoleTableId"
                                                ref="holeTable"
                                                v-bind="blastInfo"
                                                @holeClick="holeClick"
                                            />
                                        </div>
                                    </CTab>
                                </CTabs>
                            </CCol>
                        </CRow>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    </CCardBody>
</CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoFiring from '@/views/blastLibrary/component/BlastDataInfoFiring'

import FiringHoleTable from '@/views/blastLibrary/component/FiringHoleTable'
import FiringOperationTabComp from '@/views/blastLibrary/component/FiringOperationTabComp'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import utils from '@/assets/js/utils'
import moment from 'moment'

Vue.use(VueAxios, axios)

import { validationMixin } from "vuelidate"
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'Firing',
    components: {
        BlastNameLists,
        BlastDataInfoFiring,
        FiringHoleTable,
        FiringOperationTabComp,
        AppIcon
    },
    data() {
        return {
            pageName: 'Firing',
            pageStatus: true,
            spinnerFlag: false,
            form: this.getEmptyForm(),

            activeTab: 0,
            blastDataInfoFiringId: 0,
            firingOperationTabCompId: 0,
            firingHoleTableId: 0,

            // Firing radio option
            selectFiringOptions: '',
            firingOptions: [
                { value: '01', label: 'Hole ID' },
                { value: '02', label: 'Firing time' },
                { value: '03', label: 'Delay' },
                { value: '04', label: 'Relief' },
                { value: '05', label: 'Contour line' },
                { value: '06', label: 'Rock hardness' },
            ],
            holeType: '',

            holeListData: [],
            hardness: [],
            hardnessConst: [],
            holePosition: null,
            shadowPosition: null,
            summaryInfo: [],
            legend: {
                good: '-',
                ng: '-',
                etc: '-',
            },

            // google map
            map: null,
            zoom: 2,
            center: { lat: 9.532600, lng: 160.024612 },
            markers: [],
            infoWindows: {
                holeId: '',
                timing: '',
                status: '',
            },
            infoWindowPos: {
                lat: 0,
                lng: 0
            },
            infoWinOpen: false,
            currentMidx: null,
            // optional: offset infowindow so it visually sits nicely on top of our marker
            options: {
                minZoom: 3,
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                mapTypeControl: true,
                mapTypeId: "satellite",
                controlSize: 21,
            },
            infoOptions: {
                pixelOffset: null,
            },
            // google map
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            holeType: {
                //
            },
        }
    },
    async created() {
        if (this.blastInfo.blastId == 0) {
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }else{
            //let siteInfo = utils.getUserInformation().selectedUserSite
            // 접속 사이트 맵 셋팅
            //this.zoom = 17
            //this.center = { lat: Number(siteInfo.latitudeValue), lng: Number(siteInfo.longitudeValue) }
            // 접속 blast 맵 셋팅
            this.zoom = 17
            this.center = { lat: Number(this.blastInfo.lat), lng: Number(this.blastInfo.lng) }

            this.holeTable()
        }
    },
    mounted() {
        this.$nextTick(() => {
            this.$refs.mapRef.$mapPromise.then((map) => {
                this.map = map
                google.maps.event.addListener(this.map, 'zoom_changed', () => {
                    this.addMapZoomChanged()
                });

                this.infoOptions.pixelOffset = new google.maps.Size(0, -13)
            })
        })
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
        }),
        pagePrint() {
            window.print()
        },
        async holeTable() {
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/firings/hole-tables"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.status == '200' && this.data != undefined) {
                this.holeListData = this.data.content
                this.setMapLegend(this.data.mapLegend)
                this.setHoleMarker()

                this.$refs.holeTable.childMethod(this.holeListData)
            }

            setTimeout(() => {
                this.spinnerFlag = false
            }, 1500);
        },
        setMapLegend(data) {
            let that = this
            data.forEach(function (el) {
                let legend = (el.status).toLowerCase().trim()
                let value = el.count
                if (el.percentage==null) value += ' '
                else value += ' ('+el.percentage.toFixed(1)+'%)'

                if (legend.indexOf('good') >-1) that.legend.good = value
                else if (legend.indexOf('ng') >-1) that.legend.ng = value
                else that.legend.etc = value
            })
        },
        // 초기 로딩시 맵에 blast list의 장소를 marker한다
        setHoleMarker() {
            let that = this
            // info window 닫기
            this.infoWinOpen = false

            this.hardness = []
            let holeInfo = []
            let viewFlag = true

            this.holeListData.forEach(function (el) {
                viewFlag = true
                if (viewFlag) {
                    let status = el.holeFiringStatus
                    if (status=='' || status==null || status==undefined) status = '-'
                    else status = status.toLowerCase().trim()

                    let iconType = 'hole_etc.png'
                    if (status=='good') iconType = 'hole_good.png'
                    else if (status=='ng') iconType = 'hole_out.png'

                    let firingTime = ''
                    if (el.firingTime != null) firingTime = moment(el.firingTime).format('YYYY-MM-DD HH:mm')

                    let rockHardness = el.rockHardness
                    if (rockHardness==null || rockHardness=='') rockHardness = '-'

                    holeInfo.push({
                        holeId: el.holeId,
                        position: { lat: el.pointXValue, lng: el.pointYValue },
                        draggable: false,
                        label: '',
                        labelInfo: {
                            holeName: el.holeName,
                            timing: (el.timing!=null?el.timing:'-'),
                            shotfirer: (el.shotfirer!=null?el.shotfirer:'-'),
                            '01': { text: ''+el.holeName, color: 'red', fontSize: '6px' },
                            '02': { text: ''+firingTime, color: 'blue', fontSize: '6px' },
                            '03': { text: ''+el.delay, color: 'olive', fontSize: '6px' },
                            '04': { text: ''+el.relief, color: 'green', fontSize: '6px' },
                            '05': { text: '-', color: 'purple', fontSize: '6px' },
                            '06': { text: ''+rockHardness, color: 'violet', fontSize: '6px' },
                        },
                        icon: {
                            url: 'img/gmap/'+iconType,
                            labelOrigin: { x: 12, y: 20 }  // x: 27, y: 28
                        }
                    })

                    // let ran = Math.floor((Math.random() * 3) + 1)
                    // if (ran==1) rockHardness = 'hard'
                    // else if (ran==2) rockHardness = 'soft'
                    // else if (ran==3) rockHardness = 'moderate'

                    let iconHardness = ''
                    rockHardness = rockHardness.toLowerCase()
                    if (rockHardness=='hard') iconHardness = 'bg_hard.png'
                    else if (rockHardness=='soft') iconHardness = 'bg_soft.png'
                    else if (rockHardness=='moderate') iconHardness = 'bg_moderate.png'

                    if (rockHardness != '') {
                      that.hardnessConst.push({
                        holeId: el.holeId,
                        position: { lat: el.pointXValue, lng: el.pointYValue },
                        icon: {
                          url: 'img/gmap/'+iconHardness,
                          anchor: new google.maps.Point(10, 15),
                        }
                      })
                    }
                }
            })
            this.markers = holeInfo

            if (holeInfo.length > 0) {
                this.zoom = 18
                this.center = { lat: holeInfo[0].position.lat, lng: holeInfo[0].position.lng }
            }
        },
        setMarker(type) {
            let that = this
            let holeType = this.form.holeType
            let labelView = false

            if (type == 'radio') {
                let latValue = this.markers[0].position.lat
                let lngValue = this.markers[0].position.lng
                let myLatLng = new google.maps.LatLng(latValue, lngValue)

                this.options.mapTypeId = 'roadmap'
                this.map.setCenter(myLatLng)
                setTimeout(function() {
                    if (holeType=='06') that.map.setZoom(20)
                    else that.map.setZoom(21)
                }, 1000)
            }
            if (this.map.getZoom() >= 19) labelView = true

            this.markers.forEach(function (el) {
                if (labelView) el.label = el.labelInfo[holeType]
                else el.label = ''
            })
            if (holeType=='06') {
                that.hardness = that.hardnessConst
            }else if (that.hardness.length>0) {
                that.hardness = []
            }
        },
        InfoWindowOverRow() {
            this.InfoWindowOver(this.markers[0], 0)
        },
        InfoWindowOver(marker) {
            let flag = this.infoWinOpen
            if (flag && this.infoWindows.holeId==marker.holeId) flag = false
            else flag = true

            this.infoWinOpen = flag

            this.infoWindowPos = marker.position
            this.infoWindows.holeId = marker.holeId
            this.infoWindows.holeName = marker.labelInfo.holeName
            this.infoWindows.timing = marker.labelInfo.timing
            this.infoWindows.shotfirer = marker.labelInfo.shotfirer

            //this.infoWinOpen = true
            this.zoom = 20

            // setTimeout(() => {
            //     this.infoWinOpen = false
            // }, 3000);
        },
        // TableComp.vue 에서 해당 holeName
        holeClick(item) {
            let that = this

            this.markers.forEach(function (el) {
                if (el.holeId == item.holeId) {
                    that.InfoWindowOver(el, 0)
                    return false
                }
            })

            // this.holePosition = { lat: Number(item.pointXValue), lng: Number(item.pointYValue) }
            // this.map.setZoom(19)
            // this.center = this.holePosition

            // this.shadowPosition = this.holePosition
        },
        async blastClick(blastInfo) {
            this.activeTab = 0
            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.setBlastInfoAction(this.blastInfo)

            this.blastDataInfoFiringId += 1
            this.firingOperationTabCompId += 1
            this.firingHoleTableId += 1

            this.holeTable()

            // Hole table에서 hole name클릭에 대한 기존 선택된 상태값 초기화
            this.holePosition = null
            this.shadowPosition = null
            this.infoWinOpen = false
        },
        holeRadioClick(event, options) {
            this.form.holeType = event
            this.setMarker('radio')

            let optionValue = event.replace(/(^0+)/, "") - 1
            this.selectFiringOptions = options[optionValue].label
        },
        addMapZoomChanged() {
            this.setMarker('zoom')
        },
        updateActiveTab(index) {
            this.activeTab = index
            this.spinnerFlag = true
            setTimeout(() => {
                this.spinnerFlag = false
            }, 1500);
        },
        getEmptyForm() {
            return {
                holeType: ''
            }
        },
    }
}
</script>
<style lang="scss" scoped>
.gmap{
    height: 899px;
}
@media screen and (max-width:991px){
    .gmap{
        height: 400px;
    }
}
</style>