const siteInfoData = [
  { holeName: 'A1', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549118, lng: 128.961027 },
  { holeName: 'A2', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549136, lng: 128.961072 },
  { holeName: 'A3', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549136, lng: 128.961148 },
  { holeName: 'A4', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549145, lng: 128.961213 },
  { holeName: 'A5', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549335, lng: 128.962005 },
  { holeName: 'A6', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549356, lng: 128.962066 },
  { holeName: 'A7', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549341, lng: 128.962146 },
  { holeName: 'A8', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549356, lng: 128.962186 },
  { holeName: 'A9', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549370, lng: 128.962206 },
  { holeName: 'A10', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549384, lng: 128.962256 },
  { holeName: 'A11', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549385, lng: 128.962266 },
  { holeName: 'A12', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549386, lng: 128.962276 },
  { holeName: 'A13', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549387, lng: 128.962286 },
  { holeName: 'A14', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549388, lng: 128.962296 },
  { holeName: 'A15', designDepth:'8', actualDepth:'7', depthDifferencd:'0.1', xyAccuracy:'-', diameter:'-', drillUnitOperator: '-', drilledTime: '', rockHardness:'', lat: 37.549389, lng: 128.962210 },
]

export default siteInfoData


