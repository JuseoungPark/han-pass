const siteInfoData = [
  { holeNmae: 'A1', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A2', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A3', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A4', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A5', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A6', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A7', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A8', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A9', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A10', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A11', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A12', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A13', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A14', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
  { holeNmae: 'A15', designCharge:'8', actualCharge:'7', depthDifferencd:'0.1', diameter:'-', noOfDeck:'-', stemmingLength: '-', chargeDensity: '', mpyUnitOperator:'', operationTime:'', pF: ''},
]

export default siteInfoData


