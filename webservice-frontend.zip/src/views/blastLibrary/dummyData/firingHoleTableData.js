const siteInfoData = [
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
  { holeNmae: 'A1', deck:'8', detonator:'7', timing: '-', status: '', plannerId:'', blasterId:'', shotfirer: ''},
]

export default siteInfoData


