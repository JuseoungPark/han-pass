const siteInfoData = [
  { blastName: 'A720825', dateDesigned:'2020-10-22', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'12',lat: 37.549118, lng: 128.961027},
  { blastName: 'A720823', dateDesigned:'2020-10-20', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'22',lat: 37.549136, lng: 128.961072},
  { blastName: 'A720821', dateDesigned:'2020-10-17', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'32',lat: 37.549136, lng: 128.961148},
  { blastName: 'A720822', dateDesigned:'2020-10-15', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'42',lat: 37.549145, lng: 128.961213},
  { blastName: 'A720824', dateDesigned:'2020-10-12', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'52',lat: 37.549335, lng: 128.962005},
  { blastName: 'A720826', dateDesigned:'2020-10-10', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'62',lat: 37.549356, lng: 128.962066},
  { blastName: 'A720827', dateDesigned:'2020-10-07', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'72',lat: 37.549341, lng: 128.962146},
  { blastName: 'A720828', dateDesigned:'2020-10-05', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'82',lat: 37.549356, lng: 128.962186},
  { blastName: 'A720829', dateDesigned:'2020-10-02', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'62',lat: 37.549370, lng: 128.962206},
  { blastName: 'A720830', dateDesigned:'2020-10-01', dateFired:'2020-08-22 16:00', pit:'A', Elevaltion:'72',lat: 37.549384, lng: 128.962256},
]

export default siteInfoData


