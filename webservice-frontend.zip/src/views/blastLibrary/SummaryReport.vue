<template>
    <CCard class="print-summary">
        <CCardBody class="line-none">
            <div>
                <CRow id="printPage">
                    <!-- spinner -->
                    <div class="spinner-wrap" v-if="spinnerFlag">
                        <div class="sk-wave">
                            <div class="sk-wave-rect"></div>
                            <div class="sk-wave-rect"></div>
                            <div class="sk-wave-rect"></div>
                            <div class="sk-wave-rect"></div>
                            <div class="sk-wave-rect"></div>
                        </div>
                    </div>
                    <CCol lg="12" class="position-relative">
                        <div class="btn-page-event-wrap absolute-wrap d-md-down-none">
                            <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton>
                            <CButton type="button" size="sm" color="dark" class="btn-print ml-1" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                        </div>
                        <!-- <CCard> -->
                            <div class="pb-4">
                                <CCol lg="12" class="px-0">
                                <!-- 공통 tab -->
                                <div class="tab-content blast-main-tabs report">
                                    <ul class="nav nav-tabs">
                                        <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                            <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 0}">{{ item.name }}</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- // 공통 tab -->
                                </CCol>
                                <CRow class="value-info-wrap mt-4">
                                    <!-- blast name -->
                                    <CCol lg="3">
                                        <!-- <CCard class="mb-0"> -->
                                            <div class="box-unit main large position-relative">
                                                <app-icon name="blasts" size="xl" fill />
                                                <div class="text-wrap">
                                                    <Strong class="d-block main-text">Blast Name</Strong>
                                                    <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                                </div>
                                                <div class="list-unit">
                                                    <BlastNameLists :key="blastNameListsId"
                                                        @blastClick="blastClick"
                                                    />
                                                </div>
                                            </div>
                                        <!-- </CCard> -->
                                    </CCol>
                                    <!-- // blast name -->
                                    <CCol lg="9" class="lg-mt">
                                        <BlastDataInfoSummary :key="blastDataInfoSummaryId"
                                            v-bind="blastInfo"
                                        />
                                    </CCol>
                                </CRow>
                            </div>
                        <!-- </CCard> -->
                    </CCol>
                    <CCol lg="12">
                        <!-- <CCard>
                            <CCardBody> -->
                                <CRow>
                                    <CCol lg="6">
                                        <CCard>
                                            <CCardHeader>
                                                <strong>Blast Condition</strong>
                                            </CCardHeader>
                                            <CCardBody>
                                                <CRow>
                                                    <CCol lg="12">
                                                        <div class="position-relative radius025 tooltip-style-wrap">
                                                            <GmapMap
                                                                ref="mapBlast"
                                                                class="gmap"
                                                                :center="mapBlastCenter"
                                                                :zoom="mapBlastZoom"
                                                                :options="mapBlastOptions"
                                                                @center_changed="updateBlastCenter($refs.mapBlast.$mapObject.getCenter())"
                                                                style="height: 300px"
                                                            >
                                                                <GmapInfoWindow
                                                                    :options="infoOptions"
                                                                    :position="infoWindowPos"
                                                                    :opened="infoWinOpen"
                                                                    @closeclick="infoWinOpen=false">
                                                                    <div class="map-tooltip-typeC">
                                                                        <div class="map-tooltip-contents">
                                                                            <div class="contents">
                                                                                <ul class="map-tooltip-list list-unstyled border-top-0 pt-1 mb-0">
                                                                                    <li>
                                                                                        <app-icon name="blasts" size="s" fill />
                                                                                        <span class="text-wrap-location">
                                                                                            <span>{{ infoWindows.blastInfo }}</span>
                                                                                        </span>
                                                                                    </li>
                                                                                    <li>
                                                                                        <app-icon name="pitName" size="s" fill />
                                                                                        <span class="text-wrap-location">
                                                                                            <span>{{ infoWindows.pitName }}</span>
                                                                                        </span>
                                                                                    </li>
                                                                                    <li>
                                                                                        <app-icon name="calendar" size="s" fill />
                                                                                        <span class="text-wrap-location">
                                                                                            <span>{{ infoWindows.blastDate }}</span>
                                                                                        </span>
                                                                                    </li>
                                                                                </ul>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </GmapInfoWindow>
                                                                <GmapMarker
                                                                    :key="index"
                                                                    v-for="(m, index) in markersBlast"
                                                                    :position="m.position"
                                                                    :label="m.label"
                                                                    :clickable="true"
                                                                    :draggable="m.draggable"
                                                                    :icon="{ url: 'img/gmap/ic_blast_now.png' }"
                                                                    @mouseover="InfoWindowOver(m, index)"
                                                                />
                                                                <GmapPolygon
                                                                    :paths="polygonPaths"
                                                                    :options="polygonOptions"
                                                                />
                                                            </GmapMap>
                                                            <!-- mini map -->
                                                            <div ref="miniMap" class="mini-map small" @click="changeMapBlastType">
                                                                <GmapMap
                                                                    :center="mapBlastCenter"
                                                                    :zoom="18"
                                                                    :options=miniMapBlastOptions
                                                                    style="height: 100%"
                                                                >
                                                                </GmapMap>
                                                            </div>
                                                        </div>
                                                    </CCol>
                                                    <CCol lg="12" class="mt-3">
                                                        <ul class="nth-custom list-unstyled half-layout">
                                                            <li v-for="(item, index) in blastConditionList" :key="index">
                                                                <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                                <span>
                                                                    {{ item.value }}
                                                                    <small v-if="item.unit != ''">
                                                                        {{ item.unit }}
                                                                    </small>
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </CCol>
                                                </CRow>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                    <CCol lg="6">
                                        <CCard>
                                            <CCardHeader>
                                                <strong>Blast Pattern</strong>
                                            </CCardHeader>
                                            <CCardBody>
                                                <CRow>
                                                    <CCol lg="12">
                                                        <div class="position-relative radius025">
                                                            <GmapMap
                                                                ref="mapHole"
                                                                class="gmap"
                                                                :center="mapHoleCenter"
                                                                :zoom="mapHoleZoom"
                                                                :options="mapHoleOptions"
                                                                @center_changed="updateHoleCenter($refs.mapHole.$mapObject.getCenter())"
                                                                style="height: 300px"
                                                            >
                                                                <GmapMarker
                                                                    v-for="(m, index) in markersHole"
                                                                    :key="'hole-'+index"
                                                                    :position="m.position"
                                                                    :label="m.label"
                                                                    :clickable="true"
                                                                    :draggable="m.draggable"
                                                                    :icon="m.icon"
                                                                />
                                                                <GmapMarker
                                                                    v-for="(m, index) in markersLabel"
                                                                    :key="'label-'+index"
                                                                    :position="m.position"
                                                                    :label="m.label"
                                                                    :clickable="false"
                                                                    :draggable="false"
                                                                    :icon="m.icon"
                                                                />
                                                            </GmapMap>
                                                            <!-- mini map -->
                                                            <div ref="miniMapHole" class="mini-map small" @click="changeMapHoleType">
                                                                <GmapMap
                                                                    :center="mapHoleCenter"
                                                                    :zoom="18"
                                                                    :options=miniMapHoleOptions
                                                                    style="height: 100%"
                                                                >
                                                                </GmapMap>
                                                            </div>
                                                            <CCard class="mb-0 position-absolute legend-radio-wrap top-right">
                                                                <!-- <CCardHeader class="py-1">
                                                                    <strong>Radio button</strong>
                                                                </CCardHeader> -->
                                                                <CCardBody class="line-none">
                                                                    <!-- class="col-sm-9" -->
                                                                    <CInputCheckbox
                                                                        v-for="(option, index) in radioOptions"
                                                                        :key="'key-' + index"
                                                                        :label="option.label"
                                                                        :value="option.value"
                                                                        custom
                                                                        @update:checked="checkboxClick($event, option)"
                                                                    />
                                                                        <!-- :checked="$v.form.radioType.$model" -->
                                                                        <!-- v-model.trim="$v.form.radioType.$model" -->
                                                                </CCardBody>
                                                            </CCard>
                                                        </div>
                                                    </CCol>
                                                    <CCol lg="12" class="mt-3">
                                                        <ul class="nth-custom list-unstyled half-layout blast-pt-mb">
                                                            <li v-for="(item, index) in blastPatternList" :key="index">
                                                                <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                                <span>
                                                                    {{ item.value  }}
                                                                    <small v-if="item.unit != ''">
                                                                        {{ item.unit }}
                                                                    </small>
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </CCol>
                                                </CRow>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                </CRow>
                            <!-- </CCardBody>
                        </CCard> -->
                    </CCol>

                    <CCol lg="12">
                        <!-- <CCard>
                            <CCardBody> -->
                                <CRow>
                                    <CCol lg="4">
                                        <CCard>
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('drilling','green'),
                                                                yellow: getInterfaceStatus('drilling','yellow'),
                                                                gray: getInterfaceStatus('drilling','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Drilling</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); drillingResultData=true;"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <ul class="odd-custom list-unstyled">
                                                    <li v-for="(item, index) in drillingList" :key="index">
                                                        <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                        <span>
                                                            {{ item.value | setDecimal }}
                                                            <small v-if="item.unit != ''">
                                                                {{ item.unit }}
                                                            </small>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                    <CCol lg="4">
                                        <CCard>
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('charging','green'),
                                                                yellow: getInterfaceStatus('charging','yellow'),
                                                                gray: getInterfaceStatus('charging','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Charging</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); chargingResultData = true"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <ul class="odd-custom list-unstyled mb-3">
                                                    <li v-for="(item, index) in chargingList" :key="index">
                                                        <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                        <span>
                                                            {{ item.value }}
                                                            <small v-if="item.unit != ''">
                                                                {{ item.unit }}
                                                            </small>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                    <CCol lg="4">
                                        <CCard>
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('firing','green'),
                                                                yellow: getInterfaceStatus('firing','yellow'),
                                                                gray: getInterfaceStatus('firing','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Firing</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); FiringResultData = true"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <ul class="odd-custom list-unstyled firing-mb">
                                                    <li v-for="(item, index) in firingList" :key="index">
                                                        <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                        <span>
                                                            {{ item.value }}
                                                            <small v-if="item.unit != ''">
                                                                {{ item.unit }}
                                                            </small>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                </CRow>
                            <!-- </CCardBody>
                        </CCard> -->
                    </CCol>
                </CRow>
            </div>
            <div class="page-break">
                <CRow>
                    <CCol lg="12">
                        <!-- <CCard> -->
                            <!-- <CCardBody> -->
                                <CRow>
                                    <CCol lg="8">
                                        <CCard>
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('fragmentation','green'),
                                                                yellow: getInterfaceStatus('fragmentation','yellow'),
                                                                gray: getInterfaceStatus('fragmentation','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Fragmentation</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); FragmentationData = true"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <CRow>
                                                    <CCol lg="6">
                                                        <CCard class="mb-0">
                                                            <AmChartXYHorizontalComp :key="amChartXYHorizontalCompId"
                                                                v-if="xyHorizontalChartData.data.length!=0"
                                                                series1Name="Actual"
                                                                series2Name="Expected"
                                                                chartHeight="200"
                                                                :chartData=xyHorizontalChartData
                                                            />
                                                        </CCard>
                                                    </CCol>
                                                    <CCol lg="6">
                                                        <ul class="odd-custom list-unstyled fragmentation-mb">
                                                            <li v-for="(item, index) in fragmentationList" :key="index">
                                                                <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                                <span>
                                                                    {{ item.value }}
                                                                    <small v-if="item.unit != ''">
                                                                        {{ item.unit }}
                                                                    </small>
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </CCol>
                                                </CRow>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                    <CCol lg="4">
                                        <CCard>
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('vibration','green'),
                                                                yellow: getInterfaceStatus('vibration','yellow'),
                                                                gray: getInterfaceStatus('vibration','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Vibration</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); VibrationData = true"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <ul class="odd-custom list-unstyled vibration-mb">
                                                    <li v-for="(item, index) in vibrationList" :key="index">
                                                        <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                        <span>
                                                            {{ item.value }}
                                                            <small v-if="item.unit != ''">
                                                                {{ item.unit }}
                                                            </small>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                </CRow>
                            <!-- </CCardBody> -->
                        <!-- </CCard> -->
                    </CCol>
                    <CCol lg="12">
                        <!-- <CCard>
                            <CCardBody> -->
                                <CRow>
                                    <CCol lg="12">
                                        <CCard class="mb-0">
                                            <CCardHeader class="position-relative">
                                                <div class="row">
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                                        <!-- green: 완성, yellow: 미완(drilling, charging에서 유닛 일부만 data있을때, gray: data없음) -->
                                                        <div
                                                            class="report-status-wrap absolute"
                                                            :class="{
                                                                green: getInterfaceStatus('productivity','green'),
                                                                yellow: getInterfaceStatus('productivity','yellow'),
                                                                gray: getInterfaceStatus('productivity','gray')
                                                            }"
                                                        >
                                                            <strong class="title text-nowrap">Productivity / Cost</strong>
                                                        </div>
                                                        <CButton
                                                            v-if="isInterface"
                                                            class="btn-custom-default outline"
                                                            @click="reportEdit(); ProductivityCostData = true"
                                                        >
                                                            Edit
                                                        </CButton>
                                                    </div>
                                                </div>
                                            </CCardHeader>
                                            <CCardBody>
                                                <CRow>
                                                    <CCol lg="5">
                                                        <ul class="odd-custom list-unstyled">
                                                            <li v-for="(item, index) in productivityCostList" :key="index">
                                                                <strong class="list-tit mr-1">{{ item.title }} : </strong>
                                                                <span>
                                                                    {{ item.value }}
                                                                    <small v-if="item.unit != ''">
                                                                        {{ item.unit }}
                                                                    </small>
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </CCol>
                                                    <CCol lg="7">
                                                        <div v-show="pieChartDataTotal!=0">
                                                        <CCard class="mb-0">
                                                            <AmChartPieHoverComp :key="amChartPieHoverCompId"
                                                                v-if="pieChartDataTotal!=0"
                                                                chartHeight="250"
                                                                :chartData=pieChartData
                                                            />
                                                        </CCard>
                                                        </div>
                                                        <div v-show="pieChartDataTotal==0" v-text="$t('message.noData')" style="padding-top:10px;" />
                                                    </CCol>
                                                </CRow>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                </CRow>
                            <!-- </CCardBody>
                        </CCard> -->
                    </CCol>
                    <sweet-modal
                        ref="editModal"
                        blocking
                        overlay-theme="dark"
                        hide-close-button
                        class="modal-pop max-450"
                        :class="{'max-plus' : VibrationData}"
                    >
                        <DrillingResultDataComp :key="resultDataCompId"
                            v-if="drillingResultData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                        <ChargingResultDataComp :key="resultDataCompId"
                            v-if="chargingResultData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                        <FiringResultDataComp :key="resultDataCompId"
                            v-if="FiringResultData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                        <FragmentationDataComp :key="resultDataCompId"
                            v-if="FragmentationData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                        <VibrationDataComp :key="resultDataCompId"
                            v-if="VibrationData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                        <ProductivityCostDataComp :key="resultDataCompId"
                            v-if="ProductivityCostData"
                            v-bind="blastInfo"
                            @submitChk="submitChk"
                            @closeEditPop="closeEditPop"
                        />
                    </sweet-modal>
                    <!-- https://sweet-modal-vue.adepto.as/ -->
                </CRow>
            </div>
        </CCardBody>
    </CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoSummary from '@/views/blastLibrary/component/BlastDataInfoSummary'

import { SweetModal } from 'sweet-modal-vue'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

const AmChartXYHorizontalComp = () => import(/* webpackChunkName: "SummaryReportCharts" */ './component/AmChartXYHorizontalComp')
const AmChartPieHoverComp = () => import(/* webpackChunkName: "SummaryReportCharts" */ './component/AmChartPieHoverComp')

const DrillingResultDataComp = () => import(/* webpackChunkName: "DrillingResultEditPop" */ './component/DrillingResultDataComp')
const ChargingResultDataComp = () => import(/* webpackChunkName: "ChargingResultEditPop" */ './component/ChargingResultDataComp')
const FiringResultDataComp = () => import(/* webpackChunkName: "FiringResultEditPop" */ './component/FiringResultDataComp')
const FragmentationDataComp = () => import(/* webpackChunkName: "FragmentationEditPop" */ './component/FragmentationDataComp')
const VibrationDataComp = () => import(/* webpackChunkName: "VibrationEditPop" */ './component/VibrationDataComp')
const ProductivityCostDataComp = () => import(/* webpackChunkName: "ProductivityCostEditPop" */ './component/ProductivityCostDataComp')

//import moment from 'moment'
import moment from 'moment-timezone'
import utils from '@/assets/js/utils'
import haversine from 'haversine'
import { validationMixin } from "vuelidate"
import { mapGetters, mapActions } from 'vuex'
import VueHtml2pdf from 'vue-html2pdf'

const blastLibrary = 'blastLibrary'

export default {
    name: 'SummaryReport',
    components: {
        BlastNameLists,
        BlastDataInfoSummary,

        AmChartPieHoverComp, //chart
        AmChartXYHorizontalComp, //chart

        VueHtml2pdf,
        AppIcon,
        SweetModal,
        DrillingResultDataComp, // edit pop
        ChargingResultDataComp, // edit pop
        FiringResultDataComp, // edit pop
        FragmentationDataComp, // edit pop
        VibrationDataComp, // edit pop
        ProductivityCostDataComp, // edit pop
    },
    data() {
        return {
            pageName: 'SummaryReport',
            pageStatus: true,
            spinnerFlag: false,
            form: this.getEmptyForm(),
            checkbox_check: [],

            drillingResultData: false,
            chargingResultData: false,
            FiringResultData: false,
            FragmentationData: false,
            VibrationData: false,
            ProductivityCostData: false,

            blastNameListsId: 0,
            resultDataCompId: 0,
            blastDataInfoSummaryId: 0,
            amChartXYHorizontalCompId: 0,
            amChartPieHoverCompId: 0,

            // Drilling radio option
            radioOptions: [
                { value: '01', label: 'Hole ID' },
                { value: '02', label: 'Firing time' },
                { value: '03', label: 'Delay' },
            ],
            radioType: '',

            // gray, yellow, green
            interfaceStatus: {
                drilling: 'gray',
                charging: 'gray',
                firing: 'gray',
                fragmentation: 'gray',
                vibration: 'gray',
                productivity : 'gray',
            },
            isInterface: false,

            // Blast Condition list
            blastConditionList: [
                { title: 'Blast location(pit)', value: '', unit: '' },
                { title: 'Elevation', value: '', unit: '' },
                { title: 'Blasted time',  value: '', unit: ''},
                { title: 'Weather',  value: '', unit: '' },
                { title: 'Temperature',  value: '', unit: '' },
                { title: 'Rock type',  value: '', unit: '' },
                { title: 'Rock strength',  value: '', unit: '' },
                { title: 'Rock factor',  value: '', unit: '' },
            ],
            // Blast Pattern
            blastPatternList: [
                { title: 'Designed holes', value: '', unit: '' },
                { title: 'Patten type', value: '', unit: '' },
                { title: 'Burden/Spacing', value: '', unit: '' },
                { title: 'Desinged volume', value: '', unit: '' },
                { title: 'Bench height(depth)', value: '', unit: '' },
                { title: 'P.F', value: '', unit: '' },
            ],
            // Drilling
            drillingList: [
                { title: 'Drilled hole', value: '', unit: '' },
                { title: 'Total Drill meter', value: '', unit: '(m)' },
                { title: 'Avg. Drill meter', value: '', unit: '(m)' },
                { title: 'Total Work hour', value: '', unit: '' },
                { title: 'Diamter', value: '', unit: '(mm)' },
                { title: 'Cost', value: '', unit: '' },
            ],
            // Fragmentation
            fragmentationList: [
                { title: 'Target D50', value: '', unit: '(m)' },
                { title: 'Predicted D50', value: '', unit: '(m)' },
                { title: 'Actual D50', value: '', unit: '(m)' },
                { title: 'Uniformity', value: '', unit: '' },
            ],
            // Charging
            chargingList: [
                { title: 'Total Charge weight', value: '', unit: '(kg)' },
                { title: 'Avg. Charge weight', value: '', unit: '(%)' },
                { title: 'Avg. Charge density', value: '', unit: '' },
                { title: 'Total Work hour', value: '', unit: '' },
                { title: 'Actual P.F', value: '', unit: '' },
                { title: 'Bulk name', value: '', unit: '' },
            ],
            // Vibration
            vibrationList: [
                { title: 'Distance', value: '', unit: '(m)' },
                { title: 'Target PPV', value: '', unit: '(mm/s)' },
                { title: 'Predicted PPV', value: '', unit: '(mm/s)' },
                { title: 'Acutal PVS', value: '', unit: '(mm/s)' },
                { title: 'Actual Sound', value: '', unit: '(dB)' },
            ],
            // Firing
            firingList: [
                { title: 'Detonator', value: '', unit: '' },
                { title: 'Last Firing timing', value: '', unit: '(ms)' },
                { title: 'M.I.C', value: '', unit: '(kg)' },
                { title: 'Fume', value: '', unit: '' },
                { title: 'Misfire or Failure', value: '', unit: '' },
                { title: 'Relief Value', value: '', unit: '(ms/s)' },
            ],
            pieChartDataTotal: 0,

            // google map blast
            mapBlast: null,
            mapBlastCenter: { lat: 9.532600, lng: 160.024612 },
            markersBlast: [],
            mapBlastZoom: 2,
            mapBlastOptions: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                draggable: true,
                mapTypeControl: false,
                mapTypeId: "satellite",  // roadmap
                minZoom: 3,
                maxZoom: 20,
                controlSize: 21,
            },
            // google map hole
            mapHole: null,
            mapHoleCenter: { lat: 9.532600, lng: 160.024612 },
            markersHole: [],
            markersLabel: [],
            mapHoleZoom: 2,
            mapHoleOptions: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                draggable: true,
                mapTypeControl: false,
                mapTypeId: "roadmap",  // roadmap
                minZoom: 3,
                maxZoom: 25,
                controlSize: 21,
            },
            infoContent: '',
            infoLink: '',
            infoWindowPos: {
                lat: 0,
                lng: 0,
            },
            infoWindows: {
                blastInfo: '',
                pitName: '',
                blastDate: '',
            },
            infoWinOpen: false,
            currentMidx: null,
            // optional: offset infowindow so it visually sits nicely on top of our marker
            infoOptions: {
                pixelOffset: {
                    width: 0,
                    height: -40,
                }
            },
            polygonPaths: [],
            polygonOptions: {
                strokeColor: '#FF0000',
                strokeOpacity: 0.8,
                strokeWeight: 1,
                fillColor: '#FF0000',
                fillOpacity: 0.35,
            },

            miniMapBlastOptions: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: false,
                mapTypeControl: false,
                draggable: false,
                zoomControl: false,
                minZoom: 11,
                maxZoom: 11,
                mapTypeId: "roadmap",
            },
            miniMapHoleOptions: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: false,
                mapTypeControl: false,
                draggable: false,
                zoomControl: false,
                minZoom: 11,
                maxZoom: 11,
                mapTypeId: "satellite",
            },
            // google map

            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            xyHorizontalChartData: {
                data: [{
                    "target": "-",
                    "value1": 0,
                    "value2": 0
                }]
            },
            pieChartData: {
                data: [{
                    "country": "-",
                    "litres": 0
                }]
            },

            //VueHtml2pdf
            progressBar: 0,
            htmlToPdfOptions: {
                margin: [10, 0, 0, 0],
                filename: "SummaryReport",
                image: {
                    type: 'jpeg',
                    quality: 1
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a4',
                    orientation: 'landscape',
                },
                pagebreak: {
                    // mode: ['avoid-all', 'css', 'legacy']
                    mode: ['avoid', 'css', 'legacy']
                },
                html2canvas: {
                    scale: 1,
                    useCORS: true,
                    allowTaint: false,
                    ignoreElements: (node) => {
                        return node.nodeName === 'IFRAME'
                    },
                    // svg image
                    onclone: (element) => {
                        const svgElements = Array.from(element.querySelectorAll('svg'))

                        svgElements.forEach(s => {
                            const bBox = s.getBBox()
                            s.setAttribute("x", bBox.x)
                            s.setAttribute("y", bBox.y)
                            s.setAttribute("width", bBox.width)
                            s.setAttribute("height", bBox.height)
                        })
                    }
                }
            },
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            radioType: {
                //
            }
        }
    },
    async created() {
console.log('created ************')
console.log(this.blastInfo.siteId, this.blastInfo.blastId)
console.log(this.blastInfo)
console.log(this.blastList)

        // 직접 해당 메뉴로 접근한 경우 처리
        if (this.blastList.length==0) {
            await this.getBlastSearch()
        } else if (this.blastInfo.blastId==0 || this.blastInfo.blastId=='') {
            let blastInfo = {
                siteId: this.blastList[0].siteId,
                blastId: this.blastList[0].blastId,
                blastName: this.blastList[0].blastName,
            }
            this.setBlastInfoAction(blastInfo)
        }

        await this.gmapInit()

        if (this.blastList.length==0) {
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }else{
            await this.pageReload()
        }

        let userSite = utils.getUserInformation().selectedUserSite
        let permission = userSite.userPermissionList.split(',')
        this.isInterface = permission.includes('createblastLibrarySummaryReport')

//onsole.log(userSite)
//console.log(userSite.timezoneType)
        //moment.tz.setDefault('America/New_York')
        //moment.tz.setDefault('Asia/Seoul')

//console.log( moment().format() )
//console.log( moment.utc().format() )

//      let calDate =  moment('2021-03-04 12:00:00').format('YYYY-MM-DD HH:mm:ss')
// console.log(calDate)
// console.log( moment.utc().format())
// console.log( moment(calDate).utc().format() )
    },
    mounted() {
        this.$nextTick(() => {
            // Blast Condition map
            this.$refs.mapBlast.$mapPromise.then((map) => {
                this.mapBlast = map
            })
            // Blast Pattern map
            this.$refs.mapHole.$mapPromise.then((map) => {
                this.mapHole = map
                google.maps.event.addListener(this.mapHole, 'zoom_changed', () => {
                    this.addMapHoleZoomChanged()
                });
            })
        })
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
        userSite () {
            return utils.getUserInformation().selectedUserSite
        },
        // Productivity/cost
        productivityCostList(){
            return [
                { title: 'Drill meter', value: '', unit: '(m)' },
                { title: 'Drill Cost', value: '', unit: '' },
                { title: 'Product Cost', value: '', unit: `(${this.userSite.currencyName})` },
                { title: 'Labor Cost', value: '', unit: `(${this.userSite.currencyName})` },
                { title: 'Extra Cost', value: '', unit: `(${this.userSite.currencyName})` },
                { title: 'Blasts Volume', value: '', unit: '(BCM)' },
                { title: 'Blast Cost', value: '', unit: `(${this.userSite.currencyName})` },
            ]
        }
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
            setBlastListAction: 'setBlastList',
        }),
        pagePrint() {
            window.print()
        },
        async pageReload() {
            this.spinnerFlag = true

            // interface 초기화
            for(let key in this.interfaceStatus) {
                this.interfaceStatus[key] = 'gray'
            }

            await this.getBlastCondition()
            await this.getBlastPattern()
            await this.getDrilling()
            await this.getCharging()
            await this.getFiring()
            await this.getFragmentation()
            await this.getVibration()
            await this.getProductivity()

            this.blastDataInfoSummaryId += 1

            if (this.markersBlast.length>0) {
                this.InfoWindowOver(this.markersBlast[0], 0)
            }

            this.spinnerFlag = false
        },
        async gmapInit() {
console.log('gmapInit...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = utils.getUserInformation().selectedUserSite.siteId

            // 접속 사이트
            let moduleName = "v1/siteInfos/"+siteId+"/sites"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.status=='200' && this.data.content.length > 0) {
                let siteInfo = this.data.content[0]

                let latValue = Number(siteInfo.latitudeValue)
                let lngValue = Number(siteInfo.longitudeValue)

                this.mapBlastZoom = 19
                this.mapBlastCenter = { lat: latValue, lng: lngValue }

                this.mapHoleZoom = 19
                this.mapHoleCenter = { lat: latValue, lng: lngValue }
            }

            this.spinnerFlag = false
        },
        async getBlastSearch() {
console.log('getBlastSearch...')
            this.spinnerFlag = true

            let params = new Array()
            let siteId = utils.getUserInformation().selectedUserSite.siteId

            params.push("siteId="+siteId)
            params.push("pagable=false")
            params.push("page=1")

            let date_start = moment().add(-15,'days').format('YYYY-MM-DD')
            let date_end = moment().add(+30,'days').format('YYYY-MM-DD')

            params.push("firingDateFrom="+date_start)
            params.push("firingDateTo="+date_end)

            let moduleName = "v1/blast-library/"+siteId+"/blasts"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.setBlastListAction([])
            if (this.dataList.length != 0) {
                this.setBlastListAction(this.dataList)

                let latValue = 0
                let lngValue = 0
                let centerLocation = this.dataList[0].centerLocation
                if (centerLocation != null) {
                    centerLocation = centerLocation.split(',')
                    latValue = Number(centerLocation[0])
                    lngValue = Number(centerLocation[1])
                }

                let blastInfo = {}
                blastInfo.siteId = utils.getUserInformation().selectedUserSite.siteId
                blastInfo.blastId = this.dataList[0].blastId
                blastInfo.blastName = this.dataList[0].blastName+' ('+this.dataList[0].holeCount+')'
                blastInfo.holes = this.dataList[0].holeCount
                blastInfo.lat = latValue
                blastInfo.lng = lngValue

                this.setBlastInfoAction(blastInfo)
                this.blastNameListsId += 1
            }

            this.spinnerFlag = false
        },
        async getBlastCondition() {
console.log('getBlastCondition...')
            let that = this
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/summary/"+blastId+"/blast-condition"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.dataList != undefined) {
                let conditionInfo = this.dataList

                conditionInfo.blastDate = moment(conditionInfo.blastDate).format('YYYY-MM-DD HH:mm')

                this.blastConditionList[0].value = conditionInfo.pitName
                this.blastConditionList[1].value = conditionInfo.elevationValue
                this.blastConditionList[2].value = conditionInfo.blastDate
                this.blastConditionList[3].value = this.chkNull(conditionInfo.weatherValue)
                this.blastConditionList[4].value = this.chkNull(conditionInfo.temperatureValue)
                if (conditionInfo.rock != null) {
                    this.blastConditionList[5].value = this.chkNull(conditionInfo.rock.rockName)
                    this.blastConditionList[6].value = this.chkNull(conditionInfo.rock.tensileStrengthValue)
                    this.blastConditionList[7].value = this.chkNull(conditionInfo.rock.rockfactorValue)
                } else {
                    this.blastConditionList[5].value = '-'
                    this.blastConditionList[6].value = '-'
                    this.blastConditionList[7].value = '-'
                }
                let centerLocation = conditionInfo.centerLocation
                if (centerLocation != null) {
                    centerLocation = centerLocation.split(',')
                    let latValue = Number(centerLocation[0])
                    let lngValue = Number(centerLocation[1])

                    that.mapBlastZoom = 17
                    that.mapBlastCenter = { lat: latValue, lng: lngValue }

                    that.markersBlast = []
                    that.markersBlast.push({
                        position: { lat: latValue, lng: lngValue },
                        draggable: false,
                        label: '',
                        labelInfo: {
                            blastInfo: conditionInfo.blastName+' ('+conditionInfo.holeCount+')',
                            pitName: conditionInfo.pitName,
                            blastDate: conditionInfo.blastDate,
                        }
                    })
                }

                let locations = conditionInfo.locations
                if (locations != null) {
                    that.polygonPaths = []
                    locations = locations.replaceAll('}','')
                    locations = locations.replaceAll('{','')
                    locations = locations.split(',')

                    let latValue, lngValue
                    locations.forEach(function (el, index) {
                        if (index%2==0) {
                            latValue = Number(el)
                            lngValue = ''
                        }else{
                            lngValue = Number(el)
                            that.polygonPaths.push({ lat: latValue, lng: lngValue })
                        }
                    })
                }
            }else{
                utils.showToastRed('failed to load BlastCondition data...');
            }

            this.spinnerFlag = false
        },
        async getBlastPattern() {
console.log('getBlastPattern...')
            let that = this
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/summary/"+blastId+"/blast-pattern"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.dataList != undefined) {
                let patternInfo = this.dataList

                this.blastPatternList[0].value = this.chkNull(patternInfo.designHoleCount)
                this.blastPatternList[1].value = patternInfo.blastPatternTypeName
                this.blastPatternList[2].value = this.chkNull(patternInfo.burdenSpacing)
                this.blastPatternList[3].value = this.chkNull(patternInfo.designVolumnCount)
                this.blastPatternList[4].value = this.chkNull(patternInfo.benchHeightValue)
                this.blastPatternList[5].value = this.chkNull(patternInfo.pfValue)

                let centerLocation = patternInfo.centerLocation
                if (centerLocation != null) {
                    centerLocation = centerLocation.split(',')
                    let latValue = Number(centerLocation[0])
                    let lngValue = Number(centerLocation[1])

                    that.mapHoleZoom = 21
                    that.mapHoleCenter = { lat: latValue, lng: lngValue }
                }

                that.markersHole = []
                patternInfo.holeDesign.forEach (function (el) {
                    that.markersHole.push({
                        holeId: el.holeId,
                        position: { lat: el.pointXValue, lng: el.pointYValue },
                        radius: 1,
                        draggable: false,
                        label: '',
                        labelInfo: {
                            '01': { text: ''+el.holeName, color: 'red', fontSize: '6px' },
                            '02': { text: ''+(el.timing!=null?el.timing:'-'), color: 'blue', fontSize: '6px' },
                            '03': { text: ''+(el.delay!=null?el.delay:'-'), color: 'green', fontSize: '6px' },
                        },
                        icon: {
                            url: 'img/gmap/map_designed.png',
                            labelOrigin: { x: 12, y: 20 }
                        }
                        // options: { strokeColor: '#FFFFFF', strokeWeight: 0.1,
                        //     fillColor: 'YELLOW', fillOpacity: 0.15
                        // },
                        // icon: {
                        //     path: 0, //this.google.maps.SymbolPath.CIRCLE,
                        //     strokeColor: 'YELLOW',
                        //     scale: 1.3,
                        // }
                    })
                })
//console.log(that.markersHole)
            }else{
                utils.showToastRed('failed to load BlastPattern data...');
            }
            this.spinnerFlag = false
        },
        async getDrilling() {
console.log('getDrilling...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/summary/"+blastId+"/drilling"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.interfaceStatus.drilling = 'gray'
            if (this.status=='200' && this.dataList != undefined) {
                let drillingInfo = this.dataList[0]

                this.drillingList[0].value = this.chkNull(drillingInfo.drilledHole)
                this.drillingList[1].value = this.chkNull(drillingInfo.totalDrillLength)
                this.drillingList[2].value = this.chkNull(drillingInfo.averageDrillLength)
                this.drillingList[3].value = this.getSecondsTohhmm(drillingInfo.totalWorkSecond)
                this.drillingList[4].value = this.chkNull(drillingInfo.diameterValue)
                this.drillingList[5].value = this.chkNull(drillingInfo.cost)

                if (drillingInfo.drillingStatusCode=='CODE0108') {
                    this.interfaceStatus.drilling = 'green'
                } else if (drillingInfo.drillingStatusCode=='CODE0109') {
                    this.interfaceStatus.drilling = 'yellow'
                }
            }
            this.spinnerFlag = false
        },
        async getCharging() {
console.log('getCharging...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/summary/"+blastId+"/charging"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.interfaceStatus.charging = 'gray'
            if (this.status=='200') {
                let chargingInfo = this.dataList[0]
                if (chargingInfo != undefined) {
                    try {
                        this.chargingList[0].value = this.chkNull(chargingInfo.totalChargeWeight)
                        this.chargingList[1].value = this.chkNull(chargingInfo.averageChargeWeight, 3)
                        this.chargingList[2].value = this.chkNull(chargingInfo.averageChargeDensity)
                        this.chargingList[3].value = this.getSecondsTohhmm(chargingInfo.totalWorkSecond)
                        this.chargingList[4].value = this.chkNull(chargingInfo.pfValue)
                        this.chargingList[5].value = this.chkNull(chargingInfo.bulk)

                        if (chargingInfo.chargingStatusCode=='CODE0108') {
                            this.interfaceStatus.charging = 'green'
                        } else if (chargingInfo.chargingStatusCode=='CODE0109') {
                            this.interfaceStatus.charging = 'yellow'
                        }
                    } catch (error) {
                        console.log(error)
                    }
                }
            }
            this.spinnerFlag = false
        },
        async getFiring() {
console.log('getFiring...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "v1/blast-library/"+siteId+"/summary/"+blastId+"/firing"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.interfaceStatus.firing = 'gray'
            if (this.status=='200') {
                let firingInfo = this.dataList[0]
                if (firingInfo != undefined) {
                    this.firingList[0].value = this.chkNull(firingInfo.detonator)
                    this.firingList[1].value = this.chkNull(firingInfo.lastFiringTiming)
                    this.firingList[2].value = this.chkNull(firingInfo.mic)
                    this.firingList[3].value = this.chkNull(firingInfo.fume)
                    this.firingList[4].value = this.chkNull(firingInfo.misfire)
                    this.firingList[5].value = this.chkNull(firingInfo.reliefValue)

                    let firingFlag = false
                    this.firingList.forEach(function (el, idx) {
                        if (idx > 0 && el.value != null) firingFlag = true
                    })

                    if (firingFlag) this.interfaceStatus.firing = 'green'
                }
            }
            this.spinnerFlag = false
        },
        async getFragmentation() {
console.log('getFragmentation...')
            let that = this
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "v1/blast-library/"+siteId+"/summary/"+blastId+"/fragmentation"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.interfaceStatus.fragmentation = 'gray'
            if (this.status=='200') {
                let fragmentation = this.dataList[0]
                if (fragmentation != undefined) {
                    this.fragmentationList[0].value = this.chkNull(fragmentation.targetD50, 7)
                    this.fragmentationList[1].value = this.chkNull(fragmentation.expectedD50, 7)
                    this.fragmentationList[2].value = this.chkNull(fragmentation.actualD50, 7)
                    this.fragmentationList[3].value = this.chkNull(fragmentation.uniformity, 3)

                    if (fragmentation.expectedD50!=null || fragmentation.actualD50!=null || fragmentation.uniformity!=null) {
                        this.interfaceStatus.fragmentation = 'green'
                    }
                }
            }

            // fragmentation chart
            moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/fragmentations/keyparameter"
            payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)
            if (that.data.content != null) {
                // chart
                let chart = that.data.content.chart
                let chartData = {}

                chartData.target = 'D50'
                chartData.value1 = Number(chart.actual)
                chartData.value2 = Number(chart.expected)

                that.xyHorizontalChartData.data[0] = chartData
                that.amChartXYHorizontalCompId += 1

                this.interfaceStatus.fragmentation = 'green'
            }

            that.spinnerFlag = false
        },
        async getVibration() {
console.log('getVibration...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "v1/blast-library/"+siteId+"/summary/"+blastId+"/vibration"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.interfaceStatus.vibration = 'gray'
            if (this.status=='200') {
                let vibration = this.dataList
                let centerLocation = vibration.centerLocation
                let distance
                if (centerLocation != '' && centerLocation != null) {
                    let centerLocationArr = centerLocation.split(',')
                    const start = {
                        latitude: Number(centerLocationArr[0].trim()),
                        longitude: Number(centerLocationArr[1].trim())
                    }
                    let distanceComp = 0
                    vibration.geophoneList.forEach(function (el, index) {
                        let end = {
                            latitude: Number(el.latitudeValue),
                            longitude: Number(el.longitudeValue)
                        }

                        distance = (haversine(start, end)*1000).toFixed(2)
                        if (index > 0 && distance > distanceComp) distance = distanceComp
                        distanceComp = distance
                    })
                }

                this.vibrationList[0].value = this.chkNull(distance)
                this.vibrationList[1].value = this.chkNull(vibration.targetPvs)
                this.vibrationList[2].value = this.chkNull(vibration.predictedPvs)
                this.vibrationList[3].value = this.chkNull(vibration.actualPvs)
                this.vibrationList[4].value = this.chkNull(vibration.sound)

                if (vibration.actualPvs!=null || vibration.sound!=null) {
                    this.interfaceStatus.vibration = 'green'
                }
            }

            this.spinnerFlag = false
        },
        async getProductivity() {
console.log('getProductivity...')
            let that = this
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "v1/blast-library/"+siteId+"/summary/"+blastId+"/cost"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let chartData = []
            this.productivityCostList.forEach(function (el) {
                el.value = ''
            })

            this.interfaceStatus.productivity = 'gray'
            if (this.status=='200') {
                let productivity = this.dataList
                if (productivity != undefined) {
                    this.productivityCostList[0].value = this.chkNull(productivity.drillMeter)
                    this.productivityCostList[1].value = this.chkNull(productivity.drillCost)
                    this.productivityCostList[2].value = this.chkNull(productivity.productCost)
                    this.productivityCostList[3].value = this.chkNull(productivity.laborCost)
                    this.productivityCostList[4].value = this.chkNull(productivity.extraCost)
                    this.productivityCostList[5].value = this.chkNull(productivity.blastVolumn)
                    this.productivityCostList[6].value = this.chkNull(productivity.blastCost)

                    let productivityFlag = false
                    this.productivityCostList.forEach(function (el) {
                        if (el.value != '-' && el.value > 0 ) productivityFlag = true
                    })
                    if (productivityFlag) this.interfaceStatus.productivity = 'yellow'

                    chartData.push({ country: 'drillCost', litres: productivity.chart.drillCost })
                    chartData.push({ country: 'productCost', litres: productivity.chart.productCost })
                    chartData.push({ country: 'laborCost', litres: productivity.chart.laborCost })
                    chartData.push({ country: 'extraCost', litres: productivity.chart.extraCost })
                }
            }

            this.pieChartDataTotal = 0
            chartData.forEach(function (el) {
                if (el.litres != '' && el.litres != '-' && el.litres != 0) that.pieChartDataTotal += Number(el.litres)
            })
            if (this.pieChartDataTotal > 0) this.interfaceStatus.productivity = 'green'

            this.pieChartData.data = chartData
            this.amChartPieHoverCompId += 1

            this.spinnerFlag = false
        },
        setMarker(type) {
            let that = this
            //let radioType = this.form.radioType
            let labelView = false

            if (type=='radio') {
                let latValue = this.mapHoleCenter.lat
                let lngValue = this.mapHoleCenter.lng
                let myLatLng = new google.maps.LatLng(latValue, lngValue)

                this.mapHole.setZoom(21)
                this.mapHole.setCenter(myLatLng)
            }
            if (this.mapHole.getZoom() >= 19) labelView = true

            that.markersLabel = []
            this.markersHole.forEach(function (el) {
                if (labelView) {
                    if (that.checkbox_check==0) el.label = ''
                    else {
                      that.checkbox_check.forEach(function (value, index) {
                        let iconInfo = {
                            url: 'img/gmap/map_designed.png',
                            labelOrigin: { x: 12, y: 20 }
                        }
                        if (value=='01') iconInfo.labelOrigin = { x: 12, y: 20 }
                        else if (value=='02') iconInfo.labelOrigin = { x: 12, y: -8 }
                        else if (value=='03') iconInfo.labelOrigin = { x: 20, y: 5 }

                        if (index==0) {
                            el.label = el.labelInfo[value]
                            el.icon = iconInfo
                        } else {
                            that.markersLabel.push({
                                position: { lat: el.position.lat, lng: el.position.lng },
                                radius: 1,
                                label: el.labelInfo[value],
                                icon: iconInfo
                            })
                        }
                      })
                    }
                } else el.label = ''
            })
        },
        InfoWindowOver(marker) {
            this.infoWindowPos = marker.position
            this.infoWindows.blastInfo = marker.labelInfo.blastInfo
            this.infoWindows.pitName = marker.labelInfo.pitName
            this.infoWindows.blastDate = marker.labelInfo.blastDate

            this.infoWinOpen = true
        },
        blastClick(blastInfo) {
            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.setBlastInfoAction(this.blastInfo)
            this.pageReload()
        },
        getSecondsTohhmm(totalSeconds) {
            var hours   = Math.floor(totalSeconds / 3600);
            var minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);

            var result = ''
            if (hours > 0) result += hours + '시간 '
            if (minutes > 0) result += minutes + '분'

            return result
        },
        getInterfaceStatus(tab, status) {
            let tabInfo = this.interfaceStatus[tab]

            if (tabInfo==status) return true
            else return false
        },
        reportEdit() {
            this.drillingResultData = false
            this.chargingResultData = false
            this.FiringResultData = false
            this.FragmentationData = false
            this.VibrationData = false
            this.ProductivityCostData = false

            // 랜더링 처리
            this.resultDataCompId += 1
            // edit 레이어 오픈
            this.$refs.editModal.open()
        },
        // google mini map
        updateBlastCenter(newCenter) {
            // minimap과 전체map 위치 맞춤
            console.log('center changed!!!')

            // map drag slow 이슈 (소수점 값이너무많아 drag 느려짐)
            // map drag시 snap 발생
            // this.mapBlastCenter = {
            //     lat: Number( newCenter.lat().toFixed(2) ),
            //     lng: Number( newCenter.lng().toFixed(2) )
            // }
        },
        changeMapBlastType() {
            // map type 변경
            console.log('map change!!', this.mapBlastOptions.mapTypeId)

            this.mapBlastOptions.mapTypeId==="satellite" ? this.mapBlastOptions.mapTypeId = "roadmap" : this.mapBlastOptions.mapTypeId = "satellite"
            this.miniMapBlastOptions.mapTypeId==="roadmap" ? this.miniMapBlastOptions.mapTypeId = 'satellite' : this.miniMapBlastOptions.mapTypeId = 'roadmap'
        },
        updateHoleCenter(newCenter) {
            // minimap과 전체map 위치 맞춤
            console.log('center changed!!!')
            // console.log('center changed!!!', newCenter)

            // map drag slow 이슈 (소수점 값이너무많아 drag 느려짐)
            // map drag시 snap 발생
            // this.mapHoleCenter = {
            //     lat: Number( newCenter.lat().toFixed(2) ),
            //     lng: Number( newCenter.lng().toFixed(2) )
            // }
        },
        changeMapHoleType() {
            // map type 변경
            console.log('map change!!', this.mapHoleOptions.mapTypeId)

            this.mapHoleOptions.mapTypeId==="satellite" ? this.mapHoleOptions.mapTypeId = "roadmap" : this.mapHoleOptions.mapTypeId = "satellite"
            this.miniMapHoleOptions.mapTypeId==="satellite" ? this.miniMapHoleOptions.mapTypeId = 'roadmap' : this.miniMapHoleOptions.mapTypeId = 'satellite'
        },
        checkboxClick(event, item) {
          if (event) this.checkbox_check.push(item.value)
          else {
              this.checkbox_check.splice(this.checkbox_check.indexOf(item.value), 1)
          }
          this.checkbox_check.sort()

          this.setMarker('radio')
        },
        radioClick(event) {
            this.form.radioType = event
            this.setMarker('radio')
        },
        submitChk(type) {
            if (type=='drilling') this.getDrilling()
            else if (type=='charging') this.getCharging()
            else if (type=='firing') this.getFiring()
            else if (type=='fragmentation') this.getFragmentation()
            else if (type=='vibration') this.getVibration()
            else if (type=='productivity') this.getProductivity()
        },
        closeEditPop() {
            this.$refs.editModal.close()
        },
        addMapHoleZoomChanged() {
            this.setMarker('zoom')
        },
        getEmptyForm() {
            return {
                radioType: ''
            }
        },
        chkNull(val, fixed) {
            if (val == null) return "-"
            else if (fixed == undefined) return utils.setDecimal(val)
            else if (val != 0) return utils.setDecimal(val, fixed)
            else return utils.setDecimal(val)
        },
    }
}
</script>
<style lang="scss" scoped>
.list-tit{
    font-weight: 500;
}
.blast-pt-mb{
    margin-bottom: 0;
    min-height: 120px;
}
.vibration-mb{
    margin-bottom: 0;
    min-height: 202px;
}
.firing-mb{
    margin-bottom: 0;
    min-height: 172px;
}
.fragmentation-mb{
    margin-bottom: 0;
    min-height: 202px;
}
</style>