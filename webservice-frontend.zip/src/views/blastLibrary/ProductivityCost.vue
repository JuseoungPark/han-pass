<template>
<CCard class="print-pc">
    <CCardBody class="line-none">
        <CRow id="printPage">
            <!-- spinner -->
            <div class="spinner-wrap" v-if="spinnerFlag">
                <div class="sk-wave">
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                </div>
            </div>
            <!-- //spinner -->
            <CCol lg="12" class="position-relative">
                <div class="btn-page-event-wrap absolute-wrap">
                    <!-- <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton> -->
                    <!-- excel download -->
                    <a href="download/sample.xlsx" download class="btn btn-excel btn-dark btn-sm " title="excel download">
                        <CImg src="img/excel.png"
                            class="icon-down"
                        />
                    </a>
                    <CButton type="button" size="sm" color="dark" class="btn-print ml-1 d-md-down-none" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                </div>
                <!-- <CCard> -->
                    <div class="pb-4">
                        <CCol lg="12" class="px-0">
                        <!-- 공통 tab -->
                        <div class="tab-content blast-main-tabs cost">
                            <ul class="nav nav-tabs">
                                <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                    <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 6}">{{ item.name }}</a>
                                </li>
                            </ul>
                        </div>
                        <!-- // 공통 tab -->
                        </CCol>
                        <CRow class="value-info-wrap mt-4">
                            <!-- blast name -->
                            <CCol lg="3">
                                <!-- <CCard class="mb-0"> -->
                                    <div class="box-unit main large position-relative">
                                        <app-icon name="blasts" size="xl" fill />
                                        <div class="text-wrap">
                                            <Strong class="d-block main-text">Blast Name</Strong>
                                            <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                        </div>
                                        <div class="list-unit">
                                            <BlastNameLists
                                                @blastClick="blastClick"
                                            />
                                        </div>
                                    </div>
                                <!-- </CCard> -->
                            </CCol>
                            <!-- // blast name -->
                            <CCol lg="9" class="lg-mt">
                                <BlastDataInfoProductivityCost :key="blastDataInfoProductivityCostId"
                                    ref="blastDataInfoProductivityCost"
                                    v-bind="blastInfo"
                                />
                            </CCol>
                        </CRow>
                    </div>
                <!-- </CCard> -->
            </CCol>
            <CCol>
                <!-- <CCard>
                    <CCardBody class="line-none"> -->
                <CRow>
                    <CCol lg="7">
                        <ProductivityComp :key="productivityCompId"
                            ref="productivityComp"
                            v-bind="blastInfo"
                        />
                    </CCol>
                    <CCol lg="5">
                        <CostComp :key="costCompId"
                            ref="costComp"
                            v-bind="blastInfo"
                        />
                    </CCol>
                </CRow>
                    <!-- </CCardBody>
                </CCard> -->
            </CCol>
        </CRow>
    </CCardBody>
</CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoProductivityCost from '@/views/blastLibrary/component/BlastDataInfoProductivityCost'
import ProductivityComp from '@/views/blastLibrary/component/ProductivityComp'
import CostComp from '@/views/blastLibrary/component/CostComp'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'

import utils from '@/assets/js/utils'

Vue.use(VueAxios, axios)

import { validationMixin } from "vuelidate"
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'ProductivityCost',
    components: {
        BlastNameLists,
        BlastDataInfoProductivityCost,
        ProductivityComp,
        CostComp,
        AppIcon
    },
    data() {
        return {
            pageName: 'ProductivityCost',
            spinnerFlag: false,
            blastDataInfoProductivityCostId: 0,
            productivityCompId: 0,
            costCompId: 0,
        }
    },
    async created() {
        if (this.blastInfo.blastId == 0) {
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
        }),
        pagePrint() {
            window.print()
        },
        // pageReload() {
        //     this.$router.go()
        // },
        blastClick(blastInfo) {
            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.blastDataInfoProductivityCostId += 1
            this.productivityCompId += 1
            this.costCompId += 1
        },
    }
}
</script>