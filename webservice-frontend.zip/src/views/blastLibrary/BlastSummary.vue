<template>
    <CCard>
        <CCardBody class="line-none">
            <CRow>
                <CCol lg="12">
                    <CRow>
                        <!-- spinner -->
                        <div class="spinner-wrap" v-if="spinnerFlag">
                            <div class="sk-wave">
                                <div class="sk-wave-rect"></div>
                                <div class="sk-wave-rect"></div>
                                <div class="sk-wave-rect"></div>
                                <div class="sk-wave-rect"></div>
                                <div class="sk-wave-rect"></div>
                            </div>
                        </div>
                        <!-- //spinner -->
                        <CCol>
                            <CCard class="header-card">
                                <CCardBody class="blasts-select-wrap line-none">
                                    <CRow>
                                        <CCol class="text-right">
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Pit</span>
                                                <div class="col-sm-9">
                                                    <multiselect
                                                        v-model="pitMulti"
                                                        :options="pitMultiselectOptions"
                                                        :multiple="true"
                                                        label="label"
                                                        track-by="label"
                                                    />
                                                </div>
                                            </div>
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Shot firer</span>
                                                <div class="col-sm-9">
                                                    <multiselect
                                                        v-model="fireMulti"
                                                        :options="fireMultiselectOptions"
                                                        :multiple="true"
                                                        label="label"
                                                        track-by="label"
                                                    />
                                                </div>
                                            </div>
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Detonator</span>
                                                <div class="col-sm-9">
                                                    <multiselect
                                                        v-model="detonatorMulti"
                                                        :options="detonatorMultiselectOptions"
                                                        :multiple="true"
                                                        label="label"
                                                        track-by="label"
                                                    />
                                                </div>
                                            </div>
                                        </CCol>
                                        <CCol class="text-right">
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Date Fired</span>
                                                <date-picker
                                                    ref="picker"
                                                    class="date-picker col-sm-9"
                                                    lang
                                                    v-model="dateSelect"
                                                    range
                                                >
                                                </date-picker>
                                                <!-- https://github.com/mengxiong10/vue2-datepicker -->
                                            </div>
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Elevation</span>
                                                <div class="col-sm-9">
                                                    <vue-slider
                                                        ref="sliderElevation"
                                                        v-model="searchElevationValue"
                                                        :process="true"
                                                        :contained="true"
                                                        :min="minElevationValue"
                                                        :max="maxElevationValue"
                                                        :silent="true"
                                                        :interval="1"
                                                        :process-style="{ backgroundColor: 'rgb(243, 115, 33)' }"
                                                        :tooltip-style="{ backgroundColor: 'rgb(248, 155, 108)', borderColor: 'rgb(248, 155, 108)' }"
                                                    >
                                                        <template v-slot:dot="{ searchElevationValue, focus }">
                                                            <div :class="['custom-dot', { focus }]"></div>
                                                        </template>
                                                    </vue-slider>
                                                </div>
                                                <!-- https://nightcatsama.github.io/vue-slider-component/#/ -->
                                            </div>
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">P.F</span>
                                                <div class="col-sm-9">
                                                    <vue-slider
                                                        ref="sliderPf"
                                                        v-model="searchPFValue"
                                                        :process="true"
                                                        :contained="true"
                                                        :min="minPFValue"
                                                        :max="maxPFValue"
                                                        :silent="true"
                                                        :interval="0.01"
                                                        :process-style="{ backgroundColor: 'rgb(243, 115, 33)' }"
                                                        :tooltip-style="{ backgroundColor: 'rgb(248, 155, 108)', borderColor: 'rgb(248, 155, 108)' }"
                                                    >
                                                        <template v-slot:dot="{ searchPFValue, focus }">
                                                            <div :class="['custom-dot', { focus }]"></div>
                                                        </template>
                                                    </vue-slider>
                                                </div>
                                                <!-- https://nightcatsama.github.io/vue-slider-component/#/ -->
                                            </div>
                                            <div class="form-row align-items-center mb-1">
                                                <span class="col-form-label col-sm-3 px-3">Hole</span>
                                                <div class="col-sm-9">
                                                    <vue-slider
                                                        ref="sliderHole"
                                                        v-model="searchHoleValue"
                                                        :process="true"
                                                        :contained="true"
                                                        :min="minHoleValue"
                                                        :max="maxHoleValue"
                                                        :silent="true"
                                                        :interval="1"
                                                        :process-style="{ backgroundColor: 'rgb(243, 115, 33)' }"
                                                        :tooltip-style="{ backgroundColor: 'rgb(248, 155, 108)', borderColor: 'rgb(248, 155, 108)' }"
                                                    >
                                                        <template v-slot:dot="{ searchHoleValue, focus }">
                                                            <div :class="['custom-dot', { focus }]"></div>
                                                        </template>
                                                    </vue-slider>
                                                </div>
                                                <!-- https://nightcatsama.github.io/vue-slider-component/#/ -->
                                            </div>
                                            <CButton ref="searchSubmit" type="submit" class="btn-custom-default hanwha outline" @click="onBlastSearch()">
                                                Search
                                            </CButton>
                                        </CCol>
                                    </CRow>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                </CCol>
                <CCol lg="12">
                    <!-- <CRow>
                        <CCol>
                            <CCard class="mb-0">
                                <CCardBody class="line-none"> -->
                                    <CRow>
                                        <CCol lg="6">
                                            <!-- data table -->
                                            <CDataTableCompWrapper
                                                :items="okData"
                                                v-if="okData.length!=0"
                                                class="data-table mb-0"
                                                hover
                                                striped
                                                border
                                                fixed
                                                @blastClick="blastClick"
                                                @markerClick="markerClick"
                                            />
                                            <div v-show="!okData.length" v-text="$t('message.noData')" style="padding-top:10px;" />
                                            <!-- //data table -->
                                        </CCol>
                                        <CCol lg="6">
                                            <CRow>
                                                <CCol lg="12" class="lg-mt">
                                                    <CCardGroup>
                                                        <!-- blast -->
                                                        <div class="card box-unit typeA large py-2">
                                                            <app-icon name="blasts" size="xl" fill />
                                                            <div class="text-wrap">
                                                                <Strong class="main-text">Blast</Strong>
                                                                <span class="sub-text">{{ headerBlasts }}</span>
                                                            </div>
                                                        </div>
                                                        <!-- hole -->
                                                        <div class="card box-unit typeA large py-2">
                                                            <app-icon name="noOfHole" size="xl" fill />
                                                            <div class="text-wrap">
                                                                <Strong class="main-text">No. of Holes</Strong>
                                                                <span class="sub-text">{{ headerHoles }}</span>
                                                            </div>
                                                        </div>
                                                    </CCardGroup>
                                                </CCol>
                                            </CRow>
                                            <div class="position-relative tooltip-style-wrap mt-3">
                                                <GmapMap
                                                    ref="mapRef"
                                                    :center="center"
                                                    :zoom="zoom"
                                                    :options="options"
                                                    style="height: 322px"
                                                >
                                                    <GmapInfoWindow
                                                        :options="infoOptions"
                                                        :position="infoWindowPos"
                                                        :opened="infoWinOpen"
                                                        @closeclick="infoWinOpen=false"
                                                        >
                                                        <div class="map-tooltip-typeA">
                                                            <div class="map-tooltip-contents">
                                                                <div class="blast">
                                                                    <div style="color:#fff">[ <span style="font-weight: bold;color:#fff">{{ infoWindows.infoContent }}</span> ]</div>
                                                                    <div style="padding-top:5px; color:#fff">Elevation : {{ infoWindows.infoElevaltion }}</div>
                                                                    <div style="color:#fff">Date : {{ infoWindows.infoDateDesigned }}</div>
                                                                    <div style="color:#fff">Lat : {{ infoWindows.infoLat }}</div>
                                                                    <div style="color:#fff">Lng : {{ infoWindows.infoLng }}</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </GmapInfoWindow>
                                                    <GmapMarker
                                                        :key="'blast-'+index"
                                                        v-for="(m, index) in markers"
                                                        :position="m.position"
                                                        :clickable="true"
                                                        :draggable="m.draggable"
                                                        :zIndex="index"
                                                        :label="m.label"
                                                        :icon="{ labelOrigin: {x:28, y:28}, url: 'http://labs.google.com/ridefinder/images/mm_20_orange.png' }"
                                                        @mouseover="InfoWindowOver(m, index)"
                                                    />
                                                    <GmapMarker
                                                        :position="blastPosition"
                                                        :clickable="true"
                                                        :draggable="false"
                                                        :zIndex="9999"
                                                        :icon="{ url: 'img/gmap/ic_blast_now.png' }"
                                                        @mouseover="InfoWindowOverRow()"
                                                    />
                                                    <GmapPolygon
                                                        :paths="polygonPaths"
                                                        :options="polygonOptions"
                                                    />
                                                </GmapMap>
                                                <!--
                                                <div class="select-wrap top absolute-layout">
                                                    <CSelect
                                                        class="mb-0"
                                                        :options="mapSearchOptions"
                                                    />
                                                </div>
                                                -->
                                                <div class="map-progress Vertical absolute-layout" style="top:2.5rem">
                                                    <vue-slider
                                                        ref="sliderMapElevation"
                                                        v-model="mapElevationValue"
                                                        :min="minMapElevationValue"
                                                        :max="maxMapElevationValue"
                                                        :process="true"
                                                        :height="220"
                                                        direction="btt"
                                                        @drag-end="onSliderElevation()"
                                                    >
                                                        <template v-slot:dot="{ mapElevationValue, focus }">
                                                            <div :class="['custom-dot-2', { focus }]"></div>
                                                        </template>
                                                    </vue-slider>
                                                </div>
                                                <div class="map-progress horizontal absolute-layout" style="width:calc(100% - 5rem)">
                                                    <vue-slider
                                                        ref="sliderMapTime"
                                                        v-model="mapTimeValue"
                                                        :min="minMapTime"
                                                        :max="maxMapTime"
                                                        stepVal="86400000"
                                                        :process="true"
                                                        :tooltip-formatter="formatter"
                                                        @drag-end="onSliderTime()"
                                                    >
                                                        <template v-slot:dot="{ mapTimeValue, focus }">
                                                            <div :class="['custom-dot-2', { focus }]"></div>
                                                        </template>
                                                    </vue-slider>
                                                </div>
                                            </div>
                                        </CCol>
                                    </CRow>
                                <!-- </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow> -->
                </CCol>
            </CRow>
        </CCardBody>
    </CCard>
</template>

<script>
import CDataTableCompWrapper from '@/views/blastLibrary/component/TableComp3'
import DatePicker from 'vue2-datepicker'
import VueSlider from 'vue-slider-component'
import Multiselect from 'vue-multiselect'
import AppIcon from '@/components/AppIcon'

import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import 'vue2-datepicker/index.css'
import 'vue-slider-component/theme/antd.css'
import 'vue-multiselect/dist/vue-multiselect.min.css'

//import moment from 'moment'
import moment from 'moment-timezone'
import utils from '@/assets/js/utils'

import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'BlastSummary',
    components: {
        CDataTableCompWrapper,
        DatePicker,
        VueSlider,
        Multiselect,
        AppIcon
    },
    data() {
        return {
            okData: [],

            dateSelect: null,
            spinnerFlag: false,

            searchElevationValue: [],
            minElevationValue: 0,
            maxElevationValue: 0,

            searchPFValue: [],
            minPFValue: 0,
            maxPFValue: 0,

            searchHoleValue: [],
            minHoleValue: 0,
            maxHoleValue: 0,

            mapElevationValue: [],
            minMapElevationValue: 0,
            maxMapElevationValue: 0,
            mapElevationMinValue: 0,
            mapElevationMaxValue: 0,

            mapTimeValue: [],
            minMapTime: 0,
            maxMapTime: 0,
            mapTimeMinValue: 0,
            mapTimeMaxValue: 0,

            headerPit: '-',
            headerShotFire: '-',
            headerBlasts: '-',
            headerHoles: '-',

            pitMulti: null, // Multiselect v-model
            pitMultiselectOptions: null,
            fireMulti: null, // Multiselect v-model
            fireMultiselectOptions: null,
            detonatorMulti: null, // Multiselect v-model
            detonatorMultiselectOptions: null,

            blastPosition: null,

            mapSearchOptions: [
                'View',
                'siteTypeOption-01',
                'siteTypeOption-02',
            ], //임시 selectbox data

            // google map start
            map: null,
            zoom: 2,
            center: { lat: 9.532600, lng: 160.024612 },
            markers: [],
            infoWindows: {
                infoContent: '',
                infoLink: '',
                infoDateDesigned: '',
                infoElevaltion: '',
                infoLat: '',
                infoLng: '',
            },
            infoWindowPos: {
                lat: 0,
                lng: 0
            },
            infoWinOpen: false,
            options: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                mapTypeControl: true,
                mapTypeId: "satellite",
                controlSize: 21,
            },
            infoOptions: {
                pixelOffset: {
                    width: 0,
                    height: -20
                }
            },

            polygonPaths: [],
            polygonOptions: {
                strokeColor: '#FF0000',
                strokeOpacity: 0.8,
                strokeWeight: 1,
                fillColor: '#FF0000',
                fillOpacity: 0.35
            },
            // google map end

            // slider 날짜 포맷 설정
            formatter: val => {
                let valDate = new Date(val).toDateString()
                return moment(valDate).format('YYYY-MM-DD')
            },

            rowItem: []
        }
    },
    async created() {
        // search Pit
        this.pitMultiselectOptions = []
        // search Shot fire
        this.fireMultiselectOptions = []
        // search Detonator
        this.detonatorMultiselectOptions = []

        // search Pit settting
        //this.pitMulti = [{ value: 'A', label: 'Pit A' }]

        // search Date fired
        const toDate = moment().format('YYYY-MM-DD')
        const fromDate = moment().add(-7,'days').format('YYYY-MM-DD')
        this.dateSelect = [ new Date(fromDate), new Date(toDate) ]

        // search ElevationValue
        this.minElevationValue = 0
        this.maxElevationValue = 100
        this.searchElevationValue = [ this.minElevationValue, this.maxElevationValue ]

        // search PFValue
        this.minPFValue = 0.00
        this.maxPFValue = 9.00
        this.searchPFValue = [ this.minPFValue, this.maxPFValue ]

        // search HoleValue
        this.minHoleValue = 0
        this.maxHoleValue = 100
        this.searchHoleValue = [ this.minHoleValue, this.maxHoleValue ]

        this.setBlastMarker('init', [])

        // map slider ElevationValue
        this.minMapElevationValue = this.minElevationValue
        this.maxMapElevationValue = this.maxElevationValue
        this.mapElevationValue = [ this.minMapElevationValue, this.maxMapElevationValue ]
        this.mapElevationMinValue = this.minMapElevationValue
        this.mapElevationMaxValue = this.maxMapElevationValue

        // map slider Date
        this.minMapTime = new Date(fromDate).getTime()
        this.maxMapTime = new Date(toDate).getTime()
        this.mapTimeValue = [ this.minMapTime, this.maxMapTime ]
        this.mapTimeMinValue = this.minMapTime
        this.mapTimeMaxValue = this.maxMapTime
    },
    mounted() {
        // 맵에 대한 정보 획득 및 zoom 이벤트 주입
        this.$refs.mapRef.$mapPromise.then((map) => {
            this.map = map;
            google.maps.event.addListener(this.map, 'zoom_changed', () => {
                this.addMapZoomChanged()
            })
        })

        // 맵 초기 셋팅
        this.gmapInit()
        // 검색 조건 셋팅
        this.searchDataInit()

        // 초기화
        let blastInfo = {}
        blastInfo.siteId = utils.getUserInformation().selectedUserSite.siteId
        blastInfo.blastId = 0
        blastInfo.blastName = ''
        this.setBlastInfoAction(blastInfo)
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
        //sliderStep() {
        //    return (this.maxPFValue - this.minPFValue) / 1000
        //}
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
            setBlastListAction: 'setBlastList',
        }),
        async gmapInit() {
console.log('gmapInit...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = utils.getUserInformation().selectedUserSite.siteId

            // 접속 사이트 보
            let moduleName = "v1/siteInfos/"+siteId+"/sites"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.status == '200' && this.data.content.length > 0) {
                let siteInfo = this.data.content[0]

                let latValue = Number(siteInfo.latitudeValue)
                let lngValue = Number(siteInfo.longitudeValue)

                this.zoom = 15
                this.center = { lat: latValue, lng: lngValue }
            }

            this.spinnerFlag = false
        },
        async searchDataInit() {
            this.spinnerFlag = true
console.log('searchDataInit...')
            // 입력값 설정
            let moduleName
            let params = new Array()
            let payload
            let siteId = utils.getUserInformation().selectedUserSite.siteId

            moduleName = "v1/select/pit"
            params.push("siteId="+siteId)
            payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            this.searchFormInit(moduleName, this.dataList)

            moduleName = "v1/select/worker"
            params.push("workerTypeCode=CODE0048")
            payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            this.searchFormInit(moduleName, this.dataList)

            moduleName = "v1/select/detonator"
            payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            this.searchFormInit(moduleName, this.dataList)

            moduleName = "v1/select/range/Blast"
            params = new Array()
            params.push("siteId="+siteId)
            payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            this.searchFormInit(moduleName, this.dataList)

            this.spinnerFlag = false

            // submit 검색 버튼 이벤트 발생
            //const elem = this.$refs.searchSubmit
            //elem.click()

            setTimeout(() => {
                this.onBlastSearch()
            }, 1000); // 1초
        },
        searchFormInit(type, data) {
            let that = this
            if (type.indexOf('pit') > -1) {
                that.pitMulti = []
                that.pitMultiselectOptions = []
                data.forEach(function (el) {
                   that.pitMultiselectOptions.push({ value: el.value, label: el.option })
                   that.pitMulti.push({ value: el.value, label: el.option })
                })
            }else if (type.indexOf('worker') > -1) {
                that.fireMulti = []
                that.fireMultiselectOptions = []
                data.forEach(function (el) {
                   that.fireMulti.push({ value: el.value, label: el.option })
                   that.fireMultiselectOptions.push({ value: el.value, label: el.option })
                })
                // 1개 인경우 기본 셋팅
                if (data.length == 1) that.fireMulti.push(that.fireMultiselectOptions[0])
            }else if (type.indexOf('detonator') > -1) {
                that.detonatorMulti = []
                that.detonatorMultiselectOptions = []
                data.forEach(function (el) {
                   that.detonatorMulti.push({ value: el.value, label: el.option })
                   that.detonatorMultiselectOptions.push({ value: el.value, label: el.option })
                })
                // 1개 인경우 기본 셋팅
                if (data.length == 1) that.detonatorMulti.push(that.detonatorMultiselectOptions[0])
            }else if (type.indexOf('range/Blast') > -1) {
                // search ElevationValue
                that.minElevationValue = data.elevationMin
                that.maxElevationValue = data.elevationMax
                that.searchElevationValue = [ that.minElevationValue, that.maxElevationValue ]

                // map ElevationValue
                that.minMapElevationValue = that.minElevationValue
                that.maxMapElevationValue = that.maxElevationValue
                that.mapElevationValue = [ that.minMapElevationValue, that.maxMapElevationValue ]
                that.mapElevationMinValue = that.minMapElevationValue
                that.mapElevationMaxValue = that.maxMapElevationValue

                // search PFValue
                that.minPFValue = data.pfMin
                that.maxPFValue = data.pfMax
                that.searchPFValue = [ that.minPFValue, that.maxPFValue ]

                // search HoleValue
                that.minHoleValue = data.holeMin
                that.maxHoleValue = data.holeMax
                that.searchHoleValue = [ that.minHoleValue, that.maxHoleValue ]
            }
        },
        // google map zoom event
        addMapZoomChanged() {
console.log('event.zoom_changed...')
        },
        // 초기 로딩시 맵에 blast list의 장소를 marker 한다.
        setBlastMarker(type) {
            // info window 닫기
            this.infoWinOpen = false

            let blastInfo = []
            let viewFlag = true

            let mapElevationMinValue = this.mapElevationMinValue
            let mapElevationMaxValue = this.mapElevationMaxValue
            let mapTimeMinValue = this.mapTimeMinValue
            let mapTimeMaxValue = this.mapTimeMaxValue

            if (type != 'init') {
                mapTimeMinValue = new Date(mapTimeMinValue).toDateString()
                mapTimeMinValue = moment(mapTimeMinValue).format('YYYY-MM-DD')

                mapTimeMaxValue = new Date(mapTimeMaxValue).toDateString()
                mapTimeMaxValue = moment(mapTimeMaxValue).format('YYYY-MM-DD')
            }
            // Blast List 초기화
            this.markers = []

            this.okData.forEach(function (el) {
                viewFlag = true
                if (type != 'init') {
                    // Elevaltion 범위 확인
                    let val = Number(el.elevaltion)
                    if (val >= mapElevationMinValue && val <= mapElevationMaxValue) viewFlag = true
                    else viewFlag = false

                    if (viewFlag) {
                        // Date 범위 확인
                        val = new Date(el.dateDesigned).toDateString()
                        val = moment(val).format('YYYY-MM-DD')

                        if (val >= mapTimeMinValue && val <= mapTimeMaxValue) viewFlag = true
                        else viewFlag = false
                    }
                }
                if (viewFlag) {
                    blastInfo.push({
                        blastId: el.blastId,
                        position: { lat: el.lat, lng: el.lng },
                        draggable: false,
                        label: '', //{text:'└ '+el.blastName, color:'red', fontSize:'6px'},
                        title: el.blastName,
                        elevaltion: el.elevaltion,
                        dateDesigned: el.dateDesigned,
                        lat: el.lat,
                        lng: el.lng
                    })
                }
            })
            this.markers = blastInfo

            if (blastInfo.length > 0) {
                this.zoom = 17
                this.center = { lat: blastInfo[0].position.lat, lng: blastInfo[0].position.lng }
            }
        },
        // blast list에서 blast name 클릭시
        blastClick(item) {
            let blastInfo = {}
            blastInfo.siteId = utils.getUserInformation().selectedUserSite.siteId
            blastInfo.blastId = item.blastId
            blastInfo.blastName = item.blastName+ '('+item.holes+')'
            blastInfo.lat = item.lat
            blastInfo.lng = item.lng

            this.setBlastInfoAction(blastInfo)

            this.$router.push({ path: `summaryReport` })
        },
        // blast list에서 marker icon 클릭시
        markerClick(item) {
            let that = this
            this.rowItem = item

            this.blastPosition = { lat: item.lat, lng: item.lng }
            this.zoom = 15
            this.center = this.blastPosition

            let locations = item.locations
            if (locations != null) {
                that.polygonPaths = []
                locations = locations.replaceAll('}','')
                locations = locations.replaceAll('{','')
                locations = locations.split(',')

                let latValue, lngValue
                locations.forEach(function (el, index) {
                    if (index%2 == 0) {
                        latValue = Number(el)
                        lngValue = ''
                    }else{
                        lngValue = Number(el)
                        that.polygonPaths.push({ lat: latValue, lng: lngValue })
                    }
                })
            }
            this.InfoWindowOverRow()
        },
        // 특정 blask 위치 아이콘 틀릭시
        InfoWindowOverRow() {
            let blastInfo = []
            blastInfo.push({
                blastId: this.rowItem.blastId,
                position: { lat: this.rowItem.lat, lng: this.rowItem.lng },
                draggable: false,
                label: '',
                title: this.rowItem.blastName,
                elevaltion: this.rowItem.elevaltion,
                dateDesigned: this.rowItem.dateDesigned,
                lat: this.rowItem.lat,
                lng: this.rowItem.lng,
            })
            this.InfoWindowOver(blastInfo[0], 0)
        },
        // 맵에서 마커 아이콘 마우스 오버 이벤트 발생 시
        InfoWindowOver(marker) {
            let flag = this.infoWinOpen
            if (flag && this.infoWindows.blastId==marker.blastId) flag = false
            else flag = true

            this.infoWinOpen = flag

            this.infoWindowPos = marker.position
            this.infoWindows.blastId = marker.blastId
            this.infoWindows.infoContent = marker.title
            this.infoWindows.infoLink = marker.www
            this.infoWindows.infoElevaltion = marker.elevaltion
            this.infoWindows.infoDateDesigned = marker.dateDesigned
            this.infoWindows.infoLat = marker.lat
            this.infoWindows.infoLng = marker.lng
        },
        // 검색 버튼 click
        async onBlastSearch() {
            this.spinnerFlag = true
            this.okData = []

            let params = new Array()
            let siteId = utils.getUserInformation().selectedUserSite.siteId

            params.push("siteId="+siteId)
            params.push("pagable=false")
            params.push("page=1")

            // Pit
            if (this.pitMulti != null) {
                let pitArr = ''
                this.pitMulti.forEach(function (el, index) {
                    if (index>0) pitArr += ','
                    pitArr += String(el.value)
                })
                if (pitArr!='') params.push("pitId=["+pitArr+']')
            }
            // fire
            if (this.fireMulti != null) {
                let fireArr = ''
                this.fireMulti.forEach(function (el, index) {
                    if (index>0) fireArr += ','
                    fireArr += String(el.value)
                })
                if (fireArr!='') params.push("shotfirerId=["+fireArr+']')
            }
            // detonator
            if (this.detonatorMulti != null) {
                let detonatorArr = ''
                this.detonatorMulti.forEach(function (el, index) {
                    if (index>0) detonatorArr += ','
                    detonatorArr += String(el.value)
                })
                if (detonatorArr!='') params.push("detonatorId=["+detonatorArr+']')
            }

            // Date Fired
            if (this.dateSelect != null) {
                let date_start = this.dateSelect[0]
                date_start = moment(date_start).format('YYYY-MM-DD')

                let date_end = this.dateSelect[1]
                date_end = moment(date_end).add(+1,'days').format('YYYY-MM-DD')

                const term = moment(date_end).diff(moment(date_start), 'days')

                params.push("firingDateFrom="+date_start)
                params.push("firingDateTo="+date_end)
            }

            // 검색조건 (Elevation)
            let elevation = this.$refs.sliderElevation.getValue()
            params.push("elevationFrom="+elevation[0])
            params.push("elevationTo="+elevation[1])

            // 검색조건 (P.F)
            let pf = this.$refs.sliderPf.getValue()
            params.push("pfFrom="+pf[0])
            params.push("pfTo="+pf[1])

            // 검색조건 (Hole)
            let hole = this.$refs.sliderHole.getValue()
            params.push("holeFrom="+hole[0])
            params.push("holeTo="+hole[1])

            // 검색조건에 대한 Blast 리스트 조회
            let moduleName = "v1/blast-library/"+siteId+"/blasts"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            // 검색 결과에 대한 Summary 셋팅
            //this.headerPit = this.data.pitCount.toString()
            //this.headerShotFire = this.data.shotfirerCount.toString()
            this.headerBlasts = '-'
            this.headerHoles = '-'
            this.setBlastListAction([])

            if (this.dataList.length != 0) {
                //this.$store.state.blastList = this.dataList
                this.setBlastListAction(this.dataList)

                let holes = 0
                let that = this
                that.dataList.forEach(function (item) {
                    holes += item.holeCount

                    let dateDesigned = moment(item.blastPlanDate).format('YYYY-MM-DD')
                    let dateFired = moment(item.blastDate).format('YYYY-MM-DD')

                    // 실 데이터로 수정 필요
                    let latValue = 37.549118
                    let lngValue = 128.968973

                    let centerLocation = item.centerLocation
                    if (centerLocation != null) {
                        centerLocation = centerLocation.split(',')
                        latValue = Number(centerLocation[0])
                        lngValue = Number(centerLocation[1])
                    }
                    let blastInfo = {
                        'blastName': item.blastName
                        ,'blastId': item.blastId
                        ,'dateDesigned': dateDesigned
                        ,'dateFired': dateFired
                        ,'pit': item.pitName
                        ,'elevaltion': item.elevationValue
                        ,'holes': item.holeCount
                        ,'shotFirer': item.shotfirerName
                        ,'P.F(kg/BCM)': item.pfValue
                        ,'Geometry(BxSxD,m)': item.geometryPattern
                        //,'lat': lat - (0.001 * index)
                        //,'lng': lng - (0.001 * index)
                        ,'lat': latValue
                        ,'lng': lngValue
                        ,'locations': item.locations
                    }
                    that.okData.push(blastInfo)
                })

                this.headerBlasts = utils.comma(this.dataList.length)
                this.headerHoles = utils.comma(holes)
            }
            this.spinnerFlag = false

            // 맵에서 위치 정보 최기화 셋팅
            this.setBlastMarker('init', [])
        },
        // 맵에서 좌측 elevation 드래그 이벤트 발생 시
        onSliderElevation() {
            let altitude = this.$refs.sliderMapElevation.getValue()

            this.mapElevationMinValue = altitude[0]
            this.mapElevationMaxValue = altitude[1]

            this.setBlastMarker('Elevation')
        },
        // 맵에서 하단 기간 드래그 이벤트 발생 시
        onSliderTime() {
            let time = this.$refs.sliderMapTime.getValue()

            this.mapTimeMinValue = time[0]
            this.mapTimeMaxValue = time[1]

            this.mapTimeMinValue = new Date(this.mapTimeMinValue).toDateString()
            this.mapTimeMinValue = moment(this.mapTimeMinValue).format('YYYY-MM-DD')

            this.mapTimeMaxValue = new Date(this.mapTimeMaxValue).toDateString()
            this.mapTimeMaxValue = moment(this.mapTimeMaxValue).format('YYYY-MM-DD')

            this.setBlastMarker('Time')
        },
    }
}
</script>
<style lang="scss" scoped>
    .custom-dot {
        width: 100%;
        height: 100%;
        border-radius: 0;
        border:2px solid rgb(251, 181, 132);
        background-color: #fff;
        transition: all .3s;
        &:hover{
            transform: rotateZ(45deg);
            border-color:rgb(243, 115, 33);
        }
        &.focus{
            border-radius: 50%;
            box-shadow: 0 0 0 5px rgba(243, 115, 33, 0.2);
        }
    }
    .custom-dot-2{
        width: 100%;
        height: 100%;
        border-radius: 0;
        border:2px solid #9cd5ff;
        background-color: #fff;
        transition: all .3s;
        &:hover{
            border-color:#36abff;
        }
        &.focus{
            border-radius: 50%;
            box-shadow: 0 0 0 5px rgba(54, 171, 255, 0.2);
        }
    }
</style>