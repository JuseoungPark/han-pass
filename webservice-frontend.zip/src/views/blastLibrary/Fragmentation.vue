<template>
<CCard class="print-frag">
    <CCardBody class="line-none">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <div>
            <!-- pdf-format="a3" -->
            <!-- pdf-orientation="landscape" -->
            <!-- filename="VibrationSound" -->
            <vue-html2pdf
                ref="html2Pdf"
                class="html2pdf-wrap"
                :show-layout="true"
                :float-layout="false"
                :enable-download="true"
                :preview-modal="true"
                :paginate-elements-by-height="1400"
                :pdf-quality="2"
                :manual-pagination="false"
                :html-to-pdf-options="htmlToPdfOptions"
                pdf-content-width="100%"
                @progress="onProgress($event)"
                @hasStartedGeneration="hasStartedGeneration()"
                @hasGenerated="hasGenerated($event)"
            >
            <section slot="pdf-content">
                <CRow id="printPage">
                    <CCol lg="12" class="position-relative">
                        <div class="btn-page-event-wrap absolute-wrap" data-html2canvas-ignore="true">
                            <!-- <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton> -->
                            <!-- pdf download -->
                            <!-- <a href="download/sample.pdf" download class="btn btn-dark btn-sm" title="pdf download"> -->
                            <button
                                @click="generateReport"
                                class="btn btn-dark btn-sm position-relative d-md-down-none"
                                title="pdf download">
                                <CImg src="img/pdf.png"
                                    class="icon-down"
                                />
                                <div v-if="progressBar >= 30"
                                    class="pdf-progress-wrap position-absolute">
                                    <div class="pdf-progress"><span class="pdf-progress-inner" :style="'width:' + progressBar + '%'"></span></div>
                                </div>
                            </button>
                            <CButton type="button" size="sm" color="dark" class="btn-print ml-1 d-md-down-none" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                        </div>
                        <!-- <CCard> -->
                            <div class="pb-4">
                                <CCol lg="12" class="px-0" data-html2canvas-ignore="true">
                                    <!-- 공통 tab -->
                                    <div class="tab-content blast-main-tabs fragmentation">
                                        <ul class="nav nav-tabs">
                                            <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                                <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 4}">{{ item.name }}</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- // 공통 tab -->
                                </CCol>
                                <CRow class="value-info-wrap mt-4">
                                    <!-- blast name -->
                                    <CCol lg="3">
                                        <!-- <CCard class="mb-0"> -->
                                            <div class="box-unit main large position-relative">
                                                <app-icon name="blasts" size="xl" fill />
                                                <div class="text-wrap">
                                                    <Strong class="d-block main-text">Blast Name</Strong>
                                                    <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                                </div>
                                                <div class="list-unit">
                                                    <BlastNameLists
                                                        @blastClick="blastClick"
                                                    />
                                                </div>
                                            </div>
                                        <!-- </CCard> -->
                                    </CCol>
                                    <!-- // blast name -->
                                    <CCol lg="9" class="lg-mt">
                                        <BlastDataInfoFragmentation :key="blastDataInfoFragmentationId"
                                            ref="blastDataInfoFragmentation"
                                            v-bind="blastInfo"
                                        />
                                    </CCol>
                                </CRow>
                            </div>
                        <!-- </CCard> -->
                    </CCol>
                    <CCol>
                        <CCard class="cont-wrap">
                            <CCardBody class="line-none">
                                <CRow>
                                    <CCol lg="5">
                                        <CCard class="mb-0">
                                            <!-- pdf viewer -->
                                            <!-- https://www.npmjs.com/package/vue-pdf -->
                                            <div class="pdf-view-wrap spinner">
                                                <VuePerfectScrollbar class="scroll-area" :settings="settings">
                                                    <pdf
                                                        v-for="i in numPages"
                                                        :key="i"
                                                        :src="src"
                                                        :page="i"
                                                        style="display: inline-block; width: 100%"
                                                    ></pdf>
                                                </VuePerfectScrollbar>
                                            </div>
                                            <!-- //pdf viewer -->
                                            <!--
                                            <div class="map-file-wrap spinner">
                                                <CImg :src="mapFilePath"
                                                    class="image data-image"
                                                />
                                            </div> -->
                                        </CCard>
                                    </CCol>
                                    <CCol lg="7">
                                        <CTabs variant="pills" :active-tab="0" class="lg-mt position-relative" @update:activeTab="activeTab">
                                            <CTab title="Key Parameters" sm="3">
                                                <FragmentationKeyTabComp :key="fragmentationKeyTabCompId"
                                                    ref="fragmentationKeyTabComp"
                                                    v-bind="blastInfo"
                                                />
                                            </CTab>
                                            <CTab title="Distribution Chart" sm="3">
                                                <FragmentationDistributionTabComp :key="fragmentationDistributionTabCompId"
                                                    ref="fragmentationDistributionTabComp"
                                                    v-bind="blastInfo"
                                                />
                                            </CTab>
                                        </CTabs>
                                    </CCol>
                                </CRow>
                            </CCardBody>
                        </CCard>
                    </CCol>
                </CRow>
            </section>
            </vue-html2pdf>
        </div>
    </CCardBody>
</CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoFragmentation from '@/views/blastLibrary/component/BlastDataInfoFragmentation'

import FragmentationKeyTabComp from '@/views/blastLibrary/component/FragmentationKeyTabComp'
import FragmentationDistributionTabComp from '@/views/blastLibrary/component/FragmentationDistributionTabComp'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
// import PDFViewer from '@/components/PDFViewer'

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import utils from '@/assets/js/utils'
import VueHtml2pdf from 'vue-html2pdf'
import pdf from 'vue-pdf'
import VuePerfectScrollbar from 'vue-perfect-scrollbar'

import moment from 'moment'

Vue.use(VueAxios, axios)

import { validationMixin } from "vuelidate"
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'Fragmentation',
    components: {
        BlastNameLists,
        BlastDataInfoFragmentation,

        AppIcon,
        VueHtml2pdf,
        pdf,
        VuePerfectScrollbar,
        FragmentationKeyTabComp,
        FragmentationDistributionTabComp,

        // PDFViewer
    },
    data() {
        return {
            blastDataInfoFragmentationId: 0,
            fragmentationDistributionTabCompId: 0,
            fragmentationKeyTabCompId: 0,

            settings: {// custom scroll
                maxScrollbarLength: 60
            },
            // pdf viewer
            //src: pdf.createLoadingTask('https://fragmentation-pdf.s3.ap-northeast-2.amazonaws.com/1/fragmentationpdf/1_1612487839308.pdf'),
            //src: pdf.createLoadingTask('pdf/After_fragreport.pdf'),
            src: '',
            numPages: undefined,
            // pdf viewer

            //VueHtml2pdf
            pageName: 'Fragmentation',
            pageStatus: true,
            spinnerFlag: false,

            progressBar: 0,
            htmlToPdfOptions: {
                margin: 0,
                filename: "Fragmentation",
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a3',
                    orientation: 'landscape',
                },
                pagebreak: {
                    // mode: ['avoid-all', 'css', 'legacy']
                    mode: ['avoid', 'css', 'legacy']
                },
                html2canvas: {
                    scale: 1,
                    useCORS: true,
                    allowTaint: false,
                    ignoreElements: (node) => {
                        return node.nodeName === 'IFRAME'
                    },
                    // svg image
                    onclone: (element) => {
                        const svgElements = Array.from(element.querySelectorAll('svg'))

                        svgElements.forEach(s => {
                            const bBox = s.getBBox()
                            s.setAttribute("x", bBox.x)
                            s.setAttribute("y", bBox.y)
                            s.setAttribute("width", bBox.width)
                            s.setAttribute("height", bBox.height)
                        })
                    }
                }
            },

            // image url
            mapFilePath: 'img/sample.jpg'
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
    },
    async created() {
        if (this.blastInfo.blastId == 0) {
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }else{
            await this.getPdfInfo()
        }
    },
    mounted() {
        // this.getPdfPages()
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
        }),
        getPdfPages() {
console.log('getPdfPages...')
            this.spinnerFlag = true

            // pdf viewer
            this.src.promise.then(pdf => {
                this.numPages = pdf.numPages
            })

            this.spinnerFlag = false
        },
        pagePrint() {
            window.print()
        },
        async getPdfInfo() {
console.log('getPdfInfo..')
            let that = this

            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/fragmentation"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            that.src = pdf.createLoadingTask('pdf/noData.pdf')

            that.data.content.forEach (function (el) {
                if (el.fileType == 'fragmentationpdf') {
console.log(el.filePath)
                    that.src = pdf.createLoadingTask(el.filePath)
                }
            })

            //that.src = pdf.createLoadingTask('https://cdn.rawgit.com/mozilla/pdf.js/c6e8ca86/test/pdfs/freeculture.pdf')
            //that.src = pdf.createLoadingTask('https://fragmentation-pdf.s3.ap-northeast-2.amazonaws.com/28/fragmentationpdf/31_1613706751849.pdf')
            //that.src = pdf.createLoadingTask('pdf/After_fragreport.pdf')
            //that.src = pdf.createLoadingTask('https://fragmentation-pdf.s3.ap-northeast-2.amazonaws.com/28/fragmentationpdf/28_1613606885442%2B(1).pdf')

            that.getPdfPages()
        },
        blastClick(blastInfo) {
            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.blastDataInfoFragmentationId += 1
            this.fragmentationDistributionTabCompId += 1
            this.fragmentationKeyTabCompId += 1

            this.getPdfInfo()
        },
        generateReport() {
            this.$refs.html2Pdf.generatePdf()
        },
        onProgress(progress) {
			this.progressBar = progress
            console.log(`PDF generation progress: ${progress}%`)

            if (progress == 100) {
                setTimeout(() => {
                    utils.showToast('PDF download is completed')
                    return this.progressBar = 0
                }, 1000)
            }
        },
        activeTab(index) {
            this.spinnerFlag = true
            setTimeout(() => {
                this.spinnerFlag = false
            }, 1500);
        },
    }
}
</script>
<style lang="scss" scoped>
.pdf-view-wrap{
    .scroll-area{
        position: relative;
        margin: 0;
        height: 576px;
        span{
            z-index: 1;
        }
    }
}
</style>