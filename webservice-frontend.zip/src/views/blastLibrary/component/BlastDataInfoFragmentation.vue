<template>
    <CRow>
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ fragmentationSummary.pitName }}</span>
                    </div>
                </div>
                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ fragmentationSummary.holes }}</span>
                    </div>
                </div>
                <!-- Target D50 -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="targetD50" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Target D50</Strong>
                        <span class="sub-text">{{ fragmentationSummary.target | SetDecimal }}</span>
                    </div>
                </div>
                <!-- Expected D50 -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="expectedD50" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Predicted D50</Strong>
                        <span class="sub-text">{{ fragmentationSummary.expected }}</span>
                    </div>
                </div>
                <!-- Actual D50 -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="actualD50" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Actual D50</Strong>
                        <span class="sub-text">{{ fragmentationSummary.actual | SetDecimal }}</span>
                    </div>
                </div>
                <!-- Fired time -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="firedTime" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Fired time</Strong>
                        <span class="sub-text small">{{ fragmentationSummary.time }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastDataInfoFragmentation',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            spinnerFlag: false,

            fragmentationSummary: {
                pitName: '-',
                holes: '-',
                target: '-',
                expected: '-',
                actual: '-',
                time: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setFragmentationSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setFragmentationSummary() {
            this.spinnerFlag = true
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 6
//blastId = 67
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/fragmentations/summary"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            if (this.dataList.length>0) {
                let fragmentations = this.dataList[0]

                this.fragmentationSummary.pitName = fragmentations.pitName
                this.fragmentationSummary.holes = fragmentations.holeCount
                this.fragmentationSummary.target = (fragmentations.targetD50!=null?fragmentations.targetD50:'-')
                this.fragmentationSummary.expected = (fragmentations.expectedD50!=null?fragmentations.expectedD50:'-')
                this.fragmentationSummary.actual = (fragmentations.actualD50!=null?fragmentations.actualD50:'-')

                let firedTime = '-'
                if (fragmentations.firedTime != null) {
                    firedTime = new Date(fragmentations.firedTime)
                    firedTime = moment(firedTime).format('YYYY-MM-DD HH:mm')
                }
                this.fragmentationSummary.time = firedTime
            }
            this.spinnerFlag = false
        }
    }
}
</script>