<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ chargingSummary.pitName }}</span>
                    </div>
                </div>

                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ chargingSummary.holes }}</span>
                    </div>
                </div>

                <!-- Charge weight (kg) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="weight" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Charge weight (kg)</Strong>
                        <span class="sub-text">{{ chargingSummary.chargeWeight }}</span>
                    </div>
                </div>

                <!-- P.F (kg/BCM) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="avgPf" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">P.F (kg/BCM)</Strong>
                        <span class="sub-text">{{ chargingSummary.pf }}</span>
                    </div>
                </div>

                <!-- Equipment -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="epuipment" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Equipment</Strong>
                        <span class="sub-text">{{ chargingSummary.equipment }}</span>
                    </div>
                </div>

                <!-- Work hour -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="workHours" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Work hour</Strong>
                        <span class="sub-text small">{{ chargingSummary.workHour }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import utils from '@/assets/js/utils'
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastDataInfoCharging',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            chargingSummary: {
                pitName: '-',
                holes: '-',
                chargeWeight: '-',
                pf: '-',
                equipment: '-',
                workHour: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setChargingSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setChargingSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 67
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/chargings/summary"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.dataList.length>0) {
                let summary = this.dataList[0]

                this.chargingSummary.pitName = summary.pitName
                this.chargingSummary.holes = summary.holeCount
                this.chargingSummary.chargeWeight = summary.chargeWeightValue
                this.chargingSummary.pf = summary.pf
                this.chargingSummary.equipment = summary.equipmentCount
                this.chargingSummary.workHour = this.getSecondsTohhmmss(summary.totalWorkSecond)

                summary.workHour = this.chargingSummary.workHour

                this.$emit('setSummaryInfo', summary)
            }
        },
        getSecondsTohhmmss(totalSeconds) {
            if (!totalSeconds) return '-'

            var hours   = Math.floor(totalSeconds / 3600);
            var minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);
            var seconds = totalSeconds - (hours * 3600) - (minutes * 60);

            // round seconds
            seconds = Math.round(seconds * 100) / 100

            var result = ''
            if (hours > 0) result += hours + '시간 '
            if (minutes > 0) result += minutes + '분 '
            if (hours == 0 && seconds > 0) result += seconds + '초'

            return result
        }
    }
}
</script>