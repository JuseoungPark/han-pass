<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ firingSummary.pitName }}</span>
                    </div>
                </div>

                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ firingSummary.holes }}</span>
                    </div>
                </div>

                <!-- Detonator -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="detonator" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Detonator</Strong>
                        <span class="sub-text">{{ firingSummary.detonator }}</span>
                    </div>
                </div>

                <!-- Last Firing timing -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="lastFiredTime" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Last Firing timing (ms)</Strong>
                        <span class="sub-text small">{{ firingSummary.lastTiming }}</span>
                    </div>
                </div>

                <!-- M.I.C (kg) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="avgInstantaneous" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">M.I.C (kg)</Strong>
                        <span class="sub-text">{{ firingSummary.mic }}</span>
                    </div>
                </div>

                <!-- Fired time -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="firedTime" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Fired time</Strong>
                        <span class="sub-text small">{{ firingSummary.firedTime }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastDataInfoFiring',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            firingSummary: {
                pitName: '-',
                holes: '-',
                detonator: '-',
                lastTiming: '-',
                mic: '-',
                firedTime: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setFiringSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setFiringSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/firings/summary"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
            if (this.dataList.length>0) {
                let firingSummary = this.dataList[0]

                this.firingSummary.pitName = firingSummary.pitName
                this.firingSummary.holes = (firingSummary.holeCount!=null?firingSummary.holeCount:0)
                this.firingSummary.detonator = (firingSummary.detonator!=null?firingSummary.detonator:'-')
                this.firingSummary.lastTiming = (firingSummary.lastFiringTiming!=null?firingSummary.lastFiringTiming:'-')
                this.firingSummary.mic = (firingSummary.mic!=null?firingSummary.mic:'-')

                let firedTime = '-'
                if (firingSummary.firedTime != null) {
                    firedTime = new Date(firingSummary.firedTime)
                    firedTime = moment(firedTime).format('YYYY-MM-DD HH:mm')
                }
                this.firingSummary.firedTime = firedTime
            }
        },
    }
}
</script>