<template>
    <div>
        <CDataTable
          :items="loadedItems"
          :fields="fields"
          :hover="hover"
          :striped="striped"
          :bordered="bordered"
          :small="small"
          :fixed="fixed"
        >
          <template #holeName="{item}">
            <td>
              <router-link to="/blastLibrary/drilling" @click.native="holeClick(item, $event)">
                {{ item.holeName }}
              </router-link>
              <button class="btn btn-dark btn-sm ml-3" @click="smallModalPop(item)">
                <CIcon name="cil-magnifying-glass" class="pop-diagram" />
              </button>
            </td>
          </template>
        </CDataTable>
        <sweet-modal
          ref="holeModal"
          blocking
          overlay-theme="dark"
          class="hole-modal-pop"
        >
          <CCard class="mb-0">
            <CCardHeader>
              <strong>Penetration Rate (m/min)</strong>
            </CCardHeader>
            <CCardBody class="line-none">
              <div class="hole-value-wrap">

                <!-- left contents -->
                <div class="hole-data-view">
                  <span class="info-text">Depth(m)</span>
                  <div class="hole-data-list__wrap">
                      <ul class="hole-data-list">
                          <li class="list"
                            v-for="(list, idx) in holeSampleData"
                            :key="idx">

                            <span class="data-box" 
                              :class="{
                                'red' : list === 'h',
                                'yellow' : list === 'm',
                                'green' : list === 's'
                              }"
                              :title="list === 'h' ? 'Hard' : list === 'm' ? 'Moderate' : list === 's' ? 'Soft' : ''"></span>
                            <span class="num-text first"
                              v-if="idx === 0">{{ idx }}</span>
                            <span class="num-text">{{ (idx + 1) * 2 }}</span>

                          </li>  
                      </ul>
                  </div>
                </div>

                <!-- right contents -->
                <div class="hole-data-view__info">

                  <div class="color-info">
                    <span class="title">Hardness</span>
                    <ul class="color-info-list">
                      <li class="list"
                        v-for="(list, idx) in colorInfo"
                        :key="idx"
                        :class="{
                          'red' : list === 'Hard',
                          'yellow' : list === 'Moderate',
                          'green' : list === 'Soft'
                          }">
                        {{ list }}
                      </li>
                    </ul>
                  </div>

                  <div class="single-table">
                    <span class="thead-th">AVE.PR</span>
                    <span class="tbody-td">
                      34.18 
                      <span class="unit ml-1">m/min</span>
                    </span>
                  </div>

                </div>
                  <!-- <AmChartStackedCustomComp
                    v-if="StackedChartData.data.length!=0"
                    chartHeight="500"
                    :chartData=StackedChartData
                  /> -->
              </div>
            </CCardBody>
          </CCard>
        </sweet-modal>
    </div>
</template>

<script>
import { SweetModal, SweetModalTab } from 'sweet-modal-vue'
import { mapGetters, mapActions } from 'vuex'

import utils from '@/assets/js/utils'
import moment from 'moment'

const AmChartStackedCustomComp = () => import(/* webpackChunkName: "popCharts" */ './AmChartStackedCustomComp')

const blastLibrary = 'blastLibrary'

export default {
    name: 'DataTableComp',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
        caption: {
            type: String,
            default: 'Table'
        },
        items: Array,
        hover: Boolean,
        striped: Boolean,
        bordered: Boolean,
        small: Boolean,
        fixed: Boolean,
        dark: Boolean,
        isClickable: Boolean,
    },
    components: {
        SweetModal,
        SweetModalTab,
        AmChartStackedCustomComp
    },
    data () {
        return {
            holeSampleData:['s','m','h','h','s','m','h','h','h','m'],
            colorInfo:['Soft', 'Moderate', 'Hard'],

            fields: [],
            loadedItems: this.items.slice(0),
            pages: Math.ceil(this.items.length / 5),
            // chart
            StackedChartData: { data:[] }
        }
    },
    async created() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data : 'getData',
            dataList : 'getDataList',
            selectedData : 'getSelectedData'
        }),
    },
    mounted() {
        this.dataFields()
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction : 'setDataList',
            setSelectedAction : 'setSelectedData',
        }),
        dataFields() {
            let fields = this.loadedItems
            let fieldsArr = Object.keys(fields[0])

            // 특정 컬럼 제외
            fieldsArr.splice(fieldsArr.indexOf('holeId'), 1)
            fieldsArr.splice(fieldsArr.indexOf('designPointXValue'), 1)
            fieldsArr.splice(fieldsArr.indexOf('designPointYValue'), 1)

            //return this.fields = Object.keys(fields[0])
            return this.fields = fieldsArr
        },
        async smallModalPop(item) {
            let that = this

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
            let holeId = item.holeId
//siteId = 1
//blastId = 57
//holeId = 2010
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/mwd-info/"+holeId
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            that.StackedChartData.data = []
            this.dataList.forEach(function (el, index) {
                let chartName = new Date(el.datetime)
                chartName = moment(chartName).format('YYYY-MM-DD HH:mm:ss')

                let color = '#F9EBEA'
                let minutes = Number(el.timeDiffSecond)
//minutes = Math.floor(Math.random() * 3600 + 1)
                minutes = Math.floor(minutes) / 60

                // Drilling 시간에 따른 강도 색상으로 표시
                if (minutes >= 60) color = '#641E16'
                else if (minutes >= 55) color = '#7B241C'
                else if (minutes >= 45) color = '#922B21'
                else if (minutes >= 40) color = '#A93226'
                else if (minutes >= 35) color = '#C0392B'
                else if (minutes >= 30) color = '#CD6155'
                else if (minutes >= 25) color = '#D98880'
                else if (minutes >= 20) color = '#E6B0AA'
                else if (minutes >= 10) color = '#F2D7D5'

//console.log(el.datetime+' / '+ new Date(el.datetime) +' / '+chartName)
                //if (index <= 9) {
                that.StackedChartData.data.push(
                    {
                        "name": chartName,
                        "value": el.lengthValue,
                        "color": color
                    }
                )
                //}
            })
//console.log(that.StackedChartData)
            this.$refs.holeModal.open()
        },
        // hole name클릭시 map에서 해당 hole zoom
        holeClick(item, that) {
          let selectSiblings = document.querySelectorAll('.select-table tr')

            selectSiblings.forEach( e => {
                e.classList.remove("selected")
            });
            that.path[2].classList.add("selected")

            this.$emit('holeClick', item)
        },
    }
}
</script>