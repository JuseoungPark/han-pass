<template>
    <div class="am-xy-chart" ref="chartxy" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)

export default {
    name: 'xySeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        seriesName:String,
        series2Name:String,
        targetColor:String,
        chartColor:String,
        chartHeight: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
                chart.svgContainer.measure()

                chart.data = addData.data

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30
                categoryAxis.renderer.labels.template.fill = am4core.color("#777")
                categoryAxis.renderer.labels.template.fontSize = 11

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxis.min = 0
                valueAxis.renderer.minGridDistance = 30
                valueAxis.renderer.labels.template.fill = am4core.color("#777")
                valueAxis.renderer.labels.template.fontSize = 11

            // Create series
            let series = chart.series.push(new am4charts.ColumnSeries())
                series.dataFields.valueY = "value1"
                series.dataFields.categoryX = "category"
                series.name = this.seriesName
                // series.clustered = false
                series.columns.template.strokeWidth = 0
                series.columns.template.opacity = 1
                series.columns.template.fill = am4core.color(this.targetColor)
                series.columns.template.width = am4core.percent(30)
                series.tooltipText = series.name + " : [bold]{valueY}[/]"
                series.cloneTooltip = false // Tooltip off
                series.showOnInit = false // animation off

            let series2 = chart.series.push(new am4charts.ColumnSeries())
                series2.dataFields.valueY = "value2"
                series2.dataFields.categoryX = "category"
                series2.name = this.series2Name
                // series2.clustered = false
                series2.columns.template.strokeWidth = 0
                series2.columns.template.fill = am4core.color(this.chartColor)
                series2.columns.template.width = am4core.percent(30)
                series2.tooltipText = series2.name + " : [bold]{valueY}[/]"
                series2.cloneTooltip = false // Tooltip off
                series2.showOnInit = false // animation off

            chart.cursor = new am4charts.XYCursor()
            chart.cursor.behavior = "panX"
            chart.cursor.xAxis = categoryAxis
            chart.cursor.fullWidthLineX = true
            chart.cursor.lineX.strokeWidth = 0
            chart.cursor.lineX.fill = am4core.color("#000")
            chart.cursor.lineX.fillOpacity = 0.1
            // chart.cursor.behavior = "selectX"
            chart.cursor.lineY.disabled = true

            chart.legend = new am4charts.Legend()
            chart.legend.useDefaultMarker = false
            chart.legend.position = "top"
            chart.legend.contentAlign = "right"
            chart.legend.marginBottom = 20
            chart.legend.fontSize = 11
            // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
}
</style>