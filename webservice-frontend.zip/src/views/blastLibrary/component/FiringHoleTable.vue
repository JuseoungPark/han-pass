<template>
  <div>
    <!-- 공통 table (component 안에 modal popup) -->
    <CTableCompWrapper
      :items="firingHoleTableData"
      v-if="firingHoleTableData.length != 0"
      class="select-table data-table mt-2"
      hover
      striped
      border
      fixed
      v-bind="blastInfo"
      @holeClick="holeClick"
    />
    <div
      v-show="!firingHoleTableData.length"
      v-text="$t('message.noData')"
      style="padding-top:10px;"
    />
  </div>
</template>

<script>
import CTableCompWrapper from "@/views/blastLibrary/component/TableComp2"
//import firingHoleTableData from '@/views/blastLibrary/dummyData/firingHoleTableData' //임시 data

export default {
  name: "FiringHoleTable",
  props: {
    siteId: {
      type: Number,
    },
    blastId: {
      type: Number,
    },
  },
  components: {
    CTableCompWrapper,
  },
  data() {
    return {
      firingHoleTableData: [],
      blastInfo: {
        siteId: 0,
        blastId: 0,
      },
    }
  },
  async created() {
    this.blastInfo.siteId = this.siteId
    this.blastInfo.blastId = this.blastId
  },
  async mounted() {
    //this.holeDataList()
  },
  methods: {
    holeClick(item) {
      this.$emit("holeClick", item)
    },
    // 부모 components에서 holeData로 처리 시
    childMethod(tableData) {
      let that = this
      let holeTable = []
      tableData.forEach(function(item) {
        let holeInfo = {
          holeName: item.holeName,
          holeId: item.holeId,
          deck: item.deckNo,
          detonator: that.chkNull(item.detonator),
          timing: that.chkNull(item.timing),
          status: that.chkNull(item.status),
          blasterId: that.chkNull(item.blasterId),
          shotfirer: that.chkNull(item.shotfirer),
          pointXValue: item.pointXValue,
          pointYValue: item.pointYValue,
        }
        holeTable.push(holeInfo)
      })

      that.firingHoleTableData = holeTable
    },
    chkNull(val, fixed) {
      if (val == null) return "No data"
      else if (fixed == undefined) return val
      else if (val != 0) return val.toFixed(fixed)
      else return val
    },
  },
}
</script>
