<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ summary.pitName }}</span>
                    </div>
                </div>
                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ summary.holes | NumUnitCutting }}</span>
                    </div>
                </div>
                <!-- Drill Meter (m) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="meter" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Drill Meter (m)</Strong>
                        <span class="sub-text">{{ summary.drillMeter | NumUnitCutting }}</span>
                    </div>
                </div>
                <!-- Blasted Volume -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="volume" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Blasted Volume</Strong>
                        <span class="sub-text">{{ summary.volume | NumUnitCutting }}</span>
                    </div>
                </div>
                <!-- Total cost -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="totalCost" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Total cost ({{ userSite.currencyName }})</Strong>
                        <span class="sub-text">{{ summary.totalCost | NumUnitCutting }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
import utils from '@/assets/js/utils'
export default {
    name: 'BlastDataInfoProductivityCost',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            summary: {
                pitName: '-',
                holes: '-',
                drillMeter: '-',
                volume: '-',
                totalCost: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setSummary()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
        userSite () {
        return utils.getUserInformation().selectedUserSite
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 6
//blastId = 67
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/costs/summary"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.dataList != null) {
                let productivity = this.dataList

                this.summary.pitName = productivity.pitName
                this.summary.holes = productivity.holeCount
                this.summary.drillMeter = (productivity.drillMeter!=null?productivity.drillMeter:'-')
                this.summary.volume = (productivity.volume!=null?productivity.volume:'-')
                this.summary.totalCost = (productivity.totalCost!=null?productivity.totalCost:'-')
            }
        }
    }
}
</script>