<template>
    <div>
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <ul class="list-unstyled half-layout my-2 bg-light-gary">
            <li><span class="list-tit">Work start  : </span>{{ operationSummary.workStart }}</li>
            <li><span class="list-tit">Work end : </span>{{ operationSummary.workEnd }}</li>
            <li><span class="list-tit">Operator : </span>{{ operationSummary.operator }}</li>
            <li><span class="list-tit">Work hour : </span>{{ operationSummary.workHour }}</li>
            <li><span class="list-tit">Bulk product : </span>{{ operationSummary.bulkProduct }}</li>
            <li><span class="list-tit">Density : </span>{{ operationSummary.density }}</li>
            <li><span class="list-tit">Powder Factor : </span>{{ operationSummary.powderFactor }}</li>
        </ul>
        <div class="operation-table-wrap data-table typeA">
            <div class="position-relative table-responsive">
                <fieldset>
                    <legend class="sr-only">Operation dataSet</legend>
                    <table class="table table-fixed table-bordered table-hover mb-0">
                        <thead>
                            <tr>
                                <th scope="col" rowspan="2"></th>
                                <th v-for="(value, index) in operationTitle" :key="index" scope="row" colspan="3">
                                    {{ value }}
                                </th>
                            </tr>
                            <tr>
                                <th v-for="(value, index) in operationSub" :key="index" scope="col">
                                    {{ value }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-nowrap">Total Charge</th>
                                <td v-for="(value, index) in tableHole" :key="index">
                                    {{ value | NumUnitCutting }}
                                </td>
                            </tr>
                            <tr>
                                <th class="text-nowrap">Average Charge</th>
                                <td v-for="(value, index) in tableAverage" :key="index">
                                    {{ value | NumUnitCutting }}
                                </td>
                            </tr>
                        </tbody>
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th v-for="(value, index) in operation2Sub" :key="index" scope="col">
                                    {{ value }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-nowrap">Charge accuracy</th>
                                <td v-for="(value, index) in table2Charge" :key="index">
                                    {{ value | NumUnitCutting }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </fieldset>
            </div>
        </div>
        <CRow class="mt-3">
            <CCol lg="12">
                <CCard class="mb-0">
                    <CCardHeader class="position-relative">
                        <div class="row">
                            <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                <div>
                                    <strong class="text-nowrap">Charge Accuracy</strong>
                                    <!-- <span class="text-nowrap ml-1">(Charge weight)</span> -->
                                </div>
                                <span class="text-right">
                                    <CSelect
                                        class="position-right-center right-1"
                                        style="width:80px;"
                                        :value.sync="categoryInterval"
                                        :options="categoryIntervalOptions"
                                        @change="changeStandrd($event)"
                                    />
                                    <!-- CInput
                                        placeholder=" 00.1~99.0"
                                        class="position-right-center right-1"
                                        style="width:90px;"
                                        maxlength="4"
                                        @focus="onFocus"
                                        @keyup="isNumberKey"
                                        v-model="categoryInterval"
                                    / -->
                                </span>
                                <!--span class="text-right">정확도 <span class="num">100</span>%</span-->
                            </div>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartCategoryComp :key="amChartCategoryCompId"
                            v-if="categoryChartData.data.length!=0"
                            isGuide
                            seriesName="Weight"
                            :chartData=categoryChartData
                        />
                        <div v-show="!categoryChartData.data.length" v-text="$t('message.noData')" />
                    </CCardBody>
                </CCard>
            </CCol>
            <!-- <CCol lg="5" class="lg-mt">
                <CCard class="mb-0">
                    <CCardHeader>
                        <div class="row">
                            <div class="col-md-12">
                                <strong class="text-nowrap">Standard column charge</strong>
                            </div>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <div>
                            <AmChartStackedCustomComp
                                v-if="stackedChartData.data.length!=0"
                                chartHeight="250"
                                labelsFontSize="11"
                                :chartData=stackedChartData
                            />
                        </div>
                    </CCardBody>
                </CCard>
            </CCol> -->
        </CRow>
    </div>
</template>

<script>
import moment from 'moment'
import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'

const AmChartCategoryComp = () => import(/* webpackChunkName: "chargeOperationCharts" */ './AmChartCategoryComp')
// const AmChartStackedCustomComp = () => import(/* webpackChunkName: "chargeOperationCharts" */ './AmChartStackedCustomComp')

const blastLibrary = 'blastLibrary'

export default {
    name: 'ChargeOperationTab',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartCategoryComp,
        // AmChartStackedCustomComp
    },
    data() {
        return {
            spinnerFlag: false,

            operationSummary: {
                workStart: '',
                workEnd: '',
                operator: '',
                workHour: '',
                bulkProduct: '',
                density: '',
                powderFactor: '',
            },
            amChartCategoryCompId: 0,

            operationTitle: [],
            operationSub: [],
            tableHole: [],
            tableAverage: [],

            operation2Sub: [],
            table2Charge: [],

            categoryInterval: '',
            categoryIntervalOptions: [
                { value: '1', label: '1kg' },
                { value: '2', label: '2kg' },
                { value: '5', label: '5kg' },
                { value: '10', label: '10kg' },
                { value: '20', label: '20kg' },
                { value: '50', label: '50kg' },
            ],

            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            categoryChartData: {
                data:[]
            },
            // stackedChartData: {
            //     data:[]
            // },
        }
    },
    created () {
        this.categoryInterval = this.categoryIntervalOptions[0].value
        if (this.blastId != 0) {
            this.setOperationTable()
            this.setAmChartCategoryComp()
            // this.setAmChartStackedCustomComp()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data : 'getData',
            dataList : 'getDataList',
            selectedData : 'getSelectedData'
        }),
    },
    mounted() {
        //
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction : 'setDataList',
            setSelectedAction : 'setSelectedData',
        }),
        onFocus() {
            this.categoryInterval = ''
        },
        isNumberKey(event) {
            let newValue = this.categoryInterval
            newValue = newValue.replace(/[^0-9.]/g,'')

            let pattern1 = /^\d{3}$/ // 현재 value값이 3자리 숫자이면 . 만 입력가능
            if (pattern1.test(newValue)) {
                this.categoryInterval = newValue.substring(0,2)
                utils.showToast('100이하의 숫자(00.1~99.0)만 입력 가능합니다.')  // Only numbers less than 100 (00.1~99.0) can be entered.

                return false
            }

            let pattern2 = /^\d*[.]\d{2}$/ // 현재 value값이 소수점 첫째짜리 숫자이면 더이상 입력 불가
            if (pattern2.test(newValue)) {
//console.log(newValue+' / '+(newValue.length-1))
                this.categoryInterval = newValue.substring(0,(newValue.length-1))
                utils.showToast('소수점 첫째자리까지만 입력가능합니다.')

                return false;
            }

            let pattern3 = /^\d*[.]\d{1}$/
            if (pattern3.test(newValue)) {
                // input box에 마우스 커서 삭제
                event.target.blur()

                this.categoryInterval = newValue
                this.setAmChartCategoryComp()
            }
//console.log(pattern3.test(newValue))
        },
        setOperationSummary(item) {
            let workStart = new Date(item.workStart)
            workStart = moment(workStart).format('YYYY-MM-DD HH:mm')

            let workEnd = new Date(item.workEnd)
            workEnd = moment(workEnd).format('YYYY-MM-DD HH:mm')

            this.operationSummary.workStart = workStart
            this.operationSummary.workEnd = workEnd
            this.operationSummary.operator = (item.operator!=null?item.operator:'-')
            this.operationSummary.workHour = (item.workHour!=null?item.workHour:'-')
            this.operationSummary.bulkProduct = (item.bulk!=null?item.bulk:'-')
            this.operationSummary.density = (item.density!=null?item.density:'-')
            this.operationSummary.powderFactor = (item.chargeWeightValue!=null?item.chargeWeightValue:'-')
        },
        async setOperationTable() {
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/chargings/operation"
            let payload = { params : params, moduleName : moduleName }
            await this.setDataListAction(payload)

            this.operationTitle = []
            this.operationSub = []

            this.tableHole = []
            this.tableAverage = []

            // 장비 1개 이상인 경우 Total값 처리
            if (this.data.content.length > 1) {
                this.setOperationTableInfo('Total', [this.data.total])
            }
            // 각 장비에 대한 처리
            this.setOperationTableInfo('Equipment', this.data.content)

            this.spinnerFlag = false
        },
        setOperationTableInfo(type, data) {
            let that = this
            data.forEach (function (el) {
                if (type == 'Total') that.operationTitle.push(type)
                else {
                    let equipmentName = (el.equipmentName!=null?el.equipmentName:'-')
                    that.operationTitle.push(equipmentName)
                }
                that.operationSub.push('Planned')
                that.operationSub.push('Actual')
                that.operationSub.push('Difference')

                that.tableHole.push(el.plan.totalCharge)
                that.tableHole.push(el.result.totalCharge)
                that.tableHole.push(el.diff.totalCharge)

                that.tableAverage.push(el.plan.averageCharge)
                that.tableAverage.push(el.result.averageCharge)
                that.tableAverage.push(el.diff.averageCharge)

                that.operation2Sub.push('Charge hole')
                that.operation2Sub.push('In tolerance')
                that.operation2Sub.push('Out of tolerance')

                that.table2Charge.push(el.chargedHoleCount)
                that.table2Charge.push(el.inTolerance)
                that.table2Charge.push(el.outOfTolerance)
            })
        },
        async setAmChartCategoryComp() {
            let that = this

            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let interval = this.categoryInterval
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/chargings/accuracy-weight/"+interval

            let payload = { params : params, moduleName : moduleName }
            await this.setDataListAction(payload)

            let categoryData = []
            let categoryChartData = []
            that.categoryChartData.data = []

            if (that.data.status == 200) {
                that.data.content.forEach (function (el) {
                    let intervalValue = Number(el.intervalValue).toFixed(1)
                    categoryData.push(intervalValue)

                    categoryChartData.push({ "category": intervalValue, "value": el.count })
                })
//console.log(that.categoryChartData.data)
                let categoryBase = []
                categoryData.forEach (function (el) {
                    categoryBase.push(el)

                    let categoryKey = 0
                    if (Math.sign(el) > 0) categoryKey = Number(el) * -1
                    else categoryKey = Math.abs(el)

                    if(!categoryData.includes(categoryKey)) {
                        categoryBase.push(categoryKey)
                    }
                })
//console.log(categoryBase)
                let min = Math.min.apply(Math, categoryBase)
                let max = Math.max.apply(Math, categoryBase)
//console.log(min, max)
                if (min == 0 && max == 0) {
                    min = -3
                    max = 3
                }

                let steps = Number(interval)  // '01.0'
//console.log(steps)
                for (var idx=min; idx<=max; idx+=steps) {
                    let idxKey = idx.toFixed(1)

                    if(!categoryData.includes(idxKey)) {
                        categoryChartData.push({ "category": idxKey, "value": 0 })
                    }
                }

                var sortingField = "category"  // a - b, b - a
                categoryChartData.sort(function(a, b) {
                    return a[sortingField] - b[sortingField];
                })

                that.categoryChartData.data = categoryChartData
                that.amChartCategoryCompIdx += 1
//console.log(that.categoryChartData.data)
            }
            that.spinnerFlag = false
        },
        changeStandrd(event) {
            this.categoryInterval = event.target.value

            this.setAmChartCategoryComp()
        },
//         async setAmChartStackedCustomComp() {
//             let that = this

//             that.spinnerFlag = true

//             let params = new Array()
//             let siteId = that.siteId
//             let blastId = that.blastId
// siteId = 1
// //blastId = 92
//             let moduleName = "blast-library/"+siteId+"/"+blastId+"/chargings/standard-column"
//             let payload = { params : params, moduleName : moduleName }
//             await this.setDataListAction(payload)
// console.log(that.data)
//             that.stackedChartData.data = []
//             if (that.data.status == 200) {
//                 if (that.data.content.length > 0) {
//                     that.stackedChartData.data.push({ "name": "stemmingLengthValue", "value": that.data.content[0].standard.stemmingLengthValue })
//                     that.stackedChartData.data.push({ "name": "chargeLength", "value": that.data.content[0].standard.chargeLength })
//                 }
//             }
//             that.spinnerFlag = false
//         }
    }
}
</script>
<style lang="scss" scoped>
.list-tit{
    font-weight: 700;
}
</style>