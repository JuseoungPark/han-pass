<template>
    <CDropdown
        placement="bottom-end"
        :caret="false"
        in-nav
        class="c-header-nav-item header-notif-wrap list-unstyled"
        add-menu-classes="pt-0"
    >
        <template #toggler>
            <CIcon name="cil-list-rich" />
        </template>
        <CDropdownHeader
            tag="div"
            class="text-center"
        >
            <strong>Blast List (Holes)</strong>
        </CDropdownHeader>
        <ul class="list-unstyled max-height140">
            <li>
                <CDropdownItem
                    :key="index" v-for="(m, index) in blastNameList"
                >
                    <span @click="blastClick(m)">{{ m.blastName }} ({{ m.holes }})</span>
                </CDropdownItem>
                <div v-show="!blastNameList.length" v-text="$t('message.noData')" class="info-txt" />
            </li>
        </ul>
    </CDropdown>
</template>

<script>
import utils from '@/assets/js/utils'

import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'BlastNameLists',
    data() {
        return {
            blastNameList: []
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
        }),
    },
    mounted() {
        let that = this
        if (this.blastList != undefined) {
            this.blastList.forEach(function (el) {
                let latValue = 0
                let lngValue = 0
                let centerLocation = el.centerLocation
                if (centerLocation != null) {
                    centerLocation = centerLocation.split(',')
                    latValue = Number(centerLocation[0])
                    lngValue = Number(centerLocation[1])
                }

                that.blastNameList.push({ blastId: el.blastId, blastName: el.blastName, holes: el.holeCount, lat: latValue, lng: lngValue })
            })
        }else{
            utils.showToastRed('$store.state.balstList load error...')
        }
    },
    methods: {
        ...mapActions(blastLibrary, {
            setBlastInfoAction: 'setBlastInfo',
        }),
        blastClick(item) {
            this.$emit('blastClick', item)
        },
    }
}
</script>