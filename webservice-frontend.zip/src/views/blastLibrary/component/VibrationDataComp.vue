<template>
    <CCard class="mb-0">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <CForm @submit.prevent>
            <CCardHeader>
                <strong>Vibration Data Import</strong>
            </CCardHeader>
            <CCardBody class="form-group-wrap">
                <CRow>
                    <CCol lg="6" class="data-table typeA table-max-height450">
                        <div class="datepicker-wrap align-items-center">
                            <!-- <span class="col-form-label col-sm-3">Date range</span> -->
                            <date-picker
                                class="date-picker"
                                lang
                                v-model="dateRange"
                                range
                                :editable="false"
                                >
                            </date-picker>
                            <!-- https://github.com/mengxiong10/vue2-datepicker -->
                            <CButton ref="searchSubmit" class="btn-custom-default hanwha outline" @click="onSearch()">
                                Search
                            </CButton>
                        </div>
                        <div class="table-responsive">
                            <fieldset>
                                <legend class="sr-only">Vibration Data Import table</legend>
                                <table class="table table-fixed table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-nowrap">File</th>
                                            <th class="text-nowrap">Serial Number</th>
                                            <th class="text-nowrap">Date</th>
                                        </tr>
                                    </thead>
                                    <!-- @click="fileClick(item)" style="cursor: pointer;"  -->
                                    <tbody>
                                        <tr v-for="(item, index) in sisFileList" :key="index">
                                            <td class="text-nowrap">{{ item.fileName }}
                                                <a @click="fileClick(item, 'down')" class="cursor-pointer" style="padding-left:5px;">
                                                    <CIcon name="cil-save" />
                                                </a>
                                                <a @click="fileClick(item, 'upload')" class="cursor-pointer" style="padding-left:5px;">
                                                    <CIcon name="cil-arrow-thick-from-left" />
                                                </a>
                                            </td>
                                            <td class="text-nowrap">{{ item.serialNumber }}</td>
                                            <td class="text-nowrap">{{ item.date }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </fieldset>
                        </div>
                    </CCol>
                    <CCol lg="6">
                        <ul class="data-dropdown-list list-unstyled h-scroll">
                            <li class="dropdown-list"
                                v-for="(item, idx) in fileList"
                                :key="idx">
                                <div class="title-wrap d-flex align-items-center justify-content-between" :class="{'nonEvent' : fileList.length === 1}" @click="dropdownSelect(idx)">
                                    <span>{{ item.geophoneName }}</span>
                                    <app-icon v-show="fileList.length > 1" :name="`${dropdownSelectNum == idx ? 'arrowTop' : 'arrowBottom'}`" size="sss" fill class="icon-arrow"/>
                                </div>
                                <transition name="fade">
                                    <CCollapse :show="fileList.length == 1 || dropdownSelectNum == idx" :duration="400" class="list-item p-3">
                                        <div role="group">
                                            <ul class="list-unstyled full-width">
                                                <li class="full-width">
                                                    <label class="col-form-label col-sm-12 px-0">{{ item.unitName }}
                                                        <span v-if="item.upFileStr != ''" @click="vibrationFileClick(item)" class="down-wrap">
                                                            <app-icon name="fileDown" size="s" fill class="ml-2" />{{ item.upFileStr }}
                                                        </span>
                                                    </label>
                                                    <div class="col-sm-12" style="padding-left:10px;">
                                                        <input :id="'drilling-file-add-0'+idx" type="file" class="custom-file-input custom"
                                                            v-on:input="process(idx, $event)">
                                                        <label :for="'drilling-file-add-0'+idx" class="custom-file-label">
                                                            {{ item.fileName }}
                                                            <span class="icon-wrap">
                                                                <CIcon name="cil-library-add" />
                                                            </span>
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="mt-3">
                                            <label :for="'actualPvs'+idx">Actual PVS</label>
                                            <div class="unit-input-wrap position-relative mb-3">
                                                <CInput
                                                    :id="'geophoneId'+idx"
                                                    type="hidden"
                                                    name="geophoneId[]"
                                                    v-model.trim="$v.form[idx].geophoneId.$model"
                                                    >
                                                </CInput>
                                                <CInput
                                                    :id="'fileId'+idx"
                                                    type="hidden"
                                                    name="fileIdId[]"
                                                    v-model.trim="$v.form[idx].fileId.$model"
                                                    >
                                                </CInput>
                                                <CInput
                                                    :id="'modifyFlag'+idx"
                                                    type="hidden"
                                                    name="modifyFlag[]"
                                                    v-model.trim="$v.form[idx].modifyFlag.$model"
                                                    >
                                                </CInput>
                                                <CInput
                                                    class="mb-0"
                                                    :id="'actualPvs'+idx"
                                                    placeholder="Please enter Actual PVS"
                                                    type="text"
                                                    name="actualPVS[]"
                                                    append="mm/s"
                                                    v-model.trim="$v.form[idx].actualPVS.$model"
                                                    @change="setModifyFlag(idx)"
                                                    :isValid="$v.form[idx].actualPVS.$dirty ? !$v.form[idx].actualPVS.$error : null">
                                                    <template slot="invalid-feedback">
                                                        <ValidFeedback :param="$v.form[idx].actualPVS" />
                                                    </template>
                                                </CInput>
                                            </div>
                                        </div>
                                        <div class="mt-3">
                                            <label :for="'actualSound'+idx">Actual Sound</label>
                                            <div class="unit-input-wrap position-relative mb-3">
                                                <CInput
                                                    class="mb-0"
                                                    :id="'actualSound'+idx"
                                                    placeholder="Please enter Actual Sound"
                                                    type="text"
                                                    name="actualSound[]"
                                                    append="dB"
                                                    v-model.trim="$v.form[idx].actualSound.$model"
                                                    @change="setModifyFlag(idx)">
                                                    <template slot="invalid-feedback">
                                                        <ValidFeedback :param="$v.form[idx].actualSound" />
                                                    </template>
                                                </CInput>
                                            </div>
                                        </div>
                                        <CTextarea
                                            label="Remark"
                                            placeholder="Please enter Remark"
                                            rows="4"
                                            class="mt-2"
                                            :maxlength="250"
                                            block
                                            name="remark[]"
                                            v-model.trim="$v.form[idx].remark.$model"
                                            @change="setModifyFlag(idx)">
                                            <template slot="invalid-feedback">
                                                <ValidFeedback :param="$v.form[idx].remark" />
                                            </template>
                                        </CTextarea>
                                    </CCollapse>
                                </transition>
                            </li>
                        </ul>
                    </CCol>
                </CRow>
            </CCardBody>
            <CCardFooter>
                <CButton type="submit"
                    class="btn-custom-default hanwha outline rectangle"
                    :disabled="!isValid"
                    @click="submit"
                >
                    {{ $t('commonLabel.submit') }}
                </CButton>
                <CButton type="button"
                    class="btn-custom-default outline rectangle"
                    @click="editPopClose"
                >
                    {{ $t('commonLabel.cancel') }}
                </CButton>
            </CCardFooter>
        </CForm>
    </CCard>
</template>

<script>
import moment from 'moment'
import utils from '@/assets/js/utils'
import ValidFeedback from '@/components/form/ValidFeedback'
import { mapGetters, mapActions } from 'vuex'
import { validationMixin } from "vuelidate"
import { required, decimal, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import DatePicker from 'vue2-datepicker'
import 'vue2-datepicker/index.css'

const blastLibrary = 'blastLibrary'

export default {
    name: 'VibrationData',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        DatePicker,
        ValidFeedback,
        AppIcon
    },
    data() {
        return {
            dropdownSelectNum: 0,
            spinnerFlag: false,

            dateRange: '',
            sisFileList: [],
            fileList: [],
            form: {},
            formCnt: 10,
            formUpload: {}
        }
    },
    mixins: [validationMixin],
    validations() {
        const validations = {
            form: {}
        }
        for (var idx=0; idx<this.formCnt; idx++) {
          validations.form[idx] = {
            modifyFlag: {
                //
            },
            fileId: {
                //
            },
            geophoneId: {
                //
            },
            actualPVS: {
                decimal,
                between: between(-999.999999999999999, 999.999999999999999),
                decimalLimit: decimalLimit(15)
            },
            actualSound: {
                decimal,
                between: between(-999.999999999999999, 999.999999999999999),
                decimalLimit: decimalLimit(15)
            },
            remark: {
                byte: byte(250)
            },
          }
        }

        return validations
    },
    mounted() {
        const toDate = moment().format('YYYY-MM-DD')
        const fromDate = moment().add(-7,'days').format('YYYY-MM-DD')
        this.dateRange = [ new Date(fromDate), new Date(toDate) ]

        if (this.blastId != 0) {
            this.onSearch()
            this.getInterfaceInfo()
        }

        for (var idx=0; idx<this.formCnt; idx++) {
            this.form[idx] = this.getEmptyForm()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
        }),
        isValid() {
            return !this.$v.form[0].$invalid
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            downloadAction: 'download',
            putDataAction: 'putData',
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setFileDataAction: 'setFileData',
        }),
        async onSearch() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
            let startDate = ''
            let endDate = ''

            params.push("pagable="+false)
            params.push("siteId="+siteId)
            params.push("blastId="+blastId)

            // Date Fired
            if (this.dateRange != null) {
                let date_start = this.dateRange[0]
                startDate = moment(date_start).format('YYYY-MM-DD 00:00:00')
                startDate = moment(startDate).utc().format()

                let date_end = this.dateRange[1]
                endDate = moment(date_end).format('YYYY-MM-DD 23:59:59')
                endDate = moment(endDate).utc().format()
                //endDate = moment(date_end).add(+1,'days').format('YYYY-MM-DD 23:59:59')

                params.push("startDate="+startDate)
                params.push("endDate="+endDate)
            }

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/vibration-list?pagable=false&startDate="+startDate+"&endDate="+endDate
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.sisFileList = []
            if (this.dataList.content.length != 0) {
                (this.dataList.content).forEach(function (item, index) {
                    let fileInfo = {
                        'siteId': item.siteId,
                        'blastId': item.blastId,
                        'fileId': item.fileId,
                        'fileName': item.fileName,
                        'serialNumber': item.serialNo,
                        'date': moment(item.insertDatetime).format('YYYY-MM-DD HH:mm:ss'),
                    }
                    that.sisFileList.push(fileInfo)
                })
            }

            that.spinnerFlag = false
        },
        async getInterfaceInfo() {
            let that = this
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/vibrations"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.status == '200') {
                this.data.content.forEach (function (el, idx) {
                    let unitName = 'Vibration Analysis File'
                    let fileInfo = { siteId: '', unitName: unitName, equipmentId: '', upFileName: '', upFileStr: '', file: '', fileId: '', fileName: '' }
                    fileInfo.siteId = siteId

                    let fileId = el.fileId
                    let upFileName = el.fileName
                    let upFileStr = ''
                    if (upFileName != null && upFileName != '') upFileStr = ' ( '+upFileName+' )'

                    fileInfo.geophoneId = el.geophoneId
                    fileInfo.geophoneName = el.geophoneName
                    fileInfo.fileId = fileId
                    fileInfo.fileName = ''
                    fileInfo.upFileName = upFileName
                    fileInfo.upFileStr = upFileStr

                    that.fileList.push(fileInfo)

                    that.form[idx] = that.getEmptyForm()
                    that.form[idx].fileId =
                    that.form[idx].geophoneId = el.geophoneId
                    that.form[idx].actualPVS = el.vibrationActualPvs
                    that.form[idx].actualSound = el.vibrationActualSound
                    that.form[idx].remark = el.vibrationRemark
                })
            }

            if (this.fileList.length==1) that.dropdownSelect(0)

            this.spinnerFlag = false
        },
        async submit() {
console.log('submit...')
            let that = this
            that.spinnerFlag = true

            let siteId = this.siteId
            let blastId = this.blastId

            // form 등록, 수정 관리
            that.fileList.forEach (async function (el, idx) {
                if (that.form[idx].modifyFlag == 'Y') {
// console.log( that.form[idx].modifyFlag )
// console.log( that.form[idx].geophoneId )
                    let geophoneId = that.form[idx].geophoneId
                    let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/vibration/"+geophoneId+"/remark"

                    await that.putDataAction({
                        params: {
                            vibrationActualPvs: that.form[idx].actualPVS,
                            vibrationActualSound: that.form[idx].actualSound,
                            vibrationRemark: that.form[idx].remark,
                        },
                        moduleName: moduleName
                    })
                }
            })

            // file 등록 관리
            for (const item of that.fileList) {
                if (item.file != '') {
                    that.formUpload = {}
                    that.formUpload.blastId = blastId
                    that.formUpload.uploadFile = item.file

                    let moduleName = "v1/files/"+siteId+"/vib?blastId="+blastId
                    await this.setFileDataAction({
                        params: that.formUpload,
                        moduleName: moduleName
                    })
                } else if (item.fileId != '') {
                    that.formUpload = {}
                    that.formUpload.blastId = blastId
                    that.formUpload.fileId = item.fileId
                    that.formUpload.geophoneId = item.geophoneId

                    let moduleName = "v1/files/"+siteId+"/vib/"+item.fileId+"?blastId="+blastId+"&geophoneId="+item.geophoneId
                    await this.setFileDataAction({
                        params: that.formUpload,
                        moduleName: moduleName
                    })
                }
            }

            this.$emit('submitChk', 'vibration')
            that.editPopClose()

            that.spinnerFlag = false
        },
        async _submit() {
console.log('submit...')
            let that = this
            that.spinnerFlag = true

            let siteId = this.siteId
            let blastId = this.blastId

console.log(that.form[0].actualPVS)
//console.log(that.form[1])

            that.dropdownSelect(0)

/*
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/vibration/remark"
            await this.putDataAction({
                params: {
                    vibrationActualPvs: this.form[0].actualPVS,
                    vibrationActualSound: this.form[0].actualSound,
                    vibrationRemark: this.form[0].remark,
                },
                moduleName: moduleName
            })
console.log(that.fileList)
            for (const item of that.fileList) {
                if (item.file != '') {
                    that.form.blastId = blastId
                    that.form.uploadFile = item.file

                    moduleName = "v1/files/"+siteId+"/vib?blastId="+blastId
                    await this.setFileDataAction({
                        params: that.form,
                        moduleName: moduleName
                    })
                }
            }

            this.$emit('submitChk', 'vibration')
            that.editPopClose()
*/
            that.spinnerFlag = false
        },
        vibrationFileClick(item) {
            //item.fileName = item.upFileName

            this.fileClick(item, 'down')
        },
        async fileClick(item, type) {
            if (type=='down') {
                let fileName = item.fileName  // item.fileName.substring(0, item.fileName.lastIndexOf('.'))
                if (fileName == null || fileName == '') fileName = item.upFileName
                await this.downloadAction({
                    params : {
                        fileName: fileName
                    },
                    moduleName : `v1/files/${item.siteId}/vib/download/${item.fileId}`
                })
            } else {  // upload
                let index = this.dropdownSelectNum
                this.fileList[index].fileId = item.fileId
                this.fileList[index].fileName = item.fileName
            }
        },
        setModifyFlag(idx) {
            this.form[idx].modifyFlag = 'Y'
        },
        editPopClose() {
            this.$emit('closeEditPop')
        },
        process(index, event) {
            this.fileList[index].fileId = ''
            this.fileList[index].fileName = event.target.value
            this.fileList[index].file = event.target.files[0]
        },
        getEmptyForm() {
            return {
                fileId: '',
                modifyFlag: 'N',
                geophoneId: '',
                actualPVS: '',
                actualSound: '',
                remark: '',
            }
        },
        dropdownSelect(index) {
            if(this.fileList.length === 1) return false

            if(this.dropdownSelectNum != index) {
                // open
                return this.dropdownSelectNum = index
            }
            else {
                // close
                return this.dropdownSelectNum = null
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.datepicker-wrap{
    margin-bottom:10px;
    .date-picker{
        width:calc(100% - 80px);
    }
    .btn{
        width:74px;
        margin-left:6px;
    }
}
</style>