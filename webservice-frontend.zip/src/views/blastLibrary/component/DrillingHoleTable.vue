<template>
  <div>
    <!-- 공통 table (component 안에 modal popup) -->
    <CTableCompWrapper
      :items="drillingHoleTableData"
      v-if="drillingHoleTableData.length != 0"
      class="select-table data-table mt-2 table-max-height805"
      hover
      striped
      border
      fixed
      v-bind="blastInfo"
      @holeClick="holeClick"
    />
    <div
      v-show="!drillingHoleTableData.length"
      v-text="$t('message.noData')"
      style="padding-top:10px;"
    />
  </div>
</template>

<script>
import CTableCompWrapper from "@/views/blastLibrary/component/TableComp"
import drillingHoleTableDummyData from "@/views/blastLibrary/dummyData/drillingHoleTableData" //임시 data
import utils from '@/assets/js/utils'
export default {
  name: "DrillingHoleTable",
  props: {
    siteId: {
      type: Number,
    },
    blastId: {
      type: Number,
    },
  },
  components: {
    CTableCompWrapper,
  },
  data() {
    return {
      drillingHoleTableDummyData,
      drillingHoleTableData: [],
      blastInfo: {
        siteId: 0,
        blastId: 0,
      },
    }
  },
  async created() {
    this.blastInfo.siteId = this.siteId
    this.blastInfo.blastId = this.blastId
  },
  async mounted() {
    //this.holeDataList()
  },
  methods: {
    // 해당 components에서 axios로 데이터 처리시
    //         holeDataList() {
    // console.log('computedList...')
    //             let that = this
    //             this.drillingHoleTableData = []
    //             this.$nextTick(function() {
    //                 drillingHoleTableDummyData.forEach (function (el, index) {
    //                     that.drillingHoleTableData.push(el)
    //                 })
    //             })
    //             return this.drillingHoleTableData
    //         },
    holeClick(item) {
      this.$emit("holeClick", item)
    },
    // 부모 components에서 holeData로 처리 시
    childMethod(tableData) {
      let that = this
      this.drillingHoleTableData = []
      let holeTable = []

      tableData.forEach(function(item) {
        let holeInfo = {
          holeId: item.holeId,
          holeName: item.holeName,
          designDepth: that.chkNull(item.designLengthValue),
          actualDepth: that.chkNull(item.actualLengthValue),
          depthDifference: that.chkNull(item.diffLengthValue),
          collarAccuracy: that.chkNull(item.XYAccuracy, 10),
          diameter: that.chkNull(item.diameterValue),
          "drillUnit/operator":
            that.chkNull(item.equipmentName) +
            " / " +
            that.chkNull(item.workerName),
          drilledTime: that.chkNull(item.designLengthValue),
          rockHardness: that.chkNull(item.rockType),
          designPointXValue: item.designPointXValue,
          designPointYValue: item.designPointYValue,
        }

        // let holeInfo = {
        //     'holeName': item.holeName
        //     ,'holeId': item.holeId
        //     ,'designPointXValue': item.designPointXValue
        //     ,'designPointYValue': item.designPointYValue
        //     ,'rockType': item.rockType
        //     ,'workerId': item.workerId
        //     ,'equipmentId': item.equipmentId
        //     ,'actualLengthValue': item.actualLengthValue
        //     ,'designLengthValue': item.designLengthValue
        //     ,'diameterValue': item.diameterValue
        //     ,'diffLengthValue': item.diffLengthValue
        //     ,'drilledTime': item.drilledTime
        //     ,'lineLength': item.lineLength
        // }

        holeTable.push(holeInfo)
      })

      that.drillingHoleTableData = holeTable
    },
    chkNull(val, fixed) {
      if (val == null) return "No data"
      else if (fixed == undefined) return utils.setDecimal(val)
      else if (val != 0) return utils.setDecimal(val, fixed)
      else return utils.setDecimal(val)
    },
  },
}
</script>
