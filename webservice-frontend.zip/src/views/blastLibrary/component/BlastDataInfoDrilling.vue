<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ drillingSummary.pitName }}</span>
                    </div>
                </div>

                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ drillingSummary.holes }}</span>
                    </div>
                </div>

                <!-- Drill Meter (m) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="meter" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Drill Meter (m)</Strong>
                        <span class="sub-text">{{ drillingSummary.drillMeter }}</span>
                    </div>
                </div>

                <!-- Hole Diameter (mm) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="holeDiameter" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Hole Diameter (mm)</Strong>
                        <span class="sub-text">{{ drillingSummary.holeDiameter }}</span>
                    </div>
                </div>

                <!-- Equipment -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="epuipment" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Equipment</Strong>
                        <span class="sub-text">{{ drillingSummary.equipment }}</span>
                    </div>
                </div>

                <!-- Work hour -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="workHours" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Work hour</Strong>
                        <span class="sub-text small">{{ drillingSummary.workHour }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import utils from '@/assets/js/utils'
import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastDataInfoDrilling',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            drillingSummary: {
                pitName: '-',
                holes: '-',
                drillMeter: '-',
                holeDiameter: '-',
                equipment: '-',
                workHour: '-',
            }
        }
    },
    async created() {
        this.blastId = (this.blastId==undefined?0:this.blastId)
        if (this.blastId != 0) {
            this.setDrillingSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data : 'getData',
            dataList : 'getDataList',
            selectedData : 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction : 'setDataList',
            setSelectedAction : 'setSelectedData',
        }),
        async setDrillingSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 59

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/summary"
console.log(moduleName)
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.dataList.length>0) {
                let summary = this.dataList[0]

                this.drillingSummary.pitName = summary.pitName
                this.drillingSummary.holes = summary.holeCount
                this.drillingSummary.drillMeter = summary.lengthValue
                this.drillingSummary.holeDiameter = summary.diameterValue
                this.drillingSummary.equipment = summary.equipmentCount
                this.drillingSummary.workHour = this.getSecondsTohhmmss(summary.totalWorkSecond)

                summary.workHour = this.drillingSummary.workHour

                this.$emit('setSummaryInfo', summary)
            }
        },
        getSecondsTohhmmss(totalSeconds) {
            if (!totalSeconds) return '-'

            var hours   = Math.floor(totalSeconds / 3600);
            var minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);
            var seconds = totalSeconds - (hours * 3600) - (minutes * 60);

            // round seconds
            seconds = Math.round(seconds * 100) / 100

            var result = ''
            if (hours > 0) result += hours + '시간 '
            if (minutes > 0) result += minutes + '분 '
            if (hours == 0 && seconds > 0) result += seconds + '초'

            return result
        }
    }
}
</script>