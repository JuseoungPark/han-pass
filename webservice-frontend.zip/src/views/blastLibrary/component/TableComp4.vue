<template>
    <div>
        <CDataTable
          :items="loadedItems"
          :fields="fields"
          :hover="hover"
          :striped="striped"
          :bordered="bordered"
          :small="small"
          :fixed="fixed"
        >
          <template #holeName="{item}">
            <td>
              <router-link to="/blastLibrary/charging" @click.native="holeClick(item, $event)">
                {{ item.holeName }}
              </router-link>
              <button class="btn btn-dark btn-sm ml-3" @click="smallModalPop(item)">
                <CIcon name="cil-magnifying-glass" class="pop-diagram " />
              </button>
            </td>
          </template>
        </CDataTable>

        <sweet-modal
          ref="holeModal"
          blocking
          overlay-theme="dark"
          class="hole-modal-pop"
        >
          <CCard class="mb-0">
            <CCardHeader>
              <strong>Charge Cross section</strong>
              <small class="ml-2">Hole Name (ID) : {{ holeName }} ({{ holeId }})</small>
            </CCardHeader>
            <CCardBody>
              <div>
                <ul class="half-layout list-unstyled">
                  <li>
                    <AmChartStackedCustomComp
                      v-if="StackedChartAdjustData.data.length!=0"
                      chartHeight="500"
                      :chartData=StackedChartAdjustData
                    />
                  </li>
                  <li>
                    <AmChartStackedCustomComp
                      v-if="StackedChartResultData.data.length!=0"
                      chartHeight="500"
                      :chartData=StackedChartResultData
                    />
                  </li>
                </ul>
              </div>
            </CCardBody>
          </CCard>
        </sweet-modal>
    </div>
</template>

<script>
import { SweetModal, SweetModalTab } from 'sweet-modal-vue'
import { mapGetters, mapActions } from 'vuex'

import utils from '@/assets/js/utils'
import moment from 'moment'

const AmChartStackedCustomComp = () => import(/* webpackChunkName: "popCharts" */ './AmChartStackedCustomComp')

const blastLibrary = 'blastLibrary'

export default {
    name: 'DataTableComp',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
        caption: {
            type: String,
            default: 'Table'
        },
        items: Array,
        hover: Boolean,
        striped: Boolean,
        bordered: Boolean,
        small: Boolean,
        fixed: Boolean,
        dark: Boolean,
        isClickable: Boolean,
    },
    components: {
        SweetModal,
        SweetModalTab,
        AmChartStackedCustomComp
    },
    data () {
        return {
            holeId: '',
            holeName: '',
            fields: [],
            loadedItems: this.items.slice(0),
            pages: Math.ceil(this.items.length / 5),

            // chart
            StackedChartAdjustData: {
                data:[]
            },
            StackedChartResultData: {
                data:[]
            },
        }
    },
    async created() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData'
        }),
    },
    mounted() {
        this.dataFields()
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        dataFields() {
            let fields = this.loadedItems
            let fieldsArr = Object.keys(fields[0])

            fieldsArr.splice(fieldsArr.indexOf('pointXValue'), 1)
            fieldsArr.splice(fieldsArr.indexOf('pointYValue'), 1)

            return this.fields = fieldsArr
        },
        async smallModalPop(item) {
            let that = this

            this.holeName = item.holeName
            this.holeId = item.holeId

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
            let holeId = item.holeId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/chargings/cross-section/"+holeId
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            that.StackedChartAdjustData.data = []
            that.StackedChartResultData.data = []
            if (that.data.status == 200) {
                if (that.data.content.length>0) {
                    that.StackedChartAdjustData.data.push({ "name": "stemmingLengthValue", "value": that.data.content[0].adjust.stemmingLengthValue })
                    that.StackedChartAdjustData.data.push({ "name": "chargeLength", "value": that.data.content[0].adjust.chargeLength })

                    that.StackedChartResultData.data.push({ "name": "stemmingLengthValue", "value": that.data.content[0].result.stemmingLengthValue })
                    that.StackedChartResultData.data.push({ "name": "chargeLength", "value": that.data.content[0].result.chargeLength })
                }else{
                  utils.showToastRed(this.$t('message.noData'))
                }
            }

            this.$refs.holeModal.open()
        },
        // hole name클릭시 map에서 해당 hole zoom
        holeClick(item, that) {
          let selectSiblings = document.querySelectorAll('.select-table tr')

          selectSiblings.forEach( e => {
           e.classList.remove("selected")
          });
          that.path[2].classList.add("selected")

          this.$emit('holeClick', item)
        },
    }
}
</script>