<template>
    <div class="am-xy-chart" ref="chartxy" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)

export default {
    name: 'CategoryDoubleSeries',
    data() {
        return {
            max: 0,
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
        series1Name: String,
        series2Name: String,
        targetValue: String,
        isColorType: Boolean,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
                chart.svgContainer.measure()

                chart.data = addData.data

                this.max = Number(this.targetValue)
                let value = chart.data[0].value
                let value2 = chart.data[0].value2

                if (this.max < value) this.max = value
                if (this.max < value2) this.max = value2

                if(this.isColorType){
                    chart.colors.list = [
                        am4core.color("#845EC2"),
                        am4core.color("#D65DB1"),
                    ];
                }

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.cellStartLocation = 0.1
                categoryAxis.renderer.cellEndLocation = 0.9
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30
                categoryAxis.renderer.labels.template.fill = am4core.color("#777")
                categoryAxis.renderer.labels.template.fontSize = 11

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxis.renderer.minGridDistance = 30
                valueAxis.renderer.labels.template.fill = am4core.color("#777")
                valueAxis.renderer.labels.template.fontSize = 11
                valueAxis.min = 0
                valueAxis.max = this.max

            // target line
            let range = valueAxis.axisRanges.create()
                range.value = this.targetValue
                range.grid.stroke = am4core.color("#5ea565")
                range.grid.strokeWidth = 1
                range.grid.strokeOpacity = 1
                range.label.inside = true
                range.label.text = "target"
                range.label.fill = range.grid.stroke
                //range.label.align = "right"
                range.label.verticalCenter = "bottom"

            // Create series
            let series1 = chart.series.push(new am4charts.ColumnSeries())
                series1.dataFields.valueY = "value"
                series1.dataFields.categoryX = "category"
                series1.name = this.series1Name
                series1.columns.template.tooltipText = series1.name + " : [bold;]{valueY}[/]"
                series1.columns.template.strokeWidth = 0
                series1.columns.template.width = am4core.percent(50)
                series1.cloneTooltip = false // Tooltip off
                series1.showOnInit = false // animation off
                series1.columns.template.tooltipX = am4core.percent(50)
                series1.columns.template.tooltipY = am4core.percent(0)
                series1.tooltip.pointerOrientation = "vertical"

            // chart color set
            // series1.columns.template.adapter.add("fill", function(fill, target) {
            //     return chart.colors.getIndex(target.dataItem.index);
            // })

            let series2 = chart.series.push(new am4charts.ColumnSeries())
                series2.dataFields.valueY = "value2"
                series2.dataFields.categoryX = "category"
                series2.name = this.series2Name
                series2.columns.template.tooltipText = series2.name + " : [bold]{valueY}[/]"
                series2.columns.template.strokeWidth = 0
                series2.columns.template.width = am4core.percent(50)
                series2.cloneTooltip = false // Tooltip off
                series2.showOnInit = false // animation off
                series2.columns.template.tooltipX = am4core.percent(50)
                series2.columns.template.tooltipY = am4core.percent(0)
                series2.tooltip.pointerOrientation = "vertical"

            // chart color set
            // series2.columns.template.adapter.add("fill", function(fill, target) {
            //     return chart.colors.getIndex(target.dataItem.index + 4);
            // })

            // target line
            // let lineSeries = chart.series.push(new am4charts.StepLineSeries())
            //     lineSeries.dataFields.valueY = "target"
            //     lineSeries.dataFields.categoryX = "category"
            //     lineSeries.name = this.targetName
            //     lineSeries.align = "right"
            //     lineSeries.valign = "top"
            //     // lineSeries.showTooltipOn = "always"
            //     // lineSeries.tooltipText = "target : [bold]{valueY}[/]"
            //     lineSeries.strokeWidth = 1
            //     lineSeries.stroke = am4core.color("red")
            //     lineSeries.cloneTooltip = false // Tooltip off
            //     lineSeries.showOnInit = false // animation off

            //     // target data
            //     let targetData = [], data = {}
            //     let category = data.category
            //     let target = data.target

            //     for(let i = 0; i < addData.data.length; i++){
            //         targetData.push({
            //             'category' : addData.data[i].category,
            //             'target' : this.targetValue
            //             })
            //     }

            //     lineSeries.data = targetData


            // let label = lineSeries.createChild(am4core.Label)
            //     label.strokeOpacity = 0
            //     label.fontSize = 10
            //     label.fill = lineSeries.stroke
            //     label.fillOpacity = 1
            //     label.padding(40, 0, 10, 40)
            //     label.verticalCenter = "top"
            //     label.horizontalCenter = "left"
            //     label.text = "target : " + lineSeries.data[0].target

                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"
                // chart.cursor.xAxis = categoryAxis
                // chart.cursor.fullWidthLineX = true
                // chart.cursor.lineX.strokeWidth = 0
                // chart.cursor.lineX.fill = am4core.color("#000")
                // chart.cursor.lineX.fillOpacity = 0.1
                // chart.cursor.behavior = "selectX"
                // chart.cursor.lineY.disabled = true

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = false
                chart.legend.position = "top"
                chart.legend.contentAlign = "right"
                chart.legend.marginBottom = 20
                chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>