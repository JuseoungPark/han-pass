<template>
  <div>
    <!-- 공통 table (component 안에 modal popup) -->
    <CTableCompWrapper
      :items="chargingHoleTableData"
      v-if="chargingHoleTableData.length != 0"
      class="select-table data-table mt-2 table-max-height790"
      hover
      striped
      border
      fixed
      v-bind="blastInfo"
      @holeClick="holeClick"
    />
    <div
      v-show="!chargingHoleTableData.length"
      v-text="$t('message.noData')"
      style="padding-top:10px;"
    />
  </div>
</template>

<script>
import utils from '@/assets/js/utils'
import CTableCompWrapper from '@/views/blastLibrary/component/TableComp4'
//import chargingHoleTableData from '@/views/blastLibrary/dummyData/chargingHoleTableData' //임시 data

export default {
  name: "ChargingHoleTable",
  props: {
    siteId: {
      type: Number,
    },
    blastId: {
      type: Number,
    },
  },
  components: {
    CTableCompWrapper,
  },
  data() {
    return {
      chargingHoleTableData: [],
      blastInfo: {
        siteId: 0,
        blastId: 0,
      },
    }
  },
  async created() {
    this.blastInfo.siteId = this.siteId
    this.blastInfo.blastId = this.blastId
  },
  async mounted() {
    //this.holeDataList()
  },
  methods: {
    holeClick(item) {
      this.$emit("holeClick", item)
    },
    // 부모 components에서 holeData로 처리 시
    childMethod(tableData) {
      let that = this
      let holeTable = []
      tableData.forEach(function(item) {
        let holeInfo = {
          holeName: item.holeName,
          holeId: item.holeId,
          "No. of deck": item.deckNo,
          designCharge: that.chkNull(item.designCharge),
          actualCharge: that.chkNull(item.actualCharge),
          chargeDifference: that.chkNull(item.chargeDifference),
          diameter: that.chkNull(item.diameterValue),
          stemmingLength: that.chkNull(item.stemmingLength),
          chargedTime: that.chkNull(item.chargedTime),
          "MPY unit/operator": that.chkNull(item.operator),
          "P.F": that.chkNull(item.pfValue),
          pointXValue: item.pointXValue,
          pointYValue: item.pointYValue,
        }
        holeTable.push(holeInfo)
      })

      that.chargingHoleTableData = holeTable
    },
    chkNull(val, fixed) {
      if (val == null) return "No data"
      else if (fixed == undefined) return utils.setDecimal(val)
      else if (val != 0) return utils.setDecimal(val, fixed)
      else return utils.setDecimal(val)
    },
  },
}
</script>
