<template>
    <div>
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <CTabs variant="pills" :active-tab="0" class="lg-mt">
            <CTab title="Drilling cost" sm="3">
                <CCard class="table-card-wrap mt-2">
                    <CCardBody class="line-none">
                        <div class="mt-1">
                            <div class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ drillingTotal | setDecimal }}</span></div>
                            <div class="position-relative table-responsive data-table typeA mt-1">
                                <fieldset>
                                    <legend class="sr-only">Drilling cost dataSet</legend>
                                    <table class="table table-fixed table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th
                                                    v-for="(item, index) in drillingThItems"
                                                    :key="index"
                                                    scope="col"
                                                >
                                                    {{item.titText}}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr
                                                v-for="(item, index) in drillingTdItems"
                                                :key="index"
                                            >
                                                <td>{{ item.value1 | setDecimal }}</td>
                                                <td>{{ item.value2 | setDecimal }}</td>
                                                <td>{{ item.value3 | setDecimal }}</td>
                                                <td>{{ item.value4 | setDecimal }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </div>
                        </div>
                    </CCardBody>
                </CCard>
            </CTab>

            <CTab title="Explosives cost" sm="3">
                <CCard class="table-card-wrap mt-2">
                    <CCardBody class="line-none">
                        <div class="mt-1">
                            <div class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ explosivesTotal | setDecimal }}</span></div>
                            <div class="position-relative table-responsive data-table typeA mt-1">
                                <fieldset>
                                    <legend class="sr-only">Explosives cost dataSet</legend>
                                    <table class="table table-fixed table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th
                                                    v-for="(item, index) in explosivesThItems"
                                                    :key="index"
                                                    scope="col"
                                                >
                                                    {{item.titText}}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr
                                                v-for="(item, index) in explosivesTdItems"
                                                :key="index"
                                            >
                                                <td>{{ item.value1 | setDecimal }}</td>
                                                <td>{{ item.value2 | setDecimal }}</td>
                                                <td>{{ item.value3 | setDecimal }}</td>
                                                <td>{{ item.value4 | setDecimal }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </div>
                        </div>
                    </CCardBody>
                </CCard>
            </CTab>
            <CTab title="Initialtion cost" sm="3">
                <CCard class="table-card-wrap mt-2">
                    <CCardBody class="line-none">
                        <div class="mt-1">
                            <div class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ initialtionTotal | setDecimal }}</span></div>
                            <div class="position-relative table-responsive data-table typeA mt-1">
                                <fieldset>
                                    <legend class="sr-only">Explosives cost dataSet</legend>
                                    <table class="table table-fixed table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th
                                                    v-for="(item, index) in initialtionThItems"
                                                    :key="index"
                                                    scope="col"
                                                >
                                                    {{item.titText}}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr
                                                v-for="(item, index) in initialtionTdItems"
                                                :key="index"
                                            >
                                                <td>{{ item.value1 | setDecimal }}</td>
                                                <td>{{ item.value2 | setDecimal }}</td>
                                                <td>{{ item.value3 | setDecimal }}</td>
                                                <td>{{ item.value4 | setDecimal }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </div>
                        </div>
                    </CCardBody>
                </CCard>
            </CTab>
            <CTab title="Labor cost" sm="3">
                <CCard class="table-card-wrap mt-2">
                    <CCardBody class="line-none">
                        <div class="mt-1">
                            <div class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ laborTotal | setDecimal }}</span></div>
                            <div class="position-relative table-responsive data-table typeA mt-1">
                                <fieldset>
                                    <legend class="sr-only">Explosives cost dataSet</legend>
                                    <table class="table table-fixed table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th
                                                    v-for="(item, index) in laborThItems"
                                                    :key="index"
                                                    scope="col"
                                                >
                                                    {{item.titText}}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr
                                                v-for="(item, index) in laborTdItems"
                                                :key="index"
                                            >
                                                <td>{{ item.value1 | setDecimal }}</td>
                                                <td>{{ item.value2 | setDecimal }}</td>
                                                <td>{{ item.value3 | setDecimal }}</td>
                                                <td>{{ item.value4 | setDecimal }}</td>
                                                <td>{{ item.value5 | setDecimal }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </div>
                        </div>
                    </CCardBody>
                </CCard>
            </CTab>
            <CTab title="Extra cost" sm="3">
                <CCard class="table-card-wrap mt-2">
                    <CCardBody class="line-none">
                        <div class="mt-1">
                            <div class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ extraTotal | setDecimal }}</span></div>
                            <div class="position-relative table-responsive data-table typeA mt-1">
                                <fieldset>
                                    <legend class="sr-only">Explosives cost dataSet</legend>
                                    <table class="table table-fixed table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th
                                                    v-for="(item, index) in extraThItems"
                                                    :key="index"
                                                    scope="col"
                                                >
                                                    {{item.titText}}
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr
                                                v-for="(item, index) in extraTdItems"
                                                :key="index"
                                            >
                                                <td>{{ item.value1 | setDecimal }}</td>
                                                <td>{{ item.value2 | setDecimal }}</td>
                                                <td>{{ item.value3 | setDecimal }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </div>
                        </div>
                    </CCardBody>
                </CCard>
            </CTab>
        </CTabs>
        <CCard class="table-card-wrap">
            <CCardHeader>
                <div class="row">
                    <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                        <strong>Cost Analysis</strong>
                        <span class="text-right">Total cost ({{ userSite.currencyName }}) : <span>{{ costAnalysisTotal | setDecimal }}</span></span>
                    </div>
                </div>
            </CCardHeader>
            <CCardBody>
                <div class="mt-3">
                    <div class="position-relative table-responsive data-table typeA">
                        <fieldset>
                            <legend class="sr-only">Cost Analysis dataSet</legend>
                            <table class="table table-fixed table-bordered table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th
                                            v-for="(item, index) in costAnalysisThItems"
                                            :key="index"
                                            scope="col"
                                        >
                                            {{item.titText}}
                                        </th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Total cost</th>
                                        <th>{{ costAnalysisTotal | setDecimal }}</th>
                                        <th>{{ costAnalysisTotalHole | setDecimal }}</th>
                                        <th>{{ costAnalysisTotalBcm | setDecimal }}</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr
                                        v-for="(item, index) in costAnalysisTdItems"
                                        :key="index"
                                    >
                                        <th>{{ item.value1 }}</th>
                                        <td>{{ item.value2 | setDecimal }}</td>
                                        <td>{{ item.value3 | setDecimal }}</td>
                                        <td>{{ item.value4 | setDecimal }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </fieldset>
                    </div>
                </div>
            </CCardBody>
        </CCard>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import utils from '@/assets/js/utils'

const blastLibrary = 'blastLibrary'

export default {
    name: 'CostComp',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    data() {
        return {
            spinnerFlag: false,

            // Drilling Cost table
            drillingThItems: [
                { titText: 'Diameter' },
                { titText: 'Drill meter' },
                { titText: 'DrillUnit cost' },
                { titText: 'Cost' }
            ],
            drillingTotal: 0,
            drillingTdItems: [],
            // Explosives Cost table
            explosivesThItems: [
                { titText: 'Product Name' },
                { titText: 'Qty' },
                { titText: 'ProductUnit Cost' },
                { titText: 'Cost' }
            ],
            explosivesTotal: 0,
            explosivesTdItems: [],
            // Initialtion Cost table
            initialtionThItems: [
                { titText: 'Product Name' },
                { titText: 'Qty' },
                { titText: 'ProductUnit Cost' },
                { titText: 'Cost' }
            ],
            initialtionTotal: 0,
            initialtionTdItems: [],
            // Labor Cost table
            laborThItems: [
                { titText: 'Labor Class' },
                { titText: 'WorkHour' },
                { titText: 'Worker' },
                { titText: 'LaborUnitcost' },
                { titText: 'Cost' }
            ],
            laborTotal: 0,
            laborTdItems: [],
            // Extra Cost table
            extraThItems: [
                { titText: 'Event' },
                { titText: 'ExtraUnit Cost' },
                { titText: 'Cost' },
            ],
            extraTotal: 0,
            extraTdItems: [],

            // Cost Analysis table
            costAnalysisThItems: [
                { titText: '' },
                { titText: 'Cost' },
                { titText: 'Per Hole' },
                { titText: 'Per BCM' }
            ],
            costAnalysisTotal: 0,
            costAnalysisTotalHole: 0,
            costAnalysisTotalBcm: 0,
            costAnalysisTdItems: [],
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setCostComp()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
        userSite () {
            return utils.getUserInformation().selectedUserSite
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setCostComp() {
            let that = this
            that.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/costs/cost"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            if (that.status == '200') {
                let drillCost = that.dataList.drillCost
                if (drillCost != undefined) {
                    that.drillingTotal = (drillCost.total!=null?drillCost.total:0)
                    if (drillCost.list.length==0) {
                        that.drillingTdItems.push({
                            value1: '-', value2: '-', value3: '-', value4: '-'
                        })
                    }
                    drillCost.list.forEach(function (item) {
                        that.drillingTdItems.push({
                            value1: item.diameter,
                            value2: item.drillMeter,
                            value3: item.drillUnitCost,
                            value4: item.cost,
                        })
                    })
                }
                let explosiveCost = that.dataList.explosiveCost
                if (explosiveCost != undefined) {
                    that.explosivesTotal = (explosiveCost.total!=null?explosiveCost.total:0)
                    if (explosiveCost.list.length==0) {
                        that.explosivesTdItems.push({
                            value1: '-', value2: '-', value3: '-', value4: '-'
                        })
                    }
                    explosiveCost.list.forEach(function (item) {
                        that.explosivesTdItems.push({
                            value1: item.productName,
                            value2: item.qty,
                            value3: item.productUnitCost,
                            value4: item.cost,
                        })
                    })
                }
                let initiationCost = that.dataList.initiationCost
                if (initiationCost != undefined) {
                    that.initialtionTotal = (initiationCost.total!=null?initiationCost.total:0)
                    if (initiationCost.list.length==0) {
                        that.initialtionTdItems.push({
                            value1: '-', value2: '-', value3: '-', value4: '-'
                        })
                    }
                    initiationCost.list.forEach(function (item) {
                        that.initialtionTdItems.push({
                            value1: item.productName,
                            value2: item.qty,
                            value3: item.productUnitCost,
                            value4: item.cost,
                        })
                    })
                }
                let laborCost = that.dataList.laborCost
                if (laborCost != undefined) {
                    that.laborTotal = (laborCost.total!=null?laborCost.total:0)
                    if (laborCost.list.length==0) {
                        that.laborTdItems.push({
                            value1: '-', value2: '-', value3: '-', value4: '-', value5: '-'
                        })
                    }
                    laborCost.list.forEach(function (item) {
                        that.laborTdItems.push({
                            value1: item.laborClass,
                            value2: item.workHour,
                            value3: item.worker,
                            value4: item.laborUnitcost,
                            value5: item.cost,
                        })
                    })
                }
                let extraCost = that.dataList.extraCost
                if (extraCost != undefined) {
                    that.extraTotal = (extraCost.total!=null?extraCost.total:0)
                    if (extraCost.list.length==0) {
                        that.extraTdItems.push({
                            value1: '-', value2: '-', value3: '-'
                        })
                    }
                    extraCost.list.forEach(function (item) {
                        that.extraTdItems.push({
                            value1: item.event,
                            value2: item.extraUnitCost,
                            value3: item.cost,
                        })
                    })
                }
            }

            moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/costs/cost-analysis"
            payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            if (that.status == '200') {
                let costAnalysisTotal = 0
                let costAnalysisTotalHole = 0
                let costAnalysisTotalBcm = 0

                that.dataList.forEach(function (item) {
                    if (item.costName != 'total') {
                        that.costAnalysisTdItems.push({
                            value1: item.costName,
                            value2: item.cost,
                            value3: item.perHole,
                            value4: item.perBcm,
                        })

                        costAnalysisTotal += Number(item.cost)
                        costAnalysisTotalHole += Number(item.perHole)
                        costAnalysisTotalBcm += Number(item.perBcm)
                    }
                })

                that.costAnalysisTotal = costAnalysisTotal.toFixed(3)
                that.costAnalysisTotalHole = costAnalysisTotalHole.toFixed(3)
                that.costAnalysisTotalBcm = costAnalysisTotalBcm.toFixed(3)
            }

            that.spinnerFlag = false
        }
    }
}
</script>