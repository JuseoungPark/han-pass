<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ vibrationSummary.pitName }}</span>
                    </div>
                </div>

                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ vibrationSummary.holes }}</span>
                    </div>
                </div>

                <!-- PVS (mm/s) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="limitationPVS" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Predicted PPV (mm/s)</Strong>
                        <span class="sub-text">{{ vibrationSummary.predictedPpv }}</span>
                    </div>
                </div>

                <!-- PVS (mm/s) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="actualPVS" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Actual PPV (mm/s)</Strong>
                        <span class="sub-text">{{ vibrationSummary.actualPpv }}</span>
                    </div>
                </div>

                <!-- M.I.C (kg) -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="avgInstantaneous" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">M.I.C (kg)</Strong>
                        <span class="sub-text">{{ vibrationSummary.mic }}</span>
                    </div>
                </div>

                <!-- Sound -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="sound" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Sound</Strong>
                        <span class="sub-text">{{ vibrationSummary.sound }}</span>
                    </div>
                </div>

            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import moment from 'moment'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'BlastDataInfoVibrationSound',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            vibrationSummary: {
                pitName: '-',
                holes: '-',
                predictedPpv: '-',
                actualPpv: '-',
                mic: '-',
                sound: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setVibrationSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setVibrationSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 6
//blastId = 67
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/vibrations/summary"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            if (this.status == '200' && this.dataList.summary != undefined) {
                let vibrationSummary = this.dataList.summary

                this.vibrationSummary.pitName = vibrationSummary.pitName
                this.vibrationSummary.holes = vibrationSummary.holeCount
                this.vibrationSummary.predictedPpv = '-'
                this.vibrationSummary.actualPpv = (vibrationSummary.actualPvs!=null?vibrationSummary.actualPvs:'-')
                this.vibrationSummary.mic = (vibrationSummary.mic!=null?vibrationSummary.mic:'-')
                this.vibrationSummary.sound = (vibrationSummary.sound!=null?vibrationSummary.sound:'-')
            }
        },
        setSummary(item) {
            this.vibrationSummary.pvs2 = (item.pvs2!=null?item.pvs2:'')
            this.vibrationSummary.sound = (item.sound!=null?item.sound:'-')
        }
    }
}
</script>