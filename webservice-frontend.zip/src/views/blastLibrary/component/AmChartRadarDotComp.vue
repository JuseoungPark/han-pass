<template>
    <div class="am-xy-radar" ref="chartRadar"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"
// import am4themes_kelly from "@amcharts/amcharts4/themes/kelly"

// am4core.useTheme(am4themes_animated)
// am4core.useTheme(am4themes_kelly)

am4core.options.queue = false // chart 순차 load
am4core.options.onlyShowOnViewport = false

export default {
    name: 'RadarChart',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        seriesName1: String,
        seriesName2: String,
        seriesName3: String
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
//console.log(this.chartData.data)
        this.renderChart(this.chartData)
    },
    methods: {
        computedList(newChartData) {
            this.okData = []
            this.$nextTick(function() {
                if (newChartData.length != 0) {
                    for(let item of newChartData) {
                        this.okData.push(item)
                    }
                }
            })
            return this.okData
        },
        loadChart() {
            //console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartRadar, am4charts.XYChart)
                chart.svgContainer.measure()

                chart.data = addData.data

            /* Create axes */
            var xAxis = chart.xAxes.push(new am4charts.ValueAxis())
                xAxis.min = -100
                xAxis.max = 100
                xAxis.keepSelection = true
                xAxis.renderer.grid.template.above = true
                xAxis.renderer.minGridDistance = 30
                // xAxis.renderer.opposite = true
                xAxis.renderer.labels.template.fill = am4core.color("#777")
                xAxis.renderer.labels.template.fontSize = 10 // 11

            let yAxis = chart.yAxes.push(new am4charts.ValueAxis())
                yAxis.min = -100
                yAxis.max = 100
                yAxis.keepSelection = true
                yAxis.renderer.grid.template.above = true
                yAxis.renderer.minGridDistance = 30
                yAxis.renderer.labels.template.fill = am4core.color("#777")
                yAxis.renderer.labels.template.fontSize = 10 // 11

            /* Create and configure series1 */
            let series1 = chart.series.push(new am4charts.LineSeries())
                series1.strokeOpacity = 0
                series1.dataFields.valueX = "x"
                series1.dataFields.valueY = "y"
                series1.name = this.seriesName1
                series1.sequencedInterpolation = true
                series1.sequencedInterpolationDelay = 10
                series1.cloneTooltip = false // Tooltip off
                series1.showOnInit = false // animation off
                series1.stroke = am4core.color("#f9b990")
                series1.data = chart.data.series1

            let bulletA = series1.bullets.push(new am4charts.CircleBullet())
                bulletA.circle.radius = 1.5
                bulletA.circle.fill = am4core.color(series1.stroke)
                bulletA.tooltipText = series1.name +
                `
                [bold]Accuracy (Horizontal)[/]
                X : [bold;#fff]{valueX}[/]   Y : [bold;#fff]{valueY}[/]`

            /* Create and configure series2 */
            let series2 = chart.series.push(new am4charts.LineSeries())
                series2.strokeOpacity = 0
                series2.dataFields.valueX = "x"
                series2.dataFields.valueY = "y"
                series2.name = this.seriesName2
                series2.sequencedInterpolation = true
                series2.sequencedInterpolationDelay = 10
                series2.cloneTooltip = false // Tooltip off
                series2.showOnInit = false // animation off
                series2.stroke = am4core.color("#f5854c")
                series2.data = chart.data.series2

            if (this.seriesName2 != '') {
                let bulletB = series2.bullets.push(new am4charts.CircleBullet())
                bulletB.circle.radius = 1.5
                bulletB.circle.fill = am4core.color(series2.stroke)
                bulletB.tooltipText = series2.name +
                `
                [bold]Accuracy (Horizontal)[/]
                X : [bold]{valueX}[/]   Y : [bold]{valueY}[/]`
            }

            /* Create and configure series3 */
            let series3 = chart.series.push(new am4charts.LineSeries())
                series3.strokeOpacity = 0
                series3.dataFields.valueX = "x"
                series3.dataFields.valueY = "y"
                series3.name = this.seriesName3
                series3.sequencedInterpolation = true
                series3.sequencedInterpolationDelay = 10
                series3.cloneTooltip = false // Tooltip off
                series3.showOnInit = false // animation off
                series3.stroke = am4core.color("#f5854c")
                series3.data = chart.data.series3

            if (this.seriesName3 != '') {
                let bulletC = series3.bullets.push(new am4charts.CircleBullet())
                bulletC.circle.radius = 1.5
                bulletC.circle.fill = am4core.color(series3.stroke)
                bulletC.tooltipText = series3.name +
                `
                [bold]Accuracy (Horizontal)[/]
                X : [bold]{valueX}[/]   Y : [bold]{valueY}[/]`
            }

            // let range = xAxis.axisRanges.push(new am4charts.ValueAxisDataItem())
            //     range.endValue = 200
            //     range.value = 50
            //     range.axisFill.fill = am4core.color("#ff0000")
            //     range.axisFill.fillOpacity = 0.1
            //     range.axisFill.adapter.add("innerRadius", (innerRadius, target)=>{
            //         return -yAxis.valueToPoint(4).y
            //     })
            //     range.axisFill.adapter.add("radius", (innerRadius, target)=>{
            //         return -yAxis.valueToPoint(6).y
            //     })

                /* Add legend */
                chart.legend = new am4charts.Legend()
                // chart.legend.useDefaultMarker = true
                chart.legend.position = "top"  // right
                chart.legend.contentAlign = "right"  // right
                chart.legend.marginBottom = 15
                chart.legend.fontSize = 10 // 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 15
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

                /* Add cursor */
                chart.cursor = new am4charts.RadarCursor()

            // let rangeSeries = chart.series.push(new am4charts.RadarColumnSeries())
            //     rangeSeries.hiddenInLegend = true
            //     rangeSeries.dataFields.openValueX = "openX"
            //     rangeSeries.dataFields.valueX = "valueX"
            //     rangeSeries.dataFields.openValueY = "openY"
            //     rangeSeries.dataFields.valueY = "valueY"
            //     rangeSeries.data = [{
            //     openX: 60,
            //     valueX: 300,
            //     openY: 7,
            //     valueY: 8
            // }];

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-radar{
    width:100%;
    height:250px;
}
</style>
