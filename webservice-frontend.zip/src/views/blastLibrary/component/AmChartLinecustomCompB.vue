<template>
    <div class="am-line-chart" ref="chartdiv" :style="'height:'+ chartHeight + 'px'"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
am4core.options.minPolylineStep = 10 // chart 성능 향상을 위한 data 경로 단순화 option

export default {
    name: 'LineSeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        valueAxisXTitle: String,
        valueAxisYTitle: String,
        chartHeight: String,
        lineColor: String
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartdiv, am4charts.XYChart)
                chart.paddingRight = 20
                
                chart.data = addData.data

            let valueAxisX = chart.xAxes.push(new am4charts.ValueAxis())
                valueAxisX.renderer.grid.template.location = 0
                valueAxisX.renderer.minGridDistance = 30
                valueAxisX.title.text = this.valueAxisXTitle
                valueAxisX.renderer.labels.template.fill = am4core.color("#777")
                valueAxisX.renderer.labels.template.fontSize = 11

            let valueAxisY = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxisY.title.text = this.valueAxisYTitle
                valueAxisY.renderer.labels.template.fill = am4core.color("#777")
                valueAxisY.renderer.labels.template.fontSize = 11

            let series = chart.series.push(new am4charts.LineSeries())
                series.dataFields.valueX = "valueX"
                series.dataFields.valueY = "valueY"
                // series.tooltipText = "{valueY}"
                series.tooltipText =  this.valueAxisYTitle + " : {valueY}\n" + this.valueAxisXTitle + " : {valueX}"
                series.stroke = am4core.color(this.lineColor)
                series.tooltip.background.fill = am4core.color(this.lineColor)
                series.tooltip.getFillFromObject = false
                series.tooltip.pointerOrientation = "vertical"

                chart.cursor = new am4charts.XYCursor()
                chart.cursor.snapToSeries = series
                chart.cursor.xAxis = valueAxisX

            // let scrollbarX = new am4charts.XYChartScrollbar()
            //     scrollbarX.series.push(series)
            //     chart.scrollbarX = scrollbarX

            if(this.chartData.legends)
                chart.legend = new am4charts.Legend()

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-line-chart{
    width:100%;
    /* height:300px; */
}
</style>