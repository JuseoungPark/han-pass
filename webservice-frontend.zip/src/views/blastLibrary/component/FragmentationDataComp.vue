<template>
    <CCard class="mb-0">
        <CForm @submit.prevent>
            <CCardHeader>
                <strong>Fragmentation Data Import</strong>
            </CCardHeader>
            <CCardBody class="form-group-wrap">
                <div role="group">
                    <ul class="list-unstyled full-width">
                        <li v-for="(item, index) in fileList" :key="index" class="full-width">
                            <label class="col-form-label col-sm-12 px-0">{{ item.unitName }}
                                <span v-if="item.upFileStr != ''" @click="fileClick(item)" class="down-wrap"><app-icon name="fileDown" size="s" fill class="ml-2" />{{ item.upFileStr }}</span>
                            </label>
                            <div class="col-sm-12" style="padding-left:10px;">
                                <input :id="'drilling-file-add-0'+index" type="file" class="custom-file-input custom" v-bind:name="item.equipmentId" v-on:input="process(index, $event)">
                                <label :for="'drilling-file-add-0'+index+' col-sm-12'" class="custom-file-label">
                                    {{ item.fileName }}
                                    <span class="icon-wrap">
                                        <CIcon name="cil-library-add" />
                                    </span>
                                </label>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="mt-3">
                    <label for="actual">Actual D50</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="actual"
                            placeholder="Please enter Actual D50"
                            type="text"
                            name="actualD50"
                            append="mm"
                            v-model.trim="$v.form.actualD50.$model"
                            :isValid="$v.form.actualD50.$dirty ? !$v.form.actualD50.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.actualD50" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <CTextarea
                    label="Remark"
                    placeholder="Please enter Remark"
                    rows="4"
                    class="mt-2"
                    :maxlength="250"
                    block
                    name="remark"
                    v-model.trim="$v.form.remark.$model"
                    :isValid="$v.form.remark.$dirty ? !$v.form.remark.$error : null">
                    <template slot="invalid-feedback">
                        <ValidFeedback :param="$v.form.remark" />
                    </template>
                </CTextarea>
            </CCardBody>
            <CCardFooter>
                <CButton type="submit"
                    class="btn-custom-default hanwha outline rectangle"
                    :disabled="!isValid"
                    @click="submit"
                >
                    {{ $t('commonLabel.submit') }}
                </CButton>
                <CButton type="button"
                    class="btn-custom-default outline rectangle"
                    @click="editPopClose"
                >
                    {{ $t('commonLabel.cancel') }}
                </CButton>
            </CCardFooter>
        </CForm>
    </CCard>
</template>

<script>
import utils from '@/assets/js/utils'
import ValidFeedback from '@/components/form/ValidFeedback'
import { mapGetters, mapActions } from 'vuex'
import { validationMixin } from "vuelidate"
import { required, decimal, numeric, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
const blastLibrary = 'blastLibrary'

export default {
    name: 'FragmentationData',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        ValidFeedback,
        AppIcon
    },
    data() {
        return {
            spinnerFlag: false,

            fileList: [],
            form: this.getEmptyForm()
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            actualD50: {
                decimal,
                between: between(-999.999999999999999, 999.999999999999999),
                decimalLimit: decimalLimit(15)
            },
            remark: {
                byte: byte(250)
            },
        }
    },
    mounted() {
        if (this.blastId != 0) {
            this.getInterfaceInfo()
        }
        console.log(this.validations)
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
        }),
        isValid() {
            return !this.$v.form.$invalid
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            downloadAction: 'download',
            putDataAction: 'putData',
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setFileDataAction: 'setFileData',
        }),
        async getInterfaceInfo() {
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 67
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/fragmentation"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let fileInfo = { siteId: '', unitName: '', equipmentId: '', upFileName: '', upFileStr: '', fileName: '', file: '', fileId: '', fileType: '' }

            fileInfo.siteId = siteId

            fileInfo.unitName = 'Fragmentation PDF'
            fileInfo.fileType = 'fragmentationpdf'
            let pdfFileInfo = Object.assign({}, fileInfo)

            fileInfo.unitName = 'Fragmentation Analysis File'
            fileInfo.fileType = 'file'
            let resultFileInfo = Object.assign({}, fileInfo)

            this.data.content.forEach (function (el, index) {
                if (el.fileType == 'fragmentationpdf') {
                    pdfFileInfo.fileId = el.fileId
                    pdfFileInfo.fileType = el.fileType
                    pdfFileInfo.upFileName = el.fileName
                    pdfFileInfo.upFileStr = ' ( '+ pdfFileInfo.upFileName +' )'
                }else{
                    resultFileInfo.fileId = el.fileId
                    resultFileInfo.fileType = el.fileType
                    resultFileInfo.upFileName = el.fileName
                    resultFileInfo.upFileStr = ' ( '+ resultFileInfo.upFileName +' )'
                }
            })
                // let fileId = this.data.content[0].fileId
                // let upFileName = this.data.content[0].fileName
                // let upFileStr = ' ( '+upFileName+' )'

                // fileInfo.fileId = fileId
                // fileInfo.upFileName = upFileName
                // fileInfo.upFileStr = upFileStr

                // this.fileList.push(fileInfo)

            this.fileList.push(pdfFileInfo)
            this.fileList.push(resultFileInfo)

            if (this.data.remark.length == 0) {
                this.form = this.getEmptyForm()
            }else{
                let interfaceInfo = this.data.remark[0]

                this.form.actualD50 = interfaceInfo.fragmentationActualD50
                this.form.remark = interfaceInfo.fragmentationRemark
            }

            this.spinnerFlag = false
        },
        async submit() {
            let that = this
            that.spinnerFlag = true

            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 67
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/fragmentation/remark"
            await this.putDataAction({
                params: {
                    fragmentationActualD50: this.form.actualD50,
                    fragmentationRemark: this.form.remark,
                },
                moduleName: moduleName
            })

            for (const item of that.fileList) {
                if (item.file != '') {
                    that.form.blastId = blastId
                    that.form.uploadFile = item.file

                    if (item.fileType == 'fragmentationpdf') moduleName = "v1/files/"+siteId+"/fragmentationpdf?blastId="+blastId
                    else moduleName = "v1/files/"+siteId+"/fragmentation?blastId="+blastId
                    await this.setFileDataAction({
                        params: that.form,
                        moduleName: moduleName
                    })
                }
            }
            this.$emit('submitChk', 'fragmentation')
            that.editPopClose()
            that.spinnerFlag = false
        },
        async fileClick(item) {
            let fileName = item.upFileName

            await this.downloadAction({
                params : {
                    fileName: fileName
                },
                moduleName : `v1/files/${item.siteId}/${item.fileType}/download/${item.fileId}`
            })
        },
        editPopClose() {
            this.$emit('closeEditPop')
        },
        process(index, event) {
            this.fileList[index].fileName = event.target.value
            this.fileList[index].file = event.target.files[0]
        },
        getEmptyForm() {
            return {
                actualD50: '',
                remark: '',
            }
        },
    }
}
</script>