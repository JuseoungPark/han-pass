<template>
    <div>
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <CCard class="table-card-wrap">
            <CCardHeader>
                <strong>Productivity</strong>
            </CCardHeader>
            <CCardBody class="table-max-height200">
                <div class="position-relative table-responsive data-table typeA">
                    <fieldset>
                        <legend class="sr-only">Productivity dataSet</legend>
                        <table class="table table-fixed table-bordered table-hover mb-0">
                            <thead>
                                <tr>
                                    <th
                                        v-for="(item, index) in productivityThItems"
                                        :key="index"
                                        scope="col"
                                    >
                                        {{ item.titText }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="(item, index) in productivityTdItems"
                                    :key="index"
                                >
                                    <th class="text-nowrap">{{ item.titText }}</th>
                                    <td>{{ item.targetValue | Commas }}</td>
                                    <td>{{ item.actualValue | Commas }}</td>
                                    <td>{{ item.percentValue | Commas }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </fieldset>
                </div>
            </CCardBody>
        </CCard>
        <CRow class="chart-wrap">
            <CCol lg="6">
                <CCard>
                    <CCardHeader>
                        <strong>Target, Actual Drill meter</strong>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartLayeredColumnComp
                            seriesName="Target"
                            series2Name="Drill meter"
                            targetColor="rgb(249, 185, 144)"
                            chartColor="rgb(243, 115, 33)"
                            chartHeight="250"
                            :chartData=layeredChartData1
                        />
                    </CCardBody>
                </CCard>
            </CCol>
            <CCol lg="6">
                <CCard>
                    <CCardHeader>
                        <strong>Target, Actual BCM</strong>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartLayeredColumnComp
                            seriesName="Target"
                            series2Name="Actual BCM"
                            targetColor="rgb(249, 185, 144)"
                            chartColor="rgb(243, 115, 33)"
                            chartHeight="250"
                            :chartData=layeredChartData2
                        />
                    </CCardBody>
                </CCard>
            </CCol>
            <CCol lg="6">
                <CCard>
                    <CCardHeader>
                        <strong>Cost</strong><small class="ml-2">(Drill, Explosives, Initialtion, labor, extra)</small>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartPieHoverComp
                            chartHeight="250"
                            :chartData=pieChartData
                        />
                    </CCardBody>
                </CCard>
            </CCol>
            <CCol lg="6">
                <CCard>
                    <CCardHeader>
                        <strong>Target, Actual Total cost</strong>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartLayeredColumnComp
                            seriesName="Target"
                            series2Name="Total cost"
                            targetColor="rgb(249, 185, 144)"
                            chartColor="rgb(243, 115, 33)"
                            chartHeight="250"
                            :chartData=layeredChartData3
                        />
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    </div>
</template>

<script>
const AmChartPieHoverComp = () => import(/* webpackChunkName: "ProductivityCostCharts" */ './AmChartPieHoverComp')
const AmChartLayeredColumnComp = () => import(/* webpackChunkName: "ProductivityCostCharts" */ './AmChartLayeredColumnComp')

import { mapGetters, mapActions } from 'vuex'
import utils from '@/assets/js/utils'

const blastLibrary = 'blastLibrary'

export default {
    name: 'ProductivityComp',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartPieHoverComp,
        AmChartLayeredColumnComp
    },
    data(){
        return {
            spinnerFlag: false,
            // Productivity table
            productivityThItems: [
                { titText: '' },
                { titText: 'Target Production' },
                { titText: 'Actual Production' },
                { titText: '%' }
            ],
            productivityTdItems: [
                { titText: 'Drill', targetValue: '-', actualValue: '-', percentValue: '-' },
                { titText: 'Blasting', targetValue: '-', actualValue: '-', percentValue: '-' },
            ],

            // chart data
            layeredChartData1: {
                data: [{
                    "category": "Drill",
                    "value1": 0,
                    "value2": 0
                }]
            },
            layeredChartData2: {
                data: [{
                    "category": "Blasting",
                    "value1": 0,
                    "value2": 0
                }]
            },
            layeredChartData3: {
                data: [{
                    "category": "Actual Total cost",
                    "value1": 0,
                    "value2": 0
                }]
            },
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setProductivityComp()
            this.setPieChartData()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
        userSite () {
            return utils.getUserInformation().selectedUserSite
        },
        pieChartData() {
            return {
                data: [
                    { "country": `Drilling cost (${this.userSite.currencyName})`, "litres": 0 },
                    { "country": `Explosives cost (${this.userSite.currencyName})`, "litres": 0 },
                    { "country": `Initialtion cost (${this.userSite.currencyName})`, "litres": 0 },
                    { "country": `Labor cost (${this.userSite.currencyName})`, "litres": 0 },
                    { "country": `Extra cost (${this.userSite.currencyName})`, "litres": 0 },
                ]
            }
        }
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setProductivityComp() {
            let that = this
            that.spinnerFlag = true
            // 입력값 설정
            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId
//siteId = 6
//blastId = 190
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/costs/productivity"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            that.productivityTdItems.forEach(function (el) {
                el.targetValue = '-'
                el.actualValue = '-'
                el.percentValue = '-'
            })

            if (that.status == '200') {
                let idx = 0
                that.dataList.forEach(function (item) {
                    if (item.type == 'Drill') idx = 0
                    else idx = 1

                    that.productivityTdItems[idx].targetValue = (item.targetProduction!=null?item.targetProduction:'0')
                    that.productivityTdItems[idx].actualValue = (item.actualProduction!=null?item.actualProduction:'0')
                    that.productivityTdItems[idx].percentValue = (item.per!=null?item.per:'0')

                    if (item.targetProduction!=null) {
                        if (item.type == 'Drill') {
                            that.layeredChartData1.data = []
                            that.layeredChartData1.data.push({
                                "category": "Drill",
                                "value1": that.productivityTdItems[idx].targetValue,
                                "value2": that.productivityTdItems[idx].actualValue,
                            })
                        }else{
                            that.layeredChartData2.data = []
                            that.layeredChartData2.data.push({
                                "category": "Blasting",
                                "value1": that.productivityTdItems[idx].targetValue,
                                "value2": that.productivityTdItems[idx].actualValue,
                            })
                        }
                    }
                })
                let costChart = that.data.costChart
                if (costChart != undefined) {
                    that.layeredChartData3.data = []
                    that.layeredChartData3.data.push({
                        "category": `Total cost (${this.userSite.currencyName})`,
                        "value1": costChart.targetCost,
                        "value2": costChart.actualCost,
                    })
                }
            }

            that.spinnerFlag = false
        },
        async setPieChartData() {
            let that = this
            // 입력값 설정
            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/costs/cost"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)
            if (that.status == '200') {
                let drillCost = that.dataList.drillCost
                if (drillCost != undefined) {
                    that.pieChartData.data[0].litres = (drillCost.total!=null?drillCost.total:0)
                }
                let explosiveCost = that.dataList.explosiveCost
                if (explosiveCost != undefined) {
                    that.pieChartData.data[1].litres = (explosiveCost.total!=null?explosiveCost.total:0)
                }
                let initiationCost = that.dataList.initiationCost
                if (initiationCost != undefined) {
                    that.pieChartData.data[2].litres = (initiationCost.total!=null?initiationCost.total:0)
                }
                let laborCost = that.dataList.laborCost
                if (laborCost != undefined) {
                    that.pieChartData.data[3].litres = (laborCost.total!=null?laborCost.total:0)
                }
                let extraCost = that.dataList.extraCost
                if (extraCost != undefined) {
                    that.pieChartData.data[4].litres = (extraCost.total!=null?extraCost.total:0)
                }
            }
        }
    }
}
</script>