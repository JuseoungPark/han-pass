<template>
    <CCard class="mb-0">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <CForm @submit.prevent>
            <CCardHeader>
                <strong>Drilling Result Data Import</strong>
            </CCardHeader>
            <CCardBody class="form-group-wrap">
                <div role="group">
                    <ul class="list-unstyled full-width">
                        <li v-for="(item, index) in fileList" :key="index" class="full-width">
                            <label class="col-form-label col-sm-12 px-0">{{ item.unitName }}
                                <span v-if="item.upFileStr != ''" @click="fileClick(item)" class="down-wrap"><app-icon name="fileDown" size="s" fill class="ml-2" />{{ item.upFileStr }}</span>
                            </label>
                            <div class="col-sm-12" style="padding-left:10px;">
                                <input :id="'drilling-file-add-0'+index" type="file" class="custom-file-input custom" v-bind:name="item.equipmentId" v-on:input="process(index, $event)">
                                <label :for="'drilling-file-add-0'+index+' col-sm-12'" class="custom-file-label">
                                    {{ item.fileName }}
                                    <span class="icon-wrap">
                                        <CIcon name="cil-library-add" />
                                    </span>
                                </label>
                            </div>
                        </li>
                    </ul>
                </div>
                <CTextarea
                    label="Remark"
                    placeholder="Please enter Remark"
                    rows="4"
                    class="mt-2"
                    :maxlength="250"
                    block
                    name="remark"
                    :value.sync="drillingRemark"
                />
            </CCardBody>
            <CCardFooter>
                <CButton type="submit"
                    class="btn-custom-default hanwha outline rectangle"
                    @click="submit"
                >
                    {{ $t('commonLabel.submit') }}
                </CButton>
                <CButton type="button"
                    class="btn-custom-default outline rectangle"
                    @click="editPopClose"
                >
                    {{ $t('commonLabel.cancel') }}
                </CButton>
            </CCardFooter>
        </CForm>
    </CCard>
</template>

<script>
import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
const blastLibrary = 'blastLibrary'

export default {
    name: 'DrillingResultData',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            spinnerFlag: false,

            form: {},
            fileList: [],
            drillingRemark: '',
        }
    },
    mounted() {
        if (this.blastId != 0) {
            this.getInterfaceInfo()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            downloadAction: 'download',
            putDataAction: 'putData',
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setFileDataAction: 'setFileData',
        }),
        async getInterfaceInfo() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 67
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/drilling"
//console.log(moduleName)
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
//console.log(this.dataList)
            this.fileList = []
            this.dataList.forEach(function (el, index) {
                // let upFileName = ''
                // if (el.fileName != '' && el.fileName != null) upFileName = ' ('+ el.fileName +')'

                // that.fileList.push({ unitName: el.equipmentName, equipmentId: el.equipmentId, upFileName: upFileName, upFileStr: '', fileName: '', file: '', fileId: '' })

                let fileInfo = { siteId: '', unitName: '', equipmentId: '', upFileName: '', upFileStr: '', fileName: '', file: '', fileId: '', fileType: '' }

                fileInfo.siteId = siteId

                fileInfo.equipmentId = el.equipmentId
                fileInfo.unitName = el.equipmentName
                if (el.fileId != null && el.fileId != '') {
                    let upFileName = el.fileName
                    let upFileStr = ' ( '+upFileName+' )'

                    fileInfo.fileType = el.fileType
                    fileInfo.fileId = el.fileId
                    fileInfo.upFileName = upFileName
                    fileInfo.upFileStr = upFileStr
                }
                that.fileList.push(fileInfo)
            })

            if (this.data.remark.length>0) {
                let remark = this.data.remark[0].drillingRemark
                if (remark != undefined) {
                    this.drillingRemark = remark
                }
            }
            if (this.fileList.length == 0) {
                utils.showToastRed(this.$t('message.requiredEquipment'))
            }

            that.spinnerFlag = false
        },
        async submit() {
            let that = this
            that.spinnerFlag = true

            if (this.fileList.length == 0) {
                utils.showToastRed(this.$t('message.requiredEquipment'))
                that.spinnerFlag = false
                return
            }

            let siteId = this.siteId
            let blastId = this.blastId
//siteId = 1
//blastId = 67
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/drilling/remark"
            await this.putDataAction({
                params: {
                    drillingRemark: this.drillingRemark,
                },
                moduleName: moduleName
            })

            for (const item of that.fileList) {
                if (item.file != '') {
                    that.form.blastId = blastId
                    that.form.equipmentId = item.equipmentId
                    that.form.uploadFile = item.file

                    moduleName = "v1/files/"+siteId+"/drilling?blastId="+blastId+"&equipmentId="+item.equipmentId
                    await this.setFileDataAction({
                        params: that.form,
                        moduleName: moduleName
                    })
                }
            }
            this.$emit('submitChk', 'drilling')
            that.editPopClose()
            that.spinnerFlag = false
        },
        async fileClick(item) {
            let fileName = item.upFileName

            await this.downloadAction({
                params: {
                    fileName: fileName
                },
                moduleName : `v1/files/${item.siteId}/drilling/download/${item.fileId}`
            })
        },
        editPopClose() {
            this.$emit('closeEditPop')
        },
        process(index, event) {
            this.fileList[index].fileName = event.target.value
            this.fileList[index].file = event.target.files[0]

            //this.fileName = event.target.value
            //this.$emit('input', event.target.value);
        }
    }
}
</script>