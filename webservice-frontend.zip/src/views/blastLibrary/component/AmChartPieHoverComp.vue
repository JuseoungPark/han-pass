<template>
    <div class="am-pie-chart" ref="chartPie" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

function am4themes_myTheme(target) {
    if (target instanceof am4core.ColorSet) {
        target.list = [
            am4core.color("#f9b990"),
            am4core.color("#f5854c"),
            am4core.color("#fd6402"),
            am4core.color("#a35732"),
            am4core.color("#d75c5c")
        ];
    }
}

// am4core.useTheme(am4themes_animated)
am4core.useTheme(am4themes_myTheme)

export default {
    name: 'PieChart',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartPie, am4charts.PieChart)
                chart.svgContainer.measure()

                chart.data = addData.data

            // Add and configure Series
            let pieSeries = chart.series.push(new am4charts.PieSeries())
                pieSeries.dataFields.value = "litres"
                pieSeries.dataFields.category = "country"
                pieSeries.slices.template
                // change the cursor on hover to make it apparent the object can be interacted with
                .cursorOverStyle = [
                    {
                    "property": "cursor",
                    "value": "pointer"
                    }
                ]
                pieSeries.labels.template.disabled = true
                pieSeries.cloneTooltip = false // Tooltip off
                pieSeries.showOnInit = false // animation off

                // Create a base filter effect (as if it's not there) for the hover to return to
                let shadow = pieSeries.slices.template.filters.push(new am4core.DropShadowFilter)
                    shadow.opacity = 0

                // Create hover state
                let hoverState = pieSeries.slices.template.states.getKey("hover") // normally we have to create the hover state, in this case it already exists

                // Slightly shift the shadow and make it more prominent on hover
                let hoverShadow = hoverState.filters.push(new am4core.DropShadowFilter)
                    hoverShadow.opacity = 0.7
                    hoverShadow.blur = 5

                // Add a legend
                chart.legend = new am4charts.Legend()
                chart.legend.position = "right"
                chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

                let markerTemplate = chart.legend.markers.template
                    markerTemplate.width = 6
                    markerTemplate.height = 6
                    markerTemplate.margin(0, 5, 0, 0)
                    markerTemplate.stroke = am4core.color("#ccc")
                    
                let ring = markerTemplate.createChild(am4core.Circle);
                    ring.radius = 6
                    ring.x = 4
                    ring.y = 4
                    ring.opacity = 0
                    ring.verticalCenter = "middle"
                    ring.fill = am4core.color('green')// ignored unless useDefaultMarker is true
                    ring.toBack()

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-pie-chart{
    width:100%;
    /* height:250px; */
}
</style>