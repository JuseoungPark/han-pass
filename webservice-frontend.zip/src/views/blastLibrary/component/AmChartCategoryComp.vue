<template>
    <div class="am-xy-chart" ref="chartxy"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)

export default {
    name: 'xySeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        seriesName: String,
        isGuide: Boolean
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateRawData();
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
                chart.svgContainer.measure()

                chart.data = addData.data

            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "category"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.minGridDistance = 30
                categoryAxis.renderer.labels.template.fill = am4core.color("#777")
                categoryAxis.renderer.labels.template.fontSize = 10 // 11

            let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxis.renderer.labels.template.fill = am4core.color("#777")
                valueAxis.renderer.labels.template.fontSize = 10 // 11

            // Create series
            let series = chart.series.push(new am4charts.ColumnSeries())
                series.dataFields.valueY = "value"
                series.dataFields.categoryX = "category"
                series.name = this.seriesName
                series.columns.template.tooltipText = "[bold]" + this.seriesName + "[/]\n{categoryX} : [bold;#fff]{valueY}[/]"
                series.columns.template.strokeWidth = 0
                series.columns.template.fill = am4core.color("#f9b990")
                series.cloneTooltip = false // Tooltip off
                series.showOnInit = false // animation off

                series.columns.template.tooltipX = am4core.percent(50)
                series.columns.template.tooltipY = am4core.percent(0)

                series.tooltip.pointerOrientation = "vertical"

            if( this.isGuide ){

                let centerRange = categoryAxis.axisRanges.create()
                    centerRange.category = "0.0"
                    centerRange.endCategory = "0.0"
                    // centerRange.axisFill.fill = am4core.color("#396478")
                    // centerRange.axisFill.fillOpacity = 0.3
                    centerRange.label.fill = chart.colors.list[1]
                    centerRange.label.dy = 10
                    centerRange.label.fontWeight = "600"
                    centerRange.grid.strokeOpacity = 0.3
                    centerRange.grid.stroke = am4core.color("#5ea565")
                    centerRange.label.fill = centerRange.grid.stroke
            }


            // chart color set
            // series.columns.template.adapter.add("fill", function(fill, target) {
            //     return chart.colors.getIndex(target.dataItem.index);
            // })

            chart.cursor = new am4charts.XYCursor()
            chart.cursor.behavior = "panX"
            chart.cursor.xAxis = categoryAxis
            chart.cursor.fullWidthLineX = true
            chart.cursor.lineX.strokeWidth = 0
            chart.cursor.lineX.fill = am4core.color("#000")
            chart.cursor.lineX.fillOpacity = 0.1
            // chart.cursor.behavior = "selectX"
            chart.cursor.lineY.disabled = true

            chart.legend = new am4charts.Legend()
            chart.legend.useDefaultMarker = false
            chart.legend.position = "top" // top
            chart.legend.contentAlign = "right"  // right
            chart.legend.marginBottom = 15
            chart.legend.fontSize = 10 // 11
            // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>