<template>
    <div>
        <ul class="list-unstyled half-layout align-items-stretch my-2 bg-light-gary">
            <li><span class="list-tit">Monitoring point name  :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Monitoring point type :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Model :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Serial number :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Distance :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Measured time :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Sample rate :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Trigger level :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Limitation PVS :</span> {{ sampleTextData }}</li>
            <li><span class="list-tit">Limitation Sound :</span> {{ sampleTextData }}</li>
        </ul>
        <CRow>
            <CCol lg="5">
                <div class="operation-table-wrap">
                    <div class="position-relative table-responsive ">
                        <fieldset>
                            <legend class="sr-only">Measured dataSet</legend>
                            <table class="table table-fixed table-bordered table-hover mb-0">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="row">Measured data</th>
                                        <th scope="row" colspan="3"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-nowrap">Geophone</td>
                                        <td>Tran</td>
                                        <td>Vert</td>
                                        <td>Long</td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">PPV</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">ZC freq</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Dominant freq</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Peak time</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Peak acceleration</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Peak Displacement</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Sensor check</td>
                                        <td>Xxx</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Expected PVS</td>
                                        <td colspan="3">Xxx</td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Actual PVS</td>
                                        <td colspan="3">Xxx</td>
                                    </tr>
                                    <tr>
                                        <td class="text-nowrap">Sound level</td>
                                        <td colspan="3">Xxx</td>
                                    </tr>
                                </tbody>
                            </table>
                        </fieldset>
                    </div>
                </div>
            </CCol>
            <CCol lg="7">
                <CTabs variant="pills" :active-tab="0" class="3depth lg-mt">
                    <CTab title="Vibration & sound record" sm="3">
                        <ul class="max-height508 list-unstyled mt-2 mb-0">
                            <li>
                                <AmChartLinecustomCompA
                                    chartHeight="180"
                                    dateAxisTitle="[bold] Time (sec)[/]"
                                    valueAxisYTitle="[bold] Tran 
                                    Velocity (mm/s)[/]"
                                    lineColor="rgb(232, 65, 23)"
                                    :chartData= lineChartData2
                                />
                            </li>
                            <li>
                                <AmChartLinecustomCompA
                                    chartHeight="180"
                                    dateAxisTitle="[bold] Time (sec)[/]"
                                    valueAxisYTitle="[bold] Vert 
                                    Velocity (mm/s)[/]"
                                    lineColor="rgb(66, 245, 144)"
                                    :chartData= lineChartData2
                                />
                            </li>
                            <li>
                                <AmChartLinecustomCompA
                                    chartHeight="180"
                                    dateAxisTitle="[bold] Time (sec)[/]"
                                    valueAxisYTitle="[bold] Long 
                                    Velocity (mm/s)[/]"
                                    lineColor="rgb(66, 164, 245)"
                                    :chartData= lineChartData2
                                />
                            </li>
                            <li>
                                <AmChartLinecustomCompA
                                    chartHeight="180"
                                    dateAxisTitle="[bold] Time (sec)[/]"
                                    valueAxisYTitle="[bold] MicA 
                                    Pressure (A)(db(A))[/]"
                                    lineColor="rgb(143, 144, 150)"
                                    :chartData= lineChartData2
                                />
                            </li>
                        </ul>
                    </CTab>
                    <CTab title="FFT" sm="3">
                        <ul class="max-height508 list-unstyled mt-2">
                            <li>
                                <strong class="font-small d-block text-center">Tran - Dominant Frequency 4.8 Hz, Amplitude 0.067 mm/s (Peak Particle Velocity: 0.460 mm/s)</strong>

                                <AmChartLinecustomCompB
                                    chartHeight="180"
                                    valueAxisXTitle="[bold] Frequency (Hz)[/]"
                                    valueAxisYTitle="[bold] Velocity (mm/s)[/]"
                                    lineColor="rgb(232, 65, 23)"
                                    :chartData= lineChartData3
                                />

                            </li>
                            <li>
                                <strong class="font-small d-block text-center">Vert - Dominant Frequency 4.9 Hz, Amplitude 0.090 mm/s (Peak Particle Velocity: 0.762 mm/s)</strong>

                                <AmChartLinecustomCompB
                                    chartHeight="180"
                                    valueAxisXTitle="[bold] Frequency (Hz)[/]"
                                    valueAxisYTitle="[bold] Velocity (mm/s)[/]"
                                    lineColor="rgb(66, 245, 144)"
                                    :chartData= lineChartData3
                                />

                            </li>
                            <li>
                                <strong class="font-small d-block text-center">Long - Dominant Frequency 5.8 Hz, Amplitude 0.116 mm/s (Peak Particle Velocity: 0.984 mm/s)</strong>
                                
                                <AmChartLinecustomCompB
                                    chartHeight="180"
                                    valueAxisXTitle="[bold] Frequency (Hz)[/]"
                                    valueAxisYTitle="[bold] Velocity (mm/s)[/]"
                                    lineColor="rgb(66, 164, 245)"
                                    :chartData= lineChartData3
                                />

                            </li>
                        </ul>
                    </CTab>
                    <CTab title="Velocity vs Frequency" sm="3">
                        <div class="mt-3">
                            <strong class="font-small d-block text-center">USBM RI8507 And OSMRE</strong>
                            <strong class="font-small d-block text-center">Velocity Versus Frequency (Zero Crossing)</strong>

                            <AmChartLineLegendCustomComp
                                valueAxisXTitle="[bold] Frequency (Hz)[/]"
                                valueAxisYTitle="[bold] Velocity (mm/s)[/]"
                                chartHeight="350"
                                :chartData= LineLegendCustomData 
                            />
                        </div>
                    </CTab>
                </CTabs>
            </CCol>
        </CRow>
            
    </div>
</template>
<script>
const AmChartLinecustomCompA = () => import(/* webpackChunkName: "VibrationSoundCharts" */ './AmChartLinecustomCompA')
const AmChartLinecustomCompB = () => import(/* webpackChunkName: "VibrationSoundCharts" */ './AmChartLinecustomCompB')
const AmChartLineLegendCustomComp = () => import(/* webpackChunkName: "VibrationSoundCharts" */ './AmChartLineLegendCustomComp')

export default {
    name: 'ChargeOperationTab',
    components: {
        AmChartLinecustomCompA,
        AmChartLinecustomCompB,
        AmChartLineLegendCustomComp
    },
    data() {
        return{
            sampleTextData: 'sample-data',
            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            lineChartData2: {
                data: []
            },
            lineChartData3: {
                data: []
            },
            LineLegendCustomData: {
                data: [{
                    "y": 10,
                    "x": 14,
                    "value": 2,
                    "y2": 5,
                    "x2": 3,
                    "value2": 2,
                    "y3": 2,
                    "x3": 7,
                    "value3": 2,
                }, {
                    "y": 5,
                    "x": 3,
                    "value": 2,
                    "y2": 15,
                    "x2": 8,
                    "value2": 2,
                    "y3": 5,
                    "x3": 5,
                    "value3": 2,
                }, {
                    "y": 10,
                    "x": 8,
                    "value": 2,
                    "y2": 4,
                    "x2": 6,
                    "value2": 2,
                    "y3": 4,
                    "x3": 8,
                    "value3": 2,
                }, {
                    "y": 6,
                    "x": 5,
                    "value": 2,
                    "y2": 5,
                    "x2": 6,
                    "value2": 2,
                    "y3": 5,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 15,
                    "x": 4,
                    "value": 2,
                    "y2": 10,
                    "x2": 8,
                    "value2": 2,
                    "y3": 6,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 13,
                    "x": 6,
                    "value": 2,
                    "y2": 2,
                    "x2": 10,
                    "value2": 2,
                    "y3": 2,
                    "x3": 10,
                    "value3": 2,
                }, {
                    "y": 1,
                    "x": 6,
                    "value": 2,
                    "y2": 0,
                    "x2": 3,
                    "value2": 2,
                    "y3": 10,
                    "x3": 5,
                    "value3": 2,
                }]
            },
        }
    },
    mounted() {
        this.lineData2()
        this.lineData3()
    },
    methods: {
        lineData2(){
            // sample line chart data
            let firstDate = new Date()
                // now set 500 minutes back
                firstDate.setMinutes(firstDate.getDate() - 500)
            
            let value  = 500
            for (let i = 0; i < 500; i++) {
                let newDate = new Date(firstDate)
                    // each time we add one minute
                    newDate.setMinutes(newDate.getMinutes() + i)
                // let date = new Date()
                    // date.setHours(0,0,0,0)
                    // date.setDate(i)

                value -= Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10)
                this.lineChartData2.data.push({date: newDate, value: value})
            }
        },
        lineData3(){
            // sample line chart data
            let valueY  = 500
            for (let i = 0; i < 500; i++) {

                valueY -= Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10)
                this.lineChartData3.data.push({valueX: i, valueY: valueY})
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.list-tit{
    font-weight: 700;
}
</style>