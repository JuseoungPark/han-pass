<template>
    <div class="am-xy-chart" ref="chartxy" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)

export default {
    name: 'xySeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
        seriesName: String,
        lineSeriesName: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
                chart.svgContainer.measure()

                chart.data = addData.data

                chart.validateData()
                
            // Create axes
            let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis())
                categoryAxis.treatZeroAs = 0.01
                //valueAxisX.min = 0.1
                categoryAxis.max = 10
                categoryAxis.logarithmic = true
                categoryAxis.dataFields.category = "valueBx"
                categoryAxis.title.text = 'Size (m) Diameter of an Equivalent Sphere'
                categoryAxis.renderer.minGridDistance = 30
                categoryAxis.renderer.labels.template.fill = am4core.color("#777")
                categoryAxis.renderer.labels.template.fontSize = 11
                categoryAxis.strictMinMax = true

            let valueAxisY = chart.yAxes.push(new am4charts.ValueAxis())
                // valueAxisY.treatZeroAs = 0.1
                //valueAxisY.min = 0.1
                // valueAxisY.logarithmic = true
                // valueAxisY.renderer.minGridDistance = 30
                valueAxisY.title.text = '% Passing'
                valueAxisY.renderer.labels.template.fill = am4core.color("#777")
                valueAxisY.renderer.labels.template.fontSize = 11
                valueAxisY.strictMinMax = true

            // Create series
            let series = chart.series.push(new am4charts.ColumnSeries())
                series.dataFields.categoryX = "valueBx"
                series.dataFields.valueY = "valueBy"
                series.name = this.seriesName
                series.columns.template.fill = am4core.color("#f9b990")
                series.tooltipText = "[bold;#fff]{categoryX} (m)\n[bold;#fff]{valueY} (%)[/]"
                series.cloneTooltip = false // Tooltip off
                series.showOnInit = false // animation off
                series.columns.template.width = am4core.percent(95)

                series.tooltip.pointerOrientation = "vertical"

            // let series = chart.series.push(new am4charts.StepLineSeries())
            //     // series.sequencedInterpolation = true
            //     series.dataFields.valueX = "valueBx"
            //     series.dataFields.valueY = "valueBy"
            //     // series.smoothing = "monotoneX"
            //     // series.smoothing = "monotoneY"
            //     series.connect = true
            //     series.name = this.seriesName
            //     // series.tooltipText = "[bold]{valueY}[/]"
            //     series.strokeWidth = 1
            //     // series.stroke = am4core.color("rgb(209, 115, 196)")
            //     series.fillOpacity = 0.6
            //     series.cloneTooltip = false // Tooltip off
            //     series.showOnInit = false // animation off
            //     series.startLocation = 0.5

            //     series.tooltip.pointerOrientation = "vertical"

            let lineSeries = chart.series.push(new am4charts.LineSeries())
                lineSeries.dataFields.categoryX = "valueAx"
                lineSeries.dataFields.valueY = "valueAy"
                lineSeries.name = this.lineSeriesName
                lineSeries.tooltipText = "[bold;#fff]{valueY} (%)[/]"
                lineSeries.strokeWidth = 1
                lineSeries.stroke = am4core.color("#2f8eb5")
                lineSeries.tooltip.background.fill = am4core.color(lineSeries.stroke)
                lineSeries.tooltip.getFillFromObject = false
                lineSeries.tooltip.pointerOrientation = "vertical"

                lineSeries.cloneTooltip = false // Tooltip off
                lineSeries.showOnInit = false // animation off

            // let bullet = series.bullets.push(new am4core.Circle())
            //     bullet.radius = 1
            //     bullet.tooltipText = "[bold]X : {valueX} \nY : {valueY}[/]"
            //     bullet.stroke = am4core.color("#fff")
            //     bullet.fill = lineSeries.stroke

                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"
                // chart.cursor.xAxis = ValueAxis
                // chart.cursor.fullWidthLineX = true
                // chart.cursor.lineX.strokeWidth = 0
                // chart.cursor.lineX.fill = am4core.color("#000")
                // chart.cursor.lineX.fillOpacity = 0.1
                // chart.cursor.behavior = "selectX"
                // chart.cursor.lineY.disabled = true

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = false
                chart.legend.position = "top"
                chart.legend.contentAlign = "right"
                chart.legend.marginBottom = 20
                chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    height:250px;
}
</style>