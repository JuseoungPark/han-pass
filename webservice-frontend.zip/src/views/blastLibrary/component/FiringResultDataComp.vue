<template>
    <CCard class="mb-0">
        <CForm @submit.prevent>
            <CCardHeader>
                <strong>Firing Result Data Import</strong>
            </CCardHeader>
            <div class="position-relative">
                <CCardBody class="form-group-wrap">
                    <div role="group">
                        <ul class="list-unstyled full-width">
                            <li v-for="(item, index) in fileList" :key="index" class="full-width">
                                <label class="col-form-label col-sm-12 px-0">{{ item.unitName }}
                                    <span v-if="item.upFileStr != ''" @click="fileClick(item)" class="down-wrap"><app-icon name="fileDown" size="s" fill class="ml-2" />{{ item.upFileStr }}</span>
                                </label>
                                <div class="col-sm-12" style="padding-left:10px;">
                                    <input :id="'drilling-file-add-0'+index" type="file" class="custom-file-input custom" v-bind:name="item.equipmentId" v-on:input="process(index, $event)">
                                    <label :for="'drilling-file-add-0'+index+' col-sm-12'" class="custom-file-label">
                                        {{ item.fileName }}
                                        <span class="icon-wrap">
                                            <CIcon name="cil-library-add" />
                                        </span>
                                    </label>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <CInput
                        class="mt-3"
                        label="Misfire"
                        placeholder="Please enter Misfire"
                        type="text"
                        name="misfire"
                        v-model.trim="$v.form.misfire.$model"
                        :isValid="$v.form.misfire.$dirty ? !$v.form.misfire.$error : null">
                        <template slot="invalid-feedback">
                            <ValidFeedback :param="$v.form.misfire" />
                        </template>
                    </CInput>
                    <div>
                        <label for="maximumCharge">Maximum Instantaneouns Charge</label>
                        <div class="unit-input-wrap position-relative mb-3">
                            <CInput
                                class="mb-0"
                                id="maximumCharge"
                                placeholder="Please enter Maximum Instantaneouns Charge"
                                type="number"
                                name="maximumCharge"
                                append="kg"
                                v-model.trim="$v.form.maximumCharge.$model"
                                :isValid="$v.form.maximumCharge.$dirty ? !$v.form.maximumCharge.$error : null">
                                <template slot="invalid-feedback">
                                    <ValidFeedback :param="$v.form.maximumCharge" />
                                </template>
                            </CInput>
                        </div>
                    </div>
                    <div>
                        <label for="reliefValue">Relief Value</label>
                        <div class="unit-input-wrap position-relative mb-3">
                            <CInput
                                class="mb-0"
                                id="reliefValue"
                                placeholder="Please enter Relief Value"
                                type="number"
                                name="reliefValue"
                                append="ms/s"
                                v-model.trim="$v.form.reliefValue.$model"
                                :isValid="$v.form.reliefValue.$dirty ? !$v.form.reliefValue.$error : null">
                                <template slot="invalid-feedback">
                                    <ValidFeedback :param="$v.form.reliefValue" />
                                </template>
                            </CInput>
                        </div>
                    </div>
                    <CSelect
                        label="Fume Level"
                        placeholder="Please enter Fume Level"
                        name="fumeLevel"
                        :value.sync="$v.form.fumeLevel.$model"
                        :options="codes.fumeLevelCodes"
                        :isValid="$v.form.fumeLevel.$dirty ? !$v.form.fumeLevel.$error : null"
                        :invalidFeedback="$t('validation.required')"
                    />
                    <div class="mb-3">
                        <label for="firingDatetime" class="d-block">FiringDatetime</label>
                        <CDatePicker id="firingDatetime"
                            :validForm.sync="$v.form.siteMapDatetime"
                            type="datetime"
                            valueType="YYYY-MM-DD HH:mm"
                            format="YYYY-MM-DD HH:mm"
                            v-model="dateTime"
                            placeholder="Please enter firingDatetime"
                        />
                    </div>
                    <div class="d-flex align-items-center position-relative">
                        <label for="useYn" class="mb-0 mr-2">Fired Y/N</label>
                        <CSwitchYN
                            :value.sync="form.useYn"
                        />
                    </div>
                    <CTextarea
                        label="Remark"
                        placeholder="Please enter Remark"
                        rows="4"
                        class="mt-3"
                        :maxlength="250"
                        block
                        name="remark"
                        v-model.trim="$v.form.remark.$model"
                        :isValid="$v.form.remark.$dirty ? !$v.form.remark.$error : null">
                        <template slot="invalid-feedback">
                            <ValidFeedback :param="$v.form.remark" />
                        </template>
                    </CTextarea>
                </CCardBody>
                <CCardFooter>
                    <CButton type="submit"
                        class="btn-custom-default hanwha outline rectangle"
                        :disabled="!isValid"
                        @click="submit"
                    >
                        {{ $t('commonLabel.submit') }}
                    </CButton>
                    <CButton type="button"
                        class="btn-custom-default outline rectangle"
                        @click="editPopClose"
                    >
                        {{ $t('commonLabel.cancel') }}
                    </CButton>
                </CCardFooter>
                <!-- Confirm popup -->
                <div class="inner-confirm-pop"
                    v-if="isConfirmPop">
                    <div class="contents">
                        <div class="card-body">
                            <span class="info-text">{{ $t('message.firingConfirm') }}</span>
                        </div>
                        <div class="card-footer">
                            <CButton type="submit"
                                class="btn-custom-default hanwha outline rectangle"
                                :disabled="!isValid"
                                @click="submitAction"
                            >
                                {{ $t('commonLabel.confirm') }}
                            </CButton>
                            <CButton type="button"
                                class="btn-custom-default outline rectangle"
                                @click="confirmPopClose"
                            >
                                {{ $t('commonLabel.cancel') }}
                            </CButton>
                        </div>
                    </div>
                </div>
            </div>
        </CForm>
    </CCard>
</template>

<script>
import moment from 'moment-timezone'
import utils from '@/assets/js/utils'
import ValidFeedback from '@/components/form/ValidFeedback'
import { mapGetters, mapActions } from 'vuex'
import { validationMixin } from "vuelidate"
import { required, decimal, numeric, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'
import CDatePicker from '@/components/form/CDatePicker'
import CSwitchYN from '@/components/form/CSwitchYN'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
const blastLibrary = 'blastLibrary'

export default {
    name: 'FiringResultData',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        CDatePicker,
        CSwitchYN,
        ValidFeedback,
        AppIcon
    },
    data() {
        return {
            isConfirmPop: false,
            dateTime: null,
            spinnerFlag: false,
            firedYn: '',
            fileList: [],
            form: this.getEmptyForm(),
            codes: {
                fumeLevelCodes: utils.getOptionCode('fumeLevel', true)
            },
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            misfire: {
                //required,
                numeric,
                between: between(0, 999),
            },
            maximumCharge: {
                //required,
                numeric,
                between: between(0, 999),
            },
            reliefValue: {
                //required,
                decimal,
                between: between(0, 999.99),
                decimalLimit: decimalLimit(2)
            },
            fumeLevel: {
                //required,
            },
            siteMapDatetime: {
                required
            },
            useYn: {
                required
            },
            remark: {
                byte: byte(250)
            },
        }
    },
    mounted() {
        if (this.blastId != 0) {
            this.getInterfaceInfo()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
        }),
        isValid() {
            return !this.$v.form.$invalid
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            downloadAction: 'download',
            putDataAction: 'putData',
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setFileDataAction: 'setFileData',
        }),
        async getInterfaceInfo() {
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/firing"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let unitName = 'Firing Data File'
            let fileInfo = { siteId: '', unitName: unitName, equipmentId: '', upFileName: '', upFileStr: '', fileName: '', file: '', fileId: '' }
            fileInfo.siteId = siteId

            if (this.data.content.length == 0) {
                this.fileList.push(fileInfo)
            }else{
                let fileId = this.data.content[0].fileId
                let upFileName = this.data.content[0].fileName
                let upFileStr = ' ('+upFileName+')'

                fileInfo.fileId = fileId
                fileInfo.upFileName = upFileName
                fileInfo.upFileStr = upFileStr

                this.fileList.push(fileInfo)
            }

            if (this.data.remark.length == 0) {
                this.form = this.getEmptyForm()
            }else{
                let interfaceInfo = this.data.remark[0]

                let siteMapDatetime = interfaceInfo.blastDate
                if (siteMapDatetime !=null && siteMapDatetime != '') {
                    siteMapDatetime = moment(siteMapDatetime).format('YYYY-MM-DD HH:mm')
                }

                let firedYn = 'Y'
                if (interfaceInfo.firedYn != 'Y') firedYn = 'N'

                this.form.misfire = (interfaceInfo.firingMisfire!=null?interfaceInfo.firingMisfire:0)
                this.form.maximumCharge = interfaceInfo.firingMic
                this.form.reliefValue = interfaceInfo.firingReliefValue
                this.form.fumeLevel = interfaceInfo.firingFumeLevel
                this.form.remark = interfaceInfo.firingRemark

                this.form.siteMapDatetime = siteMapDatetime
                this.form.useYn = firedYn

                this.firedYn = firedYn
            }

            this.spinnerFlag = false
        },
        async submit() {
            if (this.firedYn == 'N' && this.form.useYn == 'Y') {
                this.isConfirmPop = true
            }else{
                this.submitAction()
            }
        },
        async submitAction() {
            let that = this
            that.spinnerFlag = true

            let siteMapDatetime = this.form.siteMapDatetime
            if (siteMapDatetime != '') {
                siteMapDatetime += ':00'
                siteMapDatetime = moment(siteMapDatetime).utc().format()
            }

            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/firing/remark"
            await this.putDataAction({
                params: {
                    firingMisfire: this.form.misfire,
                    firingMic: this.form.maximumCharge,
                    firingReliefValue: this.form.reliefValue,
                    firingFumeLevel: this.form.fumeLevel,
                    firingRemark: this.form.remark,
                    blastDate: siteMapDatetime,
                    firedYn: this.form.useYn
                },
                moduleName: moduleName
            })

            for (const item of that.fileList) {
                if (item.file != '') {
                    that.form.blastId = blastId
                    that.form.uploadFile = item.file

                    moduleName = "v1/files/"+siteId+"/firing?blastId="+blastId
                    await this.setFileDataAction({
                        params: that.form,
                        moduleName: moduleName
                    })
                }
            }

            this.$emit('submitChk', 'firing')
            that.editPopClose()

            that.spinnerFlag = false
        },
        async fileClick(item) {
            let fileName = item.upFileName

            await this.downloadAction({
                params: {
                    fileName: fileName
                },
                moduleName: `v1/files/${item.siteId}/firing/download/${item.fileId}`
            })
        },
        editPopClose() {
            this.$emit('closeEditPop')
        },
        process(index, event) {
            this.fileList[index].fileName = event.target.value
            this.fileList[index].file = event.target.files[0]
        },
        getEmptyForm() {
            return {
                misfire: 0,
                maximumCharge: '',
                reliefValue: '',
                fumeLevel: '',
                siteMapDatetime: '',
                useYn: 'Y',
                remark: '',
            }
        },
        confirmPopClose() {
            this.isConfirmPop = false
        }
    }
}
</script>