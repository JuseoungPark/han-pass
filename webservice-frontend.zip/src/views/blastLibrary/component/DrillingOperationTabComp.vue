<template>
    <div>
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <ul class="list-unstyled half-layout align-items-stretch my-2 bg-light-gary">
            <li><span class="list-tit">Work start : </span>{{ operationSummary.workStart }}</li>
            <li><span class="list-tit">Work end : </span>{{ operationSummary.workEnd }}</li>
            <li><span class="list-tit">Operator : </span>{{ operationSummary.operator }}</li>
            <li><span class="list-tit">Work hour : </span>{{ operationSummary.workHour }}</li>
        </ul>
        <div class="operation-table-wrap data-table typeA">
            <div class="position-relative table-responsive ">
                <fieldset>
                    <legend class="sr-only">Operation dataSet</legend>
                    <table class="table table-fixed table-bordered table-hover">
                        <thead>
                            <tr>
                                <th scope="col" rowspan="2"></th>
                                <th v-for="(value, index) in operationTitle" :key="index" scope="row" colspan="3">
                                    {{ value }}
                                </th>
                            </tr>
                            <tr>
                                <th v-for="(value, index) in operationSub" :key="index" scope="col">
                                    {{ value }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-nowrap">Hole number</th>
                                <td v-for="(value, index) in tableHole" :key="index">
                                    {{ value }}
                                </td>
                            </tr>
                            <tr>
                                <th class="text-nowrap">Drill meter</th>
                                <td v-for="(value, index) in tableDrill" :key="index">
                                    {{ value }}
                                </td>
                            </tr>
                            <tr>
                                <th class="text-nowrap">Average depth</th>
                                <td v-for="(value, index) in tableAverage" :key="index">
                                    {{ value }}
                                </td>
                            </tr>
                        </tbody>
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th v-for="(value, index) in operation2Sub" :key="index" scope="col">
                                    {{ value }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-nowrap">Drill accuracy</th>
                                <td v-for="(value, index) in table2Drill" :key="index">
                                    {{ value }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </fieldset>
            </div>
        </div>
        <CForm @submit.prevent>
        <CRow class="mt-3">
            <CCol lg="6">
                <CCard class="mb-0">
                    <CCardHeader class="position-relative">
                        <div class="row">
                            <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                <div>
                                    <strong class="text-nowrap">Depth Accuracy</strong>
                                </div>
                                <!-- div>
                                    <strong class="text-nowrap">Accuracy</strong>
                                    <span class="text-nowrap ml-1">(Depth)</span>
                                </div -->
                                <span class="text-right">
                                    <CSelect
                                        class="position-right-center right-1"
                                        style="width:80px;"
                                        :value.sync="categoryInterval"
                                        :options="categoryIntervalOptions"
                                        @change="changeStandrd($event)"
                                    />
                                </span>
                                <!--span class="text-right">정확도 <span class="num">100</span>%</span-->
                            </div>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartCategoryComp :key="amChartCategoryCompIdx"
                            v-if="categoryChartData.data.length!=0"
                            isGuide
                            seriesName="Depth"
                            :chartData=categoryChartData
                        />
                    </CCardBody>
                </CCard>
            </CCol>
            <CCol lg="6" class="lg-mt">
                <CCard class="mb-0">
                    <CCardHeader>
                        <div class="row">
                            <div class="d-flex align-items-center justify-content-between flex-wrap full-width px-3">
                                <div>
                                    <strong class="text-nowrap">Collar Accuracy</strong>
                                </div>
                                <!--
                                <div>
                                    <strong class="text-nowrap">Accuracy</strong>
                                    <span class="text-nowrap ml-1">(Horizontal)</span>
                                </div>
                                <span class="text-right">정확도 <span class="num">100</span>%</span>
                                -->
                            </div>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartRadarDotComp
                            v-if="radarChartData.data.series1.length!=0"
                            :seriesName1=seriesName1
                            :seriesName2=seriesName2
                            :seriesName3=seriesName3
                            :chartData=radarChartData
                        />
                        <div v-show="radarChartData.data.series1.length==0" v-text="$t('message.noData')" style="padding-top:10px;" />
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
        </CForm>
    </div>
</template>

<script>
import moment from 'moment'
import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'

const AmChartCategoryComp = () => import(/* webpackChunkName: "DrillingOperationCharts" */ './AmChartCategoryComp')
const AmChartRadarDotComp = () => import(/* webpackChunkName: "DrillingOperationCharts" */ './AmChartRadarDotComp')

const blastLibrary = 'blastLibrary'

export default {
    name: 'DrillingOperationTab',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartCategoryComp,
        AmChartRadarDotComp,
    },
    data() {
        return {
            spinnerFlag: false,

            operationSummary: {
                workStart: '',
                workEnd: '',
                operator: '',
                workHour: '',
            },
            categoryInterval: '',
            categoryIntervalOptions: [
                { value: '0.1', label: '0.1 m' },
                { value: '0.2', label: '0.2 m' },
                { value: '0.5', label: '0.5 m' },
                { value: '1.0', label: '1.0 m' },
                { value: '2.0', label: '2.0 m' },
                { value: '5.0', label: '5.0 m' },
            ],
            amChartCategoryCompIdx: 0,

            operationTitle: [],
            operationSub: [],
            tableHole: [],
            tableDrill: [],
            tableAverage: [],

            operation2Sub: [],
            table2Drill: [],

            //chart
            categoryChartData: {
                data: []
            },
            seriesName1: '',
            seriesName2: '',
            seriesName3: '',
            radarChartData: {
                data: {
                    series1: [],
                    series2: [],
                    series3: [],
                }
            },
        }
    },
    created() {
        if (this.blastId != 0 && this.blastId != undefined) {
            this.categoryInterval = this.categoryIntervalOptions[5].value

            this.setOperationTable()
            this.setAmChartCategoryComp()
            this.setAmChartRadarDotComp()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    mounted() {
        //
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        setOperationSummary(item) {
            let workStart = new Date(item.workStart)
            workStart = moment(workStart).format('YYYY-MM-DD HH:mm')

            let workEnd = new Date(item.workEnd)
            workEnd = moment(workEnd).format('YYYY-MM-DD HH:mm')

            this.operationSummary.workStart = workStart
            this.operationSummary.workEnd = workEnd
            this.operationSummary.operator = (item.operator!=null?item.operator:'-')
            this.operationSummary.workHour = (item.workHour!=null?item.workHour:'-')
        },
        async setOperationTable() {
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/operation"
            let payload = { params : params, moduleName : moduleName }
            await this.setDataListAction(payload)

            this.operationTitle = []
            this.operationSub = []

            this.tableHole = []
            this.tableDrill = []
            this.tableAverage = []

            // 장비 1개 이상인 경우 Total값 처리
            if (this.data.content.length > 1) {
                this.setOperationTableInfo('Total', [this.data.total])
            }
            // 각 장비에 대한 처리
            this.setOperationTableInfo('Equipment', this.data.content)

            this.spinnerFlag = false
        },
        setOperationTableInfo(type, data) {
            let that = this
            data.forEach (function (el) {
                if (type == 'Total') that.operationTitle.push(type)
                else that.operationTitle.push((el.equipmentName!=null?el.equipmentName:'-'))

                that.operationSub.push('Planned')
                that.operationSub.push('Actual')
                that.operationSub.push('Difference')

                that.tableHole.push(el.plan.holeCount)
                that.tableHole.push(el.result.holeCount)
                that.tableHole.push(el.diff.holeCount)

                that.tableDrill.push(el.plan.drillMeter)
                that.tableDrill.push(el.result.drillMeter)
                that.tableDrill.push(el.diff.drillMeter)

                that.tableAverage.push(el.plan.averageDepth)
                that.tableAverage.push(el.result.averageDepth)
                that.tableAverage.push(el.diff.averageDepth)

                that.operation2Sub.push('Drilled hole')
                that.operation2Sub.push('In tolerance')
                that.operation2Sub.push('Out of tolerance')

                that.table2Drill.push((el.drilledHoleCount!=null?el.drilledHoleCount:'-'))
                that.table2Drill.push((el.inTolerance!=null?el.inTolerance:'-'))
                that.table2Drill.push((el.outOfTolerance!=null?el.outOfTolerance:'-'))
            })
        },
        async setAmChartCategoryComp() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let interval = this.categoryInterval
            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/accuracy-depth/"+interval
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let categoryData = []
            let categoryChartData = []
            that.categoryChartData.data = []

            if (that.data.status == 200) {
                that.data.content.forEach (function (el) {
                    let intervalValue = Number(el.intervalValue).toFixed(1)
                    categoryData.push(intervalValue)
console.log('intervalValue = '+intervalValue)
                    categoryChartData.push({ "category": intervalValue, "value": el.holeCount })
                })
                let categoryBase = []
                categoryData.forEach (function (el) {
                    categoryBase.push(el)

                    let categoryKey = 0
                    if (Math.sign(el) > 0) categoryKey = Number(el) * -1
                    else categoryKey = Math.abs(el)

                    if(!categoryData.includes(categoryKey)) {
                        categoryBase.push(categoryKey)
                    }
                })
//console.log(categoryBase)
                let min = Math.min.apply(Math, categoryBase)
                let max = Math.max.apply(Math, categoryBase)
//console.log(min, max)
                let steps = 1.0  // 0.1 , 0.2 , 0.5 , 1.0 , 2.0 , 5.0
                steps = Number(interval)
//console.log(steps)
                let idx, length = 0
                for (idx=min; idx<=max; idx+=steps) {
                    length += 1
                }
                if (length==1) {
                    min = (-steps * 3)
                    max = (steps * 3)
                }
console.log('length1 = '+length)
                if (length>1000) {
                    steps = 5.0
                    this.categoryInterval =  this.categoryIntervalOptions[5].value
                }
                length = 0
                for (idx=min; idx<=max; idx+=steps) {
                    length += 1
                    let idxKey = idx.toFixed(1)
//console.log('> '+idx+' / '+idxKey+' => '+!categoryData.includes(idxKey))
                    if(!categoryData.includes(idxKey)) {
                        categoryChartData.push({ "category": idxKey, "value": 0 })
                    }
                }
console.log('length2 = '+length)
                if (length > 1000) {
                    utils.showToastRed('Depth Accuracy data exceeded 1000 cases')
                } else {
                    var sortingField = "category"  // a - b, b - a
                    categoryChartData.sort(function(a, b) {
                        return a[sortingField] - b[sortingField];
                    })

                    that.categoryChartData.data = categoryChartData
                    that.amChartCategoryCompIdx += 1
                }
//console.log(that.categoryChartData.data)
            }

            that.spinnerFlag = false
        },
        async setAmChartRadarDotComp() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/accuracy-horizontal"
            let payload = { params: params, moduleName: moduleName }

            await this.setDataListAction(payload)

            that.radarChartData.data.series1 = []
            that.radarChartData.data.series2 = []
            that.radarChartData.data.series3 = []
            if (that.data.status == 200) {
                that.data.content.forEach (function (el, index) {
                    if (index == 0) {
                        that.seriesName1 = el.equipmentName
                        el.holes.forEach (function (hole) {
                            that.radarChartData.data.series1.push({ "x": hole.pointXDiffValue, "y": hole.pointYDiffValue })
                        })
                    }else if (index == 1) {
                        that.seriesName2 = el.equipmentName
                        el.holes.forEach (function (hole) {
                            that.radarChartData.data.series2.push({ "x": hole.pointXDiffValue, "y": hole.pointYDiffValue })
                        })
                    }else if (index == 2) {
                        that.seriesName3 = el.equipmentName
                        el.holes.forEach (function (hole) {
                            that.radarChartData.data.series3.push({ "x": hole.pointXDiffValue, "y": hole.pointYDiffValue })
                        })
                    }
                })
            }

            that.spinnerFlag = false
        },
        changeStandrd(event) {
            this.categoryInterval = event.target.value

            this.setAmChartCategoryComp()
        },
    }
}
</script>
<style lang="scss" scoped>
.list-tit{
    font-weight: 700;
}
</style>