<template>
    <CCard class="mb-0">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <CForm @submit.prevent>
            <CCardHeader>
                <strong>Productivity / Cost Import</strong>
            </CCardHeader>
            <CCardBody class="form-group-wrap">
                <div>
                    <label for="drillMeter">Drill Meter</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="drillMeter"
                            placeholder="Please enter Drill Meter"
                            type="number"
                            name="drillMeter"
                            append="m"
                            v-model.trim="$v.form.drillMeter.$model"
                            :isValid="$v.form.drillMeter.$dirty ? !$v.form.drillMeter.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.drillMeter" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="drillCost">Drill Cost</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="drillCost"
                            placeholder="Please enter Drill Cost"
                            type="number"
                            name="drillCost"
                            :append="userSite.currencyName"
                            v-model.trim="$v.form.drillCost.$model"
                            :isValid="$v.form.drillCost.$dirty ? !$v.form.drillCost.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.drillCost" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="productCost">Product Cost</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="productCost"
                            placeholder="Please enter Product Cost"
                            type="number"
                            name="productCost"
                            :append="userSite.currencyName"
                            v-model.trim="$v.form.productCost.$model"
                            :isValid="$v.form.productCost.$dirty ? !$v.form.productCost.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.productCost" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="laborCost">Labor Cost</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="laborCost"
                            placeholder="Please enter Labor Cost"
                            type="number"
                            name="laborCost"
                            :append="userSite.currencyName"
                            v-model.trim="$v.form.laborCost.$model"
                            :isValid="$v.form.laborCost.$dirty ? !$v.form.laborCost.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.laborCost" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="extraCost">Extra Cost</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="extraCost"
                            placeholder="Please enter Extra Cost"
                            type="number"
                            name="extraCost"
                            :append="userSite.currencyName"
                            v-model.trim="$v.form.extraCost.$model"
                            :isValid="$v.form.extraCost.$dirty ? !$v.form.extraCost.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.extraCost" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="blastVolumn">Blast Volume</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="blastVolumn"
                            placeholder="Please enter Blast Volume"
                            type="number"
                            name="blastVolumn"
                            append="BCM"
                            v-model.trim="$v.form.blastVolumn.$model"
                            :isValid="$v.form.blastVolumn.$dirty ? !$v.form.blastVolumn.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.blastVolumn" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <div class="mt-3">
                    <label for="blastCost">Blast Cost</label>
                    <div class="unit-input-wrap position-relative mb-3">
                        <CInput
                            class="mb-0"
                            id="blastCost"
                            placeholder="Please enter Blast Cost"
                            type="number"
                            name="blastCost"
                            :append="userSite.currencyName"
                            v-model.trim="$v.form.blastCost.$model"
                            :isValid="$v.form.blastCost.$dirty ? !$v.form.blastCost.$error : null">
                            <template slot="invalid-feedback">
                                <ValidFeedback :param="$v.form.blastCost" />
                            </template>
                        </CInput>
                    </div>
                </div>
                <CTextarea
                    label="Remark"
                    placeholder="Please enter Remark"
                    rows="3"
                    class="mt-2"
                    :maxlength="250"
                    block
                    name="remark"
                    v-model.trim="$v.form.remark.$model"
                    :isValid="$v.form.remark.$dirty ? !$v.form.remark.$error : null">
                    <template slot="invalid-feedback">
                        <ValidFeedback :param="$v.form.remark" />
                    </template>
                </CTextarea>
            </CCardBody>
            <CCardFooter>
                <CButton type="submit"
                    class="btn-custom-default hanwha outline rectangle"
                    :disabled="!isValid"
                    @click="submit"
                >
                    {{ $t('commonLabel.submit') }}
                </CButton>
                <CButton type="button"
                    class="btn-custom-default outline rectangle"
                    @click="editPopClose"
                >
                    {{ $t('commonLabel.cancel') }}
                </CButton>
            </CCardFooter>
        </CForm>
    </CCard>
</template>

<script>
import utils from '@/assets/js/utils'
import ValidFeedback from '@/components/form/ValidFeedback'
import { mapGetters, mapActions } from 'vuex'
import { validationMixin } from "vuelidate"
import { required, decimal, numeric, between } from "vuelidate/lib/validators"
import { byte, decimalLimit } from '@/assets/js/validatorCustome'

const blastLibrary = 'blastLibrary'

export default {
    name: 'ProductivityCostData',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        ValidFeedback,
    },
    data() {
        return {
            spinnerFlag: false,
            form: this.getEmptyForm()
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            drillMeter: {
                numeric,
                between: between(0, 9999999),
            },
            drillCost: {
                decimal,
                between: between(0, 9999999.99),
                decimalLimit: decimalLimit(2)
            },
            productCost: {
                decimal,
                between: between(0, 9999999.99),
                decimalLimit: decimalLimit(2)
            },
            laborCost: {
                decimal,
                between: between(0, 9999999.99),
                decimalLimit: decimalLimit(2)
            },
            extraCost: {
                decimal,
                between: between(0, 9999999.99),
                decimalLimit: decimalLimit(2)
            },
            blastVolumn: {
                numeric,
                between: between(0, 9999999.99),
            },
            blastCost: {
                decimal,
                between: between(0, 9999999.99),
                decimalLimit: decimalLimit(2)
            },
            remark: {
                byte: byte(250)
            },
        }
    },
    mounted() {
        if (this.blastId != 0) {
            this.getInterfaceInfo()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
        }),
        userSite() {
            return utils.getUserInformation().selectedUserSite
        },
        isValid() {
            return !this.$v.form.$invalid
        },
    },
    methods: {
        ...mapActions(blastLibrary, {
            putDataAction: 'putData',
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setFileDataAction: 'setFileData',
        }),
        async getInterfaceInfo() {
            this.spinnerFlag = true

            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/productivity-cost"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let interfaceInfo = this.dataList
            if (interfaceInfo != undefined) {
                this.form.drillMeter = interfaceInfo.drillMeter
                this.form.drillCost = interfaceInfo.drillCost
                this.form.productCost = interfaceInfo.productCost
                this.form.laborCost = interfaceInfo.laborCost
                this.form.extraCost = interfaceInfo.extraCost
                this.form.blastVolumn = interfaceInfo.blastVolumn
                this.form.blastCost = interfaceInfo.blastCost
                this.form.remark = interfaceInfo.remark
            }else{
                this.form = this.getEmptyForm()
            }

            this.spinnerFlag = false
        },
        async submit() {
            let that = this
            that.spinnerFlag = true

            let siteId = this.siteId
            let blastId = this.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/interface/productivity-cost/remark"

            await this.putDataAction({
                params: {
                    drillMeter: this.form.drillMeter,
                    drillCost: this.form.drillCost,
                    productCost: this.form.productCost,
                    laborCost: this.form.laborCost,
                    extraCost: this.form.extraCost,
                    blastVolumn: this.form.blastVolumn,
                    blastCost: this.form.blastCost,
                    remark: this.form.remark,
                },
                moduleName: moduleName
            })

            this.$emit('submitChk', 'productivity')
            that.editPopClose()
            that.spinnerFlag = false
        },
        editPopClose() {
            this.$emit('closeEditPop')
        },
        getEmptyForm() {
            return {
                drillMeter: '',
                drillCost: '',
                productCost: '',
                laborCost: '',
                extraCost: '',
                blastVolumn: '',
                blastCost: '',
                remark: '',
            }
        },
    }
}
</script>