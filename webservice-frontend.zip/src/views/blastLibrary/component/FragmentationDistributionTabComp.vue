<template>
    <div class="mt-2">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <CRow class="mt-3">
            <CCol lg="12">
                <CCard class="mb-0">
                    <CCardHeader>
                        <strong class="text-nowrap">Particle size cumulatove distribution chart</strong>
                    </CCardHeader>
                    <CCardBody>
                        <CRow>
                            <CCol lg="8">
                                <AmChartStepSmoothLineComp
                                    chartHeight="436"
                                    :chartData=categoryChartData
                                />
                            </CCol>
                            <CCol lg="4" class="table-max-height370">
                                <div class="position-relative table-responsive data-table typeA">
                                    <fieldset>
                                        <legend class="sr-only">Particle size cumulatove distribution chart data table</legend>
                                        <table class="table table-fixed table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-nowrap" scope="col">Size (m)</th>
                                                    <th class="text-nowrap" scope="col">% Passing</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(item, index) in distributionList" :key="index">
                                                    <td>{{ item.sizeValue | SetDecimal }}</td>
                                                    <td>{{ item.passingValue | SetDecimal }}%</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </fieldset>
                                </div>
                            </CCol>
                        </CRow>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

const AmChartStepSmoothLineComp = () => import(/* webpackChunkName: "fragmentationDistributionCharts" */ './AmChartStepSmoothLineComp')
import utils from '@/assets/js/utils'
const blastLibrary = 'blastLibrary'

export default {
    name: 'FragmentationDistributionTab',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartStepSmoothLineComp
    },
    data() {
        return {
            spinnerFlag: false,
            // productivity
            distributionList: [
                {sizeValue: '-', passingValue: '-'},
            ],

            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            categoryChartData: {
                data: [{
                    "valueAx": 0, // line, size
                    "valueAy": 0, // line, passing
                    "valueBx": 0, // bar, size
                    "valueBy": 0, // bar, passing
                    }
                ]
            },
        }
    },
    created () {
        if (this.blastId != 0) {
            this.setDistribution()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData'
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setDistribution() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId
//siteId = 6
//blastId = 67
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/fragmentations/distribution"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            if (that.data.content.length > 0) {
                that.distributionList = []
                that.data.content.forEach(function (el) {
                    that.distributionList.push({ sizeValue: el.particleSize, passingValue: el.passing.toFixed(1) })
                })

                that.categoryChartData.data = []
                let size = 0, passing = 0, passingBefore = 0, diff = 0
                that.data.content.forEach(function (el, index) {
                    let valueArr = {}
                    size = utils.setDecimal(el.particleSize)
                    passing = utils.setDecimal(el.passing)

                    if (index == 0) diff = 0
                    else diff = passing - passingBefore

                    // line chart
                    valueArr.valueAx = size
                    valueArr.valueAy = passing
                    // bar chart
                    valueArr.valueBx = size
                    valueArr.valueBy = diff

                    passingBefore = passing

                    that.categoryChartData.data.push(valueArr)
                })
            }

            that.spinnerFlag = false
        },
    }
}
</script>