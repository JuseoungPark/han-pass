<template>
    <CRow>
        <!-- Site name -->
        <CCol lg="4" v-if="isSiteNeme">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3">
                    <CIcon name="cil-text" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Site Name</Strong>
                    <span class="sub-text">XXX</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Site name -->

        <!-- Pit name -->
        <CCol lg="4" v-if="isPitName">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-text" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Pit Name</Strong>
                    <span class="sub-text">XXX</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Pit name -->

        <!-- No. of Holes -->
        <CCol lg="4" v-if="isHoles">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-scrubber" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">No. of Holes</Strong>
                    <span class="sub-text">100</span>
                </div>
            </CCard>
        </CCol>
        <!-- // No. of Holes -->

        <!-- Shot firer -->
        <CCol lg="4" v-if="isShotFirer">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-fire" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Shot firer</Strong>
                    <span class="sub-text">Teddy</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Shot firer -->

        <!-- Fired time -->
        <CCol lg="4" v-if="isFiredTime">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-av-timer" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Fired time</Strong>
                    <span class="sub-text">2020-08-31 12:05</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Fired time -->

        <!-- Drill Meter (m) ///////--> 
        <CCol lg="4" v-if="isDrillMeter">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-line-spacing" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Drill Meter (m)</Strong>
                    <span class="sub-text">700</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Drill Meter (m) -->

        <!-- Hole Diameter (mm) -->
        <CCol lg="4" v-if="isHoleDiameter">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-resize-width" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Hole Diameter (mm)</Strong>
                    <span class="sub-text">200</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Hole Diameter (mm) -->

        <!-- Charge weight (kg) -->
        <CCol lg="4" v-if="isChargeWeight">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-justify-center" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Charge weight (kg)</Strong>
                    <span class="sub-text">1,200</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Charge weight (kg) -->

        <!-- P.F (kg/BCM) -->
        <CCol lg="4" v-if="isPf">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-justify-center" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">P.F (kg/BCM)</Strong>
                    <span class="sub-text">200</span>
                </div>
            </CCard>
        </CCol>
        <!-- // P.F (kg/BCM) -->

        <!-- Equipment -->
        <CCol lg="4" v-if="isEquipment">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-settings" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Equipment</Strong>
                    <span class="sub-text">200</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Equipment -->

        <!-- Work hour -->
        <CCol lg="4" v-if="isWorkHour">
            <CCard>
                <div class="box-unit horizontal white-text bg-gradient-yo large text-left py-3 position-relative">
                    <CIcon name="cil-av-timer" class="ml-4 mr-2" />
                    <Strong class="main-text mr-3">Work hour</Strong>
                    <span class="sub-text">9h 27min</span>
                </div>
            </CCard>
        </CCol>
        <!-- // Work hour (mm) -->
    </CRow>
</template>
<script>
export default {
    name: 'BlastDataInfo',
    props: {
        isSiteNeme: Boolean,
        isPitName: Boolean,
        isHoles: Boolean,
        isShotFirer: Boolean,
        isFiredTime: Boolean,
        isDrillMeter: Boolean,
        isHoleDiameter: Boolean,
        isChargeWeight: Boolean,
        isPf: Boolean,
        isEquipment: Boolean,
        isWorkHour: Boolean,
    },
}
</script>