<template>
    <div class="am-line-chart" ref="chartdiv" :style="'height:'+ chartHeight + 'px'"></div>
</template>
<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
export default {
    name: 'LineSeries',
    data() {
        return {
            chart: '',
        }
    },
    props: {
        chartData: Object,
        valueAxisXTitle: String,
        valueAxisYTitle: String,
        chartHeight: String
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart()
    },
    methods: {
        loadChart() {
            console.log('Values are changed')
            this.chart.invalidateRawData();
        },
        renderChart() {
            let chart = am4core.create(this.$refs.chartdiv, am4charts.XYChart)

                chart.paddingRight = 20

                chart.data = this.chartData.data
                // chart.data = []

            let valueAxisX = chart.xAxes.push(new am4charts.ValueAxis())
                valueAxisX.renderer.grid.template.location = 0
                valueAxisX.renderer.minGridDistance = 30
                valueAxisX.renderer.labels.template.fill = am4core.color("#777")
                valueAxisX.title.text = this.valueAxisXTitle
                valueAxisX.renderer.labels.template.fontSize = 11

            let valueAxisY = chart.yAxes.push(new am4charts.ValueAxis())
                valueAxisY.renderer.labels.template.fill = am4core.color("#777")
                valueAxisY.title.text = this.valueAxisYTitle
                valueAxisY.renderer.labels.template.fontSize = 11

            // Create series #1
            let series = chart.series.push(new am4charts.LineSeries())
                series.dataFields.valueY = "y"
                series.dataFields.valueX = "x"
                series.dataFields.value = "value"
                series.strokeWidth = 0
                series.tooltip.background.fill = am4core.color("#f9b990")
                series.tooltip.getFillFromObject = false
                // series.name = "Series 1"

            let bullet = series.bullets.push(new am4charts.Bullet())
                bullet.tooltipText = 
                `[bold]Tran[/]
                Frequency (Hz) : [bold]{valueX}[/] 
                Velocity (mm/s) : [bold]{valueY}[/]`
                bullet.layout = "absolute"
                bullet.rotation = 45

            let rectangle = bullet.createChild(am4core.Rectangle)
                rectangle.verticalCenter = "middle"
                rectangle.horizontalCenter = "middle"
                rectangle.width = 1
                rectangle.height = 1
                rectangle.strokeOpacity = 0.5
                rectangle.opacity = 0.7
                rectangle.fill = am4core.color("#f9b990")

                rectangle.stroke = am4core.color("#ffffff")
                rectangle.nonScalingStroke = true

                rectangle.verticalCenter = "middle"
                rectangle.horizontalCenter = "middle"

                series.heatRules.push({
                    target: rectangle,
                    min: 1,
                    max: 8,
                    property: "scale"
                })

            // Create series #2
            let series2 = chart.series.push(new am4charts.LineSeries())
                series2.dataFields.valueY = "y2"
                series2.dataFields.valueX = "x2"
                series2.dataFields.value = "value2"
                series2.strokeWidth = 0
                series2.tooltip.background.fill = am4core.color("#f5854c")
                series2.tooltip.getFillFromObject = false
                // series2.name = "Series 2"

            let bullet2 = series2.bullets.push(new am4charts.Bullet())
                bullet2.tooltipText = 
                `[bold]Vert[/]
                Frequency (Hz) : [bold]{valueX}[/] 
                Velocity (mm/s) : [bold]{valueY}[/]`
                bullet2.layout = "absolute"
                bullet2.rotation = 45

            let rectangle2 = bullet2.createChild(am4core.Rectangle)
                rectangle2.verticalCenter = "middle"
                rectangle2.horizontalCenter = "middle"
                rectangle2.width = 1
                rectangle2.height = 1
                rectangle2.strokeOpacity = 0.5
                rectangle2.opacity = 0.7
                rectangle2.fill = am4core.color("#f5854c")
                rectangle2.stroke = am4core.color("#ffffff")
                rectangle2.nonScalingStroke = true

                rectangle2.verticalCenter = "middle"
                rectangle2.horizontalCenter = "middle"

                series2.heatRules.push({
                    target: rectangle2,
                    min: 1,
                    max: 8,
                    property: "scale"
                })

            // Create series #3
            let series3 = chart.series.push(new am4charts.LineSeries())
                series3.dataFields.valueY = "y3"
                series3.dataFields.valueX = "x3"
                series3.dataFields.value = "value3"
                series3.strokeWidth = 0
                series3.tooltip.background.fill = am4core.color("#fd6402")
                series3.tooltip.getFillFromObject = false
                // series3.name = "Series 3"

            let bullet3 = series3.bullets.push(new am4charts.Bullet())
                bullet3.tooltipText = 
                `[bold]Long[/]
                Frequency (Hz) : [bold]{valueX}[/] 
                Velocity (mm/s) : [bold]{valueY}[/]`
                bullet3.layout = "absolute"
                bullet3.rotation = 45

            let rectangle3 = bullet3.createChild(am4core.Rectangle)
                rectangle3.verticalCenter = "middle"
                rectangle3.horizontalCenter = "middle"
                rectangle3.width = 1
                rectangle3.height = 1
                rectangle3.strokeOpacity = 0.5
                rectangle3.opacity = 0.7
                rectangle3.fill = am4core.color("#fd6402")
                rectangle3.stroke = am4core.color("#ffffff")
                rectangle3.nonScalingStroke = true

                rectangle3.verticalCenter = "middle"
                rectangle3.horizontalCenter = "middle"

                series3.heatRules.push({
                    target: rectangle3,
                    min: 1,
                    max: 8,
                    property: "scale"
                })

            // Guide Lines
            let lineSeries1 = chart.series.push(new am4charts.LineSeries())
                lineSeries1.dataFields.valueX = "gX"
                lineSeries1.dataFields.valueY = "gY"
                lineSeries1.strokeWidth = 2
                lineSeries1.stroke = am4core.color("#000")
                lineSeries1.cloneTooltip = false // Tooltip off
                lineSeries1.showOnInit = false // animation off
                // Guide Line
                lineSeries1.data = [
                    {"gX": 0, "gY": 5},
                    {"gX": 4, "gY": 20},
                    {"gX": 11, "gY": 20},
                    {"gX": 30, "gY": 50},
                    {"gX": 100, "gY": 50},
                ]

            let lineSeries2 = chart.series.push(new am4charts.LineSeries())
                lineSeries2.dataFields.valueX = "gX"
                lineSeries2.dataFields.valueY = "gY"
                lineSeries2.strokeWidth = 1
                lineSeries2.stroke = am4core.color("#000")
                lineSeries2.cloneTooltip = false // Tooltip off
                lineSeries2.showOnInit = false // animation off
                lineSeries2.strokeDasharray = "3,4"
                // Guide Line
                lineSeries2.data = [
                    {"gX": 0, "gY": 5},
                    {"gX": 4, "gY": 20},
                    {"gX": 20, "gY": 20},
                    {"gX": 39, "gY": 50},
                    {"gX": 100, "gY": 50},
                ]

            let lineSeries3 = chart.series.push(new am4charts.LineSeries())
                lineSeries3.dataFields.valueX = "gX"
                lineSeries3.dataFields.valueY = "gY"
                lineSeries3.strokeWidth = 1
                lineSeries3.stroke = am4core.color("#000")
                lineSeries3.cloneTooltip = false // Tooltip off
                lineSeries3.showOnInit = false // animation off
                lineSeries3.strokeDasharray = "3,4"
                // Guide Line
                lineSeries3.data = [
                    {"gX": 0, "gY": 5},
                    {"gX": 2.5, "gY": 13},
                    {"gX": 15.5, "gY": 13},
                    {"gX": 39, "gY": 50},
                    {"gX": 100, "gY": 50},
                ]

                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"
                // chart.cursor.xAxis = categoryAxis
                // chart.cursor.fullWidthLineX = true
                // chart.cursor.lineX.strokeWidth = 0
                // chart.cursor.lineX.fill = am4core.color("#000")
                // chart.cursor.lineX.fillOpacity = 0.1
                // // chart.cursor.behavior = "selectX"
                // chart.cursor.lineY.disabled = true

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = false
                chart.legend.position = "top"
                chart.legend.contentAlign = "right"
                chart.legend.textClickEnabled = true
                chart.legend.marginBottom = 20
                chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"
                
                chart.legend.data = [{
                        "name": "Tran",
                        "fill": rectangle.fill
                    }, {
                        "name": "Vert",
                        "fill": rectangle2.fill
                    }, {
                        "name": "Long",
                        "fill": rectangle3.fill
                    }]

                chart.legend.itemContainers.template.clickable = true
                chart.legend.itemContainers.template.togglable = true

                chart.legend.itemContainers.template.events.on('hit', (ev) => {

                    if (ev.target.dataItem.dataContext['name'] === 'Tran') {
                        
                        series.isHidden ? series.show() : series.hide()

                    }
                    if (ev.target.dataItem.dataContext['name'] === 'Vert') {
                        
                        series2.isHidden ? series2.show() : series2.hide()

                    }
                    if (ev.target.dataItem.dataContext['name'] === 'Long') {
                        
                        series3.isHidden ? series3.show() : series3.hide()

                    }
                })


            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 10
                markerTemplate.height = 10
                markerTemplate.rotation = 45
                markerTemplate.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose();
        }
    }
}
</script>
<style scoped>
.am-line-chart{
    width:100%;
    /* height:300px; */
}
</style>