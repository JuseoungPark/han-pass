<template>
    <div class="mt-2">
        <div>
            <!-- spinner -->
            <div class="spinner-wrap" v-if="spinnerFlag">
                <div class="sk-wave">
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                </div>
            </div>
            <!-- //spinner -->
            <CRow>
                <CCol lg="6">
                    <div class="position-relative table-responsive data-table typeA">
                        <fieldset>
                            <legend class="sr-only">Operation dataSet</legend>
                            <table class="table table-fixed table-bordered table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col" colspan="2">Productivity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in productivityList" :key="index">
                                        <th>{{ item.title }}</th>
                                        <td>{{ item.value }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </fieldset>
                    </div>
                    <div class="position-relative table-responsive data-table typeA mt-3">
                        <fieldset>
                            <legend class="sr-only">Operation dataSet</legend>
                            <table class="table table-fixed table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col" colspan="2">Timing</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in timingList" :key="index">
                                        <th>{{ item.title }}</th>
                                        <td>{{ item.value }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </fieldset>
                    </div>
                </CCol>
                <CCol lg="6" class="table-max-height480">
                    <div class="position-relative table-responsive data-table typeA">
                        <fieldset>
                            <legend class="sr-only">Operation dataSet</legend>
                            <table class="table table-fixed table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col" colspan="2">Blast History</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in blastHistoryList" :key="index">
                                        <th>{{ item.title }}</th>
                                        <td>{{ item.value }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </fieldset>
                    </div>
                </CCol>
            </CRow>
        </div>
        <CRow class="mt-3">
            <CCol lg="12">
                <CCard class="mb-0">
                    <CCardHeader>
                        <div class="row">
                            <div class="col-md-12">
                                <strong class="text-nowrap">Instantaneous Charge</strong>
                                <span class="text-nowrap ml-1">(Charge weight)</span>
                                <span class="text-right">
                                    <!--
                                    <CInput
                                        placeholder="  1 ~ 100"
                                        class="position-right-center right-1"
                                        style="width:90px;"
                                        maxlength="3"
                                        @focus="onFocus"
                                        @keyup="isNumberKey"
                                        v-model="windowInterval"
                                    />
                                    -->
                                    <CSelect
                                        class="position-right-center right-1"
                                        style="width:80px;"
                                        :value.sync="windowInterval"
                                        :options="windowIntervalOptions"
                                        @change="changeWindow($event)"
                                    />
                                </span>
                            </div>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <AmChartCategoryComp
                            v-if="categoryChartData.data.length!=0"
                            seriesName="Charge weight"
                            :chartData=categoryChartData
                        />
                        <div v-show="categoryChartData.data.length==0" v-text="$t('message.noData')" style="padding-top:10px;" />
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import moment from 'moment'

const AmChartCategoryComp = () => import(/* webpackChunkName: "firingOperationCharts" */ './AmChartCategoryComp')
// import AmChartCategoryComp from './AmChartCategoryComp'

const blastLibrary = 'blastLibrary'

export default {
    name: 'FiringOperationTab',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartCategoryComp
    },
    data() {
        return {
            spinnerFlag: false,

            windowInterval: '',
            windowIntervalOptions: [],

            // productivity
            productivityList: [
                //{ title: 'Work start', value: '-' },
                //{ title: 'Work end', value: '-' },
                { title: 'Shot firer', value: '-' },
                //{ title: 'Fired time', value: '-' },
                { title: 'Detonator product', value: '-' },
                { title: 'No. of Deto', value: '-' },
                { title: 'No. of Misfire', value: '-' },
                { title: 'Primer', value: '-' },
            ],
            // timing
            timingList: [
                { title: 'Last Firing timing', value: '-' },
                { title: 'Timing mode', value: '-' },
                //{ title: 'Row Delay', value: '-' },
                //{ title: 'Hole Delay', value: '-' },
                { title: 'Average Relief', value: '-' },
                { title: 'M.I.C', value: '-' },
            ],
            // Blast History
            blastHistoryList: [
                { title: '-', value: '-' },
            ],

            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            categoryChartData: {
                data: []
            },
        }
    },
    created () {
        let that = this

        if (this.blastId != 0) {
            this.setOperation()
            this.setInstantaneous()

            for (let i=1; i<=100; i++) {
                that.windowIntervalOptions.push(
                    { value: i, label: i }
                )
            }
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData'
        }),
    },
    mounted() {
        //
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        onFocus() {
            this.windowInterval = ''
        },
        isNumberKey(event) {
            let newValue = this.windowInterval
            newValue = newValue.replace(/[^0-9]/g,'')

            let pattern3 = /^[0-9]/g
            if (pattern3.test(newValue)) {
                // input box에 마우스 커서 삭제
                event.target.blur()

                this.windowInterval = newValue
                this.setInstantaneous()
            }
        },
        changeWindow(event) {
            this.windowInterval = event.target.value

            this.setInstantaneous()
        },
        async setOperation() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/firings/operation"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            if (that.status == '200' && that.dataList != undefined) {
                let productivity = that.data.content.productivity
                if (productivity != undefined) {
                    that.productivityList = []
                    for(var key in productivity) {
                        let value = productivity[key]
                        if ((key).toLowerCase().indexOf('date')>-1 || (key).toLowerCase().indexOf('time')>-1) {
                            value = new Date(value)
                            value = moment(value).format('YYYY-MM-DD HH:mm')
                        }
                        value = (value==null || value==''?'-':value)

                        that.productivityList.push({ title: key, value: value })
                    }
                }

                let timing = that.data.content.timing
                if (timing != undefined) {
                    that.timingList = []
                    for(var key in timing) {
                        let value = timing[key]
                        if ((key).toLowerCase().indexOf('date')>-1 || (key).toLowerCase().indexOf('time')>-1) {
                            value = new Date(value)
                            value = moment(value).format('YYYY-MM-DD HH:mm')
                        }
                        value = (value==null || value==''?'-':value)

                        that.timingList.push({ title: key, value: value })
                    }
                }

                let history = that.data.content.history
                if (history != undefined) {
                    that.blastHistoryList = []
                    history.forEach(function (el, index) {
                        that.blastHistoryList.push({ title: el.history, value: el.time })
                    })
                    if (that.blastHistoryList == 0) that.blastHistoryList.push({ title: '-', value: '-' })
                }
            }

            that.spinnerFlag = false
        },
        async setInstantaneous() {
console.log('setInstantaneous...')
            let that = this
            that.spinnerFlag = true

            let interval = this.windowInterval

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/firings/charts"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            let chart = that.data.content
            if (chart != undefined) {
                let idx = 0, weight = 0, sum = 0
                chart.forEach (function (el, index) {
                    if (el.value > 0) weight = el.value
                    if (idx < interval) {
                        sum = sum + el.value
                    }else{
                        sum = weight
                        weight = 0
                        idx = 0
                    }
                    idx += 1
//console.log(index, el.value, sum, idx)
                    that.categoryChartData.data.push(
                        { category: el.category, value: sum }
                    )
                })
            }

            that.spinnerFlag = false
        }
    },
}
</script>