<template>
    <CRow>
        <CCol lg="12">
            <CCardGroup>
                <!-- Site name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="siteName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Site Name</Strong>
                        <span class="sub-text">{{ blastSummary.siteName }}</span>
                    </div>
                </div>
                <!-- Pit name -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="pitName" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Pit Name</Strong>
                        <span class="sub-text">{{ blastSummary.pitName }}</span>
                    </div>
                </div>
                <!-- No. of Holes -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="noOfHole" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">No. of Holes</Strong>
                        <span class="sub-text">{{ blastSummary.holes }}</span>
                    </div>
                </div>
                <!-- Shot firer -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="shotFirer" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Shot firer</Strong>
                        <span class="sub-text">{{ blastSummary.shotFirer }}</span>
                    </div>
                </div>
                <!-- Fired time -->
                <div class="card box-unit typeB large py-2">
                    <app-icon name="firedTime" size="xl" fill />
                    <div class="text-wrap">
                        <Strong class="main-text">Fired time</Strong>
                        <span class="sub-text small">{{ blastSummary.firedTime }}</span>
                    </div>
                </div>
            </CCardGroup>
        </CCol>
    </CRow>
</template>

<script>
import moment from 'moment'
import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

export default {
    name: 'BlastDataInfoSummary',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AppIcon
    },
    data() {
        return {
            blastSummary: {
                siteName: utils.getUserInformation().selectedUserSite.siteName,
                pitName: '-',
                holes: '-',
                shotFirer: '-',
                firedTime: '-',
            }
        }
    },
    async created() {
        if (this.blastId != 0) {
            this.setBlastSummary()
        }
    },
    mounted() {
        //
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setBlastSummary() {
            // 입력값 설정
            let params = new Array()
            let siteId = this.siteId
            let blastId = this.blastId

            params.siteId = siteId
            params.blastId = blastId

            let moduleName = "blast-library/"+siteId+"/summary/"+blastId
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            let summaryInfo = this.dataList
            if (summaryInfo != undefined) {
                this.blastSummary.pitName = summaryInfo.pitName
                this.blastSummary.holes = (summaryInfo.holeCount!=null?summaryInfo.holeCount:'-')
                this.blastSummary.shotFirer = (summaryInfo.shotfirerName!=null?summaryInfo.shotfirerName:'-')
                this.blastSummary.firedTime = moment(summaryInfo.blastDate).format('YYYY-MM-DD HH:mm')
            }
        }
    }
}
</script>