<template>
    <div class="mt-2">
        <!-- spinner -->
        <div class="spinner-wrap" v-if="spinnerFlag">
            <div class="sk-wave">
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
                <div class="sk-wave-rect"></div>
            </div>
        </div>
        <!-- //spinner -->
        <CRow class="mt-3">
            <CCol lg="12">
                <CCard class="mb-0">
                    <CCardHeader>
                        <strong class="text-nowrap">Target, Predicted, Actual</strong>
                    </CCardHeader>
                    <CCardBody>
                        <CRow>
                            <CCol lg="8">
                                <AmChartCategoryDoubleTargetLineComp :key="amChartCategoryDoubleTargetLineCompId"
                                    chartHeight="436"
                                    series1Name="Predicted"
                                    series2Name="Actual"
                                    :targetValue=targetValue
                                    :chartData=categoryDoubleChartData
                                />
                            </CCol>
                            <CCol lg="4" class="table-max-height387">
                                <div class="position-relative table-responsive data-table typeA">
                                    <fieldset>
                                        <legend class="sr-only">Target, Predicted, Actual Key parameters table</legend>
                                        <table class="table table-fixed table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-nowrap" scope="col" colspan="2">Key parameters</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(item, index) in keyDataList" :key="index">
                                                    <td>{{ item.key }}</td>
                                                    <td>{{ item.parameters }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </fieldset>
                                </div>
                            </CCol>
                        </CRow>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

const AmChartCategoryDoubleTargetLineComp = () => import(/* webpackChunkName: "fragmentationKeyCharts" */ './AmChartCategoryDoubleTargetLineComp')
import utils from '@/assets/js/utils'
const blastLibrary = 'blastLibrary'

export default {
    name: 'FragmentationKeyTab',
    props: {
        siteId: {
            type: Number,
        },
        blastId: {
            type: Number,
        },
    },
    components: {
        AmChartCategoryDoubleTargetLineComp
    },
    data() {
        return {
            spinnerFlag: false,
            amChartCategoryDoubleTargetLineCompId: 0,
            // productivity
            keyDataList: [
                { key: '-', parameters: '-' }
            ],

            //chart
            //데이터에 문자열 기반 날짜가 포함되어 있을경우 Date객체 또는 타임 스탬프 로 변환할경우 차트 성능이 향상됨
            categoryDoubleChartData: {
                data: [{
                    "category": "category",
                    "value": 0,
                    "value2": 0,
                }]
            },
            targetValue: '100'
        }
    },
    created () {
        if (this.blastId != 0) {
            this.setKeyParameters()
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData'
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
        }),
        async setKeyParameters() {
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            let siteId = that.siteId
            let blastId = that.blastId

            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/fragmentations/keyparameter"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            if (that.data.content != null) {
                // Key parameters list
                let keyParameters = that.data.content.keyParameter
                that.keyDataList = []
                for (var key in keyParameters) {
                    that.keyDataList.push({ key: key, parameters: utils.setDecimal(keyParameters[key]) })
                }

                // chart
                let chart = that.data.content.chart

                let chartData = {}

                chartData.category = 'D50'
                chartData.value = Number(chart.expected)
                chartData.value2 = utils.setDecimal(chart.actual)

                that.targetValue = chart.target+''

                that.categoryDoubleChartData.data[0] = chartData
                that.amChartCategoryDoubleTargetLineCompId += 1
            }

            that.spinnerFlag = false
        },
    }
}
</script>