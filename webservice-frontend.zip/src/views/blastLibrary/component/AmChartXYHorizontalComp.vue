<template>
    <div class="am-xy-chart" ref="chartxy" :style="'height:'+ chartHeight + 'px'"></div>
</template>

<script>
import * as am4core from "@amcharts/amcharts4/core"
import * as am4charts from "@amcharts/amcharts4/charts"
// import am4themes_animated from "@amcharts/amcharts4/themes/animated"

// am4core.useTheme(am4themes_animated)
am4core.options.queue = false

export default {
    name: 'xyHorizontalSeries',
    data() {
        return {
            chart: null,
            okData: []
        }
    },
    props: {
        chartData: Object,
        chartHeight: String,
        series1Name: String,
        series2Name: String,
    },
    watch: {
        chartData: {
            handler: 'loadChart',
            deep: true
        }
    },
    mounted() {
        this.renderChart(this.chartData)
    },
    methods: {
        loadChart() {
            console.log('Values are changed')

            this.chart.dispose()
            this.renderChart(this.chartData)
            this.chart.invalidateData()
        },
        renderChart(addData) {
            let chart = am4core.create(this.$refs.chartxy, am4charts.XYChart)
                chart.data = addData.data

                chart.colors.list = [
                    am4core.color("#f9b990"),
                    am4core.color("#f37321")
                ]

            let categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis())
                categoryAxis.dataFields.category = "target"
                categoryAxis.renderer.grid.template.location = 0
                categoryAxis.renderer.cellStartLocation = 0.1
                categoryAxis.renderer.cellEndLocation = 0.9
                categoryAxis.renderer.labels.template.fill = am4core.color("#777")
                categoryAxis.renderer.labels.template.fontSize = 11
                categoryAxis.renderer.inversed = true
                categoryAxis.renderer.grid.template.disabled = true

            let valueAxis = chart.xAxes.push(new am4charts.ValueAxis())
                valueAxis.min = 0
                valueAxis.renderer.minGridDistance = 30
                valueAxis.renderer.labels.template.fill = am4core.color("#777")
                valueAxis.renderer.labels.template.fontSize = 11
                // valueAxis.renderer.opposite = true

            let series1 = chart.series.push(new am4charts.ColumnSeries())
                series1.dataFields.valueX = 'value1'
                series1.dataFields.categoryY = "target"
                // series1.columns.template.height = am4core.percent(100)
                // series1.sequencedInterpolation = true
                series1.columns.template.tooltipText = "[bold]{target}[/]\n" + this.series1Name + ": [bold;#fff]{valueX}[/]"
                series1.name = this.series1Name
                series1.columns.template.strokeWidth = 0
                series1.columns.template.fill = am4core.color("#f9b990")
                series1.columns.template.tooltipX = am4core.percent(100)
                series1.columns.template.tooltipY = am4core.percent(50)

                series1.cloneTooltip = false // Tooltip off
                series1.showOnInit = false // animation off

            let series2 = chart.series.push(new am4charts.ColumnSeries())
                series2.dataFields.valueX = 'value2'
                series2.dataFields.categoryY = "target"
                // series1.columns.template.height = am4core.percent(100)
                // series1.sequencedInterpolation = true
                series2.columns.template.tooltipText = "[bold]{target}[/]\n" + this.series2Name + ": [bold;#fff]{valueX}[/]"
                series2.name = this.series2Name
                series2.columns.template.strokeWidth = 0
                series2.columns.template.fill = am4core.color("#f37321")
                series2.columns.template.tooltipX = am4core.percent(100)
                series2.columns.template.tooltipY = am4core.percent(50)

                series2.cloneTooltip = false // Tooltip off
                series2.showOnInit = false // animation off

            // 막대 그래프 위 text 표현
            let categoryLabel1 = series1.bullets.push(new am4charts.LabelBullet())
                categoryLabel1.label.text = this.series1Name
                categoryLabel1.label.horizontalCenter = "right"
                categoryLabel1.label.textAlign = "end"
                categoryLabel1.label.dx = -10
                categoryLabel1.label.fill = am4core.color("#fff")
                categoryLabel1.label.hideOversized = true
                categoryLabel1.label.truncate = false

            let categoryLabel2 = series2.bullets.push(new am4charts.LabelBullet())
                categoryLabel2.label.text = this.series2Name
                categoryLabel2.label.horizontalCenter = "right"
                categoryLabel2.label.textAlign = "end"
                categoryLabel2.label.dx = -10
                categoryLabel2.label.fill = am4core.color("#fff")
                categoryLabel2.label.hideOversized = true
                categoryLabel2.label.truncate = false

                chart.maskBullets = false
                chart.paddingRight = 30

                chart.cursor = new am4charts.XYCursor()
                chart.cursor.behavior = "panX"
                chart.cursor.xAxis = categoryAxis
                chart.cursor.fullWidthLineX = true
                chart.cursor.lineX.strokeWidth = 0
                chart.cursor.lineX.fill = am4core.color("#000")
                chart.cursor.lineX.fillOpacity = 0.1
                // chart.cursor.behavior = "selectX"
                chart.cursor.lineY.disabled = true

                chart.legend = new am4charts.Legend()
                chart.legend.useDefaultMarker = true
                chart.legend.position = "top"
                chart.legend.contentAlign = "right"
                chart.legend.marginBottom = 20
                chart.legend.fontSize = 11
                // chart.legend.labels.template.propertyFields.fill = "stroke"

            let markerTemplate = chart.legend.markers.template
                markerTemplate.width = 15
                markerTemplate.height = 10
                markerTemplate.stroke = am4core.color("#ccc")

            // let outLine = chart.legend.markers.template.children.getIndex(0)
            //     outLine.strokeWidth = 2
            //     outLine.strokeOpacity = 1
            //     outLine.stroke = am4core.color("#ccc")

            this.chart = chart
        }
    },
    beforeDestroy(){
        if (this.chart) {
            this.chart.dispose()
        }
    }
}
</script>
<style scoped>
.am-xy-chart{
    width:100%;
    /* height:250px; */
}
</style>
