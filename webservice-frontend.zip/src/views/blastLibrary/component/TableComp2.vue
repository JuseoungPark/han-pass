<template>
    <div>
        <CDataTable
            :items="loadedItems"
            :fields="fields"
            :hover="hover"
            :striped="striped"
            :bordered="bordered"
            :small="small"
            :fixed="fixed"
            :scopedSlots="scopedSlots"
        >
          <template #holeName="{item}">
            <td>
              <router-link to="/blastLibrary/firing" @click.native="holeClick(item, $event)">
                {{ item.holeName }}
              </router-link>
            </td>
          </template>
        </CDataTable>
    </div>
</template>

<script>
export default {
    name: 'DataTableComp',
    props: {
        caption: {
            type: String,
            default: 'Table'
        },
        items: Array,
        hover: Boolean,
        striped: Boolean,
        bordered: Boolean,
        small: Boolean,
        fixed: Boolean,
        dark: Boolean,
        isClickable: Boolean,
    },
    components: {
        //
    },
    data () {
        return {
            fields: [],
            scopedSlots: {},
            loadedItems: this.items.slice(0),
            pages: Math.ceil(this.items.length / 5)
        }
    },
    computed: {
        //
    },
    mounted() {
        this.scopedSlots = {
            'holeId': (item) => (
                '<td>->' + item.holeId + '</td>'
            )
        }

        this.dataFields()
    },
    methods: {
        dataFields() {
            let fields = this.loadedItems
            let fieldsArr = Object.keys(fields[0])

            // 특정 컬럼 제외
            fieldsArr.splice(fieldsArr.indexOf('holeId'), 1)
            fieldsArr.splice(fieldsArr.indexOf('pointXValue'), 1)
            fieldsArr.splice(fieldsArr.indexOf('pointYValue'), 1)

            return this.fields = fieldsArr
        },
        // hole name클릭시 map에서 해당 hole zoom
        holeClick(item, that) {
            let selectSiblings = document.querySelectorAll('.select-table tr')

            selectSiblings.forEach( e => {
                e.classList.remove("selected")
            });
            that.path[2].classList.add("selected")

            this.$emit('holeClick', item)
        },
    }
}
</script>
