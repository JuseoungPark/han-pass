<template>
<CCard class="print-drilling">
    <CCardBody class="line-none">
        <CRow id="printPage">
            <!-- spinner -->
            <div class="spinner-wrap" v-if="spinnerFlag">
                <div class="sk-wave">
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                </div>
            </div>
            <!-- //spinner -->
            <CCol lg="12" class="position-relative">
                <div class="btn-page-event-wrap absolute-wrap">
                    <!-- <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton> -->
                    <CButton type="button" size="sm" color="dark" class="btn-print ml-1 d-md-down-none" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                </div>
                <!-- <CCard> -->
                    <div class="pb-4">
                        <CCol lg="12" class="px-0">
                        <!-- 공통 tab -->
                        <div class="tab-content blast-main-tabs drilling">
                            <ul class="nav nav-tabs">
                                <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                    <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 1}">{{ item.name }}</a>
                                </li>
                            </ul>
                        </div>
                        <!-- // 공통 tab -->
                        </CCol>
                        <CRow class="value-info-wrap mt-4">
                            <!-- blast name -->
                            <CCol lg="3">
                                <!-- <CCard class="mb-0"> -->
                                    <div class="box-unit main large position-relative">
                                        <app-icon name="blasts" size="xl" fill />
                                        <div class="text-wrap">
                                            <Strong class="d-block main-text">Blast Name</Strong>
                                            <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                        </div>
                                        <div class="list-unit">
                                            <BlastNameLists
                                                @blastClick="blastClick"
                                            />
                                        </div>
                                    </div>
                                <!-- </CCard> -->
                            </CCol>
                            <!-- // blast name -->
                            <CCol lg="9" class="lg-mt">
                                <BlastDataInfoDrilling :key="blastDataInfoDrillingId"
                                    ref="blastDataInfoDrilling"
                                    v-bind="blastInfo"
                                    @setSummaryInfo="setSummaryInfo"
                                />
                            </CCol>
                        </CRow>
                    </div>
                <!-- </CCard> -->
            </CCol>
            <CCol>
                <CCard class="cont-wrap mb-0">
                    <CForm @submit.prevent>
                    <CCardBody class="line-none">
                        <CRow>
                            <CCol lg="6">
                                <CCard class="mb-0">
                                    <div class="position-relative radius025 tooltip-style-wrap">
                                        <GmapMap
                                            ref="mapRef"
                                            :center="center"
                                            :zoom="zoom"
                                            :options="options"
                                            class="gmap"
                                        >
                                            <GmapInfoWindow
                                                :options="infoOptions"
                                                :position="infoWindowPos"
                                                :opened="infoWinOpen"
                                                @closeclick="infoWinOpen=false">
                                                <div class="map-tooltip-typeA">
                                                    <div class="map-tooltip-contents">
                                                        <div class="blast d-flex align-items-start justify-content-start">
                                                            <app-icon name="drillPoint" size="l" fill class="ml-1" />
                                                            <div class="info-text-wrap">
                                                                <div style="color:#fff">Hole ID : {{ infoWindows.holeName }}</div>
                                                                <div style="color:#fff">Equipment : {{ infoWindows.equipment }}</div>
                                                                <div style="color:#fff">Worker : {{ infoWindows.worker }}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </GmapInfoWindow>
                                            <GmapMarker
                                                :key="'hole'+index"
                                                v-for="(m, index) in markers"
                                                :position="m.position"
                                                :label="m.label"
                                                :clickable="true"
                                                :draggable="m.draggable"
                                                :zIndex="9990"
                                                :icon="m.icon"
                                                @mouseover="InfoWindowOver(m, index)"
                                            />
                                            <GmapMarker
                                                :key="'hardness'+index"
                                                v-for="(m, index) in hardness"
                                                :position="m.position"
                                                :zIndex="9980"
                                                :icon="m.icon"
                                            />
                                            <GmapMarker
                                                :position="holePosition"
                                                :clickable="true"
                                                :draggable="false"
                                                :zIndex="9999"
                                                :icon="{ url: 'http://labs.google.com/ridefinder/images/mm_20_red.png' }"
                                                @mouseover="InfoWindowOverRow()"
                                            />
                                            <GmapMarker
                                                :position="shadowPosition"
                                                :clickable="false"
                                                :draggable="false"
                                                :zIndex="9998"
                                                :icon="{
                                                    url: 'http://labs.google.com/ridefinder/images/mm_20_shadow.png',
                                                    anchor: { x:6, y:19 }
                                                }"
                                            />
                                        </GmapMap>

                                        <CCard class="mb-0 position-absolute legend-data-wrap">
                                            <!-- <CCardHeader class="py-1">
                                                <strong>Legend</strong>
                                            </CCardHeader> -->
                                            <CCardBody class="line-none">
                                                <ul class="list-unstyled mb-0">
                                                    <li>
                                                        <CImg src="img/gmap/hole_good.png" class="ex-img"/>
                                                        <span>Good</span><small class="ml-2">{{ legend.good }}</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/hole_out.png" class="ex-img"/>
                                                        <span>Out of tolerance</span><small class="ml-2">{{ legend.out }}</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_cancled.png" class="ex-img"/>
                                                        <span>Canceled</span><small class="ml-2">{{ legend.canceled }}</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/hole_etc.png" class="ex-img"/>
                                                        <span>etc.</span><small class="ml-2">{{ legend.etc }}</small>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>

                                        <!-- Rock Hardness -->
                                        <CCard v-if="selectDrillingOptions == 'Rock hardness'" class="mb-0 position-absolute legend-data-wrap" style="min-width:13.75rem;top:8.875rem;">
                                            <CCardBody class="line-none">
                                                <ul class="hardness list-unstyled mb-0">
                                                    <li>
                                                        <CImg src="img/gmap/map_soft.jpg" class="ex-img"/>
                                                        <span>Soft</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_moderate.jpg" class="ex-img"/>
                                                        <span>Moderate</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                    <li class="mt-1">
                                                        <CImg src="img/gmap/map_hard.jpg" class="ex-img"/>
                                                        <span>Hard</span><small class="ml-2">(0.0%)</small>
                                                    </li>
                                                </ul>
                                            </CCardBody>
                                        </CCard>

                                        <CCard class="mb-0 position-absolute legend-radio-wrap">
                                            <!-- <CCardHeader class="py-1">
                                                <strong>Radio button</strong>
                                            </CCardHeader> -->
                                            <CCardBody class="line-none">
                                                <CInputRadioGroup
                                                    name="holeType"
                                                    :options="drillingOptions"
                                                    :checked="$v.form.holeType.$model"
                                                    custom
                                                    v-model.trim="$v.form.holeType.$model"
                                                    @update:checked="holeRadioClick($event, drillingOptions)"
                                                />
                                            </CCardBody>
                                        </CCard>
                                    </div>
                                </CCard>
                            </CCol>
                            <CCol lg="6">
                                <CTabs variant="pills" :active-tab="activeTab" class="lg-mt position-relative" @update:activeTab="updateActiveTab">
                                    <CTab title="Operation" sm="3">
                                        <DrillingOperationTabComp :key="drillingOperationTabCompId"
                                            ref="drillingOperation"
                                            v-bind="blastInfo"
                                        />
                                    </CTab>
                                    <CTab title="Hole table" sm="3">
                                        <!-- excel download -->
                                        <a href="download/sample.xlsx" download class="btn btn-dark btn-sm position-absolute right-top" title="excel download">
                                            <CImg src="img/excel.png"
                                                class="icon-down"
                                            />
                                        </a>
                                        <div class="dark-thead">
                                            <DrillingHoleTable :key="drillingHoleTableId"
                                                ref="holeTable"
                                                v-bind="blastInfo"
                                                @holeClick="holeClick"
                                            />
                                        </div>
                                    </CTab>
                                </CTabs>
                            </CCol>
                        </CRow>
                    </CCardBody>
                    </CForm>
                </CCard>
            </CCol>
        </CRow>
    </CCardBody>
</CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoDrilling from '@/views/blastLibrary/component/BlastDataInfoDrilling'

import DrillingHoleTable from '@/views/blastLibrary/component/DrillingHoleTable'
import DrillingOperationTabComp from '@/views/blastLibrary/component/DrillingOperationTabComp'

//import HoleListData from '@/views/blastLibrary/dummyData/drillingHoleTableData' //임시 data
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import utils from '@/assets/js/utils'

Vue.use(VueAxios, axios)

import { validationMixin } from "vuelidate"
//import { required, minLength } from "vuelidate/lib/validators"

import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'Drilling',
    components: {
        BlastNameLists,
        BlastDataInfoDrilling,
        DrillingHoleTable,
        DrillingOperationTabComp,
        AppIcon
    },
    data() {
        return {
            pageName: 'Drilling',
            pageStatus: true,
            spinnerFlag: false,
            form: this.getEmptyForm(),
            submitted: false,

            activeTab: 0,
            blastDataInfoDrillingId: 0,
            drillingOperationTabCompId: 0,
            drillingHoleTableId: 0,

            // Drilling radio option
            selectDrillingOptions: '',
            drillingOptions: [
                { value: '01', label: 'Hole ID' },
                { value: '02', label: 'Drill Unit' },
                { value: '03', label: 'Planned Drill meter' },
                { value: '04', label: 'Actual Drill meter' },
                { value: '05', label: 'Rock hardness' },
            ],
            holeType: '',

            holeListData: [],
            hardness: [],
            hardnessConst: [],
            holePosition: null,
            shadowPosition: null,
            summaryInfo: [],
            legend: {
                good: '-',
                out: '-',
                canceled: '-',
                etc: '-',
            },

            // google map
            map: null,
            zoom: 2,
            center: { lat: 9.532600, lng: 160.024612 },
            markers: [],
            infoWindows: {
                holeId: '',
                equipmentId: '',
                workerId: '',
            },
            infoWindowPos: {
                lat: 0,
                lng: 0
            },
            infoWinOpen: false,
            currentMidx: null,
            // optional: offset infowindow so it visually sits nicely on top of our marker
            options: {
                minZoom: 3,
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                mapTypeControl: true,
                mapTypeId: "satellite",  //roadmap
                controlSize: 21,
            },
            infoOptions: {
                pixelOffset: null,
            },
            // google map
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            holeType: {
                //
            },
        }
    },
    async created() {
        if (this.blastInfo.blastId == 0) {
            this.pageStatus = false
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }else{
            //this.form.holeType = this.drillingOptions[0].value

            this.holeTable()
        }
    },
    mounted() {
        if (!this.pageStatus) return

        this.$nextTick(() => {
            this.$refs.mapRef.$mapPromise.then((map) => {
                this.map = map
                google.maps.event.addListener(this.map, 'zoom_changed', () => {
                    this.addMapZoomChanged()
                })

                this.infoOptions.pixelOffset = new google.maps.Size(0, -15)
            })
        })
    },
    computed: {
        ...mapGetters(blastLibrary, {
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
        }),
        pagePrint() {
            window.print()
        },
        async holeTable() {
    //        this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let payload
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId

            let moduleName = "blast-library/"+siteId+"/"+blastId+"/drillings/hole-tables"
            payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.holeListData = this.data.content
            this.setMapLegend(this.data.mapLegend)
            this.setHoleMarker()

            this.$refs.holeTable.childMethod(this.holeListData)
        },
        setMapLegend(data) {
            let that = this
            data.forEach(function (el) {
                let legend = (el.status).toLowerCase().trim()
                let value = el.count
                if (el.percentage==null) value += ' '
                else value += ' ('+el.percentage.toFixed(1)+'%)'

                if (legend.indexOf('good') >-1) that.legend.good = value
                else if (legend.indexOf('out') >-1) that.legend.out = value
                else if (legend.indexOf('canceled') >-1) that.legend.canceled = value
                else if (legend.indexOf('etc') >-1) that.legend.etc = value
            })
        },
        // 초기 로딩시 맵에 blast list의 장소를 marker한다
        setHoleMarker() {
            let that = this
            // info window 닫기
            this.infoWinOpen = false

            this.hardness = []
            let holeInfo = []
            let viewFlag = true

            this.holeListData.forEach(function (el) {
                viewFlag = true
                if (viewFlag) {
                    let statusCode = el.drillHoleStatusCode

                    let iconType = 'hole_etc.png'
                    if (statusCode == 'CODE0064') iconType = 'hole_good.png'
                    else if (statusCode == 'CODE0065') iconType = 'hole_out.png'
                    else if (statusCode == 'CODE0066') iconType = 'hole_canceled.png'
                    else if (statusCode == 'CODE0067') iconType = 'hole_etc.png'

                    let rockType = el.rockType
                    if (rockType == '' || rockType == undefined) rockType = '-'

                    holeInfo.push({
                        holeId: el.holeId,
                        position: { lat: el.designPointXValue, lng: el.designPointYValue },
                        draggable: false,
                        label: '',
                        labelInfo: {
                            holeName: el.holeName,
                            equipment: (el.equipmentName!=null?el.equipmentName:'-'),
                            worker: (el.workerName!=null?el.workerName:'-'),
                            '01': { text:''+el.holeName, color:'red', fontSize:'6px' },
                            '02': { text:''+el.equipmentName, color:'blue', fontSize:'6px' },
                            '03': { text:''+el.designLengthValue, color:'olive', fontSize:'6px' },
                            '04': { text:''+el.actualLengthValue, color:'green', fontSize:'6px' },
                            '05': { text:''+rockType, color:'purple', fontSize:'6px' },
                        },
                        icon: {
                            url: 'img/gmap/'+iconType,
                            labelOrigin: { x: 12, y: 20 }  // x: 27, y: 28
                        }
                    })

                    // let ran = Math.floor((Math.random() * 3) + 1)
                    // if (ran==1) rockType = 'hard'
                    // else if (ran==2) rockType = 'soft'
                    // else if (ran==3) rockType = 'moderate'

                    let iconHardness = ''
                    rockType = rockType.toLowerCase()
                    if (rockType=='hard') iconHardness = 'bg_hard.png'
                    else if (rockType=='soft') iconHardness = 'bg_soft.png'
                    else if (rockType=='moderate') iconHardness = 'bg_moderate.png'

                    if (rockType != '') {
                      that.hardnessConst.push({
                        holeId: el.holeId,
                        position: { lat: el.designPointXValue, lng: el.designPointYValue },
                        icon: {
                          url: 'img/gmap/'+iconHardness,
                          anchor: new google.maps.Point(10, 15),
                        }
                      })
                    }
                }
            })
            this.markers = holeInfo

            if (holeInfo.length > 0) {
                this.zoom = 18
                this.center = { lat: holeInfo[0].position.lat, lng: holeInfo[0].position.lng }
            }

            setTimeout(() => {
                this.spinnerFlag = false
            }, 1500);
        },
        setMarker(type) {
            let that = this
            let holeType = this.form.holeType
            let labelView = false

            if (type == 'radio') {
                let latValue = this.markers[0].position.lat
                let lngValue = this.markers[0].position.lng
                let myLatLng = new google.maps.LatLng(latValue, lngValue)

                this.options.mapTypeId = 'roadmap'
                this.map.setCenter(myLatLng)
                setTimeout(function() {
                    if (holeType=='05') that.map.setZoom(20)
                    else that.map.setZoom(21)
                 }, 1000)
            }
            if (this.map.getZoom() >= 19) labelView = true

            this.markers.forEach(function (el) {
                if (labelView) el.label = el.labelInfo[holeType]
                else el.label = ''
            })
            if (holeType=='05') {
                that.hardness = that.hardnessConst
            }else if (that.hardness.length>0) {
                that.hardness = []
            }
        },
        InfoWindowOverRow() {
            this.InfoWindowOver(this.markers[0], 0)
        },
        InfoWindowOver(marker) {
            let flag = this.infoWinOpen
            if (flag && this.infoWindows.holeId==marker.holeId) flag = false
            else flag = true

            this.infoWinOpen = flag

            this.infoWindowPos = marker.position
            this.infoWindows.holeId = marker.holeId
            this.infoWindows.holeName = marker.labelInfo.holeName
            this.infoWindows.equipment = marker.labelInfo.equipment
            this.infoWindows.worker = marker.labelInfo.worker

            //this.infoWinOpen = true
            this.zoom = 20

            // setTimeout(() => {
            //     this.infoWinOpen = false
            // }, 3000);
        },
        // TableComp.vue 에서 해당 holeName
        holeClick(item) {
            let that = this

            this.markers.forEach(function (el) {
                if (el.holeId == item.holeId) {
                    that.InfoWindowOver(el, 0)
                    return false
                }
            })

            // this.holePosition = { lat: Number(item.designPointXValue), lng: Number(item.designPointYValue) }
            // this.map.setZoom(21)
            // this.center = this.holePosition

            // this.shadowPosition = this.holePosition
        },
        async blastClick(blastInfo) {
            this.activeTab = 0

            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.setBlastInfoAction(this.blastInfo)

            // 클릭한 hole에 대한 렌더링
            this.blastDataInfoDrillingId += 1
            this.drillingOperationTabCompId += 1
            this.drillingHoleTableId += 1

            await this.holeTable()

            // Hole table에서 hole name클릭에 대한 기존 선택된 상태값 초기화
            this.holePosition = null
            this.shadowPosition = null
            this.infoWinOpen = false
        },
        holeRadioClick(event, options) {
            this.form.holeType = event
            this.setMarker('radio')

            let optionValue = event.replace(/(^0+)/, "") - 1
            this.selectDrillingOptions = options[optionValue].label
        },
        setSummaryInfo(item) {
            this.$refs.drillingOperation.setOperationSummary(item)
        },
        addMapZoomChanged() {
            this.setMarker('zoom')
        },
        updateActiveTab(index) {
            this.activeTab = index

            this.spinnerFlag = true
            setTimeout(() => {
                this.spinnerFlag = false
            }, 1500);
        },
        getEmptyForm() {
            return {
                holeType: ''
            }
        },
    }
}
</script>
<style lang="scss" scoped>
.gmap{
    height: 790px;
}
@media screen and (max-width:991px){
    .gmap{
        height: 400px;
    }
}
</style>