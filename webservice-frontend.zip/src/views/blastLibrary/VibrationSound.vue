<template>
<CCard class="print-vs">
    <CCardBody class="line-none">
        <div>
            <!-- pdf-format="a3" -->
            <!-- pdf-orientation="landscape" -->
            <!-- filename="VibrationSound" -->
        <vue-html2pdf
            class="html2pdf-wrap"
            :show-layout="true"
            :float-layout="false"
            :enable-download="true"
            :preview-modal="true"
            :paginate-elements-by-height="1400"
            :pdf-quality="2"
            :manual-pagination="false"
            :html-to-pdf-options="htmlToPdfOptions"
            pdf-content-width="100%"
            @progress="onProgress($event)"
            @hasStartedGeneration="hasStartedGeneration()"
            @hasGenerated="hasGenerated($event)"
            ref="html2Pdf"
        >
        <section slot="pdf-content">
        <CRow id="printPage">
            <!-- spinner -->
            <div class="spinner-wrap" v-if="spinnerFlag">
                <div class="sk-wave">
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                    <div class="sk-wave-rect"></div>
                </div>
            </div>
            <!-- //spinner -->
            <CCol lg="12" class="position-relative">
                <div class="btn-page-event-wrap absolute-wrap" data-html2canvas-ignore="true">
                    <!-- <CButton type="button" size="sm" color="dark" class="btn-reload" @click="pageReload"><CIcon name="cil-reload"/></CButton> -->
                    <!-- pdf download -->
                    <!-- <a href="download/sample.pdf" download class="btn btn-dark btn-sm" title="pdf download"> -->
                    <button @click="generateReport"
                        class="btn btn-dark btn-sm position-relative d-md-down-none"
                        title="pdf download">
                        <CImg src="img/pdf.png"
                            class="icon-down"
                        />
                        <div v-if="progressBar >= 30"
                            class="pdf-progress-wrap position-absolute">
                            <div class="pdf-progress"><span class="pdf-progress-inner" :style="'width:' + progressBar + '%'"></span></div>
                        </div>
                    </button>
                    <CButton type="button" size="sm" color="dark" class="btn-print ml-1 d-md-down-none" @click="pagePrint"><CIcon name="cil-print"/></CButton>
                </div>
                <!-- <CCard> -->
                    <div class="pb-4">
                        <CCol lg="12" class="px-0" data-html2canvas-ignore="true">
                        <!-- 공통 tab -->
                        <div class="tab-content blast-main-tabs vibration">
                            <ul class="nav nav-tabs">
                                <li v-for="(item, index) in blastTabData" :key="index" class="nav-item">
                                    <a :href="`#/blastLibrary/${item.link}`" target="_self" class="nav-link" :class="{active : index == 5}">{{ item.name }}</a>
                                </li>
                            </ul>
                        </div>
                        <!-- // 공통 tab -->
                        </CCol>
                        <CRow class="value-info-wrap mt-4">
                            <!-- blast name -->
                            <CCol lg="3">
                                <!-- <CCard class="mb-0"> -->
                                    <div class="box-unit main large position-relative">
                                        <app-icon name="blasts" size="xl" fill />
                                        <div class="text-wrap">
                                            <Strong class="d-block main-text">Blast Name</Strong>
                                            <span class="sub-text d-block">{{ blastInfo.blastName }}</span>
                                        </div>
                                        <div class="list-unit">
                                            <BlastNameLists
                                                @blastClick="blastClick"
                                            />
                                        </div>
                                    </div>
                                <!-- </CCard> -->
                            </CCol>
                            <!-- // blast name -->
                            <CCol lg="9" class="lg-mt">
                                <BlastDataInfoVibrationSound :key="blastDataInfoVibrationSoundId"
                                    ref="blastDataInfoVibrationSound"
                                    v-bind="blastInfo"
                                />
                            </CCol>
                        </CRow>
                    </div>
                <!-- </CCard> -->
            </CCol>
            <CCol>
                <CCard class="cont-wrap">
                    <CForm @submit.prevent>
                    <CCardBody class="line-none">
                        <CRow>
                            <CCol lg="5">
                                <CCard class="mb-0">
                                    <div class="position-relative radius025 tooltip-style-wrap">
                                        <GmapMap
                                            ref="mapRef"
                                            :center="center"
                                            :zoom="zoom"
                                            :options="options"
                                            class="gmap"
                                        >
                                            <GmapInfoWindow
                                                :options="blastInfoOptions"
                                                :position="blastInfoWindowPos"
                                                :opened="blastInfoWinOpen"
                                                @closeclick="blastInfoWinOpen=false">
                                                <div class="map-tooltip-typeA">
                                                    <div class="map-tooltip-contents">
                                                        <div class="blast d-flex align-items-start justify-content-start">
                                                            <app-icon name="blastPoint" size="l" fill class="ml-1" />
                                                            <div class="info-text-wrap">
                                                                <div style="color:#fff">Blast name : {{ blastInfoWindows.blastName }}</div>
                                                                <div style="color:#fff">Pit time : {{ blastInfoWindows.pitName }}</div>
                                                                <div style="color:#fff">Blasted time : {{ blastInfoWindows.blastedTime }}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </GmapInfoWindow>
                                            <GmapInfoWindow
                                                :options="pointInfoOptions"
                                                :position="pointInfoWindowPos"
                                                :opened="pointInfoWinOpen"
                                                @closeclick="pointInfoWinOpen=false">
                                                <div class="map-tooltip-typeA">
                                                    <div class="map-tooltip-contents">
                                                        <div class="blast d-flex align-items-start justify-content-start">
                                                            <app-icon name="structurePoint" size="l" fill class="ml-1" />
                                                            <div class="info-text-wrap">
                                                                <div class="value-wrap">
                                                                    <span>Point Name</span>
                                                                    <span class="num">{{ pointInfoWindows.pointName }}</span>
                                                                </div>
                                                                <div class="value-wrap">
                                                                    <span>Limitation PVS</span>
                                                                    <span class="num">{{ pointInfoWindows.limitationPvs }}</span>
                                                                </div>
                                                                <div class="value-wrap">
                                                                    <span>Actual PVS</span>
                                                                    <span class="num">{{ pointInfoWindows.actualPvs }}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </GmapInfoWindow>
                                            <GmapInfoWindow
                                                :options="structuresInfoOptions"
                                                :position="structuresInfoWindowPos"
                                                :opened="structuresInfoWinOpen"
                                                @closeclick="structuresInfoWinOpen=false">
                                                <div class="map-tooltip-typeA">
                                                    <div class="map-tooltip-contents">
                                                        <div class="blast d-flex align-items-start justify-content-start">
                                                            <app-icon name="structurePoint" size="l" fill class="ml-1" />
                                                            <div class="info-text-wrap">
                                                                <span class="name">structurePoint</span>

                                                                <div class="value-wrap">
                                                                    <span>Structures Name</span>
                                                                    <span class="num">{{ structuresInfoWindows.structuresName }}</span>
                                                                </div>
                                                                <div class="value-wrap">
                                                                    <span>Description</span>
                                                                    <span class="num">{{ structuresInfoWindows.description }}</span>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </GmapInfoWindow>
                                            <GmapMarker
                                                :key="'blast-'+index"
                                                v-for="(m, index) in blastPosition"
                                                :position="m.position"
                                                :label="m.label"
                                                :clickable="true"
                                                :draggable="m.draggable"
                                                :icon="{ url: 'img/gmap/ic_blast_now.png' }"
                                                @mouseover="InfoWindowOverBlast(m, index)"
                                            />
                                            <GmapMarker
                                                :key="'point-'+index"
                                                v-for="(m, index) in pointPosition"
                                                :position="m.position"
                                                :label="m.label"
                                                :clickable="true"
                                                :draggable="m.draggable"
                                                :icon="{ url: 'img/gmap/ic_vibration.png' }"
                                                @mouseover="InfoWindowOverPoint(m, index)"
                                            />
                                            <GmapMarker
                                                :key="'structures-'+index"
                                                v-for="(m, index) in structuresPosition"
                                                :position="m.position"
                                                :label="m.label"
                                                :clickable="true"
                                                :draggable="m.draggable"
                                                :visible="m.visibility"
                                                :icon="{ url: 'img/gmap/ic_structure.png' }"
                                                @mouseover="InfoWindowOverStructures(m, index)"
                                            />
                                            <GmapCircle
                                                v-for="(pin, index) in circle"
                                                :key="'circle-'+index"
                                                :center="pin.position"
                                                :radius="pin.radius"
                                                :visible="true"
                                                :options="pin.options"
                                                >
                                            </GmapCircle>
                                        </GmapMap>
                                        <CCard class="mb-0 position-absolute legend-radio-wrap"><!-- top-right -->
                                            <!-- <CCardHeader class="py-1">
                                                <strong>Radio button</strong>
                                            </CCardHeader> -->
                                            <CCardBody class="line-none">
                                                <!-- class="col-sm-9" -->
                                                <CInputRadioGroup
                                                    name="radioType"
                                                    :options="radioOptions"
                                                    :checked="$v.form.radioType.$model"
                                                    custom
                                                    v-model.trim="$v.form.radioType.$model"
                                                    @update:checked="radioClick($event)"
                                                />
                                            </CCardBody>
                                        </CCard>
                                    </div>
                                </CCard>
                            </CCol>
                            <CCol lg="7">
                                <CTabs variant="pills" :active-tab="0" class="lg-mt position-relative" @update:activeTab="setPointTab">
                                    <CTab v-for="point in pointTab"
                                        :key="point.index"
                                        :title="point.title"
                                        sm="3">
                                        <VibrationSoundPoint01TabComp
                                            ref="vibrationSoundPointTabComp"
                                            v-if="pointTabIndex == point.index"
                                            v-bind="blastInfo"
                                        />
                                    </CTab>
                                    <!-- <CTab title="Point 01" sm="3">
                                        <VibrationSoundPoint01TabComp
                                            ref="vibrationSoundPoint01TabComp"
                                            v-if="pointTabIndex == 0"
                                            v-bind="blastInfo"
                                        />
                                    </CTab>
                                    <CTab title="Point 02" sm="3">
                                        <VibrationSoundPoint02TabComp
                                            v-if="pointTabIndex == 1"
                                        />
                                    </CTab> -->
                                </CTabs>
                            </CCol>
                        </CRow>
                    </CCardBody>
                    </CForm>
                </CCard>
            </CCol>
        </CRow>
        </section>
        </vue-html2pdf>
        </div>
    </CCardBody>
</CCard>
</template>

<script>
import BlastNameLists from '@/views/blastLibrary/component/BlastNameLists'
import BlastDataInfoVibrationSound from '@/views/blastLibrary/component/BlastDataInfoVibrationSound'

import VibrationSoundPoint01TabComp from '@/views/blastLibrary/component/VibrationSoundPoint01TabComp'
//import VibrationSoundPoint02TabComp from '@/views/blastLibrary/component/VibrationSoundPoint02TabComp'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import moment from 'moment'
import utils from '@/assets/js/utils'
import VueHtml2pdf from 'vue-html2pdf'

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'

Vue.use(VueAxios, axios)

import { validationMixin } from "vuelidate"
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
    name: 'VibrationSound',
    components: {
        BlastNameLists,
        BlastDataInfoVibrationSound,

        AppIcon,
        VueHtml2pdf,

        VibrationSoundPoint01TabComp,
        //VibrationSoundPoint02TabComp,
    },
    data() {
        return {
            pageName: 'VibrationSound',
            pointTabIndex: 0, // point tab index number
            spinnerFlag: false,
            form: this.getEmptyForm(),
            blastDataInfoVibrationSoundId: 0,

            //VueHtml2pdf
            progressBar: 0,
            htmlToPdfOptions: {
                margin: 0,
                filename: "VibrationSound",
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a3',
                    orientation: 'landscape',
                },
                pagebreak: {
                    // mode: ['avoid-all', 'css', 'legacy']
                    mode: ['avoid', 'css', 'legacy']
                },
                html2canvas: {
                    scale: 1,
                    useCORS: true,
                    allowTaint: false,
                    ignoreElements: (node) => {
                        return node.nodeName === 'IFRAME'
                    },
                    // svg image
                    onclone: (element) => {
                        const svgElements = Array.from(element.querySelectorAll('svg'))

                        svgElements.forEach(s => {
                            const bBox = s.getBBox()
                            s.setAttribute("x", bBox.x)
                            s.setAttribute("y", bBox.y)
                            s.setAttribute("width", bBox.width)
                            s.setAttribute("height", bBox.height)
                        })
                    }
                }
            },

            pointTab: [],

            // Drilling radio option
            radioOptions: [
                { value: '01', label: 'Monitoring point' },
                { value: '02', label: 'Mine Structure' },
                { value: '03', label: 'Vibration Range' },
            ],
            radioType: '',

            // google map
            map: null,
            zoom: 2,
            center: { lat: 37.552855, lng: 128.968973 },
            // blast
            blastPosition: [],
            blastInfoWindows: {
                blastName: '',
                pitName: '',
                blastedTime: '',
            },
            blastInfoWindowPos: {
                lat: 0,
                lng: 0
            },
            blastInfoOptions: {
                pixelOffset: null,
            },
            blastInfoWinOpen: false,
            // point
            pointPosition: [],
            pointInfoWindows: {
                pointName: '',
                limitationPvs: '',
                actualPvs: '',
            },
            pointInfoWindowPos: {
                lat: 0,
                lng: 0
            },
            pointInfoOptions: {
                pixelOffset: null,
            },
            pointInfoWinOpen: false,
            // structures
            structuresPosition: [],
            structuresInfoWindows: {
                structuresName: '',
                description: '',
            },
            structuresInfoWindowPos: {
                lat: 0,
                lng: 0
            },
            structuresInfoOptions: {
                pixelOffset: null,
            },
            structuresInfoWinOpen: false,

            currentMidx: null,
            // optional: offset infowindow so it visually sits nicely on top of our marker
            options: {
                fullscreenControl: false,
                streetViewControl: false,
                rotateControl: false,
                scrollwheel: true,
                mapTypeControl: true,
                mapTypeId: "satellite",  //roadmap
                controlSize: 21,
            },
            infoOptions: {
                pixelOffset: null,
            },

            circle: [],
            // google map
        }
    },
    mixins: [validationMixin],
    validations: {
        form: {
            radioType: {
                //
            },
        }
    },
    async created() {
        if (this.blastInfo.blastId == 0) {
            utils.showToastRed(this.$t('message.noBlastInfo'))
        }else{
            // 접속 blast 맵 셋팅
 //           this.zoom = 17
            //this.center = { lat: Number(this.blastInfo.lat), lng: Number(this.blastInfo.lng) }
//            this.center = { lat: 37.552855, lng: 128.968973 }
        }
    },
    mounted() {
        this.$nextTick(() => {
            this.$refs.mapRef.$mapPromise.then((map) => {
                this.map = map
                google.maps.event.addListener(this.map, 'zoom_changed', () => {
                    this.addMapZoomChanged()
                });

                this.blastInfoOptions.pixelOffset = new google.maps.Size(0, -40)
                this.pointInfoOptions.pixelOffset = new google.maps.Size(0, -25)
                this.structuresInfoOptions.pixelOffset = new google.maps.Size(0, -40)
            })
        })

        if (this.blastInfo.blastId != 0) {
            this.getBlast()

            this.form.radioType = this.radioOptions[2].value
            this.radioClick(this.form.radioType)
        }
    },
    computed: {
        ...mapGetters(blastLibrary, {
            status: 'getStatus',
            data: 'getData',
            dataList: 'getDataList',
            selectedData: 'getSelectedData',
            blastInfo: 'getBlastInfo',
            blastList: 'getBlastList',
            blastTabData: 'getBlastTabData',
        }),
    },
    methods: {
        ...mapActions(blastLibrary, {
            setDataListAction: 'setDataList',
            setSelectedAction: 'setSelectedData',
            setBlastInfoAction: 'setBlastInfo',
        }),
        pagePrint() {
            window.print()
        },
        // pageReload() {
        //     this.$router.go()
        // },
        async getBlast() {
console.log('getBlast...')
            this.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId
//siteId = 6
//blastId = 55
            let moduleName = "blast-library/"+siteId+"/summary/"+blastId+"/blast-condition"
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)

            this.blastPosition = []
            if (this.dataList != undefined) {
                let blastInfo = this.dataList

                blastInfo.blastedTime = moment(blastInfo.blastDate).format('YYYY-MM-DD HH:mm')

                let centerLocation = blastInfo.centerLocation
                if (centerLocation != null) {
                    centerLocation = centerLocation.split(',')
                    let latValue = Number(centerLocation[0])
                    let lngValue = Number(centerLocation[1])

                    this.zoom = 15
                    this.center = { lat: latValue, lng: lngValue }

                    this.blastPosition.push({
                        position: this.center,
                        draggable: false,
                        label: '',
                        labelInfo: {
                            blastName: blastInfo.blastName,
                            pitName: blastInfo.pitName,
                            blastedTime: blastInfo.blastedTime,
                        }
                    })
                }
            }

            this.getSummary()

            this.spinnerFlag = false
        },
        async getSummary() {
console.log('getSummary...')
            let that = this
            that.spinnerFlag = true

            let params = new Array()
            //let siteId = that.siteId
            //let blastId = that.blastId
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId
//siteId = 6
//blastId = 67
            let moduleName = "v1/blast-library/"+siteId+"/"+blastId+"/vibrations/summary"
//console.log(moduleName)
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)

            that.pointTab = []
            that.pointPosition = []

            if (that.status == '200' && that.dataList.geophoneList != null) {
//console.log(that.dataList.geophoneList)
                that.dataList.geophoneList.forEach(function (el, idx) {
                    that.pointTab.push(
                        {
                            index: idx,
                            id: el.geophoneId,
                            title: el.geophoneName,
                            model: el.modelName,
                            pointType: el.monitoringPointType,
                        }
                    )
// 시스템 실데이터 적용 필요
                    if (el.latitudeValue != null && el.latitudeValue != '') {
                        that.pointPosition.push({
                            id: el.geophoneId,
                            position: { lat: Number(el.latitudeValue), lng: Number(el.longitudeValue) },
                            visibility: false,
                            pointName: el.geophoneName,
                            limitationPvs: (el.pvsValue!=null?el.pvsValue:'-'),
                            actualPvs: (el.actualPvs!=null?el.actualPvs:'-')
                        })
                    }
                })
            }

            that.getGeophone(0)
            that.getStructures()

            that.spinnerFlag = false
        },
        async getStructures() {
console.log('getStructures...')
            let that = this
            that.spinnerFlag = true

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
//siteId = 1
            let moduleName = "v1/siteInfos/"+siteId+"/structures/?pagable=false&page=1&size=100"
            let payload = { params: params, moduleName: moduleName }
            await that.setDataListAction(payload)
//console.log(that.data)
            that.structuresPosition = []
            if (that.status == '200' && that.data != undefined) {
                let latValue = '' // 37.552855
                let lngValue = '' // 128.965973
                let structuresArr = that.data.content
                structuresArr.forEach(function (el) {
                    if (el.useYn == 'Y') {
                        latValue = Number(el.latitudeValue)
                        lngValue = Number(el.longitudeValue)

                        that.structuresPosition.push({
                            position: { lat: latValue, lng: lngValue },
                            visibility: false,
                            structuresName: el.structureName,
                            description: el.structureDescription,
                        })
                    }
                })
            }
//console.log(that.structuresPosition)
            that.spinnerFlag = false
        },
        async getGeophone(tabIndex) {
console.log('getGeophone....')
            this.spinnerFlag = true

            if (this.pointPosition.length==0) return

            // 입력값 설정
            let params = new Array()
            let siteId = this.blastInfo.siteId
            let blastId = this.blastInfo.blastId
            let geophoneId = this.pointTab[tabIndex].id

            let geophonePosition = { lat: '', lng: '' }
            this.pointPosition.forEach(function (el) {
                if (geophoneId==el.id) {
                    geophonePosition = el.position
                }
            })

//siteId = 6
//blastId = 103
//blastId = 60
            let moduleName = "v1.1/blast-library/"+siteId+"/vibrations/"+blastId+"/"+geophoneId
            let payload = { params: params, moduleName: moduleName }
            await this.setDataListAction(payload)
console.log(moduleName)
            if (this.status == '200' && this.data.content != null) {
                let pointInfo = this.data.content

                pointInfo.model = this.pointTab[tabIndex].model
                pointInfo.pointType = this.pointTab[tabIndex].pointType

                // let summary = {}
                // // summary PVS
                // let pvs2 = pointInfo.VectorSum1stBlock
                // summary.pvs2 = pvs2

                // // summary sound
                // let PeakValueForEachChannel = pointInfo.PeakValueForEachChannel
                // let sound = 0
                // PeakValueForEachChannel.forEach(function (value) {
                //     sound += Number(value)
                // })
                // summary.sound = sound.toFixed(1)

                pointInfo.tabIndex = tabIndex
                pointInfo.blastPosition = this.blastPosition[0].position
                pointInfo.geophonePosition = geophonePosition

                //this.$refs.blastDataInfoVibrationSound.setSummary(summary)

                //this.$refs.vibrationSoundPointTabComp.setPointInfo(pointInfo)
                this.$refs['vibrationSoundPointTabComp'][0].setPointInfo(pointInfo)
            } else {
                utils.showToastRed(this.$t('message.noGeophoneInfo'))
            }

            //this.getGmapCircle()

            this.spinnerFlag = false
        },
        getGmapCircle() {
            // GmapCircle -----------------------------------------------------
            this.circle.push({
                position: { lat: 37.552855, lng: 128.968973 },
                radius: 250,
                draggable: false,
                options: {
                    strokeColor: 'red', strokeOpacity: 0.1, strokeWeight: 1
                    , fillColor: 'red', fillOpacity: 0.2
                }
            })

            this.circle.push({
                position: { lat: 37.552855, lng: 128.968973 },
                radius: 100,
                draggable: false,
                options: {
                    strokeColor: 'red', strokeOpacity: 0.1, strokeWeight: 1
                    , fillColor: 'red', fillOpacity: 0.2
                }
            })
        },
        InfoWindowOverBlast(marker) {
            this.InfoWindowOverClose('blast')

            this.blastInfoWindowPos = marker.position
            this.blastInfoWindows.blastName = marker.labelInfo.blastName
            this.blastInfoWindows.pitName = marker.labelInfo.pitName
            this.blastInfoWindows.blastedTime = marker.labelInfo.blastedTime

            let flag = this.blastInfoWinOpen
            this.blastInfoWinOpen = !flag
            // setTimeout(() => {
            //     this.blastInfoWinOpen = false
            // }, 3000);
        },
        InfoWindowOverPoint(marker) {
            this.InfoWindowOverClose('point')

            this.pointInfoWindowPos = marker.position
            this.pointInfoWindows.pointName = marker.pointName
            this.pointInfoWindows.limitationPvs = marker.limitationPvs
            this.pointInfoWindows.actualPvs = marker.actualPvs

            let flag = this.pointInfoWinOpen
            this.pointInfoWinOpen = !flag
            // setTimeout(() => {
            //     this.pointInfoWinOpen = false
            // }, 3000);
        },
        InfoWindowOverStructures(marker) {
            this.InfoWindowOverClose('structures')

            this.structuresInfoWindowPos = marker.position
            this.structuresInfoWindows.structuresName = marker.structuresName
            this.structuresInfoWindows.description = marker.description

            let flag = this.structuresInfoWinOpen
            this.structuresInfoWinOpen = !flag
            // setTimeout(() => {
            //     this.structuresInfoWinOpen = false
            // }, 3000);
        },
        InfoWindowOverClose(type) {
            if (type != 'blast') this.blastInfoWinOpen = false
            if (type != 'point') this.pointInfoWinOpen = false
            if (type != 'structures') this.structuresInfoWinOpen = false
        },
        setPointTab(number) {
console.log('pointTab...')
            this.getGeophone(number)

            return this.pointTabIndex = number
        },
        generateReport() {
            this.$refs.html2Pdf.generatePdf()
        },
        onProgress(progress) {
			this.progressBar = progress
            console.log(`PDF generation progress: ${progress}%`)

            if(progress == 100){
                setTimeout(() => {
                    utils.showToast('PDF download is completed')
                    return this.progressBar = 0
                }, 1000)
            }
        },
        blastClick(blastInfo) {
            this.blastInfo.blastId = blastInfo.blastId
            this.blastInfo.blastName = blastInfo.blastName + '('+blastInfo.holes+')'
            this.blastInfo.lat = blastInfo.lat
            this.blastInfo.lng = blastInfo.lng

            this.setBlastInfoAction(this.blastInfo)
            this.getBlast()

            this.blastDataInfoVibrationSoundId += 1
        },
        radioClick(event) {
            if (event == 1) {
                this.circle = []
                this.InfoWindowOverPoint(this.pointPosition[0])

                this.structuresPosition.forEach(function (el) {
                    el.visibility = false
                })
            }else if (event == 2) {
                this.circle = []
                this.InfoWindowOverStructures(this.structuresPosition[0])

                this.structuresPosition.forEach(function (el) {
                    el.visibility = true
                })
            }else if (event == 3) {
                this.getGmapCircle()
                this.structuresPosition.forEach(function (el) {
                    el.visibility = false
                })
            }
        },
        addMapZoomChanged() {
            //this.setMarker('zoom')
        },
        getEmptyForm() {
            return {
                radioType: ''
            }
        },
    }
}
</script>
<style lang="scss" scoped>
.gmap{
    height: 862px;
}
@media screen and (max-width:991px){
    .gmap{
        height: 400px;
    }
}
</style>