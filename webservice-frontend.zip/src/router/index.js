import Vue from 'vue'
import Router from 'vue-router'
// import store from '@/store'
 import utils from '@/assets/js/utils'

// Containers
const TheContainer = () => import(/* webpackChunkName: "containers" */ '@/containers/TheContainer')

// Views
//const Dashboard = () => import('@/views/Dashboard')
const HomeDashboard = () => import(/* webpackChunkName: "homeDashboard" */ '@/views/HomeDashboard')

const SiteDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/SiteDashboard')

// D&B Menu
const DrillingDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/dashboard/DrillingDashboard')
const ChargingDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/dashboard/ChargingDashboard')
const ADDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/dashboard/ChargingDashboard')
const VibrationDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/dashboard/VibrationDashboard')
const MonitoringDashboard = () => import(/* webpackChunkName: "dashboard" */ '@/views/dashboard/MonitoringDashboard')
//const ADDashboard = () => import('@/views/dashboard/ADDashboard')
//----------------------------------------------------------------//

// admin
const SiteInformation = () => import(/* webpackChunkName: "siteAdmin" */ '@/views/admin/SiteInformation')
// const SiteCompany = () => import(/* webpackChunkName: "siteAdmin" */ '@/views/admin/siteComp/SiteCompany')
// const Site = () => import(/* webpackChunkName: "siteAdmin" */ '@/views/admin/siteComp/Site')
// const SiteMap = () => import(/* webpackChunkName: "siteAdmin" */ '@/views/admin/siteComp/SiteMap')
// const UserManagement = () => import(/* webpackChunkName: "siteAdmin" */ '@/views/admin/siteComp/user-management')


const SystemSetting = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemsetting')
// const CodeManagement1depth = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/codeManagement1Depth')
// const CodeManagement2depth = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/codeManagement2Depth')
// const MenuManagement1depth = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/menu-management-1depth')
// const MenuManagement2depth = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/menu-management-2depth')
// const CodeManagementAuthority = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/authorityType')
// const MenuAuthority = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/authorityMenuSetting')
// const LanguageManagement = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/language-management')
// const UserLogManagement = () => import(/* webpackChunkName: "systemAdmin" */ '@/views/admin/systemComp/user-log-management')
//----------------------------------------------------------------//


// analytics
const analyticsSummary = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsSummary')
const analyticsDrilling = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsDrilling')
const analyticsCharging = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsCharging')
const analyticsCost = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsCost')
const analyticsFragmentation = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsFragmentation')
const analyticsVibration = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsVibration')
const analyticsFleet = () => import(/* webpackChunkName: "analytics" */ '@/views/analytics/analyticsFleet')

// library
const BlastSummary = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/BlastSummary')
const SummaryReport = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/SummaryReport')
const DrillingManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/Drilling')
const ChargingManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/Charging')
const FiringManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/Firing')
const FragmentationManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/Fragmentation')
const VibrationSoundManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/VibrationSound')
const ProductivityCostManagement = () => import(/* webpackChunkName: "library" */ '@/views/blastLibrary/ProductivityCost')


const Colors = () => import('@/views/theme/Colors')
const Typography = () => import('@/views/theme/Typography')

const Charts = () => import('@/views/charts/Charts')
const AmChartSample = () => import('@/views/charts/AmChartSample')
const Widgets = () => import('@/views/widgets/Widgets')

// Views - Components
const Cards = () => import('@/views/base/Cards')
const Switches = () => import('@/views/base/Switches')
const Tabs = () => import('@/views/base/Tabs')
const Breadcrumbs = () => import('@/views/base/Breadcrumbs')
const Carousels = () => import('@/views/base/Carousels')
const Collapses = () => import('@/views/base/Collapses')
const Jumbotrons = () => import('@/views/base/Jumbotrons')
const ListGroups = () => import('@/views/base/ListGroups')
const Navs = () => import('@/views/base/Navs')
const Navbars = () => import('@/views/base/Navbars')
const Paginations = () => import('@/views/base/Paginations')
const Popovers = () => import('@/views/base/Popovers')
const ProgressBars = () => import('@/views/base/ProgressBars')
const Tables = () => import('@/views/tables/Tables')
const AdvancedTables = () => import('@/views/tables/AdvancedTables')
const Tooltips = () => import('@/views/base/Tooltips')

// Views - Buttons
const StandardButtons = () => import('@/views/buttons/StandardButtons')
const ButtonGroups = () => import('@/views/buttons/ButtonGroups')
const Dropdowns = () => import('@/views/buttons/Dropdowns')
const BrandButtons = () => import('@/views/buttons/BrandButtons')

// Views - Editors
const TextEditors = () => import('@/views/editors/TextEditors')
const CodeEditors = () => import('@/views/editors/CodeEditors')

// Views - Forms
const BasicForms = () => import('@/views/forms/Forms')
const AdvancedForms = () => import('@/views/forms/AdvancedForms')
const ValidationForms = () => import('@/views/forms/ValidationForms')

// Views GoogleMaps
const GoogleMaps = () => import('@/views/GoogleMaps')

// Views - Icons.
const CoreUIIcons = () => import('@/views/icons/CoreUIIcons')
const Brands = () => import('@/views/icons/Brands')
const Flags = () => import('@/views/icons/Flags')

// Views - Notifications
const Alerts = () => import('@/views/notifications/Alerts')
const Badges = () => import('@/views/notifications/Badges')
const Modals = () => import('@/views/notifications/Modals')
const Toaster = () => import('@/views/notifications/Toaster')


// Views - Pages
const Page404 = () => import(/* webpackChunkName: "Pages" */ '@/views/pages/Page404')
const Page500 = () => import(/* webpackChunkName: "Pages" */ '@/views/pages/Page500')
const Login = () => import(/* webpackChunkName: "Pages" */ '@/views/pages/Login')
const Register = () => import(/* webpackChunkName: "Pages" */ '@/views/pages/Register')

// Users
const Users = () => import('@/views/users/Users')
const User = () => import('@/views/users/User')

// Plugins
const Draggable = () => import('@/views/plugins/Draggable')
const Calendar = () => import('@/views/plugins/Calendar')
const Spinners = () => import('@/views/plugins/Spinners')

// Views - UI Kits
const Invoice = () => import('@/views/apps/invoicing/Invoice')
const Compose = () => import('@/views/apps/email/Compose')
const Inbox = () => import('@/views/apps/email/Inbox')
const Message = () => import('@/views/apps/email/Message')

Vue.use(Router)

const requireAuth = () => (from, to, next) => {
  let checkData = utils.getUserInformation()
  if (!checkData)  {
    next('/user/login?returnPath=/homedashboard')
    //return
  } else {
    const isAuthenticated = utils.getUserInformation().isAuthenticated
    //const isAuthenticated = localStorage.getItem('isAuthenticated')
    //  console.log("******* requireAuth isAuthenticated before",isAuthenticated )
    if (isAuthenticated) {
    // if (store.getters.isAuthenticated) {
      // console.log("******* requireAuth isAuthenticated after",isAuthenticated )
      return next()
    }
    next('/user/login?returnPath=/homedashboard')
  }
}

//const lmsg = utils.getLogMessage('router')

// function onBeforeEnter(to, from, next) {
//   const toCategory = to.path.split('/')[1]
//   const fromCategory = from.path.split('/')[1]

//   console.log("toCategory : ", toCategory)
//   console.log("fromCategroy : ", fromCategory)

//   if (toCategory !== fromCategory || toCategory === 'systems') {
//     const pageName = to.path.split('/').splice(-1)
//     const key = `${ pageName }-searchItem`

//     console.log(pageName)
//     console.log(key)

//     localStorage.removeItem(key)
//   }
//   next()
// }


export default new Router({
  mode: 'hash', // https://router.vuejs.org/api/#mode
  //mode : 'history',
  linkActiveClass: 'open active',
  scrollBehavior: () => ({ y: 0 }),
  routes: [
    // {
    //   path: '/login',
    //   redirect: '/pages/Login',
    //   name: 'login',
    //   component: {
    //     render (c) { return c('router-view') }
    //   },
    //   children: [
    //     {
    //       path: 'login',
    //       name: 'Login',
    //       component: Login
    //     }
    //   ]
    // },
    {
      path: '/',
      redirect: 'homedashboard',
      //redirect: '/pages/Login',
      name: 'Home',
      component: {
        render (c) { return c('router-view') }
      },
      children: [
        {
          path: 'homedashboard',
          name: 'HomeDashboard',
          component: HomeDashboard,
          beforeEnter: requireAuth(),
        },
      ]
    },
    {
      path: '/',
      redirect: 'sitedashboard',
      //redirect: '/pages/Login',
      name: 'Site Dashboard',
      component: TheContainer,
      children: [
        // {
        //   path: 'homedashboard',
        //   name: 'HomeDashboard',
        //   component: HomeDashboard,
        //   beforeEnter: requireAuth(),
        // },
        {
          path: 'sitedashboard',
          name: 'SiteDashboard',
          component: SiteDashboard,
          beforeEnter: requireAuth(),
          //beforeEnter: onBeforeEnter
        },
        {
          path: 'dashboard',
          redirect: '/dashboard/drillingdashboard',
          name: 'Dashboard',
          component: {
            render (c) { return c('router-view') }
          },
          children: [
            {
              path: 'drillingdashboard',
              name: 'DrillingDashboard',
              component: DrillingDashboard,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            {
              path: 'chargingdashboard',
              name: 'ChargingDashboard',
              component: ChargingDashboard,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            {
              path: 'addashboard',
              name: 'ADDashboard',
              component: ADDashboard,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            {
              path: 'vibrationdashboard',
              name: 'VibrationDashboard',
              component: VibrationDashboard,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            {
              path: 'monitoringdashboard',
              name: 'MonitoringDashboard',
              component: MonitoringDashboard,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
          ]
        },
        //----------------------------------------------------//
        {
          path: 'admin',
          redirect: '/admin/siteinformation',
          name: 'admin',
          component: {
            render (c) { return c('router-view') }
          },
          children: [
            {
              path: 'siteinformation',
              name: 'SiteInformation',
              component: SiteInformation,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            {
              path: 'systemsetting',
              name: 'systemsetting',
              component: SystemSetting,
              beforeEnter: requireAuth(),
              //beforeEnter: onBeforeEnter
            },
            // {
            //   path: 'siteCompany',
            //   name: 'SiteCompany',
            //   component: SiteCompany,
            //   beforeEnter: requireAuth(),
            //   //beforeEnter: onBeforeEnter
            // },
            // {
            //   path: 'site',
            //   name: 'Site',
            //   component: Site,
            //   beforeEnter: requireAuth(),
            //   //beforeEnter: onBeforeEnter
            // },
            // {
            //   path: 'siteMap',
            //   name: 'SiteMap',
            //   component: SiteMap,
            //   beforeEnter: requireAuth(),
            //   //beforeEnter: onBeforeEnter
            // },
          ]
        },
        // {
        //   path: 'admin',
        //   redirect: '/admin/systemsetting',
        //   name: 'admin',
        //   component: {
        //     render (c) { return c('router-view') }
        //   },
        //   children: [
        //     {
        //       path: 'systemsetting',
        //       name: 'systemsetting',
        //       component: SystemSetting,
        //       beforeEnter: requireAuth(),
        //       //beforeEnter: onBeforeEnter
        //     },
        //     // {
        //     //   path: 'code-management-1depth',
        //     //   name: 'codeManagement1Depth',
        //     //   component: CodeManagement1depth,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'code-management-2depth',
        //     //   name: 'codeManagement2Depth',
        //     //   component: CodeManagement2depth,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'menu-management-1depth',
        //     //   name: 'menuManagement1depth',
        //     //   component: MenuManagement1depth,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'menu-management-2depth',
        //     //   name: 'menuManagement2depth',
        //     //   component: MenuManagement2depth,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'code-management-authority',
        //     //   // name: 'codeManagementAuthority',
        //     //   name: 'authorityType',
        //     //   component: CodeManagementAuthority,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'menu-authority',
        //     //   name: 'authorityMenuSetting',
        //     //   // name: 'menuAuthority',
        //     //   component: MenuAuthority,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'user-management',
        //     //   name: 'userManagement',
        //     //   component: UserManagement,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'language-management',
        //     //   name: 'languageManagement',
        //     //   component: LanguageManagement,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //     // {
        //     //   path: 'user-log-management',
        //     //   name: 'userLogManagement',
        //     //   component: UserLogManagement,
        //     //   beforeEnter: requireAuth(),
        //     // },
        //   ]
        // },
        //------------------------------------------------------//
        //----------------------------------------------------//
        {
          path: 'BlastLibrary',
          redirect: '/blastLibrary/blastSummary',
          name: 'blastLibrary',
          component: {
            render (c) { return c('router-view') }
          },
          children: [
            {
              path: 'blastSummary',
              name: 'BlastSummary',
              component: BlastSummary,
              beforeEnter: requireAuth(),
            },
            {
              path: 'summaryReport',
              name: 'SummaryReport',
              component: SummaryReport,
              beforeEnter: requireAuth(),
            },
            {
              path: 'drilling',
              name: 'Drilling',
              component: DrillingManagement,
              beforeEnter: requireAuth(),
            },
            {
              path: 'charging',
              name: 'Charging',
              component: ChargingManagement,
              beforeEnter: requireAuth(),
            },
            {
              path: 'firing',
              name: 'Firing',
              component: FiringManagement,
              beforeEnter: requireAuth(),
            },
            {
              path: 'fragmentation',
              name: 'Fragmentation',
              component: FragmentationManagement,
              beforeEnter: requireAuth(),
            },
            {
              path: 'vibrationSound',
              name: 'VibrationSound',
              component: VibrationSoundManagement,
              beforeEnter: requireAuth(),
            },
            {
              path: 'productivityCost',
              name: 'ProductivityCost',
              component: ProductivityCostManagement,
              beforeEnter: requireAuth(),
            },
          ]
        },
        //------------------------------------------------------//
        //----------------------------------------------------//
        {
          path: 'Analytics',
          redirect: '/analytics/analyticsSummary',
          name: 'analytics',
          component: {
            render (c) { return c('router-view') }
          },
          children: [
            {
              path: 'analyticsSummary',
              name: 'analyticsSummary',
              component: analyticsSummary
            },
            {
              path: 'analyticsDrilling',
              name: 'analyticsDrilling',
              component: analyticsDrilling,
              beforeEnter: requireAuth(),
            },
            {
              path: 'analyticsCharging',
              name: 'analyticsCharging',
              component: analyticsCharging,
              beforeEnter: requireAuth(),
            },
            {
              path: 'analyticsCost',
              name: 'analyticsCost',
              component: analyticsCost,
              beforeEnter: requireAuth(),
            },
            {
              path: 'analyticsFragmentation',
              name: 'analyticsFragmentation',
              component: analyticsFragmentation,
              beforeEnter: requireAuth(),
            },
            {
              path: 'analyticsVibration',
              name: 'analyticsVibration',
              component: analyticsVibration,
              beforeEnter: requireAuth(),
            },
            {
              path: 'analyticsFleet',
              name: 'analyticsFleet',
              component: analyticsFleet,
              beforeEnter: requireAuth(),
            },
          ]
        },
        //------------------------------------------------------//
        {
          path: 'icons',
          redirect: '/icons/font-awesome',
          name: 'Icons',
          component: {
            render (c) { return c('router-view') }
          },
          children: [
            {
              path: 'coreui-icons',
              name: 'CoreUI Icons',
              component: CoreUIIcons
            },
            {
              path: 'flags',
              name: 'Flags',
              component: Flags
            },
            {
              path: 'brands',
              name: 'Brands',
              component: Brands
            }
          ]
        },
        {
          path: 'AmChartSample',
          name: 'AmChartSample',
          component: AmChartSample
        },
      ]
    },
    {path:'*', component: Page404},
    {
      path: '/user',
      redirect: '/user/404',
      name: 'Pages',
      component: {
        render (c) { return c('router-view') }
      },
      children: [
        {
          path: '404',
          name: 'Page404',
          component: Page404
        },
        {
          path: '500',
          name: 'Page500',
          component: Page500
        },
        {
          path: 'login',
          name: 'Login',
          component: Login
        }
      ]
    }
  ]
})
