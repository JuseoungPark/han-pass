<template>
    <svgicon
        :class="{
        [$options.name]: true,
        [`${$options.name}--${size}`]: size,
        }"
        :name="name"
        :color="color">
    </svgicon>
</template>

<script>
export default {
    name: `AppIcon`,
    props: {
        name: {
            type: String,
            required: true,
        },
        size: {
            type: String,
        },
        color: {
            type: String,
        },
    },
    created() {
        // The `[request]` placeholder is replaced
        // by the filename of the file which is
        // loaded (e.g. `AppIcon-music.js`).
        import(/* webpackChunkName: "AppIcon-[request]" */ `./icons/${this.name}`);
    },
};
</script>

<style>
.AppIcon {
    display: inline-block;
    height: 1em;
    color: inherit;
    vertical-align: middle;
    fill: none;
    stroke: currentColor;
}
.AppIcon.color-hold{
    color:#fff;
}
.AppIcon.dark-white{
    /* color: rgba(0, 0, 21, 0.5); */
    color: #999;
}
.AppIcon--fill {
    fill: currentColor;
    stroke: none;
}
.AppIcon--sss {
    min-width: 1rem;
    height: 0.35rem;
}
.AppIcon--s {
    min-width: 1rem;
    height: 0.9rem;
}
.AppIcon--sm {
    min-width: 1rem;
    height: 1.1rem;
}
.AppIcon--m {
    height: 1.3rem;
}
.AppIcon--l {
    height: 1.8rem;
}
.AppIcon--xl {
    min-width:2.625rem;
    height: 2.6rem;
}

.c-dark-theme .AppIcon.dark-white{
        color:#fff;
    }

</style>
