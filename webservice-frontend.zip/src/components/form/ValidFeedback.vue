<template>
  <div class="invalid-feedback">
    <template v-for="key in keys.slice(0, 1)">
      <div :key="key" v-if="!param[key] && key === 'minLength'">
        {{$t('validation.minLength', [param.$params.minLength.min])}}
      </div>
      <div :key="key" v-else-if="!param[key] && key === 'maxLength'">
        {{$t('validation.maxLength', [param.$params.maxLength.max])}}
      </div>
      <div :key="key" v-else-if="!param[key] && key === 'decimalLimit'">
        {{$t('validation.decimalLimit', [param.$params.decimalLimit.limit])}}
      </div>
      <div :key="key" v-else-if="!param[key] && key === 'between'">
        {{$t('validation.between', [param.$params.between.min, param.$params.between.max])}}
      </div>
      <div :key="key" v-else-if="!param[key] && key === 'byte'">
        {{$t('validation.byte', [param.$params.byte.limit])}}
      </div>
      <div :key="key" v-else-if="!param[key]">
        {{$t(`validation.${key}`)}}
      </div>
    </template>
  </div>
</template>

<script>
export default {
  name: `ValidFeedback`,
  props: {
    param: {
      type: Object,
      required: true
    }
  },
  computed: {
    keys () {
      return Object.keys(this.param).filter(item => {
        return !item.startsWith('$') && this.param[item] === false
      })
    }
  }
}
</script>