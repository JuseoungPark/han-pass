<template>
  <CModal
    :show="true"
    :no-close-on-backdrop="true"
    :centered="true"
    title="Modal title 2"
    size="lg"
    color="dark">
    <CCardBody class="pop-data-table">
      <CAlert show color="dark" style="margin-bottom:0">
        {{model}}
        <hr />
        <CRow>
          <CCol col="12" sm="6" lg="5">
            <label for="file" style="cursor: pointer;">
              <CWidgetIcon
                header="Excel"
                text=".xlsx 확장자를 선택해 주세요"
                color="gradient-info"
                style="margin-bottom:0">
                <CIcon name="cil-cloud-upload" width="24" />
                <input type="file" name="file" id="file" accept=".xlsx" v-on:change="processFile($event)" class="file-input" />
              </CWidgetIcon>
            </label>
          </CCol>
          <CCol col="12" sm="6" lg="5">
            <json-down name="Sample"
              :rowNum="false"
              v-bind:data="sampleData"
              v-bind:cols="sampleFields">
              <label for="sample" style="cursor: pointer;">
                <CWidgetIcon
                  header="Sample"
                  text="샘플형식을 지켜주세요."
                  color="gradient-warning"
                  style="margin-bottom:0">
                  <CIcon name="cil-cloud-download" width="24" />
                </CWidgetIcon>
              </label>
            </json-down>
          </CCol>
        </CRow>
      </CAlert>
    </CCardBody>
    <template #header>
      <h5 class="modal-title">Excel Upload</h5>
      <CButtonClose @click="$emit('is-close')" class="text-white" />
    </template>
    <template #footer>
      <CButton @click="$emit('is-close')" class="btn-custom-default outline rectangle">{{$t('commonLabel.cancel')}}</CButton>
      <CButton @click="edit" class="btn-custom-default hanwha outline rectangle">{{$t('commonLabel.submit')}}</CButton>
    </template>
  </CModal>
</template>

<script>
import XLSX from 'xlsx'
import JsonDown from '@/components/form/JsonDown'
import utils from '@/assets/js/utils'

export default {
  name: `ExcelUpload`,
  props: {
    param: {
      type: Object,
      default: {
        keys: {}
      }
    }
  },
  components: {
    JsonDown
  },
  data () {
    return {
      model: null
    }
  },
  computed: {
    sampleFields () {
      return Object.keys(this.param.keys).map(item => {
        return {
          key: this.param.keys[item], label: item
        }
      })
    },
    sampleData () {
      if (this.param.sampleData && this.param.sampleData.length) {
        return this.param.sampleData
      } else {
        let obj = {}
        Object.keys(this.param.keys).map(item => {
          obj[this.param.keys[item]] = ''
        })
        return [obj]
      }
    }
  },
  methods: {
    processFile (event) {
      this.model = null
      const file = event.target.files[0]
      if (file) {
        let fileExt = file.name.substring(file.name.lastIndexOf('.'))
        if ('.xlsx'.indexOf(fileExt) < 0) {
          utils.showToast('확장자를 확인해 주세요.')
          return
        }

        const reader = new FileReader()
        reader.onload = e => {
          /* Parse data */
          const bstr = e.target.result
          const wb = XLSX.read(bstr, { type: 'array' })
          /* Get first worksheet */
          const wsname = wb.SheetNames[0]
          const ws = wb.Sheets[wsname]

          // 헤더 바꾸기
          var range = XLSX.utils.decode_range(ws['!ref'])
          for (var C = range.s.c; C <= range.e.c; ++C) {
            var col = XLSX.utils.encode_col(C) + '1'
            if (!ws[col]) continue
            console.log(ws[col])
            ws[col].v = this.param.keys[ws[col].v]
            ws[col].h = this.param.keys[ws[col].h]
            ws[col].w = this.param.keys[ws[col].w]
          }

          /* Convert array of arrays */
          const data = XLSX.utils.sheet_to_json(ws, { skipHeader: true, defval: '' })
          
          this.model = data
          //this.cols = make_cols(ws['!ref'])
        }
        //reader.readAsText(file, 'euc-kr')
        reader.readAsArrayBuffer(file)
      } else {
        //
      }
    },
    edit () {

    }
  }
}
</script>