<template>
  <CSwitch
    :id="id"
    class="mx-1 switch-custom"
    color="warning"
    variant="opposite"
    shape="pill"
    :checked.sync="checked"
    @update:checked="checkFlag" />
    <!-- v-bind="useYnLabel" -->
</template>

<script>
export default {
  name: `CSwitchYN`,
  props: {
    id: {
      type: String,
      default() {
        return 'useYn'
      }
    },
    value: {
      type: String,
      default() {
        return ''
      }
    }
  },
  data() {
    return {
      checked: (this.value === 'Y'),
      // useYnLabel: {
      //   labelOn: 'yes',
      //   labelOff: 'no'
      // }
    }
  },
  watch: {
    value(val) {
      this.checked = (val === 'Y')
    }
  },
  methods: {
    checkFlag () {
      this.$emit('update:value', (this.checked ? 'Y' : 'N'))
    }
  }
}
</script>