<template>
  <div v-if="tabs.length">
    <div>
      <ul class="nav" :class="tc">
        <li v-for="tab in tabs"
          class="nav-item"
          :key="tab[tabOption.key]">
          <a href="javascript:;" target="_self" class="nav-link"
            :class="{'active': tab[tabOption.key] === activeTab}"
            @click="updateTab(tab)">
            {{tab[tabOption.label]}}
          </a>
        </li>
      </ul>
    </div>
    <div>
      <div class="tab-content">
        <div class="tab-pane active">
          <slot :item="activeTab"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: `CTabLayer`,
  props: {
    activeTab: {
      type: [String, Number]
    },
    tabs: {
      type: Array,
      default () {
        return []
      }
    },
    tabClass: {
      type: String,
      default() {
        return 'tabs'
      }
    },
    tabOption: {
      type: Object,
      default () {
        return {
          key: 'key',
          label: 'label'
        }
      }
    }
  },
  data() {
    return { }
  },
  computed: {
    tc () {
      return `nav-${this.tabClass}`
    }
  },
  methods: {
    updateTab (item) {
      if (this.activeTab !== item[this.tabOption.key]) {
        this.$emit('update:activeTab', item[this.tabOption.key])
        this.$emit('updateTab', item)
      }
    }
  }
}
</script>