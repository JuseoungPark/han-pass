<template>
  <CElementCover v-bind:style="coverStyle">
    <slot>
      <div class="spinner-wrap">
        <div class="sk-wave">
          <div class="sk-wave-rect"></div>
          <div class="sk-wave-rect"></div>
          <div class="sk-wave-rect"></div>
          <div class="sk-wave-rect"></div>
          <div class="sk-wave-rect"></div>
        </div>
      </div>
    </slot>
  </CElementCover>
</template>

<script>
export default {
  name: `CThemaCover`,
  props: {
    customeStyle: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return { 
    }
  },
  computed: {
    coverStyle () {
      return Object.assign({
        opacity: 0.5,
        'z-index': 9999,
        'background-color': (this.$store.state.uxui.darkMode) ? 'rgba(0, 0, 0, 0.5)': 'rgba(255, 255, 255, 0.5)'
      }, this.customeStyle)
    }
  }
}
</script>