<template>
  <!--
    DB Date 형태 픽스 후 조정 필요할수도 있음.
    케이스별 기능은 필요시 추가.
    유효성체크 필요할 경우 validForm 아닌 경우 dateForm
    -->
  <div :class="validClass">
    <date-picker class="date-picker" :class="datepickerClass"
      :lang="{
        formatLocale: {
          firstDayOfWeek: 1,
        }
      }"
      :show-week-number="false"
      :range="range"
      :clearable="clearable"
      :editable="editable"
      :type="type"
      :input-attr="{id: id}"
      :valueType="valueType"
      :format="format"
      :placeholder="placeholder"
      :disabled-date="disabledDate"
      v-model.trim="dateValue"
      @change="customChange">
      <template slot="icon-calendar" v-if="isValid && validForm.$dirty">
        <p style="display:none;"></p>
      </template>
      <template slot="icon-clear" v-if="isValid && validForm.$dirty">
        <p style="display:none;"></p>
      </template>
    </date-picker>
    <div v-if="isFeedback" class="invalid-feedback" style="display: block;">
      <div>{{$t('validation.required')}}</div>
    </div>
  </div>
</template>

<script>
import DatePicker from 'vue2-datepicker'
import 'vue2-datepicker/index.css'

export default {
  name: `CDatePicker`,
  props: {
    validForm: {
      type: Object
    },
    dateForm: {
      type: [String, Array, Date]
    },
    id: {
      type: String,
      default () {
        return 'datepicker'
      }
    },
    datepickerClass: {
      type: String,
      default () {
        return 'w-100'
      }
    },
    range: {
      type: Boolean,
      default () {
        return false
      }
    },
    type: {
      type: String,
      default () {
        return 'date'
      }
    },
    valueType: {
      type: String,
      default () {
        return 'format'
      }
    },
    format: {
      type: String,
      default () {
        return 'YYYY-MM-DD'
      }
    },
    placeholder: {
      type: String
    },
    clearable: {
      type: Boolean,
      default () {
        return true
      }
    },
    editable: {
      type: Boolean,
      default () {
        return true
      }
    },
    minDate: {
      type: String,
      default () {
        return ''
      }
    },
    maxDate: {
      type: String,
      default () {
        return ''
      }
    },
    minDatetime: {
      type: String,
      default () {
        return ''
      }
    },
    maxDatetime: {
      type: String,
      default () {
        return ''
      }
    }
  },
  components: {
    DatePicker
  },
  date () {
    return {
    }
  },
  computed: {
    dateValue: {
      get() {
        if (typeof this.validForm !== 'undefined') {
          return this.validForm.$model
        } else if (typeof this.dateForm !== 'undefined') {
          return this.dateForm
        }
      },
      set(val) {
        if (typeof this.validForm !== 'undefined') {
          this.validForm = Object.assign(this.validForm, {
            $model: val
          })
        } else if (typeof this.dateForm !== 'undefined') {
          this.$emit('update:dateForm', val)
        }
      }
    },
    isValid () {
      if (typeof this.validForm !== 'undefined') {
        return Object.keys(this.validForm.$params).length > 0
      } else if (typeof this.dateForm !== 'undefined') {
        return false
      }
    },
    validClass () {
      if (typeof this.validForm !== 'undefined') {
        return !this.isValid ? '' : this.validForm.$dirty ? (this.validForm.$error ? 'invalid' : 'valid') : ''
      } else if (typeof this.dateForm !== 'undefined') {
        return ''
      }
    },
    isFeedback () {
      if (typeof this.validForm !== 'undefined') {
        return (this.isValid) ? (this.validForm.$dirty ? this.validForm.$error : null) : false 
      } else if (typeof this.dateForm !== 'undefined') {
        return false
      }
    }
  },
  methods: {
    customChange (date, type) {
      if (type === 'week') {
        this.dateValue = [
          this.$moment(date[0]).startOf('isoweek').format('YYYY-MM-DD'),
          this.$moment(date[1]).startOf('week').add((this.$moment(date[1]).day() === 0) ? 0 : 7, 'day').format('YYYY-MM-DD')
        ]
      } else if (type === 'month') {
        this.dateValue = [
          this.$moment(date[0]).startOf('month').format('YYYY-MM-DD'),
          this.$moment(date[1]).endOf('month').format('YYYY-MM-DD')
        ]
      }
    },
    disabledDate (date) {
      if (this.minDate === '' && this.maxDate === '') {
        return false
      } else {
        let min, max = undefined
        if (this.minDate !== '' && this.maxDate === '') {
          min = this.$moment(this.minDate).startOf('day')
          return this.$moment(date).isBefore(min)
        }
        else if (this.maxDate !== '' && this.minDate === '') {
          max = this.$moment(this.maxDate).endOf('day')
          return this.$moment(date).isAfter(max)
        } else {
          min = this.$moment(this.minDate).startOf('day')
          max = this.$moment(this.maxDate).endOf('day')
          return !this.$moment(date).isBetween(min, max, undefined, '[]')
        }
      }
      return false
    }
  }
}
</script>
<style>
  .invalid .date-picker input {
    border-color: #e55353!important;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23e55353' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23e55353' stroke='none'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
    background-position: right calc(0.375em + 0.1875rem) center;
  }
  .valid .date-picker input {
    border-color: #2eb85c!important;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath fill='%232eb85c' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
    background-position: right calc(0.375em + 0.1875rem) center;
  }
</style>