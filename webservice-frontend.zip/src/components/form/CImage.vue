<template>
  <img ref="photo" class="image data-image" :src="src" @error="error" />
</template>

<script>
import { mapActions } from 'vuex'
const common = 'common'

export default {
  name: 'CImage',
  props: {
    siteId: {
      type: Number,
      required: true
    },
    fileId: {
      type: Number,
      default () {
        return null
      }
    },
    fileType: {
      type: String,
      default () {
        return ''
      }
    }
  },
  data() {
    return {
      src: '',
      defaultPath: 'img/no-image.jpg'
    }
  },
  watch: {
    fileId: {
      immediate: true,
      async handler(id) {
        if (id) {
          await this.createImage()
        }
      }
    }
  },
  methods: {
    ...mapActions(common, {
      imageUrlAction: 'imageUrl'
    }),
    async createImage () {
      if ((this.fileId || '') !== '') {
        const res = await this.imageUrlAction({
          moduleName : `v1/files/${this.siteId}/${this.fileType}/download/${this.fileId}`
        })
        this.$refs.photo.src = res
      }
    },
    error () {
      this.$refs.photo.src = this.defaultPath
    }
  }
}
</script>