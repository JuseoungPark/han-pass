<template>
  <span v-on:click="generate">
    <slot>
      Excel Import
    </slot>
  </span>
</template>

<script>
import XLSX from 'xlsx'
import download from 'downloadjs'
import utils from '@/assets/js/utils'

export default {
  name: `JsonDown`,
  props: {
    type: {
      type: String,
      default: 'xlsx'
    },
    data: {
      type: Array,
      required: true
    },
    cols: {
      type: Array,
      required: true
    },
    name: {
      type: String
    },
    isSkipHeader: {
      type: Boolean,
      default: false
    },
    rowNum: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    downloadData() {
      if (this.data !== undefined) return this.data.slice(0)
    },
    downloadCols() {
      return this.cols.slice(0).filter(item => {
        return item.key !== 'select' && item.key !== 'expand'
      })
    }
  },
  methods: {
    generate() {
      if (!this.downloadData.length) {
        utils.showToast(this.$t('message.noData'))
        return
      }

      const datas = this.getProcessedJson(this.downloadData, this.downloadCols)
      const wscols = []
      if (this.rowNum) {
        wscols.push({
          wpx: 50
        })
      }
      this.downloadCols.map(item => {
        let w = datas.wscols[item.key]
        if (item.label.length > w) {
          w = item.label.length
        }
        wscols.push({
          wch: w + 5
        })
      })
      
      var ws = XLSX.utils.json_to_sheet(datas.data, {
        skipHeader: this.isSkipHeader
      })
      ws['!cols'] = wscols

      var wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1')
      var wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' })
      download(
        new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }),
        `${this.name}.${this.type}`
      )
    },
    s2ab(s) {
      var buf = new ArrayBuffer(s.length)
      var view = new Uint8Array(buf)
      for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff
      return buf
    },
    getProcessedJson(data, cols) {
      let newData = {
        data: [],
        wscols: {}
      }

      data.map(item => {
        let newItem = {}

        if (this.rowNum) {
          newItem['No.'] = this.downloadData.length - data.indexOf(item)
        }

        cols.map(col => {
          if (typeof col.excelmode === 'undefined') {
            col.excelmode = {}
          }

          if (typeof col.excelmode.excel === 'undefined') {
            col.excelmode.excel = true
          }

          if (col.excelmode.excel) {
            let val = ''
            // 케이스 생기면 작업하지 뭐
            if (typeof col.excelmode.key !== 'undefined') {
              val = item[col.excelmode.key]
            } else if (typeof col.itemTemplate !== 'undefined') {
              if (typeof col.itemTemplate === 'function') {
                val = col.itemTemplate(col.key, item)
              }
            } else {
              val = item[col.key]
            }

            let excelLabel = col.excelmode.label || col.label
            if (typeof val === 'undefined' || val === null) {
              val = ''
            }
            newItem[excelLabel] = val + ''

            // width
            if (typeof newItem[excelLabel] !== 'undefined' && newItem[excelLabel] !== null) {
              if (newItem[excelLabel].length >= (newData.wscols[col.key] || 0)) {
                newData.wscols[col.key] = newItem[excelLabel].length
              }
            }
          }
        }, {})
        newData.data.push(newItem)
      })

      return newData
    }
  }
}
</script>