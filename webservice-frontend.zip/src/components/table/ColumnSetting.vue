<template>
  <CModal
    :show="true"
    :no-close-on-backdrop="true"
    :centered="true"
    title="Modal title 2"
    size="lg"
    color="dark">
    <CCardBody class="pop-data-table">
      <DataTable :items="items" :fields="fields"
        :loading="loading"
        :column-filter="false"
        :sorter="false"
        :tableFilter="false"
        :overTable="false"
        :isMultiSelect="true"
        :isNoItemClick="false">
        <template slot="order" slot-scope="props">
          <CButtonGroup @click.stop>
            <CButton color="custom" variant="outline" v-if="props.item.order !== items.length" @click="order(props.item, 1)">
              <!-- <CIcon name="cil-arrow-thick-bottom" class="mr-1" /> -->
              <app-icon name="arrowBt" size="s" fill class="arrow-bt"/>
            </CButton>
            <CButton color="custom" variant="outline" v-if="props.item.order !== 1" @click="order(props.item, -1)">
              <!-- <CIcon name="cil-arrow-thick-top" class="mr-1" /> -->
              <app-icon name="arrowT" size="s" fill class="arrow-t"/>
            </CButton>
          </CButtonGroup>
        </template>
      </DataTable>
    </CCardBody>
    <template #header>
      <h5 class="modal-title">칼럼설정</h5>
      <CButtonClose @click="$emit('is-close')" class="text-white" />
    </template>
    <template #footer>
      <CButton @click="edit" class="btn-custom-default hanwha outline rectangle">{{$t('commonLabel.submit')}}</CButton>
      <CButton @click="$emit('is-close')" class="btn-custom-default outline rectangle">{{$t('commonLabel.cancel')}}</CButton>
    </template>
  </CModal>
</template>

<script>
import DataTable from '@/components/table/DataTable'
import utils from '@/assets/js/utils'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)
export default {
  name: "ColumnSetting",
  components: {
    DataTable,
    AppIcon
  },
  props: {
    param: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      loading: false,
      fields: [
        {key:'column', label:'칼럼키'},
        {key:'columnName', label:'칼럼명'},
        {key:'order', label:'순서', isDrawing:true}
      ],
      items: []
    }
  },
  computed: {},
  async mounted() {
    this.loading = true
    this.init()
    this.loading = false
  },
  methods: {
    init () {
      let cols = this.param.column.slice(0)
      const storage = JSON.parse(localStorage.tableStrrings || null) || {},
      setting = storage[`${this.$route.name}/${this.param.key}`]
      if (setting) {
        if (setting.columns) {
          setting.columns.map(item => {
            item.label = cols.find(s => s.key === item.key).label || ''
          })
          cols = setting.columns
        }
      }
      cols.map((item, index) => {
        this.items.push({
          _selected: (item.visible !== undefined) ? item.visible : true,
          column: item.key,
          columnName: item.label,
          order: (item.order !== undefined) ? item.order : (index + 1)
        })
      })
    },
    order (item, i) {
      item.order = item.order + i
      this.items.find(s => s.order === item.order && s.column !== item.column).order = item.order + (-i)
      this.items.sort((a, b) => {
        if (a.order > b.order) {
        return 1
      }
      if (a.order < b.order) {
        return -1
      }
        return 0
      })
    },
    edit () {
      if (!this.items.some(s => s._selected === true)) {
        utils.showToast(this.$t('message.noSelectItem'))
        return
      }

      let fields = this.items.map(item => {
        return {
          visible: item._selected,
          key: item.column,
          order: item.order
        }
      })
      const storage = JSON.parse(localStorage.tableStrrings || null) || {}
      let obj = {}
      obj[`${this.$route.name}/${this.param.key}`] = {
        columns: fields
      }
      localStorage.tableStrrings = JSON.stringify(Object.assign(storage, obj))
      this.$emit('is-result', fields)
    }
  }
}
</script>
