<!--

 필요기능들은 지속적으로 업뎃 필요
 
 -->
<template>
  <CDataTable
    ref="datatable"
    :items="dataItems"
    :fields="cols"
    class="data-table"
    :addTableClasses="tableClass"
    hover bordered fixed
    :striped="striped"
    :dark="dark"
    :clickable-rows="clickableRows"
    :column-filter="columnFilter"
    :table-filter="tableFilter"
    :sorter="sorter"
    :loading="loading"
    :items-per-page="isPage ? pager.limit : items.length"
    :active-page="pager.activePage"
    :pagination="isPage"
    @row-clicked="rowClick">

    <template #thead-top>
      <slot name="theadTop" />
    </template>

    <!-- 추가 기능 -->
    <template #over-table v-if="overTable">
      <CDropdown
        :class="overTableClass"
        :style="overTableStyle"
        color="link dropdown-list-wrap"
        size="lg"
        :caret="false">
        <template #toggler-content>
          <CIcon name="cil-settings" size="xl" />
        </template>
        <slot name="firstOverTable" />
        <CDropdownItem v-if="overTableContents.includes('import')">
          <json-down :name="excelName"
            v-bind:data="currentItems"
            v-bind:cols="cols" />
        </CDropdownItem>
        <CDropdownItem v-if="overTableContents.includes('column')" @click="toggleComponent('ColumnSetting')">
          {{ $t('commonLabel.columnSetting') }}
        </CDropdownItem>
        <slot name="lastOverTable" />
      </CDropdown>
    </template>

    <!-- All Select Header -->
    <template #select-header v-if="isMultiSelect">
      <CInputCheckbox
        :checked.sync="isAll"
        @update:checked="updateAllSelect"
        custom />
    </template>

    <!-- auto Drawing -->
    <template v-for="field in cols" :slot="field.key" slot-scope="props">
      <!-- select -->
      <td :key="field.key" v-if="field.key === 'select'" @click.stop>
        <CInputCheckbox
          :checked.sync="props.item._selected"
          @update:checked="updateSelect(props.item)"
          custom />
      </td>

      <!-- Template -->
      <td :key="field.key" v-else-if="field.template">
        <!-- 
          YN Badge
          template: 'ynBadge'
        -->
        <CBadge v-if="field.template === 'ynBadge'"
          class="custom-badge ynBadge"
          :class="{yes : props.item[field.key] === 'Y', no : props.item[field.key] === 'N'}">
          {{props.item[field.key] === 'Y' ? 'YES' : 'NO'}}
        </CBadge>

        <!-- 
          Badge
          template: 'badge'
        -->
        <CBadge v-else-if="field.template === 'badge' && (props.item[field.key] || '') !== ''"
          class="custom-badge"
          color="dark">
          {{props.item[field.key]}}
        </CBadge>

        <!-- 
          Date
          template: 'date'
        -->
        <span v-else-if="field.template === 'date'">
          <!-- {{$moment(props.item[field.key]).format(field.dateFormat || 'YYYY-MM-DD')}} -->
          {{dateForamt(props.item[field.key], field.dateFormat)}}
        </span>
        <span v-else-if="field.template === 'decimal'">
          {{props.item[field.key] | setDecimal}}
        </span>
      </td>

        <!-- 
          Item Template
          itemTemplate: (key, item) => {
          return item.xxx.xxxxxx
        }
        
      <td :key="field.key" v-else-if="field.itemTemplate" v-text="field.itemTemplate(field.key, props.item)" />
      -->

      <!-- 
          Double click
          dblclick: (key, item) => {
          fn(item)
        }
        -->
      <td :key="field.key" v-else-if="field.dblclick"
        @click.stop
        @dblclick="field.dblclick(field.key, props.item)">
        {{props.item[field.key]}}
        <CIcon name="cil-external-link" class="mr-1" />
      </td>

      <!--
        self Drawing
        isDrawing:true
        -->
      <td :key="field.key" v-else-if="field.isDrawing === true">
        <slot :name="field.key" :item="props.item" />
      </td>

      <!-- 
          expand
          expand:true(field level)
          isExpand: true(table level)
        -->
      <td :key="field.key" v-else-if="field.expand === true" @click.stop>
        {{props.item[field.key]}}
        <CButton
          class="btn-dropdown"
          variant="outline"
          square
          size="sm"
          @click="toggleExpand(props.item)">
          <CIcon :name="`cil-expand-${props.item._expand ? 'up' : 'down'}`" style="cursor: pointer;" />
        </CButton>
      </td>

      <!-- Normal -->
      <td :key="field.key" v-else>
        {{props.item[field.key]}}
      </td>
    </template>

    <!-- detail -->
    <template #details="{item}" v-if="isExpandCols">
      <CCollapse :show="Boolean(item._expand)" :duration="400">
        <slot name="expandLayer" :item="item" />
      </CCollapse>
    </template>

    <!-- no data -->
    <template slot="no-items-view">
      <div v-if="isNoItemClick" class="text-center my-5" @click="rowClick(null)">
        <h3>{{$t('message.noData')}}</h3>
      </div>
      <div v-else class="text-center my-5">
        <h3>{{$t('message.noData')}}</h3>
      </div>
    </template>

    <template #under-table>
      <component v-bind:is="editMode"
        :param="componentParam"
        @is-close="toggleComponent"
        @is-result="componentEvent" />
    </template>
  </CDataTable>
</template>

<script>
import JsonDown from '@/components/form/JsonDown'
import utils from '@/assets/js/utils'
export default {
  name: `DataTable`,
  props: {
    items: {
      type: Array,
      default () {
        return []
      }
    },
    fields: {
      type: Array,
      default () {
        return []
      }
    },
    tableClass: {
      type: String,
      default () {
        return ''
      }
    },
    isPage: {
      type: Boolean,
      default () {
        return false
      }
    },
    pager: {
      type: Object,
      default () {
        return {
          activePage: 1,
          limit: 5
        }
      }
    },
    loading: {
      type: Boolean,
      default () {
        return false
      }
    },
    dark: {
      type: Boolean,
      default () {
        return false
      }
    },
    striped: {
      type: Boolean,
      default () {
        return true
      }
    },
    isNoItemClick: {
      type: Boolean,
      default () {
        return true
      }
    },
    isSelect: {
      type: Boolean,
      default () {
        return false
      }
    },
    isMultiSelect: {
      type: Boolean,
      default () {
        return false
      }
    },
    isExpand: {
      type: Boolean,
      default () {
        return false
      }
    },
    columnFilter: {
      default () {
        return { external: false, lazy: true }
      }
    },
    sorter: {
      default () {
        return { external: false, resetable: true }
      }
    },
    tableFilter: {
      default () {
        return { external: false, lazy: true }
      }
    },
    clickableRows: {
      type: Boolean,
      default () {
        return true
      }
    },
    overTable: {
      type: Boolean,
      default () {
        return false
      }
    },
    overTableContents: {
      type: Array,
      default () {
        // 스토리보드 사양과 맞추기 위해 기능 제거
        // return ['column', 'import']
        return []
      }
    },
    overTableClass: {
      type: String,
      default () {
        return 'position-top-right btn-modal'
      }
    },
    overTableStyle: {
      type: Object,
      default () {
        return null
      }
    },
    tableSettingKey: {
      type: String,
      default () {
        return ''
      }
    },
    excelName: {
      type: String,
      default () {
        return 'List'
      }
    }
  },
  components: {
    JsonDown,
    ColumnSetting: () => import('./ColumnSetting')
  },
  data() {
    return {
      isAll: false,
      subComponent: '',
      componentParam: {},
      tableStrrings: null
    }
  },
  computed: {
    dataItems () {
      let d = [...this.items]
      d.forEach((item) => {
        this.fields.forEach(k => {
          if(k.itemTemplate) item[k.key] = k.itemTemplate(k.key, item)
        })
      })
      return d
    },
    cols () {
      let handlerCols = this.fields.slice(0)
      if (this.isSelect || this.isMultiSelect) {
        handlerCols.unshift({
          key: 'select',
          label: '',
          _style: 'width:1%',
          sorter: false,
          filter: false
        })
      }
      if (this.isExpand) {
        handlerCols.push({
          key: 'expand',
          label: '',
          _style: 'width:1%',
          sorter: false,
          filter: false,
          expand: true
        })
      }

      if ((this.tableStrrings || {}).columns) {
        handlerCols.map(item => {
          if (['select', 'expand'].includes(item.key)) {
            item.visible = true
            item.order = (item.key === 'select') ? 1 : handlerCols.length
          } else {
            let set = this.tableStrrings.columns.find(s => s.key === item.key)
            item.visible = (set) ? set.visible : true
            item.order = (set) ? set.order : 1
          }
        })

        handlerCols.sort((a, b) => {
          if (a.order > b.order) {
            return 1
          }
          if (a.order < b.order) {
            return -1
          }
          return 0
        })
      }
      
      return handlerCols.filter(item => {
        return ((typeof item.visible === 'undefined') ? true : item.visible) === true
      })
    },
    isExpandCols () {
      return this.cols.find(s => s.expand === true)
    },
    editMode() {
      return this.subComponent
    },
    isDynamicColumn () {
      return this.overTable && this.overTableContents.includes('column')
    },
    currentItems () {
      if (this.$refs.datatable) {
        return this.$refs.datatable.sortedItems
      } else {
        return this.items
      }
    }
  },
  async mounted() {
    this.dynamicColumnSetting()
  },
  methods: {
    rowClick (item) {
      if (this.isSelect || this.isMultiSelect) {
        this.$set(item, '_selected', !item._selected)
      } else {
        if (this.clickableRows && item) {
          this.items.map(data => {
            this.$delete(data, '_classes')
          })
          this.$set(item, '_classes', 'selected')
        }
      }
      this.$emit('rowClick', item)
    },
    updateSelect (item) {
      this.$emit('rowClick', item)
    },
    updateAllSelect () {
      this.currentItems.map(item => {
        this.$set(item, '_selected', this.isAll)
      })
    },
    toggleExpand (item) {
      this.$set(item, '_expand', !item._expand)
    },
    toggleComponent(type) {
      this.subComponent = ''
      if ((type || '') !== '') {
        this.componentParam = {
          column: this.fields.slice(0).filter(item => {
            return item.key !== 'select' && item.key !== 'expand'
          }),
          key: this.tableSettingKey
        }
        this.$nextTick(() => {
          this.subComponent = type
        })
      }
    },
    componentEvent () {
      this.dynamicColumnSetting()
      this.toggleComponent('')
    },
    dynamicColumnSetting () {
      if (this.isDynamicColumn) {
        const storage = JSON.parse(localStorage.tableStrrings || null) || {},
        setting = storage[`${this.$route.name}/${this.tableSettingKey}`]
        if (setting) {
          this.tableStrrings = setting
        }
      }
    },
    dateForamt (val, format = 'YYYY-MM-DD') {
      return this.$moment.utc(val).format(format)
    }
  }
}
</script>