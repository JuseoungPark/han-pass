/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'holeTotal': {
    width: 10,
    height: 16,
    viewBox: '0 0 10 16',
    data: '<path pid="0" data-name="ic_hole total" d="M8 0a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1zm0 5a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1zM2 0a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1zm0 5a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1zm6 5a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1zm-6-1a2 2 0 11-2 2 2 2 0 012-2zm0 1a1 1 0 11-1 1 1 1 0 011-1z" _fill="#fff" fill-rule="evenodd" opacity=".6"/>'
  }
})
