/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'avg': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Avg (mm)" d="M29 32H0V0h2v4h3v1H2v12h3v1H2v12h12v-3h1v3h13v-3h1v3h3v2h-3zm-2-22a5 5 0 115-5 5 5 0 01-5 5zM16 20a4 4 0 114-4 4 4 0 01-4 4zm-8.5 7a2.5 2.5 0 112.5-2.5A2.5 2.5 0 017.5 27z" _fill="#333" fill-rule="evenodd"/>'
  }
})
