/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'arrowTop': {
    width: 7,
    height: 4,
    viewBox: '0 0 7 4',
    data: '<path pid="0" data-name="v copy" d="M3.5 0L7 4H0z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
