/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'mine': {
    width: 14,
    height: 14,
    viewBox: '0 0 14 14',
    data: '<path pid="0" d="M9 14H4l-4-3V5l6-5h2l6 5v6zm-3-1h3V7H6v6zm-5-3l4 3V7H1v3zm0-4h7L6 2zm6-5l3 5h3zm6 6h-3v5l3-2V7z" _fill="#d1d1d1" fill-rule="evenodd"/>'
  }
})
