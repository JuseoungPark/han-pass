/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'arrowR': {
    width: 3.56,
    height: 5.688,
    viewBox: '0 0 3.56 5.688',
    data: '<path pid="0" d="M.72 5.672l-.71-.707 2.12-2.121L.01.723.72.016l2.83 2.828z" _fill="#999" fill-rule="evenodd"/>'
  }
})
