/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'lineChart': {
    width: 18,
    height: 17,
    viewBox: '0 0 18 17',
    data: '<path pid="0" d="M18 16v1H0V0h1v16h17zm-.916-6.767L18 13.811l-4.577-.931 1.309-1.3-1.625-1.627 1.077-1.074 1.629 1.624zM5.267 6.726l-2.5-2.471 1.076-1.082 2.516 2.479zM18 1.784l-4.577.932 1.309 1.3-4.082 4.088-2.289-2.291-5.6 5.525 1.076 1.082 4.518-4.451 2.282 2.283 5.173-5.159 1.272 1.266z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
