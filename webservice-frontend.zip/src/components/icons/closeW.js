/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'closeW': {
    width: 50,
    height: 50,
    viewBox: '0 0 50 50',
    data: '<image data-name="레이어 1" width="50" height="50" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABIUlEQVRogd2a6w3DIAyEoRN0pUzKSO0o3cAVFVFIlaaYly/nv7HwfREh5sDlISJBRB4icnegEbUljeFQYYJYAxImg1gjfCfkEJAwBxB7mB8QUDAnEBvMnwRzmAKIj8biRAsYtTZEmGpNSDDNWhBgummwhOle2wJmWM2ZMMNrzYCZ9sJGFpo+hUcUNFtUehY2X+Z7CID58bYIgWuFagTBNqcaYcgdthYGes+jgcGGWKMBBs/kqIDBtZ0UMN0hbj0HowiKqUXxsVMsvxQ/RIoWhaJppGjjKTZWFFtdCvOBwg6iMOgoLFMKE5viWIHioIfi6I3iMBTZPFNpQzfPSmGi+fA8GSc+W7z3r4nad5FqLwU6SS7VZInXv+aUJV7z4plz7g0Nh7pUGLFSugAAAABJRU5ErkJggg=="/>'
  }
})
