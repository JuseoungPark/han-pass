/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'arrowT': {
    width: 9.88,
    height: 13.44,
    viewBox: '0 0 9.88 13.44',
    data: '<path pid="0" data-name="사각형 1203 복사 2" d="M3.53 1.4l.91-.91V.44h.05l.45-.45.45.45h.05v.05l.31.31.6.6 3.54 3.54-1.41 1.41-3.04-3.03v10.12h-1V3.32L1.4 6.35-.01 4.94z" _fill="#b2b2b2" fill-rule="evenodd"/>'
  }
})
