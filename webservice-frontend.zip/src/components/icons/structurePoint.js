/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'structurePoint': {
    width: 20.25,
    height: 24.35,
    viewBox: '0 0 20.25 24.35',
    data: '<path pid="0" d="M10.12 24.34C4.42 19.35-.01 15.54-.01 9.96a10.137 10.137 0 0120.27 0c0 5.58-4.44 9.39-10.14 14.38zm-3.96-6.22a8.855 8.855 0 008-.03V8.22l-4-2-4 2v9.9zm3.97-16.89a8.915 8.915 0 00-4.97 16.32V7.22l4.91-2 5.09 2V17.5a8.914 8.914 0 00-5.03-16.27zM8.16 13.22h1v2h-1v-2zm0-3h1v2h-1v-2zm4 2h-1v-2h1v2zm0 3h-1v-2h1v2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
