/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'drillPoint': {
    width: 20.25,
    height: 24.344,
    viewBox: '0 0 20.25 24.344',
    data: '<path pid="0" d="M10.121 19.06a8.914 8.914 0 118.913-8.913 8.913 8.913 0 01-8.913 8.913zm0-19.049A10.043 10.043 0 00-.014 9.959c0 5.579 4.434 9.393 10.135 14.376 5.7-4.983 10.135-8.8 10.135-14.376A10.043 10.043 0 0010.12.011z" _fill="#fff" fill-rule="evenodd"/><path pid="1" data-name="Layer 1175" d="M13.156 14.219a31.091 31.091 0 00-3 2c-.1 0-3-2-3-2v-17h6v17zm7-18h-14v3h-4v-7h5v-2h6v2h10l3 3v1h-5m-9 13.429l-4 2.714v1.714l4-2.714V9.648zm0-4.143l-4 2.714v1.714l4-2.714V5.505zm0-4.143l-4 2.714V5.79l4-2.714V1.362zm0-4.143l-4 2.714v1.715l4-2.715v-1.714z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
