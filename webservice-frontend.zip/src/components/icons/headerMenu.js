/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'headerMenu': {
    width: 20,
    height: 18,
    viewBox: '0 0 20 18',
    data: '<path pid="0" d="M0 0h20v2H0V0zm0 8h20v2H0V8zm0 8h20v2H0v-2z" _fill="#111" fill-rule="evenodd"/>'
  }
})
