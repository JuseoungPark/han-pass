/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'arrowBt': {
    width: 9.88,
    height: 13.44,
    viewBox: '0 0 9.88 13.44',
    data: '<path pid="0" data-name="사각형 1203" d="M6.35 12.04l-.91.91V13h-.05l-.45.45-.45-.45h-.05v-.05l-.31-.31-.6-.6L-.01 8.5 1.4 7.09l3.04 3.03V0h1v10.12l3.04-3.03L9.89 8.5z" _fill="#b2b2b2" fill-rule="evenodd"/>'
  }
})
