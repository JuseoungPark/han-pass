/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'list': {
    width: 17,
    height: 16,
    viewBox: '0 0 17 16',
    data: '<path pid="0" d="M4 16h13v-2H4v2zm0-7h13V7H4v2zm0-9v2h13V0H4zM2 0H0v2h2V0zm0 7H0v2h2V7zm0 9H0v-2h2v2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
