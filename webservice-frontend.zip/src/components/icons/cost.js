/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'cost': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" d="M12 24H8v-.153A13.611 13.611 0 016 24c-3.314 0-6-1.119-6-2.5S2.686 19 6 19a13.611 13.611 0 012 .153V8h24v16H12zm18.009-14h-20v9.652C11.223 20.109 12 20.764 12 21.5a1.133 1.133 0 01-.121.5h18.13V10zM14 19h-1v-6h1v6zm6-6a3 3 0 11-3 3 3 3 0 013-3zm-1 4h2v-2h-2v2zm8 2h-1v-6h1v6zM6 28s-6 .312-6-2v-2s.789 2 6 2a8.42 8.42 0 006-2v2s-.742 2-6 2zm0-12H4V4h22v2H6v10zm-4-6H0V0h22v2H2v8zm4 20a8.42 8.42 0 006-2v2s-.742 2-6 2c0 0-6 .312-6-2v-2s.789 2 6 2z" _fill="#333" fill-rule="evenodd"/>'
  }
})
