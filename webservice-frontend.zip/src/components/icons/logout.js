/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'logout': {
    width: 13,
    height: 13,
    viewBox: '0 0 13 13',
    data: '<path pid="0" d="M10.057 9.981l-.738-.87L11.111 7H2.792V6h8.319L9.319 3.889l.738-.87L13.013 6.5zM1 3v7a1.955 1.955 0 002 2h6v1H2a1.974 1.974 0 01-2-2V2a1.955 1.955 0 012-2h7v1H3a1.944 1.944 0 00-2 2z" _fill="#333" fill-rule="evenodd"/>'
  }
})
