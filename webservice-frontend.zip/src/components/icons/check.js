/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'check': {
    width: 15,
    height: 12,
    viewBox: '0 0 15 12',
    data: '<image data-name="check" width="15" height="12" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAMCAYAAAC9QufkAAAA00lEQVQokZXRMUrDQRDF4U8RixxBsNJLRLSxCKhtGq1jqbXEzsI6RdTOC2hlLwHBC+gVPIGgnSAjuzBZ/0XyqhmW39uZNyufF9uW0CmGuMLr2hLgDqZYxwD3qwuCG3goYOgbk0XgAB6LQegHx3jP8B42O+Ab9FN/hqcoAt7FM14wawwioFHqb3FXm4APsF/6rWRQA6qK387zSJH2ZanHjUEvBfRW9ox95+BQl0HVB45KwnPKgYXBdfP+hcNi8E/tqbJBjHgSJ+kC89itQR337ySdwi/nOiSknO8XWQAAAABJRU5ErkJggg=="/>'
  }
})
