/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'avgPf': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="P.F (kg/BCM)" d="M0 32l7-11h3v5l1-2 3-7 3-2 5 1v5l1-2 1-8 4-2h4v23H0zm16-19v-3h-2l.24-3.121L12.12 9 10 6.879 9.88 9.65l-2.71.057 1.42 1.414-1.42 1.414L10 15H1l4.05-4.586L1 7h6V0l5.16 4.742L17 0v7l5.73-.121L18 13h-2z" _fill="#333" fill-rule="evenodd"/>'
  }
})
