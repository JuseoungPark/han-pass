/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'pass': {
    width: 16,
    height: 22,
    viewBox: '0 0 16 22',
    data: '<path pid="0" d="M12 22H4a4 4 0 01-4-4v-5a4 4 0 014-4h8a4 4 0 014 4v5a4 4 0 01-4 4zm2-8a3 3 0 00-3-3H5a3 3 0 00-3 3v3a3 3 0 003 3h6a3 3 0 003-3v-3zm-7 0h2v4H7v-4zm4-10s.053-2-3-2c0 0-3-.352-3 2v4H3V2a3.808 3.808 0 013-2h4s3 .065 3 2v6h-2V4z" _fill="#dbdbdb" fill-rule="evenodd"/>'
  }
})
