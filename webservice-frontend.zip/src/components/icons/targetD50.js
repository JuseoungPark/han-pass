/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'targetD50': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Target D50" d="M32 16v1h-.043C31.506 26.812 24.584 30.216 20 31.383V32h-8v-8h3v-2h2v2h3v.217c3.668-1.632 4.645-5.409 4.9-7.217H22v-2h2.938c-.5-6.522-5.718-7.729-7.938-7.949V10h-2V0h2v.133C33.108 2.405 32 16 32 16zM17 2.125v2.921c9.149.477 10.049 7.339 10.048 9.954h2.918C29.386 4.869 20.077 2.6 17 2.125zM30.086 17h-3.123A9.775 9.775 0 0120 26.261v2.661C29.358 25.677 30.15 19.42 30.086 17zM20 20h-8v-8h8v8zM0 24h8v8H0v-8zm0-12h8v8H0v-8zM0 0h8v8H0V0z" _fill="#333" fill-rule="evenodd"/>'
  }
})
