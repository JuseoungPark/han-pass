/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'loginUser': {
    width: 16,
    height: 22,
    viewBox: '0 0 16 22',
    data: '<path pid="0" d="M14 22v-7s-.03-2-3-2H5s-3-.018-3 2v7H0v-8s.3-3 5-3h6s5-.018 5 3v8h-2zM8 10a5 5 0 115-5 5 5 0 01-5 5zm0-8a3 3 0 103 3 3 3 0 00-3-3z" _fill="#dbdbdb" fill-rule="evenodd"/>'
  }
})
