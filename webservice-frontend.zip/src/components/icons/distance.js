/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'distance': {
    width: 14,
    height: 14.062,
    viewBox: '0 0 14 14.062',
    data: '<path pid="0" d="M0 11.062h1v3H0v-3zm12.92 0H14v3h-1.08v-3zm-11.92 2h11.92v1H1v-1zM10.3.018a1 1 0 011.24 1.238l-2.55 8.839a1 1 0 01-1.67.43L1.03 4.231a1 1 0 01.43-1.668zm-.38 1.525L7.98 8.879 2.59 3.487zM6.56 4.194l.71.707L4.44 7.73l-.7-.707 2.82-2.829z" _fill="#b1b1b1" fill-rule="evenodd"/>'
  }
})
