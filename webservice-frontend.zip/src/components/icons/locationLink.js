/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'locationLink': {
    width: 11,
    height: 14.844,
    viewBox: '0 0 11 14.844',
    data: '<path pid="0" d="M5.5 8.029a2.526 2.526 0 112.52-2.525A2.526 2.526 0 015.5 8.029zM5.5 0A5.46 5.46 0 00-.01 5.405c0 3.031 2.41 6.732 5.51 9.44 3.09-2.708 5.5-6.409 5.5-9.44A5.452 5.452 0 005.5 0z" _fill="#3d3d3d" fill-rule="evenodd"/>'
  }
})
