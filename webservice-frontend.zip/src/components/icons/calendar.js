/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'calendar': {
    width: 14,
    height: 14.656,
    viewBox: '0 0 14 14.656',
    data: '<path pid="0" d="M0 14.656V1.575h1.56v.781a1.565 1.565 0 103.13 0v-.782h4.26v.782a1.566 1.566 0 001.57 1.565A1.435 1.435 0 0012 2.656v-1h2v13H0zm13-9H1v8h12v-8zm-8 4H3v-2h2v2zm6 0H9v-2h2v2zm-.48-6.516a.784.784 0 01-.79-.783V.793a.785.785 0 011.57 0v1.563a.782.782 0 01-.78.784zm-7.39 0a.782.782 0 01-.78-.783V.793a.78.78 0 111.56 0v1.563a.782.782 0 01-.78.784z" _fill="#bdbdbd" fill-rule="evenodd"/>'
  }
})
