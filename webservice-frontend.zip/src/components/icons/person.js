/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'person': {
    width: 14.19,
    height: 14,
    viewBox: '0 0 14.19 14',
    data: '<path pid="0" d="M14 14H0a6.551 6.551 0 014.74-6.706 4 4 0 114.49.027A6.953 6.953 0 0114 14zM10 4a3 3 0 10-3 3 3 3 0 003-3zM8 8v-.141a3.617 3.617 0 01-2 0V8c-3.9.682-5 5-5 5h12a7.438 7.438 0 00-5-5z" _fill="#bdbdbd" fill-rule="evenodd"/>'
  }
})
