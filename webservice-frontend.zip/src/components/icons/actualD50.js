/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'actualD50': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Actual D50" d="M0 24h8v8H0v-8zm12 0h8v8h-8v-8zm12 0h8v8h-8v-8zM0 12h8v8H0v-8zM0 0h8v8H0V0zm12 12h8v8h-8v-8zm8.343-6L26 .343 31.657 6 26 11.657 20.343 6z" _fill="#333" fill-rule="evenodd"/>'
  }
})
