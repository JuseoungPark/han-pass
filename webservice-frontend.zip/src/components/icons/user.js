/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'user': {
    width: 24,
    height: 24,
    viewBox: '0 0 24 24',
    data: '<path pid="0" d="M11.99 23.993a12 12 0 1112-12 12 12 0 01-12 12zM12 2a10 10 0 00-7 17.134v-.072c0-2.292 1.8-3.792 3.97-4.15a31.086 31.086 0 016.07 0 4.064 4.064 0 013.97 4.15v.062A9.995 9.995 0 0012 2zm-.01 10A3 3 0 1115 9a3 3 0 01-3.01 3z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
