/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'profile': {
    width: 12,
    height: 14.375,
    viewBox: '0 0 12 14.375',
    data: '<path pid="0" d="M6 .015a3.36 3.36 0 11-3.36 3.36A3.36 3.36 0 016 .015zm0 1.733a1.627 1.627 0 11-1.627 1.627A1.627 1.627 0 016 1.748zM0 14.375s.5-6 5.454-6c0 0 6.733-.6 6.546 6H0zm6-5s-4.187.29-4 3.792h8s.792-3.304-4-3.792z" _fill="#333" fill-rule="evenodd"/>'
  }
})
