/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'mpuPoint': {
    width: 20.246,
    height: 24.35,
    viewBox: '0 0 20.246 24.35',
    data: '<path pid="0" d="M10.12 24.34C4.42 19.35-.015 15.54-.015 9.96a10.137 10.137 0 0120.271 0c0 5.58-4.44 9.39-10.136 14.38zm0-23.11a8.915 8.915 0 108.915 8.92 8.92 8.92 0 00-8.914-8.92zm6.036 10.99v-3h-2v-3h2v1h1v5h-1zm-4 0H9.879a3.526 3.526 0 11-6.446 0h-.277v-6h8v-1h3v1h-2v6zm-5 2h2v-2h-2v2zm-3 0h2v-2h-2v2zm7-6h-7v3h7v-3zm3 3a2 2 0 11-2 2 2.006 2.006 0 012-2zm-1 3h2v-2h-2v2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
