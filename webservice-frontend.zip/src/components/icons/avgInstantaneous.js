/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'avgInstantaneous': {
    width: 31.906,
    height: 32,
    viewBox: '0 0 31.906 32',
    data: '<path pid="0" data-name="Avg. Instantaneous" d="M10.906 32s3.472-12.808 11-13c0 0 8.117 1.192 10 13h-21zm6-3h-1v1h1v-1zm1-1h2v-2h-2v2zm4-5h-2v2h2v-2zm1 4h-1v1h1v-1zm2-2h-1v1h1v-1zm1 3h-2v2h2v-2zm-16-13V9h2v6h5v2h-7v-2zm10.011 2a9.235 9.235 0 00.069-1.072A9 9 0 0012.045 7h-2v-.025a9 9 0 00.866 17.95v2.068a10.993 10.993 0 01-.866-21.943V3H6.906a1 1 0 01-1-1V1a1 1 0 011-1h8a1 1 0 011 1v1a1 1 0 01-1 1h-2.861v2.051A11.007 11.007 0 0122.063 16c0 .337-.021.67-.051 1h-2.1z" _fill="#333" fill-rule="evenodd"/>'
  }
})
