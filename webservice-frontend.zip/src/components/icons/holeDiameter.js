/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'holeDiameter': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" d="M16 32a16 16 0 1116-16 16 16 0 01-16 16zm-.009-30a14 14 0 1014 14 14 14 0 00-14-14zm6.5 9.107l-11.3 11.3h2.759v2.134h-6.4v-6.4h2.133V20.9l11.3-11.3h-2.758V7.466h6.4v6.4h-2.133V11.1z" _fill="#333" fill-rule="evenodd"/>'
  }
})
