/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'fleet': {
    width: 18,
    height: 17.031,
    viewBox: '0 0 18 17.031',
    data: '<path pid="0" d="M13 12.031H4c-3.312 0-3 2-3 2 0 1.4 3 1 3 1h10.1a1.5 1.5 0 110 1.022H4s-4.009.375-4.009-2.022c0-3.71 4.009-3 4.009-3h9c4 .187 4-4 4-4 .125-1.472-2-2-2-2v-1a2.935 2.935 0 013 3c0 4.716-5 5-5 5zm-3-3a2 2 0 111.723-3H13v-2l-3-3H8v3H7v-3H1v5l.274.006A1.987 1.987 0 111 7.031H0V.014h11l3.009 3.017v4H12a2 2 0 01-2 2zm1.01-2H11v-1h.01v-.014h-2v2h2v-.986zm-9 .986h2v-2h-2v2zM8 6.031v1H5v-1h3z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
