/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'chargingPoint': {
    width: 20.25,
    height: 24.35,
    viewBox: '0 0 20.25 24.35',
    data: '<path pid="0" d="M10.13 19.06a8.915 8.915 0 118.91-8.91 8.913 8.913 0 01-8.91 8.91zM10.12.01A10.048 10.048 0 00-.01 9.96c0 5.58 4.43 9.39 10.13 14.38 5.7-4.99 10.14-8.8 10.14-14.38A10.05 10.05 0 0010.12.01z" _fill="#fff" fill-rule="evenodd"/><path pid="1" data-name="사각형 1188" d="M7.16 1.22h1v5h4v-5h1v11a2.006 2.006 0 01-2 2h-2a2.006 2.006 0 01-2-2v-11z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
