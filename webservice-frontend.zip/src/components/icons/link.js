/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'link': {
    width: 19,
    height: 19.219,
    viewBox: '0 0 19 19.219',
    data: '<path pid="0" data-name="ic_site view" d="M19 8.219h-1V2.133l-9.182 9.182-1.414-1.414 8.682-8.682H11v-1h6.086l.217-.218.218.218H19v8zm-18-2v10a1.969 1.969 0 002 2h10a1.96 1.96 0 002-2v-7h1v7a2.942 2.942 0 01-3 3H3a2.944 2.944 0 01-3-3v-10a2.935 2.935 0 013-3h5v1H3a1.961 1.961 0 00-2 2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
