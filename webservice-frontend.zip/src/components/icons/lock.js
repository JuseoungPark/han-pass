/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'lock': {
    width: 12,
    height: 16,
    viewBox: '0 0 12 16',
    data: '<path pid="0" d="M2 5h8a2 2 0 012 2v7a2 2 0 01-2 2H2a2 2 0 01-2-2V7a2 2 0 012-2zm0 1h8a1 1 0 011 1v7a1 1 0 01-1 1H2a1 1 0 01-1-1V7a1 1 0 011-1zm3 3h2v3H5V9zM2 5V2a2 2 0 012-2h4a2 2 0 012 2v3.034M3 5V2a1 1 0 011-1h4a1 1 0 011 1v3.018" _fill="#333" fill-rule="evenodd"/>'
  }
})
