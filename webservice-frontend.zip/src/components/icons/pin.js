/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'pin': {
    width: 16,
    height: 16,
    viewBox: '0 0 16 16',
    data: '<image width="16" height="16" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABYUlEQVQ4jZWRTyutURSHHzpEVxTSHbkpUkyklC8gJbphcnMkAyNTMyn5kwEpAwMTke7sTgzOSAZMFE4Gd8QHYCSMSMqjXfut03sOHbvWrr3W+j1rrb0qVMo8FcAp8Az8AZ6CrLJcNdAHVAPvwB7Q9B1AHbAI3AO/gTdgF2guBzAI5OIIP4FpYCYWP0j/QS/QCFxGwTwwAuwDm0APsA3cAS1AVSYKa4A5YCg4gQfgBXgFssBVzMsDt0ADsAScEDpQa9Qj9VBtUDfVR7U7xhObVS/V+sRXGGxVj9UNNYw2r+bVrhgPsGt1uBBKqkJHrLCmVqrrEdKu/lV3UvlFgKST/+pWfK+oT2pObUrnZ4q3Rnfc9wCwCiwAtdH/XpSdIo6pN+q4+ku9iONUqWfp+dMjjEZxtsDXqZ6o/9Rztf8zQCKeKPEnbRGyrGZKAUK7QTxZQpzYD7W6VCxcYW1TX4g/N+UDsEztrXSMepAAAAAASUVORK5CYII="/>'
  }
})
