/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'accuracy': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Accuracy (%)" d="M28 32h-8a4 4 0 01-4-4v-8a4 4 0 014-4h8a4 4 0 014 4v8a4 4 0 01-4 4zm-7-13a2 2 0 102 2 2 2 0 00-2-2zm6.47-.012l-8.485 8.485 1.414 1.414 8.486-8.485zM27 25a2 2 0 102 2 2 2 0 00-2-2zM14 14h2v2h-2v-2zm2-7.024V10h-2V7.015A8.177 8.177 0 007.032 14H10v2H6.976A8.179 8.179 0 0014 23.215v1.967A10.12 10.12 0 015.044 16H0v-2h5.068A10.123 10.123 0 0114 5.066V0h2v5.044A10.121 10.121 0 0125.182 14h-1.967A8.18 8.18 0 0016 6.976z" _fill="#333" fill-rule="evenodd"/>'
  }
})
