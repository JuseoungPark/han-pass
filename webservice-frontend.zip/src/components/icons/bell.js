/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'bell': {
    width: 20,
    height: 19,
    viewBox: '0 0 20 19',
    data: '<path pid="0" data-name="menu copy" d="M20 19l-20.01.009L0 17h2v-6a8 8 0 0116 0v6h2v2zm-4-8a6 6 0 10-12 0v6h12v-6zM9 0h2v3H9V0z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
