/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'blastList': {
    width: 18,
    height: 14,
    viewBox: '0 0 18 14',
    data: '<path pid="0" data-name="모양 1181" d="M5 14H0v-2h5v2zm0-6H0V6h5v2zm13-6H0V0h18v2zM7 14l3-3-4-3h5V4l4 3 3-3v10H7zm5-2h4v-2l-2-2-2 2v2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
