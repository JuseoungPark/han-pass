/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'listDot': {
    width: 20,
    height: 20,
    viewBox: '0 0 20 20',
    data: '<path pid="0" d="M2 0a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2zM2 8a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2zM2 16a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2zm8 0a2 2 0 11-2 2 2 2 0 012-2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
