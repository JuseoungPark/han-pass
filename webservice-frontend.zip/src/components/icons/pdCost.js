/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'pdCost': {
    width: 19,
    height: 13,
    viewBox: '0 0 19 13',
    data: '<path pid="0" d="M3 13v-1h15V4h1v9H3zM0 0h16v10H0V0zm1 9h14V1H1v8zm7-2a2 2 0 112-2 2 2 0 01-2 2z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
