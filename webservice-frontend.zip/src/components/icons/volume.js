/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'volume': {
    width: 32.031,
    height: 32,
    viewBox: '0 0 32.031 32',
    data: '<path pid="0" d="M24.015 32V6h8v26h-8zM19.867 4.394l-1.813 7.269-1.788-.514 1.36-5.453-16.283 9.471L.009 12.84l16.284-9.472-5.369-1.54.453-1.817 7.155 2.053 1.789.514-.454 1.817zm-1.909-.548l.09.157.031-.122zM8.008 32h-8V19h8v13zm12 0h-8V14h8v18z" _fill="#333" fill-rule="evenodd"/>'
  }
})
