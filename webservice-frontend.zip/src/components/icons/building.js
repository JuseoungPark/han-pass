/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'building': {
    width: 14,
    height: 14,
    viewBox: '0 0 14 14',
    data: '<path pid="0" d="M13 14H0v-1h1V0h12v13h1v1h-1zM12 1H2v12h10V1zM6 5H5V4H4V3h2v2zm0 3H5V7H4V6h2v2zm0 3H5v-1H4V9h2v2zm4-6H9V4H8V3h2v2zm0 3H9V7H8V6h2v2zm0 3H9v-1H8V9h2v2z" _fill="#bdbdbd" fill-rule="evenodd"/>'
  }
})
