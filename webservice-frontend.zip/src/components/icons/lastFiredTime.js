/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'lastFiredTime': {
    width: 32,
    height: 32.031,
    viewBox: '0 0 32 32.031',
    data: '<path pid="0" data-name="Last fired time" d="M29.847 26.955l.153.076-.793.793-.906 1.231-.2-.122L25 32.031H9l5-5-4-5h6v-6l6 4 6-4v8h4zM25 26.031v-3l-3.178 2.153L19 23.031l.337 2.753-2.848-.621L18 28.031l-2.416 1.174 1.29.826H24l3.085-3.085-.085-.915h-2zm-9-11v-10h2v10h-2zm-7 2.2v-12.2l6.1 6.1zm5-15.2c-11.836 0-12 12-12 12 0 6.4 6 9 6 9v2a10.765 10.765 0 01-8-8v-7c3.581-11.183 14-10 14-10 10.914 0 13 10 13 10v5h-2c0-13.1-11-13-11-13z" _fill="#333" fill-rule="evenodd"/>'
  }
})
