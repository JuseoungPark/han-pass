/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'night': {
    width: 17.56,
    height: 17.563,
    viewBox: '0 0 17.56 17.563',
    data: '<path pid="0" d="M4.87-.001a9.353 9.353 0 1012.69 12.69A9.362 9.362 0 014.87-.001z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
