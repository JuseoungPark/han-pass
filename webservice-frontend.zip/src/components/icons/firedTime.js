/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'firedTime': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="fired time" d="M29.847 26.924L30 27l-.793.793-.906 1.231-.2-.122L25 32H9l5-5-4-5h6v-6l6 4 6-4v8h4zM25 26v-3l-3.178 2.153L19 23l.337 2.753-2.848-.621L18 28l-2.416 1.174 1.29.826H24l3.085-3.085L27 26h-2zm-14-9v-3h3v3h-3zm-3-3v3H5v-3h3zm16-4H2v15h8v2H0V3h4v4s-.02 1 2 1h1c2.018 0 2-.8 2-2V3h8v3a1.983 1.983 0 002 2h1a1.953 1.953 0 002-2V3h4v12h-2v-5zm-4-4h-1a1 1 0 01-1-1V1a1 1 0 011-1h1a1 1 0 011 1v4a1 1 0 01-1 1zM7 6H6a1 1 0 01-1-1V1a1 1 0 011-1h1a1 1 0 011 1v4a1 1 0 01-1 1z" _fill="#333" fill-rule="evenodd"/>'
  }
})
