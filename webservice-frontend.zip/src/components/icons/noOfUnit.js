/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'noOfUnit': {
    width: 32.06,
    height: 32,
    viewBox: '0 0 32.06 32',
    data: '<path pid="0" d="M21 2v1h-2V0h12.99l.06 2H21zm-6 0h-4a.979.979 0 00-1 1H8s.09-3 2-3h7v3h-2V2zm-1 6h-2V7H8a.979.979 0 00-1 1H5s.09-3 2-3h7v3zm-4 2v10h19v7h-2.14a4.111 4.111 0 01.14 1 4 4 0 01-8 0 4.111 4.111 0 01.14-1h-6.28a4.111 4.111 0 01.14 1 4 4 0 01-8 0 4.111 4.111 0 01.14-1H0v-8l3-8a2.166 2.166 0 012-1h5zm13 20a2 2 0 10-2-2 2 2 0 002 2zM9 30a2 2 0 10-2-2 2 2 0 002 2zM2 19v2h2v2H2v2h4v.379A3.943 3.943 0 0111.62 25h8.76a3.932 3.932 0 015.24 0H27v-3H8V12H6v7H2zm27-3a3 3 0 01-3 3H14a3 3 0 01-3-3v-6h18v6zm-2-4H13v2a3 3 0 003 3h8a3 3 0 003-3v-2zm-9-4h-2V5h16v6h-2V7H18v1z" _fill="#333" fill-rule="evenodd"/>'
  }
})
