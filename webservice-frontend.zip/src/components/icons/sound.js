/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'sound': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" d="M16 32a16 16 0 1116-16 16 16 0 01-16 16zm0-30.009a14 14 0 1014 14 13.995 13.995 0 00-14-14zM18 15h7v2h-7v-2zm0-2l4.95-4.95 1.41 1.414-4.95 4.95zM6 21a1 1 0 01-1-1v-8a1 1 0 011-1h3l8-5v20l-8-5H6zm3-8H7v6h2v-6zm2 7l4 2V10l-4 2v8zm13.37 3l-1.41 1.414-4.95-4.95 1.41-1.414z" _fill="#333" fill-rule="evenodd"/>'
  }
})
