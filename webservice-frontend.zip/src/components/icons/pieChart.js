/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'pieChart': {
    width: 17.969,
    height: 17.937,
    viewBox: '0 0 17.969 17.937',
    data: '<path pid="0" d="M10.148 7.82V-.002A7.542 7.542 0 0117.97 7.82h-7.822zm5.883 2.117v1s-1.167 7.2-8 7c0 0-8.167.511-8-8 0 0-.723-7.459 7-7.955v-.045h1v8h8zm-9-6.9a6.756 6.756 0 00-6 5.9v2s.458 5.636 7 6c0 0 4.333.011 7-6h-8v-7.9z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
