/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'close': {
    width: 50,
    height: 50,
    viewBox: '0 0 50 50',
    data: '<image data-name="레이어 1" width="50" height="50" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABdUlEQVRoge2a2xHCIBREl1RgKWnBTvSLmvgynaSFlGIJjhlwUPPgcRGy435pQrh7MgQuDwVPxpgbgB7AWWt9R4MyxpwAjAAmrfXVOXyBWIiL/Tu1CONB9PbS4GAUviGcmoJZgHCaYdQKhFMTMBsQTkO3cRP23mgrqqIAiNnnE+Rs33xzMIEQc6tRsQ/8qpnFelKpD8rafleKl89xpDpMqgf1WaImTE7sL5DcClOVG3MR5NcwErFWQaQC7EkqxiZIaRjJundBpAOWqjMIRDpwiRcTDCJloFRTjQLJNVLye4sGSTVUugdMAok1Zn8X7caTQRAHg9IDaxYIwmG2JJIdZIMgD0YsXxMBQRqMaNIpBoI4GPFpQCdVUW39m5Yvio+dovulGBApUhSKpJEijaeYWFFMdSkWHyiWgygW6CiWTCkWsSm2FSg2eii23ig2Q1uEcIrx1rUK8ZSNGXQOoNspVP0IRyDMxHOoxit4/GNOXsFjHjwD8ABRA/GMYYl5AQAAAABJRU5ErkJggg=="/>'
  }
})
