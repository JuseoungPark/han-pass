/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'charging': {
    width: 16,
    height: 17,
    viewBox: '0 0 16 17',
    data: '<path pid="0" data-name="사각형 1178" d="M0-.007h16v17H0v-17zM3-1h10v15H3V-1zm2 1h6v12H5V0z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
