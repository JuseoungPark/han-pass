/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'serial': {
    width: 13,
    height: 13,
    viewBox: '0 0 13 13',
    data: '<path pid="0" d="M0 0h6v6H0V0zm.86.857h4.28v4.286H.86V.857zM3 2a1 1 0 11-1 1 1 1 0 011-1zM0 7h6v6H0V7zm.86.857h4.28v4.286H.86V7.857zM3 9a1 1 0 11-1 1 1 1 0 011-1zm4-9h6v6H7V0zm.86.857h4.28v4.286H7.86V.857zM10 2a1 1 0 11-1 1 1 1 0 011-1zM8 7h1v4H8V7zm0 5h1v1H8v-1zm2-5h1v3h-1V7zm2 0h1v6h-1V7z" _fill="#b1b1b1" fill-rule="evenodd"/>'
  }
})
