/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'operationTime': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Operation time" d="M30 28v-4.289A15.982 15.982 0 01.291 13H2.33a13.993 13.993 0 0026.311 9H24v-2h8v8h-2zM17 8v10H7v-2h8V8h2zm12.841 10A13.981 13.981 0 003.894 9H8v2H0V3h2v5.292A15.966 15.966 0 0131.862 18h-2.021z" _fill="#333" fill-rule="evenodd"/>'
  }
})
