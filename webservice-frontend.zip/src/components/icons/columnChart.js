/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'columnChart': {
    width: 19,
    height: 16,
    viewBox: '0 0 19 16',
    data: '<path pid="0" d="M0 16v-1h19v1H0zm16-7h2v4h-2V9zm-5-6h2v10h-2V3zM6 0h2v13H6V0zM1 6h2v7H1V6z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
