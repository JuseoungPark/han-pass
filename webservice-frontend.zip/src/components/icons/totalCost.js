/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'totalCost': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" d="M26 19v-6h1v6h-1zm-8 5v-2h12.01V10h-20v4H8V8h24v16H18zM6 14H4V4h22v2H6v8zm-4-4H0V0h22v2H2v8zm12 3v1h-1v-1h1zM4 16h8a4 4 0 014 4v8a4 4 0 01-4 4H4a4 4 0 01-4-4v-8a4 4 0 014-4zm0 5l6 3v1l-6 2v2h8v-1H6l6-3v-1l-6-4h6v-1H4v2zm16-8a3 3 0 11-3 3 3 3 0 013-3zm-1 4h2v-2h-2v2z" _fill="#333" fill-rule="evenodd"/>'
  }
})
