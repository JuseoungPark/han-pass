/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'expectedD50': {
    width: 32,
    height: 32,
    viewBox: '0 0 32 32',
    data: '<path pid="0" data-name="Expected D50" d="M12 24h8v8h-8v-8zM0 24h8v8H0v-8zm0-12h8v8H0v-8zM0 0h8v8H0V0zm2 2h4v4H2V2zm10 10h8v8h-8v-8zm2 2h4v4h-4v-4zM24 0h8v8h-8V0zm2 2h4v4h-4V2zm-2 22h8v8h-8v-8zm2 2h4v4h-4v-4z" _fill="#333" fill-rule="evenodd"/>'
  }
})
