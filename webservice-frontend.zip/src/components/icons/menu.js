/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'menu': {
    width: 26,
    height: 24,
    viewBox: '0 0 26 24',
    data: '<path pid="0" d="M0 0h26v3H0V0zm0 11h26v3H0v-3zm0 10h26v3H0v-3z" _fill="#111" fill-rule="evenodd"/>'
  }
})
