/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'fragmentation': {
    width: 18,
    height: 18,
    viewBox: '0 0 18 18',
    data: '<path pid="0" d="M0 0h4v4H0V0zm0 7h4v4H0V7zm7 0h4v4H7V7zM15.732.268l2 3.464-3.464 2-2-3.464 3.464-2zM0 14h4v4H0v-4zm7 0h4v4H7v-4zm7 0h4v4h-4v-4z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
