/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'chartReport': {
    width: 18,
    height: 14,
    viewBox: '0 0 18 14',
    data: '<path pid="0" d="M17 2v12H1V2H0V0h18v2h-1zm-1 0H2v11h14V2zM6 11H4V9h2v2zm4 0H8V7h2v4zm4 0h-2V5h2v6z" _fill="#fff" fill-rule="evenodd"/>'
  }
})
