import { helpers } from "vuelidate/lib/validators"
import utils from '@/assets/js/utils'

export const decimalLimit = (limit) => 
  helpers.withParams({ type: 'decimalLimit', limit: limit},
    (value) => {
      if (helpers.req(value)) {
        let reg = new RegExp(`^[-]?(\\d)+(\\.\\d{1,${limit}})?$`)
        return reg.test(value)
      }
      return true
    }
  )

export const byte = (limit) => 
  helpers.withParams({ type: 'byte', limit: limit},
    (value) => {
      if (helpers.req(value)) {
        return utils.getByteLen(value) <= limit
      }
      return true
    }
  )

export const phone = () =>
  helpers.withParams({ type: 'phone'},
    (value) => {
      if (helpers.req(value)) {
        return /^01([0|1|6|7|8|9]?)-([0-9]{3,4})-([0-9]{4})$/.test(value)
      }
      return true
    }
  )

export const betweenLength = (min, max) =>
  helpers.withParams({ type: 'betweenLength', min: min, max: max},
    (value) => {
      if (helpers.req(value)) {
        return (value.length >= min && value.length <= max)
      }
      return true
    }
  )

export const equalLength = (len) =>
  helpers.withParams({ type: 'equal', len: len},
    (value) => {
      if (helpers.req(value)) {
        return (value.length === len)
      }
      return true
    }
  )

export const strongPass = () =>
  helpers.withParams({ type: 'strongPass'},
    (value) => {
      if (helpers.req(value)) {
        return /(?=.*\d)(?=.*[a-z]).{6,}/.test(value) // (?=.*[A-Z])
      }
      return true
    }
  )