import CThemaCover from '@/components/form/CThemaCover'
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import utils from '@/assets/js/utils'
import am4lang_en_US from "@amcharts/amcharts4/lang/en_US";
import am4lang_ko_KR from "@amcharts/amcharts4/lang/ko_KR";
am4core.options.queue = true
am4core.options.onlyShowOnViewport = true
// am4core.options.minPolylineStep = 5
export default {
    components: {
        CThemaCover
    },
    data () {
        return {
            chart: null,
            isSerices: true,
            isNumberCutting: true,
            chartLoading:false,
        }
    },
    computed: {
        langType(){
            return this.$i18n.locale
        },
        userSite () {
            return utils.getUserInformation().selectedUserSite
        },
        items() {
            return this.item
        },
        itemsKeys(){
            return Object.keys(this.item[0])
        }
    },
    watch: {
        item: {
            deep: true,
            handler(data) {
                this.startChart()
            }
        },
        langType(lang){
            if(lang === 'ko'){
                this.chart.language.locale = am4lang_ko_KR;
            }else{
                this.chart.language.locale = am4lang_en_US;
            }
        }
    },
    methods: {
        async startChart(){
            if (this.chart) this.chart.dispose()
            this.chartLoading = true
            // this.setLoading(true)
            await this.drawChart()
            if(this.isSerices && this.items.length > 0) this.createSerices()
            if (this.chart){
                this.chart.events.on("ready", () => {
                    this.chartLoading = false
                    // this.setLoading(false)
                });
            }
        },
        initChart(){
            let chart = am4core.create(this.$refs.am, am4charts.XYChart)
            chart.data = this.items
            chart.svgContainer.measure()
            chart.cursor = new am4charts.XYCursor()
            chart.numberFormatter.numberFormat = "#,###.###a";
            chart.numberFormatter.smallNumberThreshold = 0
            // chart.numberFormatter.bigNumberPrefixes = [
            //     { "number": 1e-3, "suffix": "" },
            //     { "number": 1e-1, "suffix": "" }
            // ]
            if(this.langType === 'ko'){
                chart.language.locale = am4lang_ko_KR;
            }else{
                chart.language.locale = am4lang_en_US;
            }
            // chart.width = am4core.percent(100);
            this.chart = chart
        },
        async drawChart(){
            await this.initChart()
        },
        setDateAxis(){
            let x = this.chart.xAxes.push(new am4charts.DateAxis())
            // x.startLocation = 0
            // x.endLocation = 1
            x.dataFields.date = 'date'
            x.skipEmptyPeriods = false
            // x.renderer.minLabelPosition = 0
            // x.renderer.maxLabelPosition = 1
            // x.renderer.labels.template.locaton = 0.0001
            x.renderer.labels.template.fill = am4core.color('#777')
            x.renderer.labels.template.fontSize = 11
            if(Object.keys(this.search).length){
                if(this.search.date.length === 2){
                    let date = this.search.date.map((item) => Number(this.$moment(item).toDate()))
                    x.min = date[0]
                    x.max = date[1]
                    let daysCnt = this.$moment(date[1]).diff(date[0],'days') + 1
                    // let weeksCnt = daysCnt / 7 // 1534
                    // x.renderer.labels.template.maxWidth = 10
                    // console.log(this.$options.name, this.items.length)
                    let timeUnit = 'day'
                    if(this.search.periodType === 'Daily'){
                        // console.log(this.items.length, daysCnt)
                        x.renderer.minGridDistance = 30
                        if(daysCnt >= 100) x.renderer.labels.template.fontSize = 10
                        // x.dateFormats.setKey("day", "MMMM dd");
                        // x.periodChangeDateFormats.setKey("year", "MMM dd YYYY"); 
                    }else if(this.search.periodType === 'Weekly'){
                        // console.log(this.items.length, this.items.map(d => this.$moment(new Date(d.date)).format('YYYY-MM-DD')))
                        // let i = 0
                        // let period = this.search.date.map((item) => this.$moment(item))
                        // while (i <= period[1].diff(period[0], 'days')) {
                        //     let d = this.search.date.map((item) => this.$moment(item))
                        //     let a = d[0].add(i, 'days')
                        //     if(a.day() === 1) console.log(a.format('YYYY-MM-DD'))
                        //     i++
                        // }
                        x.renderer.minGridDistance = 30
                        timeUnit = 'week'
                        x.max = date[1]
                    }else if(this.search.periodType === 'Monthly'){
                        x.renderer.minGridDistance = 30
                        timeUnit = 'month'
                    }
                    x.gridIntervals.setAll([
                        { timeUnit: timeUnit, count: 1 },
                        { timeUnit: timeUnit, count: 2 },
                        { timeUnit: timeUnit, count: 3 },
                        { timeUnit: timeUnit, count: 4 },
                        { timeUnit: timeUnit, count: 5 },
                        { timeUnit: timeUnit, count: 10 },
                        { timeUnit: timeUnit, count: 50 },
                        { timeUnit: timeUnit, count: 100 },
                    ]);
                }else{
                    x.renderer.minGridDistance = 40
                }
            }            
        },
        removeSeries() {
            let count = this.chart.series.length
            if (count) {
                for(let i = 0; i < count; i++) {
                this.chart.series.removeIndex(0).dispose()
                }
            }
        },
        setLoading(flag){
            this.$emit('setLoading', flag)
        }
    },
    beforeDestroy() {
        if (this.chart) this.chart.dispose()
    }
}