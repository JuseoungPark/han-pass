// import axios from 'axios'

const validateFns = {
    vRequired (key, val) {
      if (!val) {
        // return `${key} is required`
        // console.log("XXXXXXXXXXX vRequired key",key)
        // console.log("XXXXXXXXXXX vRequired val",val)
        return `은(는) 필수항목입니다. `
      }
    },
    vLength2 (key, val) {
      return (val && val.length && val.length < 2) ? `은(는) 2자이상 입력합니다.` : ''
    },
    vLength8 (key, val) {
      if (val) {
        if (val.length >=1 && val.length < 8) {
          return `은(는) 8자이상 입력합니다.`
        }
      }
    },
    vLengthBetween1and30 (key, val) {
      if (val) {
        if (val.length <=0 || val.length >= 30) {
          return `은(는) 길이 1~30자 이하 입력합니다.`
        }
      }
    },
    vLengthBetween1and200 (key, val) {
      if (val) {
        if (val.length <=0 || val.length >= 200) {
          return `은(는) 길이 1~200자 이하 입력합니다.`
        }
      }
    },
    vInteger (key, val) {
      const intRegex = /^\d+$/
      if (!intRegex.test(val) && val.length >=1  ) {
        return `은(는) 숫자(정수)만 입력합니다. `
      }
    },
    vNumber (key, val) {
      const intRegex = /^\d+$/;
      if (!intRegex.test(val) && val.length >=1) {
        return `은(는) 숫자만 입력합니다. `
      }
    },
    vFloat (key, val) {
      const floatRegex = /^((\d+(\.\d *)?)|((\d*\.)?\d+))$/;
      const intRegex = /^\d+$/;
			if ((floatRegex.test(val) || intRegex.test(val) ) && val.length >=1) {
        return `은(는) 숫자(실수)만 입력합니다. `
			}
    },
    vIP (key, val) {
			const Regex = new RegExp(/\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/);
			if (!Regex.test(val)) {
        return `은(는) 유효하지 않은 IP입니다.`
      }
    },
    //2020.08.13 Regex 확인할 것~, leekee
    // vURL (key, val) {
		// 	const Regex = /^(ftp|http|https):\/\/(([a-zA-Z0-9$\-_.+!*'(),;:&=]|%[0-9a-fA-F]{2})+@)?(((25[0-5]|2[0-4][0-9]|[0-1][0-9][0-9]|[1-9][0-9]|[0-9])(\.(25[0-5]|2[0-4][0-9]|[0-1][0-9][0-9]|[1-9][0-9]|[0-9])){3})|localhost|([a-zA-Z0-9\-\u00C0-\u017F]+\.)+([a-zA-Z]{2,}))(:[0-9]+)?(\/(([a-zA-Z0-9$\-_.+!*'(),;:@&=]|%[0-9a-fA-F]{2})*(\/([a-zA-Z0-9$\-_.+!*'(),;:@&=]|%[0-9a-fA-F]{2})*)*)?(\?([a-zA-Z0-9$\-_.+!*'(),;:@&=\/?]|%[0-9a-fA-F]{2})*)?(\#([a-zA-Z0-9$\-_.+!*'(),;:@&=\/?]|%[0-9a-fA-F]{2})*)?)?$/;
		// 	if (!Regex.test(val)) {
    //       return `유효하지 않은 URL입니다.`
    //   }
    // },
    // vEmail (key, val) {
		// 	const Regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		// 	if (!Regex.test(val)) {
    //     return `유효하지 않은 email입니다.`
    //   }
    // },
    vAlphaNumericDashUnerscore (key, val) {
			const Regex =  /^[a-zA-Z0-9-_]+$/;
			if (!Regex.test(val) && val.length >=1) {
        return `알파벳(A~Z,a~z)과 숫자(0~9), 하이픈(-),언더바(_)만 가능합니다.`
      }
    },
    vAlphaNumeric (key, val) {
			const Regex =  /^[a-zA-Z0-9]+$/;
			if (!Regex.test(val) && val.length >=1) {
        return `알파벳(A~Z,a~z)과 숫자(0~9)만 가능합니다.`
      }
    },
    vAlpha (key, val) {
			const Regex =  /^[a-zA-Z]+$/;
			if (!Regex.test(val) && val.length >=1) {
        return `알파벳(A~Z,a~z)과 숫자(0~9)만 가능합니다.`
      }
    },
    vPassword (key, val) {
			const Regex =  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/;
			if (!Regex.test(val)) {
        return `알파벳 대문자(1), 알파벳 소문자(1), 숫자(1), 특수문자(1)를 포함한 최소 8자이상 입력필요합니다.`
      }
    }
  }

  
  const validator = {
    init () {
      this.validates = new Map()
      return this
    },
  
    setup (key, expression) {
      const validates = expression.replace(/'/g, '').split('|')
      this.validates.set(key, validates)
    },
  
    validate (key, value) {
      const validates = this.validates.get(key)
      return validates
        .map(v => validateFns[v](key, value))
        .filter(v => !!v)
    }
  }
  
  export default validator.init()
  