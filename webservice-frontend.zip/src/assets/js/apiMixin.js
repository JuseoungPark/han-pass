import axios from 'axios'
import config from '@/assets/js/config'
import utils from '@/assets/js/utils'
import i18n from '@/locales'
// axios.defaults.validateStatus = () => true
//중복클릭 방지
import PreventDuplicateUtils from '@/assets/js/PreventDuplicateUtils.js'
const preventDuplicateUtils = new PreventDuplicateUtils()

export default {
    data() {
      return {
        loading: false,
        _moduleName: '',
        params: {}
      }
    },
    computed: {
      maxDate () {
        let date = this.$moment().format('YYYY-MM-DD')
        if (this.search.periodType === 'Daily') {
          //date = this.$moment().subtract(1, 'days').format('YYYY-MM-DD')
          date = this.$moment().format('YYYY-MM-DD')
        } else if (this.search.periodType === 'Weekly') {
          date = this.$moment().startOf('week').add((this.$moment().day() === 0) ? 0 : 7, 'day').format('YYYY-MM-DD')
        } else if (this.search.periodType === 'Monthly') {
          date = this.$moment().endOf('month').format('YYYY-MM-DD')
        }
        return date
      },
    },
    methods: {
      getDataList() {
        this.items = []
        this._moduleName = this.moduleName
        this.params = { pagable: false }
        this.requestApiAsync((res)=>{
          this.items = res.content
        })
      },
      
      async getvibrationTarget() {
        this.codes.vibrationTargetIds = []
        this._moduleName = 'v1/select/vibrationTarget'
        this.params = { siteId: this.userSite.siteId }
        let res = await this.requestApiSync()
        this.codes.vibrationTargetIds = res.content.map(item => {
          return {
            value: item.value,
            label: item.option2,
            pvsValue: item.pvsValue,
            ppvValue: item.ppvValue,
          }
        })
      },
      async getCompany() {
        this.codes.companyIds = []
        this._moduleName = 'v1/select/company'
        this.params = { siteId: this.userSite.siteId }
        let res = await this.requestApiSync()
        this.codes.companyIds = res.content.map(item => {
          return {
            value: item.value,
            label: item.option
          }
        })
      },
      async getCodes(code, moduleName) {
        this._moduleName = moduleName
        this.params = { siteId: this.userSite.siteId }
        let res = await this.requestApiSync()
        this.codes[code] = res.content.map(item => {
          return {
            value: item.value,
            label: item.option
          }
        })
      },
      async productDataAdd(item, params){
        if (item) {
          this.disabled.submit = true
          let d = {
            moduleName: this.moduleName,
            params: params,
          }
          await this.setData(d)
          await this.getDataList()
          this.resetData()
          this.visible.form = false
          this.toggleComponent('')
          this.disabled.submit = false
        }
      },
      dupClickChk(){
        let flag = true
        if (!preventDuplicateUtils.overClick(3000)) {
          utils.showToast(this.$t('message.rejectDuplicateClicks'))
          flag = false
        }
        return flag
      },
      dateVaildChk(){
        let flag = true
        if(this.search.date.length > 0){
          if (!this.$moment(this.search.date[1]).isSameOrBefore(this.$moment(this.search.date[0]).add(1, 'years').subtract(1, 'days'))) {
            utils.showToast(this.$t('message.searchPeriodCheck', [this.$t('commonLabel.yearLabel', [1])]))
            flag = false
          }
        }
        return flag
      },
      async saveDataAction(d){
        if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
        this.disabled.submit = true
        let isDupl = await this.isDuplication(d)
        if (isDupl) {
          d.params = this.form
          await this.setData(d)
          await this.getDataList()
          this.resetData()
        }
        this.disabled.submit = false
      },
      async isDuplication(d){
        this.loadingShow()
        return await axios.get( 
          config.getDbsApiUrl(`${d.moduleName}/duplication/${d.params[d.payload.keyword]}`), 
          { params: d.params } 
        ).then((res) => {
          this.loadingHide()
          return this.apiCodeValidate(res, 'dup', i18n.t('message.dulplicated', [d.payload.keywordName]))
        })
        .catch((error) => {
          this.loadingHide()
          // console.error('error', error)
          utils.showToast(this.$t(`${error}<br>${this.$t('message.contactSystemAdministrator')}`))
          return null
        })
      },
      async deleteData(){
        if (!this.dupClickChk()) return false; // 3초 이내 클릭 이벤트 체크
        this.disabled.delete = true
        let d = {
          moduleName: this.moduleName,
          params: this.form
        }
        await this.setDataDel(d)
        await this.getDataList()
        this.resetData()
        this.visible.dangerModal = false
        this.disabled.delete = false
      },  
      async setData(d, method){
        this.loadingShow()
        let req = {
          url: config.getDbsApiUrl(d.moduleName, d.params.dataId || null),
          method: (method)? method : (d.params.dataId || null) ? 'put' : 'post',
          data: d.params
        }
        if(d.type && d.type === 'file'){
          let formData = new FormData()
          Object.keys(d.params).forEach(key => {
            formData.append(key, d.params[key])
          })
          req.headers = { 'Content-Type': 'multipart/form-data'}
          req.data = formData
        }
        // console.log(req)
        await axios(req).then(res => {
          this.loadingHide()
          this.apiCodeValidate(res, 'set')
        }).catch(error => {
          this.loadingHide()
          utils.showToast(`${this.$t('message.contactSystemAdministrator')}`)
          console.error('error', error)
        })
      },
      async setDataDel(d){
        if (d.params.dataId) {
          this.loadingShow()
          let req = {
            url: config.getDbsApiUrl(d.moduleName, d.params.dataId || null),
            method: 'delete'
          }
          // console.log(req)
          return await axios(req).then(res => {
            this.loadingHide()
            this.apiCodeValidate(res, 'set', `It was deleted Normally`)
          })
          .catch(error => {
            this.loadingHide()
            utils.showToast(`${this.$t('message.contactSystemAdministrator')}`)
            console.error('error', error)
          })
        }        
      },  
      setFormValidate(){
        // 소수점 처리
        Object.keys(this.form).forEach(key => {
          if(this.$v.form[key] && this.$v.form[key].$params && this.$v.form[key].$params.decimalLimit){
            let limit = this.$v.form[key].$params.decimalLimit.limit
            this.form[key] = parseFloat(this.form[key]).toFixed(limit)
          }
        })
      },
      async requestApiDownload(d){
        let req = {
          url: config.getDbsApiUrl(d.moduleName),
          method: 'GET',
          responseType: 'blob'
        }
        await axios(req).then(res => {
          console.log(res)
          const data = res.request.response
          if (!window.navigator.msSaveOrOpenBlob) {
            console.log('1')
            const url = window.URL.createObjectURL(new Blob([data], { type: res.headers['content-type'] }))
            const link = document.createElement('a')
            link.href = url
            link.setAttribute('download', d.params.fileName)
            document.body.appendChild(link)
            link.click()
          } else {
            const url = window.navigator.msSaveOrOpenBlob(
              new Blob([data], { type: res.headers['content-type'] }),
              this.name
            )
            const link = document.createElement('a')
            link.href = url
            link.setAttribute('download', d.params.fileName)
            document.body.appendChild(link)
            link.click()
          }
        })
      },
      requestApiMutiAsync(callback, d) {
        let getApiObj = d.modules.map((item) => axios.get(config.getDbsApiUrl(item), {params: d.params}))
        this.loadingShow()
        axios.all(getApiObj).then(axios.spread((...res) => {
          this.loadingHide()
          let result = res.map((item) => this.apiCodeValidate(item))
          callback(result)
        }));
      },
      async requestApiMutiSync(d) {
        let getApiObj = d.modules.map((item) => axios.get(config.getDbsApiUrl(item), {params: d.params}))
        this.loadingShow()
        return await axios.all(getApiObj).then(axios.spread((...res) => {
          this.loadingHide()
          let result = res.map((item) => this.apiCodeValidate(item))
          return result
        }))
      },      
      requestApiAsync(callback) {
          this.loadingShow()
          axios.get( config.getDbsApiUrl(this._moduleName), {params: this.params} ).then((res) => {
            this.loadingHide()
            let result = this.apiCodeValidate(res)
            callback(result)
          })
          /*.catch((error) => {
            this.loadingHide()
            utils.showToast(`${this.$t('message.viewFailed')}<br>${error}`)
            utils.showToast(this.$t('message.contactSystemAdministrator'))
            // console.log(error)
            // callback({ error: error })
          })*/
      },
      async requestApiSync() {
        this.loadingShow()
        return await axios.get( config.getDbsApiUrl(this._moduleName), {params: this.params} ).then((res) => {
          this.loadingHide()
          let result = this.apiCodeValidate(res)
          return result
        })
        /*.catch((error) => {
          this.loadingHide()
          utils.showToast(`${this.$t('message.viewFailed')}<br>${error}`)
          utils.showToast(this.$t('message.contactSystemAdministrator'))
          // console.log(error)
        })*/
      },
      getApiMsg(msg){
        let message = msg
        if(msg.indexOf(' ') >= 0){
          if(msg.indexOf('require') >= 0 || msg.indexOf('duplicated') >= 0 || msg.indexOf('invalid') >= 0 || msg.indexOf('not number') >= 0){
            let d = msg.split(' ')
            if(d.length >= 2){
              let field = d[d.length - 1]
              let type = msg.replaceAll(field, '').trim()
              if(this.fields){
                let langkey = this.fields.find((item) => item.key === field)
                if(langkey) field = langkey.label
              }
              if(type.indexOf(' ') >= 0) type = msg.replaceAll(' ', '_')
              message = this.$t(`apimsg.${type}`, [field])
            }
          }else{
            let msgCode = msg.replaceAll(' ', '_')
            if(this.$t(`apimsg.${msgCode}`)) message = this.$t(`apimsg.${msgCode}`)
          }
        }
        return message
      },
      apiCodeValidate(res, type = 'get', msg) {
        if(type === 'get'){
          if (res.status === 200 && (res.data.message === 'success' || res.data.message === 'no data')) {
            return res.data    
          } else {
            utils.showToastRed(`${this.$t('message.viewFailed')}<br>${this.$t('message.contactSystemAdministrator')}<br>${this.getApiMsg(res.data.message)}`)
            res.data.content = []
            return res.data  
          }
        }else if(type === 'dup'){
          if (res.status === 200) {
            if (res.data.message === 'available') {
              return true
            } else {
              if(msg) utils.showToastRed(`${msg}`)
              return false
            }
          } else {
            utils.showToastRed(`${this.getApiMsg(res.data.message)}<br>${this.$t('message.contactSystemAdministrator')}`)
            return null
          }  
        }else{
          if ((res.status === 200 || res.status === 201) && res.data.message === 'success') {
            if(msg) utils.showToast(`${msg}`)
          }else{
            if (res.status <= 400) {
              utils.showToastRed(`${this.getApiMsg(res.data.message)}`)
            }else{
              utils.showToastRed(`${this.getApiMsg(res.data.message)}<br>${this.$t('message.contactSystemAdministrator')}`)
            }
          }
        }
      },
      setLoading(flag){
        this.visible.fullLoading = flag
        // console.log('loading', flag)
      },
      loadingShow(){
        this.loading = true
        if (this.visible){
          this.visible.fullLoading = true
          this.visible.loading = true
        } 
        // console.log('loadingShow', this.visible.fullLoading)
      },
      loadingHide(){
        if (this.visible && this.visible.loading) this.visible.loading = false
        if (this.visible && this.visible.fullLoading) this.visible.fullLoading = false
        if (this.loading) this.loading = false
        // console.log('loadingHide', this.visible.fullLoading)
      },
    }
}