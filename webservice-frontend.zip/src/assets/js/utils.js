import moment from 'moment'
import Toasted from 'vue-toasted';
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'
import VueAxios from 'vue-axios'
import config from '@/assets/js/config'
import i18n from '@/locales'

Vue.use(Vuex)
Vue.use(VueAxios, axios)
Vue.use(Toasted)

import CryptoJS from 'crypto-js'
import pbkdf2 from 'pbkdf2-sha256'

export default {
  getUserInformation() {
    let dbs = localStorage.dbs
    if (!dbs) return false
    dbs = JSON.parse(CryptoJS.AES.decrypt(localStorage.dbs, config.getDbsKey()).toString(CryptoJS.enc.Utf8))
    //dbs = JSON.parse(CryptoJS.AES.decrypt(localStorage.dbs, "Secret Passphrase").toString(CryptoJS.enc.Utf8))
    //console.log("getItem >>> : ", dbs)
    return dbs
  },
  getOptionCode(code) {
    let optionCode = []
    let dbs = localStorage.dbs
    if (!dbs) return false

    let getItems = JSON.parse(CryptoJS.AES.decrypt(localStorage.dbs, config.getDbsKey()).toString(CryptoJS.enc.Utf8)).codeList
    //let getItems = CryptoJS.AES.decrypt(localStorage.dbs, "Secret Passphrase").toString(CryptoJS.enc.Utf8).codeList
    // console.log("getItem >>> : ", getItems.find(x => x.option === code).commonCode)

    let codeObj = getItems.find(x => x.option === code).commonCode
    optionCode = codeObj.map((item) => {
      let d = {...item, label: item.option}
      if(code === 'diamterValue'){
        d.label = Number(d.label)
        d.value = Number(d.value)
      }
      return d
    })

    return optionCode
  },
  getLogMessage(tag) {
    return {
      tag: tag,
      get(...msg) {
        return `[${ moment(new Date()).format('DD.HHmm.SSS') }] [${ this.tag }] ${msg.join(' ')}`
      },
      log(level, ...msg) {
        return `[${ moment(new Date()).format('DD.HHmm.SSS') }] [${ level }] [${ this.tag }] ${msg.join(' ')}`
      },
      debug(...msg) {
        return this.log('DEBUG', msg)
      },
    }
  },

  showToast(message, duration) {
    //토스트 메세지
    Vue.toasted.show(message, {
        theme: "primary",
        position: 'top-right',
        duration : duration ? duration : 1500,
        fullWidth: false
    })
  },
  showToastRed(message, duration) {
    //토스트 메세지 에러 전용
    Vue.toasted.show(message, {
        theme: "bubble",
        position: 'top-right',
        duration : duration ? duration : 1500,
        fullWidth: false
    });
  },
  showToastRed2(message, duration) {
    //토스트 메세지 에러 전용
    Vue.toasted.show(message, {
        theme: "bubble",
        position: 'bottom-right',
        duration : duration ? duration : 10000,
        fullWidth: false
    });
  },
  twoDigit(d) {
    return ['0', d].join('').slice(-2)
  },
  lpadZero(d, size) {
    const dSize = new String(d).length
    size = dSize > size ? dSize : size
    return `0000000000${d}`.slice(size * -1)
  },
  setDecimal(value, point = 3){
    let v = '-'
    let intVal = parseFloat(value)
    
    if(!isNaN(intVal)){
      v = this.comma(intVal)
      if(!Number.isInteger(intVal)){
        let strVal = String(intVal)
        let dnum = strVal.substring(strVal.indexOf('.') + 1)
        // console.log(value, strVal, dnum.length)
        if(dnum.length > point) v = intVal.toFixed(point)
      }
    } 
    return v
  },
  getYYYYMMDDTHHmm(dateString) {
    const date = new Date(dateString)
    const buff = []
    buff.push([
        date.getFullYear(),
        this.lpadZero(date.getMonth() + 1, 2),
        this.lpadZero(date.getDate(), 2)
    ].join('-'))
    buff.push([
        this.lpadZero(date.getHours(), 2),
        this.lpadZero(date.getMinutes(), 2)
    ].join(':'))

    return buff.join(' ')
  },
  getYYYYMMDD(dateString) {

    const date = new Date(dateString)
    const buff = []
    buff.push([
        date.getFullYear(),
        this.lpadZero(date.getMonth() + 1, 2),
        this.lpadZero(date.getDate(), 2)
    ].join('-'))

    return buff.join(' ')
  },
  // setButtonLoadingText(selector) {
  //   const TAG = '[setButtonLoadingText]'

  //   const $button = $(selector)
  //   const loadingText = $button.data('loading-text')
  //   $button.html(loadingText)
  // },
  // setButotnText(selector, text) {
  //   const $button = $(selector)
  //   $button.text(text)
  // },
  comma(str) {
    str = String(str)
    return str.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
  },
  uncomma(str) {
    str = String(str);
    return str.replace(/[^\d]+/g, '');
  },
  numUnitCutting(value){
    let num = parseFloat(value)
    num = isNaN(num)?  '-' : num
    let numLen = parseInt(num).toString().length
    let oNum = 4
    if(numLen <= 4){
      num = this.setDecimal(num)
    }else{
      if(i18n.locale === 'ko'){
        if(numLen >= 5 && numLen <= 8){
          num = this.numUnitAbbr(oNum, '만', num)
        }else{
          num = this.numUnitAbbr(oNum, '억', num)
        }
      }else{
        if(numLen >= 5 && numLen <= 6){
          num = this.numUnitAbbr(oNum, 'K', num)
        }else if(numLen >= 7 && numLen <= 9){
          num = this.numUnitAbbr(oNum, 'M', num)
        }else{
          num = this.numUnitAbbr(oNum, 'B', num)
        }
      }
    }
    return num
  },
  /*
  * oNum : 출력자릿수
  * unit : 숫자단위
  * value : 해당숫자
  */
  numUnitAbbr(oNum, unit, value){
    let num = '0'
    let numLen = value.toString().length
    let digits = 3
    if(i18n.locale === 'ko'){
      digits = (unit === '억')? 8 : 4
    }else{
      digits = 3
      if(unit === 'M'){
        digits = 6
      }else if(unit === 'B'){
        digits = 9
      }
    }
    let pow = Math.pow(10, digits)
    let rNum = oNum - (numLen - digits)
    if(rNum < 0) rNum = 0
    num = (value / pow).toFixed(rNum)
    if(rNum === 0) num = this.comma(num)
    return `${num}${unit}`

  },
  humanReadableSize(size) {
    const KiB = 1024
    const MiB = 1024 * KiB
    const GiB = 1024 * MiB
    if (size > GiB) {
      return `${parseInt(size / GiB)}GB`
    } else if (size > MiB) {
      return `${parseInt(size / MiB)}MB`
    } else if (size > KiB) {
      return `${parseInt(size / KiB)}KB`
    } else {
      return `${size}B`
    }
  },
  multiLanguage(lang) {
    if (lang == 'ko') {
        return '입력'
    } else {
        return 'Enter'
    }
  },
  getByteLen (str) {
    return str.split('').map(s => s.charCodeAt(0))
      .reduce((prev, c) => (prev + ((c === 10) ? 2 : ((c >> 7) ? 2 : 1))), 0)
  },
  setPwEncrypt(email, password){
    let salt1 = Buffer.from(email, 'utf8').toString('base64')
    let dbOriginPw = pbkdf2(password, salt1, 3, 32).toString('base64');
    let today = moment.utc().format('YYYYMMDD')
    let salt2 = `${today}${email}`
    let requestPw = pbkdf2(dbOriginPw, salt2, 3, 32).toString('base64');
    return {
      dbOriginPw: dbOriginPw,
      requestPw: requestPw,
    }

  }
}
