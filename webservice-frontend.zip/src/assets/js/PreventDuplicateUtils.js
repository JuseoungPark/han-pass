import utils from '@/assets/js/utils'

export default function PreventDuplicateUtils() {

  this.click = false
  this.releaseTime = -1 /* miliseconds */
  this.timeoutId = null

  this.overClick = (releaseTime) => {
    const TAG = '[overClick]'
    this.releaseTime = (releaseTime) ? releaseTime : -1
    if (!this.click) {
      // utils.showToast('첫번째 클릭입니다.')
      //console.log(TAG, '클릭됨')
      this.click = true
      this.setTimeout()

      return true
    } else {
      //utils.showToastRed('중복클릭입니다.')
      //utils.showToast(this.$t('message.rejectDuplicateClicks'))      
      //console.log(TAG, '중복클릭됨')
      this.clearTimeout()
      this.setTimeout()

      return false
    }
  }

  this.release = () => {
    this.click = false
  }

  this.setTimeout = () => {
    if (this.releaseTime == -1) {
      return
    }
    this.timeoutId = setTimeout(() => {
      this.click = false
    }, this.releaseTime)
  }

  this.clearTimeout = () => {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId)
      this.timeoutId = null
    }
  }
}