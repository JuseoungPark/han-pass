export default {

  profiles: {
    status: 'local',
    //status: 'aws',

    local: {
      auth_api_server:'http://devdbsapi-env.eba-capzcuca.ap-northeast-2.elasticbeanstalk.com',
      dbs_api_server: 'http://devdbsapi-env.eba-capzcuca.ap-northeast-2.elasticbeanstalk.com',
      //auth_api_server: 'http://192.17.20.112:80',
      //dbs_api_server: 'http://192.17.20.112:80',
      sensor_api_server: 'https://beta-sensor-api.xxxx.elasticbeanstalk.com',
      selected_scheme: 'beta',
      view_server: 'http://localhost:5000',
      key: 'Secret Passphrase'
    },
    aws: {
      auth_api_server:'http://dbs-api-operation-ALB-1401096882.ap-northeast-2.elb.amazonaws.com',
      dbs_api_server: 'http://dbs-api-operation-ALB-1401096882.ap-northeast-2.elb.amazonaws.com',
      sensor_api_server: 'https://beta-sensor-api.xxxx.elasticbeanstalk.com',
      selected_scheme: 'beta',
      view_server: 'http://localhost:5000',
      key: 'Secret Passphrase'
    },
    test: { // test for dev
      //api server address 수정할 것
      auth_api_server:  'http://devdbsapi-env.eba-capzcuca.ap-northeast-2.elasticbeanstalk.com',
      dbs_api_server: 'http://devdbsapi-env.eba-capzcuca.ap-northeast-2.elasticbeanstalk.com',
      // auth_api_server: 'http://beta-auth-api.mw39fxqrf6.ap-northeast-2.elasticbeanstalk.com',
      // dbs_api_server: 'http://beta-dbs-api.mw39fxqrf6.ap-northeast-2.elasticbeanstalk.com',
      sensor_api_server: 'https://beta-sensor-api.xxxx.elasticbeanstalk.com',
      selected_scheme: 'beta',
      view_server: 'https://dbs.beta.hanwha.com/v1',
      key: 'Secret Passphrase'
    },
    dev: {
      auth_api_server: 'https://auth-api.beta.hanwha.com',
      dbs_api_server: 'https://dbs-api.beta.hanwha.com',
      sensor_api_server: 'https://sensor-api.beta.hanwha.com',
      selected_scheme: 'beta',
      view_server: 'https://dbs.beta.hanwha.com/v1',
      key: 'Secret Passphrase'
    },
    prod: {
      auth_api_server: 'https://auth-api.hanwha.com',
      dbs_api_server: 'https://dbs-api.hanwha.com',
      sensor_api_server: 'https://sensor-api.hanwha.com',
      selected_scheme: 'prod',
      view_server: 'https://dbs.hanwha.com/v1',
      key: 'Secret Passphrase'
    },
  },

  getDbsKey() {
    return this.profiles[this.profiles.status].key
  },
  getAuthApiAddress() {
    return this.profiles[this.profiles.status].auth_api_server
  },
  getDbsApiAddress() {
    return this.profiles[this.profiles.status].dbs_api_server
  },
  getSensorApiAddress() {
    return this.profiles[this.profiles.status].sensor_api_server
  },
  getViewServer() {
    return this.profiles[this.profiles.status].view_server
  },
  geSelectedScheme() {
    return this.profiles[this.profiles.status].selected_scheme
  },

  getAuthApiUrl(module,id) {
    const apiUri = `${ this.getAuthApiAddress() }/v1/auth/${module}`
    return (id) ? `${ apiUri }/${ id }` : apiUri
  },
  getDbsApiUrl(module,id) {
    const apiUri = `${ this.getDbsApiAddress() }/${module}`
    return (id) ? `${ apiUri }/${ id }` : apiUri
  },

  getDbsApiUrlV1(module,id) {
    const apiUri = `${ this.getDbsApiAddress() }/v1/${module}`
    return (id) ? `${ apiUri }/${ id }` : apiUri
  },

  getDownloadDbsApi() {
    return `${ this.getDbsApiAddress() }/v1/download`
  },

  getDownloadSensorApi() {
    return `${ this.getSensorApiAddress() }/v1/download`
  },

  getDownloadDbsUri() {
    // const TAG = '[getDownloadDbsApi]'
    const uri = this.getDownloadDbsApi()
    // console.log(TAG, 'uri', uri)
    return uri
  },
  getDownloadSensorUri() {
    // const TAG = '[getDownloadSensorApi]'
    const uri = this.getDownloadSensorApi()
    // console.log(TAG, 'uri', uri)
    return uri
  },

  getUploadDbsApi() {
    return `${ this.getDbsApiAddress() }/v1/upload`
  },

  getUploadSensorApi() {
    return `${ this.getSensorApiAddress() }/v1/upload`
  },

  getUploadDbsUri() {
    // const TAG = '[getUploadDbsApi]'
    const uri = this.getUploadDbsApi()
    // console.log(TAG, 'uri', uri)
    return uri
  },

  getUploadSensorUri() {
    // const TAG = '[getUploadSensorApi]'
    const uri = this.getUploadSensorApi()
    // console.log(TAG, 'uri', uri)
    return uri
  },

  // getUploadDbsUri(id) {
  //   const TAG = '[getUploadDbsUri]'
  //   const uri = `${ this.getEventPageApi( id ) }/upload`
  //   console.log(TAG, 'uri', uri)
  //   return uri
  // },

  // getDownloadUri() {
  //   // const TAG = '[getDownloadUri]'
  //   const uri = this.getDownloadApi()
  //   // console.log(TAG, 'uri', uri)
  //   return uri
  // },
  // getPromotionApi(id) {
  //   const uri = `${ this.getApiAddress() }/v1`
  //   return (id) ? `${ uri }/${ id }` : uri
  // },
  // getViewUriByPromotion(item) {
  //   //const TAG = '[getViewUriByPromotion]'
  //   const {promotionId, promotionStartDate} = item
  //   // console.log(TAG, 'promotionId', promotionId)
  //   // console.log(TAG, 'promotionStartDate', promotionStartDate)
  //   const YYYY = promotionStartDate.substr(0, 4)
  //   const MM = promotionStartDate.substr(5, 2)
  //   // console.log(TAG, 'YYYY', YYYY)
  //   // console.log(TAG, 'MM', MM)
  //   const uri = `${ this.getViewServer() }/${ YYYY }/${ MM }/${ promotionId }`
  //   // console.log(TAG, 'uri', uri)
  //   return uri
  // },
  getViewUri(id) {
    const uri = `${ this.getViewServer() }`
    return (id) ? `${ uri }/${ id }` : uri
  }
}
