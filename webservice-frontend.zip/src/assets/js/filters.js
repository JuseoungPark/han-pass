import Vue from 'vue'
import utils from '@/assets/js/utils'

Vue.filter('Commas', (value) => {
  return utils.comma(value)
})

Vue.filter('NumUnitCutting', (value) => {
  return utils.numUnitCutting(value)
})

Vue.filter('SetDecimal', (value) => {
  return utils.setDecimal(value)
})