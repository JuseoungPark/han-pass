import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'
Vue.use(Vuex)

const enhanceAccessToeken = () => {
  const {accessToken} = localStorage
  if (!accessToken) return
  axios.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
}
enhanceAccessToeken()

import common from '@/store/modules/common/common.js'
import uxui from '@/store/modules/coreui/uxui.js'
import loginLogout from '@/store/modules/user/loginLogout.js'
import blastLibrary from '@/store/modules/blastLibrary/blastLibrary.js'

const store = new Vuex.Store({
  modules: {
    common: common,
    uxui: uxui,
    loginLogout: loginLogout,
    blastLibrary: blastLibrary,
  }
})

export default store
