import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'
import config from '@/assets/js/config'
import utils from '@/assets/js/utils'
import i18n from '@/locales'
Vue.use(Vuex)

const common = {
  namespaced: true,
  state: {
    //
  },
  getters: {
    //
  },
  mutations: {
    //
  },
  actions: {
    async getDataList ({ commit }, payload) {
      return await axios.get(config.getDbsApiUrl(payload.moduleName), {
        params: payload.params
      }).then(res => {
          if (res.status === 200) {
            return res.data
          } else {
            utils.showToast(this.$t('message.viewFailed'))
            utils.showToast(this.$t('message.contactSystemAdministrator'))
          }
      }).catch(err => {
        console.error('error', err)
      })
    },
    async isDuplication ({ commit }, payload) {
      return await axios.get(config.getDbsApiUrl(`${payload.moduleName}/duplication/${payload.params[payload.keyword]}`), {
        params: payload.params
      }).then(res => {
          if (res.status === 200) {
            if (res.data.message === 'available') {
              return true
            } else {
              utils.showToast(i18n.t('message.dulplicated', [payload.keywordName]))
              return false
            }
          } else {
            utils.showToast('Contact your System Administrator')
            return null
          }
      }).catch(err => {
        console.error('error', err)
        utils.showToast('Contact your System Administrator')
        return null
      })
    },
    async saveData({ commit }, payload) {
      await axios[(payload.params.dataId || null) ? 'put' : 'post'](
        config.getDbsApiUrl(payload.moduleName, payload.params.dataId || null),
        payload.params)
      .then(res => {
        console.log(res)
        // msg?
      }).catch(err => {
        utils.showToast('Contact your System Administrator')
        console.error('error', err)
        // error page go?
      })
    },
    async putData({ commit }, payload) {
      await axios['put'](
        config.getDbsApiUrl(payload.moduleName),
        payload.params)
      .then(res => {
        console.log(res)
        // msg?
      }).catch(err => {
        utils.showToast('Contact your System Administrator')
        console.error('error', err)
        // error page go?
      })
    },
    async deleteSelectedData({ commit }, payload) {
      if (payload.params.dataId) {
        return await axios.delete(config.getDbsApiUrl(payload.moduleName, payload.params.dataId || null))
        .then(res => {
          if (res.status === 200) {
            utils.showToast('It was deleted Normally')
          } else {
            utils.showToast('Contact your System Administrator')
          }
          console.log(res)
        })
        .catch(err => {
          // utils.showToast(err.response.data.message)
          utils.showToast('Contact your System Administrator')
        })
      }
    },
    async saveFileData({ commit }, payload) {
      const formData = new FormData()
      Object.keys(payload.params).forEach(key => {
        formData.append(key, payload.params[key])
      })
      await axios[(payload.params.dataId || null) ? 'put' : 'post'](
        config.getDbsApiUrl(payload.moduleName, payload.params.dataId || null),
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
      .then(res => {
        console.log(res)
      }).catch(err => {
        utils.showToast('Contact your System Administrator')
        console.error('error', err)
        // error page go?
      })
    },
    async download ({ commit }, payload) {
      await axios({
        url: config.getDbsApiUrl(payload.moduleName),
        method: 'GET',
        responseType: 'blob'
      })
      .then(res => {
        const data = res.request.response
        if (!window.navigator.msSaveOrOpenBlob) {
          console.log('1')
          const url = window.URL.createObjectURL(new Blob([data], { type: res.headers['content-type'] }))
          const link = document.createElement('a')
          link.href = url
          link.setAttribute('download', payload.params.fileName)
          document.body.appendChild(link)
          link.click()
        } else {
          const url = window.navigator.msSaveOrOpenBlob(
            new Blob([data], { type: res.headers['content-type'] }),
            this.name
          )
          const link = document.createElement('a')
          link.href = url
          link.setAttribute('download', payload.params.fileName)
          document.body.appendChild(link)
          link.click()
        }
      })
      .catch(err => {
        console.error('error', err)
      })
    },
    async imageUrl ({ commit }, payload) {
      return await axios({
        url: config.getDbsApiUrl(payload.moduleName),
        method: 'GET',
        responseType: 'arraybuffer'
      })
      .then(res => {
        const data = res.request.response
        var arrayBufferView = new Uint8Array(data)
        var blob = new Blob([arrayBufferView], { type: 'image/jpeg' })
        var urlCreator = window.URL || window.webkitURL
        var imageUrl = urlCreator.createObjectURL(blob)
        return imageUrl
      })
      .catch(err => {
        console.error('error', err)
      })
    }
  }
}
export default common
