import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex)

const uxui = {
    namespaced: true,
    state: {
        sidebarShow: 'responsive',
        sidebarMinimize: false,
        asideShow: false,
        darkMode: false,
    },
    getters: {

    },
    mutations: {
        
        //----------------------------------------------------------------------------//
        toggleSidebarDesktop (state) {
            let TAG = '[uxui store] [toggleSidebarDesktop]'
            console.log(TAG)
            const sidebarOpened = [true, 'responsive'].includes(state.sidebarShow)
            state.sidebarShow = sidebarOpened ? false : 'responsive'
        },
        toggleSidebarMobile (state) {
            const sidebarClosed = [false, 'responsive'].includes(state.sidebarShow)
            state.sidebarShow = sidebarClosed ? true : 'responsive'
        },
        set (state, [variable, value]) {
            state[variable] = value
        },
        toggle (state, variable) {
            state[variable] = !state[variable]
        },
        setToggle (state, [variable, value]) {
            state[variable] = value
            //console.log("setToggle value", value)
        },
    
        // -------------------------------------------------//
    },
    actions: {
        toggleCompleted(context, todo) {
            Vue.http.post('api/vue/toggle-status', { id: todo.id }).then(function(response) {
                if (response.status == 200) {
                    context.commit('TOGGLE_COMPLETED', todo)
      
                }
            })
          },
      
          removeTodo(context, todo) {
              Vue.http.post('api/vue/delete-todo', { id: todo.id }).then(function(response) {
                  if (response.status == 200) {
                      context.commit('REMOVE_TODO', todo)
      
                  }
              })
          }      
      
    }
}

export default uxui