import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'
import config from '@/assets/js/config'
import utils from '@/assets/js/utils'
import i18n from '@/locales'

Vue.use(Vuex)

const blastLibrary = {
    namespaced: true,
    state: {
        dataName: '',
        status: '',
        data: [],
        dataList: [],
        dataFile: [],
        selectedDataInfo: {},
        // blastList에서 선택된 blast 정보
        blastInfo: {
            siteId: 0,
            blastId: 0,
            blastName: '-',
            lat: 0,
            lng: 0
        },
        // 검색된 blast list 정보
        blastList: [],
        // blast library 하위 탭 정보
        blastTabData: [
            { name: 'Summary Report', link: 'summaryReport' },
            { name: 'Drilling', link: 'drilling' },
            { name: 'Charging', link: 'charging' },
            { name: 'Firing', link: 'firing' },
            { name: 'Fragmentation', link: 'fragmentation' },
            { name: 'Vibration & Sound', link: 'vibrationSound' },
            { name: 'Productivity / Cost', link: 'productivityCost' },
        ],
    },
    getters: {
        getStatus : state => state.status,
        getData : state => state.data,
        getDataList : state => state.dataList,
        getSelectedData : state => state.selectedDataInfo,
        getDataListPageInfo : state => state.dataListPageInfo,
        getBlastInfo(state) {
console.log('getBlastInfo...')
console.log(state.blastInfo)
            state.blastInfo.siteId = (state.blastInfo.siteId==undefined?0:state.blastInfo.siteId)
            state.blastInfo.blastId = (state.blastInfo.blastId==undefined?0:state.blastInfo.blastId)
            if (state.blastInfo.blastId == 0) {
console.log(localStorage.blastInfo)
                if (localStorage.blastInfo != undefined) {
                    state.blastInfo = JSON.parse(localStorage.blastInfo)
                }else{
                    state.blastInfo.siteId = 0
                    state.blastInfo.blastId = 0
                    state.blastInfo.blastName = '-'

                    state.blastList = []
                }
console.log(state.blastInfo)
            }
            return state.blastInfo
        },
        getBlastList(state) {
            if (state.blastInfo.blastId == 0) {
                if (localStorage.blastList != undefined) {
                    state.blastList = JSON.parse(localStorage.blastList)
                }else{
                    state.blastList = []
                }
            }
            return state.blastList
        },
        getBlastTabData : state => state.blastTabData,
    },
    mutations: {
        putData (state, playload) {
            state.data = playload
        },
        setStatus (state, playload) {
            state.status = playload
        },
        setData (state, playload) {
            state.data = playload
        },
        setDataList (state, playload) {
            state.dataList = playload
        },
        setDataList2 (state, playload) {
            state.dataList = playload
        },
        setFileData (state, playload) {
            state.dataFile = playload
        },
        setSelectedData (state, playload) {
            state.selectedDataInfo = playload
        },
        setDataListPageInfo (state, playload) {
            state.dataListPageInfo = playload
        },
        setBlastInfo (state, playload) {
            state.blastInfo = playload
        },
        setBlastList (state, playload) {
            state.blastList = playload
        },
    },
    actions: {
        async putData(store, payload) {
            await axios['put'](
                config.getDbsApiUrl(payload.moduleName),
                payload.params
            ).then(response => {
                store.commit('setData', response.data)
                utils.showToast(i18n.t('message.registeredNormally'))
            }).catch(err => {
                console.error('error', err)

                store.commit('setData', null)
                utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
            })
        },
        async setDataList(store, payload) {
            let url = config.getDbsApiUrl(payload.moduleName) + "?" + payload.params.join("&")
            await axios.get(url)
            .then(response => {
                if (response.status==200 || response.status==201) {
                    store.commit('setData', response.data)
                    store.commit('setDataList', response.data.content)
                    store.commit('setDataListPageInfo', {
                        pageable: response.data.pageable,
                        totalElements: response.data.totalElements,
                        totalPages: response.data.totalPages,
                        size: response.data.size,
                        page: response.data.page
                    })
                } else {
                    utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
                }
                store.commit('setStatus', '200')
            }).catch(error => {
                utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
                store.commit('setStatus', error.response.status)

                console.error('error', error)
            })
        },
        async setDataList2(store, payload) {
            const formData = new FormData()
            Object.keys(payload.params).forEach(key => {
//console.log(key+' / '+JSON.stringify(payload.params[key]))
                //formData.append(key, JSON.stringify(payload.params[key]))
                formData.append(key, payload.params[key])
            })

            await axios.get(config.getDbsApiUrl(payload.moduleName),
                formData
                ,{
                    headers: {
                      'Content-Type': 'application/x-www-form-urlencoded',
                    }
                }
            )
            .then(response => {
                if (response.status==200 || response.status==201) {
                    store.commit('setData', response.data)
                    store.commit('setDataList', response.data.content)
                    store.commit('setDataListPageInfo', {
                        pageable: response.data.pageable,
                        totalElements: response.data.totalElements,
                        totalPages: response.data.totalPages,
                        size: response.data.size,
                        page: response.data.page
                    })
                } else {
                    utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
                }
                store.commit('setStatus', '200')
            })
            .catch(error => {
                utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
                store.commit('setStatus', error.response.status)

                console.error('error', error)
            })
        },
        async setFileData(store, payload) {
//console.log('blastLibrary.saveFileData...')
//console.log(payload.params)
            const formData = new FormData()
            Object.keys(payload.params).forEach(key => {
//console.log(key+' / '+JSON.stringify(payload.params[key]))
                //formData.append(key, JSON.stringify(payload.params[key]))
                formData.append(key, payload.params[key])
            })
// console.log(formData)
//  console.log('1--------')
//              formData.forEach((value,key) => {
//                  console.log(key+" , "+(value))
//              })
// console.log('2--------')
//             for (let [key, value] of formData.entries()) {
//                 console.log(`${key} ${value}`)
//             }

            await axios['post'](
                config.getDbsApiUrl(payload.moduleName, null),
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
            ).then(res => {
                console.log(res)
                utils.showToast(i18n.t('message.registeredNormally'))
                store.commit('setFileData', res.data.content)
            }).catch(err => {
                console.error('error', err)
                utils.showToastRed(i18n.t('message.contactSystemAdministrator'))
                // error page go?
            })
        },
        async setSelectedData (store, payload) {
            store.commit('setSelectedData', payload)
        },
        async setBlastInfo (store, payload) {
            localStorage.setItem('blastInfo', JSON.stringify(payload))

            store.commit('setBlastInfo', payload)
        },
        async setBlastList (store, payload) {
            localStorage.setItem('blastList', JSON.stringify(payload))

            store.commit('setBlastList', payload)
        },
        async download(store, payload) {
//console.log('download...')
//console.log(payload.moduleName)
            await axios({
              url: config.getDbsApiUrl(payload.moduleName),
              method: 'GET',
              responseType: 'blob'
            })
            .then(res => {
              const data = res.request.response
//console.log(res)
//console.log(data)
              if (!window.navigator.msSaveOrOpenBlob) {
                const url = window.URL.createObjectURL(new Blob([data], { type: res.headers['content-type'] }))
                const link = document.createElement('a')
                link.href = url
                link.setAttribute('download', payload.params.fileName)
                document.body.appendChild(link)
                link.click()
              } else {
                const url = window.navigator.msSaveOrOpenBlob(
                  new Blob([data], { type: res.headers['content-type'] }),
                  this.name
                )
                const link = document.createElement('a')
                link.href = url
                link.setAttribute('download', payload.params.fileName)
                document.body.appendChild(link)
                link.click()
              }
            })
            .catch(err => {
              console.error('error', err)
            })
        }
    }
}
export default blastLibrary