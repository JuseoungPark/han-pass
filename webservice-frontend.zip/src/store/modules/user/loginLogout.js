import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'
import config from '@/assets/js/config'
import utils from '@/assets/js/utils'
import i18n from '@/locales'
Vue.use(Vuex)

//import VueCryptojs from 'vue-cryptojs'
//Vue.use(VueCryptojs)

import CryptoJS from 'crypto-js'

const enhanceAccessToeken = () => {
  const {dbs} = localStorage
  if (!dbs) return
  //const accessToken = JSON.parse(CryptoJS.AES.decrypt(localStorage.dbs, "Secret Passphrase").toString(CryptoJS.enc.Utf8)).accessToken
  const accessToken = utils.getUserInformation().accessToken
  if (!accessToken) return
  axios.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
}
enhanceAccessToeken()

const loginLogout = {
    namespaced: true,
    state: {
        accessToken: null,
        userName : "",
        userCellphoneNo : "",
        userId : "",
        email : "",
        userThemaType : "",
        userLangType : "",
        userCompany : "",
        userSite : [],
        userPermissionList:[],
        userMenuList:[],
        codeList:[],
        isAuthenticated: false,
        expiration: "",
        selectedUserSite: {},
        userData:{}
    },
    getters: {
      getUserData : state => state.userData,
      getUserName : state => state.userName,
      getUserCellphoneNo : state => state.userCellphoneNo,
      getUserId : state => state.userId,
      getUserEmail : state => state.email,
      getUserThemaType : state => state.userThemaType,
      getUserLangType : state => state.userLangType,
      getUserCompany : state => state.userCompany,
      getUserSite : state => state.userSite,
      getExpiration : state => state.expiration,
      getUserPermissionList : state => state.userPermissionList,
      getUserMenuList: state => state.userMenuList,
      getCodeList : state => state.codeList,
      getIsAuthenticated : state => state.isAuthenticated,
      getSelectedUserSite : state => state.selectedUserSite,
    },
    mutations: {
        reSetUserData (state, data) {
          state.userData.accessToken = state.accessToken
          state.userData.isAuthenticated = state.isAuthenticated
          state.userData.userName = state.userName
          state.userData.userLangType = state.userLangType
          state.userData.userCompany = state.userCompany
          state.userData.userCellphoneNo = state.userCellphoneNo
          state.userData.userId = state.userId
          state.userData.email = state.email
          state.userData.userThemaType = state.userThemaType
          state.userData.expiration = state.expiration
          state.userData.userPermissionList = state.selectedUserSite.userPermissionList
          state.userData.userMenuList = state.selectedUserSite.userMenuList
          state.userData.codeList =  state.codeList // _nav.js 형식으로
          state.userData.userSite = state.userSite // n개 이상 일 수 있다.
          state.userData.selectedUserSite = state.selectedUserSite // n개 이상 일 수 있다.

          localStorage.userData = JSON.stringify(state.userData)
          localStorage.dbs = CryptoJS.AES.encrypt(JSON.stringify(state.userData), config.getDbsKey()).toString()
        },
        reSetUserThemaType (state, data) {
          state.userThemaType = data.themaType
          //console.log("state.userThemaType : >>> ", state.userThemaType )
        },
        reSetUserLangType (state, data) {
          state.userLangType = data.userLanguageType
          //console.log("state.userLangType : >>> ", state.userLangType )
        },
        reSetUserCellphoneNo (state, data) {
          state.userCellphoneNo = data.cellphoneNo
          //console.log("state.userCellphoneNo : >>> ", state.userCellphoneNo )
        },
        reSetUserInfo (state, data) {
            state.accessToken = data.accessToken
            state.isAuthenticated = true
            state.userName = data.userName
            state.userLangType = data.userLangType
            state.userCompany = data.userCompany
            state.userCellphoneNo = data.userCellphoneNo
            state.userId = data.userId
            state.email = data.email
            state.userThemaType = data.userThemaType
            state.expiration = data.expiration
            state.userPermissionList = state.selectedUserSite.userPermissionList
            state.userMenuList =  state.selectedUserSite.userMenuList
            state.codeList =  data.codeList // _nav.js 형식으로
            state.userSite = data.userSite // n개 이상 일 수 있다.
        },
        reSetSelectedSiteInfo (state, data) {
          state.selectedUserSite = {}
          state.selectedUserSite.id = data.id
          state.selectedUserSite.siteId = data.siteId
          state.selectedUserSite.siteName = data.siteName
          state.selectedUserSite.timezoneType = data.timezoneType
          state.selectedUserSite.countryCodeName = data.countryCodeName
          state.selectedUserSite.userPermissionList = data.userPermissionList
          state.selectedUserSite.userMenuList = data.userMenuList
          state.selectedUserSite.currency = data.currency
          state.selectedUserSite.currencyName = data.currencyName
          state.selectedUserSite.latitudeValue = data.latitudeValue
          state.selectedUserSite.longitudeValue = data.longitudeValue
          state.selectedUserSite.authorityName = data.authorityName

          //localStorage.selectedUserSite = CryptoJS.AES.encrypt(JSON.stringify(state.selectedUserSite), "Secret Passphrase").toString()
          //console.log("OK localStorage.selectedUserSite >>> : ", localStorage.selectedUserSite)
        },
        reSetSelectedMenuList (state, data) {
            state.userMenuList =  data
        },
        reSetSelectedPermissionList (state, data) {
            state.userPermissionList = data
        },
        LOGIN (state, {message, data} ) {
            // console.log(message)

            let TAG = 'LOGIN MUTATION'
console.log(TAG, 'data:', data);
            // console.log(TAG, 'response.data.accessToken:', data.accessToken);

//            const itemKey = CryptoJS.AES.encrypt("accessToken", "Secret Passphrase").toString()
//            localStorage.setItem(itemKey, CryptoJS.AES.encrypt(data.accessToken, "Secret Passphrase").toString())

            state.accessToken = data.accessToken
            state.isAuthenticated = true
            state.userName = data.userName
            state.userLangType = data.userLangType
            state.userCompany = data.userCompany
            state.userCellphoneNo = data.userCellphoneNo
            state.userId = data.userId
            state.email = data.email
            state.userThemaType = data.userThemaType
            state.expiration = data.expiration
            state.userPermissionList = data.userSite[0].userPermissionList
            state.userMenuList =  data.userSite[0].userMenuList
            // state.codeList =  JSON.stringify(data.codeList) // _nav.js 형식으로
            // state.userSite = JSON.stringify(data.userSite) // n개 이상 일 수 있다.
            state.codeList =  data.codeList // _nav.js 형식으로
            state.userSite = data.userSite // n개 이상 일 수 있다.

            state.selectedUserSite = {}
            if (data.lastSite != -1) {
              let index = data.userSite.findIndex(y=>y.siteId == +data.lastSite)
              if (index < 0) index = 0

              state.selectedUserSite.id = index
              state.selectedUserSite.siteId = data.userSite[index].siteId
              state.selectedUserSite.siteName = data.userSite[index].siteName
              state.selectedUserSite.timezoneType = data.userSite[index].timezoneType
              state.selectedUserSite.countryCodeName = data.userSite[index].countryCodeName
              state.selectedUserSite.userPermissionList = data.userSite[index].userPermissionList
              state.selectedUserSite.userMenuList = data.userSite[index].userMenuList
              state.selectedUserSite.currency = data.userSite[index].currency
              state.selectedUserSite.currencyName = data.userSite[index].currencyName
              state.selectedUserSite.latitudeValue = data.userSite[index].latitudeValue
              state.selectedUserSite.longitudeValue = data.userSite[index].longitudeValue
              state.selectedUserSite.authorityName = data.userSite[index].authorityName
              state.userPermissionList = data.userSite[index].userPermissionList
              state.userMenuList =  data.userSite[index].userMenuList
            }

            //console.log("state.selectedUserSite", state.selectedUserSite)

            // 토큰을 로컬 스토리지에 저장, (브라우저 화면을 갱신하면 토큰정보가 날아간다. )
            // localStorage.accessToken = data.accessToken
            // localStorage.isAuthenticated = true
            // localStorage.userName = data.userName
            // localStorage.userCompany = data.userCompany
            // localStorage.userLangType = data.userLangType
            // localStorage.userCellphoneNo = data.userCellphoneNo
            // localStorage.userId = data.userId
            // localStorage.userThemaType = data.userThemaType
            // localStorage.expiration = data.expiration
            // localStorage.userPermissionList = data.userSite[0].userPermissionList
            // localStorage.userMenuList =  JSON.stringify(data.userSite[0].userMenuList)
            // localStorage.codeList =  JSON.stringify(data.codeList)
            // localStorage.userSite = JSON.stringify(data.userSite) // n개 이상 일 수 있다.

            //임시로 첫번째 사이트 정보를 지정한다.
/* dhgo.
            let selectedUserSite = {}
            selectedUserSite.id = 0
            selectedUserSite.siteId = data.userSite[0].siteId
            selectedUserSite.siteName = data.userSite[0].siteName
            selectedUserSite.countryCodeName = data.userSite[0].countryCodeName
            selectedUserSite.userPermissionList = data.userSite[0].userPermissionList
            selectedUserSite.userMenuList = data.userSite[0].userMenuList
            selectedUserSite.currency = data.userSite[0].currency
            selectedUserSite.currencyName = data.userSite[0].currencyName
            selectedUserSite.latitudeValue = data.userSite[0].latitudeValue
            selectedUserSite.longitudeValue = data.userSite[0].longitudeValue
*/
            //localStorage.selectedUserSite = JSON.stringify(selectedUserSite)

            //const decryptedText = CryptoJS.AES.decrypt(localStorage.dbs, "Secret Passphrase").toString(CryptoJS.enc.Utf8)
            //-----------------------------------------------------//
            localStorage.dbs = CryptoJS.AES.encrypt(JSON.stringify(data), config.getDbsKey()).toString()
            //localStorage.selectedUserSite = CryptoJS.AES.encrypt(JSON.stringify(selectedUserSite), "Secret Passphrase").toString()

            //localStorage.dbs2 = JSON.stringify(data)
            //localStorage.selectedUserSite2 =JSON.stringify(selectedUserSite)
          },
          LOGOUT (state) {
            //토큰 정보 삭제
            state.accessToken = null
            // delete localStorage.accessToken
            // delete localStorage.isAuthenticated
            // delete localStorage.userName
            // delete localStorage.userLangType
            // delete localStorage.userCompany
            // delete localStorage.userSite
            // delete localStorage.expiration
            // delete localStorage.codeList

            // delete localStorage.userCellphoneNo
            // delete localStorage.userId
            // delete localStorage.userThemaType

            delete localStorage.userPermissionList
            delete localStorage.userMenuList
            delete localStorage.selectedUserSite
            delete localStorage.blastInfo
            delete localStorage.blastList
            //-----------------------------------------------------//
            delete localStorage.dbs
          },
    },
    actions: {
        /*async reSetUserData (store, payload) {
          store.commit('reSetUserData',payload)
        },*/
        async reSetUserThemaType (store, payload) {
          store.commit('reSetUserThemaType',payload.params)
          //console.log("reSetUserThemaType payload >>>> ", payload)
        },
        async reSetUserLangType (store, payload) {
          store.commit('reSetUserLangType',payload.params)
          //console.log("reSetUserLangType payload >>>> ", payload)
        },
        async reSetUserCellphoneNo (store, payload) {
          store.commit('reSetUserCellphoneNo',payload.params)
          //console.log("reSetUserCellphoneNo payload >>>> ", payload)
        },
        async reSetUserInfo(store, payload) {
            store.commit('reSetUserInfo',payload)
          },
        async reSetSelectedPermissionList (store, payload) {
            store.commit('reSetSelectedPermissionList',payload)
        },
        async reSetSelectedSiteInfo (store, payload) {
            store.commit('reSetSelectedSiteInfo',payload)
          },
        async reSetSelectedMenuList (store, payload) {
            store.commit('reSetSelectedMenuList',payload)
        },
        async reSetUserData (store, payload) {
          store.commit('reSetUserData',payload)
        },
        async profileEdit ({commit}, payload) {
          let req = {
            url: config.getDbsApiUrlV1(payload.moduleName),
            method: 'put',
            data: payload.params
          }
          return await axios(req).then(res => {
            if (res.status === 200) {
              // console.log(res.data.content)
              commit('reSetUserData',res.data.content)
              return true
            }else{
              if (res.status <= 400) {
                utils.showToast(`${res.data.message}`)
              }else{
                utils.showToast(`${res.data.message}<br>${i18n.t('message.contactSystemAdministrator')}`)
              }
              return false
            }
          }).catch(error => {
            utils.showToast(`${i18n.t('message.contactSystemAdministrator')}`)
            console.error('error', error)
          })

        },
        async LOGIN ({commit}, form) {
            const TAG = '[store,LOGIN, actions]'
            let url = config.getAuthApiUrl("login")
            let encrypt = utils.setPwEncrypt(form.email, form.password)
            //console.log('dbOriginPw', encrypt.dbOriginPw)
            //console.log('requestPw', encrypt.requestPw)
            let params = {
              email:form.email,
              password:encrypt.requestPw
            }
            return await axios.post(url, params).then(response => {
                if (response.status === 200) {
                    // console.log(TAG, 'status code:', response.status);
                    // console.log(TAG, 'data:', response.data);
                    // console.log(TAG, 'response:', response);
                    // console.log(TAG, 'response.data.accessToken:', response.data.accessToken);
                    commit('LOGIN',response)
                    commit('reSetUserData',response)
                    //모든 HTTP 요청 헤더에 Authorization을 추가한다. // 태훈님작업 내용 확인 후 적용할 것
                    axios.defaults.headers.common['Authorization'] = `Bearer ${response.data.accessToken}`
                    return true
                } else {
                    if(response.data.message){
                      utils.showToastRed(`${response.data.message}`)
                      // utils.showToastRed(`Check Email ID and Password`)
                    }else{
                      utils.showToastRed('Contact your System Administrator')
                    }
                    return false
                }
            })
            .catch (error => {
                //utils.showToast('Contact your System Administrator');
                utils.showToastRed('Check emailID and Password');
                console.log(TAG, 'error******* :', error)

                return false
            })
        },
        LOGOUT ({commit}) {
            //HTTP 요청 헤더값 제거
            axios.defaults.headers.common['Authorization'] = undefined
            commit('LOGOUT')
        },
    }
}
export default loginLogout
