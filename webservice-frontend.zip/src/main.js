import 'core-js/stable'
import * as VueGoogleMaps from 'vue2-google-maps'
import Vue from 'vue'
import CoreuiVue from '@coreui/vue'
import App from './App'

import router from '@/router/index'
// import { freeSet } from '@coreui/icons'
import './assets/js/filters'
import { iconsSet as icons } from './assets/icons/icons.js'


import axios from 'axios'
import VueAxios from 'vue-axios'

axios.defaults.validateStatus = () => true

/*
axios.interceptors.response.use(function (response) {
  if (response.status === 200 && response.data.message) {
    console.log(response.data.message)
  }
  if (response.status === 201 && response.data.message) {
    console.log(response.data.message)
  }
  return response
}, function (error) {
  console.log('error', error)
  if (error.response) {
    if (error.response.status === 404 || error.response.status === 400) {
      console.log(error.response.data.message)
    }
  }
  // router.push('/user/404');
  return Promise.reject(error)
})
*/

import * as svgicon from 'vue-svgicon'
Vue.use(svgicon, {
  classPrefix: 'AppIcon-',
})

Vue.use(VueAxios, axios)
Vue.use(CoreuiVue)
// Vue.component('country-flag', CountryFlag)

Vue.prototype.$log = console.log.bind(console)

import i18n from '@/locales' // lang 디렉토리의 index.js 를 읽어옴.
import store from '@/store/index'

// import dbsPlugin from '@/assets/js/dbsPlugin'
// Vue.use(dbsPlugin)


//import VueCryptojs from 'vue-cryptojs'
//Vue.use(VueCryptojs)

//import Vue from 'vue'

import CryptoJS from 'vue-cryptojs'
Vue.use(CryptoJS)

import moment from 'moment'
Vue.prototype.$moment = moment

Vue.use(VueGoogleMaps, {
  load: {
    libraries: 'geometry',
    // aws
    // key: 'AIzaSyDMaFkV4Nz6D8wKBphGbcruJxHwdpWnHJY'
    key: 'AIzaSyCOe5Fsdu1w4o2v-uhpchSHfjQFuY9yVmo'
     // local
    //key: 'AIzaSyASyYRBZmULmrmw_P9kgr7_266OhFNinPA'
    // key: ''
    // To use the Google Maps JavaScript API, you must register your app project on the Google API Console and get a Google API key which you can add to your app
    // v: 'OPTIONAL VERSION NUMBER',
    // libraries: 'places', //// If you need to use place input
  }
})

new Vue({
  el: '#app',
  store,
  i18n,
  router,
  CryptoJS,
  //CIcon component documentation: https://coreui.io/vue/docs/components/icon
  // WeatherUnderground,
  icons,
  // icons: { ...freeSet },
  template: '<App/>',
  components: {
    App
  }
})
