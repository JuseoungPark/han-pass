<template>
  <CDropdown 
    placement="bottom-end"
    :caret="false"
    in-nav
    class="c-header-nav-item px-2 flag-select-wrap"
    add-menu-classes="pt-0"
  >
    <template #toggler>
      <CHeaderNavLink class="p-0">
        <!-- <div v-html="setFlag" class="header-flag-wrap"> -->
        <div class="header-flag-wrap">
            <country-flag v-if="$i18n.locale === 'ko'" country='kr' size='normal'/>
            <country-flag v-else-if="$i18n.locale === 'en'" country='us' size='normal'/>
            <country-flag v-else-if="$i18n.locale === 'in'" country='id' size='normal'/>
        </div>
      </CHeaderNavLink>
    </template>
    <CDropdownHeader 
      tag="div" 
      class="text-center"
    >
      <strong>Language</strong>
    </CDropdownHeader>
    <CDropdownItem class="mt-1">
      <!-- <CIcon :height="42" :content="cif-kr" class="text-success"/> <button @click="$i18n.locale='ko'">한국어</button> -->
      <button @click="changeLanguage('ko')">
        <div class="language-wrap">
          <div class="icon-wrap">
            <country-flag country='kr' size='normal'/>
          </div>
          <div class="value-wrap">
            <span class="tit">Korean</span>
            <span class="lang">KO</span>
          </div>
        </div>
      </button>
    </CDropdownItem>
    <CDropdownItem>
      <!-- <CIcon name="cil-user-unfollow" class="text-danger"/> <button @click="$i18n.locale='en'">English</button> -->
      <button @click="changeLanguage('en')">
        <div class="language-wrap">
          <div class="icon-wrap">
            <country-flag country='us' size='normal'/>
          </div>
          <div class="value-wrap">
            <span class="tit">English</span>
            <span class="lang">EN</span>
          </div>
        </div>
      </button>
    </CDropdownItem>
    <CDropdownItem class="mb-1">
      <!-- <CIcon name="cil-chart-pie" class="text-info"/> <button @click="$i18n.locale='in'">xxxx English</button>    -->
      <!-- <button @click="$i18n.locale='in'"><country-flag country='id' size='normal'/></button>    -->
      <button @click="changeLanguage('in')">
        <div class="language-wrap">
          <div class="icon-wrap">
            <country-flag country='id' size='normal'/>
          </div>
          <div class="value-wrap">
            <span class="tit">Indonesia</span>
            <span class="lang">IN</span>
          </div>
        </div>
      </button>   
    </CDropdownItem>
    <!-- https://github.com/P3trur0/vue-country-flag -->
  </CDropdown>
</template>
<script>

import utils from '@/assets/js/utils'
import i18n from '@/locales' // lang 디렉토리의 index.js 를 읽어옴.
import CountryFlag from 'vue-country-flag'
import { mapGetters, mapActions } from 'vuex'
const userInfo = 'loginLogout'

export default {
  name: 'TheHeaderDropdownLocale',
  components: {
    'country-flag': CountryFlag
  },
  data () {
    return {
      // setFlag: '',
      LangtypeOptions: utils.getOptionCode('multilingualType') ,
    }
  },
  computed: {
    ...mapGetters(userInfo, {
        userName : 'getUserName',
        userCellphoneNo: 'getUserCellphoneNo',
        userId : 'getUserId',
        userThemaType : 'getUserThemaType',
        userLangType : 'getUserLangType',
        userCompany : 'getUserCompany',
        userSite : 'getUserSite',
        expiration : 'getExpiration',
        userPermissionList : 'getUserPermissionList',
        userMenuList : 'getUserMenuList',
        codeList : 'getCodeList',
        isAuthenticated : 'getIsAuthenticated',
        selectedUserSite : 'getSelectedUserSite',
    }),
  },  
  created() {

    //let getUserInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('dbs'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))

    //this.reSetUserInfo(getUserInfo)
    //console.log("userSite : ", this.userSite)

    //let getUserSelectedSiteInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('selectedUserSite'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))
    //this.reSetSelectedSiteInfo(getUserSelectedSiteInfo)

  },
  mounted() {
    // this.localeLanguageCheck()
  },
  beforeUpdate(){
    // this.localeLanguageCheck()

  },
  methods: {
    ...mapActions(userInfo, {
        reSetUserInfo : 'reSetUserInfo',
        reSetSelectedPermissionList : 'reSetSelectedPermissionList',
        reSetSelectedSiteInfo : 'reSetSelectedSiteInfo',
        reSetSelectedMenuList : 'reSetSelectedMenuList',
        reSetUserLangType : 'reSetUserLangType'
    }),           
    changeLanguage(lang) {
      this.$i18n.locale = lang
      if (this.$i18n.locale=='ko') {
        this.inputMessage = '입력'
      }else {
        this.inputMessage = 'Enter'
      }
      if(this.LangtypeOptions[this.LangtypeOptions.findIndex(y=>y.label === lang)]){
        let params = { userLanguageType: this.LangtypeOptions[this.LangtypeOptions.findIndex(y=>y.label === lang)].value }
        this.reSetUserLangType({params : params })
      }
    },
    // localeLanguageCheck() {
    //   if(this.$i18n.locale == 'en'){
    //     this.setFlag = '<span class="flag f-us normal-flag"></span>'
    //   }
    //   else if (this.$i18n.locale == 'kr') {
    //     this.setFlag = '<span class="flag f-kr normal-flag"></span>'
    //   }
    //   else if (this.$i18n.locale == 'in') {
    //     this.setFlag = '<span class="flag f-id normal-flag"></span>'
    //   }
    // },
    // krLanguage(){
    //   this.$i18n.locale='ko'
    //   this.setFlag = '<span class="flag f-kr normal-flag"></span>'
    // },
    // usLanguage(){
    //   this.$i18n.locale='us'
    //   this.setFlag = '<span class="flag f-us normal-flag"></span>'
    // },
    // inLanguage(){
    //   this.$i18n.locale='in'
    //   this.setFlag = '<span class="flag f-id normal-flag"></span>'
    // },
  }
}
</script>