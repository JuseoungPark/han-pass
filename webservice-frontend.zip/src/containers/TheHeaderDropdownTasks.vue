<template>
  <CDropdown
    :caret="false"
    placement="bottom-end"
    in-nav
    class="c-header-nav-item header-porgress d-md-down-none px-2"
    add-menu-classes="pt-0"
  >
    <template #toggler>
      <CHeaderNavLink>
        <!-- <CIcon name="cil-list-rich"/> -->
        <app-icon name="list" size="sm" fill class="dark-white" />
        <CBadge shape="pill" color="hanwha">{{ taskList.length }}</CBadge>
      </CHeaderNavLink>
    </template>
    <CDropdownHeader
      tag="div"
      class="text-center"
      >
      <strong>{{$t('commonLabel.opeartion')}}</strong>
    </CDropdownHeader>
    <ul class="dropdown-list list-unstyled">
      <li
        v-for="(list, idx) in taskList"
        :key="idx"
      >
        <CDropdownItem class="d-block" @click="listClick(list)">
          <div class="small mb-1">
            {{ list.name }} <span class="float-right"><strong>{{ list.per }}%</strong></span>
          </div>
          <!-- <CProgress class="progress-xs" color="success" :value="list.per"/> -->
          <!-- <CProgress class="progress-xs" color="warning" :value="list.per"/> -->
          <!-- <CProgress class="progress-xs" color="danger" :value="list.per"/> -->
          <CProgress class="progress-xs" :color="list.per <= 25 ? 'danger' : (list.per > 25 && list.per <= 50 ? 'warning' : (list.per > 50 && list.per <= 75 ? 'info' : 'success'))" :value="list.per"/>
        </CDropdownItem>
      </li>
      <div v-show="!taskList.length" v-text="$t('message.noData')" class="info-txt" style="padding-bottom:10px" />
    </ul>

    <!-- <CDropdownItem class="text-center border-top">
      <strong>View all tasks</strong>
    </CDropdownItem> -->

  </CDropdown>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
  name: 'TheHeaderDropdownTasks',
  components: {
    AppIcon
  },
  data () {
    return {
      intervalTasks: '',
      taskList : []
    }
  },
  computed: {
    ...mapGetters(blastLibrary, {
      data: 'getData',
      dataList: 'getDataList',
    }),
  },
  async created() {
    this.setTasks()

    this.intervalTasks = setInterval(() => {
     this.setTasks()
    }, 60000);  // 60초
  },
  destroyed() {
    clearInterval(this.intervalTasks)
  },
  methods: {
    ...mapActions(blastLibrary, {
      setDataListAction: 'setDataList',
    }),
    async setTasks() {
      let that = this
      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      let moduleName = "v1/dashboard/"+siteId+"/worklist"
      let payload = { params: params, moduleName: moduleName }
      await this.setDataListAction(payload)
//console.log('setTasks...')
//console.log(this.dataList)
      that.taskList = []
      if (this.dataList.length > 0) {
        this.dataList.forEach(function (item) {
          let workrper = (item.workrper!=null?Number(item.workrper):0)
          if (workrper > 100) workrper = 100
          if (workrper > 0) {
            that.taskList.push({
              name: item.name,
              per: workrper
            })
          }
        })
      }
    },
    listClick(item) {
      let query = { gubun: 'blast', name: item.name, queryId: (Math.floor(Math.random() * (10 - 1 + 1)) + 1) }
      if (this.$route.name == 'SiteDashboard') {
        //let path = this.$router.currentRoute.path
        this.$router.push({ path: '/sitedashboard', query })
      }else this.$router.push({ path: '/sitedashboard', query }).catch(()=>{});
    }
  }
}
</script>