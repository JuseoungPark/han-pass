<template>
  <CDropdown
    inNav
    class="c-header-nav-items header-authority-dropdown profile-dropdown"
    placement="bottom-end"
    add-menu-classes="pt-0"
  >
    <template #toggler>
      <CHeaderNavLink class="p-0">
        <CIcon name="cil-user" />
        <span class="mx-2 authority-txt">Profile</span>
      </CHeaderNavLink>
    </template>
    <!-- <CDropdownHeader tag="div" class="text-center" color="light">
      <strong>Account</strong>
    </CDropdownHeader>
    <CDropdownItem>
      <CIcon name="cil-bell"/> Updates
      <CBadge color="info" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-envelope-open" /> Messages
      <CBadge color="success" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-task" /> Tasks
      <CBadge color="danger" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-comment-square" /> Comments
      <CBadge color="warning" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem> -->
    <CDropdownHeader
      tag="div"
      class="text-center bg-hanwha-orange50"
    >
      <!-- color="light" -->
      <strong>{{$t('commonLabel.profileInformationUpdate')}}</strong>
    </CDropdownHeader>
    <CForm>
      <div class="header-profile-select">
        <CInput
          horizontal
          label="User Pw"
          type="password"
          placeholder="Enter your Password"
        />
      </div>
      <CDropdownDivider/>
    </CForm>
  </CDropdown>
</template>

<script>
export default {
  name: 'TheHeaderDropdownProfile',
  data () {
    return {

    }
  },
  methods : {

  }
}
</script>

<style scoped>
  .c-icon {
    margin-right: 0.3rem;
  }
</style>