<template>
  <CDropdown
    placement="bottom-end"
    :caret="false"
    in-nav
    class="c-header-nav-item mr-2 pl-2 pr-3 header-siteinfo-wrap"
    add-menu-classes="pt-0"
  >
    <template #toggler>
      <CHeaderNavLink class="p-0">
        <!-- <CIcon size="lg" name="cil-applications-settings"/> -->
        <app-icon name="listDot" size="sm" fill class="dark-white" />
      </CHeaderNavLink>
    </template>
    <CDropdownHeader
      tag="div"
      class="text-center"
    >
      <strong>{{$t('commonLabel.siteInformation')}}</strong>
    </CDropdownHeader>
    <div class="link-wrap">
      <router-link
          :to="homeDashboard.to"
          class="home-link"
        >
        <app-icon name="mapLocation" size="s" fill class="dark-white location" />map view<app-icon name="arrowR" size="s" fill class="dark-white arrow-r" />
      </router-link>
    </div>
    <ul class="list-unstyled header-siteinfo-list">
      <li v-for="(list, index) in siteInfoList" :key="index">
        <input :id="`list`+index"
          type="radio"
          name="siteInfoList"
          :checked="index == selectedUserSite.id"
          class="input"
          @change="updateSiteInfo(list)"
        />
        <!-- <div  @click="updateSiteInfo(list)"    > -->
          <label :for="`list`+index" class="label mb-0">
            <span class="title-text">{{ list.name }}</span>
            <div class="d-flex align-items-start">
              <app-icon name="locationPoint" size="s" fill class="dark-white" />
              <span class="small-text">{{ list.address }}</span>
            </div>
          </label>
        <!-- </div> -->
      </li>
    </ul>
  </CDropdown>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import { mapGetters, mapActions } from 'vuex'

const userInfo = 'loginLogout'
const blastLibrary = 'blastLibrary'

export default {
  name: 'TheHeaderDropdownSiteInfo',
  components: {
    AppIcon
  },
  data () {
    return {
      homeDashboard: {
          to: '/homeDashboard'
      },
      siteInfoList: []
    }
  },
  created() {
    //let getUserInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('dbs'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))

    //this.reSetUserInfo(getUserInfo)
    //console.log("userSite : ", this.userSite)

    //let getUserSelectedSiteInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('selectedUserSite'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))
    //this.reSetSelectedSiteInfo(getUserSelectedSiteInfo)
//    console.log("selectedUserSite : ", this.selectedUserSite)

    this.computedList()
  },
  computed: {
    ...mapGetters(userInfo, {
        userName : 'getUserName',
        userCellphoneNo: 'getUserCellphoneNo',
        userId : 'getUserId',
        userThemaType : 'getUserThemaType',
        userLangType : 'getUserLangType',
        userCompany : 'getUserCompany',
        userSite : 'getUserSite',
        expiration : 'getExpiration',
        userPermissionList : 'getUserPermissionList',
        userMenuList : 'getUserMenuList',
        codeList : 'getCodeList',
        isAuthenticated : 'getIsAuthenticated',
        selectedUserSite : 'getSelectedUserSite',
    }),
  },
  methods: {
    ...mapActions(userInfo, {
        reSetUserInfo : 'reSetUserInfo',
        reSetSelectedPermissionList : 'reSetSelectedPermissionList',
        reSetSelectedSiteInfo : 'reSetSelectedSiteInfo',
        reSetSelectedMenuList : 'reSetSelectedMenuList',
        reSetUserData : 'reSetUserData',
    }),
    ...mapActions(blastLibrary, {
        setBlastInfoAction: 'setBlastInfo',
        setBlastListAction: 'setBlastList',
    }),
    computedList() {
        this.siteInfoList = []

        let idx = 0
        this.$nextTick(function() {
            if (this.userSite.length != 0) {
                for(let item of this.userSite) {
                  let siteItem = {}
                  siteItem.id = idx++
                  siteItem.siteId = item.siteId
                  siteItem.name = item.countryCodeName + ' ' + item.siteName
                  siteItem.address = (item.address!=null?item.address:'-')

                  this.siteInfoList.push(siteItem)
                }
            }
        })
        return this.siteInfoList
    },
    updateSiteInfo(list) {
console.log(list)
      let index = this.userSite.findIndex(y=>y.siteId == list.siteId)

      this.reSetSelectedMenuList(this.userSite[index].userMenuList)
      this.reSetSelectedPermissionList(this.userSite[index].userPermissionList)

      let selectedUserSite = {}
      selectedUserSite.id = list.id
      selectedUserSite.siteId = this.userSite[index].siteId
      selectedUserSite.siteName = this.userSite[index].siteName
      selectedUserSite.timezoneType = this.userSite[index].timezoneType
      selectedUserSite.countryCodeName = this.userSite[index].countryCodeName
      selectedUserSite.currency = this.userSite[index].currency
      selectedUserSite.currencyName = this.userSite[index].currencyName

      selectedUserSite.userPermissionList = this.userSite[index].userPermissionList
      selectedUserSite.userMenuList = this.userSite[index].userMenuList
      selectedUserSite.authorityName = this.userSite[index].authorityName
      //selectedUserSite.userMenuList = JSON.stringify(this.userSite[index].userMenuList)

      //선택된 데이터 별도 처리!!!
      this.reSetSelectedSiteInfo(selectedUserSite)
      this.reSetUserData(selectedUserSite)

      let blastInfo = { siteId:0, blastId:0, blastName:'-' }
      this.setBlastInfoAction(blastInfo)
      this.setBlastListAction([])

      this.$emit('setTimezone', selectedUserSite.timezoneType)

      if (this.$route.name == 'SiteDashboard') this.$router.go()
      else this.$router.push("/sitedashboard")
    }
  }
}
</script>
