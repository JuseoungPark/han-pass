<template>
  <CDropdown
    inNav
    class="c-header-nav-items header-authority-dropdown"
    placement="bottom-end"
    add-menu-classes="pt-0 profile-wrap"
  >
    <template #toggler>
      <CHeaderNavLink>
        <!-- <span class="mx-2 authority-txt">{{userName}} ({{userCompany}}) </span> -->
        <div class="c-avatar icon">
          <app-icon name="user" size="sm" fill class="dark-white"/>
          <!-- <img
            src="img/user/default.png"
            class="c-avatar-img default"
          /> -->
        </div>
      </CHeaderNavLink>
    </template>
    <!-- <CDropdownHeader tag="div" class="text-center" color="light">
      <strong>Account</strong>
    </CDropdownHeader>
    <CDropdownItem>
      <CIcon name="cil-bell"/> Updates
      <CBadge color="info" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-envelope-open" /> Messages
      <CBadge color="success" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-task" /> Tasks
      <CBadge color="danger" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-comment-square" /> Comments
      <CBadge color="warning" class="ml-auto">{{ itemsCount }}</CBadge>
    </CDropdownItem> -->
    <CDropdownHeader
      tag="div"
      class="text-center"
    >
      <!-- <strong>{{$t('commonLabel.profileInformation')}}</strong> -->
      <strong>{{userName}} <span v-if="selectedUserSite.authorityName">({{selectedUserSite.authorityName}})</span></strong>
    </CDropdownHeader>

    <!-- Profile 설정 -->
    <CDropdownItem @click="$emit('profileSetting', $event)">
      <!-- <CIcon name="cil-user" />Profile -->
      <app-icon name="profile" size="s" fill class="dark-white mr-2"/>Profile
    </CDropdownItem>

    <!-- <div class="header-authority-select d-flex align-items-center">
      <CIcon name="cil-lock-locked" />
      <CSelect
        class="mb-0"
        :options="authorityOptions"
        placeholder="권한 선택"
      />
    </div> -->

    <!-- guide line -->
    <!-- <CDropdownDivider/> -->

    <CDropdownItem
        v-if="isAuthenticated"
        @click="logOut"
    >
      <!-- <CIcon name="cil-room"
      /> Logout -->
      <app-icon name="logout" size="s" fill class="dark-white mr-2"/> Logout
    </CDropdownItem>

    <!-- <CDropdownItem>
      <CIcon name="cil-shield-alt" /> Lock Account
    </CDropdownItem> -->
    <!-- <CDropdownItem
        v-if="!isAuthenticated"
        @click="logIn">
      <CIcon name="cil-lock-locked"
      /> LogoIn
    </CDropdownItem> -->


  </CDropdown>
</template>

<script>
import TheHeaderDropdownProfile from '@/containers/TheHeaderDropdownProfile'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import store from '@/store'
import utils from '@/assets/js/utils'
import config from '@/assets/js/config'

import { mapGetters, mapActions } from 'vuex'
const userInfo = 'loginLogout'

import moment from 'moment'

export default {
  name: 'TheHeaderDropdownAccnt',
  components: {
    TheHeaderDropdownProfile,
    AppIcon
  },
  data () {
    return {
      currentTime: moment().format('YYYY-MM-DD HH:mm:ss'),
      // isAuthenticated: false,
      isLoginCheckPopView: false,  // 로그인체크 팝업 상태값
      itemsCount: 42,
      authorityOptions:[
        'Please select',
        'authorityOptions-01',
        'authorityOptions-02',
      ],
      // userName: '',
      // userPermissionList: '',
      // userCompany: '',
      // expiration: '',
      // userSite: ''
    }
  },
  computed: {
    ...mapGetters(userInfo, {
        userName : 'getUserName',
        userCellphoneNo: 'getUserCellphoneNo',
        userId : 'getUserId',
        userThemaType : 'getUserThemaType',
        userLangType : 'getUserLangType',
        userCompany : 'getUserCompany',
        userSite : 'getUserSite',
        expiration : 'getExpiration',
        userPermissionList : 'getUserPermissionList',
        userMenuList : 'getUserMenuList',
        codeList : 'getCodeList',
        isAuthenticated : 'getIsAuthenticated',
        selectedUserSite : 'getSelectedUserSite',
    }),
  },
  async created() {
    // console.log('selectedUserSite',this.selectedUserSite.authorityName)
  },
  methods : {
    logOut() {
      //this.showToastRed('로그아웃 되었습니다.')
      store.dispatch('loginLogout/LOGOUT').then(()=> this.$router.push({path:'/user/login'}))
      // this.$router.push({path:'/admin/Login'})
    },
    // logIn() {
    //   // this.showToastRed('로그아웃 되었습니다.')
    //   store.dispatch('LOGOUT').then(()=> this.$router.push({path:'/pages/Login'}))
    //   // this.$router.push({path:'/admin/Login'})
    // },

  }
}
</script>

<style scoped>
  .c-icon {
    margin-right: 0.3rem;
  }
</style>