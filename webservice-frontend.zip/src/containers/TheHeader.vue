<template>
<div>
  <CHeader with-subheader id="appHeader">
      <!-- in-header -->
    <CToggler
      class="ml-3 d-lg-none btn-header-menu"
      @click="$store.commit('uxui/toggleSidebarMobile')">
      <app-icon name="headerMenu" size="m" fill />
    </CToggler>

      <!-- in-header -->
    <CToggler
      class="ml-3 d-md-down-none btn-header-menu"
      @click="$store.commit('uxui/toggleSidebarDesktop')">
      <app-icon name="headerMenu" size="m" fill />
    </CToggler>

    <CHeaderBrand class="mx-auto d-lg-none" to="/">
      <!-- <CIcon name="logo" height="48" alt="Logo"/> -->
      <CImg
        src="img/main-logo-m.png"
        name="logo"
        height="30"
        size="custom-size"
        alt="Logo"
        />
    </CHeaderBrand>
    <CHeaderNav class="d-md-down-none mr-auto header-location-item">
      <CHeaderNavItem class="px-2">
        <!-- 선택 광산 -->
        <!-- <span class="site-info-text">{{ siteInfo }}</span> -->
        <span class="site-info-text">{{ selectedUserSite.siteName }}</span>
      </CHeaderNavItem>
      <CHeaderNavItem class="px-2">
        <!-- 날짜, 시간 -->
        <!-- <span class="time-text d-block">{{ todaysDate }}</span> -->
        <span class="time-text">{{ date }}</span>
        <span class="time-text ml-1">{{ time }}</span>
      </CHeaderNavItem>
      <CHeaderNavItem class="px-2">
        <!-- 날씨, 온도 -->
        <!-- https://github.com/manifestinteractive/weather-underground-icons -->
        <div class="d-flex align-items-center">
          <!-- <i class="wu wu-black wu-32 wu-sunny" :class="'wu-' + (!$store.state.uxui.darkMode ? 'black' : 'white')"></i> -->
          <i class="wu wu-black wu-32" :class="`wu-${$store.state.uxui.darkMode ? 'white' : 'black'} wu-${weather}`"></i>
          <span class="header-list-text ml-1" style="padding-left:3px; padding-top:2px;">{{ temperature }} ℃</span>
        </div>
      </CHeaderNavItem>
      <!-- <CHeaderNavItem class="px-3">
        <CHeaderNavLink to="/users" exact>
          Users
        </CHeaderNavLink>
      </CHeaderNavItem>
      <CHeaderNavItem class="px-3">
        <CHeaderNavLink>
          Settings
        </CHeaderNavLink>
      </CHeaderNavItem> -->
    </CHeaderNav>
    <CHeaderNav>
      <CHeaderNavItem class="pl-2">
        <button
          @click="() => $store.commit('uxui/toggle', 'darkMode')"
          class="c-header-nav-btn"
        >
          <!-- <CIcon v-if="$store.state.uxui.darkMode" name="cil-sun"/> -->
          <app-icon v-if="$store.state.uxui.darkMode" name="light" size="sm" fill class="dark-white color-hanwha" />
          <app-icon v-else name="night" size="sm" fill class="dark-white" />

          <!-- <CIcon v-if="$store.state.uxui.darkMode" name="cil-sun"/>
          <CIcon v-else name="cil-moon"/> -->
        </button>
      </CHeaderNavItem>

      <!-- {{$t('message1.hello')}} -->

      <TheHeaderDropdownNotif
        v-if="theHeaderNotif"
      />
      <TheHeaderDropdownTasks
        v-if="theHeaderTasks"
      />
      <TheHeaderDropdownAccnt
        @profileSetting="profileSetting"
      />
      <TheHeaderDropdownLocale />
      <TheHeaderDropdownSiteInfo
        @setTimezone="setTimezone"
      />
      <!-- <TheHeaderDropdownMssgs/> -->
      <!-- <CHeaderNavItem class="px-3">
        <button
          in-header
          class="c-header-nav-btn"
          @click="$store.commit('toggle', 'asideShow')"
        >
          <CIcon size="lg" name="cil-applications-settings" class="mr-2"/>
        </button>
      </CHeaderNavItem> -->
    </CHeaderNav>
    <CSubheader class="px-3">
      <CBreadcrumbRouter class="border-0 mb-0"/>
    </CSubheader>
  </CHeader>

    <sweet-modal
      ref="profileModal"
      blocking
      overlay-theme="dark"
      class="profile-modal-pop"
    >
    <CCard class="mb-0">
      <CForm @submit.prevent>
        <CCardHeader>
          <strong>{{$t('commonLabel.profileInformationUpdate')}}</strong>
        </CCardHeader>
        <CCardBody class="pb-0">
          <div class="header-profile-select">
            <CInput
              :label="$t('userInformation.userName',[''])"
              type="text"
              :placeholder="$t('userInformation.userName',[inputMessage])"
              name="userName"
              :disabled="true"
              v-model.trim="$v.form.userName.$model"
              autocomplete="username"
            />
            <div class="text-right">
              <div role="group" class="mb-2 custom-control custom-checkbox">
                <input id="changePassword" type="checkbox" class="custom-control-input" v-model="changePassword">
                <label for="changePassword" class="custom-control-label"> {{$t('commonLabel.changePassword')}} </label>
              </div>
            </div>
          </div>
        </CCardBody>
        <CCardBody class="p-0 line-all-none">
          <div class="header-profile-select">
            <div
              v-if="changePassword"
              class="hidden-wrap mb-3"
            >
              <CInput
                :label="$t('userInformation.currentPassword',[''])"
                type="password"
                :placeholder="$t('userInformation.currentPassword',[inputMessage])"
                :isValid="checkIfValid('currentPassword')"
                :value.sync="$v.form.currentPassword.$model"
              />
              <CInput
                :label="$t('userInformation.newPassword',[''])"
                type="password"
                :placeholder="$t('userInformation.newPassword',[inputMessage])"
                autocomplete="new-password"
                :isValid="checkIfValid('newPassword')"
                :value.sync="$v.form.newPassword.$model"
                invalidFeedback="Required password containing at least: number and lowercase letter, 6 characters"
              />
              <CInput
                :label="$t('userInformation.confirmPassword',[''])"
                type="password"
                :placeholder="$t('userInformation.confirmPassword',[inputMessage])"
                autocomplete="new-password"
                invalidFeedback="Passwords must match"
                :isValid="checkIfValid('confirmPassword')"
                :value.sync="$v.form.confirmPassword.$model"
              />
            </div>
          </div>
        </CCardBody>
        <CCardBody class="pt-0 line-all-none">
          <div class="header-profile-select">
            <CInput
              :label="$t('userInformation.cellphoneNo',[''])"
              type="text"
              :placeholder="$t('userInformation.cellphoneNo',[inputMessage])"
              name="cellphoneNo"
              :maxlength="20"
              :isValid="checkIfValid('userCellphoneNo')"
              v-model.trim="$v.form.userCellphoneNo.$model">
                <template slot="invalid-feedback">
                  <ValidFeedback :param="$v.form.userCellphoneNo" />
                </template>
              </CInput>

            <!-- <CSelect
                label="Company Id"
                :options="companyIdOptions"
            /> -->

              <label for="userLanguageType" class="d-block">
                {{$t('userInformation.userLanguageType',[''])}}
              </label>
              <select id="userLanguageType-category-value1"
                  class="custom-select form-control"
                    v-model="selectedUserLanguageTypeOption" >
                    <option v-for="option in LangtypeOptions"
                        :key="option.key"
                        :value="option.value">
                        {{option.option}}
                    </option>
              </select>

            <!-- <CSelect
                label="User Langtype"
                :options="LangtypeOptions"
            /> -->
            <div class="mt-3">
            <label class="d-block">{{$t('commonLabel.Theme',[''])}}</label>
            <CInputRadioGroup
                class="thema-radio"
                name="userThemaType"
                :options="themaOptions"
                :checked="$v.form.userThemaType.$model"
                v-model.trim="$v.form.userThemaType.$model"
                @update:checked="changeThema"
                :custom="true"
                :inline="true"
            />
            </div>
          </div>
        </CCardBody>
        <CCardFooter>
          <CButton type="submit"
              class="btn-custom-default hanwha outline rectangle"
              :disabled="!isValid"
              @click="saveData"
          >
            {{$t('commonLabel.submit')}}
          </CButton>
        </CCardFooter>
    </CForm>
    </CCard>
    </sweet-modal>

    <!-- <sweet-modal> -->
      <!-- alert popup -->

    <!-- modal popup alert -->
        <div class="pop-wrap open fade"
            :class="{ show : isLoginCheckPopView }"
            v-show="isLoginCheckPopView">
            <alert-login-check
                @popClose="closePop"
                @onSubmit="loginConservation"/>
            <div class="modal-backdrop fade show"></div>
        </div>
    <!-- </sweet-modal> -->
    <!-- alert popup -->
</div>
</template>

<script>
import WeatherUnderground from '@johnmmackey/weather-underground-icons'

import TheHeaderDropdownAccnt from '@/containers/TheHeaderDropdownAccnt'
import TheHeaderDropdownNotif from '@/containers/TheHeaderDropdownNotif'
import TheHeaderDropdownTasks from '@/containers/TheHeaderDropdownTasks'
// import TheHeaderDropdownMssgs from '@/containers/TheHeaderDropdownMssgs'
import TheHeaderDropdownLocale from '@/containers/TheHeaderDropdownLocale'
import TheHeaderDropdownSiteInfo from '@/containers/TheHeaderDropdownSiteInfo'

import AlertLoginCheck from '@/views/pages/alertLoginCheck.vue'

import { SweetModal } from 'sweet-modal-vue'
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

//import moment from 'moment'
import moment from 'moment-timezone'

import Vue from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'

Vue.use(VueAxios, axios)

import utils from '@/assets/js/utils'
import i18n from '@/locales' // lang 디렉토리의 index.js 를 읽어옴.
import ValidFeedback from '@/components/form/ValidFeedback'

//중복클릭 방지
import PreventDuplicateUtils from '@/assets/js/PreventDuplicateUtils.js'
const preventDuplicateUtils = new PreventDuplicateUtils()

import { validationMixin } from "vuelidate"
import { required, maxLength, sameAs, helpers, numeric } from "vuelidate/lib/validators"

import { mapGetters, mapActions } from 'vuex'

const userProfile = 'userProfile'
const userInfo = 'loginLogout'
const blastLibrary = 'blastLibrary'

//import CryptoJS from 'vue-cryptojs'
//Vue.use(CryptoJS)

//import CryptoJS from 'crypto-js'

export default {
  name: 'TheHeader',
  components: {
    TheHeaderDropdownAccnt,
    TheHeaderDropdownNotif,
    TheHeaderDropdownTasks,
    // TheHeaderDropdownMssgs,
    TheHeaderDropdownLocale,
    TheHeaderDropdownSiteInfo,
    AlertLoginCheck,
    SweetModal,
    WeatherUnderground,
    AppIcon,
    ValidFeedback
  },
  data() {
    return {
      moduleName: "profile",
      //userInformation: utils.getUserInformation(),

      // dangerModal: false,

      intervalTimer: '',
      intervalWeather: '',

      weather: '',
      temperature: '',

      theHeaderNotif: true,
      theHeaderTasks: true,

      siteInfo: '',
      week: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'], // 요일 표시용 임시 data
      time: '',
      date: '',
      //----------------------------------------//
      inputMessage: 'Enter',
      //-------------------------------------------//
      form: this.getEmptyForm(),
      noDataForm:  this.getEmptyForm(),
      submitted: false,
      //------------------------------------//
      LangtypeOptions: utils.getOptionCode('multilingualType') ,
      themaOptions: ['dark', 'white'],
      selectedUserLanguageTypeOption: '',
      //------------------------------------//

      changePassword: false,
      companyIdOptions: [
          'Please select',
          'company id-01',
          'company id-02',
          'company id-03',
      ], //임시 selectbox data
      //expiration: 0,
      isLoginCheckPopView: false, // 로그인체크 팝업 상태값
      //userSite:[]
    }
  },
  // updated() {
  //     //console.log("updated")
  //     if (this.inputMessage != utils.multiLanguage(i18n.locale) ) {
  //         this.inputMessage = utils.multiLanguage(i18n.locale)
  //     }
  // },
  computed: {
      ...mapGetters(userProfile, {
          dataList : 'getDataList',
          getSiteAuthorityList : 'getSiteAuthorityList',
          dataListPageInfo: 'getDataListPageInfo',
          selectedData : 'getSelectedData',
          getCheckEmailIdDuplication : 'getCheckEmailIdDuplication'
      }),
      ...mapGetters(userInfo, {
          getUserData : 'getUserData',
          userName : 'getUserName',
          userCellphoneNo: 'getUserCellphoneNo',
          userId : 'getUserId',
          userEmail : 'getUserEmail',
          userThemaType : 'getUserThemaType',
          userLangType : 'getUserLangType',
          userCompany : 'getUserCompany',
          userSite : 'getUserSite',
          expiration : 'getExpiration',
          userPermissionList : 'getUserPermissionList',
          userMenuList : 'getUserMenuList',
          codeList : 'getCodeList',
          isAuthenticated : 'getIsAuthenticated',
          selectedUserSite : 'getSelectedUserSite',
      }),
      ...mapGetters(blastLibrary, {
          status: 'getStatus',
          data2: 'getData',
      }),
      userInformation() {
        //userInformation : utils.getUserInformation()
        return  utils.getUserInformation()
        //return  utils.getUserInformation()
      },
      formString () { return JSON.stringify(this.form, null, 4) },
      isValid () {
        return !this.$v.form.$invalid
      },
      isDirty () {
          return this.$v.form.$anyDirty
      },
  },
  async created() {
    this.intervalTimer = setInterval(() => this.updateTimezone(), 1000)  // 1초
    this.intervalWeather = setInterval(() => this.updateWeather(), (60000 * 30))  // 30분

    //let getUserInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('dbs'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))
    let getUserInfo = utils.getUserInformation()

    this.reSetUserInfo(getUserInfo)
    this.reSetSelectedSiteInfo(getUserInfo.selectedUserSite)

    this.setForm()
    this.setInitThema()
    this.setInitLangType()

    let timezone = getUserInfo.selectedUserSite.timezoneType
    this.setTimezone(timezone)

    let siteId = getUserInfo.selectedUserSite.siteId
    if (siteId == 0) {
      this.theHeaderNotif = false
      this.theHeaderTasks = false
    }
    //this.userInformation = utils.getUserInformation()
    //console.log("userInformation ::: ", this.userInformation)
    //console.log("utils.getUserInformation() ::: ", utils.getUserInformation())
  },
  watch: {
      userInformation() {
        console.log('############## userInformation #####', this.userInformation)
      },
      selectedUserLanguageTypeOption(val) {
          this.form.userLanguageType = val
          if (this.$i18n.locale=='ko') {
            this.inputMessage = '입력'
          }else {
            this.inputMessage = 'Enter'
          }
      }
  },
  mounted() {
    this.updateTime()
    this.updateWeather()
    this.checkExpired()
  },
  destroyed() {
    clearInterval(this.intervalTimer)
    clearInterval(this.intervalWeather)
  },
  methods: {
    ...mapActions(userInfo, {
        reSetUserInfo : 'reSetUserInfo',
        reSetSelectedSiteInfo : 'reSetSelectedSiteInfo',
        reSetUserThemaType : 'reSetUserThemaType',
        reSetUserLangType : 'reSetUserLangType',
        reSetUserCellphoneNo : 'reSetUserCellphoneNo',
        reSetUserData : 'reSetUserData',
        profileEdit : 'profileEdit',
    }),
    ...mapActions(blastLibrary, {
        setDataListAction: 'setDataList',
    }),
    /*...mapActions(userProfile, {
        setDataListAction : 'setDataList',
        setSiteAuthorityListAction : 'setSiteAuthorityList',
        setSelectedAction : 'setSelectedData',
        saveAction : 'saveData',
        deleteAction : 'deleteSelectedData',
        checkEmailId : 'checkEmailId'
    }),*/
    setInitThema() {
      //----------------------------------------------------------------------//
      //2020.10.13 수정
      // this.userThemaType = localStorage.getItem('userThemaType')
      this.form.userThemaType = this.userThemaType

      //console.log("this.userThemaType :", this.userThemaType)
      if (this.form.userThemaType=='dark') {
        this.$store.commit('uxui/setToggle', ['darkMode', true])
      } else {
        this.$store.commit('uxui/setToggle', ['darkMode', false])
      }
    },
    setInitLangType() {
      //----------------------------------------------------------------------//
      // this.userLangType = localStorage.getItem('userLangType')
//      console.log("this.userLangType >>> : ",this.userLangType)
      // console.log(this.LangtypeOptions)
      if(this.LangtypeOptions[this.LangtypeOptions.findIndex(y=>y.value == this.userLangType)]){
        this.userLangTypeName = this.LangtypeOptions[this.LangtypeOptions.findIndex(y=>y.value == this.userLangType)].option
      }else{
        this.userLangTypeName = 'ko'
      }
      this.$i18n.locale = this.userLangTypeName
      //console.log("this.$i18n.locale : ",this.$i18n.locale)
      if (this.$i18n.locale=='ko') {
        this.inputMessage = '입력'
      }else {
        this.inputMessage = 'Enter'
      }
    },
    setForm() {
      this.form.siteId = this.selectedUserSite.siteId
      this.form.userName = this.userName
      this.form.userId = this.userId
      this.form.userThemaType = this.userThemaType
      this.form.userCellphoneNo = this.userCellphoneNo
      this.selectedUserLanguageTypeOption = this.userLangType
      this.form.userLanguageType = this.selectedUserLanguageTypeOption
      this.changePassword = false
    },
    setTimezone(timezone) {
console.log('setTimezone = '+timezone)
      if (timezone!='') moment.tz.setDefault(timezone)

console.log( moment().format() )
console.log( moment.utc().format() )
    },
    async saveData() {
        // if (!this.okCheckDuplication) {
        //   utils.showToast(this.$t('message.checkEmailId'))
        //   return
        // }
        if (!preventDuplicateUtils.overClick(3000)) {
            utils.showToast(this.$t('message.rejectDuplicateClicks'))
            return
        }
        /*if (this.isValid) {
            this.submitted = true
        } else {
            return
        }*/
        // 입력값 설정
        let params = new Array()
        params = this.setParamData()

        // 페이징 처리를 위해서
        let payload = {params : params, moduleName : `${this.moduleName}/${this.userId}`}
        this.spinnerFlag = true
        // console.log("payload : ", payload)
        await this.reSetUserThemaType(payload)
        await this.reSetUserLangType(payload)
        await this.reSetUserCellphoneNo(payload)
        let result = await this.profileEdit(payload)
        this.spinnerFlag = false
        if(result){
          await this.resetData()
          await this.setInitThema()
          await this.setInitLangType()
          this.$refs.profileModal.close()
        }
    },
    async resetData() {
        //this.viewList()
        this.reset()
        // this.selectedCompanyOption = ''
        // this.selectedUserLanguageTypeOption = ''
        // this.selectedSiteOption = ''
        // this.selectedAuthorityOption = ''
        // this.userSiteAuthorityList = []
        // this.orgSiteAuthorityList =[]
        // this.okCheckDuplication = false
    },
    reset () {
        this.selectedDataFlag = false
        // this.$v.form.$reset()
        this.form = this.getEmptyForm()
        this.submitted = false
        this.setForm()
    },
    getEmptyForm () {
        return {
            userId: '',
            siteId: '',
            currentPassword: '',
            newPassword: '',
            confirmPassword: '',
            userName: '',
            userCellphoneNo: '',
            userLanguageType: '',
            userThemaType: 'white',
        }
    },
    setParamData() {
        // 검색하기 조건 설정
        // let setParam = {}
        let setParamData = {}

        //if (this.selectedDataFlag==true) {//기존 데이터
        setParamData.dataId = this.userId
        //}

        setParamData.siteId = this.selectedUserSite.siteId

        if (this.selectedUserLanguageTypeOption !== '') {
          this.form.userLanguageType = this.selectedUserLanguageTypeOption
          setParamData.userLanguageType = this.selectedUserLanguageTypeOption
        } else {
          if (this.userLanguageType !== '') setParamData.userLanguageType = this.userLanguageType
        }
        setParamData.userId = this.form.userId
        if (this.changePassword) {
          let encryptCur = utils.setPwEncrypt(this.userEmail, this.form.currentPassword)
          let encryptNew = utils.setPwEncrypt(this.userEmail, this.form.newPassword)
          // console.log('password', encryptCur.requestPw)
          // console.log('newPassword', encryptNew.dbOriginPw)
          setParamData.pw = this.form.newPassword
          setParamData.password = encryptCur.requestPw
          setParamData.newPassword = encryptNew.dbOriginPw
          //setParamData.password = this.form.currentPassword
          //setParamData.newPassword = this.form.newPassword
        }
        setParamData.userName = this.form.userName
        setParamData.userLanguageType = this.form.userLanguageType

        setParamData.cellphoneNo = this.form.userCellphoneNo
        setParamData.themaType = this.form.userThemaType

        return setParamData
    },
    changeThema() {
      this.form.userThemaType = (this.form.userThemaType == 'dark') ? 'white' : 'dark'
    },
    checkIfValid (fieldName) {
        const field = this.$v.form[fieldName]
        if (!field.$dirty) {
            return null
        }
        return !(field.$invalid || field.$model === '')
    },
    validate () {
        this.$v.$touch()
    },
    //-------------------------------------------------------------------------------------//
    checkExpired() {
      const me = this
      window['__sto-id__'] = setTimeout(function() {
        //if (new Date().getTime() > this.expiration) {
        if (new Date().getTime() > me.expiration) {
        //if (true) {
          // alert('timeout')
          me.loginCheckAlert()
        } else {
          me.checkExpired()
        }
      //  console.log("==========================================")
      //  console.log("new Date().getTime()", new Date().getTime())
      //  console.log("this.expiration", me.expiration)
      // console.log("==========================================")
      }, 1000)
    },
    loginCheckAlert() {
      // 로그인 팝업 상태
      this.isLoginCheckPopView = true
      this.dangerModal= true
    },
    loginConservation() {
      //로그인 했을시
      this.isLoginCheckPopView = false
      this.dangerModal= false
    },
    closePop() {
      //로그인 팝업 닫기
      this.isLoginCheckPopView = false
      this.dangerModal= false
    },
    //--------------------------------------------------//
    // ...mapMutations(uxui, {
    //     toggleSidebarDesktop: "toggleSidebarDesktop",
    //     toggleSidebarMobile: "toggleSidebarMobile",
    //     set: "set",
    //     toggle: "toggle"
    // }),
    // ...mapActions(uxui, {
    // }),
    updateTime() {
        let cd = new Date()
        let amPm = 'AM'
        let currentHours = this.zeroPadding(cd.getHours(),2)
        let currentMinute = this.zeroPadding(cd.getMinutes() ,2)
        let currentSeconds =  this.zeroPadding(cd.getSeconds(),2)

        if(currentHours >= 12){ // 시간이 12보다 클 때 PM으로 세팅, 12를 빼줌
          amPm = 'PM';
          currentHours = this.zeroPadding(cd.getHours() - 12, 2)
        }

        this.time =  amPm + ' ' + currentHours + ':' + currentMinute + ':' + currentSeconds
        this.date = this.zeroPadding(cd.getFullYear(), 4) + '.' + this.zeroPadding(cd.getMonth()+1, 2) + '.' + this.zeroPadding(cd.getDate(), 2) + ' '
        // this.date = this.zeroPadding(cd.getFullYear(), 4) + '.' + this.zeroPadding(cd.getMonth()+1, 2) + '.' + this.zeroPadding(cd.getDate(), 2) + ' ' + this.week[cd.getDay()]
    },
    updateTimezone() {
      let cd = moment().format('YYYY.MM.DD HH:mm:ss')
      let amPm = 'AM'

      //let dateTime = cd.substring(0,4) + '.' + cd.substring(5,7) + '.' + cd.substring(8,10)
      //if (Number(cd.substring(11,13))>12) amPm = 'PM'
      //let dateTime = cd.substring(0,10) + ' ' + amPm + ' ' + cd.substring(11,19)

      this.date = cd.substring(0,10)

      if (Number(cd.substring(11,13))>12) amPm = 'PM'
      this.time = amPm + ' ' + cd.substring(11,19)
    },
    async updateWeather() {
//console.log('updateWeather...')
        let params = new Array()
        let siteId = utils.getUserInformation().selectedUserSite.siteId

        let moduleName = "v1/dashboard/"+siteId+"/weather"
        let payload = { params: params, moduleName: moduleName }
        await this.setDataListAction(payload)
//console.log(this.data2)
        let temperature = '-'
        let weatherStatus = 'unknown'
        if (this.data2.status == '200' && this.data2.content != undefined) {
          let weatherInfo = this.data2.content
          weatherStatus = weatherInfo.weather.toLowerCase().trim()
console.log('weatherStatus = '+weatherStatus)
          if (weatherStatus.indexOf('clear') > -1) weatherStatus = 'sunny'
          else if (weatherStatus.indexOf('few') > -1) weatherStatus = 'partlysunny'
          else if (weatherStatus.indexOf('scattered') > -1) weatherStatus = 'cloudy'
          else if (weatherStatus.indexOf('clouds') > -1) weatherStatus = 'cloudy'
          else if (weatherStatus.indexOf('showerrain') > -1) weatherStatus = 'chancesleet'
          else if (weatherStatus.indexOf('rain') > -1) weatherStatus = 'rain'
          else if (weatherStatus.indexOf('drizzle') > -1) weatherStatus = 'hazy'
          else if (weatherStatus.indexOf('haze') > -1) weatherStatus = 'hazy'
          else if (weatherStatus.indexOf('thunderstorm') > -1) weatherStatus = 'tstorms'
          else if (weatherStatus.indexOf('snow') > -1) weatherStatus = 'snow'
          else if (weatherStatus.indexOf('mist') > -1) weatherStatus = 'fog'
          else if (weatherStatus.indexOf('fog') > -1) weatherStatus = 'fog'
          // else if (weatherStatus.indexOf('clouds') > -1) weatherStatus = 'cloudy'
          else weatherStatus = 'unknown'

          temperature = weatherInfo.temperature
        }

        this.weather = weatherStatus
        this.temperature = temperature
    },
    zeroPadding(num, digit) {
      let zero = '';
      for(let i = 0; i < digit; i++) {
          zero += '0'
      }
      return (zero + num).slice(-digit)
    },
    profileSetting() {
      this.setForm()
      this.setInitLangType();
      this.$refs.profileModal.open()
    }
  },
  mixins: [validationMixin],
    // validation 사용 방법은 아래 url 참조하세요.
    //https://vuelidate.js.org/#sub-collections-validation
    validations() {
      if(this.changePassword){
        return {
          form: {
            siteId: {},
            userId: {},
            currentPassword: {
              required,
            },
            newPassword: {
              required,
              strongPass: helpers.regex('strongPass', /(?=.*\d)(?=.*[a-z]).{6,}/)
            },
            confirmPassword: {
              required,
              sameAsPassword: sameAs("newPassword")
            },
            userName: {},
            userCellphoneNo: {
              numeric,
              maxLength: maxLength(20)
            },
            userLanguageType: {
              required
            },
            userThemaType: {
              required
            }
          }
        }
      }else{
        return {
          form: {
            siteId: {},
            userId: {},
            currentPassword: {},
            newPassword: {
              strongPass: helpers.regex('strongPass', /(?=.*\d)(?=.*[a-z]).{6,}/) //(?=.*[A-Z])
            },
            confirmPassword: {
              sameAsPassword: sameAs("newPassword")
            },
            userName: {},
            userCellphoneNo: {
              numeric,
              maxLength: maxLength(20)
            },
            userLanguageType: {
              required
            },
            userThemaType: {
              required
            }
          }
        }
      }

    }
}
</script>
