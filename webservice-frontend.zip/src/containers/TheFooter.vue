<template>
  <CFooter :fixed="false" id="appFooter">
    <div>
      <a href="https://www.hanwhacorp.co.kr/eng/index.jsp" target="_blank" class="color-hanwha--70">Hanwhacorp</a>
      <span class="ml-1">&copy; {{new Date().getFullYear()}} creative.</span>
    </div>
    <div class="ml-auto">
      <span class="mr-1">ver.</span>
      <span>0.0.9.7</span>
      <!-- <a href="https://coreui.io/vue">CoreUI for Vue </a> -->
    </div>
  </CFooter>
</template>

<script>
export default {
  name: 'TheFooter'
}
</script>
