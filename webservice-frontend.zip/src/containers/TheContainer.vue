<template>
  <div class="c-app" :class="{ 'c-dark-theme': $store.state.uxui.darkMode }">
    <TheSidebar/>
    <!-- <TheAside/> -->
    <CWrapper>
      <TheHeader/>
      <div class="c-body">
        <main class="c-main">
          <CContainer fluid>
            <transition name="fade">
              <router-view :key="$route.fullPath"></router-view>
            </transition>
          </CContainer>
        </main>
        <TheFooter/>
      </div>
    </CWrapper>
  </div>
</template>

<script>
import TheSidebar from '@/containers/TheSidebar'
import TheHeader from '@/containers/TheHeader'
import TheFooter from '@/containers/TheFooter'
// import TheAside from '@/containers/TheAside'

// import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'

// const uxui = 'uxui'

export default {
  name: 'TheContainer',
  components: {
    TheSidebar,
    TheHeader,
    TheFooter,
    // TheAside
  },
    computed: {
    // ...mapState(uxui, {
    //     sidebarShow: "sidebarShow",
    //     sidebarMinimize: "sidebarMinimize",
    //     asideShow: "asideShow",
    //     darkMode: "darkMode",
    // }),
    // ...mapGetters(uxui, {
    // }),
  },
  methods: {
    // ...mapMutations(uxui, {
    //     toggleSidebarDesktop: "toggleSidebarDesktop",
    //     toggleSidebarMobile: "toggleSidebarMobile",
    //     set: "set",
    //     toggle: "toggle"
    // }),
    // ...mapActions(uxui, {
    // }),
  },
}
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
