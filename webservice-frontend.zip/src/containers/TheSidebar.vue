<template>
  <CSidebar 
    id="appSliderMenu"
    :minimize="minimize"
    unfoldable
    :show="show"
    @update:show="(value) => $store.commit('uxui/set', ['sidebarShow', value])"
  >
    <CSidebarBrand class="d-md-down-none" to="/">
      <CImg
          src="img/main-logo.png"

          class="c-sidebar-brand-full"
          name="logo" 
          size="custom-size"
          :height="35" 
          viewBox="0 0 556 134"
        />
      <CImg
          src="img/main-logo-mini.png"

          class="c-sidebar-brand-minimized"
          name="logo" 
          size="custom-size"
          :height="35" 
          viewBox="0 0 556 134"
        />
      <!-- <CIcon 
        class="c-sidebar-brand-full" 
        name="logo" 
        size="custom-size"
        :height="35" 
        viewBox="0 0 556 134"
      />
      <CIcon 
        class="c-sidebar-brand-minimized" 
        name="logo" 
        size="custom-size"
        :height="35"
        viewBox="0 0 110 134"
      /> -->
    </CSidebarBrand>
    <!-- <CRenderFunction flat :contentToRender="$options.nav"/> -->

    <!-- side navi menu list -->
    <CSidebarNav>
      <li
        v-for="(listItem, index) in navItems[0]._children" 
        :key="index"
        :class="{
          'c-sidebar-nav-title' : listItem._name === 'CSidebarNavTitle',
          'c-sidebar-nav-item' : listItem._name === 'CSidebarNavItem'
        }"
      >
        <span v-if="listItem._children">{{ listItem._children[0] }}</span>
        <router-link
          v-if="listItem.name"
          :to="listItem.to" 
          class="c-sidebar-nav-link"
        >
            <!-- <CIcon :name="listItem.icon" class="c-sidebar-nav-icon"/> -->
            <app-icon :name="listItem.icon" size="m" fill class="c-sidebar-nav-icon" :class="listItem.icon"/>
            {{ listItem.name }}
        </router-link>
      </li>
    </CSidebarNav>

    <!-- <CRenderFunction flat :contentToRender="navItems"/> -->
    <CSidebarMinimizer 
      class="c-d-md-down-none position-relative" 
      @click.native="$store.commit('uxui/toggle', 'sidebarMinimize')"
      />
  </CSidebar>
</template>

<script>


import nav from '@/containers/_nav'

import store from '@/store'
import utils from '@/assets/js/utils'
import config from '@/assets/js/config'
//import { mapGetters, mapActions } from 'vuex'
import moment from 'moment'

import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

// import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'


import { mapGetters, mapActions } from 'vuex'
const userInfo = 'loginLogout'
const uxui = 'uxui'


export default {
  name: 'TheSidebar',
  nav,
  components: {
    AppIcon
  },
  data () {
    return {      
      currentTime: moment().format('YYYY-MM-DD HH:mm:ss'),
      // nav: [],
      nav: nav.items,
      defaultNav: nav.items,

      // isAuthenticated: false,
      // userName: '',
      // userDepartment: '',
      // userPermissionList: [],
      // menuList: [],
      // codeList: [],
      // menuItems : [],
      // expiration: '',
      //isLoginCheckPopView: false // 로그인체크 팝업 상태값
    }
  },  
  mounted () {
    console.log('navList >>>>>', this.navItems)
    // this.currentTime = moment().format('YYYY-MM-DD HH:mm:ss')
    // console.log(this.nav);
    // this.nav = this.nav.splice(2)
    //this.checkExpired();

  },

  //--------------------------------------------------//    
  //2020.08.13
  async created() {

    //dbs = JSON.parse(CryptoJS.AES.decrypt(localStorage.dbs, "Secret Passphrase").toString(CryptoJS.enc.Utf8))
    let getUserSelectedSiteInfo = utils.getUserInformation().selectedUserSite
    //console.log("getUserSelectedSiteInfo ::: ", getUserSelectedSiteInfo)
    //let getUserSelectedSiteInfo = JSON.parse(this.CryptoJS.AES.decrypt(localStorage.getItem('selectedUserSite'), "Secret Passphrase").toString(this.CryptoJS.enc.Utf8))
    this.reSetSelectedSiteInfo(getUserSelectedSiteInfo)

  },   

  methods: {
    ...mapActions(userInfo, {
        reSetUserInfo : 'reSetUserInfo',
        reSetSelectedSiteInfo : 'reSetSelectedSiteInfo',
    }),        

    // ...mapMutations(uxui, {
    //     toggleSidebarDesktop: "toggleSidebarDesktop",
    //     toggleSidebarMobile: "toggleSidebarMobile",
    //     set: "set",
    //     toggle: "toggle"
    // }),    
    // ...mapActions(uxui, {
    // }),

    checkExpired() {
      const me = this
      window['__sto-id__'] = setTimeout(function() {
        if (new  Date() > new Date(me.expiration)) {
          // alert('timeout')
          me.loginCheckAlert()
        } else {
          me.checkExpired()
        }
      }, 1000)
    },    
    showToast(message) {
        //토스트 메세지 기본
        this.$toasted.show(message, {
            theme: "primary", 
            position: 'top-right',
            duration : 1500,
            fullWidth: false
        });
    },
    showToastRed(message) {
        //토스트 메세지 에러 전용
        this.$toasted.show(message, {
            theme: "bubble", 
            position: 'top-right',
            duration : 1500,
            fullWidth: false
        });
    },    

    logOut() {
      this.showToastRed('로그아웃 되었습니다.')
      store.dispatch('LOGOUT').then(()=> this.$router.push({path:'/user/login'}))
      // this.$router.push({path:'/admin/Login'})
    },
    logIn() {
      // this.showToastRed('로그아웃 되었습니다.')
      store.dispatch('LOGOUT').then(()=> this.$router.push({path:'/user/login'}))
      // this.$router.push({path:'/admin/Login'})
    },
    getSelectedSchemeCheck() {
      return config.geSelectedScheme()
    },
    loginCheckAlert() {
      // 로그인 팝업 상태
      this.isLoginCheckPopView = true
    },
    loginConservation() {
      //로그인 했을시
      this.isLoginCheckPopView = false
    },
    closePop() {
      //로그인 팝업 닫기
      this.isLoginCheckPopView = false
    }

  },  
  //--------------------------------------------------//      
  watch: {
    //  navItems() {
    //    console.log("#################### this.navItems >>> : ")
    //    //console.log("#################### this.navItems >>> : ", this.navItems)
    //  }
  },
  //--------------------------------------------------//      
  computed: {
    ...mapGetters(userInfo, {
        userName : 'getUserName',
        userCellphoneNo: 'getUserCellphoneNo',
        userId : 'getUserId',
        userThemaType : 'getUserThemaType',
        userLangType : 'getUserLangType',
        userCompany : 'getUserCompany',
        userSite : 'getUserSite',
        expiration : 'getExpiration',
        userPermissionList : 'getUserPermissionList',
        userMenuList : 'getUserMenuList',
        codeList : 'getCodeList',
        isAuthenticated : 'getIsAuthenticated',
        selectedUserSite : 'getSelectedUserSite',
    }),    
    // ...mapState(uxui, {
    //     sidebarShow: "sidebarShow",
    //     sidebarMinimize: "sidebarMinimize",
    //     asideShow: "asideShow",
    //     darkMode: "darkMode",
    // }),    
    // ...mapGetters(uxui, {
    // }),
    //--------------------------------------------------//    
    //2020.08.13
    name () {
      return this.$route.name
    },
    list () {
      return this.$route.matched.filter((route) => route.name || route.meta.label )
    },
    //--------------------------------------------------//    
    show () {
      return this.$store.state.uxui.sidebarShow 
    },
    minimize () {
      return this.$store.state.uxui.sidebarMinimize 
    },
    navItems () {
      return [
        {
          _name: 'CSidebarNav',
          _children: this.sidebarNavChildren
        }
      ]
    },
    sidebarNavChildren () {
      return this.userMenuList.map(menuItem => {
        if(menuItem.to){
          let langKey = menuItem.to.split('/')[menuItem.to.split('/').length - 1]
          menuItem.name = this.$t(`menu.${langKey}`)
        }
        return {
          _name: menuItem._name,
          _children : menuItem._children,
          name: menuItem.name,
          to: menuItem.to,
          icon: menuItem.icon || 'cil-spreadsheet'
        }
      })
    }

  }
}
</script>
