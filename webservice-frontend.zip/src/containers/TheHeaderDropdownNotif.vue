<template>
  <CDropdown
    placement="bottom-end"
    :caret="false"
    in-nav
    class="c-header-nav-item d-md-down-none px-2 header-notif-wrap"
    add-menu-classes="header-dropdown pt-0"
  >
    <template #toggler>
      <CHeaderNavLink>
        <!-- <CIcon name="cil-bell"/> -->
        <app-icon name="bell" size="sm" fill class="dark-white" />
        <CBadge shape="pill" color="hanwha">{{ notifList.length }}</CBadge>
      </CHeaderNavLink>
    </template>
    <CDropdownHeader
      tag="div"
      class="text-center"
    >
      <strong>{{$t('commonLabel.alarm')}}</strong>
    </CDropdownHeader>
    <ul class="list-unstyled header-notif-list">
      <li
        v-for="(list, idx) in notifList"
        :key="idx"
      >
        <CDropdownItem @click="listClick(list)" v-if="list.type=='Cri'">
          <span class="circle" :class="{'red': true, 'yellow': false, 'blue': false}">Cri</span>
          <div class="value-wrap">
            <span class="tit d-block">{{ list.per }}</span>
            <span class="time d-block">{{ list.processTime }}</span>
            <span class="name d-block">{{ list.name }}</span>
          </div>
        </CDropdownItem>
        <CDropdownItem @click="listClick(list)" v-if="list.type=='Delay'">
          <span class="circle" :class="{'red': false, 'yellow': true, 'blue': false}">Delay</span>
          <div class="value-wrap">
            <span class="tit d-block">operation Progress <span class="num">{{ list.ingPer }}%</span></span>
            <span class="time d-block">{{ list.blastDate }}</span>
            <span class="name d-block">{{ list.name }}</span>
          </div>
        </CDropdownItem>
        <CDropdownItem @click="listClick(list)" v-if="list.type=='Vib'">
          <span class="circle" :class="{'red': false, 'yellow': false, 'blue': true}">Vib</span>
          <div class="value-wrap">
            <span class="tit d-block">PPV <span class="num">{{ list.ppv }}</span></span>
            <span class="time d-block">{{ list.processTime }}</span>
            <span class="name d-block">{{ list.name }}</span>
          </div>
        </CDropdownItem>
      </li>
      <div v-show="!notifList.length" v-text="$t('message.noData')" class="info-txt" style="padding-bottom:10px" />
    </ul>
    <!-- <CDropdownItem>
      <CIcon name="cil-user-unfollow" class="text-danger"/> User deleted
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-chart-pie" class="text-info"/> Sales report is ready
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-basket" class="text-primary"/> New client
    </CDropdownItem>
    <CDropdownItem>
      <CIcon name="cil-speedometer" class="text-warning"/> Server overloaded
    </CDropdownItem> -->

  </CDropdown>
</template>

<script>
import AppIcon from '@/components/AppIcon'
import(/* webpackChunkName: "svgicon" */ `@/components/icons`)

import moment from 'moment'
import i18n from '@/locales'
import utils from '@/assets/js/utils'
import { mapGetters, mapActions } from 'vuex'

const blastLibrary = 'blastLibrary'

export default {
  name: 'TheHeaderDropdownNotif',
  components: {
    AppIcon
  },
  data () {
    return {
      intervalNotif: '',
      notifList: [],
      notifChk: []
    }
  },
  computed: {
    ...mapGetters(blastLibrary, {
      data: 'getData',
      dataList: 'getDataList',
    }),
  },
  async created() {
    this.setNotif()

    this.intervalNotif = setInterval(() => {
      this.setNotif()
    }, 60000);  // 60초
  },
  destroyed() {
    clearInterval(this.intervalNotif)
  },
  methods: {
    ...mapActions(blastLibrary, {
      setDataListAction: 'setDataList',
    }),
    async setNotif() {
//console.log('setNotif....')
      let that = this
      let nowDate = moment()

      // 입력값 설정
      let params = new Array()
      let siteId = utils.getUserInformation().selectedUserSite.siteId

      let moduleName = "v1/dashboard/"+siteId+"/alarm"
      let payload = { params: params, moduleName: moduleName }
      await this.setDataListAction(payload)

      let baseDiff = 10 // 10분
      that.notifList = []
      this.dataList.forEach(function (item) {
        let type = ''
        if (item.type == 'vibration') type = 'Vib'
        else if (item.type == 'workDelay') type = 'Delay'
        else if (item.type == 'equipment') type = 'Cri'

        let alarmKey = type+'_'+item.blastId
        let blastDate = moment(item.blastDate).format('YYYY-MM-DD HH:mm')
        let diff = moment.duration(nowDate.diff(blastDate)).asMinutes()

        if (diff > 0  && diff < baseDiff) {
          let idx = that.notifChk.indexOf(alarmKey)
          if (idx == -1) {
            utils.showToastRed2(i18n.t('message.alarmOccurs', [type]))
            that.notifChk.push(alarmKey)
          }
        }

        that.notifList.push({
          type: type,
          id: (item.blastId!=null?item.blastId:''),
          name: (item.name!=null?item.name:'-'),
          ingPer: (item.ingPer!=null?item.ingPer:'-'),
          blastDate: blastDate,
          ppv: (item.ppv!=null?item.ppv:'-'),
          processTime: item.processTime
        })
      })
//console.log(that.notifList)
    },
    listClick(item) {
      let query = { gubun: item.type, id: item.id, queryId: (Math.floor(Math.random() * (100 - 1 + 1)) + 1) }
      if (this.$route.name == 'SiteDashboard') {
        this.$router.push({ path: '/sitedashboard', query })
      }else this.$router.push({ path: '/sitedashboard', query }).catch(()=>{});
    }
  }
}
</script>
<style scoped>
  .c-icon {
    margin-right: 0.3rem;
  }
</style>