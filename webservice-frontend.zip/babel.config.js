module.exports = {
  presets: [
    ["@babel/env", 
    { "targets": { 
      "browsers": [
        "last 2 versions", ">= 5%"
      ] }, 
      "corejs": {"version":3, "proposals": true }
    }
  ]
  ]
}
