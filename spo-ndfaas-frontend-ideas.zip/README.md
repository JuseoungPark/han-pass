# spo-ndfaas-frontend-ideas

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

## NPM Registry

```
http://10.220.140.221:8081/repository/npm-group/
```

## Using eslint & prettier

- Commit 전 자동으로 문법 검사를 하고, 코드 포맷팅을 합니다.
- 변수가 선언되었으나 사용되지 않는 등의 eslint가 자동으로 수정 할 수 없는 에러가 있는 경우 commit이 되지 않습니다.

### VS Code

- 아래 설정과 Extension을 설치
- 파일 저장시 자동으로 코드 포맷팅을 합니다.
- 문법적 에러, 포맷팅 규칙에 맞지 않는 경우 에디터에 표시됩니다.

#### Setting

.vscode/settings.json

```
{
  "editor.tabSize": 2,
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[javascript]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  },
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "eslint.format.enable": true,
  "eslint.alwaysShowStatus": true,
  "eslint.probe": ["javascript", "javascriptreact", "vue"]
}
```

#### Extension

- ESLint (https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
- Prettier - Code formatter (https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
