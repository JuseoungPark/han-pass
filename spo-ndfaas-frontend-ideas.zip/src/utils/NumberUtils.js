const dayString = ['월', '화', '수', '목', '금', '토', '일']
export class NumberUtils {
  constructor() {}

  static numberWithCommas(value) {
    var x = value ? parseInt(value, 10) : 0
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  }

  static timeWithColons(value) {
    var x = parseInt(value, 10)
    if (isNaN(x)) return 0
    var hours = Math.floor(x / 3600)
    var minutes = Math.floor(x / 60) % 60
    var seconds = x % 60

    return [hours, minutes, seconds]
      .map((v) => (v < 10 ? '0' + v : v))
      .filter((v, i) => v !== '00' || i > 0)
      .join(':')
  }

  static isNumber(value) {
    return value.replace(/[^0-9]/g, '')
  }

  static dayToString(value) {
    var x = parseInt(value, 10)
    if (isNaN(x)) return ''
    if (x < 0 || x > 6) return ''
    return dayString[x]
  }
}
