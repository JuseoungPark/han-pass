const TokenKey = 'Admin-Token'

export function getToken() {
  // return localStorage.getItem(TokenKey)
  return 'admin-token'
}

export function setToken(token) {
  return localStorage.setItem(TokenKey, token)
}

export function getUser() {
  return localStorage.getItem('user')
}

export function setUser(user) {
  return localStorage.setItem('user', user.userName)
}

export function removeToken() {
  return localStorage.removeItem(TokenKey)
}
