import Vue from 'vue'

Vue.filter('numberWithCommas', (value) => {
  var x = parseInt(value, 10)
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
})
