import { NumberUtils } from '@/utils/NumberUtils'

export class GridFormatter {
  constructor() {}

  static numberWithCommas(params) {
    return NumberUtils.numberWithCommas(params.value)
  }

  static timeWithColons(params) {
    return NumberUtils.timeWithColons(params.value)
  }

  static emptyWithHyphens(params) {
    if (!params.value) return '-'
  }

  static dayToString(params) {
    return NumberUtils.dayToString[params.value]
  }
}
