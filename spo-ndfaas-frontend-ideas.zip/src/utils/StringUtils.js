// import { StringUtils } from '@/utils/StringUtils'

String.prototype.format = function() {
  var formatted = this
  for (var i = 0; i < arguments.length; i++) {
    var regexp = new RegExp('\\{' + i + '\\}', 'gi')
    formatted = formatted.replace(regexp, arguments[i])
  }
  return formatted
}

export class StringUtils {
  constructor() {}

  static lPad(str, padLen, padStr) {
    if (padStr.length > padLen) return str
    str += ''
    padStr += ''
    while (str.length < padLen) str = padStr + str
    str = str.length >= padLen ? str.substring(0, padLen) : str

    return str
  }

  static objQueryString(obj) {
    let queryString = Object.keys(obj)
      .map((key) => key + '=' + obj[key])
      .join('&')
    return '&' + queryString
  }

  static isEmptyObject(obj) {
    for (var i in obj) return false
    return true
  }

  static isTelNumber(number) {
    let flag = false
    if (number.length === 9) {
      flag = /^[0-9]{4}-[0-9]{4}/.test(number)
    } else {
      flag = /^[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}/.test(number)
    }
    return flag
  }

  static isEmailAddress(address) {
    return /^([0-9a-zA-Z_\\.-]+)@([0-9a-zA-Z_-]+)(\.[0-9a-zA-Z_-]+){1,2}$/.test(
      address
    )
  }

  static getPhoneMask(phoneNumber) {
    if (!phoneNumber) return phoneNumber
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
    let res = ''
    if (phoneNumber.length < 3) {
      res = phoneNumber
    } else {
      if (phoneNumber.substr(0, 2) == '02') {
        if (phoneNumber.length <= 5) {
          //02-123-5678
          res = phoneNumber.substr(0, 2) + '-' + phoneNumber.substr(2, 3)
        } else if (phoneNumber.length > 5 && phoneNumber.length <= 9) {
          //02-123-5678
          res =
            phoneNumber.substr(0, 2) +
            '-' +
            phoneNumber.substr(2, 3) +
            '-' +
            phoneNumber.substr(5)
        } else if (phoneNumber.length > 9) {
          //02-1234-5678
          res =
            phoneNumber.substr(0, 2) +
            '-' +
            phoneNumber.substr(2, 4) +
            '-' +
            phoneNumber.substr(6)
        }
      } else {
        if (phoneNumber.length < 8) {
          if (phoneNumber.length === 4 && phoneNumber.substr(0, 3) == '010') {
            res = phoneNumber.substr(0, 3) + '-' + phoneNumber.substr(3, 4)
          } else {
            res = phoneNumber
          }
        } else if (phoneNumber.length == 8) {
          res = phoneNumber.substr(0, 4) + '-' + phoneNumber.substr(4)
        } else if (phoneNumber.length == 9) {
          res =
            phoneNumber.substr(0, 3) +
            '-' +
            phoneNumber.substr(3, 3) +
            '-' +
            phoneNumber.substr(6)
        } else if (phoneNumber.length == 10) {
          res =
            phoneNumber.substr(0, 3) +
            '-' +
            phoneNumber.substr(3, 3) +
            '-' +
            phoneNumber.substr(6)
        } else if (phoneNumber.length > 10) {
          //010-1234-5678
          res =
            phoneNumber.substr(0, 3) +
            '-' +
            phoneNumber.substr(3, 4) +
            '-' +
            phoneNumber.substr(7)
        }
      }
    }
    return res
  }
}
