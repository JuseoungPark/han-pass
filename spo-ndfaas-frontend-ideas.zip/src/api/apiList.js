export function callHistoryBookmarkAdd(params) {
  return this.$api.private.post('/api/history/bookmark/add', params)
}

export function callHistoryBookmarkDelete(params) {
  return this.$api.private.post(`/api/history/bookmark/delete`, params)
}

export function callHistoryExcept(params) {
  return this.$api.private.post(`/api/history/except`, params)
}

export function getBookmarkFolder() {
  return this.$api.private.get(`/api/bookmark/integrated/folder`)
}

export function getBookmarkFolderDetail(idx) {
  return this.$api.private.get(`/api/bookmark/integrated/folder/${idx}`)
}

export function getBookmarkFolderAdd(params) {
  return this.$api.private.post(`/api/bookmark/integrated/folder/add`, params)
}

// { no : no, folderno: folderno, updateUser: updateUser}
export function getBookmarkFolderItemAdd(params) {
  return this.$api.private.post(
    `/api/bookmark/integrated/folder/itemadd`,
    params
  )
}

// { no : no, bookmarkLevel: bookmarkLevel, updateUser: updateUser}
export function setBookmarkImportant(params) {
  return this.$api.private.post(`/api/bookmark/important`, params)
}

// { no : no, color: color, title: title, content: content, updateUser: updateUser}
export function updateBookmarkFolder(params) {
  return this.$api.private.post(
    `/api/bookmark/integrated/folder/update`,
    params
  )
}

// { no : no }
export function deleteBookmarkFolder(params) {
  return this.$api.private.post(
    `/api/bookmark/integrated/folder/delete`,
    params
  )
}

/*
해당페이지에서 가져다가 사용하는 법
import { callHistoryBookmarkAdd, callHistoryBookmarkDelete } from '@/plugins/api'
*/
