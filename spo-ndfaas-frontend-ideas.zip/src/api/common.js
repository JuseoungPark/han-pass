const getCommApi = {
  install(Vue) {
    const api = Vue.prototype.$api
    //인물유형코드
    Vue.prototype.$personTypeCode = async () => {
      let params = { cmmnCodeTyId: 'ND6006' }
      return new Promise(function(resolve) {
        api.analysis
          .get('/cmm/code', { params: params })
          .then((res) => {
            resolve(res.data.result)
          })
          .catch(function(error) {
            console.log(error)
            resolve(false)
          })
      })
    }
    //출처구분코드
    Vue.prototype.$originSeCode = async () => {
      return await api.analysis
        .get('/bookmark/origin-se-code')
        .then((res) => {
          return res.data.result
        })
        .catch(function(error) {
          console.log(error)
          return { error: error }
        })
    }

    //통화구분코드
    Vue.prototype.$talkTypeCode = () => {
      let params = { cmmnCodeTyId: 'ND0041' }
      return new Promise(function(resolve) {
        api.analysis
          .get('/cmm/code', { params: params })
          .then((res) => {
            resolve(res.data.result)
          })
          .catch(function(error) {
            console.log(error)
            resolve(false)
          })
      })
    }

    //통신사구분코드
    Vue.prototype.$telecomCode = async () => {
      let params = { cmmnCodeTyId: 'ND6018' }
      return await api.analysis
        .get('/cmm/code', { params: params })
        .then((res) => {
          return res.data.result
        })
    }

    Vue.prototype.$requestApi = (req) => {
      let url = req.url
      let method = req.method ? req.method : 'get'
      let data = undefined
      if (method === 'get') url += req.params ? '?' + req.params : ''
      else data = req.params

      let apiObj = api.analysis({
        url: url,
        method: method,
        data: data
      })
      console.log({
        url: url,
        method: method,
        data: data
      })

      return new Promise(function(resolve) {
        apiObj
          .then((res) => {
            resolve(res)
          })
          .catch(function(error) {
            console.log(error)
            return { error: error }
          })
      })
    }
  }
}

export default getCommApi
