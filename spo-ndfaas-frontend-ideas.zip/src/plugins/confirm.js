const Confirm = {
  install(Vue) {
    this.EventBus = Vue.prototype.$eventBus

    Vue.prototype.$alert = (message = null, options = {}) => {
      message && (options.message = message)
      options.alert = true

      return new Promise((resolve) => {
        Confirm.EventBus.$emit('confirm', options, resolve)
      })
    }

    Vue.prototype.$confirm = (message = null, options = {}) => {
      message && (options.message = message)
      options.alert = false

      return new Promise((resolve) => {
        Confirm.EventBus.$emit('confirm', options, resolve)
      })
    }
  }
}

export default Confirm
