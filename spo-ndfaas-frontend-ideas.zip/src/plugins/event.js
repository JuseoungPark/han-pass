import Vue from 'vue'

var EventBus = new Vue()
Object.defineProperties(Vue.prototype, {
  $eventBus: {
    get: function() {
      return EventBus
    }
  }
})
