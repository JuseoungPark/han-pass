import axios from 'axios'
import AnalysisApiHandler from './analysisApi'
import IncidentApiHandler from './incidentApi'

const Api = {
  install(Vue) {
    var incidentApi = axios.create({
      baseURL: process.env.VUE_APP_INCIDENT_API,
      headers: {
        Accept: 'application/json'
      }
    })
    incidentApi.handler = new IncidentApiHandler(incidentApi)

    var analysisApi = axios.create({
      baseURL: process.env.VUE_APP_ANALYSIS_API,
      headers: {
        Accept: 'application/json'
        // Authorization: 'Bearer token'
      }
    })
    // analysisApi.defaults.timeout = 20000
    analysisApi.handler = new AnalysisApiHandler(analysisApi)

    var privateApi = axios.create({
      baseURL: process.env.VUE_APP_PRIVATE_API,
      headers: {
        Accept: 'application/json'
      }
    })

    Vue.prototype.$axios = axios

    Vue.prototype.$api = {
      incident: incidentApi,
      analysis: analysisApi,
      private: privateApi
    }
  }
}

export default Api
