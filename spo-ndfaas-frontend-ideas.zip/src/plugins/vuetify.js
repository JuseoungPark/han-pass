import 'roboto-fontface/css/roboto/roboto-fontface.css'
import '@mdi/font/css/materialdesignicons.css'
import 'material-design-icons-iconfont/dist/material-design-icons.css'
import Vue from 'vue'
import Vuetify from 'vuetify'
import '@/styles/index.scss'

Vue.use(Vuetify)

const vuetify = new Vuetify({
  theme: {
    dark: false,
    default: 'light',
    themes: {
      light: {
        primary: '#48ccd2',
        secondary: '#97989a',
        accent: '#82B1FF',
        error: '#FF5252',
        info: '#2196F3',
        success: '#4CAF50',
        warning: '#FB8C00'
      },
      dark: {
        primary: '#48ccd2',
        secondary: '#8b8c8f',
        accent: '#82B1FF',
        error: '#FF5252',
        info: '#2196F3',
        success: '#4CAF50',
        warning: '#FB8C00'
      }
    }
  }
})

export default vuetify

Vue.prototype.$setThemeClass = (theme) => {
  var html = document.getElementsByTagName('html')[0]
  html.classList.remove(theme ? 'theme--light' : 'theme--dark')
  html.classList.add(theme ? 'theme--dark' : 'theme--light')
}

Vue.prototype.$setThemeClass(vuetify.preset.theme.dark)
