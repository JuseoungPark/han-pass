class AnalysisApiHandler {
  constructor(api) {
    this.api = api
  }

  async getDateMinMax(incidentId, callback) {
    let dateMin = undefined
    let dateMax = undefined
    let count = 1

    let response = await this.api(
      `/talk/unity-dtlses?incdntId=${incidentId}&requestPage=1&rowCntByPage=1`
    )

    if (
      response.data.code === '200' &&
      response.data.result.data &&
      response.data.result.data.length > 0
    ) {
      dateMin = response.data.result.data[0].talkBgngDt.substring(0, 10)
      count = response.data.result.pageInfo.rowAllCnt

      response = await this.api(
        `/talk/unity-dtlses?incdntId=${incidentId}&requestPage=${count}&rowCntByPage=1`
      )

      if (
        response.data.code === '200' &&
        response.data.result.data &&
        response.data.result.data.length > 0
      ) {
        dateMax = response.data.result.data[0].talkBgngDt.substring(0, 10)
        callback(dateMin, dateMax)
      }
    }
  }
}

export default AnalysisApiHandler
