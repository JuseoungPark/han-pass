import Vue from 'vue'
import router from '@/router'
import store from '@/store'
import i18n from '@/plugins/i18n'
// import NProgress from 'nprogress'
// import 'nprogress/nprogress.css'
import tabsStore from '@/store/modules/tabsView'

// NProgress.configure({ showSpinner: false })

const whiteList = ['/login', '/auth-redirect'] // no redirect whitelist

router.beforeEach((to, from, next) => {
  // NProgress.start()

  const hasToken = store.getters.userInfo.token

  if (hasToken) {
    if (to.path === '/login') {
      next({ path: '/' })
      // NProgress.done()
    } else if (store.getters.addRouters.length === 0) {
      store.dispatch('permission/generateRoutes').then((accessRoutes) => {
        router.addRoutes(accessRoutes)
        next({ ...to, replace: true })
      })
    } else {
      if (tabsStore.state.visitedViews.length > tabsStore.state.tabLimit) {
        if (!tabsStore.state.visitedViews.some((e) => e.path === to.path)) {
          Vue.prototype.$alert(i18n.tc('message.error.limitTab'))
          next(from.path)
        }
      }

      next()
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else {
      next('/login')
      // NProgress.done()
    }
  }
})

router.afterEach(() => {
  // NProgress.done()
})
