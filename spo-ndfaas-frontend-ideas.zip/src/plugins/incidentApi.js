class incidentApi {
  constructor(api) {
    this.api = api
  }

  login(userId, password, callback) {
    this.api({
      url: '/lgn/log-in/',
      method: 'POST',
      data: {
        lgnId: userId,
        encPassword: password
      }
    })
      .then((res) => {
        callback(res)
      })
      .catch((error) => {
        console.log(error)
      })
  }
}

export default incidentApi
