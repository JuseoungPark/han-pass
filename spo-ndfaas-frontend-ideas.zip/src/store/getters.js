const getters = {
  sidebar: (state) => state.app.sidebar,
  appbar: (state) => state.app.appbar,
  rightBar: (state) => state.app.rightBar,
  bottomSheet: (state) => state.app.bottomSheet,
  speedDial: (state) => state.app.speedDial,
  visitedViews: (state) => state.tabsView.visitedViews,
  cachedViews: (state) => state.tabsView.cachedViews,
  userInfo: (state) => state.user.userInfo,
  permission_routes: (state) => state.permission.routes,
  addRouters: (state) => state.permission.addRoutes,
  incidentInfo: (state) => state.incident.incidentInfo
}

export default getters
