const state = {
  incidentInfo: {
    id: '1160100000000000373',
    // id: '1160100000000000543',
    number: '사건-A1-15차-20201227',
    manager: '특사경A1'
  }
}

const mutations = {
  SET_INCIDENTID: (state, code) => {
    if (typeof code === 'string') state.incidentInfo.id = code
  },
  SET_INCIDENT_INFO: (state, info) => {
    if (typeof info.id === 'string') state.incidentInfo.id = info.id
    if (typeof info.number === 'string') state.incidentInfo.number = info.number
    if (typeof info.manager === 'string')
      state.incidentInfo.manager = info.manager
  }
}

const actions = {
  setIncidentId({ commit }, code) {
    commit('SET_INCIDENTID', code)
  },
  setIncidentInfo({ commit }, info) {
    commit('SET_INCIDENT_INFO', info)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
