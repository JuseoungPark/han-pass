const state = {
  sidebar: {
    opened: false,
    show: true,
    withoutAnimation: false
  },
  appbar: {
    show: true
  },
  bottomSheet: {
    opened: false,
    show: true
  },
  rightBar: {
    opened: false,
    show: true
  },
  speedDial: {
    opened: false,
    show: true
  }
}

const mutations = {
  TOGGLE_SIDEBAR: (state) => {
    state.sidebar.opened = !state.sidebar.opened
    state.sidebar.withoutAnimation = false
  },
  CLOSE_SIDEBAR: (state, withoutAnimation) => {
    state.sidebar.opened = false
    state.sidebar.withoutAnimation = withoutAnimation
  },
  HIDE_SIDEBAR: (state) => {
    state.sidebar.show = false
    state.sidebar.withoutAnimation = false
  },
  HIDE_APPBAR: (state) => {
    state.appbar.show = false
  },
  TOGGLE_BOTTOMSHEET: (state) => {
    state.bottomSheet.opened = !state.bottomSheet.opened
  },
  CLOSE_BOTTOMSHEET: (state) => {
    state.bottomSheet.opened = false
  },
  HIDE_BOTTOMSHEET: (state) => {
    state.bottomSheet.show = false
  },
  TOGGLE_RIGHTBAR: (state) => {
    state.rightBar.opened = !state.rightBar.opened
  },
  CLOSE_RIGHTBAR: (state) => {
    state.rightBar.opened = false
  },
  HIDE_RIGHTBAR: (state) => {
    state.rightBar.show = false
  },
  HIDE_SPEEDDIAL: (state) => {
    state.speedDial.show = false
  }
}

const actions = {
  toggleSideBar({ commit }) {
    commit('TOGGLE_SIDEBAR')
  },
  closeSideBar({ commit }, { withoutAnimation }) {
    commit('CLOSE_SIDEBAR', withoutAnimation)
  },
  hideSideBar({ commit }) {
    commit('HIDE_SIDEBAR')
  },
  hideAppBar({ commit }) {
    commit('HIDE_APPBAR')
  },
  toggleBottomSheet({ commit }) {
    commit('TOGGLE_BOTTOMSHEET')
  },
  closeBottomSheet({ commit }) {
    commit('CLOSE_BOTTOMSHEET')
  },
  hideBottomSheet({ commit }) {
    commit('HIDE_BOTTOMSHEET')
  },
  toggleRightBar({ commit }) {
    commit('TOGGLE_RIGHTBAR')
  },
  closeRightBar({ commit }) {
    commit('CLOSE_RIGHTBAR')
  },
  hideRightBart({ commit }) {
    commit('HIDE_RIGHTBAR')
  },
  hideSpeedDial({ commit }) {
    commit('HIDE_SPEEDDIAL')
  },
  setPopupMode({ commit }) {
    commit('HIDE_SIDEBAR')
    commit('HIDE_APPBAR')
    commit('HIDE_RIGHTBAR')
    commit('HIDE_BOTTOMSHEET')
    commit('HIDE_SPEEDDIAL')
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
