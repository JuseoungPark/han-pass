import { resetRouter } from '@/router'

const state = {
  userInfo: {
    loginId: '',
    userId: '',
    userName: '',
    avatar: '',
    introduction: '',
    // token: '',
    // roles: ['', '']
    token: 'test',
    roles: ['admin', 'dev']
  }
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.userInfo.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.userInfo.introduction = introduction
  },
  SET_USER_ID: (state, id) => {
    state.userInfo.userId = id
  },
  SET_USER_NAME: (state, name) => {
    state.userInfo.userName = name
  },
  SET_AVATAR: (state, avatar) => {
    state.userInfo.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.userInfo.roles = roles
  },
  APPEND_ROLE: (state, role) => {
    state.userInfo.roles.push(role)
  }
}

const actions = {
  // user login
  login({ commit }, info) {
    commit('SET_TOKEN', info.token)
    commit('SET_USER_NAME', info.userId)
  },

  // user logout
  logout({ commit, dispatch }) {
    commit('SET_TOKEN', '')
    commit('SET_ROLES', [])
    resetRouter()

    dispatch('tabsView/delAllViews', null, { root: true })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise((resolve) => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      resolve()
    })
  },

  setRoles({ commit }, roles) {
    commit('SET_ROLES', roles)
  },
  appendRole({ commit }, role) {
    commit('APPEND_ROLE', role)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
