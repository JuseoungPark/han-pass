import { mapGetters } from 'vuex'
import { StringUtils } from '@/utils/StringUtils'
export default {
  computed: {
    ...mapGetters(['permission_routes'])
  },
  methods: {
    goLink(url) {
      this.$router.push(url)
    },
    goLinkByName(name, parameters) {
      let parent = undefined
      let child = undefined
      let params = null

      parent = this.permission_routes.find((e) =>
        e.name === name
          ? true
          : e.children !== undefined
          ? e.children.find((ce) => ce.name === name)
          : false
      )
      if (parent === undefined) return

      child = parent.children.find((e) => e.name === name)
      if (child === undefined) return

      if (parameters && !StringUtils.isEmptyObject(parameters)) {
        params = parameters
      }
      if (params) {
        console.log(name, params)
        this.$router.push({ name: name, params: params })
      } else {
        console.log(
          parent.path.concat(parent.path === '/' ? '' : '/', child.path)
        )
        this.$router.push(
          parent.path.concat(parent.path === '/' ? '' : '/', child.path)
        )
      }
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
