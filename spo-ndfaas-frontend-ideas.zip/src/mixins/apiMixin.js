import '@/utils/StringUtils'
import { mapGetters } from 'vuex'
export default {
  props: {
    api: {
      type: String,
      default: ''
    },
    usePagination: {
      type: Boolean,
      default: false
    },
    apiType: {
      type: String,
      default: 'analysis'
    }
  },
  data() {
    return {
      loading: null,
      gridApi: null,
      apiUrl: '',
      apiParams: '',
      order: '',
      pagination: {
        total: 0,
        start: 0,
        end: 0,
        page: 1,
        totalPage: 0,
        prevPage: 0,
        nextPage: 0,
        limit: 20,
        visiblePage: 11
      }
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    uri: function() {
      var uri = ''

      if (this.usePagination) {
        let queryStr = '{0}?page={1}&limit={2}{3}{4}'

        if (this.apiType === 'analysis')
          queryStr = '{0}?incdntId={1}&requestPage={2}&rowCntByPage={3}{4}{5}'
        else if (this.apiType === 'incident') queryStr = '{0}/{2}/{3}?{4}{5}'

        uri = queryStr.format(
          this.apiUrl,
          this.incidentInfo.id,
          this.pagination.page,
          this.pagination.limit,
          encodeURI(this.fullFilter).replace('#', '%23'),
          encodeURI(this.fullOrder)
        )
      } else if (this.apiParams !== '') {
        uri = '{0}?incdntId={1}&{2}'.format(
          this.apiUrl,
          this.incidentInfo.id,
          encodeURI(this.fullFilter).replace('#', '%23')
        )
      } else {
        uri = this.apiUrl
      }
      console.log(uri)
      return uri
    },
    fullFilter() {
      if (this.usePagination && this.apiParams !== '')
        return '&' + this.apiParams.replace(/^&/, '')
      return this.apiParams
    },
    fullOrder() {
      return this.order !== '' ? '&' + this.order : ''
    }
  },
  created() {
    this.apiUrl = this.api
  },
  methods: {
    setApi(api) {
      this.apiUrl = api
    },
    setFilter(params) {
      this.apiParams = params
    },
    setOrder(order) {
      this.order = order
    },
    apiCodeValidate(res, errorMessage = undefined) {
      if (this.loading) this.loading.hide()
      if (this.apiType === 'analysis') {
        if (res.data.code === '200') {
          return res
        } else {
          this.$toast.error(
            '{0}{1}{2}'.format(
              errorMessage ? errorMessage + '\n' : '',
              res.data.msg,
              res.data.code
            )
          )
          return false
        }
      } else if (this.apiType === 'incident') {
        if (res.status === 200) {
          return res
        } else {
          this.$toast.error(
            '{0}{1}{2}'.format(
              errorMessage ? errorMessage + '\n' : '',
              res.statusText,
              res.status
            )
          )
          return false
        }
      } else {
        return res
      }
    },
    requestApiAsync(callback) {
      this.$api[this.apiType]
        .get(this.uri)
        .then((res) => {
          let result = this.apiCodeValidate(res)
          if (result) this.setPagination(result)
          callback(result)
        })
        .catch(function(error) {
          console.log(error)
          callback({ error: error })
        })
    },
    async requestApiSync() {
      return await this.$api[this.apiType]
        .get(this.uri)
        .then((res) => {
          let result = this.apiCodeValidate(res)
          if (result) this.setPagination(result)
          return result
        })
        .catch(function(error) {
          console.log(error)
          return { error: error }
        })
    },
    setPagination(res) {
      if (this.usePagination) {
        if (this.apiType === 'analysis') {
          if (res.data.result.pageInfo) {
            var pageInfo = res.data.result.pageInfo
            this.pagination.page = pageInfo.requestPage
            this.pagination.total = pageInfo.rowAllCnt
            this.pagination.totalPage = Math.ceil(
              this.pagination.total / this.pagination.limit
            )
            this.pagination.start =
              (this.pagination.page - 1) * this.pagination.limit + 1
            this.pagination.end =
              this.pagination.page * this.pagination.limit >
              this.pagination.total
                ? this.pagination.total
                : this.pagination.page * this.pagination.limit
          }
        } else if (this.apiType === 'incident') {
          if (
            Array.isArray(res.data) &&
            res.data.length > 0 &&
            res.data[0].totCnt
          ) {
            this.pagination.total = res.data[0].totCnt
            this.pagination.totalPage = Math.ceil(
              this.pagination.total / this.pagination.limit
            )
            this.pagination.start =
              (this.pagination.page - 1) * this.pagination.limit + 1
            this.pagination.end =
              this.pagination.page * this.pagination.limit >
              this.pagination.total
                ? this.pagination.total
                : this.pagination.page * this.pagination.limit
          }
        } else {
          this.pagination.total = res.data.total
          this.pagination.start = (res.data.page - 1) * res.data.limit + 1
          this.pagination.end =
            res.data.page * res.data.limit > res.data.total
              ? res.data.total
              : res.data.page * res.data.limit
          this.pagination.page = res.data.page
          this.pagination.totalPage = Math.ceil(res.data.total / res.data.limit)
          this.pagination.prevPage = res.data.prevPage
          this.pagination.nextPage = res.data.nextPage
          this.pagination.limit = res.data.limit
        }
      }
    },
    resetPagination() {
      this.pagination.page = 1
    },
    resetFilter() {
      this.apiParams = ''
    },
    resetOrder() {
      this.order = ''
    }
  }
}
