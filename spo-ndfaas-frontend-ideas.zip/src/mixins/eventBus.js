export default {
  name: 'eventBus',
  methods: {
    eventBusInit() {}
  },
  beforeMount() {
    this.$eventBus.$on('refresh', async () => {
      if (this.$refs.grid) {
        await this.$refs.grid.loadDataSync()
        this.$refs.grid.loadPreviousPageIfEmptyData()
      }
    })
    this.$eventBus.$on('eventBusInit', async (eventBusName) => {
      await this.eventBusInit(eventBusName)
    })
  }
}
