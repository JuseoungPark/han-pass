export default {
  data() {
    return {
      isDetailSearch: false,
      params: {},
      filter: {},
      initFilter: {},
      validError: {}
    }
  },
  computed: {
    isDetailSearchIcon() {
      return this.isDetailSearch
        ? 'mdi-arrow-collapse-up'
        : 'mdi-arrow-collapse-down'
    },
    isDetailSearchTitle() {
      return this.isDetailSearch ? '검색조건 접기' : '검색조건 펼치기'
    }
  },
  methods: {
    validate() {
      Object.keys(this.validError).forEach((key) => {
        console.log(key, this.filter[key], typeof this.filter[key])
      })
    },
    objQueryString(obj) {
      let obj_ = Object.keys(obj)
      let queryString = obj_
        .filter((key) => {
          if (typeof obj[key] === 'object') {
            return obj[key].length > 0
          } else {
            return obj[key] !== ''
          }
        })
        .map((key) => {
          if (key === 'dateList') {
            let dateList = []
            for (let i = 0; i < obj[key].length; i += 2)
              dateList.push(obj[key][i] + '/' + obj[key][i + 1])
            return key + '=' + dateList
          } else return key + '=' + obj[key]
        })
        .join('&')
      // console.log('objQueryString', queryString)
      return queryString
    },
    getColumns() {
      if (this.$refs.grid) {
        this.$refs.grid.setColumns(this.gridInfo.columns)
      }
    },
    _setFilter(filter) {
      let queryString = this.objQueryString(filter)
      this.$refs.grid.setFilter(queryString)
    },
    updateFilter() {
      this.validate()
      this.getColumns()
      let queryString = ''
      if (this.getParams && Object.keys(this.getParams).length > 0) {
        queryString = this.objQueryString(this.getParams)
      } else {
        queryString = this.objQueryString(this.filter)
      }
      this.$refs.grid.setFilter(queryString)
    },
    loadData() {
      this.updateFilter()
      this.$refs.grid.loadData()
    },
    readyAfterloadData() {
      this.$nextTick(() => {
        this.$watch(
          () => {
            return this.$refs.grid.gridApi
          },
          (val) => {
            // console.log('this.$refs.grid.gridApi:', val)
            if (val) {
              this.loadData()
            }
          }
        )
      })
    },
    resetFilterEach(keys) {
      keys.forEach((item) => {
        this.filter[item] = this.initFilter[item]
      })
      this.$refs.grid.reset()
    },
    resetFilter() {
      this.filter = { ...this.initFilter }
      this.$refs.grid.reset()
      // this.onSearch()
    },
    setInitFilter() {
      this.initFilter = { ...this.filter }
    },
    getWeekOfDayKr(d) {
      let date = d
      if (d) {
        if (d.indexOf('Mon') >= 0) {
          date = d.replace('Mon', '월')
        } else if (d.indexOf('Tue') >= 0) {
          date = d.replace('Tue', '화')
        } else if (d.indexOf('Wed') >= 0) {
          date = d.replace('Wed', '수')
        } else if (d.indexOf('Thu') >= 0) {
          date = d.replace('Thu', '목')
        } else if (d.indexOf('Fri') >= 0) {
          date = d.replace('Fri', '금')
        } else if (d.indexOf('Sat') >= 0) {
          date = d.replace('Sat', '토')
        } else if (d.indexOf('Sun') >= 0) {
          date = d.replace('Sun', '일')
        }
      }
      return date
    }
  },
  created() {
    this.setInitFilter()
  }
}
