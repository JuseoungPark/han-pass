import { mapGetters } from 'vuex'

export default {
  name: 'GridCommBtn',
  data() {
    return {
      except: 'Y',
      setbookmark: false,
      gridSelected: []
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    getExceptTit() {
      return this.except === 'Y' ? '제외' : '복원'
    },
    getBookmarkTit() {
      return this.setbookmark ? '북마크해제' : '북마크'
    },
    ...mapGetters(['incidentInfo'])
  },
  methods: {
    async setBookmarkCell(params) {
      console.log(params.data)
      this.gridSelected = [params.data]
      if (params.value) {
        let result = await this.deleteBootmark()
        if (result) {
          await this.$eventBus.$emit('refresh')
          await this.$toast(`북마크가 해제 되었습니다.`)
        }
      } else {
        let result = await this.setBootmark()
        if (result) {
          await this.$eventBus.$emit('refresh')
          await this.$toast(
            `북마크 되었습니다.\n자세한 내역은 통화내역 북마크에서 확인할 수 있습니다`
          )
        }
      }
    },
    async goBookmark(flag) {
      this.gridSelected = this.$refs.grid.getSelectedRows().filter((item) => {
        if (flag) {
          return item.bkmkId === 0
        } else {
          return item.bkmkId !== 0
        }
      })
      if (this.gridSelected.length > 0) {
        if (flag) {
          let result = await this.setBootmark()
          if (result) {
            await this.$eventBus.$emit('refresh')
            await this.$toast(
              `총 ${this.gridSelected.length}개의 목록이 북마크 되었습니다.\n자세한 내역은 통화내역 북마크에서 확인할 수 있습니다`
            )
          }
        } else {
          let result = await this.deleteBootmark()
          if (result) {
            await this.$eventBus.$emit('refresh')
            await this.$toast(
              `총 ${this.gridSelected.length}개의 통화내역이 북마크에서 해제되었습니다.`
            )
          }
        }
      } else {
        if (flag) {
          this.$toast.error('북마크에 등록할 내역을 먼저 선택해주세요')
        } else {
          this.$toast.error('북마크에서 해제할 내역을 먼저 선택해주세요')
        }
      }
    },
    async goExcept() {
      let existBookmarkedRows = this.$refs.grid
        .getSelectedRows()
        .some((item) => item.bkmkId > 0)

      this.gridSelected = this.$refs.grid.getSelectedRows().map((item) => {
        return this.except === 'Y' ? item.linkId : item.linkExclId
      })

      if (existBookmarkedRows) {
        this.$toast.error(`북마크가 되어 있는 경우는 제외가 불가능합니다.`)
      } else if (this.gridSelected.length > 0) {
        let result = await this.setExcept()
        if (result) {
          await this.$eventBus.$emit('refresh')
          if (this.$refs.outgoingNumber)
            await this.$refs.outgoingNumber.loadData()
          if (this.except === 'Y') {
            await this.$toast(
              `총 ${this.gridSelected.length}개의 목록이 제외 되었습니다.\n제외 내역 메뉴에서 다시 검토할 수 있습니다.`
            )
          } else {
            await this.$toast(
              `${this.gridSelected.length}개의 내역이 제외에서 복원되었습니다.`
            )
          }
        } else {
          if (this.except === 'Y') {
            this.$toast.error(`제외에 실패하였습니다. ${result.msg}`)
          } else {
            this.$toast.error(`복원에 실패하였습니다. ${result.msg}`)
          }
        }
      } else {
        if (this.except === 'Y') {
          this.$toast.error('목록에서 제외할 내역을 먼저 선택해주세요')
        } else {
          this.$toast.error('목록에서 복원할 내역을 먼저 선택해주세요')
        }
      }
    },
    async setBootmark() {
      let req = {
        url: `/bookmark/bookmark`,
        params: this.gridSelected.map((item) => {
          return {
            bkmkOriginSeCode: 'TALK',
            incdntId: this.incidentInfo.id,
            targetId: `${item.linkId}`
          }
        }),
        method: 'post'
      }
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async deleteBootmark() {
      let req = {
        method: 'delete',
        url: `/bookmark/bookmark`,
        params: this.gridSelected.map((item) => {
          return {
            incdntId: this.incidentInfo.id,
            bkmkId: item.bkmkId
          }
        })
      }
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async setExcept() {
      let path = '/talk/excl-dtls'
      let method = this.except === 'Y' ? 'POST' : 'PUT'
      let key = this.except === 'Y' ? 'linkId' : 'linkExclId'
      let i
      let data = []
      let item = {}

      for (i = 0; i < this.gridSelected.length; i++) {
        if (this.gridSelected[i]) {
          item = {}
          item.incdntId = this.incidentInfo.id
          item[key] = this.gridSelected[i]
          data.push(item)
        }
      }

      let res = await this.$api.analysis({
        url: path,
        method: method,
        data: data
      })
      res = this.apiCodeValidate(res)
      return res
    },
    apiCodeValidate(res) {
      if (this.loading) this.loading.hide()
      if (this.apiType === 'analysis') {
        if (res.data.code === '200') {
          return res
        } else {
          this.$toast.error(`${res.data.msg}(${res.data.code})`)
          return false
        }
      } else if (this.apiType === 'incident') {
        if (res.status === 200) {
          return res
        } else {
          this.$toast.error(`${res.statusText}(${res.status})`)
          return false
        }
      } else {
        return res
      }
    }
  }
}
