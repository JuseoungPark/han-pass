<template>
  <!-- widget button -->
  <v-speed-dial
    v-model="dialBtn"
    fixed
    bottom
    right
    direction="left"
    transition="slide-x-reverse-transition"
    v-if="speedDial.show"
  >
    <template v-slot:activator>
      <v-btn
        v-model="dialBtn"
        color="pink"
        dark
        fab
        small
        class="dea-btn--textindent"
      >
        <v-icon v-if="dialBtn">mdi-close</v-icon>
        <v-icon v-else>mdi-plus</v-icon>
        {{ dialBtn ? '퀵메뉴 접기' : '퀵메뉴 펼치기' }}
      </v-btn>
    </template>
    <v-btn fab dark small class="dea-btn--textindent" color="green">
      <v-icon>mdi-pencil</v-icon>
      메모
    </v-btn>
    <v-btn fab dark small class="dea-btn--textindent" color="indigo">
      <v-icon>mdi-plus</v-icon>
      추가
    </v-btn>
    <v-btn fab dark small class="dea-btn--textindent" color="red">
      <v-icon>mdi-delete</v-icon>
      삭제
    </v-btn>
  </v-speed-dial>
  <!-- //widget button -->
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'DeaSpeedDial',
  data() {
    return {
      dialBtn: false
    }
  },
  computed: {
    ...mapGetters(['speedDial'])
  }
}
</script>
