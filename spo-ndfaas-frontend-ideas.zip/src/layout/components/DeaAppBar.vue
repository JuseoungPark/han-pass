<template>
  <v-app-bar app dense height="114px" class="dea-app-bar" v-model="appbar.show">
    <v-sheet class="d-flex top-menu">
      <v-app-bar-nav-icon
        icon
        class="dea-btn--textindent"
        @click="toggleSideBar"
      >
        <v-icon>mdi-menu</v-icon>
        {{ sidebar.opened ? '메뉴접기' : '메뉴펼치기' }}
      </v-app-bar-nav-icon>
      <!-- <v-toolbar-title>{{ $t('title') }}</v-toolbar-title> -->
      <v-layout class="case-select">
        <div class="text">
          <v-icon>mdi-rhombus-medium</v-icon>
          <label>사건번호</label>
        </div>
        <div class="text">
          {{ incidentInfo.number }} / {{ incidentInfo.manager }}
        </div>
        <dea-button outlined rounded small @click="goCaseSelect"
          >사건목록</dea-button
        >
      </v-layout>
      <v-spacer></v-spacer>
      <!-- <v-btn text>사건목록</v-btn>
      <v-divider vertical />
      <v-btn text>즐겨찾기</v-btn>
      <v-divider vertical /> -->
      <v-btn text link :href="manualDownloadLink">매뉴얼 다운로드</v-btn>

      <v-avatar color="grey lighten-2" size="40px" class="valign-top">
        <img
          src="/img/avatar.png"
          style="width:100%; height:auto;"
          alt="홍길동 프로필 이미지"
        />
      </v-avatar>
      <v-menu
        :disabled="disabled"
        :absolute="absolute"
        :open-on-hover="openOnHover"
        :close-on-click="closeOnClick"
        :close-on-content-click="closeOnContentClick"
        :offset-x="offsetX"
        :offset-y="offsetY"
      >
        <template v-slot:activator="{ on }">
          <v-btn v-on="on" icon small class="dea-btn--textindent">
            <v-icon>mdi-chevron-down</v-icon>
            개인화메뉴
          </v-btn>
        </template>
        <!-- 추출파일 목록 : Layer Popup -->
        <v-sheet class="dea-popup" style="width:180px;">
          <v-container class="pa-0">
            <section class="dea-section">
              <div class="inner">
                <v-list dense>
                  <v-list-item>
                    <v-list-item-content>
                      <v-list-item-title>
                        <dea-button width="100%" @click="toggleTheme"
                          >테마변경</dea-button
                        >
                      </v-list-item-title>
                    </v-list-item-content>
                  </v-list-item>
                </v-list>
              </div>
            </section>
          </v-container>
        </v-sheet>
        <!-- //추출파일 목록 : Layer Popup -->
      </v-menu>
      <!-- <v-btn icon>
        <v-icon dense>mdi-apps</v-icon>
      </v-btn>
      <v-btn icon @click="dialog = !dialog">
        <v-badge color="pink" dot overlap>
          <v-icon dense>mdi-bell</v-icon>
        </v-badge>
      </v-btn>
      <v-btn icon @click="toggleTheme">
        <v-avatar size="24px" item>
          <v-img
            src="https://cdn.vuetifyjs.com/images/logos/logo.svg"
            alt="Vuetify"
          ></v-img>
        </v-avatar>
      </v-btn> -->
    </v-sheet>

    <dea-tabs-view />

    <!-- dialog -->
    <dea-dialog v-model="dialog" title="Create contact" width="800px">
      <v-row class="mx-2">
        <v-col class="align-center justify-space-between" cols="12">
          <v-row align="center" class="mr-0">
            <v-avatar size="40px" class="mx-3">
              <img
                src="//ssl.gstatic.com/s2/oz/images/sge/grey_silhouette.png"
                alt=""
              />
            </v-avatar>
            <v-text-field placeholder="Name"></v-text-field>
          </v-row>
        </v-col>
        <v-col cols="6">
          <v-text-field
            prepend-icon="mdi-account-card-details-outline"
            placeholder="Company"
          ></v-text-field>
        </v-col>
        <v-col cols="6">
          <v-text-field placeholder="Job title"></v-text-field>
        </v-col>
        <v-col cols="12">
          <v-text-field
            prepend-icon="mdi-mail"
            placeholder="Email"
          ></v-text-field>
        </v-col>
        <v-col cols="12">
          <v-text-field
            type="tel"
            prepend-icon="mdi-phone"
            placeholder="(000) 000 - 0000"
          ></v-text-field>
        </v-col>
        <v-col cols="12">
          <v-text-field
            prepend-icon="mdi-text"
            placeholder="Notes"
          ></v-text-field>
        </v-col>
      </v-row>
      <template #actions>
        <v-btn text color="primary">More</v-btn>
        <v-spacer></v-spacer>
        <v-btn text color="primary" @click="dialog = false">Cancel</v-btn>
        <v-btn text @click="dialog = false">Save</v-btn>
      </template>
    </dea-dialog>
    <!-- //dialog -->
    <!-- 사건목록 -->
    <dialog-case-select v-model="caseSelectShow"></dialog-case-select>
    <!-- 사건목록 // -->
  </v-app-bar>
</template>

<script>
import { mapGetters } from 'vuex'
import DeaTabsView from './DeaTabsView'
import DialogCaseSelect from './DialogCaseSelect'

export default {
  name: 'DeaAppBar',
  components: {
    DeaTabsView,
    DialogCaseSelect
  },
  data() {
    return {
      caseSelectShow: false,
      dialog: false,

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true
    }
  },
  computed: {
    ...mapGetters(['appbar', 'sidebar', 'incidentInfo']),
    manualDownloadLink() {
      return process.env.VUE_APP_PRIVATE_API + 'api/manual'
    }
  },
  mounted() {
    if (this.incidentInfo.id === '') {
      this.$store.dispatch('tabsView/delAllViews')
      if (this.$route.name !== 'EvidenceAnalysisHome') {
        this.$router.push('/home')
      }
      this.caseSelectShow = true
    }
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    toggleTheme() {
      this.$vuetify.theme.dark = !this.$vuetify.theme.dark
      this.$setThemeClass(this.$vuetify.theme.dark)
    },
    goCaseSelect() {
      this.caseSelectShow = true
    }
  }
}
</script>
