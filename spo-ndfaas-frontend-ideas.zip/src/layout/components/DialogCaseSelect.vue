<template>
  <!-- 사건선택 : Layer Popup -->
  <dea-dialog v-model="isShow" title="사건선택" width="1000px">
    <section class="dea-section">
      <div class="search-box">
        <dea-card class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간조건</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
                v-model="filter.date"
              ></dea-date-picker>
            </v-col>
            <v-col cols="1">
              <dea-label>수사현황</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                v-for="(item, index) in statusList"
                v-model="filter.status"
                :label="item.label"
                :cvalue="item.value"
                :key="index"
              ></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>사건검색</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                label="사건조회조건"
                style="width:200px;"
                class="flex-0"
                :items="selectItems"
                v-model="filter.condition"
              ></dea-select>
              <dea-text-field
                v-model="filter.schTxt"
                placeholder="검색어를 입력하세요"
              ></dea-text-field>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  prepend-icon="mdi-magnify"
                  color="primary"
                  @click="onSearch"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  prepend-icon="mdi-restore"
                  @click="resetFilter"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <dea-grid
            ref="grid"
            apiType="incident"
            disable-auto-load
            use-pagination
            async
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
            :etc-options="gridInfo.options"
            :return-value.sync="gridInfo.totalCount"
            @ready="onReady"
          >
            <template #header-left>
              <v-col class="d-flex">
                <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="doCancel">취소</dea-button>
        <dea-button color="primary" @click="doOK">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
  <!-- //사건선택 : Layer Popup -->
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import CellButton from '@/components/grid/CellButton'
import CellIcon from '@/components/grid/CellIcon'
export default {
  name: 'DialogCaseSelect',
  mixins: [listTemplate],
  props: {
    value: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isShow: false,
      filter: {
        date: ['2020-10-01', '2020-11-30'],
        status: ['all'],
        condition: '',
        schTxt: ''
      },
      tabSelected: 0,
      tabName: '사건목록',
      statusList: [
        { label: '전체', value: 'all' },
        { label: '진행', value: 'ing' },
        { label: '종료', value: 'complete' }
      ],
      selectItems: [
        { text: '사건번호', value: 'code' },
        { text: '사건명', value: 'title' },
        { text: '담당자', value: 'user' }
      ],
      gridInfo: {
        api: '/incdnts',
        config: {
          excelButton: true,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        options: {
          overlayNoRowsTemplate:
            '<span class="ag-overlay-loading-center">등록하신 사건이 없습니다. 사건을 등록하세요</span>',
          getRowClass: (params) => {
            if (params.data.status === 3) {
              return 'status-finish'
            }
          }
        },
        columns: [
          {
            headerName: '사건번호',
            field: 'incdntNo',
            sortable: true,
            unSortIcon: true,
            width: 100
          },
          {
            headerName: '사건명',
            field: 'incdntNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '담당자',
            field: 'mngrUserNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '서비스기간',
            field: 'period',
            sortable: true,
            unSortIcon: true,
            width: 250,
            cellRendererFramework: CellButton,
            cellRendererParams: (params) => {
              // console.log(params)
              return {
                type: 'txtbtn',
                label: '기간연장',
                showBtn: params.data.status !== 3,
                textStr:
                  params.data.terminate === 'Y'
                    ? [
                        {
                          value: '서비스기간이 곧 종료됩니다 (종료일 {0})'.format(
                            params.data.vldEndDt
                          ),
                          color: 'red'
                        }
                      ]
                    : '',
                click: (params) => {
                  this.$confirm('기간연장을 하시겠습니까?').then((confirm) => {
                    if (confirm) {
                      this.extensionDate(params)
                    }
                  })
                }
              }
            },
            valueGetter: function(params) {
              if (params.data.status === 3) {
                return '종료된 사건입니다.'
              } else {
                return '{0} ~ {1} (잔여기간 {2}일)'.format(
                  params.data.vldBgngDt,
                  params.data.vldEndDt,
                  moment(params.data.vldEndDt, 'YYYY-MM-DD').diff(
                    moment(),
                    'days'
                  )
                )
              }
            }
          },
          {
            headerName: '병합여부', // merge
            field: 'merge',
            sortable: true,
            unSortIcon: true,
            width: 80,
            cellRendererFramework: CellIcon,
            cellRendererParams: (params) => {
              return {
                icon: params.value === 'Y' ? 'mdi-table-merge-cells' : ''
              }
            }
          }
        ],
        totalCount: 0
      },
      gridSelected: {}
    }
  },
  methods: {
    onReady() {
      this.$refs.grid.hideOverlay()
    },
    onSearch() {
      console.log('onSearch')
    },
    doOK() {
      let selectedRow = this.$refs.grid.getSelectedRows()
      if (selectedRow.length > 0) {
        this.gridSelected = selectedRow[0]
        this.$store.dispatch('incident/setIncidentInfo', {
          id: this.gridSelected.incdntId,
          number: this.gridSelected.incdntNo,
          manager: this.gridSelected.mngrUserNm
        })
        // this.$store.dispatch('user/login', this.gridSelected.user)
        this.doCancel()

        this.$store.dispatch('tabsView/delAllViews')
        if (this.$route.name !== 'EvidenceAnalysisHome') {
          this.$router.push('/home')
        }
        this.$eventBus.$emit('update:evidence-home')
      } else {
        this.$toast.error('사건을 선택하세요.')
      }
    },
    doCancel() {
      if (this.incidentInfo.id === '') this.$toast.error('사건을 선택하세요.')
      else this.isShow = false
    },
    extensionDate(params) {
      this.$api.incident
        .post('/incdnt/{0}/pd-extnd/'.format(params.data.incdntId))
        .then((res) => {
          console.log(res)
          if (res.status === 200 && res.data === 2) {
            this.$toast('서비스 기간이 연장되었습니다.')
            this.loadData()
          } else {
            this.$toast.error('서비스 기간 연장이 실패하였습니다.')
          }
        })
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo.totalCount
          )})`
        }
      ]
    }
  },
  watch: {
    value(flag) {
      this.isShow = flag
    },
    isShow(flag) {
      if (flag) {
        this.$nextTick(() => {
          this.loadData()
        })
      }
      this.$emit('input', flag)
    }
  },
  created() {
    this.isShow = this.value
  }
}
</script>
<style>
.ag-theme-alpine .ag-row.status-finish {
  opacity: 0.5;
}
</style>
