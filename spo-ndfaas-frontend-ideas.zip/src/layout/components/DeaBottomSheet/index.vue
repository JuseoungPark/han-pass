<template>
  <div class="bottom-sidebar">
    <v-btn
      fab
      x-small
      bottom
      dark
      fixed
      color="primary"
      class="btn-bottom-sheet dea-btn--textindent"
      v-show="bottomSheet.show"
      @click="toggleBottomSheet"
    >
      <v-icon>mdi-plus</v-icon>
      아래쪽 사이드바 열기
    </v-btn>
    <v-bottom-sheet v-model="bottomSheet.opened">
      <v-sheet class="text-center" height="200px">
        <section class="dea-section">
          <div class="inner">
            <dea-card>
              <template slot="title">
                다운로드 현황
                <v-layout class="v-toolbar">
                  <v-row no-gutters>
                    <v-col class="d-flex align-right valign-middle">
                      <dea-button small>목록지우기</dea-button>
                      <dea-button small>파일저장관리</dea-button>
                    </v-col>
                  </v-row>
                </v-layout>
              </template>
              <v-list dense>
                <v-list-item-group
                  v-model="downloadList"
                  class="d-flex flex-wrap"
                >
                  <v-list-item
                    v-for="(downloadItem, i) in downloadItems"
                    :key="i"
                    class="flex-0"
                    style="width:380px;"
                  >
                    <v-list-item-content class="flex-row">
                      <v-list-item-subtitle :class="downloadItem.state">
                        {{ downloadItem.status }}
                      </v-list-item-subtitle>
                      <v-list-item-title>
                        {{ downloadItem.file }}
                      </v-list-item-title>
                    </v-list-item-content>
                    <v-list-item-action>
                      <dea-button icon textindent prepend-icon="mdi-close"
                        >삭제</dea-button
                      >
                    </v-list-item-action>
                  </v-list-item>
                </v-list-item-group>
              </v-list>
            </dea-card>
          </div>
        </section>
      </v-sheet>
    </v-bottom-sheet>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'DeaBottomSheet',
  data() {
    return {
      downloadList: '',
      downloadItems: [
        {
          state: 'complete',
          status: '완료',
          file: '사건번호_통화통합내역_20201105.xls'
        },
        {
          state: 'complete',
          status: '완료',
          file: '사건번호_통화통합내역_20201105.xls'
        },
        {
          state: 'fail',
          status: '실패',
          file: '사건번호_통화통합내역_20201105.xls'
        },
        {
          state: 'complete',
          status: '완료',
          file: '사건번호_통화통합내역_20201105.xls'
        },
        {
          state: 'complete',
          status: '완료',
          file: '사건번호_통화통합내역_20201105.xls'
        },
        {
          state: 'fail',
          status: '실패',
          file: '사건번호_통화통합내역_20201105.xls'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['bottomSheet'])
  },
  methods: {
    toggleBottomSheet() {
      this.$store.dispatch('app/toggleBottomSheet')
    }
  }
}
</script>
