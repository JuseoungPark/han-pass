<template>
  <div class="right-sidebar">
    <!-- aside -->
    <v-btn
      fab
      x-small
      right
      dark
      fixed
      color="primary"
      class="btn-right-sheet dea-btn--textindent"
      v-show="rightBar.show"
      @click="toggleRightBar"
    >
      <v-icon>mdi-plus</v-icon>
      오른쪽 사이드바 열기
    </v-btn>

    <v-navigation-drawer
      v-model="rightBar.opened"
      fixed
      right
      temporary
      width="400"
    >
      <section class="dea-section dea-section-detail">
        <div class="search-box">
          <dea-card>
            <template slot="title">
              2020교육10245
              <strong>선물거래금융투자상품2심사건</strong>
              <v-layout class="v-toolbar">
                <dea-button small>사건정보 상세</dea-button>
              </v-layout>
            </template>
            <div class="box-wrap">
              <v-row no-gutters>
                <v-col cols="1" class="valign-top">
                  <dea-label>분석기간:</dea-label>
                </v-col>
                <v-col class="d-flex flex-column">
                  <div class="text">20201001-20201231 (잔여: 20일)</div>
                  <dea-button small>분석기간 연장하기</dea-button>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>사건담당:</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">김수사, 나금감</div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>담당검사:</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">박검사</div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>소속기관:</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">금융감독원</div>
                </v-col>
              </v-row>
            </div>
          </dea-card>
        </div>
      </section>

      <v-divider></v-divider>

      <section class="dea-section dea-section-status">
        <div class="inner">
          <dea-card>
            <template slot="title">
              통합디지털증거분석 현황
              <v-layout class="v-toolbar align-right">
                <dea-button small>자세히 보기</dea-button>
              </v-layout>
            </template>
            <v-row no-gutters class="border-wrap">
              <v-col cols="1">
                <dea-label>통화내역</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">207</div>
              </v-col>
            </v-row>
            <v-row no-gutters class="border-wrap">
              <v-col cols="1">
                <dea-label>계좌내역</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">23</div>
              </v-col>
            </v-row>
            <v-row no-gutters class="border-wrap">
              <v-col cols="1">
                <dea-label>비정형파일</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">5,667</div>
              </v-col>
            </v-row>
            <v-row no-gutters class="border-wrap">
              <v-col cols="1">
                <dea-label>모바일</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">3</div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text">디지털증거처리현황 (총 33개)</div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text">통화내역 43건</div>
                <v-divider vertical class="ma-0" />
                <div class="text">계약내역 11건</div>
                <v-divider vertical class="ma-0" />
                <div class="text">파일 344건</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>

      <v-divider></v-divider>

      <section class="dea-section dea-section-report">
        <div class="inner">
          <dea-card>
            <template slot="title">분석보고서</template>
            <v-list dense>
              <template v-for="(analysisReportItem, i) in analysisReportItems">
                <v-list-item :key="analysisReportItem.title">
                  <v-list-item-content class="flex-column">
                    <v-layout class="flex-auto">
                      <v-list-item-title class="text-truncate-none">{{
                        analysisReportItem.title
                      }}</v-list-item-title>
                    </v-layout>
                    <v-layout class="flex-auto">
                      <v-list-item-subtitle class="text-truncate-none">{{
                        analysisReportItem.date
                      }}</v-list-item-subtitle>
                      <v-list-item-subtitle class="text-truncate-none ml-2">{{
                        analysisReportItem.name
                      }}</v-list-item-subtitle>
                    </v-layout>
                  </v-list-item-content>
                  <v-list-item-action class="flex-row">
                    <dea-button>수정</dea-button>
                    <dea-button>저장</dea-button>
                  </v-list-item-action>
                </v-list-item>
                <v-divider
                  v-if="i < analysisReportItems.length - 1"
                  :key="i"
                ></v-divider>
              </template>
            </v-list>
          </dea-card>
        </div>
      </section>
    </v-navigation-drawer>
    <!-- //aside -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// import DeaButton from '../../../components/common/DeaButton.vue'

export default {
  name: 'DeaRightBar',
  data() {
    return {
      drawerRight: null,
      items: null,

      // Modal Popup
      analysisReportList: [],
      analysisReportItems: [
        {
          title: '분석보고서 요약제목',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목2',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목3',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목4',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['rightBar'])
  },
  methods: {
    toggleRightBar() {
      this.$store.dispatch('app/toggleRightBar')
    }
  }
}
</script>
