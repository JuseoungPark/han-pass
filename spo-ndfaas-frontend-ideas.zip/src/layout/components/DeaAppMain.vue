<template>
  <v-main id="top">
    <section :class="classes">
      <v-container v-if="$route.meta.header !== false" class="page-header-wrap">
        <hgroup class="page-header">
          <v-icon v-if="$route.meta.backButton" class="mr-2" @click="goBack"
            >mdi-less-than</v-icon
          >
          <h1>{{ $route.meta.title }}</h1>
          <v-layout class="page-header-slot">
            <Component
              :is="slotContent.component"
              v-bind="{ child: slotContent.child }"
            />
          </v-layout>
          <v-breadcrumbs :items="breadItems">
            <template v-slot:divider>
              <v-icon>mdi-chevron-right</v-icon>
            </template>
          </v-breadcrumbs>
          <!-- <v-layout class="descript">페이지에 대한 설명글입니다.</v-layout> -->
          <v-layout class="v-toolbar">
            <v-menu
              :disabled="disabled"
              :absolute="absolute"
              :open-on-hover="openOnHover"
              :close-on-click="closeOnClick"
              :close-on-content-click="closeOnContentClick"
              :offset-x="offsetX"
              :offset-y="offsetY"
            >
              <template v-slot:activator="{ on: onPopup }">
                <v-btn
                  icon
                  color="primary"
                  class="dea-btn--textindent"
                  v-on="onPopup"
                  v-show="false"
                >
                  <v-icon>mdi-chart-areaspline</v-icon>
                  분석리포트 목록
                </v-btn>
                <v-tooltip bottom>
                  <template v-slot:activator="{ on: onTooltip }">
                    <v-btn
                      icon
                      color="primary"
                      class="dea-btn--textindent"
                      v-on="{ ...onPopup, ...onTooltip }"
                    >
                      <v-icon>mdi-chart-areaspline</v-icon>
                      분석리포트 목록
                    </v-btn>
                  </template>
                  <span>분석리포트 목록</span>
                </v-tooltip>
              </template>
              <!-- 분석리포트 목록 : Layer Popup -->
              <v-sheet class="dea-popup" style="width:480px;">
                <v-container class="pa-4">
                  <section class="dea-section">
                    <div class="inner">
                      <v-list dense>
                        <template
                          v-for="(analysisReportItem, i) in analysisReportItems"
                        >
                          <v-list-item :key="analysisReportItem.title">
                            <v-list-item-content class="flex-column">
                              <v-layout class="flex-auto">
                                <v-list-item-title class="text-truncate-none">{{
                                  analysisReportItem.title
                                }}</v-list-item-title>
                              </v-layout>
                              <v-layout class="flex-auto">
                                <v-list-item-subtitle
                                  class="text-truncate-none"
                                  >{{
                                    analysisReportItem.date
                                  }}</v-list-item-subtitle
                                >
                                <v-list-item-subtitle
                                  class="text-truncate-none ml-2"
                                  >{{
                                    analysisReportItem.name
                                  }}</v-list-item-subtitle
                                >
                              </v-layout>
                            </v-list-item-content>
                            <v-list-item-action class="flex-row">
                              <dea-button>수정</dea-button>
                              <dea-button>저장</dea-button>
                            </v-list-item-action>
                          </v-list-item>
                          <v-divider
                            v-if="i < analysisReportItems.length - 1"
                            :key="i"
                          ></v-divider>
                        </template>
                      </v-list>
                    </div>
                  </section>
                </v-container>
              </v-sheet>
              <!-- //분석리포트 목록 : Layer Popup -->
            </v-menu>
            <!-- <dea-button
              icon
              color="primary"
              prepend-icon="mdi-comment-question"
              textindent
              title="문의"
              bottom
              >문의</dea-button
            > -->
            <dea-button
              icon
              color="primary"
              prepend-icon="mdi-text-box-minus"
              textindent
              title="제외내역"
              bottom
              @click="goLink('/callHistory/callExclusionHistoryAnalysis')"
              >제외내역</dea-button
            >
            <dea-button
              icon
              color="primary"
              prepend-icon="mdi-text-box-plus"
              textindent
              title="북마크내역"
              bottom
              @click="goLink('/callHistory/callHistoryAnalysisBookmark')"
              >북마크내역
            </dea-button>
            <dea-button
              icon
              color="primary"
              prepend-icon="mdi-camera-plus"
              textindent
              title="화면캡쳐"
              bottom
              @click="takeScreenshot"
              >화면캡쳐
            </dea-button>
            <!-- <dea-button
              icon
              outlined
              prepend-icon="mdi-file-excel"
              title="엑셀다운로드"
              bottom
            >엑셀다운로드
            </dea-button> -->
          </v-layout>
        </hgroup>
      </v-container>
      <v-fade-transition mode="out-in">
        <keep-alive :include="cachedViews">
          <router-view
            :key="key"
            @slot-content:add="onAddSlotContent"
            @slot-content:delete="onDeleteSlotContent"
          />
        </keep-alive>
      </v-fade-transition>
    </section>
  </v-main>
</template>

<script>
import { mapGetters } from 'vuex'
import routeMixin from '@/mixins/route'
import html2canvas from 'html2canvas'
import moment from 'moment'

const SlotContent = {
  name: 'SlotContent',
  template: `<span></span>`
}

export default {
  name: 'AppMain',
  mixins: [routeMixin],
  data() {
    return {
      breadItems: [],
      slotContents: [],

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      analysisReportList: [],
      analysisReportItems: [
        {
          title: '분석보고서 요약제목',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목2',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목3',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        },
        {
          title: '분석보고서 요약제목4',
          date: '2020/10/01 14:30',
          name: '김OO 사무관'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['permission_routes', 'sidebar']),
    cachedViews() {
      return this.$store.state.tabsView.cachedViews
    },
    key() {
      return this.$route.path
    },
    slotContent() {
      var slot = this.slotContents.filter((e) => e.name === this.$route.name)
      if (slot.length > 0) {
        return slot[slot.length - 1]
      }
      return SlotContent
    },
    classes() {
      return {
        'app-main': true,
        'ml-14': this.$route.meta.leftSubMenu
      }
    }
  },
  watch: {
    $route() {
      this.updateBreadItems()
    }
  },
  methods: {
    updateBreadItems() {
      this.breadItems = Array.from(this.$route.matched, (item) => {
        return { text: item.meta.title, disabled: true, href: item.path }
      })
      // console.log(this.breadItems[this.breadItems.length - 1].text)
    },
    onAddSlotContent(slot) {
      this.onDeleteSlotContent(slot.name)
      this.slotContents.push(slot)
    },
    onDeleteSlotContent(name) {
      let deleteSlot = this.slotContents.filter((e) => e.name === name)
      deleteSlot.forEach((e) => {
        this.slotContents.splice(this.slotContents.indexOf(e), 1)
      })
    },
    takeScreenshot: function() {
      if (process.env.IS_ELECTRON) {
        let channel = 'screen-capture-' + moment().format('YYYYMMDD-HHmmss')
        window.ipcRenderer.send('screen-capture', channel)
        window.ipcRenderer.once(channel, (event, arg) => {
          if (arg === 'success') this.$toast('스크린샷이 저장되었습니다.')
          else this.$toast.error('스크린샷 저장이 실패하였습니다.')
        })
      } else {
        html2canvas(document.getElementById('top')).then((canvas) => {
          let fileURL = canvas.toDataURL()
          let fileLink = document.createElement('a')
          let fileName =
            'screenshot_' + moment().format('YYYYMMDD_HHmmss') + '.png'

          fileLink.href = fileURL
          fileLink.setAttribute('download', fileName)
          document.body.appendChild(fileLink)

          fileLink.click()

          this.$toast('스크린샷이 저장되었습니다.')
        })
      }
    }
  },
  updated() {
    document.title = this.$i18n.t('title').concat(': ', this.$route.meta.title)
  },
  mounted() {}
}
</script>
