<template>
  <v-sheet class="d-flex">
    <v-tabs show-arrows>
      <v-tabs-slider></v-tabs-slider>
      <v-tab
        v-for="tab in visitedViews"
        ref="tab"
        :key="tab.path"
        :to="{ path: tab.path, query: tab.query, fullPath: tab.fullPath }"
        tag="span"
        @click.middle.native="!isAffix(tab) ? closeSelectedTab(tab) : ''"
        @contextmenu.prevent.native="openMenu(tab, $event)"
      >
        {{ tab.title }}
        <v-btn
          icon
          small
          class="dea-btn--textindent"
          v-if="!isAffix(tab)"
          @click.prevent.stop="closeSelectedTab(tab)"
        >
          <v-icon>mdi-close</v-icon>
          탭닫기
        </v-btn>
      </v-tab>

      <v-menu
        v-model="visible"
        :position-x="left"
        :position-y="top"
        absolute
        offset-y
      >
        <v-list>
          <v-list-item
            v-if="!isAffix(selectedTab)"
            @click="closeSelectedTab(selectedTab)"
          >
            <v-list-item-title>{{ $t('text.closeTab') }}</v-list-item-title>
          </v-list-item>
          <v-list-item
            v-if="!isAffix(selectedTab) && visitedViews.length > 2"
            @click="closeOthersTabs"
          >
            <v-list-item-title>{{
              $t('text.closeOthersTab')
            }}</v-list-item-title>
          </v-list-item>
          <v-list-item @click="closeAllTabs(selectedTab)">
            <v-list-item-title>{{ $t('text.closeAllTab') }}</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-tabs>
  </v-sheet>
</template>

<script>
// import ScrollPane from './ScrollPane'
import path from 'path'
export default {
  name: 'DeaTabsView',
  // components: { ScrollPane },
  data() {
    return {
      visible: false,
      top: 0,
      left: 0,
      selectedTab: {},
      affixTabs: []
    }
  },
  computed: {
    visitedViews() {
      return this.$store.state.tabsView.visitedViews
    },
    routes() {
      return this.$store.state.permission.routes
    }
  },
  watch: {
    $route() {
      this.addTabs()
      // this.moveToCurrentTab()
    },
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  },
  mounted() {
    this.initTabs()
    this.addTabs()
  },
  methods: {
    isActive(route) {
      return route.path === this.$route.path
    },
    isAffix(tab) {
      return tab.meta && tab.meta.affix
    },
    filterAffixTabs(routes, basePath = '/') {
      let tabs = []
      routes.forEach((route) => {
        if (route.meta && route.meta.affix) {
          const tabPath = path.resolve(basePath, route.path)
          tabs.push({
            fullPath: tabPath,
            path: tabPath,
            name: route.name,
            meta: { ...route.meta }
          })
        }
        if (route.children) {
          const tempTabs = this.filterAffixTabs(route.children, route.path)
          if (tempTabs.length >= 1) {
            tabs = [...tabs, ...tempTabs]
          }
        }
      })
      return tabs
    },
    initTabs() {
      const affixTabs = (this.affixTabs = this.filterAffixTabs(this.routes))
      for (const tab of affixTabs) {
        // Must have tab name
        if (tab.name) {
          this.$store.dispatch('tabsView/addVisitedView', tab)
        }
      }
    },
    addTabs() {
      const { name, meta } = this.$route
      // NOTE 새탭은 추가하지 않는다.
      if (name && !meta.blank) {
        this.$store.dispatch('tabsView/addView', this.$route)
      }
      return false
    },
    moveToCurrentTab() {
      const tabs = this.$refs.tab
      this.$nextTick(() => {
        for (const tab of tabs) {
          if (tab.to.path === this.$route.path) {
            this.$refs.scrollPane.moveToTarget(tab)
            // when query is different then update
            if (tab.to.fullPath !== this.$route.fullPath) {
              this.$store.dispatch('tabsView/updateVisitedView', this.$route)
            }
            break
          }
        }
      })
    },
    closeSelectedTab(view) {
      this.$store
        .dispatch('tabsView/delView', view)
        .then(({ visitedViews }) => {
          if (this.isActive(view)) {
            this.toLastView(visitedViews, view)
          }
        })
    },
    closeOthersTabs() {
      this.$router.push(this.selectedTab)
      this.$store
        .dispatch('tabsView/delOthersViews', this.selectedTab)
        .then(() => {
          // this.moveToCurrentTab()
        })
    },
    closeAllTabs(view) {
      this.$store.dispatch('tabsView/delAllViews').then(({ visitedViews }) => {
        // if (this.affixTabs.some((tab) => tab.path === view.path)) {
        //   return
        // }
        this.toLastView(visitedViews, view)
      })
    },
    toLastView(visitedViews, view) {
      const latestView = visitedViews.slice(-1)[0]
      if (latestView) {
        this.$router.push(latestView.fullPath)
      } else {
        // now the default is to redirect to the home page if there is no tabs-view,
        // you can adjust it according to your needs.
        if (view.name === 'Dashboard') {
          // to reload home page
          this.$router.replace({ path: '/redirect' + view.fullPath })
        } else {
          this.$router.push('/')
        }
      }
    },
    openMenu(tab, e) {
      e.preventDefault()
      this.visible = false
      this.left = e.clientX
      this.top = e.clientY
      this.$nextTick(() => {
        this.visible = true
      })

      this.selectedTab = tab
    },
    closeMenu() {
      this.visible = false
    },
    handleScroll() {
      this.closeMenu()
    }
  }
}
</script>

<style lang="scss">
//reset element css of el-icon-close
.v-tabs {
  .v-tab {
    .mdi-close {
      width: 16px;
      height: 16px;
      vertical-align: 2px;
      border-radius: 50%;
      text-align: center;
      transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
      transform-origin: 100% 50%;
      &:before {
        transform: scale(0.8);
        display: inline-block;
        vertical-align: -1.5px;
      }
      &:hover {
        background-color: #b4bccc;
        color: #fff;
      }
    }
  }
}
</style>
