<template>
  <v-navigation-drawer
    :mini-variant="!sidebar.opened"
    width="226"
    mini-variant-width="64"
    class="side-bar"
    :expand-on-hover="!sidebar.opened"
    v-if="sidebar.show"
    app
    @transitionend="onChangeSidebar"
  >
    <v-list dense class="logo pa-0">
      <v-list-item>
        <v-list-item-icon class="mt-1 mb-1">
          <v-icon>mdi-fingerprint</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>N-DFaaS</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
    <v-list dense class="menu0 pa-0 pt-2">
      <v-list-item>
        <v-list-item-icon>
          <v-btn
            icon
            class="dea-btn--textindent"
            v-if="!expanded"
            @click="toggleShowMenus"
          >
            <v-icon>
              {{ toggleMenusIcon }}
            </v-icon>
            {{ isShowMenus ? '메뉴 접기' : '메뉴 펼치기' }}
          </v-btn>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>{{ $t('title') }}</v-list-item-title>
        </v-list-item-content>
        <v-list-item-icon>
          <v-btn
            v-if="expanded"
            @click="toggleShowMenus"
            icon
            small
            class="dea-btn--textindent"
          >
            <v-icon>
              {{ toggleMenusIcon }}
            </v-icon>
            {{ isShowMenus ? '메뉴 접기' : '메뉴 펼치기' }}
          </v-btn>
        </v-list-item-icon>
      </v-list-item>
    </v-list>
    <v-list dense class="lnb" v-show="isShowMenus">
      <dea-sidebar-item
        v-for="route in permission_routes"
        :key="route.path"
        :item="route"
        :base-path="route.path"
      />
    </v-list>

    <template v-slot:append>
      <v-divider></v-divider>
      <div class="d-flex px-4 py-2">
        <v-btn icon class="dea-btn--textindent">
          <v-icon>mdi-account</v-icon>
          개인정보
        </v-btn>
        <v-spacer></v-spacer>
        <v-btn icon class="dea-btn--textindent">
          <v-icon>mdi-bell</v-icon>
          알림
        </v-btn>
        <v-btn icon class="dea-btn--textindent">
          <v-icon>mdi-cog</v-icon>
          설정
        </v-btn>
      </div>
    </template>
  </v-navigation-drawer>
</template>

<script>
import { mapGetters } from 'vuex'
import DeaSidebarItem from './DeaSidebarItem'

export default {
  name: 'Sidebar',
  components: {
    DeaSidebarItem
  },
  data() {
    return {
      expanded: false,
      isShowMenus: true
    }
  },
  computed: {
    ...mapGetters(['permission_routes', 'sidebar']),
    toggleMenusIcon: function() {
      if (this.isShowMenus) return 'mdi-arrow-up-drop-circle'
      return 'mdi-arrow-down-drop-circle'
    }
  },
  methods: {
    onChangeSidebar(object) {
      if (object.target.className.includes('v-navigation-drawer--mini-variant'))
        this.expanded = false
      else this.expanded = true
    },
    toggleShowMenus() {
      this.isShowMenus = !this.isShowMenus
    }
  }
}
</script>
