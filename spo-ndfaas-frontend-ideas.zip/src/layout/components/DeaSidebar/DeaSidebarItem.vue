<template>
  <v-list-item
    v-if="!item.hidden && hasRole && item.meta.rootOnly"
    :to="resolveSubPath(item.path, item.children[0].path)"
  >
    <v-list-item-icon>
      <v-icon>{{ item.meta.icon }}</v-icon>
    </v-list-item-icon>
    <v-list-item-content>
      <v-list-item-title>{{ item.meta.title }}</v-list-item-title>
    </v-list-item-content>
    <v-list-item-icon>
      <v-btn
        v-if="item.meta.usePopup"
        @click.prevent.stop="
          openNewWindow(resolveSubPath(item.path, item.children[0].path))
        "
        title="새창열림"
        icon
        small
        class="dea-btn--textindent"
      >
        <v-icon>mdi-window-restore</v-icon>
        새창으로 열기
      </v-btn>
    </v-list-item-icon>
  </v-list-item>
  <v-list-group
    v-else-if="!item.hidden && hasRole"
    :class="groupClasses(item.path)"
    :key="item.meta.title"
    :prepend-icon="item.meta.icon"
    no-action
    @click="marker = !marker"
  >
    <template v-slot:activator>
      <v-list-item-content>
        <v-list-item-title v-text="item.meta.title"></v-list-item-title>
      </v-list-item-content>
    </template>
    <template v-slot:appendIcon>
      <v-btn icon small class="dea-btn--textindent"
        ><v-icon>{{ marker ? 'mdi-minus' : 'mdi-plus' }}</v-icon>
        {{ marker ? '서브메뉴 접기' : '서브메뉴 펼치기' }}
      </v-btn>
    </template>
    <v-list-item
      v-for="child in hasRoleSubMenus"
      :key="child.path"
      :to="resolvePath(child)"
    >
      <v-list-item-content>
        <v-list-item-title>{{ child.meta.title }}</v-list-item-title>
      </v-list-item-content>
      <v-list-item-icon>
        <v-btn
          v-if="child.children !== undefined"
          @click.prevent.stop="openMenu(child, $event)"
          icon
          small
          class="dea-btn--textindent"
        >
          <v-icon>mdi-arrow-collapse-down</v-icon>
          서브메뉴 리스트로 보기
        </v-btn>
        <v-btn
          v-if="child.meta.usePopup"
          @click.prevent.stop="openNewWindow(resolvePath(child))"
          title="새창열림"
          icon
          small
          class="dea-btn--textindent"
        >
          <v-icon>mdi-window-restore</v-icon>
          새창으로 열기
        </v-btn>
      </v-list-item-icon>
    </v-list-item>
    <v-menu
      v-model="visible"
      :position-x="left"
      :position-y="top"
      absolute
      offset-y
    >
      <v-list>
        <v-list-item
          v-for="subChild in child.children"
          :key="subChild.path"
          :to="resolveSubPath(child.path, subChild.path)"
        >
          <v-list-item-title>{{ subChild.meta.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-list-group>
</template>

<script>
import path from 'path'
import { mapGetters } from 'vuex'

export default {
  name: 'DeaSidebarItem',
  props: {
    item: {
      type: Object,
      required: true
    },
    basePath: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      visible: false,
      top: 0,
      left: 0,
      child: {},
      marker: false
    }
  },
  watch: {
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    hasRole: function() {
      return (
        !this.item.meta ||
        !this.item.meta.roles ||
        this.item.meta.roles.some((m) =>
          this.userInfo.roles.some((u) => u.includes(m))
        )
      )
    },
    hasRoleSubMenus: function() {
      return this.item.children.filter(
        (m) =>
          !m.meta ||
          !m.meta.roles ||
          this.userInfo.roles.some((u) => m.meta.roles.includes(u))
      )
    }
  },
  methods: {
    resolvePath(child) {
      if (child.children !== undefined) return ''
      return path.resolve(this.basePath, child.path)
    },
    openNewWindow(routePath) {
      var query = '?isPopup=true&dark=' + this.$vuetify.theme.dark
      window.open('#' + routePath + query, 'popup')
    },
    resolveSubPath(parentPath, routePath) {
      return path.resolve(this.basePath, parentPath, routePath)
    },
    openMenu(child, e) {
      e.preventDefault()
      this.child = child
      this.visible = false
      this.left = e.clientX
      this.top = e.clientY
      this.$nextTick(() => {
        this.visible = true
      })
    },
    groupClasses(path) {
      return this.$route.matched[0].path === path
        ? 'dea-list-group--selected'
        : ''
    }
  }
}
</script>

<style lang="scss">
.mdi-window-restore {
  vertical-align: 2px;
  border-radius: 50%;
  text-align: center;
  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
  transform-origin: 100% 50%;
  &:before {
    transform: scale(0.8);
    display: inline-block;
    vertical-align: -1.5px;
  }
  &:hover {
    background-color: #b4bccc;
    color: #fff;
  }
}
</style>
