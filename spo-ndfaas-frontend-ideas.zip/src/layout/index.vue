<template>
  <v-app class="dea-app">
    <dea-sidebar />

    <dea-app-bar />

    <dea-app-main />

    <dea-right-bar />

    <dea-bottom-sheet />

    <dea-speed-dial />

    <!-- go top button -->
    <v-fab-transition>
      <v-btn
        v-scroll="onScroll"
        v-show="goTop"
        bottom
        right
        color="primary"
        dark
        fab
        small
        fixed
        class="btn-top dea-btn--textindent"
        @click="toTop"
      >
        <v-icon>mdi-chevron-up</v-icon>
        맨위로
      </v-btn>
    </v-fab-transition>
    <!-- //go top button -->

    <dea-confirm-common />
  </v-app>
</template>

<script>
import {
  DeaAppMain,
  DeaSidebar,
  DeaAppBar,
  DeaBottomSheet,
  DeaRightBar,
  DeaSpeedDial
} from './components'

export default {
  name: 'Layout',
  components: {
    DeaAppMain,
    DeaSidebar,
    DeaAppBar,
    DeaBottomSheet,
    DeaRightBar,
    DeaSpeedDial
  },
  props: {
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      myAppBar: null,
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/
      goTop: false
    }
  },
  beforeMount() {
    if (this.$route.query.isPopup) {
      this.$store.dispatch('app/setPopupMode')
      this.$vuetify.theme.dark =
        this.$route.query.dark === 'true' ? true : false
      this.$setThemeClass(this.$vuetify.theme.dark)
    }
  },
  mounted() {
    this.initialize()
  },
  methods: {
    /** Initialize after mount **/
    initialize() {
      this.myAppBar = this.$refs['myAppBar']
    },

    /** Function **/
    executeSomething() {},

    /** Event Handler **/
    clickSomething(/** event **/) {},

    /** Scroll Event **/
    onScroll(e) {
      if (typeof window === 'undefined') return
      const top = window.pageYOffset || e.target.scrollTop || 0
      this.goTop = top > 20
    },
    toTop() {
      this.$vuetify.goTo('#top')
    }
  },
  beforeDestroy() {}
}
</script>

<style lang="scss">
.v-app-bar.v-toolbar.v-sheet {
  .v-toolbar__content {
    flex-direction: column;
    padding: 0;
    .d-flex.v-sheet {
      display: flex;
      width: 100%;
      align-items: center;
    }
  }
}
</style>
