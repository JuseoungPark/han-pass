import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify'
import i18n from './plugins/i18n'
import HighCharts from 'highcharts'
import './plugins/commonComponents'
import './plugins/event'
import Api from './plugins/api'
import getCommApi from '@/api/common'
import Confirm from './plugins/confirm'
import './plugins/permission'
import moment from 'moment'
import VueMomentJS from 'vue-momentjs'
import Toast from 'vue-toastification'
import 'vue-toastification/dist/index.css'
import { Plugin } from 'vue-fragment'
import './utils/filters'
import Loading from 'vue-loading-overlay'
import 'vue-loading-overlay/dist/vue-loading.css'

// Vue.use(i18n)
Vue.use(VueMomentJS, moment)
Vue.use(Confirm)
Vue.use(Api)
Vue.use(getCommApi)
Vue.use(HighCharts)
Vue.use(Toast, {
  transition: 'Vue-Toastification__fade',
  maxToasts: 20,
  newestOnTop: true,
  timeout: 2000,
  hideProgressBar: false
})
Vue.use(
  Loading,
  {
    // props
    color: '#48ccd2'
  },
  {
    // slots
  }
)
Vue.use(Plugin)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  vuetify,
  i18n,
  render: (h) => h(App)
}).$mount('#app')
