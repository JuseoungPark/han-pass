import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const TemplateRouter = {
  path: '/template',
  component: Layout,
  alwaysShow: true,
  redirect: 'noRedirect',
  name: 'Template',
  meta: {
    title: i18n.tc('menu.template.title'),
    icon: 'mdi-apps',
    roles: ['dev']
  },
  children: [
    {
      path: 'template1',
      component: () => import('@/views/template/Template1'),
      name: 'Template1',
      meta: {
        title: i18n.tc('menu.template.template1'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'commonComponents',
      component: () => import('@/views/template/CommonComponents'),
      name: 'CommonComponents',
      meta: {
        title: i18n.tc('menu.template.commonComponents'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'template2',
      component: () => import('@/views/template/Template2'),
      name: 'Template2',
      meta: {
        title: i18n.tc('menu.template.template2'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'amchartsBranding',
      component: () => import('@/views/template/AmchartsBranding'),
      name: 'AmchartsBranding',
      meta: {
        title: i18n.tc('menu.template.amchartsBranding'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'highchartsSample',
      component: () => import('@/views/template/HighchartsSample'),
      name: 'HighchartsSample',
      meta: {
        title: i18n.tc('menu.template.highchartsSample'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'template101',
      component: () => import('@/views/template/Template101'),
      name: 'Template101',
      meta: {
        title: i18n.tc('menu.template.template101'),
        roles: ['dev']
      }
    },
    {
      path: 'template00',
      component: () => import('@/views/template/Template00'),
      name: 'Template00',
      meta: {
        title: i18n.tc('menu.template.template00'),
        roles: ['dev']
      }
    },
    {
      path: 'template01',
      component: () => import('@/views/template/Template01'),
      name: 'Template01',
      meta: {
        title: i18n.tc('menu.template.template01'),
        roles: ['dev']
      }
    },
    {
      path: 'template02',
      component: () => import('@/views/template/Template02'),
      name: 'Template02',
      meta: {
        title: i18n.tc('menu.template.template02'),
        roles: ['dev']
      }
    },
    {
      path: 'template3',
      component: () => import('@/components/common/DeaRouteView.vue'),
      name: 'Template3',
      meta: {
        title: i18n.tc('menu.template.template3'),
        roles: ['dev']
      },
      children: [
        {
          path: 'template301',
          component: () => import('@/views/template/Template301'),
          name: 'Template301',
          meta: {
            title: i18n.tc('menu.template.template301'),
            roles: ['dev'],
            usePopup: true
          }
        }
      ]
    },
    {
      path: 'template4',
      component: () => import('@/components/common/DeaRouteView.vue'),
      name: 'Template4',
      meta: {
        title: i18n.tc('menu.template.template4'),
        roles: ['dev']
      },
      children: [
        {
          path: 'template401',
          component: () => import('@/views/template/Template401'),
          name: 'Template401',
          meta: {
            title: i18n.tc('menu.template.template401'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template402',
          component: () => import('@/views/template/Template402'),
          name: 'Template402',
          meta: {
            title: i18n.tc('menu.template.template402'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template403',
          component: () => import('@/views/template/Template403'),
          name: 'Template403',
          meta: {
            title: i18n.tc('menu.template.template403'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template404',
          component: () => import('@/views/template/Template404'),
          name: 'Template404',
          meta: {
            title: i18n.tc('menu.template.template404'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template405',
          component: () => import('@/views/template/Template405'),
          name: 'Template405',
          meta: {
            title: i18n.tc('menu.template.template405'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template406',
          component: () => import('@/views/template/Template406'),
          name: 'Template406',
          meta: {
            title: i18n.tc('menu.template.template406'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template407',
          component: () => import('@/views/template/Template407'),
          name: 'Template407',
          meta: {
            title: i18n.tc('menu.template.template407'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template408',
          component: () => import('@/views/template/Template408'),
          name: 'Template408',
          meta: {
            title: i18n.tc('menu.template.template408'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template409',
          component: () => import('@/views/template/Template409'),
          name: 'Template409',
          meta: {
            title: i18n.tc('menu.template.template409'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template410',
          component: () => import('@/views/template/Template410'),
          name: 'Template410',
          meta: {
            title: i18n.tc('menu.template.template410'),
            roles: ['dev'],
            usePopup: true
          }
        }
      ]
    },
    {
      path: 'template5',
      component: () => import('@/components/common/DeaRouteView.vue'),
      name: 'Template5',
      meta: {
        title: i18n.tc('menu.template.template5'),
        roles: ['dev']
      },
      children: [
        {
          path: 'template501',
          component: () => import('@/views/template/Template501'),
          name: 'Template501',
          meta: {
            title: i18n.tc('menu.template.template501'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template502',
          component: () => import('@/views/template/Template502'),
          name: 'Template502',
          meta: {
            title: i18n.tc('menu.template.template502'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template503',
          component: () => import('@/views/template/Template503'),
          name: 'Template503',
          meta: {
            title: i18n.tc('menu.template.template503'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template504',
          component: () => import('@/views/template/Template504'),
          name: 'Template504',
          meta: {
            title: i18n.tc('menu.template.template504'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template505',
          component: () => import('@/views/template/Template505'),
          name: 'Template505',
          meta: {
            title: i18n.tc('menu.template.template505'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template506',
          component: () => import('@/views/template/Template506'),
          name: 'Template506',
          meta: {
            title: i18n.tc('menu.template.template506'),
            roles: ['dev'],
            usePopup: true
          }
        }
      ]
    },
    {
      path: 'template601',
      component: () => import('@/views/template/Template601'),
      name: 'Template601',
      meta: {
        title: i18n.tc('menu.template.template601'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'template602',
      component: () => import('@/views/template/Template602'),
      name: 'Template602',
      meta: {
        title: i18n.tc('menu.template.template602'),
        roles: ['dev'],
        usePopup: true
      }
    },
    {
      path: 'template7',
      component: () => import('@/components/common/DeaRouteView.vue'),
      name: 'Template7',
      meta: {
        title: i18n.tc('menu.template.template7'),
        roles: ['dev']
      },
      children: [
        {
          path: 'template701',
          component: () => import('@/views/template/Template701'),
          name: 'Template701',
          meta: {
            title: i18n.tc('menu.template.template701'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template702',
          component: () => import('@/views/template/Template702'),
          name: 'Template702',
          meta: {
            title: i18n.tc('menu.template.template702'),
            roles: ['dev'],
            usePopup: true
          }
        },
        {
          path: 'template703',
          component: () => import('@/views/template/Template703'),
          name: 'Template703',
          meta: {
            title: i18n.tc('menu.template.template703'),
            roles: ['dev'],
            usePopup: true
          }
        }
      ]
    },
    {
      path: 'template801',
      component: () => import('@/views/template/Template801'),
      name: 'Template801',
      meta: {
        title: i18n.tc('menu.template.template801'),
        roles: ['dev'],
        usePopup: true
      }
    }
  ]
}

export default TemplateRouter
