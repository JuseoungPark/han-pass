import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const CallHistoryRouter = {
  path: '/callHistory',
  component: Layout,
  alwaysShow: true,
  redirect: 'noRedirect',
  name: 'CallHistory',
  meta: {
    title: i18n.tc('menu.callHistory.title'),
    icon: 'mdi-cellphone-iphone'
  },
  children: [
    {
      path: 'callAnalysysHome',
      component: () => import('@/views/callHistory/CallAnalysysHome'),
      name: 'CallAnalysysHome',
      meta: {
        title: i18n.tc('menu.callHistory.callAnalysysHome'),
        roles: ['admin'],
        usePopup: true,
        header: false
      }
    },
    {
      path: 'integrationCallHistory',
      component: () => import('@/views/callHistory/IntegrationCallHistory'),
      name: 'IntegrationCallHistory',
      meta: {
        title: i18n.tc('menu.callHistory.integrationCallHistory'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'callCharacteristicAnalysis',
      component: () => import('@/views/callHistory/CallCharacteristicAnalysis'),
      name: 'CallCharacteristicAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.callCharacteristicAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'singularCallHistory',
      component: () => import('@/views/callHistory/SingularCallHistory'),
      name: 'SingularCallHistory',
      meta: {
        title: i18n.tc('menu.callHistory.singularCallHistory'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'callDensityAnalysis',
      component: () => import('@/views/callHistory/CallDensityAnalysis'),
      name: 'CallDensityAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.callDensityAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'baseStationAnalysis',
      component: () => import('@/views/callHistory/BaseStationAnalysis'),
      name: 'BaseStationAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.baseStationAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'betweenKeyPeopleAnalysis',
      component: () => import('@/views/callHistory/BetweenKeyPeopleAnalysis'),
      name: 'BetweenKeyPeopleAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.betweenKeyPeopleAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'subscriberAnalysis',
      component: () => import('@/views/callHistory/SubscriberAnalysis'),
      name: 'SubscriberAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.subscriberAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'callExclusionHistoryAnalysis',
      component: () =>
        import('@/views/callHistory/CallExclusionHistoryAnalysis'),
      name: 'CallExclusionHistoryAnalysis',
      meta: {
        title: i18n.tc('menu.callHistory.callExclusionHistoryAnalysis'),
        roles: ['admin'],
        usePopup: true
      }
    },
    // Add by Dennis
    {
      path: 'callHistoryAnalysisBookmark',
      component: () =>
        import('@/views/callHistory/CallHistoryAnalysisBookmark'),
      name: 'CallHistoryAnalysisBookmark',
      meta: {
        title: i18n.tc('menu.callHistory.callHistoryAnalysisBookmark'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default CallHistoryRouter
