import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const EvidenceAnalysisRouter = {
  path: '/evidenceAnalysys',
  component: Layout,
  alwaysShow: true,
  redirect: 'evidenceAnalysysProcessStatus',
  name: 'EvidenceAnalysis',
  meta: {
    title: i18n.tc('menu.evidenceAnalysis.title'),
    icon: 'mdi-home',
    rootOnly: true
  },
  children: [
    {
      path: 'evidenceAnalysysProcessStatus',
      component: () =>
        import('@/views/evidenceanalysis/EvidenceAnalysisProcessStatus'),
      name: 'EvidenceAnalysysProcessStatus',
      meta: {
        title: i18n.tc('menu.evidenceAnalysis.evidenceAnalysisProcessStatus'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default EvidenceAnalysisRouter
