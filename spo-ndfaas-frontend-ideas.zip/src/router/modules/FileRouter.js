import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const FileRouter = {
  path: '/file',
  component: Layout,
  alwaysShow: true,
  redirect: 'noRedirect',
  name: 'File',
  meta: {
    title: i18n.tc('menu.file.title'),
    icon: 'mdi-file-multiple-outline'
  },
  children: [
    {
      path: 'fileStatus',
      component: () => import('@/views/file/FileStatus'),
      name: 'FileStatus',
      meta: {
        title: i18n.tc('menu.file.fileStatus'),
        roles: ['admin'],
        usePopup: true,
        header: false
      }
    },
    {
      path: 'registeredExtractionFile',
      component: () => import('@/views/file/RegisteredExtractionFile'),
      name: 'RegisteredExtractionFile',
      meta: {
        title: i18n.tc('menu.file.registeredExtractionFile'),
        roles: ['admin'],
        usePopup: true,
        leftSubMenu: true
      }
    },
    {
      path: 'fileTypeAnalysis',
      component: () => import('@/views/file/FileTypeAnalysis'),
      name: 'FileTypeAnalysis',
      meta: {
        title: i18n.tc('menu.file.fileTypeAnalysis'),
        roles: ['admin'],
        usePopup: true,
        leftSubMenu: true
      }
    },
    {
      path: 'indexFailureFile',
      component: () => import('@/views/file/IndexFailureFile'),
      name: 'IndexFailureFile',
      meta: {
        title: i18n.tc('menu.file.indexFailureFile'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'fileExcludeHistory',
      component: () => import('@/views/file/FileExcludeHistory'),
      name: 'FileExcludeHistory',
      meta: {
        title: i18n.tc('menu.file.fileExcludeHistory'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'fileBookmark',
      component: () => import('@/views/file/FileBookmark'),
      name: 'FileBookmark',
      meta: {
        title: i18n.tc('menu.file.fileBookmark'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default FileRouter
