import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const IntegratedBookmarkRouter = {
  path: '/integratedBookmark',
  component: Layout,
  alwaysShow: true,
  redirect: 'integratedBookmark',
  name: 'IntegratedBookmarkRoot',
  meta: {
    title: i18n.tc('menu.integratedBookmark.title'),
    icon: 'mdi-bookmark-multiple-outline',
    rootOnly: true
  },
  children: [
    {
      path: '',
      component: () => import('@/views/integratedBookmark/IntegratedBookmark'),
      name: 'IntegratedBookmark',
      meta: {
        title: i18n.tc('menu.integratedBookmark.title'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: ':idx',
      component: () => import('@/views/integratedBookmark/IntegratedBookmark'),
      name: 'IntegratedBookmarkDetail',
      meta: {
        title: i18n.tc('menu.integratedBookmark.title'),
        roles: ['admin'],
        usePopup: true,
        backButton: true,
        blank: true
      },
      props: true
    }
  ]
}

export default IntegratedBookmarkRouter
