import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const OperationPortalRouter = {
  path: '/operationPortal',
  component: Layout,
  alwaysShow: true,
  redirect: 'noRedirect',
  name: 'OperationPortal',
  meta: {
    title: i18n.tc('menu.operationPortal.title'),
    icon: 'mdi-developer-board'
  },
  children: [
    {
      path: 'extractionFileProcessStatus',
      component: () =>
        import('@/views/operationPortal/ExtractionFileProcessStatus'),
      name: 'ExtractionFileProcessStatus',
      meta: {
        title: i18n.tc('menu.operationPortal.extractionFileProcessStatus'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'incidentUsageStatus',
      component: () => import('@/views/operationPortal/IncidentUsageStatus'),
      name: 'IncidentUsageStatus',
      meta: {
        title: i18n.tc('menu.operationPortal.incidentUsageStatus'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'evidenceAnalysisUsageStatus',
      component: () =>
        import('@/views/operationPortal/EvidenceAnalysisUsageStatus'),
      name: 'EvidenceAnalysisUsageStatus',
      meta: {
        title: i18n.tc('menu.operationPortal.evidenceAnalysisUsageStatus'),
        roles: ['admin'],
        usePopup: true
      }
    },
    {
      path: 'incidentManagement',
      component: () => import('@/views/operationPortal/IncidentManagement'),
      name: 'IncidentManagement',
      meta: {
        title: i18n.tc('menu.operationPortal.incidentManagement'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default OperationPortalRouter
