import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const FileStorageManagementRouter = {
  path: '/fileStorageManagement',
  component: Layout,
  alwaysShow: true,
  redirect: 'fileStorageManagement',
  name: 'FileStorageManagementRoot',
  meta: {
    title: i18n.tc('menu.fileStorageManagement.title'),
    icon: 'mdi-folder-cog-outline',
    rootOnly: true
  },
  children: [
    {
      path: 'fileStorageManagement',
      component: () =>
        import('@/views/fileStorageManagement/FileStorageManagement'),
      name: 'FileStorageManagement',
      meta: {
        title: i18n.tc('menu.fileStorageManagement.title'),
        roles: ['admin']
      }
    }
  ]
}

export default FileStorageManagementRouter
