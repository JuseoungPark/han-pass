import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const PersonManagementRouter = {
  path: '/personManagement',
  component: Layout,
  alwaysShow: true,
  redirect: 'personManagement',
  name: 'PersonManagementRoot',
  meta: {
    title: i18n.tc('menu.personManagement.title'),
    icon: 'mdi-account-box-multiple-outline',
    rootOnly: true
  },
  children: [
    {
      path: 'personManagement',
      component: () => import('@/views/personManagement/PersonManagement'),
      name: 'PersonManagement',
      meta: {
        title: i18n.tc('menu.personManagement.title'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default PersonManagementRouter
