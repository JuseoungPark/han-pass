import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const PersonCenteredAnalysisRouter = {
  path: '/personCenteredAnalysis',
  component: Layout,
  alwaysShow: true,
  redirect: 'integratedCorrelationChart',
  name: 'PersonCenteredAnalysis',
  meta: {
    title: i18n.tc('menu.personCenteredAnalysis.title'),
    icon: 'mdi-account-reactivate-outline',
    rootOnly: true,
    usePopup: true
  },
  children: [
    {
      path: 'integratedCorrelationChart',
      component: () =>
        import('@/views/personCenteredAnalysis/IntegratedCorrelationChart2'),
      name: 'IntegratedCorrelationChart',
      meta: {
        title: i18n.tc('menu.personCenteredAnalysis.title'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default PersonCenteredAnalysisRouter
