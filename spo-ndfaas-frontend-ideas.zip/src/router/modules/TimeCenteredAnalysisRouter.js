import i18n from '@/plugins/i18n'
import Layout from '@/layout'

const TimeCenteredAnalysisRouter = {
  path: '/timeCenteredAnalysis',
  component: Layout,
  alwaysShow: true,
  redirect: 'noRedirect',
  name: 'TimeCenteredAnalysis',
  meta: {
    title: i18n.tc('menu.timeCenteredAnalysis.title'),
    icon: 'mdi-clock-outline',
    rootOnly: true,
    usePopup: true
  },
  children: [
    {
      path: 'timeSeriesAnalysis',
      component: () =>
        import('@/views/timeCenteredAnalysis/TimeSeriesAnalysis'),
      name: 'TimeSeriesAnalysis',
      meta: {
        title: i18n.tc('menu.timeCenteredAnalysis.title'),
        roles: ['admin'],
        usePopup: true
      }
    }
  ]
}

export default TimeCenteredAnalysisRouter
