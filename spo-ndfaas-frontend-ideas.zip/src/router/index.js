import Vue from 'vue'
import VueRouter from 'vue-router'
import i18n from '@/plugins/i18n'

Vue.use(VueRouter)

import Layout from '@/layout'
import PersonManagementRouter from './modules/PersonManagementRouter'
import CallHistoryRouter from './modules/CallHistoryRouter'
import PersonCenteredAnalysisRouter from './modules/PersonCenteredAnalysisRouter'
import TimeCenteredAnalysisRouter from './modules/TimeCenteredAnalysisRouter'
import IntegratedBookmarkRouter from './modules/IntegratedBookmarkRouter'
import FileRouter from './modules/FileRouter'
import FileStorageManagementRouter from './modules/FileStorageManagement'

import TemplateRouter from './modules/TemplateRouter'

export const constantRoutes = [
  {
    path: '/',
    component: Layout,
    alwaysShow: true,
    redirect: 'home',
    name: 'EvidenceAnalysis',
    meta: {
      title: i18n.tc('menu.evidenceAnalysis.title'),
      icon: 'mdi-home',
      rootOnly: true
    },
    children: [
      {
        path: 'home',
        component: () =>
          import('@/views/evidenceanalysis/EvidenceAnalysisHome'),
        name: 'EvidenceAnalysisHome',
        meta: {
          title: i18n.tc('menu.evidenceAnalysis.title'),
          affix: true,
          header: false
        }
      },
      {
        path: 'integrationSearch',
        component: () => import('@/views/evidenceanalysis/IntegrationSearch'),
        name: 'IntegrationSearch',
        hidden: true,
        meta: {
          title: i18n.tc('menu.evidenceAnalysis.integrationSearch'),
          blank: true,
          backButton: true
        }
      },
      {
        path: 'evidenceAnalysisProcessStatus',
        component: () =>
          import('@/views/evidenceanalysis/EvidenceAnalysisProcessStatus'),
        name: 'EvidenceAnalysisProcessStatus',
        hidden: true,
        meta: {
          title: i18n.tc('menu.evidenceAnalysis.evidenceAnalysisProcessStatus'),
          blank: true,
          backButton: true
        }
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/views/Login'),
    hidden: true,
    redirect: false,
    name: 'Login',
    meta: {
      title: '로그인'
    }
  }
]

export const asyncRoutes = [
  PersonManagementRouter,
  CallHistoryRouter,
  FileRouter,
  PersonCenteredAnalysisRouter,
  TimeCenteredAnalysisRouter,
  IntegratedBookmarkRouter,
  FileStorageManagementRouter,
  TemplateRouter,
  { path: '/index.html', redirect: '/', hidden: true }
]

// constantRoutes.concat(asyncRoutes)

const createRouter = () =>
  new VueRouter({
    mode: 'hash',
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
  })

const router = createRouter()

// const router = new VueRouter({
//   mode: 'hash',
//   // base: process.env.BASE_URL,
//   routes: constantRoutes
// })

export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher
}

export default router
