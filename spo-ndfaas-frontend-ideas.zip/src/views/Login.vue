<template>
  <v-app class="dea-app">
    <v-main id="top">
      <v-container fill-height fluid>
        <v-row no-gutters align="center" justify="center" class="dea-login">
          <v-col cols="12" class="d-flex align-center">
            <section class="dea-section">
              <div class="inner">
                <dea-card>
                  <template slot="title">로그인</template>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>아이디</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <dea-text-field
                        v-model="userId"
                        placeholder="아이디를 입력하세요"
                      ></dea-text-field>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>비밀번호</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <dea-text-field
                        v-model="password"
                        type="password"
                        placeholder="패스워드를 입력하세요"
                      ></dea-text-field>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <dea-checkbox
                        v-model="isStore"
                        label="아이디/비밀번호 기억하기"
                      ></dea-checkbox>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex align-center">
                      <dea-button color="primary" @click="login">
                        로그인
                      </dea-button>
                    </v-col>
                  </v-row>
                  <template slot="actions">
                    <div class="btn-group">
                      <v-row>
                        <v-col class="d-flex align-center">
                          <dea-button text small @click="idSearch = !idSearch"
                            >아이디찾기</dea-button
                          >
                          <v-divider vertical class="ma-0" />
                          <dea-button text small @click="renewPassword"
                            >비밀번호 재발급</dea-button
                          >
                        </v-col>
                      </v-row>
                    </div>
                  </template>
                </dea-card>
              </div>
            </section>
          </v-col>
        </v-row>

        <!-- 아이디찾기 : Layer Popup -->
        <dea-dialog v-model="idSearch" title="아이디찾기" width="640px">
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>소속기관</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="소속기관을 입력하세요"
                    ></dea-text-field>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>부서</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="부서명을 입력하세요"
                    ></dea-text-field>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>이름</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="이름을 입력하세요"
                    ></dea-text-field>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>핸드폰</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field label="국번"></dea-text-field>
                    <dea-text-field label="앞자리"></dea-text-field>
                    <dea-text-field label="뒷자리"></dea-text-field>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
          </section>
          <div class="btn-group">
            <v-col class="align-center">
              <dea-button outlined @click="idSearch = !idSearch"
                >닫기</dea-button
              >
              <dea-button color="primary">찾기</dea-button>
            </v-col>
          </div>
        </dea-dialog>
        <!-- //아이디찾기 : Layer Popup -->
      </v-container>
      <dea-confirm-common />
    </v-main>
  </v-app>
</template>

<script>
import VueRouter from 'vue-router'
const { isNavigationFailure, NavigationFailureType } = VueRouter

export default {
  name: 'Login',
  data() {
    return {
      userId: 'testerA1',
      password: '123456',
      isStore: '',
      idSearch: false
    }
  },
  methods: {
    login() {
      this.$api.incident.handler.login(
        this.userId,
        this.password,
        this.loginCallback
      )
    },
    loginCallback(res) {
      let code = Number(res.data.CODE)
      if (code === 0) this.loginProcess(res.data)
      else if (code === -2) this.$alert('비밀번호가 ' + res.data.MSG)
      else {
        this.$alert(res.data.MSG)
      }
    },
    loginProcess(data) {
      this.$store.dispatch('user/login', {
        userId: data.userId,
        token: data.token
      })
      this.$store.dispatch('user/appendRole', 'admin')
      this.$store.dispatch('user/appendRole', 'dev')
      this.$api.incident.defaults.headers.token = data.token
      this.$router
        .push({
          path: this.$route.query.redirect || '/'
        })
        .catch((e) => {
          if (!isNavigationFailure(e, NavigationFailureType.redirected)) {
            Promise.reject(e)
          }
        })
    },
    renewPassword() {
      this.$alert('비밀번호 재발급은 기관 관리자에게 요청하시기 바랍니다.')
    }
  }
}
</script>
