<template>
  <v-container>
    <article>
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title">Stepper / Tabs</template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label required>Stepper</dea-label>
              </v-col>
              <v-col class="d-flex">
                <v-stepper v-model="e1">
                  <v-stepper-header>
                    <v-stepper-step :complete="e1 > 1" step="1"
                      >Name of step 1</v-stepper-step
                    >
                    <v-divider></v-divider>
                    <v-stepper-step :complete="e1 > 2" step="2"
                      >Name of step 2</v-stepper-step
                    >
                    <v-divider></v-divider>
                    <v-stepper-step :complete="e1 > 3" step="3"
                      >Name of step 3</v-stepper-step
                    >
                  </v-stepper-header>

                  <v-stepper-items>
                    <v-stepper-content step="1">
                      <dea-card class="mb-12">Step 1</dea-card>
                      <dea-button color="primary" @click="e1 = 2">
                        Continue
                      </dea-button>
                      <dea-button text>
                        Cancel
                      </dea-button>
                    </v-stepper-content>

                    <v-stepper-content step="2">
                      <dea-card class="mb-12">Step 2</dea-card>
                      <dea-button color="primary" @click="e1 = 3">
                        Continue
                      </dea-button>
                      <dea-button text>
                        Cancel
                      </dea-button>
                    </v-stepper-content>

                    <v-stepper-content step="3">
                      <dea-card class="mb-12">Step 3</dea-card>
                      <dea-button color="primary" @click="e1 = 1">
                        Continue
                      </dea-button>
                      <dea-button text>
                        Cancel
                      </dea-button>
                    </v-stepper-content>
                  </v-stepper-items>
                </v-stepper>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label required>Tabs</dea-label>
              </v-col>
              <v-col class="d-flex d-block overflow-x-hidden">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-tabs
                      v-model="tab2"
                      :tabItems="tab2Items"
                      class="full-width"
                    ></dea-tabs>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-tabs v-model="tab" :tabItems="tabItems"></dea-tabs>
                  </v-col>
                </v-row>
                <v-row no-gutters style="min-height:101px">
                  <v-col class="d-flex">
                    <dea-tabs v-model="tab" :tabItems="tabItems">
                      <dea-card>
                        {{ tabItems[tab].content }}
                      </dea-card>
                    </dea-tabs>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-tabs v-model="tabSelected1" :tabItems="tabItems1">
                      <keep-alive>
                        <component
                          :is="tabItems1[tabSelected1].component"
                        ></component>
                      </keep-alive>
                    </dea-tabs>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-tabs
                      v-model="tabSelected2"
                      :tabItems="tabItems2"
                    ></dea-tabs>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title">
              Textfield, Attach File, Textarea, Value
            </template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Text fields</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  classes="flex-0"
                  styles="width:200px"
                  label="사용자"
                  placeholder="이름을 입력하세요."
                  hint="상태메세지를 보여줍니다."
                  error
                ></dea-text-field>
                <dea-text-field
                  single-line
                  clearable
                  readonly
                  label="이메일(readonly)"
                  placeholder="이메일을 입력하세요."
                  value="gildong794@gmail.com"
                  hint="At least 8 characters"
                  persistent-hint
                ></dea-text-field>
                <dea-text-field
                  disabled
                  label="전화번호(disabled)"
                  placeholder="전화번호를 입력하세요."
                  hint="상태메세지를 보여줍니다."
                ></dea-text-field>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Text fields(align)</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  clearable
                  label="정렬(Left)"
                  placeholder="입력하세요"
                  hint="상태메세지"
                ></dea-text-field>
                <dea-text-field
                  clearable
                  classes="align-center"
                  label="정렬(Center)"
                  placeholder="입력하세요"
                  hint="상태메세지"
                ></dea-text-field>
                <dea-text-field
                  clearable
                  class="align-right"
                  label="정렬(Right)"
                  placeholder="입력하세요"
                  hint="상태메세지"
                ></dea-text-field>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Text fields(icon)</dea-label>
              </v-col>
              <v-col class="d-flex" cols="5">
                <dea-text-field
                  clearable
                  label="사용자"
                  placeholder="이름을 입력하세요."
                  hint="상태메세지를 보여줍니다."
                  :prepend-icon="
                    icons ? 'mdi-emoticon-happy' : 'mdi-emoticon-sad'
                  "
                  prepend-inner-icon="mdi-account-outline"
                  :append-icon="
                    marker ? 'mdi-map-marker' : 'mdi-map-marker-off'
                  "
                  :append-outer-icon="message ? 'mdi-send' : 'mdi-microphone'"
                  @click:prepend="changeIcon"
                  @click:append="toggleMarker"
                  @click:append-outer="sendMessage"
                ></dea-text-field>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Password</dea-label>
              </v-col>
              <v-col class="d-flex" cols="5">
                <dea-text-field
                  v-model="password"
                  clearable
                  label="비밀번호"
                  placeholder="비밀번호를 입력하세요."
                  :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                  :rules="[rules.required, rules.min]"
                  :type="show1 ? 'text' : 'password'"
                  hint="At least 8 characters"
                  counter="20"
                  @click:append="show1 = !show1"
                ></dea-text-field>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>File Inputs</dea-label>
              </v-col>
              <v-col class="d-flex" cols="5">
                <dea-file-input
                  counter
                  label="Attach Single File"
                  placeholder="Select your files"
                  prepend-icon="mdi-plus"
                  :show-size="1000"
                >
                </dea-file-input>
              </v-col>
              <v-col class="d-flex" cols="5">
                <dea-file-input
                  single-line
                  counter
                  multiple
                  label="Attach Multi File"
                  placeholder="Select your files"
                  prepend-icon="mdi-plus"
                  append-outer-icon="mdi-paperclip"
                  :show-size="1000"
                >
                </dea-file-input>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1" class="valign-top">
                <dea-label>Textareas</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-textarea
                      label="상세설명"
                      placeholder="상세설명을 입력하세요."
                      hint="상태메세지를 보여줍니다."
                    ></dea-textarea>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-textarea
                      height="80px"
                      readonly
                      no-resize
                      label="상세설명(readonly)"
                      placeholder="상세설명을 입력하세요."
                      hint="상태메세지를 보여줍니다."
                      persistent-hint
                      value="가나다라마바사"
                    ></dea-textarea>
                    <dea-textarea
                      height="80px"
                      disabled
                      no-resize
                      counter="100"
                      label="상세설명(disabled)"
                      placeholder="상세설명을 입력하세요."
                      hint="상태메세지를 보여줍니다."
                      value="가나다라마바사"
                    ></dea-textarea>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Text</dea-label>
              </v-col>
              <v-col class="d-flex">
                <a href="#" class="text-decoration-none">
                  Non-underlined link
                </a>
                <div class="text-decoration-line-through">
                  Line-through text
                </div>
                <div class="text-decoration-overline">
                  Overline text
                </div>
                <div class="text-decoration-underline">
                  Underline text
                </div>
              </v-col>
            </v-row>

            <v-expand-transition>
              <div v-show="showPanel">
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>Value</dea-label>
                  </v-col>
                  <v-col class="d-flex d-block">
                    <v-row no-gutters>
                      <v-col class="d-flex">
                        <dea-text-field
                          filled
                          readonly
                          label="이메일(readonly)"
                          placeholder="이메일을 입력하세요."
                          value="gildong794@gmail.com"
                        ></dea-text-field>
                        <dea-text-field
                          single-line
                          filled
                          disabled
                          label="전화번호(disabled)"
                          placeholder="전화번호를 입력하세요."
                          value="010-1234-5678"
                        ></dea-text-field>
                      </v-col>
                    </v-row>
                    <v-row no-gutters>
                      <v-col class="d-flex">
                        <dea-textarea
                          filled
                          no-resize
                          readonly
                          counter="100"
                          label="상세설명(readonly)"
                          placeholder="상세설명을 입력하세요."
                          hint="상태메세지를 보여줍니다."
                          value="가나다라마바사"
                        ></dea-textarea>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </div>
            </v-expand-transition>

            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-left">
                  <dea-button outlined prepend-icon="mdi-home">버튼</dea-button>
                </v-col>
                <v-col class="align-right">
                  <dea-button outlined>버튼2</dea-button>
                  <dea-button outlined @click="showPanel = !showPanel">{{
                    showPanel ? '검색조건 접기' : '검색조건 펼치기'
                  }}</dea-button>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title">Select, Combobox, Autocomplete</template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Select</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-select
                      :items="items"
                      class="flex-0"
                      style="width:200px"
                      label="종류"
                      placeholder="종류를 선택하세요."
                      prepend-icon="mdi-city-variant-outline"
                      prepend-inner-icon="mdi-account-check-outline"
                      append-icon="mdi-account-plus-outline"
                      append-outer-icon="mdi-application-import"
                      @click:prepend="true"
                      @click:append-outer="true"
                    ></dea-select>
                    <dea-select
                      :items="items"
                      single-line
                      multiple
                      small-chips
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite animal"
                      persistent-hint
                    ></dea-select>
                    <dea-select
                      :items="items"
                      single-line
                      multiple
                      selections-eraseable
                      small-chips
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite animal"
                      persistent-hint
                    ></dea-select>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-select
                      v-model="select"
                      :items="items"
                      multiple
                      selections-summary
                      label="종류"
                      placeholder="종류를 선택하세요."
                    >
                    </dea-select>
                    <dea-select
                      v-model="selectedFruits"
                      :items="fruits"
                      single-line
                      multiple
                      dea-prepend-select-all
                      selections-summary
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite fruits"
                      persistent-hint
                    >
                    </dea-select>
                    <dea-select
                      v-model="select2"
                      :items="items"
                      single-line
                      readonly
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></dea-select>
                    <dea-select
                      v-model="select3"
                      :items="items"
                      single-line
                      disabled
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></dea-select>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Autocompletes</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-select
                      filterable
                      :items="items"
                      class="flex-0"
                      style="width:200px"
                      label="종류"
                      placeholder="종류를 선택하세요."
                      prepend-icon="mdi-city-variant-outline"
                      prepend-inner-icon="mdi-account-check-outline"
                      append-icon="mdi-account-plus-outline"
                      append-outer-icon="mdi-application-import"
                      @click:prepend="true"
                      @click:append-outer="true"
                    ></dea-select>
                    <dea-select
                      filterable
                      :items="items"
                      single-line
                      multiple
                      small-chips
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite animal"
                      persistent-hint
                    ></dea-select>
                    <dea-select
                      filterable
                      :items="items"
                      single-line
                      multiple
                      selections-eraseable
                      small-chips
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite animal"
                      persistent-hint
                    ></dea-select>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-select
                      filterable
                      v-model="select"
                      :items="items"
                      multiple
                      selections-summary
                      label="종류"
                      placeholder="종류를 선택하세요."
                    >
                    </dea-select>
                    <dea-select
                      filterable
                      v-model="selectedFruits"
                      :items="fruits"
                      single-line
                      multiple
                      selections-summary
                      dea-prepend-select-all
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite fruits"
                      persistent-hint
                    >
                    </dea-select>
                    <dea-select
                      filterable
                      v-model="select2"
                      :items="items"
                      single-line
                      readonly
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></dea-select>
                    <dea-select
                      filterable
                      v-model="select3"
                      :items="items"
                      single-line
                      disabled
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></dea-select>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Combobox (사용안함)</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <v-combobox
                      :items="items"
                      dense
                      outlined
                      class="flex-0"
                      style="width:200px"
                      label="종류"
                      placeholder="종류를 선택하세요."
                      prepend-icon="mdi-city-variant-outline"
                      prepend-inner-icon="mdi-account-check-outline"
                      append-icon="mdi-account-plus-outline"
                      append-outer-icon="mdi-application-import"
                      @click:prepend="true"
                      @click:append-outer="true"
                    ></v-combobox>
                    <v-combobox
                      :items="items"
                      dense
                      single-line
                      outlined
                      multiple
                      small-chips
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite animal"
                      persistent-hint
                    ></v-combobox>
                    <v-combobox
                      v-model="select2"
                      :items="items"
                      dense
                      single-line
                      outlined
                      readonly
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></v-combobox>
                    <v-combobox
                      v-model="select3"
                      :items="items"
                      dense
                      single-line
                      outlined
                      disabled
                      label="종류"
                      placeholder="종류를 선택하세요."
                    ></v-combobox>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <v-combobox
                      v-model="select"
                      :items="items"
                      dense
                      outlined
                      multiple
                      label="종류"
                      placeholder="종류를 선택하세요."
                    >
                      <template v-slot:selection="{ item, index }">
                        <v-chip v-if="index === 0" small>
                          <span>{{ item }}</span>
                        </v-chip>
                        <span v-if="index === 1" class="caption"
                          >(+{{ select.length - 1 }} others)</span
                        >
                      </template>
                    </v-combobox>
                    <v-combobox
                      v-model="selectedFruits"
                      :items="fruits"
                      dense
                      single-line
                      outlined
                      multiple
                      label="종류"
                      placeholder="종류를 선택하세요."
                      hint="Pick your favorite fruits"
                      persistent-hint
                    >
                      <template v-slot:prepend-item>
                        <v-list-item ripple @click="toggle">
                          <v-list-item-action>
                            <v-icon
                              :color="
                                selectedFruits.length > 0
                                  ? 'indigo darken-4'
                                  : ''
                              "
                              >{{ icon }}</v-icon
                            >
                          </v-list-item-action>
                          <v-list-item-content>
                            <v-list-item-title>Select All</v-list-item-title>
                          </v-list-item-content>
                        </v-list-item>
                        <v-divider class="mt-2"></v-divider>
                      </template>
                      <template v-slot:selection="{ item, index }">
                        <v-chip v-if="index === 0" small>
                          <span>{{ item }}</span>
                        </v-chip>
                        <span v-if="index === 1" class="caption"
                          >(+{{ selectedFruits.length - 1 }} others)</span
                        >
                      </template>
                    </v-combobox>
                  </v-col>
                  <v-col class="d-flex">
                    <v-combobox
                      v-model="comboModel"
                      :filter="filter"
                      :hide-no-data="!search"
                      :items="comboItems"
                      :search-input.sync="search"
                      dense
                      outlined
                      multiple
                      small-chips
                      hide-selected
                      label="Search for an option"
                      placeholder="아이템별 제거"
                      hint="아이템별로 제거가 가능한 형식"
                      persistent-hint
                    >
                      <!-- <template v-slot:no-data>
                    <v-list-item>
                      <span class="subheading">Create</span>
                      <v-chip
                        small
                      >
                        {{ search }}
                      </v-chip>
                    </v-list-item>
                  </template> -->
                      <template
                        v-slot:selection="{ attrs, item, parent, selected }"
                      >
                        <v-chip
                          v-if="item === Object(item)"
                          v-bind="attrs"
                          :color="`${item.color} lighten-3`"
                          :input-value="selected"
                          small
                        >
                          <span>
                            {{ item.text }}
                          </span>
                          <v-icon small @click="parent.selectItem(item)"
                            >close</v-icon
                          >
                        </v-chip>
                      </template>
                      <template v-slot:item="{ index, item }">
                        <v-text-field
                          v-if="editing === item"
                          v-model="editing.text"
                          autofocus
                          flat
                          hide-details
                          single-line
                          @keyup.enter="edit(index, item)"
                        ></v-text-field>
                        <v-chip v-else :color="`${item.color} lighten-3`" small>
                          {{ item.text }}
                        </v-chip>
                        <v-spacer></v-spacer>
                        <v-list-item-action @click.stop>
                          <v-btn icon @click.stop.prevent="edit(index, item)">
                            <v-icon>{{
                              editing !== item ? 'mdi-pencil' : 'mdi-check'
                            }}</v-icon>
                          </v-btn>
                        </v-list-item-action>
                      </template>
                    </v-combobox>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title">
              Selelct Controls - Checkbox, Radio, Switch
            </template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Checkbox</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-checkbox
                  v-model="checkbox"
                  label="체크박스"
                ></dea-checkbox>
                <dea-checkbox
                  v-model="checkbox2"
                  label="체크박스(readonly)"
                  readonly
                  hint="상세설명을 보여줍니다."
                  persistent-hint
                ></dea-checkbox>
                <dea-checkbox
                  v-model="checkbox3"
                  label="체크박스(disabled)"
                  disabled
                ></dea-checkbox>
                <dea-checkbox
                  input-value="true"
                  value
                  label="체크박스"
                  class="dea-btn--textindent"
                ></dea-checkbox>
                <dea-checkbox
                  value
                  label="체크박스"
                  class="dea-btn--textindent"
                ></dea-checkbox>
                <dea-checkbox
                  value
                  label="체크박스"
                  class="dea-btn--textindent"
                  indeterminate
                ></dea-checkbox>
              </v-col>
              <v-col cols="1">
                <v-subheader>Checkbox<br />(버튼형)</v-subheader>
              </v-col>
              <v-col class="d-flex" cols="3">
                <v-checkbox
                  v-model="checkbox"
                  label="1"
                  class="dea-btn-checkbox"
                ></v-checkbox>
                <v-checkbox label="2" class="dea-btn-checkbox"></v-checkbox>
                <v-checkbox
                  v-model="checkboxButton1"
                  :label="checkboxButton1 ? '선택' : '취소'"
                  class="dea-btn-checkbox"
                ></v-checkbox>
                <v-checkbox
                  v-model="checkboxButton2"
                  :label="checkboxButton2 ? '선택' : '취소'"
                  class="dea-btn-checkbox"
                ></v-checkbox>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Radio</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="radios"
                  row
                  :mandatory="false"
                  :items="radioItems"
                ></dea-radio-group>
                <dea-radio-group
                  v-model="radios"
                  row
                  readonly
                  :mandatory="false"
                  :items="radioItems"
                ></dea-radio-group>
                <dea-radio-group
                  v-model="radios"
                  row
                  disabled
                  :mandatory="false"
                  :items="radioItems"
                ></dea-radio-group>
              </v-col>
              <v-col cols="1">
                <v-subheader>Radio</v-subheader>
              </v-col>
              <v-col class="d-flex" cols="3">
                <v-radio-group
                  v-model="radios"
                  row
                  :mandatory="false"
                  class="dea-btn-radio"
                >
                  <v-radio label="Radio 1" value="radio-1"></v-radio>
                  <v-radio label="Radio 2" value="radio-2"></v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Switch</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-switch v-model="switch1" label="Switch 1"></dea-switch>
                <dea-switch label="Switch 2"></dea-switch>
                <dea-switch
                  label="Switch(readonly)"
                  input-value="true"
                  readonly
                ></dea-switch>
                <dea-switch
                  label="Switch(disabled)"
                  input-value="true"
                  disabled
                ></dea-switch>
                <dea-switch value input-value="true"></dea-switch>
                <dea-switch value></dea-switch>
                <dea-switch
                  inset
                  value
                  label="Switch(inset)"
                  input-value="true"
                ></dea-switch>
                <dea-switch inset value label="Switch(inset)"></dea-switch>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title"
              >Button은 기본형으로 Gradient를 가짐</template
            >
            <div class="box-wrap">
              <v-row>
                <v-col cols="1">
                  <dea-label>Button</dea-label>
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row>
                    <v-col class="d-flex">
                      <dea-button color="primary">버튼</dea-button>
                      <dea-button
                        color="primary"
                        prepend-icon="mdi-clipboard-edit-outline"
                      >
                        버튼
                      </dea-button>
                      <dea-button>버튼</dea-button>
                      <dea-button prepend-icon="mdi-clipboard-edit-outline">
                        버튼
                      </dea-button>
                      <dea-button
                        text
                        prepend-icon="mdi-clipboard-edit-outline"
                      >
                        버튼
                      </dea-button>
                      <dea-button
                        outlined
                        prepend-icon="mdi-clipboard-edit-outline"
                      >
                        버튼
                      </dea-button>
                      <dea-button
                        icon
                        fab
                        color="primary"
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        >버튼</dea-button
                      >
                      <dea-button
                        icon
                        fab
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        >버튼</dea-button
                      >
                      <dea-button
                        icon
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                      >
                        버튼</dea-button
                      >
                      <dea-button
                        icon
                        outlined
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                      >
                        버튼</dea-button
                      >
                      <dea-button color="primary" classes="gradient">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </dea-button>
                    </v-col>
                  </v-row>
                  <v-row>
                    <v-col class="d-flex">
                      <dea-button color="primary" disabled>버튼</dea-button>
                      <dea-button
                        color="primary"
                        prepend-icon="mdi-clipboard-edit-outline"
                        disabled
                      >
                        버튼
                      </dea-button>
                      <dea-button disabled>버튼</dea-button>
                      <dea-button
                        prepend-icon="mdi-clipboard-edit-outline"
                        disabled
                      >
                        버튼
                      </dea-button>
                      <dea-button
                        text
                        prepend-icon="mdi-clipboard-edit-outline"
                        disabled
                      >
                        버튼
                      </dea-button>
                      <dea-button
                        outlined
                        prepend-icon="mdi-clipboard-edit-outline"
                        disabled
                      >
                        버튼
                      </dea-button>
                      <dea-button
                        icon
                        fab
                        color="primary"
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        disabled
                        >버튼</dea-button
                      >
                      <dea-button
                        icon
                        fab
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        disabled
                        >버튼</dea-button
                      >
                      <dea-button
                        icon
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        disabled
                      >
                        버튼</dea-button
                      >
                      <dea-button
                        icon
                        outlined
                        prepend-icon="mdi-clipboard-edit-outline"
                        textindent
                        disabled
                      >
                        버튼</dea-button
                      >
                      <dea-button color="primary" classes="gradient" disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </dea-button>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="1">
                  <dea-label>Toggle Button</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-button-toggle
                    mandatory
                    color="primary"
                    textindent
                    :items="btnToggleItems"
                    >{{ btnToggleItems.text }}</dea-button-toggle
                  >
                  <v-btn-toggle dense>
                    <v-btn @click="toggleBtn = !toggleBtn">
                      <v-icon>mdi-arrow-expand-all</v-icon>
                      {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                    </v-btn>
                  </v-btn-toggle>
                  <dea-button-toggle
                    mandatory
                    color="primary"
                    textindent
                    :items="btnToggleItems"
                    disabled
                    >{{ btnToggleItems.text }}</dea-button-toggle
                  >
                  <v-btn-toggle dense>
                    <v-btn @click="toggleBtn = !toggleBtn" disabled>
                      <v-icon>mdi-arrow-expand-all</v-icon>
                      {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                    </v-btn>
                  </v-btn-toggle>
                </v-col>
              </v-row>
            </div>
          </dea-card>
        </div>
        <div class="search-box">
          <dea-card>
            <template slot="title">Components</template>
            <template slot="sub-title"
              >Button(v-card__text안에 위치하는 경우엔 Gradient 제거됨) / Date
              Picker / Rating</template
            >
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Button</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button color="primary">버튼</dea-button>
                    <dea-button
                      color="primary"
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button>버튼</dea-button>
                    <dea-button prepend-icon="mdi-clipboard-edit-outline">
                      버튼
                    </dea-button>
                    <dea-button text prepend-icon="mdi-clipboard-edit-outline">
                      버튼
                    </dea-button>
                    <dea-button
                      outlined
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button
                      icon
                      fab
                      color="primary"
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                      >버튼</dea-button
                    >
                    <dea-button
                      icon
                      fab
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                      >버튼</dea-button
                    >
                    <dea-button
                      icon
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                    >
                      버튼</dea-button
                    >
                    <dea-button
                      icon
                      outlined
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                    >
                      버튼</dea-button
                    >
                    <dea-button color="primary" classes="gradient">
                      <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                    </dea-button>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button color="primary" disabled>버튼</dea-button>
                    <dea-button
                      color="primary"
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button disabled>버튼</dea-button>
                    <dea-button
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button
                      text
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button
                      outlined
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                    >
                      버튼
                    </dea-button>
                    <dea-button
                      icon
                      fab
                      color="primary"
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                      >버튼</dea-button
                    >
                    <dea-button
                      icon
                      fab
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                      >버튼</dea-button
                    >
                    <dea-button
                      icon
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                    >
                      버튼</dea-button
                    >
                    <dea-button
                      outlined
                      icon
                      disabled
                      prepend-icon="mdi-clipboard-edit-outline"
                      textindent
                      >버튼
                    </dea-button>
                    <dea-button color="primary" class="gradient" disabled>
                      <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                    </dea-button>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button color="secondary">Secondary</dea-button>
                    <dea-button color="accent">Accent</dea-button>
                    <dea-button color="success">Success</dea-button>
                    <dea-button color="info">Infomation</dea-button>
                    <dea-button color="warning" prepend-icon="mdi-alert-outline"
                      >Warning</dea-button
                    >
                    <dea-button
                      color="error"
                      prepend-icon="mdi-alert-circle-outline"
                      >Error</dea-button
                    >
                    <dea-button
                      icon
                      fab
                      color="info"
                      prepend-icon="mdi-information-outline"
                      textindent
                      >Info</dea-button
                    >
                    <dea-button
                      color="warning"
                      icon
                      prepend-icon="mdi-alert-outline"
                      textindent
                      >Warning</dea-button
                    >
                    <dea-button
                      color="error"
                      icon
                      outlined
                      prepend-icon="mdi-alert-circle-outline"
                      textindent
                      >Error</dea-button
                    >
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button color="secondary">Secondary</dea-button>
                    <dea-button color="accent">Accent</dea-button>
                    <dea-button text color="success">Success</dea-button>
                    <dea-button outlined color="info">Infomation</dea-button>
                    <dea-button
                      text
                      color="warning"
                      prepend-icon="mdi-alert-outline"
                    >
                      Warning
                    </dea-button>
                    <dea-button
                      color="error"
                      prepend-icon="mdi-alert-circle-outline"
                    >
                      Error
                    </dea-button>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button color="secondary" disabled
                      >Secondary</dea-button
                    >
                    <dea-button color="accent" disabled>Accent</dea-button>
                    <dea-button text color="success" disabled
                      >Success</dea-button
                    >
                    <dea-button outlined color="info" disabled
                      >Infomation</dea-button
                    >
                    <dea-button
                      text
                      color="warning"
                      prepend-icon="mdi-alert-outline"
                      disabled
                      >Warning</dea-button
                    >
                    <dea-button
                      color="error"
                      prepend-icon="mdi-alert-circle-outline"
                      disabled
                      >Error</dea-button
                    >
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-button-toggle
                      mandatory
                      color="primary"
                      textindent
                      :items="btnToggleItems"
                      >{{ btnToggleItems.text }}</dea-button-toggle
                    >
                    <v-btn-toggle dense>
                      <v-btn @click="toggleBtn = !toggleBtn">
                        <v-icon>mdi-arrow-expand-all</v-icon>
                        {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                      </v-btn>
                    </v-btn-toggle>
                    <dea-button-toggle
                      mandatory
                      color="primary"
                      textindent
                      :items="btnToggleItems"
                      disabled
                      >{{ btnToggleItems.text }}</dea-button-toggle
                    >
                    <v-btn-toggle dense>
                      <v-btn @click="toggleBtn = !toggleBtn" disabled>
                        <v-icon>mdi-arrow-expand-all</v-icon>
                        {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                      </v-btn>
                    </v-btn-toggle>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Date Picker</dea-label>
              </v-col>
              <v-col class="d-flex" cols="4">
                <dea-date-picker
                  :close-on-content-click="false"
                  :return-value.sync="date"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                ></dea-date-picker>
                <!-- <v-menu
              ref="menu"
              v-model="menu"
              :close-on-content-click="false"
              :return-value.sync="date"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="date"
                  dense
                  outlined
                  single-line
                  label="Picker in menu"
                  v-bind="attrs"
                ></v-text-field>
                <v-icon v-on="on">mdi-calendar-month</v-icon>
              </template>
              <v-date-picker v-model="date" no-title scrollable>
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="menu = false">Cancel</v-btn>
                <v-btn text color="primary" @click="$refs.menu.save(date)"
                  >OK</v-btn
                >
              </v-date-picker>
            </v-menu> -->
              </v-col>
              <v-col cols="1">
                <dea-label>Time Picker</dea-label>
              </v-col>
              <v-col class="d-flex">
                <!-- <dea-time-picker v-model="time1"></dea-time-picker> -->
                <dea-time-picker
                  :close-on-content-click="false"
                  :return-value.sync="time1"
                  transition="scale-transition"
                  offset-y
                  use-seconds
                ></dea-time-picker>
                <span>~</span>
                <dea-time-picker v-model="time2" text></dea-time-picker>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <v-subheader>Duration Date Picker</v-subheader>
              </v-col>
              <v-col class="d-flex" cols="4">
                <dea-date-picker
                  :close-on-content-click="false"
                  :return-value.sync="date"
                  transition="scale-transition"
                  offset-y
                  range
                  min-width="290px"
                ></dea-date-picker>
              </v-col>
            </v-row>

            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Rating</dea-label>
              </v-col>
              <v-col class="d-flex" cols="4">
                <dea-rating v-model="rating"></dea-rating>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
    </article>
  </v-container>
</template>

<script>
import tab1 from './tabCont/tab1'
import tab2 from './tabCont/tab2'
import tab3 from './tabCont/tab3'

export default {
  name: 'CommonComponents',
  components: {
    tab1,
    tab2,
    tab3
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {
    model(val, prev) {
      if (val.length === prev.length) return
      this.model = val.map((v) => {
        if (typeof v === 'string') {
          v = {
            text: v,
            color: this.colors[this.nonce - 1]
          }
          this.comboItems.push(v)
          this.nonce++
        }
        return v
      })
    }
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // rating
      rating: 3,

      date: new Date().toISOString().substr(0, 10),

      showPanel: true,
      toggleBtn: null,

      type: 'number',
      time1: '',
      time2: '',
      number2: '',
      timeRules: {
        required: (value) => !!value || 'Required.',
        min: (v) => (v && v >= 0) || 'Min 00',
        max: (v) => (v && v <= 23) || 'Max 23'
      },

      icons: true,
      message: true,
      marker: true,
      items: ['강아지', '송아지', '망아지', '고양이'],
      select: null,
      select2: '강아지',
      select3: '고양이',
      fruits: [
        'Apples',
        'Apricots',
        'Avocado',
        'Bananas',
        'Blueberries',
        'Blackberries',
        'Boysenberries',
        'Bread fruit',
        'Cantaloupes (cantalope)',
        'Cherries',
        'Cranberries',
        'Cucumbers',
        'Currants',
        'Dates',
        'Eggplant',
        'Figs',
        'Grapes',
        'Grapefruit',
        'Guava'
      ],
      selectedFruits: [],

      // password
      show1: false,
      password: 'Password',
      rules: {
        required: (value) => !!value || 'Required.',
        min: (v) => (v && v.length >= 8) || 'Min 8 characters'
      },
      // checkbox & Radio
      checkbox: true,
      checkbox2: false,
      checkbox3: true,
      radios: 'radio-1',
      switch1: true,
      checkboxButton1: true,
      checkboxButton2: false,

      // combobox item close
      activator: null,
      attach: null,
      colors: ['green', 'purple', 'indigo', 'cyan', 'teal', 'orange'],
      editing: null,
      index: -1,
      comboItems: [
        // { header: 'Select an option or create one' },
        {
          text: 'Foo',
          color: 'blue'
        },
        {
          text: 'Bar',
          color: 'red'
        }
      ],
      nonce: 1,
      menu: false,
      comboModel: [],
      x: 0,
      search: null,
      y: 0,
      radioItems: [
        {
          label: 'Radio 1',
          value: 'radio-1'
        },
        {
          label: 'Radio 2',
          value: 'radio-2'
        }
      ],
      btnToggleItems: [
        {
          label: 'left',
          icon: 'mdi-format-align-left',
          text: '왼쪽 맞춤'
        },
        {
          label: 'center',
          icon: 'mdi-format-align-center',
          text: '가운데 맞춤'
        },
        {
          label: 'right',
          icon: 'mdi-format-align-right',
          text: '오른쪽 맞춤'
        },
        {
          label: 'justify',
          icon: 'mdi-format-align-justify',
          text: '양쪽 맞춤'
        }
      ],
      e1: 1,
      tab: 0,
      tabItems: [
        { name: '탭메뉴 1', content: 'Tab 1 Content' },
        { name: '탭메뉴 2', content: 'Tab 2 Content' },
        { name: '탭메뉴 3', content: 'Tab 3 Content' },
        { name: '탭메뉴 4', content: 'Tab 4 Content' },
        { name: '탭메뉴 5', content: 'Tab 5 Content' },
        { name: '탭메뉴 6', content: 'Tab 6 Content' },
        { name: '탭메뉴 7', content: 'Tab 7 Content' },
        { name: '탭메뉴 8', content: 'Tab 8 Content' },
        { name: '탭메뉴 9', content: 'Tab 9 Content' },
        { name: '탭메뉴 10', content: 'Tab 10 Content' },
        { name: '탭메뉴 11', content: 'Tab 11 Content' },
        { name: '탭메뉴 12', content: 'Tab 12 Content' },
        { name: '탭메뉴 13', content: 'Tab 13 Content' }
      ],
      tab2: 0,
      tab2Items: [
        { name: '탭메뉴 1', content: 'Tab 1 Content' },
        { name: '탭메뉴 2', content: 'Tab 2 Content' },
        { name: '탭메뉴 3', content: 'Tab 3 Content' }
      ],
      // tab menu
      tabSelected1: 1,
      tabItems1: [
        { name: '탭메뉴 1', component: 'tab1' },
        { name: '탭메뉴 2', component: 'tab2' },
        { name: '탭메뉴 3', component: 'tab3' }
      ],
      tabSelected2: 0,
      tabItems2: [
        { name: '탭메뉴 1', content: 'Tab 1 Content' },
        { name: '탭메뉴 2', content: 'Tab 2 Content' },
        { name: '탭메뉴 3', content: 'Tab 3 Content' }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    likesAllFruit() {
      return this.selectedFruits.length === this.fruits.length
    },
    likesSomeFruit() {
      return this.selectedFruits.length > 0 && !this.likesAllFruit
    },
    icon() {
      if (this.likesAllFruit) return 'mdi-close-box'
      if (this.likesSomeFruit) return 'mdi-minus-box'
      return 'mdi-checkbox-blank-outline'
    }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {},

    /** Function **/

    /** Event Handler **/
    changeIcon() {
      this.icons = !this.icons
    },
    toggleMarker() {
      this.marker = !this.marker
    },
    sendMessage() {
      this.message = !this.message
    },
    toggle() {
      this.$nextTick(() => {
        if (this.likesAllFruit) {
          this.selectedFruits = []
        } else {
          this.selectedFruits = this.fruits.slice()
        }
      })
    },

    eventPicker() {
      this.event = !this.event
    },

    // combobox item close
    edit(index, item) {
      if (!this.editing) {
        this.editing = item
        this.index = index
      } else {
        this.editing = null
        this.index = -1
      }
    },
    filter(item, queryText, itemText) {
      if (item.header) return false
      const hasValue = (val) => (val != null ? val : '')
      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return (
        text
          .toString()
          .toLowerCase()
          .indexOf(query.toString().toLowerCase()) > -1
      )
    },
    pInput(value) {
      console.log('p)input] value: ' + value + ', password: ' + this.password)
    },
    pChange(value) {
      console.log('p)change] value: ' + value + ', password: ' + this.password)
    }
  },
  beforeDestroy() {}
}
</script>
