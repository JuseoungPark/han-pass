<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-CALL-M0011, UI-ID-CALL-M0012</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button
              @click="sendCallCountCallTotal = !sendCallCountCallTotal"
              >발신건수 및 통화량</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                placeholder="인물선택"
                prepend-inner-icon="mdi-account-check-outline"
                styles="width:200px;"
                classes="flex-0"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>착발신구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="incomeSendCalls"
                row
                :mandatory="false"
                :items="incomeSendCallItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="통화"></dea-checkbox>
              <dea-checkbox label="메세지"></dea-checkbox>
              <dea-checkbox label="기타"></dea-checkbox>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner chart-wrap">
        <v-row no-gutters class="chart-top">
          <v-col class="d-flex d-block">
            <v-row no-gutters>
              <v-col class="d-flex align-right">
                <v-btn>차트변경</v-btn>
              </v-col>
            </v-row>
          </v-col>
        </v-row>
        <dea-card class="pa-0">
          차트
        </dea-card>
      </div>
    </section>

    <section class="dea-section" v-show="gridField">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-tabs class="dea-tabs">
                <v-tab>통화내역 (11)</v-tab>
              </v-tabs>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button
                  icon
                  fab
                  textindent
                  title="북마크"
                  prepend-icon="mdi-bookmark-multiple-outline"
                  bottom
                  >북마크</dea-button
                >
                <dea-button
                  icon
                  fab
                  textindent
                  title="제외"
                  prepend-icon="mdi-minus-circle-outline"
                  bottom
                  >제외</dea-button
                >
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 발신건수 및 통화량 : Layer Popup -->
    <dea-dialog
      v-model="sendCallCountCallTotal"
      title="발신건수 및 통화량"
      width="480px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card class="ba-0">
            <v-simple-table dense fixed-header>
              <template v-slot:default>
                <colgroup>
                  <col width="25%" />
                  <col width="25%" />
                  <col width="25%" />
                  <col width="25%" />
                </colgroup>
                <thead>
                  <tr>
                    <th>발신자</th>
                    <th>건수</th>
                    <th>통화량</th>
                    <th>내역보기</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>홍길동</td>
                    <td class="align-right">4</td>
                    <td>4:50</td>
                    <td>
                      <a
                        class="text-decoration-none"
                        @click="gridField = !gridField"
                        >자세히보기</a
                      >
                    </td>
                  </tr>
                  <tr>
                    <td>이순신</td>
                    <td class="align-right">50</td>
                    <td>15:00</td>
                    <td>
                      <a
                        class="text-decoration-none"
                        @click="gridField = !gridField"
                        >자세히보기</a
                      >
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="sendCallCountCallTotal = !sendCallCountCallTotal"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //발신건수 및 통화량 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template408',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,
      gridField: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      sendCallCountCallTotal: false,

      // In Modal Popup
      chartList: '',
      chartItems: [
        {
          type: 'Area Chart',
          icon: 'mdi-equalizer'
        },
        {
          type: 'Bar Chart',
          icon: 'mdi-elevation-rise'
        },
        {
          type: 'Bubble Chart',
          icon: 'mdi-circle-slice-7'
        }
      ],

      // Setting for Publishing
      incomeSendCalls: 'radio-1',
      incomeSendCallItems: [
        {
          label: '전체',
          value: 'radio-1'
        },
        {
          label: '착신',
          value: 'radio-2'
        },
        {
          label: '발신',
          value: 'radio-3'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
