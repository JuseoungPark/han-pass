<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-CALL-M0006, UI-ID-CALL-M0007, UI-ID-CALL-P0011
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="specialCallHistory = !specialCallHistory"
              >특이통화 착발신내역</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>조건선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <div class="text text-truncate">착신/발신 합이</div>
              <dea-text-field
                :clearable="false"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">건 이상</div>
              <div class="text">/</div>
              <div class="text text-truncate">착신/발신 차이가</div>
              <dea-text-field
                :clearable="false"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">% 이상인 전화번호</div>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="통화"></dea-checkbox>
              <dea-checkbox label="메세지"></dea-checkbox>
              <dea-checkbox label="기타"></dea-checkbox>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>통화특성 분석내역 (21)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>차트</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 특이통화 착발신내역 : Layer Popup -->
    <dea-dialog
      v-model="specialCallHistory"
      title="특이통화 착발신내역"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>통화내역정보</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">홍길동 010-1234-5678</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner grid-wrap">
          <dea-card>
            <dea-grid
              use-pagination
              :columns="gridInfo.callTotalHistory.columns"
            >
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>발신내역 (23)</v-tab>
                    <v-tab>착신내역 (##)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
              <template #header-right>
                <v-col class="d-flex align-right">
                  <dea-button
                    icon
                    fab
                    textindent
                    title="북마크"
                    prepend-icon="mdi-bookmark-multiple-outline"
                    bottom
                    >북마크</dea-button
                  >
                  <dea-button
                    icon
                    fab
                    textindent
                    title="제외"
                    prepend-icon="mdi-minus-circle-outline"
                    bottom
                    >제외</dea-button
                  >
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="specialCallHistory = !specialCallHistory"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //특이통화 착발신내역 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template404',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      specialCallHistory: false,

      // In Modal Popup
      chartList: '',
      chartItems: [
        {
          type: 'Area Chart',
          icon: 'mdi-equalizer'
        },
        {
          type: 'Bar Chart',
          icon: 'mdi-elevation-rise'
        },
        {
          type: 'Bubble Chart',
          icon: 'mdi-circle-slice-7'
        }
      ],

      // Setting for Publishing
      standardSelects: 'radio-1',
      standardSelectItems: [
        {
          label: '실사용자 기준',
          value: 'radio-1'
        },
        {
          label: '전화번호 기준',
          value: 'radio-2'
        }
      ],
      callDetails: 'radio-1',
      callDetailItems: [
        {
          label: '빈도',
          value: 'radio-1'
        },
        {
          label: '통화량',
          value: 'radio-2'
        }
      ],
      callStates: 'radio-1',
      callStateItems: [
        {
          label: '시간대별',
          value: 'radio-1'
        },
        {
          label: '요일별',
          value: 'radio-2'
        },
        {
          label: '일별',
          value: 'radio-3'
        },
        {
          label: '월별',
          value: 'radio-4'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
