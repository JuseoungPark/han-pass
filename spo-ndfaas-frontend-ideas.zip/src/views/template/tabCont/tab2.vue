<template>
  <div>tab2</div>
</template>

<script>
export default {}
</script>
