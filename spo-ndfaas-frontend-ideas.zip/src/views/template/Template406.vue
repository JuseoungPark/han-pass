<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-CALL-M0009, UI-ID-CALL-P0013, UI-ID-CALL-P0014,
          UI-ID-CALL-P0015
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="basePersonMoveHistory = !basePersonMoveHistory"
              >인물기준 기지국 이동내역</dea-button
            >
            <dea-button @click="baseSendCallHistory = !baseSendCallHistory"
              >기지국중심 발신기준 통화내역</dea-button
            >
            <dea-button @click="baseCallHistory = !baseCallHistory"
              >기지국기준 통화내역</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select label="발신자만"> </dea-select>
              <dea-text-field
                placeholder="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
              ></dea-text-field>
              <dea-select label="착신자만"> </dea-select>
              <dea-text-field
                placeholder="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>조건선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="3">
              <dea-radio-group
                v-model="conditionSelects"
                row
                :mandatory="false"
                :items="conditionSelectItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기지국</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                append-icon="mdi-map-marker-outline"
                placeholder="기지국 검색"
              />
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>정제주소</dea-label>
            </v-col>
            <v-col class="d-flex" cols="6">
              <dea-select placeholder="시,도 선택"></dea-select>
              <dea-select placeholder="시,군,구 선택"></dea-select>
              <dea-select placeholder="읍,면,동 선택"></dea-select>
              <dea-button icon prepend-icon="mdi-restore"></dea-button>
              <dea-checkbox label="목록에 표시"></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>주소보기</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="주소정제 성공"></dea-checkbox>
              <dea-checkbox label="주소정제 실패"></dea-checkbox>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>기지국 (11)</v-tab>
                </v-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 인물기준 기지국 이동내역 : Layer Popup -->
    <dea-dialog
      v-model="basePersonMoveHistory"
      title="인물기준 기지국 이동내역"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>실사용자 정보</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">홍길동 010-1234-5678</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner grid-wrap">
          <dea-card>
            <dea-grid
              use-pagination
              :columns="gridInfo.callTotalHistory.columns"
            >
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>인물기준 기지국 이동내역 (12)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="basePersonMoveHistory = !basePersonMoveHistory"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물기준 기지국 이동내역 : Layer Popup -->

    <!-- 기지국중심 발신기준 통화내역 : Layer Popup -->
    <dea-dialog
      v-model="baseSendCallHistory"
      title="기지국중심 발신기준 통화내역"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>기지국 정보</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">서울 종로구 종로1길 55 OO빌딩</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="divide pa-0 ba-0">
            <v-col cols="4">
              <dea-card>
                <dea-grid
                  use-pagination
                  :columns="gridInfo.callTotalHistory.columns"
                  disableAutoLoad
                >
                  <template #header-left>
                    <v-col class="d-flex">
                      <v-tabs class="dea-tabs">
                        <v-tab>인물기준 기지국 이동내역 (12)</v-tab>
                      </v-tabs>
                    </v-col>
                  </template>
                </dea-grid>
              </dea-card>
            </v-col>
            <v-col>
              <dea-card>
                <dea-grid
                  use-pagination
                  :columns="gridInfo.callTotalHistory.columns"
                ></dea-grid>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="baseSendCallHistory = !baseSendCallHistory"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //기지국중심 발신기준 통화내역 : Layer Popup -->

    <!-- 기지국기준 통화내역 : Layer Popup -->
    <dea-dialog
      v-model="baseCallHistory"
      title="기지국기준 통화내역"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>기지국 정보</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">서울 종로구 종로1길 55 OO빌딩</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <dea-grid
              use-pagination
              :columns="gridInfo.callTotalHistory.columns"
            >
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>기지국기준 총 통화내역 (12)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
              <template #header-right>
                <v-col class="d-flex align-right">
                  <dea-button
                    icon
                    fab
                    textindent
                    title="북마크"
                    prepend-icon="mdi-bookmark-multiple-outline"
                    bottom
                    >북마크</dea-button
                  >
                  <dea-button
                    icon
                    fab
                    textindent
                    title="제외"
                    prepend-icon="mdi-minus-circle-outline"
                    bottom
                    >제외</dea-button
                  >
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="baseCallHistory = !baseCallHistory"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //기지국기준 통화내역 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template406',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      basePersonMoveHistory: false,
      baseSendCallHistory: false,
      baseCallHistory: false,

      // In Modal Popup

      // Setting for Publishing
      conditionSelects: 'radio-1',
      conditionSelectItems: [
        {
          label: '기지국 중심',
          value: 'radio-1'
        },
        {
          label: '이동내역 중심',
          value: 'radio-2'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
