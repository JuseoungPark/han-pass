<template>
  <v-container class="dea-home">
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-HOME-M0001, UI-DF-COMM-P0001</div>
        <div>홈화면은 개발시 'DeaAppMain.vue' 파일이 로드되지 않아야 함.</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="caseSelect = !caseSelect">사건선택</dea-button>
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section search-field">
      <div class="search-box search-box-field">
        <dea-card class="mx-auto">
          <v-row no-gutters>
            <v-col class="d-flex flex-0">
              <v-layout class="dea-text-field ma-0">
                <v-menu
                  :disabled="disabled"
                  :absolute="absolute"
                  :open-on-hover="openOnHover"
                  :close-on-click="closeOnClick"
                  :close-on-content-click="closeOnContentClick"
                  :offset-x="offsetX"
                  :offset-y="offsetY"
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      dense
                      outlined
                      clearable
                      class="align-center"
                      placeholder="디지털증거분석결과를 검색합니다."
                      v-bind="attrs"
                      v-on="on"
                      style="width:500px;"
                    ></v-text-field>
                  </template>
                  <!-- 검색어 자동완성 : Layer Popup -->
                  <v-sheet class="dea-popup" style="width:100%;">
                    <v-container class="pa-4">
                      <section class="dea-section">
                        <div class="inner">
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <div class="text font-bold">
                                최근검색어
                              </div>
                            </v-col>
                            <v-col class="d-flex align-right">
                              <dea-button text outlined>전체삭제</dea-button>
                            </v-col>
                          </v-row>
                          <v-list dense>
                            <v-list-item-group v-model="searchList">
                              <v-list-item
                                v-for="(searchItem, i) in searchItems"
                                :key="i"
                              >
                                <v-list-item-content class="flex-row">
                                  <v-list-item-title
                                    v-text="searchItem.text"
                                  ></v-list-item-title>
                                  <v-list-item-subtitle
                                    class="align-right flex-0"
                                    style="width:150px;"
                                    v-text="searchItem.date"
                                  ></v-list-item-subtitle>
                                </v-list-item-content>
                                <v-list-item-action>
                                  <dea-button
                                    icon
                                    textindent
                                    prepend-icon="mdi-close"
                                    >삭제</dea-button
                                  >
                                </v-list-item-action>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                          <v-divider />
                          <v-row no-gutters>
                            <v-col class="d-flex align-right">
                              <dea-switch
                                inset
                                value
                                label="자동완성"
                                input-value="true"
                              ></dea-switch>
                            </v-col>
                          </v-row>
                        </div>
                      </section>
                    </v-container>
                  </v-sheet>
                  <!-- //검색어 자동완성 : Layer Popup -->
                </v-menu>
              </v-layout>
              <dea-button textindent prepend-icon="mdi-magnify">
                검색
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section status-field">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title" title-class="align-left"
            >디지털증거처리현황
            <v-layout class="v-toolbar valign-middle flex-0 ml-4">
              <div class="info-message">
                <strong>2020-10-12 19:03</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-layout>
          </template>
          <v-row>
            <v-col cols="3">
              <v-card class="dea-card-field active">
                <v-card-title
                  ><v-icon>mdi-phone-settings</v-icon>
                  통화내역
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field">
                <v-card-title
                  ><v-icon>mdi-cash-multiple</v-icon>
                  계좌내역
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field">
                <v-card-title
                  ><v-icon>mdi-account-cash</v-icon>
                  회계내역
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field nodata">
                <v-card-title>
                  <v-icon>mdi-dots-horizontal</v-icon>
                </v-card-title>
                <v-card-text class="primary--text"> </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field active">
                <v-card-title
                  ><v-icon>mdi-grain</v-icon>
                  비정형파일
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field">
                <v-card-title
                  ><v-icon>mdi-email</v-icon>
                  이메일
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field">
                <v-card-title
                  ><v-icon>mdi-cellphone-iphone</v-icon>
                  모바일
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
            <v-col cols="3">
              <v-card class="dea-card-field">
                <v-card-title
                  ><v-icon>mdi-lock</v-icon>
                  암호파일
                </v-card-title>
                <v-card-text class="primary--text">
                  1240K
                </v-card-text>
                <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn>
              </v-card>
            </v-col>
          </v-row>
          <template slot="actions">
            <v-row>
              <v-col cols="3">
                <dea-button>분석대상파일 업로드</dea-button>
              </v-col>
              <v-col cols="9">
                <v-btn block large color="primary">
                  디지털증거처리현황 자세히보기
                  <v-icon>mdi-plus</v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section quick-menu">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title">
            디지털증거 통합분석 <strong>Quick Menu</strong>
          </template>
          <v-row>
            <v-col cols="3">
              <v-btn block large color="primary">
                <v-icon>mdi-account-alert</v-icon>
                주요인물관리
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn block large>
                <v-icon>mdi-account-multiple</v-icon>
                인물중심분석
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn block large>
                <v-icon>mdi-clock-time-three-outline</v-icon>
                시간중심분석
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn block large>
                <v-icon>mdi-map-marker-radius</v-icon>
                위치중심분석
              </v-btn>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <!-- 사건선택 : Layer Popup -->
    <dea-dialog v-model="caseSelect" title="사건선택" width="900px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card class="side-btn-group">
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>기간조건</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-date-picker
                  :close-on-content-click="false"
                  transition="scale-transition"
                  offset-y
                  range
                  styles="width:200px;"
                  classes="flex-0"
                ></dea-date-picker>
              </v-col>
              <v-col cols="1">
                <dea-label>수사현황</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-checkbox label="전체"></dea-checkbox>
                <dea-checkbox label="진행" :value="true"></dea-checkbox>
                <dea-checkbox label="종료"></dea-checkbox>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>사건검색</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-select
                  label="사건조회조건"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field placeholder="수사관"></dea-text-field>
              </v-col>
            </v-row>
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-center">
                  <dea-button prepend-icon="mdi-magnify" color="primary">
                    조회
                  </dea-button>
                  <dea-button outlined prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <dea-grid :columns="gridInfo.callTotalHistory.columns">
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>사건목록 (3)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="caseSelect = !caseSelect"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //사건선택 : Layer Popup -->

    <v-snackbar
      v-model="snackbar"
      :timeout="-1"
      :value="true"
      absolute
      top
      centered
      color="pink"
      elevation="8"
    >
      선택한 사건의 서비스기간이 7일 남았습니다. 연장해주세요.
      <dea-button outlined>기간연장 바로가기</dea-button>
      <template v-slot:action="{ attrs }">
        <v-btn
          icon
          small
          class="dea-btn--textindent"
          v-bind="attrs"
          @click="snackbar = false"
        >
          <v-icon>mdi-close</v-icon>
          닫기
        </v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script>
// import DeaLabel from '../../components/common/DeaLabel.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template00',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,
      gridField: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      caseSelect: false,

      // In Modal Popup
      searchList: null,
      searchItems: [
        {
          text: '홍길동',
          date: '2020.10.06'
        },
        {
          text: '인천 횡령 사건',
          date: '2020.10.05'
        },
        {
          text: '사건번호2020교육203956',
          date: '2020.10.05'
        },
        {
          text: '박길동',
          date: '2020.10.04'
        }
      ],

      // Setting for Publishing
      snackbar: true,
      loader: null,
      loading: false
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
