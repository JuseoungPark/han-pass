<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-HOME-M0004</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>증거유형</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="회사/부서"></dea-checkbox>
              <dea-checkbox label="실사용자"></dea-checkbox>
              <dea-checkbox label="증거번호"></dea-checkbox>
            </v-col>
            <v-col cols="1">
              <dea-label>처리상태</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="처리중"></dea-checkbox>
              <dea-checkbox label="완료"></dea-checkbox>
              <dea-checkbox label="미등록"></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>검색</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                append-icon="mdi-magnify"
                placeholder="처리중인 파일은 검색되지 않으니, 처리상태 완료여부를 확인하신후 검색해주세요"
              ></dea-text-field>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>총 디지털증거수 (23)</v-tab>
                  <v-tab>완료 (22)</v-tab>
                  <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                      <v-tab v-bind="attrs" v-on="on">신규 (11)</v-tab>
                    </template>
                    <span>최근 1주일이내 처리된 디지털증거수</span>
                  </v-tooltip>

                  <v-tab>진행 (5)</v-tab>
                  <v-tab>미등록 (6)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>추출목록파일저장</dea-button>
                <dea-button color="primary">파일저장</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <v-snackbar
      v-model="snackbar"
      :timeout="-1"
      :value="true"
      absolute
      bottom
      color="primary"
      elevation="8"
    >
      다운로드가 예약되었습니다. 파일저장관리에서 확인해주세요.
    </v-snackbar>
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template02',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      callSpecGraph: false,

      // In Modal Popup

      // Setting for Publishing
      snackbar: true
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
