<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-BOMA-M0003
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner detail-view">
        <dea-card>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>등록자</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <div class="text">김수사관</div>
            </v-col>
            <v-col cols="1">
              <dea-label>등록일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">2020-11-10</div>
            </v-col>
            <v-col class="d-flex flex-0 align-right">
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <div
                    class="dea-color-picker"
                    :style="swatchStyle"
                    v-on="on"
                  />
                </template>
                <!-- 칼라픽커 : Layer Popup -->
                <v-sheet class="dea-popup">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <v-row justify="space-around">
                            <v-color-picker
                              v-model="pickerColor"
                              class="ma-2"
                              show-swatches
                            ></v-color-picker>
                          </v-row>
                        </dea-card>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //칼라픽커 : Layer Popup -->
              </v-menu>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex">
              <div class="text">사건A의 수사과정에서 정리한 중요 파일 내역</div>
            </v-col>
            <v-col class="d-flex flex-0 align-right">
              <dea-button icon prepend-icon="mdi-playlist-edit"></dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>북마크목록 (13)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <div class="text">이 폴더에서</div>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import CellButton from '@/components/grid/CellButton'

export default {
  name: 'Template702',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      bookmarkMgmt: false,
      newFolderSetting: false,

      // In Modal Popup
      newFolderCollapsible: false,
      searchConditions: '전체',
      searchConditionItems: ['전체'],
      folderLists: '',
      folderItems: [
        { text: '10월 23일' },
        { text: '사건1번의 증거모음' },
        { text: '박수사관 확인' },
        { text: '제목없음' }
      ],

      // Setting for Publishing
      pickerColor: '#1976d2ff',
      bookmarkFolder: '',
      bookmarkFolderItems: [
        { title: '폴더 제목 A', file: '13개 파일', colorStyle: '#ff0000ff' },
        { title: '폴더 제목 B', file: '5개 파일', colorStyle: '#ffc000ff' },
        { title: '폴더 제목 D', file: '2개 파일', colorStyle: '#00b050ff' },
        { title: '폴더 제목 F', file: '2개 파일', colorStyle: '#00b050ff' },
        { title: '폴더 제목 H', file: '13개 파일', colorStyle: '#ff0000ff' },
        { title: '폴더 제목 C', file: '2개 파일', colorStyle: '##ffff00ff' },
        { title: '폴더 제목 E', file: '2개 파일', colorStyle: '#00b0f0ff' },
        { title: '폴더 제목 G', file: '2개 파일', colorStyle: '#7030a0ff' }
      ],
      viewStateList: 'radio-1',
      viewStateItems: [
        {
          label: '목록형',
          value: 'radio-1'
        },
        {
          label: '빈도형',
          value: 'radio-2'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    swatchStyle() {
      const { pickerColor } = this
      return {
        backgroundColor: pickerColor,
        cursor: 'pointer',
        height: '32px',
        width: '32px'
      }
    }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
