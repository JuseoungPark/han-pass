<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-FDMA-M0001, UI-ID-FDMA-M0002
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>예약 다운로드 목록 (4)</v-tab>
                </v-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import CellButton from '@/components/grid/CellButton'

export default {
  name: 'Template701',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true

      // Modal Popup

      // In Modal Popup

      // Setting for Publishing
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
