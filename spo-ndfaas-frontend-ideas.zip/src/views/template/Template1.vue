<template>
  <v-container>
    <article>
      <section class="dea-section">
        <div class="search-box">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle>Stepper / Tabs</v-card-subtitle>
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Stepper</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-stepper v-model="e1">
                    <v-stepper-header>
                      <v-stepper-step :complete="e1 > 1" step="1"
                        >Name of step 1</v-stepper-step
                      >
                      <v-divider></v-divider>
                      <v-stepper-step :complete="e1 > 2" step="2"
                        >Name of step 2</v-stepper-step
                      >
                      <v-divider></v-divider>
                      <v-stepper-step :complete="e1 > 3" step="3"
                        >Name of step 3</v-stepper-step
                      >
                    </v-stepper-header>
                  </v-stepper>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Tabs</label></v-subheader>
                </v-col>
                <v-col class="d-flex overflow-x-hidden">
                  <v-tabs v-model="tab" class="dea-tabs">
                    <v-tab v-for="tabItem in tabItems" :key="tabItem.tab">
                      {{ tabItem.tab }}
                    </v-tab>
                  </v-tabs>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle
              >Textfield, Attach File, Textarea, Value</v-card-subtitle
            >
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Text fields</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-text-field
                    dense
                    outlined
                    class="flex-0"
                    style="width:200px"
                    label="사용자"
                    placeholder="이름을 입력하세요."
                    hint="상태메세지를 보여줍니다."
                    error
                  ></v-text-field>
                  <v-text-field
                    :rules="rules2"
                    dense
                    outlined
                    single-line
                    clearable
                    readonly
                    counter="12"
                    label="이메일(readonly)"
                    placeholder="이메일을 입력하세요."
                    value="focus가 들어갔다가 나올 때 error 상태로 변경됨"
                    hint="At least 6 characters"
                    persistent-hint
                  ></v-text-field>
                  <v-text-field
                    dense
                    outlined
                    disabled
                    label="전화번호(disabled)"
                    placeholder="전화번호를 입력하세요."
                    hint="상태메세지를 보여줍니다."
                  ></v-text-field>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Text fields(align)</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-text-field
                    dense
                    outlined
                    clearable
                    class="align-left"
                    label="정렬(Left)"
                    placeholder="입력하세요"
                    hint="상태메세지"
                  ></v-text-field>
                  <v-text-field
                    dense
                    outlined
                    clearable
                    class="align-center"
                    label="정렬(Center)"
                    placeholder="입력하세요"
                    hint="상태메세지"
                  ></v-text-field>
                  <v-text-field
                    dense
                    outlined
                    clearable
                    class="align-right"
                    label="정렬(Right)"
                    placeholder="입력하세요"
                    hint="상태메세지"
                  ></v-text-field>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Text fields(icon)</label></v-subheader>
                </v-col>
                <v-col class="d-flex" cols="5">
                  <v-text-field
                    dense
                    outlined
                    single-line
                    clearable
                    label="사용자"
                    placeholder="이름을 입력하세요."
                    hint="상태메세지를 보여줍니다."
                    :prepend-icon="
                      icons ? 'mdi-emoticon-happy' : 'mdi-emoticon-sad'
                    "
                    prepend-inner-icon="mdi-account-outline"
                    :append-icon="
                      marker ? 'mdi-map-marker' : 'mdi-map-marker-off'
                    "
                    :append-outer-icon="message ? 'mdi-send' : 'mdi-microphone'"
                    @click:prepend="icons = !icons"
                    @click:append="toggleMarker"
                    @click:append-outer="sendMessage"
                  ></v-text-field>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader
                    ><label>비밀번호 비밀번호를 바꾸자</label></v-subheader
                  >
                </v-col>
                <v-col class="d-flex" cols="5">
                  <v-text-field
                    v-model="password"
                    dense
                    outlined
                    clearable
                    label="비밀번호"
                    placeholder="비밀번호를 입력하세요."
                    :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                    :rules="[rules.required, rules.min]"
                    :type="show1 ? 'text' : 'password'"
                    hint="At least 8 characters"
                    counter="20"
                    @click:append="show1 = !show1"
                  ></v-text-field>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>File Inputs</label></v-subheader>
                </v-col>
                <v-col class="d-flex" cols="5">
                  <v-file-input
                    v-model="files"
                    dense
                    outlined
                    counter
                    label="Attach Single File"
                    placeholder="Select your files"
                    prepend-icon="mdi-plus"
                    :show-size="1000"
                  >
                  </v-file-input>
                </v-col>
                <v-col class="d-flex" cols="5">
                  <v-file-input
                    v-model="files2"
                    dense
                    outlined
                    single-line
                    counter
                    multiple
                    label="Attach Multi File"
                    placeholder="Select your files"
                    prepend-icon="mdi-plus"
                    append-outer-icon="mdi-paperclip"
                    :show-size="1000"
                  >
                    <template v-slot:selection="{ index, text }">
                      <v-chip v-if="index < 2" small>
                        {{ text }}
                      </v-chip>
                      <span v-else-if="index === 2" class="caption">
                        (+{{ files.length - 2 }} Files)
                      </span>
                    </template>
                  </v-file-input>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1" class="valign-top">
                  <v-subheader
                    ><label>Textareas (valign-top)</label></v-subheader
                  >
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-textarea
                        dense
                        outlined
                        single-line
                        label="상세설명"
                        placeholder="상세설명을 입력하세요."
                        hint="상태메세지를 보여줍니다."
                      ></v-textarea>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-textarea
                        dense
                        outlined
                        height="80px"
                        readonly
                        no-resize
                        label="상세설명(readonly)"
                        placeholder="상세설명을 입력하세요."
                        hint="상태메세지를 보여줍니다."
                        persistent-hint
                        value="가나다라마바사"
                      ></v-textarea>
                      <v-textarea
                        dense
                        outlined
                        height="80px"
                        disabled
                        no-resize
                        counter="100"
                        label="상세설명(disabled)"
                        placeholder="상세설명을 입력하세요."
                        hint="상태메세지를 보여줍니다."
                        value="가나다라마바사"
                      ></v-textarea>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Text</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <a href="#" class="text-decoration-none">
                    Non-underlined link
                  </a>
                  <div class="text-decoration-line-through">
                    Line-through text
                  </div>
                  <div class="text-decoration-overline">
                    Overline text
                  </div>
                  <div class="text-decoration-underline">
                    Underline text
                  </div>
                </v-col>
              </v-row>

              <v-expand-transition>
                <div v-show="showPanel">
                  <v-row no-gutters>
                    <v-col cols="1">
                      <v-subheader class="valign-top"
                        >Value (valign-top)</v-subheader
                      >
                    </v-col>
                    <v-col class="d-flex d-block">
                      <v-row no-gutters>
                        <v-col class="d-flex">
                          <v-text-field
                            dense
                            outlined
                            filled
                            readonly
                            label="이메일(readonly)"
                            placeholder="이메일을 입력하세요."
                            value="gildong794@gmail.com"
                          ></v-text-field>
                          <v-text-field
                            dense
                            single-line
                            outlined
                            filled
                            disabled
                            label="전화번호(disabled)"
                            placeholder="전화번호를 입력하세요."
                            value="010-1234-5678"
                          ></v-text-field>
                        </v-col>
                      </v-row>
                      <v-row no-gutters>
                        <v-col class="d-flex">
                          <v-textarea
                            dense
                            outlined
                            filled
                            no-resize
                            readonly
                            counter="100"
                            label="상세설명(readonly)"
                            placeholder="상세설명을 입력하세요."
                            hint="상태메세지를 보여줍니다."
                            value="가나다라마바사"
                          ></v-textarea>
                        </v-col>
                      </v-row>
                    </v-col>
                  </v-row>
                </div>
              </v-expand-transition>
            </v-card-text>
            <v-card-actions>
              <div class="btn-group">
                <v-col class="align-left">
                  <v-btn outlined class="white--bg" disabled>버튼</v-btn>
                </v-col>
                <v-col class="align-right">
                  <v-btn outlined class="white--bg">버튼2</v-btn>
                  <v-btn
                    outlined
                    class="white--bg"
                    @click="showPanel = !showPanel"
                    >{{
                      showPanel ? '검색조건 접기' : '검색조건 펼치기'
                    }}</v-btn
                  >
                </v-col>
              </div>
            </v-card-actions>
          </v-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle>Select, Combobox, Autocomplete</v-card-subtitle>
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Select</label></v-subheader>
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-select
                        :items="items"
                        dense
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        class="flex-0"
                        style="width:200px"
                        label="종류"
                        placeholder="종류를 선택하세요."
                        prepend-icon="mdi-city-variant-outline"
                        prepend-inner-icon="mdi-account-check-outline"
                        append-icon="mdi-account-plus-outline"
                        append-outer-icon="mdi-application-import"
                        @click:prepend="true"
                        @click:append-outer="true"
                      ></v-select>
                      <v-select
                        :items="items"
                        dense
                        single-line
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        multiple
                        small-chips
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite animal"
                        persistent-hint
                      ></v-select>
                      <v-select
                        v-model="select2"
                        :items="items"
                        dense
                        single-line
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        readonly
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-select>
                      <v-select
                        v-model="select3"
                        :items="items"
                        dense
                        single-line
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        disabled
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-select>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-select
                        v-model="select"
                        :items="items"
                        dense
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        multiple
                        label="종류"
                        placeholder="종류를 선택하세요."
                      >
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ select.length - 1 }} others)</span
                          >
                        </template>
                      </v-select>
                      <v-select
                        v-model="selectedFruits"
                        :items="fruits"
                        dense
                        single-line
                        outlined
                        :menu-props="{ bottom: true, offsetY: true }"
                        multiple
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite fruits"
                        persistent-hint
                      >
                        <template v-slot:prepend-item>
                          <v-list-item ripple @click="toggle">
                            <v-list-item-action>
                              <v-icon
                                :color="
                                  selectedFruits.length > 0
                                    ? 'indigo darken-4'
                                    : ''
                                "
                                >{{ icon }}</v-icon
                              >
                            </v-list-item-action>
                            <v-list-item-content>
                              <v-list-item-title>Select All</v-list-item-title>
                            </v-list-item-content>
                          </v-list-item>
                          <v-divider class="mt-2"></v-divider>
                        </template>
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ selectedFruits.length - 1 }} others)</span
                          >
                        </template>
                      </v-select>
                    </v-col>
                    <v-col class="d-flex"></v-col>
                  </v-row>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Autocompletes</label></v-subheader>
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-autocomplete
                        :items="items"
                        dense
                        outlined
                        class="flex-0"
                        style="width:200px"
                        label="종류"
                        placeholder="종류를 선택하세요."
                        prepend-icon="mdi-city-variant-outline"
                        prepend-inner-icon="mdi-account-check-outline"
                        append-icon="mdi-account-plus-outline"
                        append-outer-icon="mdi-application-import"
                        @click:prepend="true"
                        @click:append-outer="true"
                      ></v-autocomplete>
                      <v-autocomplete
                        :items="items"
                        dense
                        single-line
                        outlined
                        multiple
                        small-chips
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite animal"
                        persistent-hint
                      ></v-autocomplete>
                      <v-autocomplete
                        v-model="select2"
                        :items="items"
                        dense
                        single-line
                        outlined
                        readonly
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-autocomplete>
                      <v-autocomplete
                        v-model="select3"
                        :items="items"
                        dense
                        single-line
                        outlined
                        disabled
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-autocomplete>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-autocomplete
                        v-model="select"
                        :items="items"
                        dense
                        outlined
                        multiple
                        label="종류"
                        placeholder="종류를 선택하세요."
                      >
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ select.length - 1 }} others)</span
                          >
                        </template>
                      </v-autocomplete>
                      <v-autocomplete
                        v-model="selectedFruits"
                        :items="fruits"
                        dense
                        single-line
                        outlined
                        multiple
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite fruits"
                        persistent-hint
                      >
                        <template v-slot:prepend-item>
                          <v-list-item ripple @click="toggle">
                            <v-list-item-action>
                              <v-icon
                                :color="
                                  selectedFruits.length > 0
                                    ? 'indigo darken-4'
                                    : ''
                                "
                                >{{ icon }}</v-icon
                              >
                            </v-list-item-action>
                            <v-list-item-content>
                              <v-list-item-title>Select All</v-list-item-title>
                            </v-list-item-content>
                          </v-list-item>
                          <v-divider class="mt-2"></v-divider>
                        </template>
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ selectedFruits.length - 1 }} others)</span
                          >
                        </template>
                      </v-autocomplete>
                    </v-col>
                    <v-col class="d-flex"></v-col>
                  </v-row>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Combobox</label></v-subheader>
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-combobox
                        :items="items"
                        dense
                        outlined
                        class="flex-0"
                        style="width:200px"
                        label="종류"
                        placeholder="종류를 선택하세요."
                        prepend-icon="mdi-city-variant-outline"
                        prepend-inner-icon="mdi-account-check-outline"
                        append-icon="mdi-account-plus-outline"
                        append-outer-icon="mdi-application-import"
                        @click:prepend="true"
                        @click:append-outer="true"
                      ></v-combobox>
                      <v-combobox
                        :items="items"
                        dense
                        single-line
                        outlined
                        multiple
                        small-chips
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite animal"
                        persistent-hint
                      ></v-combobox>
                      <v-combobox
                        v-model="select2"
                        :items="items"
                        dense
                        single-line
                        outlined
                        readonly
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-combobox>
                      <v-combobox
                        v-model="select3"
                        :items="items"
                        dense
                        single-line
                        outlined
                        disabled
                        label="종류"
                        placeholder="종류를 선택하세요."
                      ></v-combobox>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-combobox
                        v-model="select"
                        :items="items"
                        dense
                        outlined
                        multiple
                        label="종류"
                      >
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ select.length - 1 }} others)</span
                          >
                        </template>
                      </v-combobox>
                      <v-combobox
                        v-model="selectedFruits"
                        :items="fruits"
                        dense
                        single-line
                        outlined
                        multiple
                        label="종류"
                        placeholder="종류를 선택하세요."
                        hint="Pick your favorite fruits"
                        persistent-hint
                      >
                        <template v-slot:prepend-item>
                          <v-list-item ripple @click="toggle">
                            <v-list-item-action>
                              <v-icon
                                :color="
                                  selectedFruits.length > 0
                                    ? 'indigo darken-4'
                                    : ''
                                "
                                >{{ icon }}</v-icon
                              >
                            </v-list-item-action>
                            <v-list-item-content>
                              <v-list-item-title>Select All</v-list-item-title>
                            </v-list-item-content>
                          </v-list-item>
                          <v-divider class="mt-2"></v-divider>
                        </template>
                        <template v-slot:selection="{ item, index }">
                          <v-chip v-if="index === 0" small>
                            <span>{{ item }}</span>
                          </v-chip>
                          <span v-if="index === 1" class="caption"
                            >(+{{ selectedFruits.length - 1 }} others)</span
                          >
                        </template>
                      </v-combobox>
                    </v-col>
                    <v-col class="d-flex">
                      <v-combobox
                        v-model="comboModel"
                        :filter="filter"
                        :hide-no-data="!search"
                        :items="comboItems"
                        :search-input.sync="search"
                        dense
                        outlined
                        multiple
                        small-chips
                        hide-selected
                        label="Search for an option"
                        placeholder="아이템별 제거"
                        hint="아이템별로 제거가 가능한 형식"
                        persistent-hint
                      >
                        <!-- <template v-slot:no-data>
                          <v-list-item>
                            <span class="subheading">Create</span>
                            <v-chip
                              small
                            >
                              {{ search }}
                            </v-chip>
                          </v-list-item>
                        </template> -->
                        <template
                          v-slot:selection="{ attrs, item, parent, selected }"
                        >
                          <v-chip
                            v-if="item === Object(item)"
                            v-bind="attrs"
                            :color="`${item.color} lighten-3`"
                            :input-value="selected"
                            small
                          >
                            <span>
                              {{ item.text }}
                            </span>
                            <v-icon small @click="parent.selectItem(item)"
                              >close</v-icon
                            >
                          </v-chip>
                        </template>
                        <template v-slot:item="{ index, item }">
                          <v-text-field
                            v-if="editing === item"
                            v-model="editing.text"
                            autofocus
                            flat
                            hide-details
                            single-line
                            @keyup.enter="edit(index, item)"
                          ></v-text-field>
                          <v-chip
                            v-else
                            :color="`${item.color} lighten-3`"
                            small
                          >
                            {{ item.text }}
                          </v-chip>
                          <v-spacer></v-spacer>
                          <v-list-item-action @click.stop>
                            <v-btn icon @click.stop.prevent="edit(index, item)">
                              <v-icon>{{
                                editing !== item ? 'mdi-pencil' : 'mdi-check'
                              }}</v-icon>
                            </v-btn>
                          </v-list-item-action>
                        </template>
                      </v-combobox>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="search-box">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle
              >Selelct Controls - Checkbox, Radio, Switch</v-card-subtitle
            >
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Checkbox</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-checkbox v-model="checkbox" label="체크박스"></v-checkbox>
                  <v-checkbox
                    v-model="checkbox2"
                    label="체크박스(readonly)"
                    readonly
                    hint="상세설명을 보여줍니다."
                    persistent-hint
                  ></v-checkbox>
                  <v-checkbox
                    v-model="checkbox3"
                    label="체크박스(disabled)"
                    disabled
                  ></v-checkbox>
                  <v-checkbox
                    input-value="true"
                    value
                    label="체크박스"
                    class="dea-btn--textindent"
                  ></v-checkbox>
                  <v-checkbox
                    value
                    label="체크박스"
                    class="dea-btn--textindent"
                  ></v-checkbox>
                  <v-checkbox
                    value
                    label="체크박스"
                    class="dea-btn--textindent"
                    indeterminate
                  ></v-checkbox>
                </v-col>
                <v-col cols="1">
                  <v-subheader
                    ><label>Checkbox<br />(버튼형)</label></v-subheader
                  >
                </v-col>
                <v-col class="d-flex" cols="3">
                  <v-checkbox
                    v-model="checkbox"
                    label="1"
                    class="dea-btn-checkbox"
                  ></v-checkbox>
                  <v-checkbox label="2" class="dea-btn-checkbox"></v-checkbox>
                  <v-checkbox
                    v-model="checkboxButton1"
                    :label="checkboxButton1 ? '선택' : '취소'"
                    class="dea-btn-checkbox"
                  ></v-checkbox>
                  <v-checkbox
                    v-model="checkboxButton2"
                    :label="checkboxButton2 ? '선택' : '취소'"
                    class="dea-btn-checkbox"
                  ></v-checkbox>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Radio</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-radio-group v-model="radios" row :mandatory="false">
                    <v-radio label="Radio 1" value="radio-1"></v-radio>
                    <v-radio label="Radio 2" value="radio-2"></v-radio>
                  </v-radio-group>
                  <v-radio-group
                    v-model="radios"
                    row
                    readonly
                    :mandatory="false"
                  >
                    <v-radio label="Radio 1" value="radio-1"></v-radio>
                    <v-radio label="Radio 2" value="radio-2"></v-radio>
                  </v-radio-group>
                  <v-radio-group
                    v-model="radios"
                    row
                    disabled
                    :mandatory="false"
                  >
                    <v-radio label="Radio 1" value="radio-1"></v-radio>
                    <v-radio label="Radio 2" value="radio-2"></v-radio>
                  </v-radio-group>
                </v-col>
                <v-col cols="1">
                  <v-subheader><label>Radio</label></v-subheader>
                </v-col>
                <v-col class="d-flex" cols="3">
                  <v-radio-group
                    v-model="radios"
                    row
                    :mandatory="false"
                    class="dea-btn-radio"
                  >
                    <v-radio label="Radio 1" value="radio-1"></v-radio>
                    <v-radio label="Radio 2" value="radio-2"></v-radio>
                  </v-radio-group>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Switch</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-switch v-model="switch1" label="Switch 1"></v-switch>
                  <v-switch label="Switch 2"></v-switch>
                  <v-switch
                    label="Switch(readonly)"
                    input-value="true"
                    readonly
                  ></v-switch>
                  <v-switch
                    label="Switch(disabled)"
                    input-value="true"
                    disabled
                  ></v-switch>
                  <v-switch value input-value="true"></v-switch>
                  <v-switch value></v-switch>
                  <v-switch
                    inset
                    value
                    label="Switch(inset)"
                    input-value="true"
                  ></v-switch>
                  <v-switch inset value label="Switch(inset)"></v-switch>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle
              >Button은 기본형으로 Gradient를 가짐</v-card-subtitle
            >
            <v-card-text>
              <div class="box-wrap">
                <v-row>
                  <v-col cols="1">
                    <v-subheader><label>Button</label></v-subheader>
                  </v-col>
                  <v-col class="d-flex d-block">
                    <v-row>
                      <v-col class="d-flex">
                        <v-btn color="primary">버튼</v-btn>
                        <v-btn color="primary">
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn>버튼</v-btn>
                        <v-btn>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn text>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn outlined>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn
                          icon
                          fab
                          color="primary"
                          class="dea-btn--textindent"
                        >
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn icon fab class="dea-btn--textindent">
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn icon class="dea-btn--textindent">
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn outlined icon class="dea-btn--textindent">
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn color="primary" class="gradient">
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col class="d-flex">
                        <v-btn color="primary" disabled>버튼</v-btn>
                        <v-btn color="primary" disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn disabled>버튼</v-btn>
                        <v-btn disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn text disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn outlined disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn
                          icon
                          fab
                          color="primary"
                          class="dea-btn--textindent"
                          disabled
                        >
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn icon fab class="dea-btn--textindent" disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn icon class="dea-btn--textindent" disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn
                          outlined
                          icon
                          class="dea-btn--textindent"
                          disabled
                        >
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                        <v-btn color="primary" class="gradient" disabled>
                          <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                        </v-btn>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </div>
              <v-row>
                <v-col cols="1">
                  <v-subheader><label>Toggle Button</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-btn-toggle
                    dense
                    mandatory
                    color="primary"
                    class="dea-btn--textindent"
                  >
                    <v-btn>
                      <v-icon>mdi-format-align-left</v-icon> 왼쪽 맞춤
                    </v-btn>
                    <v-btn>
                      <v-icon>mdi-format-align-center</v-icon> 가운데 맞춤
                    </v-btn>
                    <v-btn>
                      <v-icon>mdi-format-align-right</v-icon> 오른쪽 맞춤
                    </v-btn>
                    <v-btn>
                      <v-icon>mdi-format-align-justify</v-icon> 양쪽 맞춤
                    </v-btn>
                  </v-btn-toggle>
                  <v-btn-toggle dense>
                    <v-btn @click="toggleBtn = !toggleBtn">
                      <v-icon>mdi-arrow-expand-all</v-icon>
                      {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                    </v-btn>
                  </v-btn-toggle>
                  <v-btn-toggle
                    dense
                    mandatory
                    color="primary"
                    class="dea-btn--textindent"
                  >
                    <v-btn disabled>
                      <v-icon>mdi-format-align-left</v-icon> 왼쪽 맞춤
                    </v-btn>
                    <v-btn disabled>
                      <v-icon>mdi-format-align-center</v-icon> 가운데 맞춤
                    </v-btn>
                    <v-btn disabled>
                      <v-icon>mdi-format-align-right</v-icon> 오른쪽 맞춤
                    </v-btn>
                    <v-btn disabled>
                      <v-icon>mdi-format-align-justify</v-icon> 양쪽 맞춤
                    </v-btn>
                  </v-btn-toggle>
                  <v-btn-toggle dense>
                    <v-btn @click="toggleBtn = !toggleBtn" disabled>
                      <v-icon>mdi-arrow-expand-all</v-icon>
                      {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                    </v-btn>
                  </v-btn-toggle>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
        <div class="search-box">
          <v-card class="dea-card">
            <v-card-title>Components</v-card-title>
            <v-card-subtitle
              >Button(v-card__text안에 위치하는 경우엔 Gradient 제거됨) / Date
              Picker / Rating</v-card-subtitle
            >
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Button</label></v-subheader>
                </v-col>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn color="primary">버튼</v-btn>
                      <v-btn color="primary">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn>버튼</v-btn>
                      <v-btn>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn text>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn outlined>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn
                        icon
                        fab
                        color="primary"
                        class="dea-btn--textindent"
                      >
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn icon fab class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn icon class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn outlined icon class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn color="primary" class="gradient">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn color="primary" disabled>버튼</v-btn>
                      <v-btn color="primary" disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn disabled>버튼</v-btn>
                      <v-btn disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn text disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn outlined disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn
                        icon
                        fab
                        color="primary"
                        disabled
                        class="dea-btn--textindent"
                      >
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn icon fab disabled class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn icon disabled class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn outlined icon disabled class="dea-btn--textindent">
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                      <v-btn color="primary" class="gradient" disabled>
                        <v-icon>mdi-clipboard-edit-outline</v-icon> 버튼
                      </v-btn>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn color="secondary">Secondary</v-btn>
                      <v-btn color="success">Success</v-btn>
                      <v-btn color="info">Infomation</v-btn>
                      <v-btn color="warning">
                        <v-icon>mdi-alert-outline</v-icon> Warning
                      </v-btn>
                      <v-btn color="error">
                        <v-icon>mdi-alert-circle-outline</v-icon>
                        Error
                      </v-btn>
                      <v-btn icon fab color="info" class="dea-btn--textindent">
                        <v-icon>mdi-information-outline</v-icon>
                        Info</v-btn
                      >
                      <v-btn color="warning" icon class="dea-btn--textindent">
                        <v-icon>mdi-alert-outline</v-icon>
                        Warning</v-btn
                      >
                      <v-btn
                        color="error"
                        icon
                        outlined
                        class="dea-btn--textindent"
                      >
                        <v-icon>mdi-alert-circle-outline</v-icon>
                        Error</v-btn
                      >
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn color="secondary">Secondary</v-btn>
                      <v-btn text color="success">Success</v-btn>
                      <v-btn outlined color="info">Infomation</v-btn>
                      <v-btn text color="warning">
                        <v-icon>mdi-alert-outline</v-icon> Warning
                      </v-btn>
                      <v-btn color="error">
                        <v-icon>mdi-alert-circle-outline</v-icon> Error
                      </v-btn>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn color="secondary" disabled>Secondary</v-btn>
                      <v-btn text color="success" disabled>Success</v-btn>
                      <v-btn outlined color="info" disabled>Infomation</v-btn>
                      <v-btn text color="warning" disabled>
                        <v-icon>mdi-alert-outline</v-icon> Warning
                      </v-btn>
                      <v-btn color="error" disabled>
                        <v-icon>mdi-alert-circle-outline</v-icon> Error
                      </v-btn>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <v-btn-toggle
                        dense
                        mandatory
                        color="primary"
                        class="dea-btn--textindent"
                      >
                        <v-btn>
                          <v-icon>mdi-format-align-left</v-icon> 왼쪽 맞춤
                        </v-btn>
                        <v-btn>
                          <v-icon>mdi-format-align-center</v-icon> 가운데 맞춤
                        </v-btn>
                        <v-btn>
                          <v-icon>mdi-format-align-right</v-icon> 오른쪽 맞춤
                        </v-btn>
                        <v-btn>
                          <v-icon>mdi-format-align-justify</v-icon> 양쪽 맞춤
                        </v-btn>
                      </v-btn-toggle>
                      <v-btn-toggle dense>
                        <v-btn @click="toggleBtn = !toggleBtn">
                          <v-icon>mdi-arrow-expand-all</v-icon>
                          {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                        </v-btn>
                      </v-btn-toggle>
                      <v-btn-toggle
                        dense
                        mandatory
                        color="primary"
                        class="dea-btn--textindent"
                      >
                        <v-btn disabled>
                          <v-icon>mdi-format-align-left</v-icon> 왼쪽 맞춤
                        </v-btn>
                        <v-btn disabled>
                          <v-icon>mdi-format-align-center</v-icon> 가운데 맞춤
                        </v-btn>
                        <v-btn disabled>
                          <v-icon>mdi-format-align-right</v-icon> 오른쪽 맞춤
                        </v-btn>
                        <v-btn disabled>
                          <v-icon>mdi-format-align-justify</v-icon> 양쪽 맞춤
                        </v-btn>
                      </v-btn-toggle>
                      <v-btn-toggle dense>
                        <v-btn @click="toggleBtn = !toggleBtn" disabled>
                          <v-icon>mdi-arrow-expand-all</v-icon>
                          {{ toggleBtn ? 'Toggle Button' : 'Toggled Button' }}
                        </v-btn>
                      </v-btn-toggle>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Date Picker</label></v-subheader>
                </v-col>
                <v-col class="d-flex" cols="4">
                  <v-menu
                    ref="menu"
                    v-model="menu"
                    :close-on-content-click="false"
                    :return-value.sync="date"
                    transition="scale-transition"
                    offset-y
                    min-width="290px"
                  >
                    <template v-slot:activator="{ on, attrs }">
                      <v-layout class="dea-date-picker">
                        <v-text-field
                          v-model="date"
                          dense
                          outlined
                          single-line
                          label="Picker in menu"
                          v-bind="attrs"
                        ></v-text-field>
                        <v-btn text class="dea-btn--textindent">
                          <v-icon v-on="on">mdi-calendar-month</v-icon>
                          달력
                        </v-btn>
                      </v-layout>
                    </template>
                    <v-date-picker v-model="date" no-title scrollable>
                      <v-spacer></v-spacer>
                      <v-btn text color="primary" @click="menu = false"
                        >Cancel</v-btn
                      >
                      <v-btn text color="primary" @click="$refs.menu.save(date)"
                        >OK</v-btn
                      >
                    </v-date-picker>
                  </v-menu>
                </v-col>
                <v-col cols="1">
                  <v-subheader><label>Time Picker</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-text-field
                    v-if="type === 'number'"
                    v-model="number"
                    type="number"
                    :rules="[timeRules.required, timeRules.min]"
                    dense
                    outlined
                    label="Number"
                  ></v-text-field>
                  <span>~</span>
                  <v-text-field
                    v-if="type === 'number'"
                    v-model="number2"
                    type="number"
                    :rules="[timeRules.required, timeRules.min]"
                    dense
                    outlined
                    label="Number"
                  ></v-text-field>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Duration Date Picker</label></v-subheader>
                </v-col>
                <v-col class="d-flex" cols="4">
                  <v-menu
                    ref="menu2"
                    v-model="menu2"
                    :close-on-content-click="false"
                    :return-value.sync="date2"
                    transition="scale-transition"
                    offset-y
                    min-width="290px"
                  >
                    <template v-slot:activator="{ on, attrs }">
                      <v-layout class="dea-date-picker">
                        <v-text-field
                          v-model="date2RangeText"
                          dense
                          outlined
                          single-line
                          label="Picker in menu"
                          v-bind="attrs"
                        ></v-text-field>
                        <v-btn text class="dea-btn--textindent">
                          <v-icon v-on="on">mdi-calendar-month</v-icon>
                          달력
                        </v-btn>
                      </v-layout>
                    </template>
                    <v-date-picker v-model="date2" range no-title scrollable>
                      <v-spacer></v-spacer>
                      <v-btn text color="primary" @click="menu2 = false"
                        >Cancel</v-btn
                      >
                      <v-btn
                        text
                        color="primary"
                        @click="$refs.menu2.save(date2)"
                        >OK</v-btn
                      >
                    </v-date-picker>
                  </v-menu>
                </v-col>
              </v-row>

              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader><label>Rating</label></v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-rating v-model="rating"></v-rating>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </section>
    </article>
  </v-container>
</template>

<script>
export default {
  name: 'TemplateOne',
  components: {},
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {
    model(val, prev) {
      if (val.length === prev.length) return
      this.model = val.map((v) => {
        if (typeof v === 'string') {
          v = {
            text: v,
            color: this.colors[this.nonce - 1]
          }
          this.comboItems.push(v)
          this.nonce++
        }
        return v
      })
    }
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // breadcrump
      breadItems: [
        {
          text: 'Dashboard',
          disabled: true,
          href: 'breadcrumbs_dashboard'
        },
        {
          text: 'Link 1',
          disabled: true,
          href: 'breadcrumbs_link_1'
        },
        {
          text: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2'
        }
      ],

      // tab menu
      tab: null,
      tabItems: [
        { tab: '탭메뉴 1', content: 'Tab 1 Content' },
        { tab: '탭메뉴 2', content: 'Tab 2 Content' },
        { tab: '탭메뉴 3', content: 'Tab 3 Content' },
        { tab: '탭메뉴 4', content: 'Tab 4 Content' },
        { tab: '탭메뉴 5', content: 'Tab 5 Content' },
        { tab: '탭메뉴 6', content: 'Tab 6 Content' },
        { tab: '탭메뉴 7', content: 'Tab 7 Content' },
        { tab: '탭메뉴 8', content: 'Tab 8 Content' },
        { tab: '탭메뉴 9', content: 'Tab 9 Content' },
        { tab: '탭메뉴 10', content: 'Tab 10 Content' },
        { tab: '탭메뉴 11', content: 'Tab 11 Content' },
        { tab: '탭메뉴 12', content: 'Tab 12 Content' },
        { tab: '탭메뉴 13', content: 'Tab 13 Content' }
      ],

      // rating
      rating: 3,

      // stepper
      e1: 2,

      // spinner
      type: 'number',
      number: 9999,
      number2: '',
      timeRules: {
        required: (value) => !!value || 'Required.',
        min: (v) => v >= 5000 || 'Min 5000'
        // max: (value) => value <= 50000 || 'Max 50000'
      },

      // date: null,
      date: new Date().toISOString().substr(0, 10),
      menu: false,
      date2: ['2019-09-10', '2019-0920'],
      menu2: false,

      showPanel: true,
      toggleBtn: null,

      icons: true,
      message: true,
      marker: true,
      items: ['강아지', '송아지', '망아지', '고양이'],
      select: null,
      select2: '강아지',
      select3: '고양이',
      fruits: [
        'Apples',
        'Apricots',
        'Avocado',
        'Bananas',
        'Blueberries',
        'Blackberries',
        'Boysenberries',
        'Bread fruit',
        'Cantaloupes (cantalope)',
        'Cherries',
        'Cranberries',
        'Cucumbers',
        'Currants',
        'Dates',
        'Eggplant',
        'Figs',
        'Grapes',
        'Grapefruit',
        'Guava'
      ],
      selectedFruits: [],
      files: [],
      files2: [],

      // password
      show1: false,
      password: 'Password',
      rules: {
        required: (value) => !!value || 'Required.',
        min: (v) => v.length >= 8 || 'Min 8 characters'
      },
      rules2: [(v) => v.length <= 12 || 'Max 12 characters'],
      // checkbox & Radio
      checkbox: true,
      checkbox2: false,
      checkbox3: true,
      radios: 'radio-1',
      switch1: true,
      checkboxButton1: true,
      checkboxButton2: false,

      // combobox item close
      activator: null,
      attach: null,
      colors: ['green', 'purple', 'indigo', 'cyan', 'teal', 'orange'],
      editing: false,
      index: -1,
      comboItems: [
        // { header: 'Select an option or create one' },
        {
          text: 'Foo',
          color: 'blue'
        },
        {
          text: 'Bar',
          color: 'red'
        }
      ],
      nonce: 1,
      comboModel: [],
      x: 0,
      search: null,
      y: 0
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    likesAllFruit() {
      return this.selectedFruits.length === this.fruits.length
    },
    likesSomeFruit() {
      return this.selectedFruits.length > 0 && !this.likesAllFruit
    },
    icon() {
      if (this.likesAllFruit) return 'mdi-close-box'
      if (this.likesSomeFruit) return 'mdi-minus-box'
      return 'mdi-checkbox-blank-outline'
    },
    date2RangeText() {
      return this.date2.join(' ~ ')
    }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {},

    /** Function **/

    /** Event Handler **/
    // changeIcon() {
    //   this.icons = !this.icons
    // },
    toggleMarker() {
      this.marker = !this.marker
    },
    sendMessage() {
      this.message = !this.message
    },
    toggle() {
      this.$nextTick(() => {
        if (this.likesAllFruit) {
          this.selectedFruits = []
        } else {
          this.selectedFruits = this.fruits.slice()
        }
      })
    },

    // combobox item close
    edit(index, item) {
      if (!this.editing) {
        this.editing = item
        this.index = index
      } else {
        this.editing = null
        this.index = -1
      }
    },
    filter(item, queryText, itemText) {
      if (item.header) return false
      const hasValue = (val) => (val != null ? val : '')
      const text = hasValue(itemText)
      const query = hasValue(queryText)

      return (
        text
          .toString()
          .toLowerCase()
          .indexOf(query.toString().toLowerCase()) > -1
      )
    }
  },
  beforeDestroy() {}
}
</script>
