<template>
  <v-container>
    <v-row>
      <v-col cols="1" />
      <v-col cols="10">
        <section class="dea-section">
          <div class="search-box">
            <dea-card>
              <dea-highcharts-master-detail />
            </dea-card>
          </div>
        </section>
      </v-col>
      <v-col cols="1" />
    </v-row>
    <v-row>
      <v-col cols="1" />
      <v-col cols="4">
        <section class="dea-section">
          <div class="search-box">
            <dea-card>
              <dea-highcharts json-file="dependencyWheelChart.json" />
            </dea-card>
          </div>
        </section>
      </v-col>
      <v-col cols="1" />
      <v-col cols="5">
        <section class="dea-section">
          <div class="search-box">
            <dea-card>
              <dea-highcharts json-file="networkgraphChart.json" />
            </dea-card>
          </div>
        </section>
      </v-col>
      <v-col cols="1" />
    </v-row>
  </v-container>
</template>

<script>
import DeaHighcharts from '@/components/charts/DeaHighcharts'
import DeaHighchartsMasterDetail from '@/components/charts/DeaHighchartsMasterDetail'

export default {
  name: 'HighchartsSample',
  components: {
    DeaHighcharts,
    DeaHighchartsMasterDetail
  }
}
</script>
