<template>
  <v-container class="fill-height" fluid>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-DF-INTR-M0001
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <v-row no-gutters align="center" justify="center" class="dea-login">
      <v-col cols="12" class="d-flex align-center">
        <section class="dea-section">
          <div class="inner">
            <dea-card>
              <template slot="title">로그인</template>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>아이디</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-text-field
                    placeholder="아이디를 입력하세요"
                  ></dea-text-field>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>비밀번호</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-text-field
                    placeholder="패스워드를 입력하세요"
                  ></dea-text-field>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-checkbox
                    v-model="checkbox"
                    label="아이디/비밀번호 기억하기"
                  ></dea-checkbox>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-button color="primary">로그인</dea-button>
                </v-col>
              </v-row>
              <template slot="actions">
                <div class="btn-group">
                  <v-row>
                    <v-col class="d-flex align-center">
                      <dea-button text small @click="idSearch = !idSearch"
                        >아이디찾기</dea-button
                      >
                      <v-divider vertical class="ma-0" />
                      <dea-button text small @click="systemPopup = !systemPopup"
                        >비밀번호 재발급</dea-button
                      >
                    </v-col>
                  </v-row>
                </div>
              </template>
            </dea-card>
          </div>
        </section>
      </v-col>
    </v-row>

    <!-- 아이디찾기 : Layer Popup -->
    <dea-dialog v-model="idSearch" title="아이디찾기" width="640px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>소속기관</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="소속기관을 입력하세요"
                ></dea-text-field>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>부서</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="부서명을 입력하세요"
                ></dea-text-field>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>이름</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="이름을 입력하세요"
                ></dea-text-field>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>핸드폰</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field label="국번"></dea-text-field>
                <dea-text-field label="앞자리"></dea-text-field>
                <dea-text-field label="뒷자리"></dea-text-field>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="idSearch = !idSearch">닫기</dea-button>
          <dea-button color="primary">찾기</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //아이디찾기 : Layer Popup -->

    <!-- 비밀번호 재발급 : Layer Popup -->
    <dea-confirm
      v-model="systemPopup"
      message="비밀번호 재발급은 기관 관리자에게 요청하시기 바랍니다."
      @ok="doOK"
      @doCancle="doCancle"
      alert
    />
    <!-- //비밀번호 재발급 : Layer Popup -->
  </v-container>
</template>

<script>
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaTextarea from '../../components/common/DeaTextarea.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup' // 두줄 헤더일 때

export default {
  name: 'Template101',
  components: {
    // DeaTextare,
    // DeaTextFielda
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        relatedPerson: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,
      checkbox: true,

      // Modal Popup
      idSearch: false,
      systemPopup: false,
      doOK: false,
      doCancle: false

      // Setting for Publishing
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  created() {},
  computed: {},
  mounted() {},
  methods: {}
}
</script>
