<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-BOMA-M0001, UI-ID-BOMA-P0001, UI-ID-BOMA-M0002
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="bookmarkMgmt = !bookmarkMgmt"
              >북마크관리</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="통화"></dea-checkbox>
              <dea-checkbox label="계좌"></dea-checkbox>
              <dea-checkbox label="이메일"></dea-checkbox>
              <dea-checkbox label="모바일"></dea-checkbox>
              <dea-checkbox label="파일"></dea-checkbox>
              <dea-checkbox label="회계"></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>검색</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="searchConditions"
                :items="searchConditionItems"
                style="width:200px;"
                class="flex-0"
              ></dea-select>
              <dea-text-field label="검색어를 입력하세요"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>북마크목록 (32)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>북마크관리</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <section class="dea-section total-bookmark-folder">
      <div class="inner list-wrap">
        <v-row no-gutters class="list-top">
          <v-col class="d-flex">
            <v-tabs class="dea-tabs">
              <v-tab>북마크폴더 (9)</v-tab>
            </v-tabs>
          </v-col>
          <v-col class="d-flex align-right">
            <dea-button>보고서생성</dea-button>
          </v-col>
        </v-row>
        <div class="divide">
          <v-col cols="2">
            <v-list dense>
              <v-list-item-group>
                <v-list-item>
                  <v-list-item-content>
                    <v-list-item-title class="align-center"
                      >미분류</v-list-item-title
                    >
                    <v-list-item-subtitle class="align-center"
                      >54개의 파일</v-list-item-subtitle
                    >
                  </v-list-item-content>
                </v-list-item>
                <v-list-item color="primary">
                  <v-list-item-content>
                    <v-list-item-icon class="align-center">
                      <v-icon>mdi-flag-variant</v-icon>
                    </v-list-item-icon>
                    <v-list-item-title class="align-center"
                      >중요파일</v-list-item-title
                    >
                    <v-list-item-subtitle class="align-center"
                      >(5개 파일)</v-list-item-subtitle
                    >
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-col>
          <v-col>
            <v-list dense>
              <v-list-item-group
                v-model="bookmarkFolder"
                class="flex-row flex-wrap"
              >
                <v-list-item
                  v-for="(bookmarkFolderItem, i) in bookmarkFolderItems"
                  :key="i"
                >
                  <v-list-item-content>
                    <v-list-item-icon>
                      <v-icon :style="'color:' + bookmarkFolderItem.colorStyle"
                        >mdi-label</v-icon
                      >
                    </v-list-item-icon>
                    <v-list-item-title class="align-center">
                      {{ bookmarkFolderItem.title }}
                    </v-list-item-title>
                    <v-list-item-subtitle class="align-center">
                      {{ bookmarkFolderItem.file }}
                    </v-list-item-subtitle>
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-col>
        </div>
      </div>
    </section>

    <!-- 북마크관리 : Layer Popup -->
    <dea-dialog v-model="bookmarkMgmt" title="북마크관리" width="900px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <section class="dea-section">
              <div class="inner">
                <dea-card title-class="title-align">
                  <template slot="title">내역정보</template>
                  <dea-grid :columns="gridInfo.callTotalHistory.columns">
                    <template #header-right>
                      <v-col class="d-flex align-right">
                        <dea-button>북마크해제</dea-button>
                      </v-col>
                    </template>
                  </dea-grid>
                </dea-card>
              </div>
            </section>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <template slot="title">폴더설정</template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>미분류</dea-label>
              </v-col>
              <v-col class="d-flex">
                <v-menu
                  :disabled="disabled"
                  :absolute="absolute"
                  :open-on-hover="openOnHover"
                  :close-on-click="closeOnClick"
                  :close-on-content-click="closeOnContentClick"
                  :offset-x="offsetX"
                  :offset-y="offsetY"
                >
                  <template v-slot:activator="{ on }">
                    <v-btn v-on="on">폴더변경</v-btn>
                  </template>
                  <!-- Context Menu : Layer Popup -->
                  <v-sheet class="dea-popup" style="width:180px;">
                    <v-container class="pa-0">
                      <section class="dea-section">
                        <div class="inner">
                          <v-list dense v-model="folderLists">
                            <v-list-item-group>
                              <template v-for="(foldertItem, i) in folderItems">
                                <v-list-item :key="i">
                                  <v-list-item-content>
                                    <v-list-item-title>
                                      {{ foldertItem.text }}
                                    </v-list-item-title>
                                  </v-list-item-content>
                                </v-list-item>
                              </template>
                            </v-list-item-group>
                          </v-list>
                        </div>
                      </section>
                    </v-container>
                  </v-sheet>
                  <!-- //Context Menu : Layer Popup -->
                </v-menu>
                <dea-button
                  @click="newFolderCollapsible = !newFolderCollapsible"
                  >새로운 폴더</dea-button
                >
              </v-col>
            </v-row>
            <v-row no-gutters v-show="newFolderCollapsible">
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>폴더명</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="제목을 입력하세요"
                    ></dea-text-field>
                    <v-menu
                      :disabled="disabled"
                      :absolute="absolute"
                      :open-on-hover="openOnHover"
                      :close-on-click="closeOnClick"
                      :close-on-content-click="closeOnContentClick"
                      :offset-x="offsetX"
                      :offset-y="offsetY"
                    >
                      <template v-slot:activator="{ on }">
                        <div
                          class="dea-color-picker"
                          :style="swatchStyle"
                          v-on="on"
                        ></div>
                      </template>
                      <!-- 칼라픽커 : Layer Popup -->
                      <v-sheet class="dea-popup">
                        <v-container class="pa-4">
                          <section class="dea-section">
                            <div class="inner">
                              <dea-card>
                                <v-row justify="space-around">
                                  <v-color-picker
                                    v-model="pickerColor"
                                    class="ma-2"
                                    show-swatches
                                  ></v-color-picker>
                                </v-row>
                              </dea-card>
                            </div>
                          </section>
                        </v-container>
                      </v-sheet>
                      <!-- //칼라픽커 : Layer Popup -->
                    </v-menu>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>등록</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">김수사관 2020/10/23 14:00</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>비고</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field placeholder="비고"></dea-text-field>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <section class="dea-section">
              <div class="inner">
                <dea-card title-class="title-align">
                  <template slot="title">변경이력</template>
                  <dea-grid :columns="gridInfo.callTotalHistory.columns">
                  </dea-grid>
                </dea-card>
              </div>
            </section>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="bookmarkMgmt = !bookmarkMgmt"
            >취소</dea-button
          >
          <dea-button color="primary" @click="bookmarkMgmt = !bookmarkMgmt"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //북마크관리 : Layer Popup -->
  </v-container>
</template>

<script>
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import CellButton from '@/components/grid/CellButton'

export default {
  name: 'Template701',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      bookmarkMgmt: false,
      newFolderSetting: false,

      // In Modal Popup
      pickerColor: '#1976d2ff',
      newFolderCollapsible: false,
      searchConditions: '전체',
      searchConditionItems: ['전체'],
      folderLists: '',
      folderItems: [
        { text: '10월 23일' },
        { text: '사건1번의 증거모음' },
        { text: '박수사관 확인' },
        { text: '제목없음' }
      ],

      // Setting for Publishing
      bookmarkFolder: '',
      bookmarkFolderItems: [
        { title: '폴더 제목 A', file: '13개 파일', colorStyle: '#ff0000ff' },
        { title: '폴더 제목 B', file: '5개 파일', colorStyle: '#ffc000ff' },
        { title: '폴더 제목 D', file: '2개 파일', colorStyle: '#00b050ff' },
        { title: '폴더 제목 F', file: '2개 파일', colorStyle: '#00b050ff' },
        { title: '폴더 제목 H', file: '13개 파일', colorStyle: '#ff0000ff' },
        { title: '폴더 제목 C', file: '2개 파일', colorStyle: '##ffff00ff' },
        { title: '폴더 제목 E', file: '2개 파일', colorStyle: '#00b0f0ff' },
        { title: '폴더 제목 G', file: '2개 파일', colorStyle: '#7030a0ff' }
      ],
      viewStateList: 'radio-1',
      viewStateItems: [
        {
          label: '목록형',
          value: 'radio-1'
        },
        {
          label: '빈도형',
          value: 'radio-2'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    swatchStyle() {
      const { pickerColor } = this
      return {
        backgroundColor: pickerColor,
        cursor: 'pointer',
        height: '32px',
        width: '32px'
      }
    }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
