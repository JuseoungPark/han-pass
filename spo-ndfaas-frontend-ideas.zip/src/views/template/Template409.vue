<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-CALL-M0014, UI-ID-CALL-P0016</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="callHistoryReload = !callHistoryReload"
              >통화내역제외 복원</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>전화번호</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                placeholder="전화번호를 입력하세요"
              ></dea-text-field>
              <dea-select
                label="통신사"
                style="width:30%;"
                class="flex-0"
              ></dea-select>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>제외자</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                placeholder="제외자를 입력하세요"
                prepend-inner-icon="mdi-account-check-outline"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>제외일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
              ></dea-date-picker>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-tabs class="dea-tabs">
                <v-tab>제외내역(14)</v-tab>
              </v-tabs>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>복원</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 통화내역제외 복원 : Layer Popup -->
    <dea-dialog
      v-model="callHistoryReload"
      title="통화내역제외 복원"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                선택한 3개의 통화 내역을 제외에서 복원합니다
              </div>
            </v-col>
          </v-row>
          <dea-card>
            <dea-grid :columns="gridInfo.grpPersonList.columns"></dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="callHistoryReload = !callHistoryReload"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //통화내역제외 복원 : Layer Popup -->
  </v-container>
</template>

<script>
// import DeaGrid from '../../components/common/DeaGrid.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import DeaSelect from '../../components/common/DeaSelect.vue'

export default {
  name: 'Template409',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        },
        grpPersonList: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      callHistoryReload: false

      // In Modal Popup

      // Setting for Publishing
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
