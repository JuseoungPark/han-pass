<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-CHAN-M0001, UI-ID-CHAN-P0001, UI-ID-CHAN-P0002,
          UI-ID-CHAN-P0003
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <v-menu
              :disabled="disabled"
              :absolute="absolute"
              :open-on-hover="openOnHover"
              :close-on-click="closeOnClick"
              :close-on-content-click="closeOnContentClick"
              :offset-x="offsetX"
              :offset-y="offsetY"
            >
              <template v-slot:activator="{ on }">
                <v-btn v-on="on">Context Menu</v-btn>
              </template>
              <!-- Context Menu : Layer Popup -->
              <v-sheet class="dea-popup" style="width:180px;">
                <v-container class="pa-0">
                  <section class="dea-section">
                    <div class="inner">
                      <v-list dense v-model="contextList">
                        <v-list-item-group>
                          <template v-for="(contextItem, i) in contextItems">
                            <v-list-item :key="i">
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col
                                      class="d-flex align-center valign-middle"
                                    >
                                      {{ contextItem.text }}
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-divider
                              v-if="i + 1 < contextItems.length"
                              :key="i"
                              class="ma-0"
                            ></v-divider>
                          </template>
                        </v-list-item-group>
                      </v-list>
                    </div>
                  </section>
                </v-container>
              </v-sheet>
              <!-- //Context Menu : Layer Popup -->
            </v-menu>
            <dea-button @click="personSelect = !personSelect"
              >인물선택</dea-button
            >
            <dea-button @click="nodeGrpMgmt = !nodeGrpMgmt"
              >상관도 노드그룹관리</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">화면저장</v-btn>
                </template>
                <!-- 화면저장 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:240px;">
                  <v-container class="pa-0">
                    <section class="dea-section">
                      <div class="inner">
                        <v-list dense>
                          <v-list-item-group>
                            <v-list-item>
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col class="d-flex valign-middle">
                                      화면을 PC에 저장
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-list-item>
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col class="d-flex valign-middle">
                                      저장화면 불러오기
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장 : Layer Popup -->
              </v-menu>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-col>
            <v-col class="d-flex align-center">
              <dea-select
                label="대상인물"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <dea-select
                label="공통노드"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <dea-select
                label="노드그룹"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">
                    <v-icon>mdi-magnify</v-icon>
                    인물찾기
                  </v-btn>
                </template>
                <!-- 화면저장 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:400px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <dea-text-field
                              placeholder="분석하고자 하는 인물을 검색하세요"
                              append-icon="mdi-magnify"
                            ></dea-text-field>
                          </v-col>
                        </v-row>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장 : Layer Popup -->
              </v-menu>
            </v-col>
            <v-col class="d-flex align-right">
              <dea-select
                label="보기설정"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on" color="primary">분석설정</v-btn>
                </template>
                <!-- 분석설정 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:380px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <template slot="title">매체설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-checkbox
                                v-model="checkbox1"
                                label="통화"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                              <dea-checkbox
                                label="계좌"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                              <dea-checkbox
                                label="이메일"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">기간설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="요일"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="dayList"
                                v-for="(dayItem, i) in dayItems"
                                :key="i"
                                :label="dayItem.day"
                                class="dea-btn-checkbox"
                                style="width:36px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="새벽"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="timeList"
                                v-for="(timeItem, i) in timeItems"
                                :key="i"
                                :label="timeItem.time"
                                class="dea-btn-checkbox"
                                style="width:40px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">인물설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-text-field
                                placeholder="인물을 검색하세요"
                                prepend-inner-icon="mdi-account-check-outline"
                                append-icon="mdi-magnify"
                              ></dea-text-field>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">그외 조건</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <v-tabs class="dea-tabs">
                                <v-tab>통화</v-tab>
                              </v-tabs>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1">
                              <dea-label>빈도</dea-label>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-text-field></dea-text-field>
                              <div class="text">~</div>
                              <dea-text-field></dea-text-field>
                              <div class="text text-nowrap">(단위:건))</div>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1">
                              <dea-label>빈도</dea-label>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-text-field></dea-text-field>
                              <div class="text">~</div>
                              <dea-text-field></dea-text-field>
                              <div class="text text-nowrap">
                                (단위:건))
                              </div>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>닫기</dea-button>
                          <dea-button
                            prepend-icon="mdi-magnify"
                            color="primary"
                          >
                            조회
                          </dea-button>
                          <dea-button outlined prepend-icon="mdi-restore">
                            초기화
                          </dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //분석설정 : Layer Popup -->
              </v-menu>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner chart-wrap">
        <dea-card class="pa-0">차트</dea-card>
      </div>
    </section>

    <!-- 인물 선택 : Layer Popup -->
    <dea-dialog v-model="personSelect" title="인물 선택" width="800px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="radio2s"
                  row
                  :mandatory="false"
                  :items="radio2Items"
                ></dea-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  v-model="select2Lists"
                  :items="select2Items"
                  label="그룹선택"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field
                  placeholder="인물을 검색하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>검색결과 (12)</v-tab>
                  </v-tabs>
                  <div class="text text-nowrap">
                    인물을 선택해주세요.
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleLeftModel" multiple>
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="'shuttleLeftItem' + i"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleLeftItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                outlined
                textindent
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                >우측으로 이동</dea-button
              >
              <dea-button
                icon
                outlined
                textindent
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                >좌측으로 이동</dea-button
              >
            </v-col>
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text" v-show="shuttleRightItems.length">
                    선택된 인물(2)
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleRightModel" multiple>
                    <template
                      v-for="(shuttleRightItem, i) in shuttleRightItems"
                    >
                      <v-list-item
                        :key="'shuttleRightItem' + i"
                        :value="shuttleRightItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleRightItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleRightItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personSelect = !personSelect"
            >취소</dea-button
          >
          <dea-button color="primary" @click="personSelect = !personSelect"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물 선택 : Layer Popup -->

    <!-- 상관도 노드그룹관리 : Layer Popup -->
    <dea-dialog v-model="nodeGrpMgmt" title="상관도 노드그룹관리" width="800px">
      <v-layout class="divide pa-0 ba-0">
        <v-col cols="5">
          <v-tabs class="dea-tabs" vertical>
            <v-tab class="align-left">
              <span>노드1 그룹(13명)</span>
              <dea-button icon textindent outlined prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>노드2 그룹(2명)</span>
              <dea-button icon textindent outlined prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>노드3 그룹(10명)</span>
              <dea-button icon textindent outlined prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>노드4 그룹(200명)</span>
              <dea-button icon textindent outlined prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
          </v-tabs>
          <section class="dea-section">
            <div class="inner"></div>
            <v-row no-gutters>
              <v-col class="d-flex position-relative">
                <!-- <v-snackbar
                  :timeout="-1"
                  :value="true"
                  absolute
                  centered
                  top
                  rounded
                  elevation="0"
                  color="info"
                  class="d-flex"
                >
                  <v-icon class="mr-2">mdi-check-bold</v-icon>
                  <div class="text word-break">
                    그룹을 삭제하면 해당 그룹으로 등록된 인물의 그룹 정보가
                    초기화됩니다.
                  </div>
                </v-snackbar> -->
              </v-col>
            </v-row>
          </section>
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="신규 추가할 그룹명을 입력하세요"
                    ></dea-text-field>
                    <dea-button>추가</dea-button>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
          </section>
        </v-col>
        <v-col>
          <section class="dea-section">
            <div class="inner grid-wrap">
              <dea-card>
                <dea-grid :columns="gridInfo.grpInfoView.columns"></dea-grid>
              </dea-card>
            </div>
          </section>
        </v-col>
      </v-layout>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="nodeGrpMgmt = !nodeGrpMgmt"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //상관도 노드그룹관리 : Layer Popup -->
  </v-container>
</template>

<script>
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import DeaCheckbox from '../../components/common/DeaCheckbox.vue'

export default {
  name: 'Template601',
  components: {
    // DeaLabel,
    // DeaButton
    // DeaTextField
    // DeaCheckbox
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        },
        grpInfoView: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      fileDetailView: false,
      personSelect: false,
      nodeGrpMgmt: false,

      // In Modal Popup
      checkbox1: true,
      radios: 'radio-1',
      radioItems: [
        {
          label: '통화',
          value: 'radio-1'
        },
        {
          label: '계좌',
          value: 'radio-2'
        },
        {
          label: '파일',
          value: 'radio-3'
        }
      ],
      radio2s: 'radio-1',
      radio2Items: [
        {
          label: '피의자',
          value: 'radio-1'
        },
        {
          label: '혐의자',
          value: 'radio-2'
        },
        {
          label: '참고인',
          value: 'radio-3'
        },
        {
          label: '피해자',
          value: 'radio-4'
        },
        {
          label: '기타',
          value: 'radio-5'
        }
      ],
      dayList: [],
      dayItems: [
        { day: '월' },
        { day: '화' },
        { day: '수' },
        { day: '목' },
        { day: '금' },
        { day: '토' },
        { day: '일' }
      ],
      timeList: [],
      timeItems: [
        { time: '1' },
        { time: '2' },
        { time: '3' },
        { time: '4' },
        { time: '5' },
        { time: '6' }
      ],
      shuttleLeftModel: [],
      shuttleLeftItems: [
        { title: '주요인물명1', subtitle: '010-1234-5678' },
        { title: '주요인물명2', subtitle: '010-2345-6789' },
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명4', subtitle: '010-4567-8901' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],
      shuttleRightModel: [],
      shuttleRightItems: [
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],

      // Setting for Publishing
      loader: null,
      loading: false,
      selectLists: '전체',
      selectItems: ['전체'],
      select2Lists: '인물그룹 전체',
      select2Items: ['인물그룹 전체', '그룹1', '그룹2', '그룹3'],
      conditionSelects: 'radio-1',
      conditionSelectItems: [
        {
          label: '기지국 중심',
          value: 'radio-1'
        },
        {
          label: '이동내역 중심',
          value: 'radio-2'
        }
      ],
      contextList: null,
      contextItems: [
        { text: '인물정보보기' },
        { text: '노드그룹생성' },
        { text: '노드그룹축소' },
        { text: '노드그룹확장' },
        { text: '1인중심분석' },
        { text: '매체중심분석' }
      ],

      // 페이지내 좌측메뉴
      collapsibleLeft: false,
      open: ['전체', 'XX전자', '재무팀'],
      files: {
        person: 'mdi-account',
        cellphone: 'mdi-cellphone-iphone',
        notebook: 'mdi-laptop-windows'
      },
      folderTree: [],
      items: [
        {
          name: '전체',
          children: [
            {
              name: 'XX전자',
              children: [
                {
                  name: '재무팀',
                  children: [
                    {
                      name: '실사용자1',
                      file: 'person',
                      children: [
                        { name: '휴대폰', file: 'cellphone' },
                        { name: '노트북', file: 'notebook' }
                      ]
                    }
                  ]
                }
              ]
            },
            { name: 'YY전자' }
          ]
        }
      ]
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    // treeLeftClass() {
    //   return foldLeft ? 'aaa' : 'bbb'
    // }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
