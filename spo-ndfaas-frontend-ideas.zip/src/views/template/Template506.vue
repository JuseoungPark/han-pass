<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-PRFI-M0007</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                ※ 미분류 파일이 12개 있습니다. 통합 북마크로 이동하여, 폴더별로
                분류하여 중요 내역을 관리하세요!
              </div>
              <dea-button>북마크내역 분류하기</dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-tabs class="dea-tabs">
                <v-tab>파일목록 (32)</v-tab>
              </v-tabs>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>북마크해제</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 북마크해제 : Layer Popup -->
    <dea-dialog v-model="bookmarkReload" title="북마크해제" width="1100px">
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                선택한 3개의 통화 내역을 제외에서 복원합니다
              </div>
            </v-col>
          </v-row>
          <dea-card>
            <dea-grid :columns="gridInfo.grpPersonList.columns"></dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="bookmarkReload = !bookmarkReload"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //북마크해제 : Layer Popup -->
  </v-container>
</template>

<script>
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaGrid from '../../components/common/DeaGrid.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import DeaSelect from '../../components/common/DeaSelect.vue'

export default {
  name: 'Template506',
  components: {
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        },
        grpPersonList: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      bookmarkReload: false

      // In Modal Popup

      // Setting for Publishing
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
