<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-CALL-M0005, UI-ID-CALL-P0010, 차트 옵션 변경
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="callSpecGraph = !callSpecGraph"
              >통화특성 차트</dea-button
            >
            <dea-button @click="graphChange = !graphChange"
              >차트변경</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="3">
              <dea-text-field
                placeholder="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>기준선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="standardSelects"
                row
                :mandatory="false"
                :items="standardSelectItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon prepend-icon="mdi-restore"></dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox label="전체" :value="true"></dea-checkbox>
              <dea-checkbox label="통화"></dea-checkbox>
              <dea-checkbox label="메세지"></dea-checkbox>
              <dea-checkbox label="기타"></dea-checkbox>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>통화특성 분석내역 (21)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button>차트</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 통화특성 차트 : Layer Popup -->
    <dea-dialog v-model="callSpecGraph" title="통화특성 차트" width="1100px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card class="side-btn-group">
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>구분</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-checkbox label="전체" :value="true"></dea-checkbox>
                <dea-checkbox label="통화"></dea-checkbox>
                <dea-checkbox label="메세지"></dea-checkbox>
                <dea-checkbox label="기타"></dea-checkbox>
              </v-col>
              <v-col cols="1">
                <dea-label>내용</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="callDetails"
                  row
                  :mandatory="false"
                  :items="callDetailItems"
                ></dea-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>내용</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="callStates"
                  row
                  :mandatory="false"
                  :items="callStateItems"
                ></dea-radio-group>
              </v-col>
              <v-col cols="1">
                <dea-label>구분</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-checkbox label="전체" :value="true"></dea-checkbox>
                <dea-checkbox label="발신"></dea-checkbox>
                <dea-checkbox label="착신"></dea-checkbox>
              </v-col>
            </v-row>
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-center">
                  <dea-button prepend-icon="mdi-magnify" color="primary">
                    조회
                  </dea-button>
                  <dea-button outlined prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner chart-wrap">
          <dea-card class="pa-0">
            차트
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-center">
                  <dea-button>이전</dea-button>
                  <dea-button>다음</dea-button>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner grid-wrap">
          <dea-card>
            <dea-grid
              use-pagination
              :columns="gridInfo.callTotalHistory.columns"
            >
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>통화내역 (34)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
              <template #header-right>
                <v-col class="d-flex align-right">
                  <dea-button
                    icon
                    fab
                    textindent
                    title="북마크"
                    prepend-icon="mdi-bookmark-multiple-outline"
                    bottom
                    >북마크</dea-button
                  >
                  <dea-button
                    icon
                    fab
                    textindent
                    title="제외"
                    prepend-icon="mdi-minus-circle-outline"
                    bottom
                    >제외</dea-button
                  >
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button color="primary" @click="callSpecGraph = !callSpecGraph"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //통화특성 차트 : Layer Popup -->

    <!-- 차트변경 : Layer Popup -->
    <dea-dialog v-model="graphChange" title="차트변경" width="800px">
      <section class="dea-section">
        <div class="inner chart-wrap">
          <v-row no-gutters class="chart-top">
            <v-col class="d-flex">
              <v-tabs class="dea-tabs">
                <v-tab>추천</v-tab>
                <v-tab>비교차트</v-tab>
                <v-tab>분포차트</v-tab>
                <v-tab>빈도/밀도차트</v-tab>
                <v-tab>상관관계차트</v-tab>
              </v-tabs>
            </v-col>
          </v-row>
          <dea-card class="pa-0 ba-0">
            <div class="divide">
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-line.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-bar.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-area.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
            </div>
            <div class="divide">
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-bar-histogram.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-line-histogram.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-heat-map.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
            </div>
            <div class="divide">
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-stacked-bar.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-pie.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-tree-map.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
            </div>
            <div class="divide">
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-scatter-plot.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-bubble.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
              <v-col>
                <div class="chart-img-wrap">
                  <v-img
                    src="/img/chart-chord-diagram.png"
                    width="100%"
                    height="100%"
                  ></v-img>
                </div>
              </v-col>
            </div>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner chart-wrap">
          <dea-card class="pa-0">
            차트
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button @click="graphChange = !graphChange">취소</dea-button>
          <dea-button color="primary" @click="graphChange = !graphChange"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //차트변경 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template403',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      callSpecGraph: false,
      graphChange: false,

      // In Modal Popup
      chartList: '',
      chartItems: [
        {
          type: 'Area Chart',
          icon: 'mdi-equalizer'
        },
        {
          type: 'Bar Chart',
          icon: 'mdi-elevation-rise'
        },
        {
          type: 'Bubble Chart',
          icon: 'mdi-circle-slice-7'
        }
      ],

      // Setting for Publishing
      standardSelects: 'radio-1',
      standardSelectItems: [
        {
          label: '실사용자 기준',
          value: 'radio-1'
        },
        {
          label: '전화번호 기준',
          value: 'radio-2'
        }
      ],
      callDetails: 'radio-1',
      callDetailItems: [
        {
          label: '빈도',
          value: 'radio-1'
        },
        {
          label: '통화량',
          value: 'radio-2'
        }
      ],
      callStates: 'radio-1',
      callStateItems: [
        {
          label: '시간대별',
          value: 'radio-1'
        },
        {
          label: '요일별',
          value: 'radio-2'
        },
        {
          label: '일별',
          value: 'radio-3'
        },
        {
          label: '월별',
          value: 'radio-4'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
