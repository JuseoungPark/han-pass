<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-CALL-M0008, UI-ID-CALL-P0012</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button @click="personSelect = !personSelect"
              >인물선택</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                placeholder="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
                styles="width:200px;"
                classes="flex-0"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>밀도조건</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                :clearable="false"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">분 내에</div>
              <dea-text-field
                :clearable="false"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">건 이상</div>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>통화조건</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="callConditions"
                row
                :mandatory="false"
                :items="callConditionItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>통화밀도분석내역 (11)</v-tab>
                </v-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 인물선택 : Layer Popup -->
    <dea-dialog v-model="personSelect" title="인물선택" width="800px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  label="인물종류 선택"
                  placeholder="종류를 선택하세요"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field
                  placeholder="인물을 검색하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">
                    통화밀도를 확인하기 위해 인물을 선택해주세요
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleLeftModel" multiple>
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="'shuttleLeftItem' + i"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleLeftItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personSelect = !personSelect"
            >취소</dea-button
          >
          <dea-button color="primary" @click="personSelect = !personSelect"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물선택 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template405',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      personSelect: false,

      // In Modal Popup
      shuttleLeftModel: [],
      shuttleLeftItems: [
        { title: '주요인물명1', subtitle: '010-1234-5678' },
        { title: '주요인물명2', subtitle: '010-2345-6789' },
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명4', subtitle: '010-4567-8901' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],

      // Setting for Publishing
      callConditions: 'radio-1',
      callConditionItems: [
        {
          label: '전체',
          value: 'radio-1'
        },
        {
          label: '통화만 계산',
          value: 'radio-2'
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
