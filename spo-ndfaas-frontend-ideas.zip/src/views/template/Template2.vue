<template>
  <v-container>
    <article>
      <section class="dea-section">
        <div class="search-box">
          <dea-card expandable class="side-btn-group d-flex">
            <template slot="title">검색조건</template>
            <template slot="sub-title">제목에 대한 상세설명 부분</template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>Text fields</dea-label>
              </v-col>
              <v-col class="d-flex" cols="7">
                <dea-text-field
                  clearable
                  classes="flex-0"
                  styles="width:200px"
                  label="사용자"
                  placeholder="이름을 입력하세요."
                  hint="상태메세지를 보여줍니다."
                ></dea-text-field>
                <dea-text-field
                  single-line
                  clearable
                  readonly
                  label="이메일(readonly)"
                  placeholder="이메일을 입력하세요."
                  value="gildong794@gmail.com"
                  hint="At least 8 characters"
                  persistent-hint
                ></dea-text-field>
                <dea-text-field
                  disabled
                  label="전화번호(disabled)"
                  placeholder="전화번호를 입력하세요."
                  hint="상태메세지를 보여줍니다."
                ></dea-text-field>
              </v-col>

              <v-col cols="1">
                <dea-label>Password</dea-label>
              </v-col>
              <v-col class="d-flex">
                <v-text-field
                  v-model="password"
                  dense
                  outlined
                  clearable
                  label="비밀번호"
                  placeholder="비밀번호를 입력하세요."
                  :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                  :rules="[rules.required, rules.min]"
                  :type="show1 ? 'text' : 'password'"
                  hint="At least 8 characters"
                  counter="20"
                  @click:append="show1 = !show1"
                ></v-text-field>
              </v-col>
            </v-row>

            <v-expand-transition>
              <div v-show="isDetailSearch">
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>Text fields</dea-label>
                  </v-col>
                  <v-col class="d-flex" cols="7">
                    <v-text-field
                      dense
                      outlined
                      class="flex-0"
                      style="width:200px"
                      label="사용자"
                      placeholder="이름을 입력하세요."
                      hint="상태메세지를 보여줍니다."
                    ></v-text-field>
                    <v-text-field
                      dense
                      single-line
                      outlined
                      clearable
                      readonly
                      label="이메일(readonly)"
                      placeholder="이메일을 입력하세요."
                      value="gildong794@gmail.com"
                      hint="At least 8 characters"
                      persistent-hint
                    ></v-text-field>
                  </v-col>
                  <v-col class="d-flex">
                    <v-text-field
                      dense
                      outlined
                      disabled
                      label="전화번호(disabled)"
                      placeholder="전화번호를 입력하세요."
                      hint="상태메세지를 보여줍니다."
                    ></v-text-field>
                  </v-col>
                </v-row>
              </div>
            </v-expand-transition>
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-center">
                  <dea-button color="primary">
                    <v-icon>mdi-magnify</v-icon>
                    조회
                  </dea-button>
                  <dea-button outlined>
                    <v-icon>mdi-restore</v-icon>
                    초기화
                  </dea-button>
                  <dea-button
                    :prepend-icon="
                      isDetailSearch
                        ? 'mdi-arrow-collapse-up'
                        : 'mdi-arrow-collapse-down'
                    "
                    @click="isDetailSearch = !isDetailSearch"
                  >
                    {{ isDetailSearch ? '상세검색 접기' : '상세검색 펼치기' }}
                  </dea-button>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner">
          <v-layout class="divide">
            <v-col>
              <dea-card class="d-flex">
                <template slot="title">Divide 레이아웃</template>
                <template slot="sub-title">
                  세로 2단이상의 레이아웃 구조
                </template>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>라벨</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field></dea-text-field>
                  </v-col>
                  <v-col cols="1">
                    <dea-label>라벨2</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field></dea-text-field>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>라벨3</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-select class="flex-0" style="width:30%;"></dea-select>
                    <dea-text-field></dea-text-field>
                    <dea-button outlined>버튼</dea-button>
                  </v-col>
                </v-row>
              </dea-card>
            </v-col>
            <v-col>
              <dea-card class="d-flex">
                <template slot="title">Divide 레이아웃</template>
                <template slot="sub-title">
                  세로 2단이상의 레이아웃 구조
                </template>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>라벨</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field></dea-text-field>
                  </v-col>
                  <v-col cols="1">
                    <dea-label>라벨2</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-text-field></dea-text-field>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>라벨3</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <dea-select class="flex-0" style="width:30%;"></dea-select>
                    <dea-text-field></dea-text-field>
                    <dea-button outlined>버튼</dea-button>
                  </v-col>
                </v-row>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner">
          <dea-card class="detail-view">
            <template slot="title">검색결과 상세</template>
            <template slot="sub-title">
              검색결과에서 특정정보에 대한 상세값을 보여줌
            </template>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>문서번호</dea-label>
              </v-col>
              <v-col class="d-flex" cols="3">
                <div class="text">201902007</div>
              </v-col>
              <v-col cols="1">
                <dea-label>신청서제목</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">신청서 테스트</div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>서비스</dea-label>
              </v-col>
              <v-col class="d-flex" cols="3">
                <div class="text">증거분석 서비스</div>
              </v-col>
              <v-col cols="1">
                <dea-label>서비스그룹</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">경기도 특사경</div>
              </v-col>
              <v-col cols="1">
                <dea-label>서비스ID</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">PD015798</div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>완료희망일</dea-label>
              </v-col>
              <v-col class="d-flex" cols="3">
                <div class="text">2019-02-22</div>
              </v-col>
              <v-col cols="1">
                <dea-label>신청자</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">경기도 특사경 (police_user)</div>
              </v-col>
              <v-col cols="1">
                <dea-label>신청자조직</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">경기도 특사경 세무징수팀</div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>첨부파일</dea-label>
              </v-col>
              <v-col class="d-flex">
                <a class="text">a0023456779-001.jpg</a>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>요청내용</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-textarea
                  single-line
                  label="작성된 요청내용(readonly)"
                  placeholder="상세설명을 입력하세요."
                  hint="상태메세지를 보여줍니다."
                  value="가나다라마바사"
                  readonly
                  filled
                ></dea-textarea>
              </v-col>
            </v-row>
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-left">
                  <v-btn outlined class="white--bg" disabled>삭제</v-btn>
                  <v-btn color="primary" disabled>수동작업완료</v-btn>
                </v-col>
                <v-col class="align-right">
                  <v-btn outlined class="white--bg">선행작업</v-btn>
                  <v-btn outlined class="white--bg">반려</v-btn>
                  <v-btn color="primary">승인</v-btn>
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>
    </article>
  </v-container>
</template>

<script>
import DeaLabel from '@/components/common/DeaLabel'
import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template2',
  components: {
    DeaLabel,
    DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // breadcrump
      breadItems: [
        {
          text: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard'
        },
        {
          text: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1'
        },
        {
          text: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2'
        }
      ],

      // password
      show1: false,
      password: 'Password',
      rules: {
        required: (value) => !!value || 'Required.',
        min: (v) => v.length >= 8 || 'Min 8 characters'
      }
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
