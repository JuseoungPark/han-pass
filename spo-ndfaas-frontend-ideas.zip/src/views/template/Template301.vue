<template>
  <v-container class="personManagement">
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-SUSP-M0001, UI-ID-SUSP-P0001, UI-ID-SUSP-P0002,
          UI-ID-SUSP-P0003, UI-ID-SUSP-P0004, UI-ID-SUSP-M0002,
          UI-ID-SUSP-P0005, UI-ID-SUSP-M0002, UI-ID-SUSP-P0006,
          UI-ID-SUSP-P0007, UI-ID-SUSP-P0008, UI-ID-SUSP-P0009,
          UI-ID-SUSP-P0010, UI-ID-SUSP-P0011
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button outlined @click="systemPopup = !systemPopup"
              >시스템 팝업</dea-button
            >
            <dea-button outlined @click="systemPopup1 = !systemPopup1"
              >시스템 팝업1</dea-button
            >
            <dea-button @click="personRegDialog = !personRegDialog"
              >인물등록 (방법선택)</dea-button
            >
            <dea-button @click="individualReg = !individualReg"
              >인물등록</dea-button
            >
            <dea-button @click="sourceFileSearch = !sourceFileSearch"
              >출처파일 조회</dea-button
            >
            <dea-button @click="personSearch = !personSearch"
              >인물검색 (등록여부 확인)</dea-button
            >
            <dea-button @click="companyDepartMgmt = !companyDepartMgmt"
              >회사/부서관리</dea-button
            >
            <dea-button @click="individualDetail = !individualDetail"
              >인물정보 (인물 미리보기)</dea-button
            >
            <dea-button @click="personBatchReg = !personBatchReg"
              >인물정보 일괄등록</dea-button
            >
            <dea-button @click="personGrpSelect = !personGrpSelect"
              >인물그룹지정</dea-button
            >
            <dea-button @click="personGrpMgmt = !personGrpMgmt"
              >인물그룹관리</dea-button
            >
            <dea-button @click="personMerge = !personMerge"
              >인물병합</dea-button
            >
            <dea-button @click="personDivide = !personDivide"
              >인물분리</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <v-row no-gutters>
        <v-col class="d-flex valign-middle">
          <div class="info-message">
            <strong>2020-10-12 19:03</strong>
            <label class="ml-2">업데이트</label>
          </div>
          <v-btn
            text
            class="dea-btn--textindent"
            :loading="loading"
            @click="loader = 'loading'"
          >
            <v-icon>mdi-cached</v-icon>
            갱신
          </v-btn>
        </v-col>
      </v-row>

      <div class="search-box search-box-field">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-text-field
                v-model="keyword"
                class="align-center"
                append-icon="mdi-magnify"
                label="키워드입력"
                placeholder="인물과 관련된 정보로 키워드를 검색하세요."
                @click:append="searchKeyword"
                @keydown.enter="searchKeyword"
              ></dea-text-field>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card class="grid-wrap">
          <dea-grid use-pagination :columns="gridInfo.relatedPerson.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs :show-arrows="false" class="dea-tabs">
                  <v-tab class="font-bold">전체 (128)</v-tab>
                  <v-tab class="font-bold">주요인물 (25)</v-tab>
                  <v-tab class="child-tab fontsize-small2">피의자 (2)</v-tab>
                  <v-tab class="child-tab fontsize-small2">혐의자 (3)</v-tab>
                  <v-tab class="child-tab fontsize-small2">참고인 (20)</v-tab>
                  <v-tab class="child-tab fontsize-small2">피해자 (3)</v-tab>
                  <v-tab class="font-bold">기타 (100)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button color="primary">인물등록</dea-button>
                <dea-button>인물병합</dea-button>
                <dea-button>인물그룹관리</dea-button>
                <dea-button>인물그룹지정</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 인물등록(방법선택) : Layer Popup -->
    <dea-dialog v-model="personRegDialog" title="인물등록" width="600px">
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text info-message fontsize-big3 font-bold pa-8">
                인물을 등록하기 위한 방식을 선택해 주세요.
              </div>
            </v-col>
          </v-row>
          <div class="divide space-around">
            <v-col cols="5">
              <v-card
                class="dea-card-field active align-center valign-middle"
                height="150"
                @click="individualReg = !individualReg"
              >
                <v-card-title class="text-truncate-none fontsize-big3 pa-4"
                  >개별등록</v-card-title
                >
                <v-card-subtitle class="text-truncate-none word-break pa-4">
                  각 인물을 개별적으로 수동 등록합니다.</v-card-subtitle
                >
              </v-card>
            </v-col>
            <v-col cols="5">
              <v-card
                class="dea-card-field active align-center valign-middle"
                height="150"
                @click="personBatchReg = !personBatchReg"
              >
                <v-card-title class="text-truncate-none fontsize-big3 pa-4"
                  >일괄등록</v-card-title
                >
                <v-card-subtitle class="text-truncate-none word-break pa-4">
                  표준서식을 사전에 작성하여 일괄 등록합니다.</v-card-subtitle
                >
              </v-card>
              <v-row no-gutters>
                <v-col class="d-flex align-center">
                  <div class="text"><a href="#">표준서식 다운받기</a></div>
                </v-col>
              </v-row>
            </v-col>
          </div>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personRegDialog = !personRegDialog"
            >닫기</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물등록(방법선택) : Layer Popup -->

    <!-- 인물등록 : Layer Popup -->
    <dea-dialog v-model="individualReg" title="인물등록" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label required>이름</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="이름을 입력해 주세요"
                ></dea-text-field>
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="personSearch = !personSearch"
                  >인물검색</dea-button
                >
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>별칭</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="별칭을 입력해주세요. 복수 입력시에는 콤마(,)로 구분해주세요."
                ></dea-text-field>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label required>유형</dea-label>
              </v-col>
              <v-col class="d-flex">
                <v-radio-group v-model="radios" row :mandatory="false">
                  <v-radio label="피의자" value="radio-1"></v-radio>
                  <v-radio label="혐의자" value="radio-2"></v-radio>
                  <v-radio label="참고인" value="radio-3"></v-radio>
                  <v-radio label="피해자" value="radio-4"></v-radio>
                  <v-radio label="기타" value="radio-5"></v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>인물그룹</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-select
                  filterable
                  :items="grpItems"
                  placeholder="인물 그룹을 선택해주세요"
                ></dea-select>
                <dea-button>인물그룹관리</dea-button>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>회사/부서</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-select
                  filterable
                  :items="companyItems"
                  placeholder="회사를 입력해주세요"
                ></dea-select>
                <dea-select
                  filterable
                  :items="departmentItems"
                  placeholder="부서를 입력해주세요"
                ></dea-select>
                <dea-button>회사/부서관리</dea-button>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>사진등록</dea-label>
              </v-col>
              <v-col class="d-flex flex-0">
                <v-layout
                  class="img-wrap"
                  style="width:120px; padding-top:120%;"
                >
                  <img
                    src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                    alt="홍길동 이미지"
                  />
                </v-layout>
                <!-- <v-img
                  src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                  width="120"
                  style="padding-top:66.66%;"
                ></v-img> -->
              </v-col>
            </v-row>
            <v-divider />
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">전화번호</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="전화번호를 입력해주세요"
                      value="010-1234-5678"
                    ></dea-text-field>
                    <v-menu
                      :disabled="disabled"
                      :absolute="absolute"
                      :open-on-hover="openOnHover"
                      :close-on-click="closeOnClick"
                      :close-on-content-click="closeOnContentClick"
                      :offset-x="offsetX"
                      :offset-y="offsetY"
                    >
                      <template v-slot:activator="{ on }">
                        <v-btn icon small class="dea-btn--textindent" v-on="on">
                          <v-icon>mdi-folder-multiple-plus</v-icon>
                          출처파일 목록
                        </v-btn>
                      </template>
                      <!-- 추출파일 목록 : Layer Popup -->
                      <v-sheet class="dea-popup" style="width:480px;">
                        <v-container class="pa-4">
                          <section class="dea-section">
                            <div class="inner">
                              <v-list dense>
                                <v-list-item-group
                                  multiple
                                  v-model="evidenceList"
                                >
                                  <v-list-item
                                    v-for="(evidenceItem, i) in evidenceItems"
                                    :key="i"
                                  >
                                    <v-list-item-content>
                                      <v-list-item-title
                                        v-text="evidenceItem.file"
                                        class="text-truncate-none"
                                      ></v-list-item-title>
                                    </v-list-item-content>
                                    <v-list-item-action>
                                      <dea-button>보기</dea-button>
                                    </v-list-item-action>
                                  </v-list-item>
                                </v-list-item-group>
                              </v-list>
                            </div>
                          </section>
                        </v-container>
                      </v-sheet>
                      <!-- //추출파일 목록 : Layer Popup -->
                    </v-menu>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="전화번호를 입력해주세요"
                      value="010-2345-6789"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent"
                      ><v-icon>mdi-folder-plus</v-icon>
                      출처파일
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-menu
                    :disabled="disabled"
                    :absolute="absolute"
                    :open-on-hover="openOnHover"
                    :close-on-click="closeOnClick"
                    :close-on-content-click="closeOnContentClick"
                    :offset-x="offsetX"
                    :offset-y="offsetY"
                  >
                    <template v-slot:activator="{ on, attrs }">
                      <v-layout class="dea-text-field">
                        <v-text-field
                          dense
                          outlined
                          placeholder="전화번호를 입력해주세요"
                          v-bind="attrs"
                          v-on="on"
                        ></v-text-field>
                        <v-btn icon small class="dea-btn--textindent">
                          <v-icon icon>mdi-magnify</v-icon>
                          출처파일 조회
                        </v-btn>
                      </v-layout>
                    </template>
                    <!-- 추출파일 목록 : Layer Popup -->
                    <v-sheet class="dea-popup" style="width:480px;">
                      <v-container class="pa-4">
                        <section class="dea-section">
                          <div class="inner">
                            <v-row no-gutters>
                              <v-col class="d-flex">
                                <div class="text">
                                  출처 증거파일을 검색하여 등록할 수 있습니다.
                                </div>
                              </v-col>
                              <v-col class="d-flex flex-0">
                                <dea-button
                                  @click="sourceFileSearch = !sourceFileSearch"
                                  >검색등록</dea-button
                                >
                                <dea-button>직접등록</dea-button>
                              </v-col>
                            </v-row>
                          </div>
                        </section>
                      </v-container>
                    </v-sheet>
                    <!-- //추출파일 목록 : Layer Popup -->
                  </v-menu>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="전화번호를 입력해주세요"
                      value="010-2345-6789"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-folder-plus</v-icon>
                      출처파일
                    </v-btn>
                  </v-layout>
                </v-col>
              </v-col>
              <v-col class="d-flex flex-column flex-0">
                <dea-button
                  icon
                  fab
                  textindent
                  color="primary"
                  prepend-icon="mdi-plus"
                  >추가</dea-button
                >
                <dea-button icon outlined textindent prepend-icon="mdi-minus"
                  >삭제</dea-button
                >
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">계좌번호</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="계좌를 입력해주세요"
                      value="NH 102-25-12987-1"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon>mdi-folder-plus</v-icon>
                      출처파일
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="계좌를 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="계좌를 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="계좌를 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
              </v-col>
              <v-col class="d-flex flex-column flex-0">
                <dea-button
                  icon
                  fab
                  textindent
                  color="primary"
                  prepend-icon="mdi-plus"
                  >추가</dea-button
                >
                <dea-button icon outlined textindent prepend-icon="mdi-minus"
                  >삭제</dea-button
                >
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">이메일</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="이메일을 입력해주세요"
                      value="hongildong@gmail.com"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-folder-plus</v-icon>
                      출처파일
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="이메일을 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="이메일을 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="이메일을 입력해주세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
              </v-col>
              <v-col class="d-flex flex-column flex-0">
                <dea-button
                  icon
                  fab
                  textindent
                  color="primary"
                  prepend-icon="mdi-plus"
                  >추가</dea-button
                >
                <dea-button icon outlined textindent prepend-icon="mdi-minus"
                  >삭제</dea-button
                >
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">모바일앱</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="모바일앱 / 아이디를 입력하세요"
                      value="카카오톡 / hong-GD794"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="모바일앱 / 아이디를 입력하세요"
                      value="인스타그램 / hongildong@email.com"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="모바일앱 / 아이디를 입력하세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
                <v-col class="d-flex">
                  <v-layout class="dea-text-field">
                    <dea-text-field
                      placeholder="모바일앱 / 아이디를 입력하세요"
                    ></dea-text-field>
                    <v-btn icon small class="dea-btn--textindent">
                      <v-icon icon>mdi-magnify</v-icon>
                      출처파일 조회
                    </v-btn>
                  </v-layout>
                </v-col>
              </v-col>
              <v-col class="d-flex flex-column flex-0">
                <dea-button
                  icon
                  fab
                  textindent
                  color="primary"
                  prepend-icon="mdi-plus"
                  >추가</dea-button
                >
                <dea-button icon outlined textindent prepend-icon="mdi-minus"
                  >삭제</dea-button
                >
              </v-col>
            </v-row>
            <v-divider />
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">메모</dea-label>
              </v-col>
              <v-col class="d-flex">
                <dea-textarea
                  no-resize
                  placeholder="메모를 입력할 수 있습니다"
                  counter="1000"
                ></dea-textarea>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="individualReg = !individualReg"
            >취소</dea-button
          >
          <dea-button color="primary">저장</dea-button>
          <dea-button>미리보기</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물등록 : Layer Popup -->

    <!-- 출처파일 조회 : Layer Popup -->
    <dea-dialog v-model="sourceFileSearch" title="출처파일 조회" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text word-break fontsize-big3 pa-4">
                  등록된 증거파일 혹은 증거추출파일에 입력하고자 하는 전화번호가
                  있는지 확인합니다.
                </div>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="전화번호를 입력하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >검색</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <template slot="title">총 4개의 검색결과</template>
            <v-list dense class="box-wrap">
              <v-list-item-group multiple v-model="evidenceList">
                <v-list-item
                  v-for="(evidenceItem, i) in evidenceItems"
                  :key="i"
                >
                  <v-list-item-content>
                    <v-list-item-title
                      v-text="evidenceItem.file"
                      class="text-truncate-none"
                    ></v-list-item-title>
                  </v-list-item-content>
                  <v-list-item-content>
                    <v-list-item-subtitle
                      v-text="evidenceItem.desc"
                      class="text-truncate-none"
                    ></v-list-item-subtitle>
                  </v-list-item-content>
                  <v-list-item-action>
                    <dea-button>상세보기</dea-button>
                  </v-list-item-action>
                </v-list-item>
              </v-list-item-group>
            </v-list>
            <v-row no-gutters>
              <v-col class="d-flex position-relative">
                <v-snackbar
                  :timeout="-1"
                  :value="true"
                  absolute
                  centered
                  top
                  rounded
                  elevation="0"
                  color="info"
                  class="d-flex"
                >
                  <v-icon class="mr-2">mdi-check-bold</v-icon>
                  <div class="text word-break">
                    선택된 2개의 파일을 출처파일로 등록합니다.
                  </div>
                </v-snackbar>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="d-flex align-center">
          <dea-button outlined @click="sourceFileSearch = !sourceFileSearch"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //출처파일 조회 : Layer Popup -->

    <!-- 인물검색 (등록여부 확인) : Layer Popup -->
    <dea-dialog v-model="personSearch" title="인물검색" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <dea-grid :columns="gridInfo.personSearch.columns"></dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personSearch = !personSearch"
            >취소</dea-button
          >
          <dea-button color="primary">새로운 인물로 등록합니다</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물검색 (등록여부 확인) : Layer Popup -->

    <!-- 회사/부서관리 : Layer Popup -->
    <dea-dialog v-model="companyDepartMgmt" title="회사/부서관리" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="회사명을 입력해주세요"
                ></dea-text-field>
                <dea-button>추가</dea-button>
              </v-col>
            </v-row>
          </dea-card>
        </div>
        <div class="inner">
          <dea-card>
            <v-list dense height="480" class="overflow-y-auto box-wrap">
              <v-list-group
                v-for="(companyItem, i) in companyItems"
                :key="i"
                sub-group
              >
                <template v-slot:activator>
                  <v-list-item-content class="flex-row">
                    <v-list-item-title
                      v-text="companyItem.text"
                    ></v-list-item-title>
                    <v-list-item-action>
                      <dea-button
                        icon
                        outlined
                        textindent
                        prepend-icon="mdi-close"
                        >삭제</dea-button
                      >
                    </v-list-item-action>
                  </v-list-item-content>
                </template>
                <v-list-item-group>
                  <v-list-item
                    v-for="(departmentItem, i) in departmentItems"
                    :key="i"
                  >
                    <template>
                      <v-list-item-content class="flex-row">
                        <v-list-item-title
                          v-text="departmentItem.text"
                        ></v-list-item-title>
                      </v-list-item-content>
                      <v-list-item-action>
                        <dea-button
                          icon
                          outlined
                          textindent
                          prepend-icon="mdi-close"
                          >삭제</dea-button
                        >
                      </v-list-item-action>
                    </template>
                  </v-list-item>
                  <v-list-item>
                    <v-list-item-content class="flex-row">
                      <v-list-item-title>
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <dea-text-field
                              placeholder="부서를 입력해주세요"
                            ></dea-text-field>
                          </v-col>
                        </v-row>
                      </v-list-item-title>
                      <v-list-item-action>
                        <dea-button>추가</dea-button>
                      </v-list-item-action>
                    </v-list-item-content>
                  </v-list-item>
                </v-list-item-group>
              </v-list-group>
            </v-list>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="companyDepartMgmt = !companyDepartMgmt"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //회사/부서관리 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dea-dialog v-model="individualDetail" title="홍길동" width="1000px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-layout class="divide">
              <v-col class="flex-0">
                <v-row no-gutters class="flex-column" style="height:100%;">
                  <v-col class="d-flex">
                    <v-layout
                      class="img-wrap"
                      style="width:140px; padding-top:120%;"
                    >
                      <img
                        src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                      />
                    </v-layout>
                  </v-col>
                  <v-col class="d-flex flex-0 align-center">
                    <div class="text">모바일</div>
                  </v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>이름</dea-label>
                  </v-col>
                  <v-col class="d-flex flex-0">
                    <div class="text">홍길동</div>
                  </v-col>
                  <v-col class="d-flex pl-1">
                    <v-chip small>피의자</v-chip>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>별칭</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">책임자</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>회사</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">SS그룹</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>부서</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">사업관리팀</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>그룹</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text mr-4">사건A 관련</div>
                    <div class="text mr-4">E대학교동창</div>
                    <div class="text mr-4">페이스북A그룹</div>
                  </v-col>
                </v-row>
              </v-col>
            </v-layout>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1" class="valign-top">
                <dea-label>전화번호</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-menu
                  :disabled="disabled"
                  :absolute="absolute"
                  :open-on-hover="openOnHover"
                  :close-on-click="closeOnClick"
                  :close-on-content-click="closeOnContentClick"
                  :offset-x="offsetX"
                  :offset-y="offsetY"
                >
                  <template v-slot:activator="{ on }">
                    <v-chip small v-on="on">010-1234-5678</v-chip>
                  </template>
                  <!-- 추출파일 목록 : Layer Popup -->
                  <v-sheet class="dea-popup" style="width:480px;">
                    <v-container class="pa-4">
                      <section class="dea-section">
                        <div class="inner">
                          <v-list dense>
                            <v-list-item-group v-model="deviceEvidenceList">
                              <v-list-item
                                v-for="(deviceEvidenceItem,
                                i) in deviceEvidenceItems"
                                :key="i"
                              >
                                <v-list-item-content>
                                  <v-list-item-title
                                    v-text="deviceEvidenceItem.file"
                                    class="text-truncate-none"
                                  ></v-list-item-title>
                                </v-list-item-content>
                                <v-list-item-action>
                                  <dea-button>다운로드</dea-button>
                                </v-list-item-action>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                        </div>
                      </section>
                    </v-container>
                  </v-sheet>
                  <!-- //추출파일 목록 : Layer Popup -->
                </v-menu>
                <v-chip small>070-5678-1234</v-chip>
                <v-chip small>02-555-3333</v-chip>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1" class="valign-top">
                <dea-label>이메일</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-chip small>honggildong@email.com</v-chip>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1" class="valign-top">
                <dea-label>계좌번호</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-chip small>KB 124567890</v-chip>
                <v-chip small>KEB 124567890</v-chip>
                <v-chip small>NH 124567890</v-chip>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col cols="1" class="valign-top">
                <dea-label>모바일</dea-label>
              </v-col>
              <v-col class="d-flex flex-wrap">
                <v-chip small
                  >카카오톡 <span class="ml-2">hong9785</span></v-chip
                >
                <v-chip small
                  >네이버 <span class="ml-2">honghong85</span></v-chip
                >
                <v-chip small
                  >페이스북 <a href="#" class="ml-2">email@email.com</a></v-chip
                >
                <v-chip small
                  >인스타그램
                  <a href="#" class="ml-2">hong9785@email.com</a></v-chip
                >
                <v-chip small
                  >구글 <a href="#" class="ml-2">email@email.com</a></v-chip
                >
                <v-chip small
                  >트위터 <a href="#" class="ml-2">email@email.com</a></v-chip
                >
              </v-col>
            </v-row>
            <v-divider />
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label class="valign-top">메모</dea-label>
              </v-col>
              <v-col class="d-flex d-block">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <v-sheet class="text">
                      주로 모바일 APP을 이용하고 있으며 통화내역은 많지 않음
                    </v-sheet>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner grid-wrap">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                5명의 인물이 병합되어 있습니다.
              </div>
            </v-col>
          </v-row>
          <dea-card title-class="title-align">
            <template slot="title">병합정보</template>
            <dea-grid :columns="gridInfo.modifiedHistory.columns"></dea-grid>
          </dea-card>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner grid-wrap">
          <dea-card>
            <template slot="title">수정이력</template>
            <v-row>
              <v-col cols="6">
                <v-card class="dea-card-field pa-0">
                  <v-list
                    v-model="modifyHistoryPC"
                    class="history-list pa-0"
                    height="215"
                  >
                    <v-list-item
                      v-for="(modifyHistoryPCItem, i) in modifyHistoryPCItems"
                      :key="i"
                    >
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistoryPCItem.title1 }}
                          </v-list-item-title>
                          <v-list-item-title>
                            등록자: {{ modifyHistoryPCItem.title2 }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistoryPCItem.text"
                          ></div>
                        </v-layout>
                        <v-layout class="flex-50">
                          <v-list-item-subtitle>
                            [수정]항목: {{ modifyHistoryPCItem.subtitle1 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            [추가]항목:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            [삭제]: {{ modifyHistoryPCItem.subtitle2 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물병합
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물분리
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list>
                </v-card>
              </v-col>
              <v-col cols="6">
                <v-card class="dea-card-field pa-0">
                  <v-list
                    v-model="modifyHistoryPhone"
                    class="history-list pa-0"
                    height="215"
                  >
                    <v-list-item
                      v-for="(modifyHistoryPhoneItem,
                      i) in modifyHistoryPhoneItems"
                      :key="i"
                    >
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistoryPhoneItem.title1 }}
                          </v-list-item-title>
                          <v-list-item-title>
                            등록자: {{ modifyHistoryPhoneItem.title2 }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistoryPhoneItem.text"
                          ></div>
                        </v-layout>
                        <v-layout class="flex-50">
                          <v-list-item-subtitle>
                            이름: {{ modifyHistoryPhoneItem.subtitle1 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            별칭:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            유형:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물그룹:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            회사: {{ modifyHistoryPhoneItem.subtitle3 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            부서:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            사진:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            전화번호: {{ modifyHistoryPhoneItem.subtitle2 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            이메일:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            계좌번호:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            모바일앱:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            메모:
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list>
                </v-card>
              </v-col>
              <v-col cols="6">
                <v-card class="dea-card-field pa-0">
                  <v-list
                    v-model="modifyHistoryPhone"
                    class="history-list pa-0"
                    height="215"
                  >
                    <v-list-item
                      v-for="(modifyHistoryPhoneItem,
                      i) in modifyHistoryPhoneItems"
                      :key="i"
                    >
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistoryPhoneItem.title1 }}
                          </v-list-item-title>
                          <v-list-item-title>
                            등록자: {{ modifyHistoryPhoneItem.title2 }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistoryPhoneItem.text"
                          ></div>
                        </v-layout>
                        <v-layout class="flex-50">
                          <v-list-item-subtitle>
                            이름: {{ modifyHistoryPhoneItem.subtitle1 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            별칭:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            유형:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물그룹:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            회사: {{ modifyHistoryPhoneItem.subtitle3 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            부서:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            사진:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            전화번호: {{ modifyHistoryPhoneItem.subtitle2 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            이메일:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            계좌번호:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            모바일앱:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            메모:
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list>
                </v-card>
              </v-col>
              <v-col cols="6">
                <v-card class="dea-card-field pa-0">
                  <v-list
                    v-model="modifyHistoryPC"
                    class="history-list pa-0"
                    height="215"
                  >
                    <v-list-item
                      v-for="(modifyHistoryPCItem, i) in modifyHistoryPCItems"
                      :key="i"
                    >
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistoryPCItem.title1 }}
                          </v-list-item-title>
                          <v-list-item-title>
                            등록자: {{ modifyHistoryPCItem.title2 }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistoryPCItem.text"
                          ></div>
                        </v-layout>
                        <v-layout class="flex-50">
                          <v-list-item-subtitle>
                            [수정]항목: {{ modifyHistoryPCItem.subtitle1 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            [추가]항목:
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            [삭제]: {{ modifyHistoryPCItem.subtitle2 }}
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물병합
                          </v-list-item-subtitle>
                          <v-list-item-subtitle>
                            인물분리
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list>
                </v-card>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined>수정</dea-button>
          <dea-button
            color="primary"
            @click="individualDetail = !individualDetail"
            >확인</dea-button
          >
          <dea-button>인쇄</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물정보 상세 : Layer Popup -->

    <!-- 인물정보 일괄등록 : Layer Popup -->
    <dea-dialog
      v-model="personBatchReg"
      title="인물정보 일괄등록"
      width="600px"
    >
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text">
                대량의 인물정보를 파일 형태로 일괄 등록합니다.
              </div>
              <div class="text"><a href="#">표준서식 다운받기</a></div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <dea-file-input
                counter
                placeholder="로컬 PC에서 작성한 파일을 불러옵니다"
                prepend-icon="mdi-folder-open-outline"
                :show-size="1000"
              >
              </dea-file-input>
            </v-col>
          </v-row>
        </div>
      </section>

      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 font-bold fontcolor-primary">
                <v-icon class="fontsize-big3 fontcolor-primary"
                  >mdi-file-excel-outline</v-icon
                >
                표준서식파일제목.xls
              </div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text">
                업로드가 완료되어, 등록 처리 진행중입니다.
              </div>
            </v-col>
          </v-row>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personBatchReg = !personBatchReg"
            >취소</dea-button
          >
          <dea-button color="primary">업로드</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물정보 일괄등록 : Layer Popup -->

    <!-- 인물그룹지정 : Layer Popup -->
    <dea-dialog v-model="personGrpSelect" title="인물그룹지정" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card title-class="title-align">
            <template slot="title">선택한 인물</template>
            <dea-grid :columns="gridInfo.grpPersonList.columns"></dea-grid>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <template slot="title">그룹지정</template>
            <template slot="sub-title"
              >새로운 그룹을 생성하려면 그룹관리 기능을 이용해주세요.</template
            >
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  filterable
                  :items="grpItems"
                  placeholder="인물 그룹을 선택해 주세요"
                ></dea-select>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personGrpSelect = !personGrpSelect"
            >취소</dea-button
          >
          <dea-button color="primary">저장</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물그룹지정 : Layer Popup -->

    <!-- 인물그룹관리 : Layer Popup -->
    <dea-dialog v-model="personGrpMgmt" title="인물그룹관리" width="800px">
      <v-layout class="divide pa-0 ba-0">
        <v-col cols="5">
          <v-tabs class="dea-tabs" vertical>
            <v-tab class="align-left">
              <span>A그룹(13명)</span>
              <dea-button icon outlined textindent prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>B그룹(2명)</span>
              <dea-button icon outlined textindent prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>C그룹(10명)</span>
              <dea-button icon outlined textindent prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
            <v-tab class="align-left">
              <span>D그룹(200명)</span>
              <dea-button icon outlined textindent prepend-icon="mdi-close"
                >삭제</dea-button
              >
            </v-tab>
          </v-tabs>
          <section class="dea-section">
            <div class="inner"></div>
            <v-row no-gutters>
              <v-col class="d-flex position-relative">
                <v-snackbar
                  :timeout="-1"
                  :value="true"
                  absolute
                  centered
                  top
                  rounded
                  elevation="0"
                  color="info"
                  class="d-flex"
                >
                  <v-icon class="mr-2">mdi-check-bold</v-icon>
                  <div class="text word-break">
                    그룹을 삭제하면 해당 그룹으로 등록된 인물의 그룹 정보가
                    초기화됩니다.
                  </div>
                </v-snackbar>
              </v-col>
            </v-row>
          </section>
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="신규 추가할 그룹명을 입력하세요"
                    ></dea-text-field>
                    <dea-button>추가</dea-button>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
          </section>
        </v-col>
        <v-col>
          <section class="dea-section">
            <div class="inner grid-wrap">
              <dea-card>
                <dea-grid :columns="gridInfo.grpInfoView.columns"></dea-grid>
              </dea-card>
            </div>
          </section>
        </v-col>
      </v-layout>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personGrpMgmt = !personGrpMgmt"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물그룹관리 : Layer Popup -->

    <!-- 인물병합 : Layer Popup -->
    <dea-dialog v-model="personMerge" title="인물병합" width="800px">
      <section class="dea-section">
        <div class="inner grid-wrap">
          <dea-card>
            <dea-grid :columns="gridInfo.grpPersonList.columns">
              <template #header-right>
                <v-col class="d-flex align-right">
                  <div class="text">선택한 인물</div>
                  <dea-button outlined>제외</dea-button>
                </v-col>
              </template>
            </dea-grid>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text fontsize-big3 pa-4">
                  위의 인물 목록을 병합합니다.
                </div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personMerge = !personMerge"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
          <dea-button>미리보기</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물병합 : Layer Popup -->

    <!-- 인물분리 : Layer Popup -->
    <dea-dialog v-model="personDivide" title="인물분리" width="800px">
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                병합된 인물을 다음처럼 다시 분리합니다.
              </div>
            </v-col>
          </v-row>
          <dea-card>
            <dea-grid :columns="gridInfo.grpPersonList.columns"></dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personDivide = !personDivide"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물그룹지정 : Layer Popup -->

    <!-- 시스템 팝업 : System Popup 
    <dea-dialog v-model="systemPopup" width="320px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text">
                  ‘이순신’으로 등록되어 있는 모바일앱 입니다. 기존내용을
                  변경하시겠습니까?
                </div>
              </v-col>
            </v-row>
            <template slot="actions">
              <div class="btn-group">
                <v-col class="align-center">
                  <dea-button outlined @click="systemPopup = !systemPopup"
                    >아니오</dea-button
                  >
                  <dea-button
                    color="primary"
                    @click="systemPopup = !systemPopup"
                    >예</dea-button
                  >
                </v-col>
              </div>
            </template>
          </dea-card>
        </div>
      </section>
    </dea-dialog>
    -->
    <dea-confirm
      v-model="systemPopup"
      message="alert창"
      @ok="doOK"
      @doCancle="doCancle"
      alert
    />
    <dea-confirm v-model="systemPopup1">
      <template slot="message">
        <div>
          22‘이순신’으로 등록되어 있는 모바일앱 입니다. 기존내용을
          변경하시겠습니까?
        </div>
      </template>
    </dea-confirm>
  </v-container>
</template>

<script>
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup' // 두줄 헤더일 때

export default {
  name: 'Template301',
  components: {},
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      keyword: '',
      isDetailSearch: false,
      doOK: false,
      doCancle: false,

      // grid setting
      gridInfo: {
        relatedPerson: {
          columns: []
        },
        personSearch: {
          columns: []
        },
        modifiedHistory: {
          columns: []
        },
        grpPersonList: {
          columns: []
        },
        grpInfoView: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      systemPopup: false,
      systemPopup1: false,
      systemPopup2: false,
      systemPopup3: false,
      personRegDialog: false,
      individualReg: false,
      sourceFileSearch: false,
      personSearch: false,
      companyDepartMgmt: false,
      individualDetail: false,
      personBatchReg: false,
      personGrpMgmt: false,
      personGrpSelect: false,
      personMerge: false,
      personDivide: false,

      // In Modal Popup
      radios: 'radio-1',
      modifyHistoryPC: '',
      modifyHistoryPCItems: [
        {
          title1: '2020.10.05 18:12:10',
          title2: '김OO 사무관',
          text: '매뉴얼 등록',
          subtitle1: '피의자',
          subtitle2: 'AAA그룹'
        }
      ],
      modifyHistoryPhone: '',
      modifyHistoryPhoneItems: [
        {
          title1: '2020.10.01 18:00:13',
          title2: '시스템',
          text: '휴대폰',
          subtitle1: '홍길동',
          subtitle2: '010-1234-5678',
          subtitle3: 'SS전자',
          subtitle4: '기획팀',
          subtitle5: '한국 SS대학교'
        }
      ],
      grpList: null,
      grpItems: [
        { text: 'A그룹' },
        { text: 'B그룹' },
        { text: 'C그룹' },
        { text: 'D그룹' }
      ],
      companyItems: [
        { text: 'SS그룹' },
        { text: 'SS(주)' },
        { text: 'SS전자' }
      ],
      departmentItems: [
        { text: '기획팀' },
        { text: '사업관리' },
        { text: '회계팀' }
      ],
      evidenceList: null,
      evidenceItems: [
        {
          file: '증거추출파일파일제목이_아주_긴경우엔.xls',
          desc: '파일에 대한 설명이 아주 긴 경우입니다'
        },
        { file: '증거추출파일파일제목.txt', desc: '파일에 대한 메모입니다' },
        { file: '증거추출파일파일제목.xls', desc: '파일 Descripttion' },
        { file: '증거추출파일파일제목.txt', desc: 'Description' }
      ],
      deviceEvidenceList: null,
      deviceEvidenceItems: [
        {
          file: '휴대폰 (증거추출파일파일제목.XLS)',
          desc: '파일에 대한 설명이 아주 긴 경우입니다'
        },
        {
          file: 'PC (증거추출파일파일제목.XLS)',
          desc: '파일에 대한 메모입니다'
        },
        { file: '매뉴얼 등록 (김사무관)', desc: '파일 Descripttion' }
      ],
      appsList: null,
      appsItems: [
        { name: '카카오톡' },
        { name: '카카오내비' },
        { name: '카카오뱅크' }
      ],
      apps2List: null,
      apps2Items: [
        { userid: 'hong9875' },
        { userid: 'hong9875@gmail.com' },
        { userid: 'hong75@gmail.com' }
      ],
      newGrpItem: '',

      // Setting for Publishing
      loader: null,
      loading: false
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  created() {},
  computed: {},
  mounted() {},
  methods: {
    // grpItemSelect(e, idx) {
    //   if (e.target.tagName !== 'DIV') return
    //   this.closeOnContentClick = true
    //   this.grpItem = this.grpItems[idx].text
    // },
    // grpItemSelected() {
    //   this.closeOnContentClick = false
    // },
    // grpItemRemove(idx) {
    //   this.closeOnContentClick = false
    //   const remveItem = this.grpItems.splice(idx, 1)[0]
    //   if (remveItem.text === this.grpItem) {
    //     console.log(remveItem.text)
    //     this.grpItem = ''
    //   }
    // },
    // grpItemAdd() {
    //   const find = (item) => item.text === this.newGrpItem
    //   const isHave = this.grpItems.some(find)
    //   if (isHave || this.newGrpItem === '') {
    //     alert('그룹이름이 없거나 존재합니다.')
    //     return
    //   }
    //   const item = { text: this.newGrpItem }
    //   this.grpItems.push(item)
    //   this.newGrpItem = ''
    // },
    searchKeyword() {
      console.log(`${this.keyword}`)
    }
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
