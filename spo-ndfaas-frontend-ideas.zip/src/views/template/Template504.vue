<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-PRFI-M0006
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>검색어</dea-label>
            </v-col>
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-select
                    v-model="selectLists"
                    :items="selectItems"
                    style="width:200px;"
                    class="flex-0"
                  ></dea-select>
                  <dea-text-field
                    placeholder="파일명, 파일경로, 또는 본문 내용을 입력하여 검색하세요"
                  ></dea-text-field>
                  <dea-checkbox label="결과내 검색"></dea-checkbox>
                  <dea-button icon textindent prepend-icon="mdi-restore"
                    >초기화</dea-button
                  >
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-text-field
                    label="일치하는 단어"
                    prepend-inner-icon="mdi-check"
                  ></dea-text-field>
                  <dea-text-field
                    label="반드시 포함하는 단어"
                    prepend-inner-icon="mdi-plus"
                  ></dea-text-field>
                  <dea-text-field
                    label="제외하는 단어"
                    prepend-inner-icon="mdi-minus"
                  ></dea-text-field>
                  <dea-button icon textindent prepend-icon="mdi-restore"
                    >초기화</dea-button
                  >
                </v-col>
              </v-row>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                placeholder="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
                style="width:200px;"
                class="flex-0"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col cols="1">
              <dea-label>파일크기</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                style="width:100px;"
                class="flex-0"
              ></dea-text-field>
              <div class="text">kb 이상</div>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                range
                styles="width:200px;"
                classes="flex-0"
              ></dea-date-picker>
              <dea-text-field placeholder="다중 기간 선택"></dea-text-field>
              <dea-text-field placeholder="요일 시간 선택"></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.callTotalHistory.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>전체목록 (14)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex">
                <dea-button>파일저장</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import DeaCheckbox from '../../components/common/DeaCheckbox.vue'

export default {
  name: 'Template504',
  components: {
    // DeaLabel,
    // DeaTextField
    // DeaCheckbox
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      fileDetailView: false,

      // In Modal Popup

      // Setting for Publishing
      selectLists: '전체',
      selectItems: ['전체'],
      conditionSelects: 'radio-1',
      conditionSelectItems: [
        {
          label: '기지국 중심',
          value: 'radio-1'
        },
        {
          label: '이동내역 중심',
          value: 'radio-2'
        }
      ],
      callStatusList: null,
      callStatusItems: [
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: 'link-off'
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-ppt1.jpg',
          stateClass: ''
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-ppt2.jpg',
          stateClass: 'link-off'
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: 'link-off'
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: 'link-off'
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: ''
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: ''
        },
        {
          fileName: '파일제목20201103.ppt',
          fileSize: '95.1kb',
          fileDate: '20201105 11:00:13',
          imgSrc: '/img/file-background.jpg',
          stateClass: ''
        }
      ],

      // 페이지내 좌측메뉴
      collapsibleLeft: false,
      open: ['전체', 'XX전자', '재무팀'],
      files: {
        person: 'mdi-account',
        cellphone: 'mdi-cellphone-iphone',
        notebook: 'mdi-laptop-windows'
      },
      folderTree: [],
      items: [
        {
          name: '전체',
          children: [
            {
              name: 'XX전자',
              children: [
                {
                  name: '재무팀',
                  children: [
                    {
                      name: '실사용자1',
                      file: 'person',
                      children: [
                        { name: '휴대폰', file: 'cellphone' },
                        { name: '노트북', file: 'notebook' }
                      ]
                    }
                  ]
                }
              ]
            },
            { name: 'YY전자' }
          ]
        }
      ]
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    // treeLeftClass() {
    //   return foldLeft ? 'aaa' : 'bbb'
    // }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
