<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card>
          <template slot="title">Hide branding</template>
          <div
            class="hide-charts"
            ref="hideChartdiv"
            style="height: 300px"
          ></div>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="search-box">
        <dea-card>
          <template slot="title">With branding</template>
          <div
            class="branding-charts"
            ref="brandingChartdiv"
            style="height: 300px"
          ></div>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import am4themes_animated from '@amcharts/amcharts4/themes/animated'

am4core.useTheme(am4themes_animated)

export default {
  name: 'CallAnalysysHome',
  components: {},
  data() {
    return {
      hideCharts: undefined,
      brandingCharts: undefined
    }
  },
  mounted() {
    this.createHideCharts()
    this.createBrandingCharts()
  },
  beforeDestroy() {
    if (this.hideCharts) {
      this.hideCharts.dispose()
    }

    if (this.brandingCharts) {
      this.brandingCharts.dispose()
    }
  },
  methods: {
    createHideCharts() {
      let chart = am4core.create(
        this.$refs.hideChartdiv,
        am4charts.SankeyDiagram
      )

      chart.hiddenState.properties.opacity = 0
      chart.logo.disabled = true

      chart.data = [
        { from: 'A', to: 'D', value: 10 },
        { from: 'B', to: 'D', value: 8 },
        { from: 'B', to: 'E', value: 4 },
        { from: 'C', to: 'E', value: 3 },
        { from: 'D', to: 'G', value: 5 },
        { from: 'D', to: 'I', value: 2 },
        { from: 'D', to: 'H', value: 3 },
        { from: 'E', to: 'H', value: 6 },
        { from: 'G', to: 'J', value: 5 },
        { from: 'I', to: 'J', value: 1 },
        { from: 'H', to: 'J', value: 9 }
      ]

      let hoverState = chart.links.template.states.create('hover')
      hoverState.properties.fillOpacity = 0.6

      chart.dataFields.fromName = 'from'
      chart.dataFields.toName = 'to'
      chart.dataFields.value = 'value'

      // for right-most label to fit
      chart.paddingRight = 30

      // make nodes draggable
      let nodeTemplate = chart.nodes.template
      nodeTemplate.inert = true
      nodeTemplate.readerTitle = 'Drag me!'
      nodeTemplate.showSystemTooltip = true
      nodeTemplate.width = 20

      // make nodes draggable
      let chartNodeTemplate = chart.nodes.template
      chartNodeTemplate.readerTitle = 'Click to show/hide or drag to rearrange'
      chartNodeTemplate.showSystemTooltip = true
      chartNodeTemplate.cursorOverStyle = am4core.MouseCursorStyle.pointer

      this.hideCharts = chart
    },
    createBrandingCharts() {
      let chart = am4core.create(this.$refs.brandingChartdiv, am4charts.XYChart)

      chart.paddingRight = 20

      let data = []
      let visits = 10
      for (let i = 1; i < 366; i++) {
        visits += Math.round(
          (Math.random() < 0.5 ? 1 : -1) * Math.random() * 10
        )
        data.push({
          date: new Date(2018, 0, i),
          name: 'name' + i,
          value: visits
        })
      }

      chart.data = data

      let dateAxis = chart.xAxes.push(new am4charts.DateAxis())
      dateAxis.renderer.grid.template.location = 0

      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
      valueAxis.tooltip.disabled = true
      valueAxis.renderer.minWidth = 35

      let series = chart.series.push(new am4charts.LineSeries())
      series.dataFields.dateX = 'date'
      series.dataFields.valueY = 'value'

      series.tooltipText = '{valueY.value}'
      chart.cursor = new am4charts.XYCursor()

      let scrollbarX = new am4charts.XYChartScrollbar()
      scrollbarX.series.push(series)
      chart.scrollbarX = scrollbarX

      this.brandingCharts = chart
    }
  }
}
</script>
