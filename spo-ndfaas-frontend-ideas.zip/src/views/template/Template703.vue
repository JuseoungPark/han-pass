<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-BOMA-M0004
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <dea-button outlined @click="analysisReport = !analysisReport"
              >분석보고서</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <v-row no-gutters class="grid-top">
        <v-col class="d-flex align-right">
          <dea-button color="primary">임시저장</dea-button>
        </v-col>
      </v-row>
      <div class="inner detail-view">
        <dea-card>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>사건번호</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <div class="text">2020형제 16533</div>
            </v-col>
            <v-col cols="1">
              <dea-label>사건명</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">선물거래금융투자상품2심사건</div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>사건개요</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">
                주식회사 하나대투증권에 선물거래 계좌를 개설한 뒤 이른바
                홈트레이딩 시스템(Home Trading System, 이하 ‘HTS’라고 한다)을
                통하여 실제 거래시세정보를 제공받고, 프로그램 개발업자로부터 위
                거래시세정보가 실시간으로 연동되고 주식회사 하나대투증권에
                선물거래 계좌를 개설한 뒤 이른바 홈트레이딩 시스템(Home Trading
                System, 이하 ‘HTS’라고 한다)을 통하여 실제 거래시세정보를
                제공받고, 프로그램 개발업자로부터 위 거래시세정보가 실시간으로
                연동되고 주식회사 하나대투증권에 선물거래 계좌를 개설한 뒤
                이른바 홈트레이딩 시스템(Home Trading System, 이하 ‘HTS’라고
                한다)을 통하여 실제 거래시세정보를 제공받고, 프로그램
                개발업자로부터 위 거래시세정보가 실시간으로 연동되고...
              </div>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="box-wrap">
        <div class="inner">
          <dea-card>
            <template slot="title">제목</template>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-text-field
                  placeholder="분석보고서를 요약할 수 있는 제목을 입력해주세요 (최대 100자)"
                ></dea-text-field>
              </v-col>
            </v-row>
          </dea-card>
        </div>
        <div class="inner">
          <dea-card>
            <template slot="title">내용</template>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-textarea placeholder="내용을 작성하세요"></dea-textarea>
              </v-col>
            </v-row>
          </dea-card>
        </div>
        <div class="inner">
          <dea-card>
            <template slot="title">증거파일</template>
            <div class="inner detail-view">
              <dea-card>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>분류</dea-label>
                  </v-col>
                  <v-col class="d-flex" cols="2">
                    <div class="text">통화내역</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>인물</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>일시</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">
                      통화시작 : YYYY-MM-DD HH:MM:SS
                    </div>
                    <div class="text">
                      통화종료 : YYYY-MM-DD HH:MM:SS
                    </div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>내용</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">수신자 : 김광호 (02-555-6666) (통화)</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>출처</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">
                      통신사실확인서파일제목.xls (증거번호 ########)
                    </div>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
            <div class="inner detail-view">
              <dea-card>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>분류</dea-label>
                  </v-col>
                  <v-col class="d-flex" cols="2">
                    <div class="text">통화내역</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>인물</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>일시</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">
                      통화시작 : YYYY-MM-DD HH:MM:SS
                    </div>
                    <div class="text">
                      통화종료 : YYYY-MM-DD HH:MM:SS
                    </div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>내용</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">수신자 : 김광호 (02-555-6666) (통화)</div>
                  </v-col>
                </v-row>
                <v-row no-gutters>
                  <v-col cols="1">
                    <dea-label>출처</dea-label>
                  </v-col>
                  <v-col class="d-flex">
                    <div class="text">
                      통신사실확인서파일제목.xls (증거번호 ########)
                    </div>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
          </dea-card>
        </div>
      </div>
      <div class="btn-group">
        <v-col class="d-flex align-center">
          <dea-button>작성취소</dea-button>
          <dea-button color="primary">작성완료</dea-button>
          <dea-checkbox
            v-model="checkbox"
            label="PDF파일로 저장"
          ></dea-checkbox>
        </v-col>
      </div>
    </section>

    <!-- 분석보고서 : Layer Popup -->
    <dea-dialog
      v-model="analysisReport"
      title="분석보고서"
      class-prop="dea-dialog dea-report"
      width="1100px"
    >
      <div class="box-wrap">
        <section class="dea-section dea-report-title">
          <div class="inner box-wrap box-wrap-fill">
            <dea-card>
              <v-row no-gutters>
                <v-col class="d-flex d-block">
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <div class="text fontsize-big2">사건번호 :</div>
                      <div class="text fontsize-big2">
                        2020교육10245
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex">
                      <div class="text fontsize-large3 font-bold">
                        선물거래금융투자상품2심사건
                      </div>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
            </dea-card>
          </div>
        </section>
        <section class="dea-section dea-report-detail">
          <div class="inner">
            <dea-card>
              <template slot="title"
                >BBK 주가조작사건 관련 증거파일 12,304개의 분석 결과</template
              >
              <div class="box-wrap">
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <div class="text">
                      <pre>
1. 사건 진행
 - BBK, Lke뱅크, e뱅크의 설립 :  1999년 4월, 김경준은 BBK 투자자문㈜을 자본금 5천만 원으로 설립했다.
 - 옵셔널벤처스 인수 및 BBK 등록 취소
  . 2001년 4월 8일, EBK증권중개는 사업을 자진철회했다.
  . 2001년 4월 27일, 김경준(미국인) 이 같은 해 2월 26일 인수한 옵셔널벤처스(구 광은창투)의 대표로 취임
  . 김경준의 횡령 : 2001년 4월 김경준이 옵셔널벤처스의 대표로 취임. 2001년 12월 380억 원의 회사 자금을 횡령

2. 관련 기업
 - 다스 : BBK 투자자들 중 가장 큰 투자자.
 - 옵셔널벤처스 : BBK 등은 창업투자회사인 옵셔널벤처스를 인수했다.
 - MAF펀드, AMPappas 등 각종 유령회사 : BBK는 MAF펀드의 전환사채(CB)를 운용. Lke뱅크가 1250만 달러 투자

3. 관련 증거
 - BBK 투자자문㈜ 사무실 압수 수색 : 하드디스크 14대, 노트북 23대, 휴대폰, 문서 11박스
 - 다스 사무실 압수 수색 : 하드디스크 14대, 노트북 23대, 휴대폰, 문서 11박스
 - 옵셔널벤쳐스 사무실 압수 수색 : 하드디스크 14대, 노트북 23대, 휴대폰, 문서 11박스

 ◆ 디지털포렌식 결과 총 증거 파일 300,627개, 통화내역 8,498건 분석
 ◆ 통화내역 중 증거력을 갖춘 23건의 통화내역 추출하여 첨부
                      </pre>
                    </div>
                  </v-col>
                </v-row>
              </div>
            </dea-card>
          </div>
        </section>
        <section class="dea-section dea-report-file">
          <div class="inner">
            <dea-card>
              <template slot="title">첨부 증거 내역 및 증거 파일</template>
              <div class="inner box-wrap">
                <dea-card>
                  <v-row no-gutters>
                    <v-col class="d-flex align-center">
                      <div class="text">통화내역 43건</div>
                      <v-divider vertical class="ma-0" />
                      <div class="text">계약내역 11건</div>
                      <v-divider vertical class="ma-0" />
                      <div class="text">파일 344건</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col class="d-flex align-center">
                      <v-list dense v-model="listItemModel">
                        <v-list-item>
                          <v-list-item-title
                            >증거파일
                            {{ listItems.length }}건</v-list-item-title
                          >
                        </v-list-item>
                        <template v-for="(listItem, i) in listItems">
                          <v-list-item :key="i">
                            <v-list-item-content class="flex-row">
                              <v-list-item-title
                                >{{ listItem.file }}
                              </v-list-item-title>
                              <v-list-item-subtitle class="ml-2"
                                >(증거번호 {{ listItem.number }})
                              </v-list-item-subtitle>
                            </v-list-item-content>
                          </v-list-item>
                        </template>
                      </v-list>
                    </v-col>
                  </v-row>
                </dea-card>
              </div>
              <div class="inner detail-view">
                <dea-card>
                  <template slot="title">
                    <v-icon>mdi-square-medium</v-icon>
                    김OO과 이XX의 통화 MAF펀드, AMPappas 설립
                  </template>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>분류</dea-label>
                    </v-col>
                    <v-col class="d-flex" cols="2">
                      <div class="text">통화내역</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>인물</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>일시</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통화시작 : YYYY-MM-DD HH:MM:SS
                      </div>
                      <div class="text">
                        통화종료 : YYYY-MM-DD HH:MM:SS
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>내용</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        수신자 : 김광호 (02-555-6666) (통화)
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>출처</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통신사실확인서파일제목.xls (증거번호 ########)
                      </div>
                    </v-col>
                  </v-row>
                </dea-card>
              </div>
              <div class="inner detail-view">
                <dea-card>
                  <template slot="title">
                    <v-icon>mdi-square-medium</v-icon>
                    김OO과 이XX의 통화 MAF펀드, AMPappas 설립
                  </template>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>분류</dea-label>
                    </v-col>
                    <v-col class="d-flex" cols="2">
                      <div class="text">통화내역</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>인물</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>일시</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통화시작 : YYYY-MM-DD HH:MM:SS
                      </div>
                      <div class="text">
                        통화종료 : YYYY-MM-DD HH:MM:SS
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>내용</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        수신자 : 김광호 (02-555-6666) (통화)
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>출처</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통신사실확인서파일제목.xls (증거번호 ########)
                      </div>
                    </v-col>
                  </v-row>
                </dea-card>
              </div>
              <div class="inner detail-view">
                <dea-card>
                  <template slot="title">
                    <v-icon>mdi-square-medium</v-icon>
                    김OO과 이XX의 통화 MAF펀드, AMPappas 설립
                  </template>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>분류</dea-label>
                    </v-col>
                    <v-col class="d-flex" cols="2">
                      <div class="text">통화내역</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>인물</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>일시</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통화시작 : YYYY-MM-DD HH:MM:SS
                      </div>
                      <div class="text">
                        통화종료 : YYYY-MM-DD HH:MM:SS
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>내용</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        수신자 : 김광호 (02-555-6666) (통화)
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>출처</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통신사실확인서파일제목.xls (증거번호 ########)
                      </div>
                    </v-col>
                  </v-row>
                </dea-card>
              </div>
              <div class="inner detail-view">
                <dea-card>
                  <template slot="title">
                    <v-icon>mdi-square-medium</v-icon>
                    김OO과 이XX의 통화 MAF펀드, AMPappas 설립
                  </template>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>분류</dea-label>
                    </v-col>
                    <v-col class="d-flex" cols="2">
                      <div class="text">통화내역</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>인물</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">발신자 : 홍길동 (010-1234-5678)</div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>일시</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통화시작 : YYYY-MM-DD HH:MM:SS
                      </div>
                      <div class="text">
                        통화종료 : YYYY-MM-DD HH:MM:SS
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>내용</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        수신자 : 김광호 (02-555-6666) (통화)
                      </div>
                    </v-col>
                  </v-row>
                  <v-row no-gutters>
                    <v-col cols="1">
                      <dea-label>출처</dea-label>
                    </v-col>
                    <v-col class="d-flex">
                      <div class="text">
                        통신사실확인서파일제목.xls (증거번호 ########)
                      </div>
                    </v-col>
                  </v-row>
                </dea-card>
              </div>
            </dea-card>
          </div>
        </section>
        <div class="btn-group">
          <v-col class="align-center">
            <dea-button color="primary">인쇄</dea-button>
            <dea-button>다운로드</dea-button>
          </v-col>
        </div>
        <div class="layout symbol">
          <img
            src="/img/prosecutio-service.png"
            alt="검찰 Prosecutio Service"
          />
        </div>
      </div>
    </dea-dialog>
    <!-- //분석보고서 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaTextarea from '../../components/common/DeaTextarea.vue'
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import CellButton from '@/components/grid/CellButton'

export default {
  name: 'Template703',
  components: {
    DeaTextarea
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      analysisReport: false,
      checkbox: true,

      // In Modal Popup
      listItemModel: [],
      listItems: [
        {
          file: '2011008R김경준통신사실확인서.xls',
          number: '########'
        },
        {
          file: '2011008R김경준통신사실확인서.xls',
          number: '########'
        },
        {
          file: '2011008R김경준통신사실확인서.xls',
          number: '########'
        },
        {
          file: '2011008R김경준통신사실확인서.xls',
          number: '########'
        },
        {
          file: '2011008R김경준통신사실확인서.xls',
          number: '########'
        }
      ]

      // Setting for Publishing
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
