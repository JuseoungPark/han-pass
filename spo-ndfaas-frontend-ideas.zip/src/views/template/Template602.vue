<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <div>
          프로그램 ID : UI-ID-TIAN-M0001, UI-ID-TIAN-P0001, UI-ID-TIAN-P0002,
          UI-ID-TIAN-P0003, UI-ID-TIAN-P0004, UI-ID-TIAN-P0005,
          UI-ID-TIAN-P0006, UI-ID-TIAN-M0001
        </div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <v-menu
              :disabled="disabled"
              :absolute="absolute"
              :open-on-hover="openOnHover"
              :close-on-click="closeOnClick"
              :close-on-content-click="closeOnContentClick"
              :offset-x="offsetX"
              :offset-y="offsetY"
            >
              <template v-slot:activator="{ on }">
                <v-btn v-on="on">Context Menu</v-btn>
              </template>
              <!-- Context Menu : Layer Popup -->
              <v-sheet class="dea-popup" style="width:180px;">
                <v-container class="pa-0">
                  <section class="dea-section">
                    <div class="inner">
                      <v-list dense v-model="contextList">
                        <v-list-item-group>
                          <template v-for="(contextItem, i) in contextItems">
                            <v-list-item :key="i">
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col
                                      class="d-flex align-center valign-middle"
                                    >
                                      {{ contextItem.text }}
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-divider
                              v-if="i + 1 < contextItems.length"
                              :key="i"
                              class="ma-0"
                            ></v-divider>
                          </template>
                        </v-list-item-group>
                      </v-list>
                    </div>
                  </section>
                </v-container>
              </v-sheet>
              <!-- //Context Menu : Layer Popup -->
            </v-menu>
            <dea-button @click="personSelect = !personSelect"
              >인물선택</dea-button
            >
            <dea-button @click="dateDealHistory = !dateDealHistory"
              >시간별 거래내역</dea-button
            >
            <dea-button @click="detailViewPopup = !detailViewPopup"
              >내역보기</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">화면저장</v-btn>
                </template>
                <!-- 화면저장 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:380px;">
                  <v-container class="pa-2">
                    <section class="dea-section">
                      <div class="inner">
                        <v-list dense>
                          <v-list-item-group v-model="viewSaveLists">
                            <v-list-item
                              v-for="(viewSaveItem, i) in viewSaveItems"
                              :key="i"
                              class="pa-1"
                            >
                              <v-list-item-content>
                                <v-list-item-title>
                                  {{ viewSaveItem.title }}
                                </v-list-item-title>
                                <v-list-item-subtitle>
                                  {{ viewSaveItem.date }}
                                </v-list-item-subtitle>
                              </v-list-item-content>
                              <v-list-item-action>
                                <dea-button>화면 불러오기</dea-button>
                              </v-list-item-action>
                            </v-list-item>
                            <v-divider
                              v-if="i + 1 < viewSaveItems.length"
                              :key="i"
                            ></v-divider>
                          </v-list-item-group>
                        </v-list>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>닫기</dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장 : Layer Popup -->
              </v-menu>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-col>
            <v-col class="d-flex align-right">
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">이벤트설정</v-btn>
                </template>
                <!-- 이벤트설정 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:580px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <v-tabs class="dea-tabs" v-model="tabsList">
                              <v-tab href="#tabList-1">특정일지정</v-tab>
                              <v-tab href="#tabList-2">목록보기</v-tab>
                            </v-tabs>
                          </v-col>
                        </v-row>
                      </div>
                    </section>
                    <section class="dea-section">
                      <v-tabs-items v-model="tabsList">
                        <v-tab-item value="tabList-1">
                          <div class="inner">
                            <dea-card>
                              <template slot="title">인물</template>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    placeholder="인물을 선택하세요"
                                    prepend-inner-icon="mdi-account-check-outline"
                                    append-icon="mdi-magnify"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                          <div class="inner">
                            <dea-card>
                              <template slot="title">날짜</template>
                              <v-row no-gutters>
                                <v-col class="d-flex d-block">
                                  <v-row no-gutters>
                                    <v-col class="d-flex">
                                      <dea-text-field v-model="date">
                                      </dea-text-field>
                                    </v-col>
                                  </v-row>
                                  <v-row no-gutters>
                                    <v-col class="d-flex">
                                      <v-date-picker
                                        v-model="date"
                                        no-title
                                        scrollable
                                        width="100%"
                                        class="box-wrap pa-0"
                                      ></v-date-picker>
                                    </v-col>
                                  </v-row>
                                </v-col>
                                <v-col class="d-flex d-block">
                                  <v-row no-gutters>
                                    <v-col class="d-flex">
                                      <dea-text-field v-model="date">
                                      </dea-text-field>
                                    </v-col>
                                  </v-row>
                                  <v-row no-gutters>
                                    <v-col class="d-flex">
                                      <v-date-picker
                                        v-model="date"
                                        no-title
                                        scrollable
                                        width="100%"
                                        class="box-wrap pa-0"
                                      ></v-date-picker>
                                    </v-col>
                                  </v-row>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                          <div class="inner">
                            <dea-card>
                              <template slot="title">시간</template>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-time-picker
                                    :close-on-content-click="false"
                                    :return-value.sync="time1"
                                    transition="scale-transition"
                                    offset-y
                                    use-seconds
                                  ></dea-time-picker>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                          <div class="inner">
                            <dea-card>
                              <template slot="title">제목</template>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    placeholder="이벤트 제목을 입력해주세요"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                          <div class="inner">
                            <dea-card>
                              <template slot="title">내용</template>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    placeholder="내용을 입력할 수 있습니다"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                        </v-tab-item>
                        <v-tab-item value="tabList-2">
                          <div class="inner">
                            <dea-card>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <v-date-picker
                                    v-model="date"
                                    no-title
                                    scrollable
                                    width="100%"
                                    class="box-wrap pa-0"
                                  ></v-date-picker>
                                </v-col>
                                <v-col class="d-flex">
                                  <v-date-picker
                                    v-model="date"
                                    no-title
                                    scrollable
                                    width="100%"
                                    class="box-wrap pa-0"
                                  ></v-date-picker>
                                </v-col>
                              </v-row>
                            </dea-card>
                          </div>
                          <div class="inner">
                            <dea-card>
                              <v-list dense>
                                <v-list-item-group v-model="viewLists">
                                  <v-list-item
                                    two-line
                                    v-for="(viewListItem, i) in viewListItems"
                                    :key="i"
                                    class="pa-1"
                                  >
                                    <v-list-item-action>
                                      <dea-checkbox
                                        :label="viewListItem.date"
                                        :value="viewListItem.state"
                                        class="dea-btn-checkbox"
                                      ></dea-checkbox>
                                    </v-list-item-action>
                                    <v-list-item-content class="ml-4">
                                      <v-list-item-title>
                                        {{ viewListItem.title }}
                                      </v-list-item-title>
                                      <v-list-item-subtitle>
                                        {{ viewListItem.person }}
                                      </v-list-item-subtitle>
                                      <v-list-item-subtitle>
                                        {{ viewListItem.message }}
                                      </v-list-item-subtitle>
                                    </v-list-item-content>
                                  </v-list-item>
                                  <v-divider
                                    v-if="i + 1 < contextItems.length"
                                    :key="i"
                                  ></v-divider>
                                </v-list-item-group>
                              </v-list>
                            </dea-card>
                          </div>
                        </v-tab-item>
                      </v-tabs-items>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>취소</dea-button>
                          <dea-button
                            prepend-icon="mdi-magnify"
                            color="primary"
                          >
                            확인
                          </dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //이벤트설정 : Layer Popup -->
              </v-menu>
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on" color="primary">분석설정</v-btn>
                </template>
                <!-- 분석설정 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:380px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <template slot="title">매체설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-0">
                              <dea-checkbox
                                v-model="checkbox1"
                                label="통화내역"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-checkbox
                                label="발신"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                              <dea-checkbox
                                label="착신"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-0">
                              <dea-checkbox
                                label="계좌내역"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-checkbox
                                label="출금"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                              <dea-checkbox
                                label="입금"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-0">
                              <dea-checkbox
                                label="파일내역"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-checkbox
                                label="중복파일"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">기간설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-date-picker
                                :close-on-content-click="false"
                                :return-value.sync="date"
                                transition="scale-transition"
                                offset-y
                                range
                                min-width="290px"
                              ></dea-date-picker>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="요일"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="dayList"
                                v-for="(dayItem, i) in dayItems"
                                :key="i"
                                :label="dayItem.day"
                                class="dea-btn-checkbox"
                                style="width:36px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="새벽"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="timeList"
                                v-for="(timeItem, i) in timeItems"
                                :key="i"
                                :label="timeItem.time"
                                class="dea-btn-checkbox"
                                style="width:40px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">인물설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-text-field
                                placeholder="인물을 검색하세요"
                                prepend-inner-icon="mdi-account-check-outline"
                                append-icon="mdi-magnify"
                              ></dea-text-field>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">키워드검색</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-text-field
                                placeholder="    인물에 대한 키워드를 입력하세요"
                                append-icon="mdi-magnify"
                              ></dea-text-field>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>닫기</dea-button>
                          <dea-button
                            prepend-icon="mdi-magnify"
                            color="primary"
                          >
                            조회
                          </dea-button>
                          <dea-button outlined prepend-icon="mdi-restore">
                            초기화
                          </dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //분석설정 : Layer Popup -->
              </v-menu>
              <dea-button icon textindent prepend-icon="mdi-restore"
                >초기화</dea-button
              >
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner chart-wrap">
        <dea-card class="pa-0">차트</dea-card>
      </div>
    </section>

    <!-- 인물 선택 : Layer Popup -->
    <dea-dialog v-model="personSelect" title="인물 선택" width="800px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="radio2s"
                  row
                  :mandatory="false"
                  :items="radio2Items"
                ></dea-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  v-model="select2Lists"
                  :items="select2Items"
                  label="그룹선택"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field
                  placeholder="인물을 검색하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>검색결과 (12)</v-tab>
                  </v-tabs>
                  <div class="text text-nowrap">
                    인물을 선택해주세요.
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleLeftModel" multiple>
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="'shuttleLeftItem' + i"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleLeftItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                outlined
                textindent
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                >우측으로 이동</dea-button
              >
              <dea-button
                icon
                outlined
                textindent
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                >좌측으로 이동</dea-button
              >
            </v-col>
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text" v-show="shuttleRightItems.length">
                    선택된 인물(2)
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleRightModel" multiple>
                    <template
                      v-for="(shuttleRightItem, i) in shuttleRightItems"
                    >
                      <v-list-item
                        :key="'shuttleRightItem' + i"
                        :value="shuttleRightItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleRightItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleRightItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personSelect = !personSelect"
            >취소</dea-button
          >
          <dea-button color="primary" @click="personSelect = !personSelect"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물 선택 : Layer Popup -->

    <!-- 시간별 거래내역 : Layer Popup -->
    <dea-dialog
      v-model="dateDealHistory"
      title="2020년 10월 01일 화요일 11:00:02"
      width="640px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card class="ba-0">
            <v-simple-table dense fixed-header>
              <template v-slot:default>
                <colgroup>
                  <col width="15%" />
                  <col width="15%" />
                  <col width="15%" />
                  <col width="" />
                  <col width="15%" />
                </colgroup>
                <thead>
                  <tr>
                    <th>발신자</th>
                    <th>착신자</th>
                    <th>통화량</th>
                    <th>기지국</th>
                    <th>내역보기</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>인물4</td>
                    <td>이순신</td>
                    <td>10:00</td>
                    <td>주소</td>
                    <td>
                      <a
                        class="text-decoration-none"
                        @click="detailViewPopup = !detailViewPopup"
                        >내역보기</a
                      >
                    </td>
                  </tr>
                  <tr>
                    <td>인물4</td>
                    <td>이순신</td>
                    <td>10:00</td>
                    <td>주소</td>
                    <td>
                      <a
                        class="text-decoration-none"
                        @click="detailViewPopup = !detailViewPopup"
                        >내역보기</a
                      >
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button @click="dateDealHistory = !dateDealHistory"
            >닫기</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //시간별 거래내역 : Layer Popup -->

    <!-- 내역보기 : Layer Popup -->
    <dea-dialog v-model="detailViewPopup" title="내역보기" width="800px">
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <v-list dense>
              <v-list-item-group v-model="detailViewLists">
                <v-list-item
                  class="flex-column pa-2"
                  v-for="(detailViewItem, i) in detailViewItems"
                  :key="i"
                >
                  <v-row no-gutters style="width:100%;">
                    <v-col class="d-flex">
                      <div class="text font-bold">통화내역</div>
                      <div class="text">{{ detailViewItem.time }}</div>
                    </v-col>
                    <v-col class="d-flex align-right">
                      <dea-checkbox
                        label="북마크"
                        class="ico-bookmark dea-btn--textindent"
                      ></dea-checkbox>
                    </v-col>
                  </v-row>
                  <div class="inner detail-view" style="width:100%;">
                    <dea-card class="ba-0">
                      <v-simple-table dense fixed-header>
                        <template v-slot:default>
                          <colgroup>
                            <col width="18%" />
                            <col width="18%" />
                            <col width="16%" />
                            <col width="16%" />
                            <col width="12%" />
                            <col width="" />
                          </colgroup>
                          <thead>
                            <tr>
                              <th>발신</th>
                              <th>착신</th>
                              <th>통화시작시간</th>
                              <th>통화종료시간</th>
                              <th>통화량</th>
                              <th>기지국</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                {{ detailViewItem.sender }}
                                <br />
                                {{ detailViewItem.sendPhone }}
                              </td>
                              <td>
                                {{ detailViewItem.receiver }}
                                <br />
                                {{ detailViewItem.receivePhone }}
                              </td>
                              <td>{{ detailViewItem.startTime }}</td>
                              <td>{{ detailViewItem.endTime }}</td>
                              <td>{{ detailViewItem.callTime }}</td>
                              <td>{{ detailViewItem.address }}</td>
                            </tr>
                          </tbody>
                        </template>
                      </v-simple-table>
                    </dea-card>
                  </div>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button @click="detailViewPopup = !detailViewPopup"
            >닫기</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //내역보기 : Layer Popup -->
  </v-container>
</template>

<script>
import DeaCheckbox from '../../components/common/DeaCheckbox.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaTextField from '../../components/common/DeaTextField.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'
// import DeaCheckbox from '../../components/common/DeaCheckbox.vue'

export default {
  name: 'Template601',
  components: {
    DeaCheckbox
    // DeaLabel,
    // DeaButton
    // DeaTextField
    // DeaCheckbox
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        },
        grpInfoView: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      fileDetailView: false,
      personSelect: false,
      nodeGrpMgmt: false,
      dateDealHistory: false,
      detailViewPopup: false,

      // In Modal Popup
      tabsList: null,
      time1: '',
      date: new Date().toISOString().substr(0, 10),
      checkbox1: true,
      viewSaveLists: '',
      viewSaveItems: [
        {
          title: '수사관1',
          date: '2020/08/29 14:30'
        },
        {
          title: '수사관2',
          date: '2020/08/30 14:30'
        },
        {
          title: '수사관3',
          date: '2020/08/31 14:30'
        }
      ],
      viewLists: '',
      viewListItems: [
        {
          title: '이벤트 제목 이벤트 제목',
          person: '홍길동 외 12명',
          message: '벤트 내용이 여기에 표시됩니다.',
          date: '2020/08/30 14시',
          state: true
        },
        {
          title: '이벤트 제목 이벤트 제목',
          person: '홍길동 외 12명',
          message: '벤트 내용이 여기에 표시됩니다.',
          date: '2020/08/30 14시'
        },
        {
          title: '이벤트 제목 이벤트 제목',
          person: '홍길동 외 12명',
          message: '벤트 내용이 여기에 표시됩니다.',
          date: '2020/08/30 14시'
        }
      ],
      detailViewLists: '',
      detailViewItems: [
        {
          time: '2020년 10월 31일 토 11:10:10',
          sender: '인물4',
          sendPhone: '010-1234-5678',
          receiver: '홍길동',
          receivePhone: '02-555-1234',
          startTime: '20201031 11:10:10',
          endTime: '20201031 11:20:10',
          callTime: '10:00',
          address: '서울시 종로 수송동'
        },
        {
          time: '2020년 10월 31일 토 11:10:10',
          sender: '인물4',
          sendPhone: '010-1234-5678',
          receiver: '홍길동',
          receivePhone: '02-555-1234',
          startTime: '20201031 11:10:10',
          endTime: '20201031 11:20:10',
          callTime: '10:00',
          address: '서울시 종로 수송동'
        },
        {
          time: '2020년 10월 31일 토 11:10:10',
          sender: '인물4',
          sendPhone: '010-1234-5678',
          receiver: '홍길동',
          receivePhone: '02-555-1234',
          startTime: '20201031 11:10:10',
          endTime: '20201031 11:20:10',
          callTime: '10:00',
          address: '서울시 종로 수송동'
        }
      ],
      radios: 'radio-1',
      radioItems: [
        {
          label: '통화',
          value: 'radio-1'
        },
        {
          label: '계좌',
          value: 'radio-2'
        },
        {
          label: '파일',
          value: 'radio-3'
        }
      ],
      radio2s: 'radio-1',
      radio2Items: [
        {
          label: '피의자',
          value: 'radio-1'
        },
        {
          label: '혐의자',
          value: 'radio-2'
        },
        {
          label: '참고인',
          value: 'radio-3'
        },
        {
          label: '피해자',
          value: 'radio-4'
        },
        {
          label: '기타',
          value: 'radio-5'
        }
      ],
      dayList: [],
      dayItems: [
        { day: '월' },
        { day: '화' },
        { day: '수' },
        { day: '목' },
        { day: '금' },
        { day: '토' },
        { day: '일' }
      ],
      timeList: [],
      timeItems: [
        { time: '1' },
        { time: '2' },
        { time: '3' },
        { time: '4' },
        { time: '5' },
        { time: '6' }
      ],
      shuttleLeftModel: [],
      shuttleLeftItems: [
        { title: '주요인물명1', subtitle: '010-1234-5678' },
        { title: '주요인물명2', subtitle: '010-2345-6789' },
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명4', subtitle: '010-4567-8901' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],
      shuttleRightModel: [],
      shuttleRightItems: [
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],

      // Setting for Publishing
      loader: null,
      loading: false,
      selectLists: '전체',
      selectItems: ['전체'],
      select2Lists: '인물그룹 전체',
      select2Items: ['인물그룹 전체', '그룹1', '그룹2', '그룹3'],
      conditionSelects: 'radio-1',
      conditionSelectItems: [
        {
          label: '기지국 중심',
          value: 'radio-1'
        },
        {
          label: '이동내역 중심',
          value: 'radio-2'
        }
      ],
      contextList: null,
      contextItems: [
        { text: '인물정보보기' },
        { text: '1인중심분석' },
        { text: '이벤트내역' }
      ],

      // 페이지내 좌측메뉴
      collapsibleLeft: false,
      open: ['전체', 'XX전자', '재무팀'],
      files: {
        person: 'mdi-account',
        cellphone: 'mdi-cellphone-iphone',
        notebook: 'mdi-laptop-windows'
      },
      folderTree: [],
      items: [
        {
          name: '전체',
          children: [
            {
              name: 'XX전자',
              children: [
                {
                  name: '재무팀',
                  children: [
                    {
                      name: '실사용자1',
                      file: 'person',
                      children: [
                        { name: '휴대폰', file: 'cellphone' },
                        { name: '노트북', file: 'notebook' }
                      ]
                    }
                  ]
                }
              ]
            },
            { name: 'YY전자' }
          ]
        }
      ]
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {
    // treeLeftClass() {
    //   return foldLeft ? 'aaa' : 'bbb'
    // }
  },
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
