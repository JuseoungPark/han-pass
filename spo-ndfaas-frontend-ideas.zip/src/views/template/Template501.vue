<template>
  <v-container class="file-process-status">
    <section class="dea-section">
      <div class="inner">
        <div>프로그램 ID : UI-ID-PRFI-M0001</div>
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap"> </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section status-field">
      <div class="inner">
        <dea-card class="mx-auto" title-class="align-left">
          <template slot="title"
            >파일처리현황
            <v-layout class="v-toolbar valign-middle flex-0 ml-4">
              <div class="info-message">
                <strong>2020-10-12 19:03</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-layout>
          </template>
          <v-card class="dea-card-field status-list-wrap">
            <v-card-actions>
              <div class="btn-group align-center">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <div
                      class="text pl-4 pr-4 fontsize-big3"
                      v-bind="attrs"
                      v-on="on"
                    >
                      전체처리대상 <strong>3,134</strong>
                    </div>
                  </template>
                  <span>최근 1주일이내 처리된 디지털증거수</span>
                </v-tooltip>
                <v-divider vertical class="ma-0" />
                <div class="text pl-4 pr-4 fontsize-big3">
                  처리진행중 <strong>34</strong>
                </div>
                <v-divider vertical class="ma-0" />
                <div class="text pl-4 pr-4 fontsize-big3">
                  실사용자 <strong>2</strong>
                </div>
              </div>
            </v-card-actions>
            <v-card-text>
              <div class="status-list">
                <v-list v-model="callStatusList" class="d-flex flex-wrap">
                  <v-list-item
                    v-for="(callStatusItem, i) in callStatusItems"
                    :key="i"
                    style="max-width:20%; height:140px"
                    class="active"
                  >
                    <v-list-item-content>
                      <v-list-item-subtitle
                        :class="[callStatusItem.stateClass]"
                      >
                        <span>{{ callStatusItem.subtitle }}</span>
                      </v-list-item-subtitle>
                      <v-list-item-title class="mt-2">
                        {{ callStatusItem.title }}
                      </v-list-item-title>
                    </v-list-item-content>
                  </v-list-item>
                </v-list>
              </div>
            </v-card-text>
          </v-card>
          <template slot="actions">
            <v-row>
              <v-col cols="3">
                <dea-button large block>북마크내역</dea-button>
              </v-col>
              <v-col cols="9">
                <v-btn large block color="primary">
                  파일내역분석 자세히보기
                  <v-icon>mdi-plus</v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section quick-menu">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title">
            디지털증거 통합분석 <strong>Quick Menu</strong>
          </template>
          <v-row>
            <v-col cols="3">
              <dea-button block large color="primary">
                <v-icon>mdi-account-alert</v-icon>
                주요인물관리
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button block large>
                <v-icon>mdi-account-multiple</v-icon>
                인물중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button block large>
                <v-icon>mdi-clock-time-three-outline</v-icon>
                시간중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button block large>
                <v-icon>mdi-map-marker-radius</v-icon>
                위치중심분석
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <!-- 통화내역처리현황 (성공/중복/실패) : Layer Popup -->
    <dea-dialog
      v-model="callHistoryStatus"
      title="통화내역처리현황"
      width="1100px"
    >
      <section class="dea-section">
        <div class="inner">
          <v-row no-gutters>
            <v-col class="d-flex valign-middle">
              <div class="info-message">
                <strong>2020-10-12 19:03</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-col>
          </v-row>
          <dea-card>
            <dea-grid :columns="gridInfo.callTotalHistory.columns">
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>완료파일(25)</v-tab>
                    <v-tab>실패파일(7)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner chart-wrap">
          <dea-card class="pa-0 ba-0">
            <template slot="title">
              선물거래금융투자상품2심사건
              <div class="layout v-toolbar align-right valign-middle">
                <div class="info-message">
                  <strong>2020-10-12 19:03</strong>
                  <label class="ml-2">업데이트</label>
                </div>
                <v-btn
                  text
                  class="dea-btn--textindent"
                  :loading="loading"
                  @click="loader = 'loading'"
                >
                  <v-icon>mdi-cached</v-icon>
                  갱신
                </v-btn>
              </div>
            </template>
            <div class="divide">
              <v-col>
                <dea-card>통화내역분석 파일등록현황 (차트)</dea-card>
              </v-col>
              <v-col>
                <dea-card>등록 통화파일</dea-card>
              </v-col>
            </div>
            <div class="divide mt-2">
              <v-col>
                <dea-card>통화내역 파일처리현황 (차트)</dea-card>
              </v-col>
              <v-col>
                <dea-card
                  >파일처리 성공률 (차트) / 실패파일 재처리율 (차트)</dea-card
                >
              </v-col>
              <v-col>
                <dea-card>통화 분석 실패사유 분석 (차트)</dea-card>
              </v-col>
            </div>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="callHistoryStatus = !callHistoryStatus"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //통화내역처리현황 (성공/중복/실패) : Layer Popup -->
  </v-container>
</template>

<script>
// import DeaButton from '../../components/common/DeaButton.vue'
// import DeaLabel from '@/components/common/DeaLabel'
// import DeaTextField from '@/components/common/DeaTextField'

export default {
  name: 'Template501',
  components: {
    // DeaButton
    // DeaLabel,
    // DeaTextField
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      isDetailSearch: false,

      // grid setting
      gridInfo: {
        callTotalHistory: {
          columns: []
        }
      },

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      callHistoryStatus: false,

      // In Modal Popup
      searchList: null,
      searchItems: [
        {
          text: '홍길동',
          date: '2020.10.06'
        },
        {
          text: '인천 횡령 사건',
          date: '2020.10.05'
        },
        {
          text: '사건번호2020교육203956',
          date: '2020.10.05'
        },
        {
          text: '박길동',
          date: '2020.10.04'
        }
      ],

      // Setting for Publishing
      loader: null,
      loading: false,
      callStatusList: null,
      callStatusItems: [
        {
          title: '문서파일',
          subtitle: '40'
        },
        {
          title: '압축파일',
          subtitle: '12'
        },
        {
          title: '동영상파일',
          subtitle: '140'
        },
        {
          title: '음성파일',
          subtitle: '42'
        },
        {
          title: '사진/그림',
          subtitle: '540'
        },
        {
          title: '이메일',
          subtitle: '1340'
        },
        {
          title: '암호파일',
          subtitle: '20'
        },
        {
          title: 'VIRUS파일',
          subtitle: '2'
        },
        {
          title: '색인실패파일',
          subtitle: '10'
        },
        {
          title: '기타',
          subtitle: '988'
        }
      ]
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
