<template>
  <v-container>
    <p>{{ $t('menu.operationPortal.extractionFileProcessStatus') }}</p>
  </v-container>
</template>

<script>
export default {
  name: 'ExtractionFileProcessStatus'
}
</script>
