<template>
  <v-container>
    <p>{{ $t('menu.operationPortal.incidentUsageStatus') }}</p>
  </v-container>
</template>

<script>
export default {
  name: 'IncidentUsageStatus'
}
</script>
