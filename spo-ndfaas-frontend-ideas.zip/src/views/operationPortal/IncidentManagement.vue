<template>
  <v-container>
    <p>{{ $t('menu.operationPortal.incidentManagement') }}</p>
  </v-container>
</template>

<script>
export default {
  name: 'IncidentManagement'
}
</script>
