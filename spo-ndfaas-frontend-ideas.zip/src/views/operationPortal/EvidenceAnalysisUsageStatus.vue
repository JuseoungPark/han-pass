<template>
  <v-container>
    <p>{{ $t('menu.operationPortal.evidenceAnalysisUsageStatus') }}</p>
  </v-container>
</template>

<script>
export default {
  name: 'EvidenceAnalysisUsageStatus'
}
</script>
