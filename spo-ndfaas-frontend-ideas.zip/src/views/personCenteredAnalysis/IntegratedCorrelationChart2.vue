<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <!-- <div>
          프로그램 ID : UI-ID-CHAN-M0001, UI-ID-CHAN-P0001, UI-ID-CHAN-P0002,
          UI-ID-CHAN-P0003
        </div> -->
        <v-row no-gutters>
          <v-col class="d-flex flex-wrap">
            <v-menu
              :disabled="disabled"
              :absolute="absolute"
              :open-on-hover="openOnHover"
              :close-on-click="closeOnClick"
              :close-on-content-click="closeOnContentClick"
              :offset-x="offsetX"
              :offset-y="offsetY"
            >
              <template v-slot:activator="{ on }">
                <v-btn v-on="on">Context Menu</v-btn>
              </template>
              <!-- Context Menu : Layer Popup -->
              <v-sheet class="dea-popup" style="width:180px;">
                <v-container class="pa-0">
                  <section class="dea-section">
                    <div class="inner">
                      <v-list dense v-model="contextList">
                        <v-list-item-group>
                          <template v-for="(contextItem, i) in contextItems">
                            <v-list-item :key="i">
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col
                                      class="d-flex align-center valign-middle"
                                    >
                                      {{ contextItem.text }}
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-divider
                              v-if="i + 1 < contextItems.length"
                              :key="i"
                              class="ma-0"
                            ></v-divider>
                          </template>
                        </v-list-item-group>
                      </v-list>
                    </div>
                  </section>
                </v-container>
              </v-sheet>
              <!-- //Context Menu : Layer Popup -->
            </v-menu>
            <dea-button @click="personSelect = !personSelect"
              >인물선택</dea-button
            >
            <dea-button @click="nodeGrpMgmt = !nodeGrpMgmt"
              >상관도 노드그룹관리</dea-button
            >
          </v-col>
        </v-row>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    v-on="on"
                    text
                    class="dea-btn--textindent"
                    :loading="loading"
                    @click="loader = 'loading'"
                  >
                    <v-icon>mdi-cached</v-icon>
                    갱신
                  </v-btn>
                </template>
                <!-- 화면저장List : Layer Popup -->
                <v-sheet class="dea-popup" style="width:380px;">
                  <v-container class="pa-2">
                    <section class="dea-section">
                      <div class="inner">
                        <v-list dense>
                          <v-list-item-group v-model="viewSaveLists">
                            <fragment
                              v-for="(viewSaveItem, i) in viewSaveItems"
                              :key="i"
                            >
                              <v-list-item class="pa-1">
                                <v-list-item-content>
                                  <v-list-item-title>
                                    {{ viewSaveItem.title }}
                                  </v-list-item-title>
                                  <v-list-item-subtitle>
                                    {{ viewSaveItem.date }}
                                  </v-list-item-subtitle>
                                </v-list-item-content>
                                <v-list-item-action>
                                  <dea-button
                                    @click="layoutLoad(viewSaveItem.value)"
                                    >화면 불러오기</dea-button
                                  >
                                </v-list-item-action>
                              </v-list-item>
                              <v-divider
                                v-if="i + 1 < viewSaveItems.length"
                                :key="i"
                              ></v-divider>
                            </fragment>
                          </v-list-item-group>
                        </v-list>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>닫기</dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장List : Layer Popup -->
              </v-menu>
              <v-btn @click="layoutSave">화면저장</v-btn>
            </v-col>
            <v-col class="d-flex align-center">
              <dea-select
                v-model="targetPerson"
                :items="targetPersonList"
                label="대상인물"
                style="width:120px;"
                class="flex-0"
                @change="onChangeTargetPerson"
              ></dea-select>
              <dea-select
                v-model="commonNode"
                :items="commonNodeList"
                label="공통노드"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <dea-select
                label="노드그룹"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="!closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">
                    <v-icon>mdi-magnify</v-icon>
                    인물찾기
                  </v-btn>
                </template>
                <!-- 인물이름입력팝업 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:400px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <dea-text-field
                              v-model="nodename"
                              label="분석하고자 하는 인물을 검색하세요"
                              append-icon="mdi-magnify"
                              @keydown.enter="nodeFinde"
                            ></dea-text-field>
                          </v-col>
                        </v-row>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //인물이름입력팝업 : Layer Popup -->
              </v-menu>
            </v-col>
            <v-col class="d-flex align-right">
              <dea-select
                v-model="layout"
                :items="layoutList"
                label="보기설정"
                style="width:120px;"
                class="flex-0"
                @change="layoutChange()"
              ></dea-select>
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="!closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on" color="primary">분석설정</v-btn>
                </template>
                <!-- 분석설정 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:380px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <template slot="title">매체설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-checkbox
                                v-model="checkbox1"
                                label="통화"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                              <dea-checkbox
                                label="계좌"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                              <dea-checkbox
                                label="이메일"
                                class="dea-btn-checkbox"
                                disabled
                              ></dea-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">기간설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="요일"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="dayList"
                                v-for="(dayItem, idx) in dayItems"
                                :key="idx"
                                :label="dayItem.day"
                                class="dea-btn-checkbox"
                                style="width:36px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col class="d-flex flex-1" cols="2">
                              <dea-checkbox
                                label="새벽"
                                class="dea-btn-checkbox"
                              ></dea-checkbox>
                            </v-col>
                            <v-col class="d-flex flex-1">
                              <v-checkbox
                                v-model="timeList"
                                v-for="(timeItem, i) in timeItems"
                                :key="i"
                                :label="timeItem.time"
                                class="dea-btn-checkbox"
                                style="width:40px;"
                              ></v-checkbox>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">인물설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dea-text-field
                                label="인물을 검색하세요"
                                prepend-inner-icon="mdi-account-check-outline"
                                append-icon="mdi-magnify"
                              ></dea-text-field>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="inner">
                        <dea-card>
                          <template slot="title">그외 조건</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <v-tabs class="dea-tabs">
                                <v-tab>통화</v-tab>
                              </v-tabs>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1">
                              <dea-label>빈도</dea-label>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-text-field label="최소"></dea-text-field>
                              <div class="text">~</div>
                              <dea-text-field label="최대"></dea-text-field>
                              <div class="text text-nowrap">(단위:건)</div>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1">
                              <dea-label>빈도</dea-label>
                            </v-col>
                            <v-col class="d-flex">
                              <dea-text-field label="최소"></dea-text-field>
                              <div class="text">~</div>
                              <dea-text-field label="최대"></dea-text-field>
                              <div class="text text-nowrap">
                                (단위:건)
                              </div>
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button>닫기</dea-button>
                          <dea-button
                            prepend-icon="mdi-magnify"
                            color="primary"
                          >
                            조회
                          </dea-button>
                          <dea-button outlined prepend-icon="mdi-restore">
                            초기화
                          </dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //분석설정 : Layer Popup -->
              </v-menu>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <!-- 차트 -->
    <section class="dea-section">
      <div class="inner chart-wrap">
        <dea-card class="pa-0">
          <dea-cytoscape
            :layoutOpts="layoutOpts"
            :layoutSaves="viewSaveItems"
            ref="chart"
            :style="`position: relative; height:${height}px;`"
            :jsonDataFile="`/istry-analy/display?incdntId=${incidentInfo.id}`"
            :jsonStyleFile="'/api/cy-style.json'"
            @person-info="onPersonInfo"
            @call-history-info="onCallHistoryInfo"
          />
        </dea-card>
      </div>
    </section>
    <!-- // 차트 -->

    <!-- 인물 선택 : Layer Popup -->
    <dea-dialog v-model="personSelect" title="인물 선택" width="800px">
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="radio2s"
                  row
                  :mandatory="false"
                  :items="radio2Items"
                ></dea-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  v-model="select2Lists"
                  :items="select2Items"
                  label="그룹선택"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field
                  placeholder="인물을 검색하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>검색결과 (12)</v-tab>
                  </v-tabs>
                  <div class="text text-nowrap">
                    인물을 선택해주세요.
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleLeftModel" multiple>
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="'shuttleLeftItem' + i"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleLeftItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                outlined
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
              ></dea-button>
              <dea-button
                icon
                outlined
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
              ></dea-button>
            </v-col>
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text" v-show="shuttleRightItems.length">
                    선택된 인물(2)
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleRightModel" multiple>
                    <template
                      v-for="(shuttleRightItem, i) in shuttleRightItems"
                    >
                      <v-list-item
                        :key="'shuttleRightItem' + i"
                        :value="shuttleRightItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleRightItem.title"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleRightItem.subtitle"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="personSelect = !personSelect"
            >취소</dea-button
          >
          <dea-button color="primary" @click="personSelect = !personSelect"
            >확인</dea-button
          >
        </v-col>
      </div>
    </dea-dialog>
    <!-- //인물 선택 : Layer Popup -->

    <!-- 상관도 노드그룹관리 : Layer Popup -->
    <dea-dialog v-model="nodeGrpMgmt" title="상관도 노드그룹관리" width="800px">
      <v-layout class="divide pa-0 ba-0">
        <v-col cols="5">
          <v-tabs class="dea-tabs" vertical>
            <v-tab class="align-left">
              <span>노드1 그룹(13명)</span>
              <dea-button icon outlined prepend-icon="mdi-close"></dea-button>
            </v-tab>
            <v-tab class="align-left">
              <span>노드2 그룹(2명)</span>
              <dea-button icon outlined prepend-icon="mdi-close"></dea-button>
            </v-tab>
            <v-tab class="align-left">
              <span>노드3 그룹(10명)</span>
              <dea-button icon outlined prepend-icon="mdi-close"></dea-button>
            </v-tab>
            <v-tab class="align-left">
              <span>노드4 그룹(200명)</span>
              <dea-button icon outlined prepend-icon="mdi-close"></dea-button>
            </v-tab>
          </v-tabs>
          <section class="dea-section">
            <div class="inner"></div>
            <v-row no-gutters>
              <v-col class="d-flex position-relative">
                <!-- <v-snackbar
                  :timeout="-1"
                  :value="true"
                  absolute
                  centered
                  top
                  rounded
                  elevation="0"
                  color="info"
                  class="d-flex"
                >
                  <v-icon class="mr-2">mdi-check-bold</v-icon>
                  <div class="text word-break">
                    그룹을 삭제하면 해당 그룹으로 등록된 인물의 그룹 정보가
                    초기화됩니다.
                  </div>
                </v-snackbar> -->
              </v-col>
            </v-row>
          </section>
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <v-row no-gutters>
                  <v-col class="d-flex">
                    <dea-text-field
                      placeholder="신규 추가할 그룹명을 입력하세요"
                    ></dea-text-field>
                    <dea-button>추가</dea-button>
                  </v-col>
                </v-row>
              </dea-card>
            </div>
          </section>
        </v-col>
        <v-col>
          <section class="dea-section">
            <div class="inner grid-wrap">
              <dea-card>
                <!-- <dea-grid :columns="gridInfo.grpInfoView.columns"></dea-grid> -->
              </dea-card>
            </div>
          </section>
        </v-col>
      </v-layout>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="nodeGrpMgmt = !nodeGrpMgmt"
            >취소</dea-button
          >
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //상관도 노드그룹관리 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :_params.sync="individualDetailParams"
      :visible.sync="dialogIndividualDetailSow"
    />
    <!-- //인물정보 상세 : Layer Popup -->

    <!-- 발신건수 및 통화량 : Layer Popup -->
    <dea-dialog
      v-model="dialogSendCallCountCallTotalSow"
      title="발신건수 및 통화량"
      width="800px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card class="ba-0">
            <v-simple-table dense fixed-header>
              <template v-slot:default>
                <colgroup>
                  <col width="20%" />
                  <col width="20%" />
                  <col width="20%" />
                  <col width="20%" />
                  <col width="20%" />
                </colgroup>
                <thead>
                  <tr>
                    <th>발신자</th>
                    <th>수신자</th>
                    <th>건수</th>
                    <th>통화량</th>
                    <th>내역보기</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{{ sendCallCountCallTotalData.fromNm }}</td>
                    <td>{{ sendCallCountCallTotalData.toNm }}</td>
                    <td class="align-right">
                      {{ sendCallCountCallTotalData.cnt }}
                    </td>
                    <td>{{ sendCallCountCallTotalData.talkQty }}</td>
                    <td>
                      <a class="text-decoration-none" @click="showGrid"
                        >자세히보기</a
                      >
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="
              dialogSendCallCountCallTotalSow = !dialogSendCallCountCallTotalSow
            "
            >확인</dea-button
          >
          <!-- <v-icon>mdi-flag-variant</v-icon> -->
        </v-col>
      </div>
    </dea-dialog>
    <!-- //발신건수 및 통화량 : Layer Popup -->

    <!-- 통화통합내역조회 : Layer Popup -->
    <!-- <dialog-call-history
      ref="dialogCallHistory"
      :jsonCallDataFile.sync="jsonCallDataFile"
      :params.sync="sendCallCountCallTotalData"
      :visible.sync="dialogSendCallCountCallSow"
    /> -->
    <!-- // 통화통합내역조회 -->
    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->
  </v-container>
</template>
<script>
import DeaCytoscape from '@/components/graphs/DeaCytoscape'
// import DialogIndividual from '@/views/personCenteredAnalysis/Dialog/DialogIndividual'
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'
import DialogCallHistory from '@/views/callHistory/Dialog/DialogCallHistory' // 통화내역
// import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'IntegratedCorrelationChart2',
  mixins: [apiMixin],
  components: {
    DeaCytoscape,
    DialogIndividual,
    DialogCallHistory
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // 차트 높이
      height: 500,

      // 노드찾기 이름
      nodename: '',

      // 팝업창
      dialogIndividualDetailSow: false, // 인물정보 상세(팝업호출)
      dialogSendCallCountCallTotalSow: false, // 발신건수 및 통화량(팝업호출)
      dialogSendCallCountCallSow: false, //  통화내역 상세(팝업호출)

      // 팝업창 DATA
      individualDetailParams: {}, // 인물정보 상세
      sendCallCountCallTotalData: {}, // 발신건수 및 통화량

      // chart data
      // jsonStyleFile: '/api/cy-style.json',

      // jsonCallDataFile: `${this.api}/talk/unity-dtlses?incdntId=${this.incdntId}`, // 통화내역 상세
      // jsonDataFile: this.$api.analysis.get(
      //   `/istry-analy/display?incdntId=${this.incdntId}`
      // ), // 인물상관도
      // jsonDataFile: `${this.api}/istry-analy/display?incdntId=${this.incdntId}`, // 인물상관도
      // jsonPersonDataFile: `${this.api}/isrty/isrty?incdntId=${this.incdntId}`, // 인물 상세

      // chart test data
      // jsonCallDataFile: '/api/cy-call-data-api.json', // 통화내역 상세 테스트
      // jsonDataFile: '/api/cy-data-api.json', // 인물상관도 테스트
      // jsonDataFile: '/api/cy-data1.json', // 인물상관도 테스트
      // jsonPersonDataFile: '/api/cy-person-data-api.json', // 인물정보 상세 테스트

      // 쓰이는곳이 없음
      isDetailSearch: false,

      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: true,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      fileDetailView: false,
      personSelect: false,
      nodeGrpMgmt: false,

      // In Modal Popup
      checkbox1: true,
      radios: 'radio-1',
      radioItems: [
        {
          label: '통화',
          value: 'radio-1'
        },
        {
          label: '계좌',
          value: 'radio-2'
        },
        {
          label: '파일',
          value: 'radio-3'
        }
      ],
      radio2s: 'radio-1',
      radio2Items: [
        {
          label: '피의자',
          value: 'radio-1'
        },
        {
          label: '혐의자',
          value: 'radio-2'
        },
        {
          label: '참고인',
          value: 'radio-3'
        },
        {
          label: '피해자',
          value: 'radio-4'
        },
        {
          label: '기타',
          value: 'radio-5'
        }
      ],
      dayList: [],
      dayItems: [
        { day: '월' },
        { day: '화' },
        { day: '수' },
        { day: '목' },
        { day: '금' },
        { day: '토' },
        { day: '일' }
      ],
      timeList: [],
      timeItems: [
        { time: '1' },
        { time: '2' },
        { time: '3' },
        { time: '4' },
        { time: '5' },
        { time: '6' }
      ],
      shuttleLeftModel: [],
      shuttleLeftItems: [
        { title: '주요인물명1', subtitle: '010-1234-5678' },
        { title: '주요인물명2', subtitle: '010-2345-6789' },
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명4', subtitle: '010-4567-8901' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],
      shuttleRightModel: [],
      shuttleRightItems: [
        { title: '주요인물명3', subtitle: '010-3456-7890' },
        { title: '주요인물명5', subtitle: '010-3456-7890' }
      ],

      // Setting for Publishing
      loader: null,
      loading: false,
      selectLists: '전체',
      selectItems: ['전체'],
      select2Lists: '인물그룹 전체',
      select2Items: ['인물그룹 전체', '그룹1', '그룹2', '그룹3'],
      conditionSelects: 'radio-1',
      conditionSelectItems: [
        {
          label: '기지국 중심',
          value: 'radio-1'
        },
        {
          label: '이동내역 중심',
          value: 'radio-2'
        }
      ],
      contextList: null,
      contextItems: [
        { text: '인물정보보기' },
        { text: '노드그룹생성' },
        { text: '노드그룹축소' },
        { text: '노드그룹확장' },
        { text: '1인중심분석' },
        { text: '매체중심분석' }
      ],

      // 페이지내 좌측메뉴
      collapsibleLeft: false,
      open: ['전체', 'XX전자', '재무팀'],
      files: {
        person: 'mdi-account',
        cellphone: 'mdi-cellphone-iphone',
        notebook: 'mdi-laptop-windows'
      },
      folderTree: [],
      items: [
        {
          name: '전체',
          children: [
            {
              name: 'XX전자',
              children: [
                {
                  name: '재무팀',
                  children: [
                    {
                      name: '실사용자1',
                      file: 'person',
                      children: [
                        { name: '휴대폰', file: 'cellphone' },
                        { name: '노트북', file: 'notebook' }
                      ]
                    }
                  ]
                }
              ]
            },
            { name: 'YY전자' }
          ]
        }
      ],

      // 화면저장(node layout save)
      viewSaveLists: '',
      viewSaveItems: [
        // {
        //   title: '수사관1',
        //   date: '2020/08/29 14:30'
        // },
        // {
        //   title: '수사관2',
        //   date: '2020/08/30 14:30'
        // },
        // {
        //   title: '수사관3',
        //   date: '2020/08/31 14:30'
        // }
      ],

      // 대상인물
      targetPerson: [],
      targetPersonList: [
        { text: '주요인물간', value: '주요인물간' },
        { text: '주요인물중심', value: '주요인물중심' },
        { text: '전체인물중심', value: '전체인물중심' },
        { text: '1인중심', value: '1인중심' }
      ],

      // 공통노드
      commonNode: [],
      commonNodeList: [
        { text: '공통노드5', value: '공통노드5' },
        { text: '공통노드4', value: '공통노드4' },
        { text: '공통노드3', value: '공통노드3' },
        { text: '공통노드2', value: '공통노드2' }
      ],

      // 그래프 사용.
      layoutOpts: null,
      // layoutSaves: [],
      layout: {},
      layoutList: [
        {
          text: '랜덤',
          icon: 'mdi-clipboard-edit-outline',
          value: {
            name: 'random',
            randomize: true,
            flow: null
          }
        },
        // {
        //   text: 'y축',
        //   icon: 'mdi-arrow-down',
        //   value: {
        //     name: 'cola',
        //     flow: { axis: 'y', minSeparation: 30 }
        //   }
        // },
        {
          text: '원형',
          icon: 'mdi-radiobox-blank',
          value: {
            name: 'circle',
            randomize: true,
            flow: null
          }
        },
        {
          text: '중심 원형',
          icon: 'mdi-radiobox-marked',
          value: {
            name: 'concentric',
            randomize: true,
            flow: null
            // concentric: function(node) {
            //   return node.degree()
            // },
            // levelWidth: function(nodes) {
            //   return 70
            // }
          }
        },
        {
          text: '그리드형',
          icon: '',
          value: {
            name: 'grid',
            randomize: false,
            flow: null
          }
        },
        {
          text: '계층형',
          icon: 'mdi-apps',
          value: {
            name: 'dagre',
            randomize: false,
            flow: null
          }
        }
      ]
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  computed: {
    // ...mapGetters(['incdntId'])
    // api() {
    //   // return 'http://172.50.16.193:8090'
    //   return 'http://10.220.140.208:8090'
    // }
  },
  mounted() {},
  methods: {
    // 차트 모양 변경
    layoutChange() {
      console.log('차트 모양 변경>', this.layout)
      if (this.layout.name === 'circle' || this.layout.name === 'concentric') {
        this.height = 1200
      } else {
        this.height = 500
      }
      this.layoutOpts = this.layout
    },
    layoutSave() {
      // console.log('save', this.viewSaveItems.length)
      this.$refs.chart.layoutSave()
    },
    layoutLoad(data) {
      this.$refs.chart.layoutLoad(data)
    },
    layoutSelectedNode() {
      this.$refs.chart.layoutSelectedNode()
    },
    selectedNodeLock() {
      this.$refs.chart.selectedNodeLock()
    },
    // 대상인물 변경시 새로운 노드/엣지 호출.
    onChangeTargetPerson() {
      // console.log('removeData')
      this.$refs.chart.removeData()
      // 새로운 인물을 대상으로 노드/엣지 데이터 호출.
      this.$api.private.get('/api/cy-data1.json').then((res) => {
        this.layoutLoad(res.data)
        // this.reset()
        console.log('차트모양', this.layoutOpts)
        const opts = this.layoutOpts
          ? this.layoutOpts
          : { name: 'random', randomize: true, flow: null }
        this.$refs.chart.layoutChange(opts)
      })
    },
    // 노드 선택후 인물정보(팝업) 호출
    onPersonInfo(data) {
      console.log(`[넘어온 노드정보] id: ${data.id}, name ${data.name}`)

      if (data.id) {
        this.individualDetailParams = { data: { isrtyId: data.id } }
      }
      this.dialogIndividualDetailSow = true
    },
    // 엣지 선택후 통화이력정보(팝업) 호출
    onCallHistoryInfo(data) {
      console.log(
        `[넘어온 엣지정보]
        source: ${data.source},
        target: ${data.target},
        cnt: ${data.cnt}`
      )
      this.sendCallCountCallTotalData = data
      this.dialogSendCallCountCallTotalSow = true
    },
    // 상세통화이력(팝업) 호출
    showGrid() {
      console.log(
        '통화통합내역팝업 호출',
        this.sendCallCountCallTotalData.fromNm
      )
      this.$refs.dialogCallHistory.show({
        event: 'outgoingNumber',
        data: { outgoingNumber: this.sendCallCountCallTotalData.fromNm }
      })
      this.dialogSendCallCountCallTotalSow = false
      // this.dialogSendCallCountCallSow = true
    },
    onCellButtonClicked(params) {
      if (params.event == 'outgoingNumber') {
        params.data['outgoingNumber'] = params.value
        this.$refs.dialogCallHistory.show(params)
      }
    },
    // 노드찾기
    nodeFinde() {
      console.log('노드찾기', this.nodename)
      this.$refs.chart.center(this.nodename)
    }
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
