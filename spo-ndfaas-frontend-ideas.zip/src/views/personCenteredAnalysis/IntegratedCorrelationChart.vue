<template>
  <v-container ref="container">
    <article>
      <section class="dea-section">
        <div class="search-box">
          <v-card>
            <!-- <v-card-title>
              <p>
                {{
                  $t('menu.personCenteredAnalysis.integratedCorrelationChart')
                }}
              </p>
            </v-card-title> -->
            <v-card-title>3D 차트</v-card-title>
            <v-card-subtitle>노드 찾기</v-card-subtitle>
            <v-card-text>
              <v-row no-gutters>
                <v-col cols="1">
                  <v-subheader>노드 검색</v-subheader>
                </v-col>
                <v-col class="d-flex">
                  <v-text-field
                    dense
                    outlined
                    label="노드 이름"
                    placeholder="이름을 입력하세요."
                    @keyup.enter="onkeydownHandler"
                  ></v-text-field>
                  <!-- <v-btn color="primary" @click="onClickHandler"
                    >노드 찾기</v-btn
                  > -->
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </div>
      </section>

      <section class="dea-section">
        <v-card ref="card">
          <dea-3d-force-graph
            json-file="miserables_3d.json"
            :findNodeName="findNodeName"
            :parentWidth="parentWidth"
          />
        </v-card>
      </section>
    </article>
  </v-container>
</template>

<script>
import Dea3dForceGraph from '@/components/graphs/Dea3dForceGraph.vue'
export default {
  name: 'IntegratedCorrelationChart',
  components: {
    Dea3dForceGraph
  },
  data() {
    return {
      findNodeName: '',
      parentEl: null,
      parentWidth: 0
    }
  },
  mounted() {
    this.addParentWidth()
  },
  watch: {
    parentEl() {
      if (this.parentEl !== null) this.parentWidth = this.parentEl.clientWidth
    }
  },
  methods: {
    mainResize(e) {
      console.log(e)
    },
    addParentWidth() {
      this.parentEl = this.$refs.card.$el
      this.parentWidth = this.$refs.card.$el.clientWidth
    },
    onkeydownHandler(e) {
      this.findNodeName = e.target.value
    }
  }
}
</script>
