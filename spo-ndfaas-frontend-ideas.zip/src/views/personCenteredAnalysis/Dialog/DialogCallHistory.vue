<template>
  <!-- 인물간 통화내역 : Layer Popup -->
  <dea-dialog
    v-model="visible"
    title="인물간 통화내역"
    width="940px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          row-selection-multiple
          suppress-row-click-selection
          :columns="columns"
          :config="config"
        >
          <!-- 탭버튼 영역 -->
          <template #header-left>
            <v-col class="d-flex">
              <v-tabs :show-arrows="false" class="dea-tabs">
                <v-tab>총 {{ talkDtlsAllCnt }}건</v-tab>
              </v-tabs>
            </v-col>
          </template>
          <!-- // 탭버튼 영역 -->
        </dea-grid>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >닫기</dea-button
        >
      </v-col>
    </div>
  </dea-dialog>
  <!-- // 인물간 통화내역 : Layer Popup -->
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import { GridFormatter } from '@/utils/GridFormatter'
// import CellBookmark from '@/components/grid/CellBookmark'
// import CellExcept from '@/components/grid/CellExcept'
// import GridCommBtn from '../include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'
export default {
  name: 'DialogCallHistory',
  mixins: [GridCommMixins, eventBus],
  // components: {
  //   GridCommBtn
  // },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    jsonCallDataFile: {
      type: String,
      default: ''
    },
    params: {
      type: Object,
      default: undefined
    }
  },
  data() {
    return {
      talkDtlsAllCnt: 0,
      api: this.jsonCallDataFile,
      // fieldkey: '',
      // fieldvalue: '',
      config: {
        excelButton: false,
        pagination: {
          limitView: false,
          limit: 5
        },
        height: 'fixed'
      },
      columns: [
        // {
        //   headerName: '',
        //   headerGroupComponent: CustomHeaderGroup,
        //   children: [
        //     {
        //       headerName: '',
        //       field: 'header-00',
        //       width: 20,
        //       headerCheckboxSelection: true,
        //       headerCheckboxSelectionFilteredOnly: true,
        //       checkboxSelection: true
        //     },
        //     {
        //       headerName: '북마크',
        //       field: 'bookmark',
        //       width: 50,
        //       cellRendererFramework: CellBookmark,
        //       cellClass: () => {
        //         return 'cell-bookmark'
        //       },
        //       valueGetter: function(params) {
        //         return params.value ? '북마크해제' : '북마크설정'
        //       }
        //     },
        //     {
        //       headerName: '제외',
        //       field: 'except',
        //       width: 50,
        //       cellRendererFramework: CellExcept,
        //       cellRendererParams: {
        //         except: 'Y'
        //       }
        //     }
        //   ]
        // },
        {
          headerName: '발신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '실사용자',
              field: 'dsptchUserNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'dsptchTelno',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '착신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '실사용자',
              field: 'rcvUserNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'rcvTelno',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '통화정보',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '통화시작',
              field: 'talkBgngDt',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통화시간',
              field: 'talkQy',
              sortable: true,
              unSortIcon: true,
              valueFormatter: GridFormatter.timeWithColons,
              width: 80,
              cellClass: 'align-right'
            },
            {
              headerName: '구분',
              field: 'talkTyNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '기지국',
              field: 'linkRelateLcNm',
              sortable: true,
              unSortIcon: true
            }
          ]
        }
      ]
    }
  },
  methods: {
    show() {
      // 통화내역 상세
      let api = this.jsonCallDataFile
      api += `&requestPage=${1}`
      api += `&rowCntByPage=${100}`
      api += `&dsptchRlUserIds=${this.params.source}`
      api += `&rcvRlUserIds=${this.params.target}`

      // http://10.220.140.208:8090/talk-unity-dtls-list/1160100000000000373&requestPage=1&rowCntByPage=100&dsptchRlUserIds=T10439377ca23f9244f0aac81abe1e618dbd36&rcvRlUserIds=T1044c6d1d034c654f639cc883e4e94277e781
      // http://10.220.140.208:8090/talk/unity-dtlses?dsptchRlUserIds=T104dced5ddbf37949669956a2993af1e48609&incdntId=1160100000000000373&requestPage=1&rowCntByPage=20
      this.$api.analysis.get(api).then((res) => {
        console.log('받아온 통화내역', res.data.result)
        const rows = res.data.result

        if (!rows) {
          return
        }
        this.$refs.grid.rowData = rows
        this.talkDtlsAllCnt = rows.length
        console.log('>>', rows.length)
        this.$toast(`총${this.talkDtlsAllCnt}건`)
      })
    },
    hide() {
      this.$emit('update:visible', !this.visible)
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>
