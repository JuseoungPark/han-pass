<template>
  <dea-dialog
    v-model="visible"
    title="인물정보"
    width="940px"
    @dialog:close="onDialogClose"
  >
    <!-- 인물정보 -->
    <section v-if="filter.type === 'person'" class="dea-section">
      <div class="search-box">
        <dea-card>
          <template slot="title">개인정보</template>
          <v-layout class="divide">
            <v-col class="flex-0">
              <v-img
                src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"
                width="140"
                style="padding-top:66.66%;"
              ></v-img>
            </v-col>
            <v-col>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>이름</dea-label>
                </v-col>
                <v-col class="d-flex flex-0">
                  <div class="text">
                    {{ personInfo && personInfo.isrtyNm }}
                  </div>
                </v-col>
                <v-col class="d-flex pl-1">
                  <v-chip small>{{
                    personInfo && isrtyTyCode(personInfo.isrtyPrsnTyCode)
                  }}</v-chip>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>별칭</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <!-- <div class="text">
                    {{ personInfo && personInfo.isrtyNmResVos }}
                  </div> -->
                  <template v-for="(item, index) in personInfo.isrtyNmResVos">
                    <div class="text mr-4" :key="index">
                      {{ item.isrtyNm }}
                    </div>
                  </template>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>회사</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">
                    {{ personInfo && personInfo.upperIsrtyPsitnOrgnztNm }}
                  </div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>부서</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">
                    {{ personInfo && personInfo.isrtyPsitnOrgnztNm }}
                  </div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>그룹</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <template
                    v-for="(item, index) in personInfo.isrgrpIsrtyResVos"
                  >
                    <div class="text mr-4" :key="index">
                      {{ item.isrgrpNm }}
                    </div>
                  </template>
                  <!-- <div class="text mr-4">
                    {{ personInfo && personInfo.rprsIsrgrpNm }}
                  </div> -->
                  <!-- <div class="text mr-4">사건A 관련</div>
                  <div class="text mr-4">E대학교동창</div>
                  <div class="text mr-4">페이스북A그룹</div> -->
                </v-col>
              </v-row>
            </v-col>
          </v-layout>
        </dea-card>
      </div>
    </section>
    <section v-if="filter.type === 'person'" class="dea-section">
      <div class="inner">
        <dea-card>
          <!-- 전화번호 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>전화번호</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(item, index) in personInfo.telnos">
                <v-chip small :key="index">
                  {{ item.acntIdntfcValue }}
                </v-chip>
              </template>
              <!-- <v-chip small>
                {{ personInfo && personInfo.rprsTelno }}
              </v-chip> -->
            </v-col>
          </v-row>
          <!-- // 전화번호 -->

          <!-- 이메일 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>이메일</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(item, index) in personInfo.emails">
                <v-chip small :key="index">
                  {{ item }}
                </v-chip>
              </template>
            </v-col>
          </v-row>
          <!-- // 이메일 -->

          <!-- 계좌번호 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>계좌번호</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(item, index) in personInfo.acnutnos">
                <v-chip small :key="index">
                  {{ item }}
                </v-chip>
              </template>
            </v-col>
          </v-row>
          <!-- 계좌번호 -->

          <!-- 모바일 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>모바일</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(item, index) in personInfo.mobileApps">
                <v-chip small :key="index">
                  {{ item }}
                </v-chip>
              </template>
            </v-col>
          </v-row>
          <!-- // 모바일 -->
          <v-divider />
          <!-- 메모 -->
          <v-row no-gutters v-if="personInfo.isrtyMemoCn">
            <v-col cols="1">
              <dea-label class="valign-top">메모</dea-label>
            </v-col>
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col class="d-flex">
                  <v-sheet class="text">
                    {{ personInfo && personInfo.isrtyMemoCn }}
                  </v-sheet>
                </v-col>
              </v-row>
            </v-col>
          </v-row>
          <!-- // 메모 -->
        </dea-card>
      </div>
    </section>
    <!-- // 인물정보 -->

    <!-- 병합정보 -->
    <section v-if="filter.type === 'merge'" class="dea-section">
      <div class="inner grid-wrap">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text fontsize-big3 pa-4">
              {{ personMergeNum }}명의 인물이 병합되어 있습니다.
            </div>
          </v-col>
        </v-row>
        <dea-card>
          <template slot="title">병합정보</template>
          <dea-grid
            ref="refDialogIndividualGrid"
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
          ></dea-grid>
        </dea-card>
      </div>
    </section>
    <!-- // 병합정보 -->

    <!-- 수정이력 -->
    <section v-if="filter.type === 'history'" class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <template slot="title">수정이력</template>
          <v-row>
            <v-col
              cols="6"
              v-for="(modifyHistory, index) in modifyHistorys"
              :key="index"
            >
              <v-card class="dea-card-field pa-0">
                <v-list class="history-list pa-0">
                  <v-list-item-group>
                    <v-list-item>
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistory.date }}
                          </v-list-item-title>
                          <v-list-item-title>
                            등록자: {{ modifyHistory.registeredUser }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistory.sources"
                          ></div>
                        </v-layout>
                        <v-layout class="flex-50">
                          <v-list-item-subtitle
                            v-for="(hystory, idx) in modifyHistory.hystorys"
                            :key="idx"
                          >
                            [{{ hystory.state }}]{{ hystory.key }}:
                            {{ hystory.value }}
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list-item-group>
                </v-list>
              </v-card>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <!-- // 수정이력 -->
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button v-if="!readOnly" outlined @click="dialogIndividualRegShow"
          >수정</dea-button
        >
        <dea-button color="primary" @click="$emit('update:visible', !visible)"
          >확인</dea-button
        >
        <!-- <dea-button>인쇄</dea-button> -->
      </v-col>
    </div>
    <template #header-btn-radio>
      <dea-radio-group
        class="dea-btn-radio"
        v-model="filter.type"
        row
        :mandatory="false"
        :items="listTypeItems"
        @change="onChange"
      ></dea-radio-group>
    </template>
  </dea-dialog>
</template>
<script>
// import { StringUtils } from '@/utils/StringUtils'
export default {
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    params: {
      type: Object,
      default: undefined
    },
    readOnly: {
      type: Boolean,
      default: true
    },
    jsonPersonDataFile: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      personInfo: {},
      personMergeNum: 0,
      // checkbox, radio
      listTypeItems: [
        {
          label: '인물정보',
          value: 'person'
        },
        {
          label: '병합정보',
          value: 'merge'
        },
        {
          label: '수정이력',
          value: 'history'
        }
      ],
      filter: {
        type: 'person', // personInfo.represent
        mergeId: ''
      },
      modifyHistorys: [
        // {
        //   date: '2017-02-11 14:37',
        //   registeredUser: '김OO 사무관',
        //   sources: '통화이력',
        //   hystorys: [
        //     {
        //       state: '추가',
        //       key: '이름',
        //       value: '김개주'
        //     },
        //     {
        //       state: '추가',
        //       key: '별칭',
        //       value: '별칭'
        //     },
        //     {
        //       state: '추가',
        //       key: '증거번호',
        //       value: '증거번호234'
        //     },
        //     {
        //       state: '추가',
        //       key: '인물유형',
        //       value: '참고인'
        //     },
        //     {
        //       state: '추가',
        //       key: '전화번호',
        //       value: '010-2279-2652'
        //     },
        //     {
        //       state: '추가',
        //       key: '이메일',
        //       value: 'honggildong@email.com'
        //     },
        //     {
        //       state: '추가',
        //       key: '통장번호',
        //       value: 'KB 124567890'
        //     },
        //     {
        //       state: '추가',
        //       key: '모바일앱',
        //       value: '카카오톡 hong9785'
        //     }
        //   ]
        // },
        // {
        //   date: '2017-02-13 11:28',
        //   registeredUser: '김OO 사무관',
        //   sources: '메뉴얼 등록',
        //   hystorys: [
        //     {
        //       state: '수정',
        //       key: '인물유형',
        //       value: '피의자'
        //     },
        //     {
        //       state: '추가',
        //       key: '그룹',
        //       value: 'A그룹'
        //     }
        //   ]
        // }
      ],
      // grid setting
      gridInfo: {
        api: this.jsonPersonDataFile,
        count: 0,
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: '대표자',
            field: 'represent',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: 'No',
            field: 'no',
            width: 90,
            sortable: true,
            unSortIcon: true,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '전화번호',
            field: 'rprsTelno',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '이메일',
            field: 'emails',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '별칭',
            field: 'isrtyNmResVos',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록일',
            field: 'joinDate',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '메모',
            field: 'isrtyMemoCn',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '키워드',
            field: 'keyword',
            sortable: true,
            unSortIcon: true,
            hide: true
          }
        ]
      }
    }
  },
  updated() {
    this.initMergeData()
  },
  watch: {
    // 팝업닫힘 > 초기화.
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0
        this.personInfo = {}
        this.personMergeNum = 0
        this.filter.type = 'person'
        this.filter.mergeId = ''
        this.$emit('update:params', undefined)
        this.$emit('update:readOnly', true)
      }
    },
    // 넘어온 인물정보 처리
    params() {
      if (!this.params) {
        return
      }
      this.personInfo = this.params
    }
  },
  computed: {
    groupNameArr() {
      if (!this.personInfo.pgName) {
        return []
      }
      let str = this.personInfo.pgName + ''
      return str.split(',')
    }
  },
  methods: {
    // itemToArr(column) {
    //   if (!this.personInfo[column]) {
    //     return []
    //   }
    //   let str = this.personInfo[column] + ''
    //   return str.split(',')
    // },
    dialogIndividualRegShow() {
      this.$emit('update:visible', !this.visible)
      this.$emit('dialog-individual-reg-show')
      this.$emit('dialog-individual-reg-show', this.personInfo)
    },
    // 인물 병합 데이타
    initMergeData() {
      if (!this.$refs.refDialogIndividualGrid) {
        return
      }
      /** API */
    },
    onChange() {},
    // 인물유형 코드
    isrtyTyCode(code) {
      console.log('인물유형 코드', code)
      let str = ''
      switch (code) {
        case 'SUSPCT': // 피의자
          str = '피해자'
          break
        case 'SUSPIC': // 혐의자
          str = '혐의자'
          break
        case 'REFE': // 참고인
          str = '참고인'
          break
        case 'SUFRER': // 피해자
          str = '피해자'
          break
        case 'ETC': // 기타
          str = '기타'
          break
        default:
          str = '미분류'
          // 미분류
          break
      }
      return str
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>
