<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text fontsize-big3 pa-4">
                ※ 미분류 파일이 12개 있습니다. 통합 북마크로 이동하여, 폴더별로
                분류하여 중요 내역을 관리하세요!
              </div>
              <dea-button @click="LinkIntBookmark"
                >북마크내역 분류하기</dea-button
              >
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          use-pagination
          row-selection-multiple
          suppress-row-click-selection
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.totalCount"
          :etc-options="gridInfo.options"
          disableAutoLoad
          @ready="onReady"
        >
          <template #header-left>
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </template>

          <template #header-right>
            <dea-button @click="goBookmark(false)">북마크해제</dea-button>
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 가입자 정보 : Layer Popup -->
    <dialog-subscriber-info ref="dialogSubscriberInfo"></dialog-subscriber-info>
    <!-- //가입자 정보 : Layer Popup -->

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :params.sync="individualDetailParams"
    />
  </v-container>
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import CellButton from '@/components/grid/CellButton'
// import CellBookmark from '@/components/grid/CellBookmark'
import CellIcon from '@/components/grid/CellIcon'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import DialogSubscriberInfo from './Dialog/DialogSubscriberInfo'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'

import GridCommMixins from '@/mixins/callHistory/GridComm'
import listTemplate from '@/mixins/listTemplate'
import eventBus from '@/mixins/eventBus'

export default {
  name: 'CallHistoryAnalysisBookmark',
  components: {
    DialogSubscriberInfo,
    DialogCallHistory,
    DialogIndividual
  },
  mixins: [GridCommMixins, listTemplate, eventBus],
  data() {
    return {
      tabSelected: 0,
      tabName: '통화내역 목록',
      filter: {
        isBkmk: 'Y'
      },
      gridInfo: {
        api: '/talk/unity-dtlses',
        options: {},
        totalCount: 0,
        columns: [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: 'No',
                field: 'no',
                width: 60,
                cellClass: 'align-right'
              },
              {
                headerName: '북마크',
                field: 'bkmkId',
                width: 50,
                cellRendererFramework: CellIcon,
                cellRendererParams: (params) => {
                  return {
                    type: 'bookmark',
                    icon: 'mdi-star',
                    color: params.value ? '#fe7c10' : '#d7d7d7',
                    click: this.setBookmarkCell
                  }
                }
              }
            ]
          },
          {
            headerName: '발신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'dsptchUserNm',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  click: (params) => {
                    this.individualDetailParams = {
                      data: {
                        isrtyId: params.data.dsptchUserId
                      }
                    }
                    this.individualDetail = true
                  }
                }
              },
              {
                headerName: '가입자',
                field: 'dsptchSbscrberNm',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  click: (params) => {
                    this.$refs.dialogSubscriberInfo.show(
                      params.data.dsptchSbscrberId
                    )
                  }
                }
              },
              {
                headerName: '전화번호',
                field: 'dsptchTelno',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno',
                  dsptchRcvDiv: 'DSPTCH',
                  click: (params) => {
                    this.$refs.dialogCallHistory.doShow(params)
                  }
                }
              }
            ]
          },
          {
            headerName: '착신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'rcvUserNm',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  click: (params) => {
                    this.individualDetailParams = {
                      data: {
                        isrtyId: params.data.dsptchUserId
                      }
                    }
                    this.individualDetail = true
                  }
                }
              },
              {
                headerName: '가입자',
                field: 'rcvSbscrberNm',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'subscriber',
                  click: (params) => {
                    this.$refs.dialogSubscriberInfo.show(
                      params.data.rcvSbscrberId
                    )
                  }
                }
              },
              {
                headerName: '전화번호',
                field: 'rcvTelno',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno',
                  dsptchRcvDiv: 'RCV',
                  click: (params) => {
                    this.$refs.dialogCallHistory.doShow(params)
                  }
                }
              }
            ]
          },
          {
            headerName: '통화정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작',
                field: 'formattedTalkBgngDt',
                sortable: true,
                unSortIcon: true,
                width: 130,
                valueGetter: (params) => {
                  return this.getWeekOfDayKr(params.data.formattedTalkBgngDt)
                }
              },
              // {
              //   headerName: '통화종료',
              //   field: 'callEnd',
              //   sortable: true,
              //   unSortIcon: true
              // },
              {
                headerName: '통화량',
                field: 'talkQy',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.timeWithColons,
                width: 60,
                cellClass: 'align-right'
              },
              {
                headerName: '기지국',
                field: 'linkRelateAdres',
                sortable: true,
                unSortIcon: true,
                tooltipField: 'linkRelateAdres'
              }
            ]
          }
        ]
      },
      gridSelected: [],
      individualDetail: false,
      individualDetailParams: {} // 인물정보(팝업/열람)
    }
  },
  computed: {
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo.totalCount
          )})`
        }
      ]
    }
  },
  methods: {
    onReady() {
      this.loadData()
    },
    LinkIntBookmark() {
      this.$router.push('/integratedBookmark')
    }
  }
}
</script>
