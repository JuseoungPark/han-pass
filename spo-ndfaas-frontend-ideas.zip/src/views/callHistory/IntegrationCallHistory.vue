<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물 선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="filter.outgoingUsersType"
                :items="outgoingUsersTypeItems"
                label="선택"
                :disabled="disableOutgoingUsersType"
              >
              </dea-select>
              <dialog-select-person
                v-model="filter.outgoingUsers"
                use-pagination
                label="발신자 선택"
                :disabled="disableOutgoingUsersType"
                multiple
              ></dialog-select-person>
              <dea-select
                v-model="filter.incommingUsersType"
                :items="incommingUsersTypeItems"
                label="선택"
                :disabled="disableIncommingUsersType"
              >
              </dea-select>
              <dialog-select-person
                v-model="filter.incommingUsers"
                use-pagination
                label="착신자 선택"
                :disabled="disableIncommingUsersType"
                multiple
              ></dialog-select-person>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="
                  resetFilterEach([
                    'outgoingUsersType',
                    'outgoingUsers',
                    'incommingUsersType',
                    'incommingUsers'
                  ])
                "
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>

          <v-row no-gutters>
            <v-col cols="1">
              <dea-label class="valign-top">기간 선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdayTime"
              ></dialog-select-day-time>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdayTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>

          <v-expand-transition>
            <div v-show="isDetailSearch">
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>기지국</dea-label>
                </v-col>
                <v-col class="d-flex" cols="4">
                  <dialog-station-select
                    ref="dialogStationSelect"
                    v-model="filter.station"
                    label="기지국 검색"
                  ></dialog-station-select>
                  <dea-button
                    icon
                    textindent
                    prepend-icon="mdi-restore"
                    @click="resetFilterEach(['station'])"
                  >
                    초기화
                  </dea-button>
                </v-col>
                <v-col cols="1" style="width:110px;">
                  <dea-label>정제주소</dea-label>
                </v-col>
                <v-col class="d-flex" cols="6">
                  <dea-select label="시,도 선택"></dea-select>
                  <dea-select label="시,군,구 선택"></dea-select>
                  <dea-select label="읍,면,동 선택"></dea-select>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                  <dea-checkbox label="목록에 표시"></dea-checkbox>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>통화구분</dea-label>
                </v-col>
                <v-col class="d-flex" cols="4">
                  <dea-checkbox
                    label="전체"
                    :indeterminate="
                      filter.callType.length > 0 &&
                        filter.callType.length < callTypeItems.length
                    "
                    :true-value="true"
                    :value="
                      filter.callType.length === callTypeItems.length
                        ? true
                        : false
                    "
                    @click="toggle"
                  />
                  <dea-checkbox
                    v-model="filter.callType"
                    v-for="(item, index) in callTypeItems"
                    :label="item.label"
                    :cvalue="item.value"
                    :key="index"
                  />
                </v-col>
                <v-col cols="1" style="width:110px;">
                  <dea-label>통화내역파일</dea-label>
                </v-col>
                <v-col class="d-flex" cols="6">
                  <dea-text-field
                    label="파일 선택"
                    placeholder="파일 선택"
                    style="max-width:540px;"
                  ></dea-text-field>
                  <dea-button icon prepend-icon="mdi-restore"> </dea-button>
                  <dea-checkbox label="중복 포함"></dea-checkbox>
                </v-col>
              </v-row>
            </div>
          </v-expand-transition>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
                <dea-button
                  :prepend-icon="
                    isDetailSearch
                      ? 'mdi-arrow-collapse-up'
                      : 'mdi-arrow-collapse-down'
                  "
                  @click="isDetailSearch = !isDetailSearch"
                  title="상세 검색"
                >
                  상세 검색
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          async
          use-pagination
          disable-auto-load
          row-selection-multiple
          suppress-row-click-selection
          :columns="currentColumns"
          :api="currentApi"
          :return-value.sync="tabItemsName[tabSelected].count"
          @ready="onReady"
        >
          <template #header-left>
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </template>
          <template #header-right>
            <grid-comm-btn
              v-if="tabSelected === 0 && filter.type === 'list'"
              @goBookmark="goBookmark"
              @goExcept="goExcept"
            ></grid-comm-btn>
            <grid-comm-btn
              v-else-if="tabSelected === 1"
              @goBookmark="goBookmark"
              @goExcept="goExcept"
            ></grid-comm-btn>
            <!-- <dea-button v-else @click="showDialogFrequencyGraph">
              그래프로 보기
            </dea-button> -->
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 가입자 정보 : Layer Popup -->
    <dialog-subscriber-info ref="dialogSubscriberInfo"></dialog-subscriber-info>
    <!-- //가입자 정보 : Layer Popup -->

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->

    <!-- 그래프로 보기 : Layer Popup -->
    <!-- <dialog-frequency-graph ref="dialogFrequencyGraph"></dialog-frequency-graph> -->
    <!-- //그래프로 보기 : Layer Popup -->

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.date"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :_params.sync="individualDetailParams"
    />
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import DialogSelectPerson from './Dialog/DialogSelectPerson'
import DialogSubscriberInfo from './Dialog/DialogSubscriberInfo'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import DialogSelectDate from './Dialog/DialogSelectDate'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
// import DialogFrequencyGraph from './Dialog/DialogFrequencyGraph'
import DialogStationSelect from './Dialog/DialogStationSelect'
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import CellIcon from '@/components/grid/CellIcon'
// import CellBookmark from '@/components/grid/CellBookmark'
import CellButton from '@/components/grid/CellButton'
import CellExcept from '@/components/grid/CellExcept'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'

import GridCommBtn from './include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'
import apiMixin from '@/mixins/apiMixin'

var SlotContent = {
  name: 'SlotContent',
  template: `
    <v-row no-gutters class="ml-6">
      <v-col>
        <dea-radio-group
          class="dea-btn-radio"
          v-model="child.filter.type"
          :disabled="child.tabSelected === 0 ? false : true"
          row
          :mandatory="false"
          :items="child.listTypeItems"
          @change="onChangeType"
        ></dea-radio-group>
      </v-col>
    </v-row>
    `,
  props: {
    child: {}
  },
  methods: {
    onChangeType() {
      this.child.onSearch()
    }
  }
}

export default {
  name: 'IntegrationCallHistory',
  mixins: [listTemplate, GridCommMixins, eventBus, apiMixin],
  components: {
    DialogSelectPerson,
    DialogSubscriberInfo,
    DialogCallHistory,
    DialogSelectDate,
    DialogSelectDayTime,
    // DialogFrequencyGraph,
    DialogStationSelect,
    DialogIndividual,
    GridCommBtn
  },
  data() {
    return {
      isDetailSearch: false,
      tabSelected: 0,
      tabItemsName: [
        { name: '통화내역', count: 0 },
        { name: '전화번호', count: 0 },
        { name: '가입자', count: 0 }
      ],
      params: {
        dsptchRlUserIds: [],
        rcvRlUserIds: [],
        dateList: [],
        daysOfWeekTimesList: [],
        talkTyId: [],
        linkRelateLcIds: []
      },
      filter: {
        type: 'list',
        outgoingUsersType: 'out',
        outgoingUsers: [],
        incommingUsersType: 'in',
        incommingUsers: [],
        date: ['2016-02-13', '2017-01-31'],
        weekofdayTime: [],
        station: [],
        callType: []
      },
      gridInfo: [
        {
          list: {
            api: '/talk/unity-dtlses',
            columns: [
              {
                headerName: '',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    colId: 'historyRowSelector',
                    headerName: '열 선택',
                    field: 'rowSelector',
                    width: 20,
                    headerComponentFramework: CellCheckboxHeader,
                    cellRendererFramework: CellCheckbox
                  },
                  {
                    colId: 'historyRowNum',
                    headerName: 'No',
                    field: 'no',
                    width: 50,
                    cellClass: 'align-center'
                  },
                  {
                    colId: 'historyBookmark',
                    headerName: '북마크',
                    field: 'bkmkId',
                    width: 50,
                    cellRendererFramework: CellIcon,
                    cellRendererParams: (params) => {
                      return {
                        type: 'bookmark',
                        icon: 'mdi-star',
                        color: params.value ? '#fe7c10' : '#d7d7d7',
                        click: this.setBookmarkCell
                      }
                    }
                  },
                  {
                    colId: 'historyExcept',
                    headerName: '제외',
                    field: 'except',
                    width: 50,
                    cellRendererFramework: CellExcept,
                    cellRendererParams: {
                      except: 'Y'
                    }
                  }
                ]
              },
              {
                headerName: '발신자',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    colId: 'historyOutgoingUser',
                    headerName: '실사용자',
                    field: 'dsptchUserNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.individualDetailParams = {
                          data: {
                            isrtyId: params.data.dsptchUserId
                          }
                        }
                        this.individualDetail = true
                      }
                    }
                  },
                  {
                    colId: 'historyOutgoingSubscriber',
                    headerName: '가입자',
                    field: 'dsptchSbscrberNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.$refs.dialogSubscriberInfo.show(
                          params.data.dsptchSbscrberId
                        )
                      }
                    }
                  },
                  {
                    colId: 'historyOutgoingNumber',
                    headerName: '전화번호',
                    field: 'dsptchTelno',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'telno',
                      dsptchRcvDiv: 'DSPTCH',
                      click: (params) => {
                        this.$refs.dialogCallHistory.doShow(params)
                      }
                    }
                  }
                ]
              },
              {
                headerName: '착신자',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    colId: 'historyIncommingUser',
                    headerName: '실사용자',
                    field: 'rcvUserNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.individualDetailParams = {
                          data: {
                            isrtyId: params.data.dsptchUserId
                          }
                        }
                        this.individualDetail = true
                      }
                    }
                  },
                  {
                    colId: 'historyIncommingSubscriber',
                    headerName: '가입자',
                    field: 'rcvSbscrberNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'subscriber',
                      click: (params) => {
                        this.$refs.dialogSubscriberInfo.show(
                          params.data.rcvSbscrberId
                        )
                      }
                    }
                  },
                  {
                    colId: 'historyIncommingNumber',
                    headerName: '전화번호',
                    field: 'rcvTelno',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'telno',
                      dsptchRcvDiv: 'RCV',
                      click: (params) => {
                        this.$refs.dialogCallHistory.doShow(params)
                      }
                    }
                  }
                ]
              },
              {
                headerName: '통화정보',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    colId: 'historyDateTime',
                    headerName: '통화시작',
                    field: 'formattedTalkBgngDt',
                    sortable: true,
                    unSortIcon: true,
                    width: 130,
                    valueGetter: (params) => {
                      return this.getWeekOfDayKr(
                        params.data.formattedTalkBgngDt
                      )
                    }
                  },
                  {
                    colId: 'historyLength',
                    headerName: '통화량',
                    field: 'talkQy',
                    sortable: true,
                    unSortIcon: true,
                    width: 60,
                    cellClass: 'align-right'
                  },
                  {
                    colId: 'historyType',
                    headerName: '통화유형',
                    field: 'talkTyNm',
                    sortable: true,
                    unSortIcon: true
                  },
                  {
                    colId: 'historyStation',
                    headerName: '기지국',
                    field: 'linkRelateAdres',
                    sortable: true,
                    unSortIcon: true,
                    tooltipField: 'linkRelateAdres'
                  }
                ]
              }
            ]
          },
          frequency: {
            api: '/talk/unity-dtls/fq',
            columns: [
              {
                headerName: '',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    headerName: '열 선택',
                    field: 'rowSelector',
                    width: 20,
                    headerComponentFramework: CellCheckboxHeader,
                    cellRendererFramework: CellCheckbox
                  },
                  {
                    colId: 'historyRowNum',
                    headerName: 'No',
                    field: 'no',
                    width: 10,
                    cellClass: 'align-center'
                  }
                ]
              },
              {
                headerName: '발신자',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    headerName: '실사용자',
                    field: 'dsptchUserNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.individualDetailParams = {
                          data: {
                            isrtyId: params.data.dsptchUserId
                          }
                        }
                        this.individualDetail = true
                      }
                    }
                  },
                  {
                    headerName: '가입자',
                    field: 'dsptchSbscrberNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.$refs.dialogSubscriberInfo.show(
                          params.data.dsptchSbscrberId
                        )
                      }
                    }
                  },
                  {
                    headerName: '전화번호',
                    field: 'dsptchTelno',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'telno',
                      dsptchRcvDiv: 'DSPTCH',
                      click: (params) => {
                        this.$refs.dialogCallHistory.doShow(params)
                      }
                    }
                  }
                ]
              },
              {
                headerName: '착신자',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    headerName: '실사용자',
                    field: 'rcvUserNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      click: (params) => {
                        this.individualDetailParams = {
                          data: {
                            isrtyId: params.data.dsptchUserId
                          }
                        }
                        this.individualDetail = true
                      }
                    }
                  },
                  {
                    headerName: '가입자',
                    field: 'rcvSbscrberNm',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'subscriber',
                      click: (params) => {
                        this.$refs.dialogSubscriberInfo.show(
                          params.data.rcvSbscrberId
                        )
                      }
                    }
                  },
                  {
                    headerName: '전화번호',
                    field: 'rcvTelno',
                    sortable: true,
                    unSortIcon: true,
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      text: true,
                      color: 'primary',
                      event: 'telno',
                      dsptchRcvDiv: 'RCV',
                      click: (params) => {
                        this.$refs.dialogCallHistory.doShow(params)
                      }
                    }
                  }
                ]
              },
              {
                headerName: '',
                headerGroupComponent: CustomHeaderGroup,
                children: [
                  {
                    headerName: '통화빈도',
                    field: 'talkFq',
                    sortable: true,
                    unSortIcon: true,
                    valueFormatter: GridFormatter.numberWithCommas,
                    width: 60,
                    cellClass: 'align-right'
                  }
                  /*{
                    headerName: '기능',
                    field: 'function',
                    cellRendererFramework: CellButton,
                    cellRendererParams: {
                      outlined: true,
                      label: '그래프로 보기',
                      event: 'frequency-graph',
                      isShowAll: true
                    },
                    editable: false
                  }*/
                ]
              }
            ]
          }
        },
        {
          api: '/talk/unity-dtls/telno',
          columns: [
            {
              colId: 'numberUser',
              headerName: '실사용자',
              field: 'isrtyNm',
              sortable: true,
              unSortIcon: true
            },
            {
              colId: 'numberType',
              headerName: '전화번호 유형',
              field: 'linkTyNm',
              sortable: true,
              unSortIcon: true
            },
            {
              colId: 'numberNumber',
              headerName: '전화번호',
              field: 'telno',
              sortable: true,
              unSortIcon: true
            },
            {
              colId: 'numberDialing',
              headerName: '국번',
              field: 'telofcno'
            },
            {
              colId: 'numberCountryCode',
              headerName: '국가코드',
              field: 'nationCode'
            }
          ]
        },
        {
          api: '/talk/unity-dtls/sbscrber',
          columns: [
            {
              headerName: 'No',
              field: 'no',
              width: 60,
              cellClass: 'align-right'
            },
            {
              headerName: '가입자',
              field: 'isrtyNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통신사',
              field: 'telecom',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'telno',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '주소',
              field: 'adres',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'address'
            },
            {
              headerName: '가입일',
              field: 'joinYmd',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '해지일',
              field: 'trmnatYmd',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '사용유무',
              field: 'useEnnc'
            },
            {
              headerName: '비고',
              field: 'comment'
            }
          ]
        }
      ],

      // checkbox, radio
      listTypeItems: [
        {
          label: '목록형',
          value: 'list'
        },
        {
          label: '빈도형',
          value: 'frequency'
        }
      ],

      validError: {},
      dateMin: '',
      dateMax: '',
      usersTypeItems: [
        {
          text: '발신자',
          value: 'out'
        },
        {
          text: '착신자',
          value: 'in'
        },
        {
          text: '발/착신자',
          value: 'inOut'
        }
      ],
      callTypeItems: [],
      individualDetail: false,
      individualDetailParams: {} // 인물정보(팝업/열람)
    }
  },
  watch: {
    tabSelected() {
      this.$refs.grid.setApi(this.currentApi)
      this.onSearch()
    }
  },
  created() {},
  computed: {
    ...mapGetters(['incidentInfo']),
    tabItems() {
      return this.tabItemsName.map((item) => {
        return {
          name: `${item.name} (${NumberUtils.numberWithCommas(item.count)})`,
          tooltip: item.tooltip ? item.tooltip : ''
        }
      })
    },
    getParams() {
      return {
        dsptchRlUserIds: this.filter.outgoingUsers,
        rcvRlUserIds: this.filter.incommingUsers,
        dateList: this.filter.date,
        daysOfWeekTimesList: this.filter.weekofdayTime,
        talkTyId: this.filter.callType,
        linkRelateLcIds: this.filter.station
      }
    },
    currentApi() {
      if (this.tabSelected === 0)
        return this.gridInfo[this.tabSelected][this.filter.type].api
      else return this.gridInfo[this.tabSelected].api
    },
    currentColumns() {
      if (this.tabSelected === 0)
        return this.gridInfo[this.tabSelected][this.filter.type].columns
      else return this.gridInfo[this.tabSelected].columns
    },
    outgoingUsersTypeItems() {
      if (this.filter.incommingUsersType === 'inOut') {
        this.setOutgoingUsersType('inOut')
        return this.usersTypeItems.slice(2)
      }
      return this.usersTypeItems
    },
    incommingUsersTypeItems() {
      if (this.filter.outgoingUsersType === 'inOut') {
        this.setIncommingUsersType('inOut')
        return this.usersTypeItems.slice(2)
      }
      return this.usersTypeItems.slice(1)
    },
    disableOutgoingUsersType() {
      return this.filter.incommingUsersType === 'inOut' &&
        this.filter.incommingUsers.length > 1
        ? true
        : false
    },
    disableIncommingUsersType() {
      return this.filter.outgoingUsersType === 'in' ||
        (this.filter.outgoingUsersType === 'inOut' &&
          this.filter.outgoingUsers.length > 1)
        ? true
        : false
    }
  },
  mounted() {
    this.init()
  },
  destroyed() {
    this.$emit('slot-content:delete', this.$options.name)
  },
  methods: {
    onReady() {
      this.loadCount()
      this.loadData()
      /* TODO: Apply API to get Date min and max
      this.$api.analysis.handler.getDateMinMax(
        this.incidentInfo.id,
        (dateMin, dateMax) => {
          if (dateMin && dateMax) {
            this.dateMin = dateMin
            this.dateMax = dateMax
            this.filter.date = [dateMin, dateMax]

            this.setInitFilter(this.filter)
            this.updateFilter()
            this.loadData()
          }
        }
      )
      */
    },
    async init() {
      this.$emit('slot-content:add', {
        name: this.$options.name,
        component: SlotContent,
        child: this
      })
      this.getCallTypeItems()
    },
    getCallTypeItems() {
      this.$talkTypeCode().then((callType) => {
        if (callType) {
          this.callTypeItems = callType.map((item) => {
            return { label: item.cmmnCodeNm, value: item.cmmnCode }
          })
          this.filter.callType = this.callTypeItems.map((item) => item.value)
        }
      })
    },
    getColumns() {
      this.$refs.grid.setColumns(this.currentColumns)
    },
    toggle() {
      this.$nextTick(() => {
        if (this.filter.callType.length === this.callTypeItems.length) {
          this.filter.callType = []
        } else {
          this.filter.callType = this.callTypeItems.map((item) => item.value)
        }
      })
    },
    loadCount() {
      let res
      this.apiParams = this.objQueryString(this.getParams)

      this.apiUrl = '/talk/unity-dtls/telno-cnt'
      this.$requestApi({ url: this.uri }).then((response) => {
        res = this.apiCodeValidate(
          response,
          '전화번호 내역 조회에 실패하있습니다.'
        )
        if (res) this.tabItemsName[1].count = res.data.result.allCnt
      })

      this.apiUrl = '/talk/unity-dtls/sbscrber-cnt'
      this.$requestApi({ url: this.uri }).then((res) => {
        res = this.apiCodeValidate(res, '가입자 내역 조회에 실패하있습니다.')
        if (res) this.tabItemsName[2].count = res.data.result.allCnt
      })
    },
    onSearch() {
      this.$refs.grid.setApi(this.currentApi)
      this.$refs.grid.dataReset()
      this.loadData()
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    showDialogFrequencyGraph() {
      this.$refs.dialogFrequencyGraph.showMultiple(
        this.$refs.grid.gridApi.getSelectedRows()
      )
    },
    setOutgoingUsersType(val) {
      this.filter.outgoingUsersType = val
    },
    setIncommingUsersType(val) {
      this.filter.incommingUsersType = val
    }
  }
}
</script>
