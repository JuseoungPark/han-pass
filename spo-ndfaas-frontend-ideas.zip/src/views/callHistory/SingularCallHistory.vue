<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>조건선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <div class="text text-truncate">착신/발신 합이</div>
              <dea-text-field
                v-model="filter.talkFqCnt"
                :clearable="false"
                label="합"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">건 이상</div>
            </v-col>
            <v-col class="d-flex flex-0">
              <div class="text">/</div>
            </v-col>
            <v-col class="d-flex flex-0">
              <div class="text text-truncate">착신/발신 차이가</div>
              <dea-text-field
                v-model="filter.dsptchRcvDffrncRate"
                :clearable="false"
                label="차이"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">% 이상인 전화번호</div>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['talkFqCnt', 'dsptchRcvDffrncRate'])"
              >
                초기화
              </dea-button>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label class="valign-top">기간 선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.dateList"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col class="d-flex">
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.daysOfWeekTimesList"
              ></dialog-select-day-time>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['dateList', 'daysOfWeekTimesList'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                :indeterminate="
                  filter.talkTyIds.length > 0 && filter.talkTyIds.length < 3
                "
                :true-value="true"
                :value="filter.talkTyIds.length === 3 ? true : false"
                @click="toggle"
              />
              <dea-checkbox
                v-model="filter.talkTyIds"
                label="통화"
                cvalue="call"
              />
              <dea-checkbox
                v-model="filter.talkTyIds"
                label="메시지"
                cvalue="message"
              />
              <dea-checkbox
                v-model="filter.talkTyIds"
                label="기타"
                cvalue="etc"
              />
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          async
          use-pagination
          disable-auto-load
          row-selection-multiple
          suppress-row-click-selection
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.count"
          @cellButtonClicked="onCellButtonClicked"
          @ready="onReady"
        >
          <template #header-left>
            <v-tabs v-model="totalCount" class="dea-tabs">
              <v-tab>특이통화분석내역 ({{ totalCount }})</v-tab>
            </v-tabs>
          </template>
          <template #header-right>
            <dea-button>차트</dea-button>
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.dateList"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :params.sync="individualDetailParams"
    />
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import CellButton from '@/components/grid/CellButton'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import DialogSelectDate from './Dialog/DialogSelectDate'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'

export default {
  name: 'SingularCallHistory',
  mixins: [listTemplate],
  components: {
    DialogSelectDate,
    DialogSelectDayTime,
    DialogCallHistory,
    DialogIndividual
  },
  data() {
    return {
      filter: {
        talkFqCnt: 50,
        dsptchRcvDffrncRate: 90,
        dateList: ['2016-02-13', '2017-01-31'],
        daysOfWeekTimesList: [],
        talkTyIds: ['call', 'message', 'etc']
      },
      validError: {},
      dateMin: '',
      dateMax: '',
      gridInfo: {
        api: '/talk/partclr-talk-anals-dtls',
        count: 0,
        columns: [
          {
            headerName: '열 선택',
            field: 'rowSelector',
            width: 20,
            headerComponentFramework: CellCheckboxHeader,
            cellRendererFramework: CellCheckbox
          },
          {
            headerName: 'No',
            field: 'no',
            width: 60,
            cellClass: 'align-right'
          },

          {
            headerName: '실사용자',
            field: 'ruseIsrtyNm',
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'outgoingUser'
            }
          },
          {
            headerName: '전화번호',
            field: 'telno',
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'telno',
              dsptchRcvDiv: 'DSPTCH'
            }
          },

          {
            headerName: '발신',
            field: 'dsptchcnt',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.numberWithCommas,
            cellClass: 'align-right',
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'telno:DSPTCH',
              dsptchRcvDiv: 'DSPTCH'
            }
          },
          {
            headerName: '착신',
            field: 'rcvCnt',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.numberWithCommas,
            cellClass: 'align-right',
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'telno:RCV',
              dsptchRcvDiv: 'RCV'
            }
          },
          {
            headerName: '통화빈도',
            field: 'talkFq',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.numberWithCommas,
            cellClass: 'align-right'
            // cellRendererFramework: CellButton,
            // cellRendererParams: {
            //   text: true,
            //   color: 'primary',
            //   event: 'telno:ALL'
            // }
          },
          {
            headerName: '기능',
            field: 'function',
            cellRendererFramework: CellButton,
            cellRendererParams: {
              outlined: true,
              label: '기지국내역 보기',
              event: 'frequency-graph'
            },
            editable: false
          }
        ]
      },
      individualDetail: false,
      individualDetailParams: {} // 인물정보(팝업/열람)
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    totalCount: {
      get: function() {
        return NumberUtils.numberWithCommas(this.gridInfo.count)
      },
      set: function() {}
    },
    getParams() {
      return {
        talkFqCnt: this.filter.talkFqCnt,
        dsptchRcvDffrncRate: this.filter.dsptchRcvDffrncRate,
        dateList: this.filter.dateList,
        daysOfWeekTimesList: this.filter.daysOfWeekTimesList
        // talkTyIds: this.filter.talkTyIds // TODO: empty data
      }
    }
  },
  mounted() {},
  methods: {
    onReady() {
      this.loadData()
      /* TODO: Apply API to get Date min and max
    this.$api.analysis.handler.getDateMinMax(
      this.incidentInfo.id,
      (dateMin, dateMax) => {
        if (dateMin && dateMax) {
          this.dateMin = dateMin
          this.dateMax = dateMax
          this.filter.dateList = [dateMin, dateMax]

          this.setInitFilter(this.filter)
          this.updateFilter()
          this.loadData()
        }
      }
    )
    */
    },
    getColumns() {
      this.$refs.grid.setColumns(this.gridInfo.columns)
    },
    toggle() {
      this.$nextTick(() => {
        if (this.filter.talkTyIds.length === 3) {
          this.filter.talkTyIds = []
        } else {
          this.filter.talkTyIds = ['call', 'message', 'etc']
        }
      })
    },
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    onCellButtonClicked(params) {
      let queryString = '{0}{1}{2}'.format(
        this.filter.dateList.length > 0
          ? '&dateList=' + this.filter.dateList.join(',')
          : '',
        this.filter.daysOfWeekTimesList.length > 0
          ? '&daysOfWeekTimesList=' + this.filter.daysOfWeekTimesList.join(',')
          : '',
        this.filter.talkTyIds.length > 0
          ? '&talkTyIds=' + this.filter.talkTyIds.join(',')
          : ''
      )

      if (params.event == 'telno') {
        this.$refs.dialogCallHistory.doShow(params)
      } else if (params.event.match(/telno:[A-Z]+/i)) {
        this.$refs.dialogCallHistory.doShow(params)
      } else if (params.event == 'outgoingUser') {
        this.individualDetailParams = { ...params }
        this.individualDetailParams.data = {
          no: 0,
          name: params.data.user,
          photo: '',
          ptName: '피의자',
          phoneNumber: params.data.number,
          nickname: '별칭',
          pgName: null,
          comName: '',
          divName: '',
          joinDate: '2017-02-11 14:37',
          updateDate: '2017-02-11 14:37',
          registeredUser: '등록자명',
          evidenceNumber: '증거번호234',
          memo: '',
          keyword: '',
          merge: null,
          represent: null
        }
        this.individualDetail = true
      } else if (params.event == 'outgoingCallOnly') {
        this.$refs.dialogCallHistory.show(params, queryString)
      } else if (params.event == 'incommingCallOnly') {
        this.$refs.dialogCallHistory.show(params, queryString)
      } else if (params.event == 'outgoingIncommingCallSum') {
        this.$refs.dialogCallHistory.show(params, queryString)
      }
    }
  }
}
</script>
