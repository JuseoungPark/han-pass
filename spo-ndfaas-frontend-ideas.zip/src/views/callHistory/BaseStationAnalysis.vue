<template>
  <v-container>
    <section class="dea-section">
      <!-- {{ filter }} -->
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <!-- 인물 선택 -->
            <v-col cols="1">
              <dea-label>인물 선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="filter.outgoingUsersType"
                :items="outgoingUsersTypeItems"
                label="선택"
                :disabled="disableOutgoingUsersType"
              >
              </dea-select>
              <dialog-select-person
                ref="outgoingPerson"
                v-model="filter.outgoingUsers"
                label="발신자 선택"
                multiple
              ></dialog-select-person>
              <dea-select
                v-model="filter.incommingUsersType"
                :items="incommingUsersTypeItems"
                label="선택"
                :disabled="disableIncommingUsersType"
              >
              </dea-select>
              <dialog-select-person
                ref="incommingPerson"
                v-model="filter.incommingUsers"
                label="착신자 선택"
                multiple
              ></dialog-select-person>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="
                  resetFilterEach([
                    'outgoingUsersType',
                    'outgoingUsers',
                    'incommingUsersType',
                    'incommingUsers'
                  ])
                "
              >
                초기화
              </dea-button>
            </v-col>
            <!-- 조건선택 -->
            <v-col cols="1">
              <dea-label>조건선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="5">
              <dea-radio-group
                v-model="filter.type"
                row
                :mandatory="false"
                :items="typeItems"
                @change="onChangeType"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간 선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                placeholder="요일 시간 선택"
                v-model="filter.weekofdayTime"
              ></dialog-select-day-time>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdayTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="5" />
          </v-row>
          <v-expand-transition>
            <div v-show="isDetailSearch">
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>기지국</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dialog-station-select
                    ref="dialogStationSelect"
                    v-model="filter.station"
                    label="기지국 검색"
                  ></dialog-station-select>
                  <dea-button
                    icon
                    textindent
                    prepend-icon="mdi-restore"
                    @click="resetFilterEach(['station'])"
                  >
                    초기화
                  </dea-button>
                </v-col>
                <v-col cols="1">
                  <dea-label>정제주소</dea-label>
                </v-col>
                <v-col class="d-flex" cols="5">
                  <dea-select label="시,도 선택"></dea-select>
                  <dea-select label="시,군,구 선택"></dea-select>
                  <dea-select label="읍,면,동 선택"></dea-select>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>주소보기</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-radio-group
                    v-model="filter.addrType"
                    row
                    :mandatory="false"
                    :items="addrTypeItems"
                  ></dea-radio-group>
                </v-col>
                <v-col cols="1" />
                <v-col class="d-flex" cols="5" />
              </v-row>
            </div>
          </v-expand-transition>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
                <dea-button
                  :prepend-icon="
                    isDetailSearch
                      ? 'mdi-arrow-collapse-up'
                      : 'mdi-arrow-collapse-down'
                  "
                  @click="isDetailSearch = !isDetailSearch"
                  title="상세 검색"
                >
                  상세 검색
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          use-pagination
          disable-auto-load
          :columns="gridInfo[filter.type].columns"
          :api="gridInfo[filter.type].api"
          :return-value.sync="gridInfo[filter.type].totalCount"
          @ready="onReady"
        >
          <template #header-left>
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.date"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <!-- 가입자 정보 : Layer Popup -->
    <dialog-subscriber-info ref="dialogSubscriberInfo" />
    <!-- //가입자 정보 : Layer Popup -->

    <!-- 인물 기준 기지국 이동 내역 : Layer Popup -->
    <dialog-person-station-move-list ref="dialogPersonStationMoveList" />
    <!-- // 인물 기준 기지국 이동 내역 : Layer Popup -->

    <!-- 기지국 중심 발신기준 통화 내역 : Layer Popup -->
    <dialog-station-outgoing-num-list ref="dialogStationOutgoingNumList" />
    <!-- // 기지국 중심 발신기준 통화 내역 : Layer Popup -->

    <!-- 전화번호 기준, 기지국 기준 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 전화번호 기준 기지국 기준 통화 내역 : Layer Popup -->
    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :_params.sync="individualDetailParams"
    />
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
// import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import DialogSelectPerson from './Dialog/DialogSelectPerson'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
import DialogSelectDate from './Dialog/DialogSelectDate'

import DialogSubscriberInfo from './Dialog/DialogSubscriberInfo' // 가입자정보
import DialogStationSelect from './Dialog/DialogStationSelect' // 기지국 선택
import DialogPersonStationMoveList from './Dialog/DialogPersonStationMoveList' // 인물중심 기지국 이동
import DialogStationOutgoingNumList from './Dialog/DialogStationOutgoingNumList' // 기지국중심 발신자
import DialogCallHistory from './Dialog/DialogCallHistory' // 기지국기준, 전화번호기준 통화내역
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'

import CellButton from '@/components/grid/CellButton'

import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'

export default {
  name: 'BaseStationAnalysis',
  mixins: [listTemplate],
  components: {
    DialogSelectPerson,
    DialogSubscriberInfo,
    DialogSelectDayTime,
    DialogSelectDate,
    DialogStationSelect,
    DialogPersonStationMoveList,
    DialogStationOutgoingNumList,
    DialogCallHistory,
    DialogIndividual
  },
  data() {
    return {
      // tab menu
      individualDetail: false,
      individualDetailParams: {}, // 인물정보(팝업/열람)
      tabSelected: 0,
      tabName: '기지국',
      filter: {
        type: 'station', // st : 기지국, mv :이동 내역
        addrType: 'all', // 주소정제 전체/성공/실패
        outgoingUsersType: 'out',
        outgoingUsers: [],
        incommingUsersType: 'in',
        incommingUsers: [],
        station: '',
        date: ['2016-02-13', '2017-01-31'],
        weekofdayTime: ''
      },
      validError: {
        outgoingUsers: false,
        date: false
      },
      dateMin: '',
      dateMax: '',
      gridInfo: {
        station: {
          api: '/base-station/init',
          totalCount: 0,
          tabName: '기지국',
          columns: [
            {
              headerName: '기지국 중심 발신자 주소 위치',
              field: 'linkRelateAdres',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'linkRelateAdres'
            },
            {
              headerName: '정제주소',
              field: 'adresRefineLotnoAdres',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'adresRefineLotnoAdres'
            },
            {
              headerName: '발신기준 통화건수',
              field: 'dsptchCnt',
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              // 기지국 기준통화내역
              cellRendererParams: {
                text: true,
                color: 'primary',
                event: 'station'
              },
              valueFormatter: GridFormatter.numberWithCommas,
              cellClass: 'align-right'
            },
            {
              headerName: '전화번호 개수',
              field: 'totalCnt',
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              // 기지국 기준통화내역
              cellRendererParams: {
                text: true,
                color: 'primary',
                event: 'numberCount'
              },
              valueFormatter: GridFormatter.numberWithCommas,
              cellClass: 'align-right'
            }
          ]
        },
        moving: {
          api: '/base-station/talk-all',
          totalCount: 0,
          tabName: '이동내역',
          columns: [
            {
              headerName: '실사용자명',
              field: 'ruseIsrtyNm',
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              cellRendererParams: {
                text: true,
                color: 'primary',
                click: (params) => {
                  this.individualDetailParams = {
                    data: {
                      isrtyId: params.data.ruseIsrtyId
                    }
                  }
                  this.individualDetail = true
                }
              }
            },
            {
              headerName: '가입자명',
              field: 'joinIsrtyNm',
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              cellRendererParams: {
                text: true,
                color: 'primary',
                click: (params) => {
                  this.$refs.dialogSubscriberInfo.show(params.data.joinIsrtyId)
                }
              }
            },
            {
              headerName: '전화번호',
              field: 'telno',
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              cellRendererParams: {
                text: true,
                color: 'primary',
                event: 'telno',
                dsptchRcvDiv: 'DSPTCH',
                click: (params) => {
                  this.$refs.dialogCallHistory.doShow(params)
                }
              },
              cellClass: 'align-center'
            },
            {
              headerName: '기지국 (발신자 추정위치)',
              field: 'linkRelateLcNm',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'linkRelateLcNm'
            },
            {
              headerName: '정제주소',
              field: 'adresRefineLotnoAdres',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'adresRefineLotnoAdres'
            },
            {
              headerName: '최초통화시작일시',
              field: 'talkBgngDt',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '마지막통화일시',
              field: 'talkEndDt',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통화 건수',
              field: 'cnt',
              width: 90,
              sortable: true,
              unSortIcon: true,
              cellRendererFramework: CellButton,
              cellRendererParams: {
                text: true,
                color: 'primary',
                event: 'station',
                click: (params) => {
                  // 기지국기준 통화내역
                  this.$refs.dialogCallHistory.doShow(params)
                }
              },
              valueFormatter: GridFormatter.numberWithCommas,
              cellClass: 'align-right'
            },
            {
              headerName: '이동내역',
              field: 'moveHistory',
              width: 80,
              cellRendererFramework: CellButton,
              cellRendererParams: {
                label: '이동내역',
                click: (params) => {
                  // 전화번호 기준 기지국 이동내역
                  this.$refs.dialogPersonStationMoveList.show(params)
                }
              }
            }
          ]
        }
      },
      typeItems: [
        {
          label: '기지국 중심',
          value: 'station'
        },
        {
          label: '이동 내역 중심',
          value: 'moving'
        }
      ],
      addrTypeItems: [
        {
          label: '전체',
          value: 'all'
        },
        {
          label: '주소정제 성공',
          value: 'success'
        },
        {
          label: '주소정제 실패',
          value: 'fail'
        }
      ],
      usersTypeItems: [
        {
          text: '발신자',
          value: 'out'
        },
        {
          text: '착신자',
          value: 'in'
        },
        {
          text: '발/착신자',
          value: 'inOut'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo[this.filter.type].totalCount
          )})`
        }
      ]
    },
    outgoingUsersTypeItems() {
      if (this.filter.incommingUsersType === 'inOut') {
        this.setOutgoingUsersType('inOut')
        return this.usersTypeItems.slice(2)
      }
      return this.usersTypeItems
    },
    incommingUsersTypeItems() {
      if (this.filter.outgoingUsersType === 'inOut') {
        this.setIncommingUsersType('inOut')
        return this.usersTypeItems.slice(2)
      }
      return this.usersTypeItems.slice(1)
    },
    disableOutgoingUsersType() {
      return this.filter.incommingUsersType === 'inOut' &&
        this.filter.incommingUsers.length > 1
        ? true
        : false
    },
    disableIncommingUsersType() {
      return this.filter.outgoingUsersType === 'in' ||
        (this.filter.outgoingUsersType === 'inOut' &&
          this.filter.outgoingUsers.length > 1)
        ? true
        : false
    },
    getParams() {
      if (this.filter.type === 'station')
        return {
          linkBgngDt: '',
          linkEndDt: ''
        }
      /* TODO: Error......
        return {
          linkBgngDt: this.filter.date[0],
          linkEndDt: this.filter.date[1]
        }
        */
      return {
        linkRelateLcId: ''
      }
    }
  },
  methods: {
    onReady() {
      this.loadData()
      /* TODO: Apply API to get Date min and max
      this.$api.analysis.handler.getDateMinMax(
        this.incidentInfo.id,
        (dateMin, dateMax) => {
          if (dateMin && dateMax) {
            this.dateMin = dateMin
            this.dateMax = dateMax
            this.filter.date = [dateMin, dateMax]

            this.setInitFilter(this.filter)
            this.updateFilter()
            this.loadData()
          }
        }
      )
      */
    },
    onSearch() {
      // let name = '기지국'
      // if (this.filter.type === 'moving') name = '이동내역'
      this.tabName = this.gridInfo[this.filter.type].tabName
      this.$refs.grid.reset()
      this.loadData()
    },
    getColumns() {
      this.$refs.grid.setColumns(this.gridInfo[this.filter.type].columns)
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    onChangeType() {
      this.$refs.grid.setApi(this.gridInfo[this.filter.type].api)
    }
  },
  created() {},
  mounted() {}
}
</script>
