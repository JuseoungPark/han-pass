<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <dialog-select-person
                v-model="filter.users"
                use-pagination
                label="인물 선택"
                multiple
              ></dialog-select-person>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['users'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>기준선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="4">
              <dea-radio-group
                v-model="filter.baseChc"
                row
                :mandatory="false"
                :items="baseChcSelectItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col class="d-flex">
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdayTime"
              ></dialog-select-day-time>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdayTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>통화구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                :indeterminate="
                  filter.callType.length > 0 && filter.callType.length < 3
                "
                :true-value="true"
                :value="filter.callType.length === 3 ? true : false"
                @click="toggle"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="통화"
                cvalue="call"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="메시지"
                cvalue="message"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="기타"
                cvalue="etc"
              />
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          apiType="analysis"
          async
          disableAutoLoad
          use-pagination
          row-selection-multiple
          suppress-row-click-selection
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.count"
          @cellButtonClicked="onCellButtonClicked"
          @ready="onReady"
        >
          <template #header-left>
            <v-tabs v-model="totalCount" class="dea-tabs">
              <v-tab>통화특성분석내역 ({{ totalCount }})</v-tab>
            </v-tabs>
          </template>
          <template #header-right>
            <dea-button @click="showDialogCallCharacteristicGraph"
              >차트</dea-button
            >
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.date"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <dialog-call-characteristic-graph
      ref="dialogCallCharacteristicGraph"
    ></dialog-call-characteristic-graph>

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :params.sync="individualDetailParams"
    />
    <!-- //인물정보 상세 : Layer Popup -->

    <!-- 가입자 정보 : Layer Popup -->
    <dialog-subscriber-info ref="dialogSubscriberInfo"></dialog-subscriber-info>
    <!-- //가입자 정보 : Layer Popup -->

    <dialog-number-list ref="dialogNumberList"></dialog-number-list>
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import CellButton from '@/components/grid/CellButton'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import DialogSelectPerson from './Dialog/DialogSelectPerson'
import DialogSelectDate from './Dialog/DialogSelectDate'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
import DialogCallCharacteristicGraph from './Dialog/DialogCallCharacteristicGraph'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'
import DialogSubscriberInfo from './Dialog/DialogSubscriberInfo'
import DialogNumberList from './Dialog/DialogNumberList'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'

export default {
  name: 'CallCharacteristicAnalysis',
  mixins: [listTemplate],
  components: {
    DialogSelectPerson,
    DialogSelectDate,
    DialogSelectDayTime,
    DialogCallCharacteristicGraph,
    DialogCallHistory,
    DialogIndividual,
    DialogSubscriberInfo,
    DialogNumberList
  },
  data() {
    return {
      gridInfo: {
        api: '/talk/chartr-anals-dtls',
        count: 0,
        columns: [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: 'No',
                field: 'no',
                width: 60,
                cellClass: 'align-right'
              },
              {
                headerName: '전화번호',
                field: 'telno',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno',
                  dsptchRcvDiv: 'DSPTCH'
                },
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '실사용자명',
                field: 'ruseIsrtyNm',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'outgoingUser'
                },
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '가입자',
                field: 'joinIsrtyNm',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'subscriber'
                },
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '상대전화번호 개수',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '발신만',
                field: 'partnTelDsptchCnt',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                sortable: true,
                unSortIcon: true
                // cellRendererFramework: CellButton,
                // cellRendererParams: {
                //   text: true,
                //   color: 'primary',
                //   event: 'outgoingNumberOnly'
                // }
              },
              {
                headerName: '착신만',
                field: 'partnTelRcvCnt',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                sortable: true,
                unSortIcon: true
                // cellRendererFramework: CellButton,
                // cellRendererParams: {
                //   text: true,
                //   color: 'primary',
                //   event: 'incommingNumberOnly'
                // }
              },
              {
                headerName: '발신과 착신',
                field: 'partnTelDsptchrcvCnt',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                sortable: true,
                unSortIcon: true
                // cellRendererFramework: CellButton,
                // cellRendererParams: {
                //   text: true,
                //   color: 'primary',
                //   event: 'outgoingIncommingNumberSum'
                // }
              }
            ]
          },
          {
            headerName: '통화 건수',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '발신',
                field: 'talkDsptchCnt',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:DSPTCH',
                  dsptchRcvDiv: 'DSPTCH'
                },
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '착신',
                field: 'talkRcvCnt',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:RCV',
                  dsptchRcvDiv: 'RCV'
                },
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '합계',
                field: 'talkCntSum',
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                width: 80,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:ALL'
                },
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '기능',
                field: 'function',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  outlined: true,
                  label: '차트',
                  event: 'chart'
                },
                editable: false
              }
            ]
          }
        ]
      },
      filter: {
        users: [],
        baseChc: 'RL_USER',
        date: ['2016-02-13', '2017-01-31'],
        weekofdayTime: [],
        callType: ['call', 'message', 'etc']
      },
      validError: {},
      dateMin: '',
      dateMax: '',
      baseChcSelectItems: [
        {
          label: '실사용자 기준',
          value: 'RL_USER'
        },
        {
          label: '전화번호 기준',
          value: 'TELNO'
        }
      ],
      individualDetail: false,
      individualDetailParams: {} // 인물정보(팝업/열람)
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    totalCount: {
      get: function() {
        return NumberUtils.numberWithCommas(this.gridInfo.count)
      },
      set: function() {}
    },
    getParams() {
      return {
        isrtyIds: this.filter.users,
        dateList: this.filter.date,
        baseChc: this.filter.baseChc,
        daysOfWeekTimesList: this.filter.weekofdayTime
        // talkTyId: this.filter.callType // TODO: 500:데이터베이스 시스템 오류 error
      }
    }
  },
  mounted() {},
  methods: {
    onReady() {
      this.loadData()
      /* TODO: Apply API to get Date min and max
    this.$api.analysis.handler.getDateMinMax(
      this.incidentInfo.id,
      (dateMin, dateMax) => {
        if (dateMin && dateMax) {
          this.dateMin = dateMin
          this.dateMax = dateMax
          this.filter.date = [dateMin, dateMax]

          this.setInitFilter(this.filter)
          this.updateFilter()
          this.loadData()
        }
      }
    )
    */
    },
    getColumns() {
      this.$refs.grid.setColumns(this.gridInfo.columns)
    },
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    toggle() {
      this.$nextTick(() => {
        if (this.filter.callType.length === 3) {
          this.filter.callType = []
        } else {
          this.filter.callType = ['call', 'message', 'etc']
        }
      })
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    showDialogCallCharacteristicGraph() {
      this.$refs.dialogCallCharacteristicGraph.show()
    },
    onCellButtonClicked(params) {
      let queryString = '{0}{1}{2}{3}'.format(
        this.filter.users.length > 0
          ? '&users=' + this.filter.users.join(',')
          : '',
        this.filter.date.length > 0
          ? '&date=' + this.filter.date.join(',')
          : '',
        this.filter.weekofdayTime.length > 0
          ? '&weekofdayTime=' + this.filter.weekofdayTime.join(',')
          : '',
        this.filter.callType.length > 0
          ? '&callType=' + this.filter.callType.join(',')
          : ''
      )

      if (params.event.match(/telno:[A-Z]+/i)) {
        this.$refs.dialogCallHistory.doShow(params)
      } else if (params.event == 'subscriber') {
        this.$refs.dialogSubscriberInfo.show(params.data.joinIsrtyId)
      } else if (params.event == 'outgoingUser') {
        this.individualDetailParams = { ...params }
        this.individualDetailParams.data = {
          no: 0,
          name: params.data.user,
          photo: '',
          ptName: '피의자',
          phoneNumber: params.data.number,
          nickname: '별칭',
          pgName: null,
          comName: '',
          divName: '',
          joinDate: '2017-02-11 14:37',
          updateDate: '2017-02-11 14:37',
          registeredUser: '등록자명',
          evidenceNumber: '증거번호234',
          memo: '',
          keyword: '',
          merge: null,
          represent: null
        }
        this.individualDetail = true
      } else if (params.event == 'outgoingCallOnly') {
        this.$refs.dialogCallHistory.show(params, queryString)
      } else if (params.event == 'incommingCallOnly') {
        this.$refs.dialogCallHistory.show(params, queryString)
      } else if (params.event == 'outgoingIncommingCallSum') {
        this.$refs.dialogCallHistory.show(params, queryString)
      } else if (params.event == 'outgoingNumberOnly') {
        this.$refs.dialogNumberList.show(params, queryString)
      } else if (params.event == 'incommingNumberOnly') {
        this.$refs.dialogNumberList.show(params, queryString)
      } else if (params.event == 'outgoingIncommingNumberSum') {
        this.$refs.dialogNumberList.show(params, queryString)
      }
    }
  }
}
</script>
