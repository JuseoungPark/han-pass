<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <dialog-select-person
                v-model="filter.isrtyId"
                show-on-load
                use-pagination
                label="인물 선택"
              ></dialog-select-person>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['isrtyId'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>밀도조건</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                v-model="filter.lmttTime"
                :clearable="false"
                label="시간"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">분 내에</div>
              <dea-text-field
                v-model="filter.lmttCnt"
                :clearable="false"
                label="건수"
                class="flex-0 align-center"
                style="width:40px;"
              ></dea-text-field>
              <div class="text text-truncate">건 이상</div>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['lmttTime', 'lmttCnt'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>통화조건</dea-label>
            </v-col>
            <v-col class="d-flex" cols="4">
              <dea-radio-group
                v-model="filter.callCondition"
                row
                :mandatory="false"
                :items="callConditionItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col class="d-flex">
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdayTime"
              ></dialog-select-day-time>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdayTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          async
          disable-auto-load
          use-pagination
          row-selection-multiple
          suppress-row-click-selection
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.count"
          @cellButtonClicked="onCellButtonClicked"
        >
          <template #header-left>
            <v-tabs v-model="totalCount" class="dea-tabs">
              <v-tab>통화밀도분석내역 ({{ totalCount }})</v-tab>
            </v-tabs>
          </template>
        </dea-grid>
      </div>
    </section>

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.date"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :params.sync="individualDetailParams"
    />

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import DialogSelectPerson from './Dialog/DialogSelectPerson'
import DialogSelectDate from './Dialog/DialogSelectDate'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import CellButton from '@/components/grid/CellButton'
import { GridFormatter } from '@/utils/GridFormatter'

export default {
  name: 'CallDensityAnalysis',
  mixins: [listTemplate],
  components: {
    DialogSelectPerson,
    DialogSelectDate,
    DialogSelectDayTime,
    DialogIndividual,
    DialogCallHistory
  },
  data() {
    return {
      gridInfo: {
        api: '/talk/dn-anals-dtls',
        count: 0,
        columns: [
          {
            headerName: '통화 상대 정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'talkReltRuseIsrtyNm',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'outgoingUser'
                }
              },
              {
                headerName: '전화번호',
                field: 'telno',
                sortable: true,
                unSortIcon: true,
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno',
                  dsptchRcvDiv: 'DSPTCH'
                }
              }
            ]
          },
          {
            headerName: '통화 내용',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작일시',
                field: 'talkBgngDt',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '통화종료일시',
                field: 'talkEndDt',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '빈도',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '총 건수',
                field: 'fqTotalCnt',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:ALL'
                }
              },
              {
                headerName: '발신건수',
                field: 'fqDsptchCnt',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:DSPTCH',
                  dsptchRcvDiv: 'DSPTCH'
                }
              },
              {
                headerName: '착신건수',
                field: 'fqRcvCnt',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.numberWithCommas,
                cellClass: 'align-right',
                cellRendererFramework: CellButton,
                cellRendererParams: {
                  text: true,
                  color: 'primary',
                  event: 'telno:RCV',
                  dsptchRcvDiv: 'RCV'
                }
              },
              {
                headerName: '총통화량',
                field: 'totalTalkQy',
                sortable: true,
                unSortIcon: true,
                // valueFormatter: GridFormatter.timeWithColons,
                width: 60,
                cellClass: 'align-right'
              }
            ]
          }
        ]
      },
      filter: {
        lmttTime: 60,
        lmttCnt: 2,
        isrtyId: [],
        date: ['2016-02-13', '2017-01-31'],
        weekofdayTime: [],
        callCondition: 'ALL'
      },
      validError: {},
      dateMin: '',
      dateMax: '',
      callConditionItems: [
        {
          label: '전체',
          value: 'ALL'
        },
        {
          label: '통화만 계산',
          value: 'TALK'
        }
      ],
      individualDetail: false,
      individualDetailParams: {} // 인물정보(팝업/열람)
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    totalCount: {
      get: function() {
        return NumberUtils.numberWithCommas(this.gridInfo.count)
      },
      set: function() {}
    },
    getParams() {
      return {
        isrtyIds: this.filter.isrtyId,
        lmttTime: this.filter.lmttTime,
        lmttCnt: this.filter.lmttCnt,
        dateList: this.filter.date,
        daysOfWeekTimesList: this.filter.weekofdayTime,
        talkCnd: this.filter.callCondition
      }
    }
  },
  mounted() {
    /* TODO: Apply API to get Date min and max
    this.$api.analysis.handler.getDateMinMax(
      this.incidentInfo.id,
      (dateMin, dateMax) => {
        if (dateMin && dateMax) {
          this.dateMin = dateMin
          this.dateMax = dateMax
          this.filter.date = [dateMin, dateMax]

          this.setInitFilter(this.filter)
          this.updateFilter()
        }
      }
    )
    */
  },
  methods: {
    getColumns() {
      this.$refs.grid.setColumns(this.gridInfo.columns)
    },
    onSearch() {
      if (this.filter.isrtyId.length === 0) {
        this.$alert('인물을 선택해주세요.')
      } else {
        this.$refs.grid.reset()
        this.loadData()
      }
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    onCellButtonClicked(params) {
      if (params.event == 'telno') {
        this.$refs.dialogCallHistory.doShow(params)
      } else if (params.event.match(/telno:[A-Z]+/i)) {
        this.$refs.dialogCallHistory.doShow(params)
      } else if (params.event == 'outgoingUser') {
        this.individualDetailParams = { ...params }
        this.individualDetailParams.data = {
          no: 0,
          name: params.data.user,
          photo: '',
          ptName: '피의자',
          phoneNumber: params.data.number,
          nickname: '별칭',
          pgName: null,
          comName: '',
          divName: '',
          joinDate: '2017-02-11 14:37',
          updateDate: '2017-02-11 14:37',
          registeredUser: '등록자명',
          evidenceNumber: '증거번호234',
          memo: '',
          keyword: '',
          merge: null,
          represent: null
        }
        this.individualDetail = true
      } else if (params.event == 'totalNo') {
        this.$refs.dialogCallHistory.show(params)
      } else if (params.event == 'outgoingNo') {
        this.$refs.dialogCallHistory.show(params)
      } else if (params.event == 'incommingNo') {
        this.$refs.dialogCallHistory.show(params)
      }
    }
  }
}
</script>
