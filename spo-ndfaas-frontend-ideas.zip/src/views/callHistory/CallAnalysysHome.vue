<template>
  <v-container class="call-history-status">
    <section class="dea-section status-field">
      <div class="inner">
        <dea-card class="mx-auto" title-class="align-left">
          <template slot="title"
            >통화내역처리현황
            <v-layout class="v-toolbar valign-middle flex-0 ml-4">
              <div class="info-message">
                <strong>{{ updateDate }}</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="updateStatus"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-layout>
          </template>
          <div class="divide">
            <v-col>
              <v-card class="dea-card-field status-list-wrap">
                <v-card-title class="align-center">
                  통신사실확인서 처리현황
                </v-card-title>
                <v-card-text>
                  <div class="status-list">
                    <v-list v-model="callStatusList" class="d-flex flex-wrap">
                      <v-list-item
                        v-for="(callItem, i) in callStatusItems"
                        :key="i"
                        style="max-width:50%; height:140px; cursor:pointer;"
                        class="active"
                        @click="showDialogCallStatus(callItem)"
                      >
                        <v-list-item-content>
                          <v-list-item-subtitle
                            :class="
                              callItem.title === '실패파일' ? 'error--text' : ''
                            "
                          >
                            <span>{{ callItem.count | numberWithCommas }}</span>
                          </v-list-item-subtitle>
                          <v-list-item-title class="mt-2">
                            <dea-tooltip :content="callItem.tooltip" bottom>
                              <template v-slot:activator="{ on, attrs }">
                                <div
                                  class="text pl-4 pr-4 align-center"
                                  v-bind="attrs"
                                  v-on="on"
                                >
                                  {{ callItem.title }}
                                </div>
                              </template>
                            </dea-tooltip>
                          </v-list-item-title>
                        </v-list-item-content>
                      </v-list-item>
                    </v-list>
                  </div>
                </v-card-text>
                <v-card-actions>
                  <div class="btn-group align-center">
                    <dea-tooltip content="최근 1주일이내 처리된 성공파일수" top>
                      <template v-slot:activator="{ on, attrs }">
                        <div class="text pl-4 pr-4" v-bind="attrs" v-on="on">
                          신규 {{ callStatusData.newCnt | numberWithCommas }}건
                        </div>
                      </template>
                    </dea-tooltip>
                    <v-divider vertical class="ma-0" />
                    <dea-tooltip
                      content="분석을 위한 처리가 진행중인 파일 수"
                      top
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <div class="text pl-4 pr-4" v-bind="attrs" v-on="on">
                          진행중
                          {{ callStatusData.progrsCnt | numberWithCommas }}건
                        </div>
                      </template>
                    </dea-tooltip>
                  </div>
                </v-card-actions>
              </v-card>
            </v-col>
            <v-col>
              <v-card class="dea-card-field status-list-wrap">
                <v-card-title class="align-center">
                  가입자내역서 처리현황
                </v-card-title>
                <v-card-text>
                  <div class="status-list">
                    <v-list
                      v-model="subscriberStatusList"
                      class="d-flex flex-wrap"
                    >
                      <v-list-item
                        v-for="(sItem, i) in subscriberStatusItems"
                        :key="i"
                        style="max-width:50%; height:140px;cursor:pointer;"
                        class="active"
                        @click="showDialogCallStatus(sItem)"
                      >
                        <v-list-item-content>
                          <v-list-item-subtitle
                            :class="
                              sItem.title === '실패파일' ? 'error--text' : ''
                            "
                          >
                            <span>{{ sItem.count }}</span>
                          </v-list-item-subtitle>
                          <v-list-item-title class="mt-2">
                            <dea-tooltip :content="sItem.tooltip" bottom>
                              <template v-slot:activator="{ on, attrs }">
                                <div
                                  class="text pl-4 pr-4 align-center"
                                  v-bind="attrs"
                                  v-on="on"
                                >
                                  {{ sItem.title }}
                                </div>
                              </template>
                            </dea-tooltip>
                          </v-list-item-title>
                        </v-list-item-content>
                      </v-list-item>
                    </v-list>
                  </div>
                </v-card-text>
                <v-card-actions>
                  <div class="btn-group align-center">
                    <dea-tooltip content="최근 1주일이내 처리된 성공파일수" top>
                      <template v-slot:activator="{ on, attrs }">
                        <div class="text pl-4 pr-4" v-bind="attrs" v-on="on">
                          신규
                          {{ subscriberStatusData.newCnt | numberWithCommas }}건
                        </div>
                      </template>
                    </dea-tooltip>
                    <v-divider vertical class="ma-0" />
                    <dea-tooltip
                      content="분석을 위한 처리가 진행중인 파일 수"
                      top
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <div class="text pl-4 pr-4" v-bind="attrs" v-on="on">
                          진행중
                          {{
                            subscriberStatusData.progrsCnt | numberWithCommas
                          }}건
                        </div>
                      </template>
                    </dea-tooltip>
                  </div>
                </v-card-actions>
              </v-card>
            </v-col>
          </div>
          <template slot="actions">
            <v-row>
              <v-col cols="3">
                <dea-button large block>분석대상파일 파일추가</dea-button>
              </v-col>
              <v-col cols="3">
                <dea-button
                  large
                  block
                  outlined
                  @click="showDialogCallStatus(1)"
                  >실패파일 확인</dea-button
                >
              </v-col>
              <v-col cols="6">
                <v-btn
                  large
                  block
                  color="primary"
                  @click="goLinkByName('IntegrationCallHistory')"
                >
                  통화내역분석 자세히보기
                  <v-icon>mdi-plus</v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section quick-menu">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title">
            디지털증거 통합분석 <strong>Quick Menu</strong>
          </template>
          <v-row>
            <v-col cols="3">
              <dea-button
                block
                large
                color="primary"
                @click="goLinkByName('PersonManagement')"
              >
                <v-icon>mdi-account-alert</v-icon>
                주요인물관리
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button
                block
                large
                @click="goLinkByName('IntegratedCorrelationChart')"
              >
                <v-icon>mdi-account-multiple</v-icon>
                인물중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button
                block
                large
                @click="goLinkByName('TimeSeriesAnalysis')"
              >
                <v-icon>mdi-clock-time-three-outline</v-icon>
                시간중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button block large>
                <v-icon>mdi-map-marker-radius</v-icon>
                위치중심분석
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <!-- 통화내역처리현황 (성공/중복/실패) : Layer Popup -->
    <dialogCallHistoryStatus
      ref="dialogCallHistoryStatus"
      :tabSelected="popTabSelected"
    />
    <!-- //통화내역처리현황 (성공/중복/실패) : Layer Popup -->
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'
import routeMixin from '@/mixins/route'
import dialogCallHistoryStatus from './Dialog/DialogCallHistoryStatus'

export default {
  name: 'CallAnalysysHome',
  mixins: [routeMixin],
  components: { dialogCallHistoryStatus },
  data() {
    return {
      popTabSelected: 0,
      // Modal Popup
      callHistoryStatus: false,
      // Setting for Publishing
      loading: false,
      updateDate: '',
      callStatusList: null,
      callStatusData: {
        totCnt: 0,
        scsCnt: 0,
        dplctCnt: 0,
        failrCnt: 0,
        newCnt: 0,
        progrsCnt: 0
      },
      callStatusItems: [
        {
          key: 'totCnt',
          title: '전체',
          count: 0,
          tooltip: '분석 처리 요청중인 모든 파일수'
        },
        {
          key: 'scsCnt',
          title: '성공파일',
          count: 0,
          tooltip: '처리 완료되어 분석준비된 파일수'
        },
        {
          key: 'dplctCnt',
          title: '중복파일',
          count: 0,
          tooltip: '재업로드되어 처리된 중복 파일수'
        },
        {
          key: 'failrCnt',
          title: '실패파일',
          count: 0,
          tooltip: '분석 처리가 불가능한 파일수'
        }
      ],
      subscriberStatusList: null,
      subscriberStatusData: {
        totCnt: 0,
        scsCnt: 0,
        dplctCnt: 0,
        failrCnt: 0,
        newCnt: 0,
        progrsCnt: 0
      },
      subscriberStatusItems: [
        {
          key: 'totCnt',
          title: '전체',
          count: 0,
          tooltip: '분석 처리 요청중인 모든 파일수'
        },
        {
          key: 'scsCnt',
          title: '성공파일',
          count: 0,
          tooltip: '처리 완료되어 분석준비된 파일수'
        },
        {
          key: 'dplctCnt',
          title: '중복파일',
          count: 0,
          tooltip: '재업로드되어 처리된 중복 파일수'
        },
        {
          key: 'failrCnt',
          title: '실패파일',
          count: 0,
          tooltip: '분석 처리가 불가능한 파일수'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['incidentInfo'])
  },
  mounted() {
    this.updateStatus()
  },
  methods: {
    showDialogCallStatus: function(obj) {
      this.popTabSelected = 0
      if (typeof obj === 'number') {
        this.popTabSelected = obj
      } else {
        if (obj && obj.title === '실패파일') this.popTabSelected = 1
      }
      this.$refs.dialogCallHistoryStatus.show()
    },
    updateStatus() {
      this.loading = true

      this.$axios
        .all([
          this.$api.analysis.get(
            `/talk/commn-fact-cnfrmn-sttus?incdntId=${this.incidentInfo.id}`
          ),
          this.$api.analysis.get(
            `/talk/sbscrber-dtstmn-prcs-sttus?incdntId=${this.incidentInfo.id}`
          )
        ])
        .then(
          this.$axios.spread((...responses) => {
            let item = {}
            if (responses[0].data.code === '200') {
              for (const [key, value] of Object.entries(
                responses[0].data.result
              )) {
                this.callStatusData[key] = value
                item = this.callStatusItems.filter((e) => e.key === key)
                if (item.length > 0) item[0].count = value
              }
            }

            if (responses[1].data.code === '200') {
              for (const [key, value] of Object.entries(
                responses[1].data.result
              )) {
                this.subscriberStatusData[key] = value
                item = this.subscriberStatusItems.filter((e) => e.key === key)
                if (item.length > 0) item[0].count = value
              }
            }

            this.updateDate = moment().format('YYYY-MM-DD HH:mm')
            this.loading = false
          })
        )
    }
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
