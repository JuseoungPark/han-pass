<template>
  <v-menu v-model="menu" close-on-content-click>
    <template v-slot:activator="{ on, attrs }">
      <v-layout>
        <v-text-field
          v-model="selectedText"
          dense
          outlined
          :label="label"
          :placeholder="placeholder"
          prepend-inner-icon="mdi-clock-outline"
          v-bind="attrs"
          v-on="on"
        ></v-text-field>
      </v-layout>
    </template>
    <dea-dialog v-model="menu" title="요일/시간대 선택" width="900px">
      <section class="dea-section">
        <div class="inner">
          {{ $d(new Date(), 'short') }}
          <v-layout class="shuttle">
            <v-col>
              <dea-card class="pa-0">
                <v-sheet height="468" class="overflow-y-auto pa-4">
                  <section class="dea-section">
                    <div class="inner">
                      <dea-card class="pa-0 ba-0">
                        <template slot="title"
                          >1. 요일을 선택하세요
                          <v-layout class="align-right">
                            <dea-checkbox
                              v-model="allSelWeek"
                              label="전체선택"
                              @change="setAllWeek"
                            ></dea-checkbox>
                          </v-layout>
                        </template>
                        <v-row no-gutters>
                          <v-col class="d-flex flex-1">
                            <v-checkbox
                              v-for="(weekItem, index) in weekItems"
                              v-model="weekItem.value"
                              :key="index"
                              :label="weekItem.label"
                              class="dea-btn-checkbox"
                              @change="setWeek"
                            ></v-checkbox>
                          </v-col>
                        </v-row>
                      </dea-card>
                    </div>
                  </section>
                  <section class="dea-section">
                    <div class="inner chart-wrap">
                      <dea-card class="pa-0 ba-0">
                        <template slot="title"
                          >2. 시간대를 선택하세요
                          <v-layout class="align-right">
                            <dea-checkbox
                              v-model="allSelTime"
                              label="전체선택"
                              @change="setAlltime"
                            />
                          </v-layout>
                        </template>
                        <v-row no-gutters>
                          <v-col
                            class="d-flex flex-column flex-1 mr-2"
                            cols="3"
                          >
                            <template v-for="(timeSlot, index) in timeSlots">
                              <v-checkbox
                                v-model="timeSlot.value"
                                :key="index"
                                :label="timeSlot.label"
                                class="dea-btn-checkbox"
                                style="width:100%;"
                                @change="setTimeSlot(timeSlot.value, index)"
                                v-if="index < 4"
                              ></v-checkbox>
                            </template>
                          </v-col>
                          <v-col class="d-flex justify-space-between flex-wrap">
                            <v-checkbox
                              v-for="(time, index) in timeItems"
                              v-model="time.value"
                              :key="index"
                              :label="time.label"
                              class="dea-btn-checkbox"
                              style="width:39.6px;"
                              @change="setTime(time, index)"
                            ></v-checkbox>
                          </v-col>
                        </v-row>
                        <v-row no-gutters>
                          <v-col class="d-flex flex-1">
                            <template v-for="(timeSlot, index) in timeSlots">
                              <v-checkbox
                                v-model="timeSlot.value"
                                :key="index"
                                :label="timeSlot.label"
                                class="dea-btn-checkbox word-break align-center"
                                @change="setTimeSlot(timeSlot.value, index)"
                                v-if="index >= 4"
                              ></v-checkbox>
                            </template>
                          </v-col>
                        </v-row>
                      </dea-card>
                    </div>
                  </section>
                </v-sheet>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                textindent
                outlined
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                @click="goSelected"
              >
                우측으로 이동
              </dea-button>
              <dea-button
                icon
                outlined
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                @click="delSelected"
              ></dea-button>
            </v-col>
            <v-col>
              <dea-card class="pa-0">
                <v-list dense height="468" class="overflow-y-auto">
                  <v-list-item-group multiple v-model="selected">
                    <v-list-item
                      v-for="(item, index) in selectedList"
                      :key="index"
                    >
                      <v-list-item-content class="flex-row">
                        <v-list-item-title>
                          <v-row no-gutters>
                            <v-col class="d-flex"
                              ><dea-text-field
                                :clearable="false"
                                readonly
                                v-model="item.label"
                              ></dea-text-field>
                            </v-col>
                          </v-row>
                        </v-list-item-title>
                        <v-list-item-action>
                          <dea-button
                            icon
                            textindent
                            outlined
                            prepend-icon="mdi-close"
                            @click="doDelete(index)"
                          >
                            삭제
                          </dea-button>
                        </v-list-item-action>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>

      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="onClickCancel">취소</dea-button>
          <dea-button color="primary" @click="onClickOk">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
  </v-menu>
</template>

<script>
import apiMixin from '@/mixins/apiMixin'
import { NumberUtils } from '@/utils/NumberUtils'

export default {
  name: 'DialogSelectDayTime',
  mixins: [apiMixin],
  props: {
    label: {
      type: String,
      default: undefined
    },
    placeholder: {
      type: String,
      default: undefined
    },
    value: {
      default: ''
    }
  },
  data() {
    return {
      menu: false,
      selectedText: '',
      selected: [],
      allSelWeek: false,
      allSelTime: false,
      weekdaysSel: [false, false, false, false, false, false, false],
      weekItems: [
        { label: '월', value: false, longLabel: '월요일' },
        { label: '화', value: false, longLabel: '화요일' },
        { label: '수', value: false, longLabel: '수요일' },
        { label: '목', value: false, longLabel: '목요일' },
        { label: '금', value: false, longLabel: '금요일' },
        { label: '토', value: false, longLabel: '토요일' },
        { label: '일', value: false, longLabel: '일요일' }
      ],
      timeSlots: [
        { label: '새벽', value: false, min: 0, max: 5 },
        { label: '오전', value: false, min: 6, max: 11 },
        { label: '오후', value: false, min: 12, max: 17 },
        { label: '밤', value: false, min: 18, max: 23 },
        { label: '출근시간 7시~10시', value: false, min: 7, max: 10 },
        { label: '점심시간 11시~13시', value: false, min: 11, max: 13 },
        { label: '퇴근시간 17시~20시', value: false, min: 17, max: 20 },
        { label: '심야시간 0시~3시', value: false, min: 0, max: 3 }
      ],
      timeItems: [],
      selectedList: [
        /*{
          weeks: [3, 6],
          times: [[7], [7, 10]],
          label: '목요일, 일요일 7시, 7~10시'
        },*/
      ],
      localData: []
    }
  },
  methods: {
    onClickCancel() {
      this.menu = false
    },
    onClickOk() {
      this.menu = false
      this.selectedText = this.selectedList
        .map((item) => {
          return item.label
        })
        .join()

      let week
      let time = []
      this.localData = []
      this.selectedList.forEach((e) => {
        week = ''
        if (e.weeks.length > 0) {
          let stringWeeks = Array.from(e.weeks, (w) =>
            NumberUtils.dayToString(w)
          )
          week = stringWeeks.join('/')
        }
        time = []
        e.time.forEach((et) => {
          if (et.length === 1) {
            time.push(et[0])
          } else {
            time.push('{0}-{1}'.format(et[0], et[et.length - 1]))
          }
        })
        this.localData.push('{0};{1}'.format(week, time.join('/')))
      })

      this.$emit('input', this.localData)
    },
    setAllWeek(flag) {
      this.weekItems = this.weekItems.map((item) => {
        item.value = flag
        return item
      })
    },
    setWeek() {
      // console.log(week, index)
      let w = this.weekItems.filter((item) => item.value === true)
      this.allSelWeek = this.weekItems.length === w.length
    },
    setAlltime(flag) {
      this.timeItems = this.timeItems.map((item) => {
        item.value = flag
        return item
      })
      this.timeSlots = this.timeSlots.map((item) => {
        item.value = flag
        return item
      })
    },
    setTime() {
      // console.log(time, index)
      let t = this.timeItems.filter((item) => item.value === true)
      let slotChk = t.map((item) => item.label)
      this.timeSlots.forEach((item) => {
        item.value = item.times.every((it) => slotChk.includes(it))
      })
      this.allSelTime = this.timeItems.length === t.length
    },
    setTimeSlot(selected, index) {
      let min = this.timeSlots[index].min
      let max = this.timeSlots[index].max
      while (min <= max) {
        this.timeItems[min].value = selected
        min++
      }
      let t = this.timeItems.filter((item) => item.value === true)
      this.allSelTime = this.timeItems.length === t.length
    },
    selectedWeeks() {
      let w = this.weekItems.filter((item) => item.value === true)
      let label = w.map((i) => i.longLabel).join('/')
      let value = this.weekItems
        .map((e, i) => (e.value === true ? i : ''))
        .filter(String)

      return { label: label, value: value }
    },
    selectedTimes() {
      let t = this.timeItems.filter((item) => item.value === true)
      let value = []
      let time = []
      let before = null
      if (t.length === 1) {
        time.push(parseInt(t[0].label))
        value.push(time)
      } else {
        t.forEach((item, index) => {
          let label = parseInt(item.label)
          if (index === 0) {
            time.push(label)
          } else {
            if (before + 1 === label) {
              time.push(label)
              // 마지막값이면
              if (index === t.length - 1) value.push(time)
            } else {
              if (time.length > 0) value.push(time)
              time = []
              time.push(label)
              if (index === t.length - 1) value.push(time)
            }
          }
          before = label
        })
      }
      let label = value
        .map((item) => {
          let label = ''
          if (item[0] === item[item.length - 1]) {
            label = `${item[0]}시`
          } else {
            label = `${item[0]}~${item[item.length - 1]}시`
          }
          return label
        })
        .join('/')
      return { label: label, value: value }
    },
    goSelected() {
      let weeks = this.selectedWeeks()
      let times = this.selectedTimes()
      let label = `${weeks.label} ${times.label}`
      this.selectedList.push({
        weeks: weeks.value,
        time: times.value,
        label: label
      })
      this.doReset()
    },
    delSelected() {
      this.selectedList = this.selectedList.filter(
        (item, index) => !this.selected.includes(index)
      )
      this.doReset()
    },
    doReset() {
      this.allSelWeek = false
      this.allSelTime = false
      this.weekItems = this.weekItems.map((item) => {
        item.value = false
        return item
      })
      this.timeSlots = this.timeSlots.map((item) => {
        item.value = false
        return item
      })
      this.timeItems = this.timeItems.map((item) => {
        item.value = false
        return item
      })
    },
    doDelete(index) {
      this.selectedList.splice(index, 1)
    }
  },
  watch: {
    value(selected) {
      if (selected.length === 0) {
        this.selectedList = []
        this.selectedText = ''
      }
    }
  },
  mounted() {
    for (let index = 0; index < 24; index++) {
      this.timeItems.push({ label: `${index}`, value: false })
    }
    this.timeSlots.forEach((item) => {
      let min = item.min
      let max = item.max
      item.times = []
      while (min <= max) {
        item.times.push(`${min}`)
        min++
      }
    })
  }
}
</script>
