<template>
  <!-- 기지국 기준 통화 내역 : Layer Popup -->
  <dea-dialog-grid-basic
    ref="grid"
    :title="`${fieldkey} 전화번호 목록`"
    :grid-tabitems="[{ name: '총 전화번호' }]"
    width="1280px"
    :api="api"
    :columns="columns"
  >
    <!-- <template #header-right>
      <grid-comm-btn
        @goBookmark="goBookmark"
        @goExcept="goExcept"
      ></grid-comm-btn>
    </template> -->
  </dea-dialog-grid-basic>
  <!-- //기지국 기준 통화 내역 : Layer Popup -->
</template>

<script>
// import CellCheckbox from '@/components/grid/CellCheckbox'
// import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
// import GridCommBtn from '../include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'
export default {
  name: 'DialogNumberList',
  mixins: [GridCommMixins, eventBus],
  components: {
    // GridCommBtn
  },
  data() {
    return {
      api: '/api/call/number',
      fieldkey: '',
      fieldvalue: '',
      columns: [
        // {
        //   colId: 'numberRowSelector',
        //   headerName: '열 선택',
        //   field: 'rowSelector',
        //   width: 20,
        //   headerComponentFramework: CellCheckboxHeader,
        //   cellRendererFramework: CellCheckbox
        // },
        {
          colId: 'numberUser',
          headerName: '실사용자',
          field: 'user',
          sortable: true,
          unSortIcon: true
        },
        {
          colId: 'numberType',
          headerName: '전화번호 유형',
          field: 'type',
          sortable: true,
          unSortIcon: true
        },
        {
          colId: 'numberNumber',
          headerName: '전화번호',
          field: 'number',
          sortable: true,
          unSortIcon: true
        },
        {
          colId: 'numberDialing',
          headerName: '국번',
          field: 'dialing'
        },
        {
          colId: 'numberCountryCode',
          headerName: '국가코드',
          field: 'countryCode'
        }
      ]
    }
  },
  methods: {
    show(params, queryString = '') {
      let filter = ''
      if (params.event == 'outgoingNumberOnly') {
        filter = '&incommingNumberOnly=' + params.data.number + queryString
      } else if (params.event == 'incommingNumberOnly') {
        filter = '&outgoingNumberOnly=' + params.data.number + queryString
      } else if (params.event == 'outgoingIncommingNumberSum') {
        filter =
          '&outgoingIncommingNumberSum=' + params.data.number + queryString
      }
      this.$refs.grid.setFilter(filter)
      this.$refs.grid.show()
    },
    hide() {}
  }
}
</script>
