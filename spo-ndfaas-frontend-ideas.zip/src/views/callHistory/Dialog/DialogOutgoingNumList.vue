<template>
  <!-- 발신 통화 내역 : Layer Popup -->
  <dea-dialog-grid-basic
    ref="grid"
    title="전화번호 기준 통화 내역"
    width="1280px"
    :api="api"
    :columns="columns"
  >
    <template v-slot:header>
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>전화번호 정보: </dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">{{ name }} / {{ number }}</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
    </template>
    <template #header-right>
      <grid-comm-btn
        @goBookmark="goBookmark"
        @goExcept="goExcept"
      ></grid-comm-btn>
    </template>
  </dea-dialog-grid-basic>
  <!-- //발신 통화 내역 : Layer Popup -->
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import { GridFormatter } from '@/utils/GridFormatter'
import CellBookmark from '@/components/grid/CellBookmark'
import CellExcept from '@/components/grid/CellExcept'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import GridCommBtn from '../include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'

export default {
  name: 'DialogOutgoingNumList',
  mixins: [GridCommMixins, eventBus],
  components: {
    GridCommBtn
  },
  data() {
    return {
      api: '/api/call/history',
      name: '',
      number: '',
      columns: [
        {
          headerName: '기능',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '열 선택',
              field: 'rowSelector',
              width: 20,
              headerComponentFramework: CellCheckboxHeader,
              cellRendererFramework: CellCheckbox
            },
            {
              headerName: '북마크',
              field: 'bookmark',
              width: 50,
              cellRendererFramework: CellBookmark
            },
            {
              headerName: '제외',
              field: 'except',
              width: 50,
              cellRendererFramework: CellExcept,
              cellRendererParams: {
                except: 'Y'
              }
            }
          ]
        },
        {
          headerName: '발신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '사용자',
              field: 'outgoingUser',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'outgoingNumber',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '착신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '사용자',
              field: 'incommingUser',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'incommingNumber',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '통화정보',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '통화시작',
              field: 'dateTime',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통화시간',
              field: 'length',
              sortable: true,
              unSortIcon: true,
              valueFormatter: GridFormatter.timeWithColons
            },
            {
              headerName: '구분',
              field: 'type',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '기지국',
              field: 'station',
              sortable: true,
              unSortIcon: true
            }
          ]
        }
      ]
    }
  },
  methods: {
    show(params) {
      this.$refs.grid.setFilter('&outgoingNumber=' + params.value)
      this.name = params.data[params.colDef.field.replace('Number', 'User')]
      this.number = params.value
      this.$refs.grid.show()
    },
    hide() {}
  }
}
</script>
