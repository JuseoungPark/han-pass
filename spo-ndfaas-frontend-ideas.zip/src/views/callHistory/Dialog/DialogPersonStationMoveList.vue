<template>
  <!-- 전화번호 기준 기지국 이동내역 : Layer Popup -->
  <dea-dialog-grid-basic
    ref="DialogGridBasic"
    title="전화번호 기준 기지국 이동내역"
    :grid-tabitems="[{ name: '전화번호 기준 기지국 이동내역' }]"
    width="1280px"
    :api="api"
    :columns="columns"
  >
    <template v-slot:header>
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col cols="1">
                <dea-label>{{ fieldkey }}</dea-label>
              </v-col>
              <v-col class="d-flex">
                <div class="text">{{ fieldvalue }}</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
    </template>
  </dea-dialog-grid-basic>
  <!-- // 전화번호 기준 기지국 이동내역 : Layer Popup -->
</template>

<script>
// import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
export default {
  name: 'DialogPersonStationMoveList',
  data() {
    return {
      api: '/base-station/base-stataion-by-telno',
      fieldkey: '실사용자 정보',
      fieldvalue: '',
      columns: [
        {
          headerName: '기지국 (발신자 추정위치)',
          field: 'station1',
          sortable: true,
          unSortIcon: true
        },
        {
          headerName: '정제주소',
          field: 'address1',
          sortable: true,
          unSortIcon: true
        },
        {
          headerName: '최초통화시작일시',
          field: 'dateTime',
          sortable: true,
          unSortIcon: true
        },
        {
          headerName: '마지막통화일시',
          field: 'eDateTime',
          sortable: true,
          unSortIcon: true,
          valueFormatter: (params) => {
            return this.$moment(params.data.dateTime)
              .add(params.value, 'seconds')
              .format('YYYY-MM-DD HH:mm:ss')
          }
        },
        {
          headerName: '통화 건수',
          field: 'callCount1',
          sortable: true,
          unSortIcon: true,
          valueFormatter: GridFormatter.numberWithCommas,
          width: 100,
          cellClass: 'align-right'
        }
      ]
    }
  },
  methods: {
    show(params) {
      this.fieldkey = '실사용자 정보'
      this.fieldvalue = `${params.data.dsptchUserNm} ${params.data.dsptchTelno}`
      let filter = 'acntIdntfcValue={0}'.format(params.data.dsptchTelno)
      this.$refs.DialogGridBasic.setFilter(filter)
      this.$refs.DialogGridBasic.show()
    },
    hide() {}
  }
}
</script>
