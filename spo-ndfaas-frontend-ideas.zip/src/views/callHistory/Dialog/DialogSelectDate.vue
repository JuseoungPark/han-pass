<template>
  <dea-dialog v-model="isShow" title="기간 선택" width="1100px">
    <section class="dea-section">
      <div class="inner">
        <v-layout class="shuttle">
          <v-col cols="8">
            <v-row no-gutters class="list-top">
              <v-col class="d-flex">
                <div class="text">
                  기간을 선택해주세요. 달력 혹은 통화량 그래프에서 중복선택
                  가능합니다
                </div>
              </v-col>
            </v-row>
            <dea-card class="pa-0">
              <v-sheet height="574" class="overflow-y-auto pa-4">
                <section class="dea-section">
                  <div class="inner">
                    <dea-card>
                      <template slot="title">달력</template>
                      <v-row no-gutters>
                        <v-col class="d-flex">
                          <v-date-picker
                            ref="startDatePicker"
                            full-width
                            v-model="pickerDate"
                            :locale="locale"
                            :day-format="getDate"
                            no-title
                            scrollable
                            range
                            @input="onInputStartDate"
                          ></v-date-picker>
                          <v-date-picker
                            ref="endDatePicker"
                            full-width
                            v-model="pickerDate"
                            :locale="locale"
                            :day-format="getDate"
                            no-title
                            scrollable
                            range
                            @input="onInputEndDate"
                          ></v-date-picker>
                        </v-col>
                      </v-row>
                    </dea-card>
                  </div>
                </section>
                <section class="dea-section">
                  <div class="inner chart-wrap">
                    <dea-card>
                      <template slot="title">통화 빈도 그래프</template>
                      <v-row no-gutters>
                        <v-col class="d-flex"></v-col>
                      </v-row>
                      <template slot="actions">
                        <div class="btn-group">
                          <v-col class="align-center">
                            <dea-button>이전</dea-button>
                            <dea-button>다음</dea-button>
                          </v-col>
                        </div>
                      </template>
                    </dea-card>
                  </div>
                </section>
              </v-sheet>
            </dea-card>
          </v-col>
          <v-col class="btn-wrap">
            <dea-button
              icon
              textindent
              outlined
              title="우측으로 이동"
              prepend-icon="mdi-arrow-right-thick"
              bottom
              @click="onClickMoveRight"
            >
              우측으로 이동
            </dea-button>
            <dea-button
              icon
              textindent
              outlined
              title="좌측으로 이동"
              prepend-icon="mdi-arrow-left-thick"
              bottom
            >
              좌측으로 이동
            </dea-button>
          </v-col>
          <v-col>
            <v-row no-gutters class="list-top">
              <v-col class="d-flex">
                <div class="text">
                  기간이 선택되었습니다.
                </div>
              </v-col>
            </v-row>
            <dea-card class="pa-0">
              <v-list dense height="574" class="overflow-y-auto">
                <v-list-item-group>
                  <template v-for="(item, i) in selectedDate">
                    <v-list-item :key="`range-${i}`" :value="item" inactive>
                      <v-list-item-content class="flex-row">
                        <v-list-item-title>
                          <v-row no-gutters>
                            <v-col class="d-flex"
                              ><dea-date-picker-range
                                v-model="selectedDate[i]"
                                label="기간선택"
                                :close-on-content-click="false"
                                transition="scale-transition"
                                offset-y
                              ></dea-date-picker-range>
                              <dea-button
                                icon
                                textindent
                                :disabled="i === 0 ? true : false"
                                :outlined="i === 0 ? false : true"
                                :prepend-icon="i === 0 ? '' : 'mdi-close'"
                                @click="onClickRemoveRange(i)"
                              >
                                삭제
                              </dea-button>
                            </v-col>
                          </v-row>
                        </v-list-item-title>
                      </v-list-item-content>
                    </v-list-item>
                  </template>
                </v-list-item-group>
              </v-list>
            </dea-card>
          </v-col>
        </v-layout>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="hide">취소</dea-button>
        <dea-button color="primary" @click="apply">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
export default {
  name: 'DialogSelectDate',
  props: {
    value: undefined
  },
  data() {
    return {
      isShow: false,
      startDate: '',
      endDate: '',
      pickerDate: [],
      selectedDate: [],
      toParentDate: []
    }
  },
  computed: {
    locale() {
      return process.env.VUE_APP_I18N_LOCALE || 'kr'
    }
  },
  mounted() {
    this.initDate()
  },
  methods: {
    show() {
      this.selectedDate = []
      this.value.forEach((e, i) => {
        if (i % 2 == 0) {
          this.selectedDate.push([this.value[i], this.value[i + 1]])
        }
      })
      this.isShow = true
    },
    hide() {
      this.isShow = false
    },
    apply() {
      this.toParentDate = []
      this.selectedDate.forEach((e) => {
        this.toParentDate.push(e[0])
        this.toParentDate.push(e[1])
      })
      this.$emit('input', this.toParentDate)
      this.hide()
    },
    getDate(date) {
      return new Date(date).getDate()
    },
    initDate() {
      this.startDate = new Date().toISOString().substr(0, 10)
      this.endDate = new Date().toISOString().substr(0, 10)
      this.syncDate()
    },
    syncDate() {
      this.pickerDate = [this.startDate, this.endDate]
      if (this.$refs.startDatePicker)
        this.$refs.startDatePicker.tableDate = this.startDate.substr(0, 7)
      if (this.$refs.endDatePicker)
        this.$refs.endDatePicker.tableDate = this.endDate.substr(0, 7)
    },
    onInputStartDate(value) {
      let date = value.length == 2 ? value[1] : value[0]

      if (date > this.endDate) {
        this.$alert('종료 날짜보다 작은 날짜를 선택해야합니다')
      } else {
        this.startDate = date
      }
      this.syncDate()
    },
    onInputEndDate(value) {
      let date = value.length == 2 ? value[1] : value[0]

      if (date < this.startDate) {
        this.$alert('시작 날짜보다 큰 날짜를 선택해야합니다')
      } else {
        this.endDate = date
      }
      this.syncDate()
    },
    onClickMoveRight() {
      this.selectedDate.push([this.startDate, this.endDate])
      this.initDate()
    },
    onClickRemoveRange(index) {
      this.selectedDate.splice(index, 1)
    }
    // onClickSelectedDate(index) {
    //   this.startDate = this.selectedDate[index][0]
    //   this.endDate = this.selectedDate[index][1]
    //   this.syncDate()
    // }
  }
}
</script>
