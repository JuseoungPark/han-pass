<template>
  <!-- 기지국 기준 통화 내역 : Layer Popup -->
  <dea-dialog-grid-basic
    ref="grid"
    :title="`${fieldkey} 기준 통화 내역`"
    :grid-tabitems="[{ name: `${fieldkey} 기준 총 통화내역` }]"
    width="1280px"
    :api="api"
    :columns="columns"
  >
    <template v-slot:header>
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex" cols="2">
                <dea-label>{{ fieldkey }}</dea-label>
              </v-col>
              <v-col class="d-flex valign-middle">
                <div class="text">{{ fieldvalue }}</div>
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
    </template>
    <template #header-right>
      <grid-comm-btn
        @goBookmark="goBookmark"
        @goExcept="goExcept"
      ></grid-comm-btn>
    </template>
  </dea-dialog-grid-basic>
  <!-- //기지국 기준 통화 내역 : Layer Popup -->
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import { GridFormatter } from '@/utils/GridFormatter'
import CellIcon from '@/components/grid/CellIcon'
// import CellBookmark from '@/components/grid/CellBookmark'
import CellExcept from '@/components/grid/CellExcept'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import GridCommBtn from '../include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import listTemplate from '@/mixins/listTemplate'
import eventBus from '@/mixins/eventBus'
export default {
  name: 'DialogCallHistory',
  mixins: [GridCommMixins, eventBus, listTemplate],
  components: {
    GridCommBtn
  },
  data() {
    return {
      api: '/talk/spcify-telno-base-talk-dtls',
      fieldkey: '',
      fieldvalue: '',
      columns: [
        {
          headerName: '',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '열 선택',
              field: 'rowSelector',
              width: 20,
              headerComponentFramework: CellCheckboxHeader,
              cellRendererFramework: CellCheckbox
            },
            {
              headerName: '북마크',
              field: 'bkmkId',
              width: 50,
              cellRendererFramework: CellIcon,
              cellRendererParams: (params) => {
                return {
                  type: 'bookmark',
                  icon: 'mdi-star',
                  color: params.value ? '#fe7c10' : '#d7d7d7',
                  click: this.setBookmarkCell
                }
              }
            },
            {
              headerName: '제외',
              field: 'except',
              width: 50,
              cellRendererFramework: CellExcept,
              cellRendererParams: {
                except: 'Y'
              }
            }
          ]
        },
        {
          headerName: '발신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '실사용자',
              field: 'dsptchUserNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'dsptchTelno',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '착신자',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '실사용자',
              field: 'rcvUserNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'rcvTelno',
              sortable: true,
              unSortIcon: true
            }
          ]
        },
        {
          headerName: '통화정보',
          headerGroupComponent: CustomHeaderGroup,
          children: [
            {
              headerName: '통화시작',
              field: 'talkBgngDt',
              sortable: true,
              unSortIcon: true,
              valueGetter: (params) => {
                return this.getWeekOfDayKr(params.data.talkBgngDt)
              }
            },
            {
              headerName: '통화시간',
              field: 'talkQy',
              sortable: true,
              unSortIcon: true,
              valueFormatter: GridFormatter.timeWithColons,
              width: 80,
              cellClass: 'align-right'
            },
            {
              headerName: '구분',
              field: 'talkTy',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '기지국',
              field: 'bsAdres',
              sortable: true,
              unSortIcon: true,
              tooltipField: 'bsAdres'
            }
          ]
        }
      ]
    }
  },
  methods: {
    doShow(params) {
      // console.log(params, params.field)
      let filter = ''
      if (params.event === 'telno') {
        this.fieldkey = '전화번호'
        this.fieldvalue = params.value
        this.api = '/talk/spcify-telno-base-talk-dtls'
        filter = `dsptchRcvDiv=${params.dsptchRcvDiv}&searchTelno=${params.value}`
      } else if (params.event.match(/telno:[A-Z]+/i)) {
        this.fieldkey = '전화번호'
        this.fieldvalue = params.data.telno
        this.api = '/talk/spcify-telno-base-talk-dtls'
        filter = `searchTelno=${params.data.telno}`
        if (params.event !== 'telno:ALL')
          filter += `&dsptchRcvDiv=${params.dsptchRcvDiv}`
      } else if (params.event === 'telno-station') {
        // 기지국분석
        this.fieldkey = '전화번호'
        this.fieldvalue = params.value
        this.api = '/base-station/talk-rcv'
        filter = `linkRelateLcId=${params.data.linkRelateLcId}&ruserIsrtyId=${params.data.ruseIsrtyId}`
        this.columns = [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: '북마크',
                field: 'bkmkId',
                width: 50,
                cellRendererFramework: CellIcon,
                cellRendererParams: (params) => {
                  return {
                    type: 'bookmark',
                    icon: 'mdi-star',
                    color: params.value ? '#fe7c10' : '#d7d7d7',
                    click: this.setBookmarkCell
                  }
                }
              },
              {
                headerName: '제외',
                field: 'except',
                width: 50,
                cellRendererFramework: CellExcept,
                cellRendererParams: {
                  except: 'Y'
                }
              }
            ]
          },
          {
            headerName: '발신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'dsptchRuserIsrtyNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'dsptchNo',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '착신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'rcvRuserIsrtyNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'rcvNo',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '통화정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작',
                field: 'talkBgngDt',
                sortable: true,
                unSortIcon: true,
                valueGetter: (params) => {
                  return this.getWeekOfDayKr(params.data.talkBgngDt)
                }
              },
              {
                headerName: '통화시간',
                field: 'talkQy',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.timeWithColons,
                width: 80,
                cellClass: 'align-right'
              },
              {
                headerName: '구분',
                field: 'talkTy',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '기지국',
                field: 'bsAdres',
                sortable: true,
                unSortIcon: true,
                tooltipField: 'bsAdres'
              }
            ]
          }
        ]
      } else if (params.event == 'station') {
        // 기지국기준 통화내역
        this.fieldkey = '기지국'
        this.fieldvalue = params.data.linkRelateLcNm
        this.api = '/base-station/talk-user'
        filter = `linkRelateLcId=${params.data.linkRelateLcId}&ruserIsrtyId=${params.data.ruseIsrtyId}`
        this.columns = [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: '북마크',
                field: 'bkmkId',
                width: 50,
                cellRendererFramework: CellIcon,
                cellRendererParams: (params) => {
                  return {
                    type: 'bookmark',
                    icon: 'mdi-star',
                    color: params.value ? '#fe7c10' : '#d7d7d7',
                    click: this.setBookmarkCell
                  }
                }
              },
              {
                headerName: '제외',
                field: 'except',
                width: 50,
                cellRendererFramework: CellExcept,
                cellRendererParams: {
                  except: 'Y'
                }
              }
            ]
          },
          {
            headerName: '발신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'dsptchRuserIsrtyNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'dsptchNo',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '착신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'rcvRuserIsrtyNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'rcvNo',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '통화정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작',
                field: 'talkBgngDt',
                sortable: true,
                unSortIcon: true,
                valueGetter: (params) => {
                  return this.getWeekOfDayKr(params.data.talkBgngDt)
                }
              },
              {
                headerName: '통화시간',
                field: 'talkQy',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.timeWithColons,
                width: 80,
                cellClass: 'align-right'
              },
              {
                headerName: '구분',
                field: 'talkTy',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '기지국',
                field: 'bsAdres',
                sortable: true,
                unSortIcon: true,
                tooltipField: 'bsAdres'
              }
            ]
          }
        ]
      }
      this.$refs.grid.setFilter(filter)
      this.$refs.grid.show()
    },
    show(params, queryString = '') {
      console.log(params.event)
      this.fieldkey = '전화번호'
      let filter = '&outgoingNumber=' + params.data.outgoingNumber
      if (params.event == 'outgoingNumber') {
        this.fieldkey = '전화번호'
        this.fieldvalue = params.data.outgoingNumber
        filter = '&outgoingNumber=' + params.data.outgoingNumber
      } else if (params.event == 'incommingNumber') {
        this.fieldkey = '전화번호'
        this.fieldvalue = params.data.incommingNumber
        filter = '&outgoingNumber=' + params.data.incommingNumber
      } else if (params.event == 'station') {
        this.fieldkey = '기지국'
        this.fieldvalue = params.data.station
        filter = '&station={0}&address={1}{2}'.format(
          params.data.station,
          params.data.address,
          queryString
        )
      } else if (params.event == 'station1') {
        // 인물중심 기지국 통화내역
        this.fieldkey = '기지국'
        this.fieldvalue = params.data.station1
        filter =
          '&outgoingUser=' +
          params.data.outgoingUser +
          '&outgoingSubscriber=' +
          params.data.outgoingSubscriber +
          '&outgoingNumber=' +
          params.data.outgoingNumber +
          '&station=' +
          params.data.station1 +
          '&address=' +
          params.data.address1
      } else if (params.event == 'outgoingCallOnly') {
        this.fieldkey = '발신 전화번호'
        this.fieldvalue = params.data.number
        filter = '&outgoingNumber={0}{1}'.format(
          params.data.number,
          queryString
        )
      } else if (params.event == 'incommingCallOnly') {
        this.fieldkey = '착신 전화번호'
        this.fieldvalue = params.data.number
        filter = '&incommingNumber={0}{1}'.format(
          params.data.number,
          queryString
        )
      } else if (params.event == 'outgoingIncommingCallSum') {
        this.fieldkey = '전화번호'
        this.fieldvalue = params.data.number
        filter = '&outgoingIncommingNumber={0}{1}'.format(
          params.data.number,
          queryString
        )
      } else if (params.event == 'totalNo') {
        this.fieldkey = '발/착신 기준'
        this.fieldvalue = '{0} ({1})'.format(
          params.data.user,
          params.data.number
        )
        filter = '&nos={0}'.format(
          params.data.totalNo.length === 0 ? 0 : params.data.totalNo
        )
      } else if (params.event == 'outgoingNo') {
        this.fieldkey = '발신 기준'
        this.fieldvalue = '{0} ({1})'.format(
          params.data.user,
          params.data.number
        )
        filter = '&nos={0}'.format(
          params.data.outgoingNo.length === 0 ? 0 : params.data.outgoingNo
        )
      } else if (params.event == 'incommingNo') {
        this.fieldkey = '착신 기준'
        this.fieldvalue = '{0} ({1})'.format(
          params.data.user,
          params.data.number
        )
        filter = '&nos={0}'.format(
          params.data.incommingNo.length === 0 ? 0 : params.data.incommingNo
        )
      }

      this.$refs.grid.setFilter(filter)
      this.$refs.grid.show()
    },
    showByFilter(title, filter) {
      this.fieldkey = title
      this.$refs.grid.setFilter(filter)
      this.$refs.grid.show()
    },
    hide() {}
  }
}
</script>
