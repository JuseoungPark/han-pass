<template>
  <dea-dialog-grid-basic
    ref="DialogGridBasic"
    title="가입자 정보"
    :grid-tabitems="[{ name: '가입자' }]"
    width="1280px"
    :api="api"
    :columns="columns"
  >
  </dea-dialog-grid-basic>
</template>

<script>
export default {
  name: 'DialogSubscriberInfo',
  data() {
    return {
      api: '/talk/sbscrber-info',
      filter: '',
      name: '',
      columns: [
        {
          headerName: '이름',
          field: 'sbscrberNm'
        },
        {
          headerName: '통신사',
          field: 'telecom'
        },
        {
          headerName: '전화번호',
          field: 'telno'
        },
        {
          headerName: '주소',
          field: 'adres',
          tooltipField: 'adres'
        },
        {
          headerName: '가입일',
          field: 'joinYmd'
        },
        {
          headerName: '해지일',
          field: 'trmnatYmd'
        },
        {
          headerName: '사용유무',
          field: ''
        },
        {
          headerName: '비고',
          field: ''
        }
      ]
    }
  },
  methods: {
    show(name) {
      if (!name) return
      this.name = name
      this.$refs.DialogGridBasic.setFilter('joinIsrtyId=' + this.name)
      this.$refs.DialogGridBasic.show()
    },
    hide() {}
  }
}
</script>
