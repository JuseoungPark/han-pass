<template>
  <dea-dialog
    v-model="isShow"
    title="통화 전화번호 빈도(건수) 현황"
    width="1100px"
  >
    <section class="dea-section">
      <div class="search-box">
        <dea-card class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                :indeterminate="
                  filter.callType.length > 0 && filter.callType.length < 3
                "
                :true-value="true"
                :value="filter.callType.length === 3 ? true : false"
                @click="toggleCallType"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="통화"
                cvalue="call"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="메시지"
                cvalue="message"
              />
              <dea-checkbox
                v-model="filter.callType"
                label="기타"
                cvalue="etc"
              />
            </v-col>
            <v-col cols="1">
              <dea-label>내용</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="filter.callDetail"
                row
                :mandatory="false"
                :items="callDetailItems"
              ></dea-radio-group>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>형태</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="filter.callState"
                row
                :mandatory="false"
                :items="callStateItems"
              ></dea-radio-group>
            </v-col>
            <v-col cols="1">
              <dea-label>구분</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                :indeterminate="
                  filter.inOut.length > 0 && filter.inOut.length < 2
                "
                :true-value="true"
                :value="filter.inOut.length === 2 ? true : false"
                @click="toggleInOut"
              />
              <dea-checkbox
                v-model="filter.inOut"
                label="착신"
                cvalue="incomming"
              />
              <dea-checkbox
                v-model="filter.inOut"
                label="발신"
                cvalue="outgoing"
              />
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner chart-wrap">
        <v-row no-gutters class="chart-top">
          <v-col class="d-flex align-right">
            <v-menu
              :disabled="disabled"
              :absolute="absolute"
              :open-on-hover="openOnHover"
              :close-on-click="closeOnClick"
              :close-on-content-click="closeOnContentClick"
              :offset-x="offsetX"
              :offset-y="offsetY"
            >
              <template v-slot:activator="{ on }">
                <v-btn v-on="on">다른 차트로 보기</v-btn>
              </template>
              <!-- 차트리스트 -->
              <v-sheet class="dea-popup" style="width:180px;">
                <v-container class="pa-2">
                  <section class="dea-section">
                    <div class="inner">
                      <v-list dense>
                        <v-list-item-group v-model="chartList">
                          <v-list-item
                            v-for="(chartItem, i) in chartItems"
                            :key="i"
                          >
                            <v-list-item-icon>
                              <v-icon>{{ chartItem.icon }}</v-icon>
                            </v-list-item-icon>
                            <v-list-item-content>
                              <v-list-item-title
                                v-text="chartItem.type"
                                class="text-truncate-none"
                              ></v-list-item-title>
                            </v-list-item-content>
                          </v-list-item>
                        </v-list-item-group>
                      </v-list>
                    </div>
                  </section>
                </v-container>
              </v-sheet>
              <!-- //차트리스트 -->
            </v-menu>
          </v-col>
        </v-row>
        <dea-card class="pa-0">
          차트
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button>이전</dea-button>
                <dea-button>다음</dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          async
          use-pagination
          suppress-row-click-selection
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.count"
        >
          <template #header-left>
            <v-tabs class="dea-tabs">
              <v-tab>통화내역 ({{ totalCount }})</v-tab>
            </v-tabs>
          </template>
          <template #header-right>
            <dea-button
              icon
              fab
              title="북마크"
              prepend-icon="mdi-bookmark-multiple-outline"
              bottom
            ></dea-button>
            <dea-button
              icon
              fab
              title="제외"
              prepend-icon="mdi-minus-circle-outline"
              bottom
            ></dea-button>
          </template>
        </dea-grid>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button color="primary" @click="hide">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'

export default {
  name: 'DialogCallCharacteristicGraph',
  mixins: [listTemplate],
  data() {
    return {
      isShow: false,
      gridInfo: {
        api: '',
        count: 0,
        columns: []
      },
      filter: {
        callType: ['call', 'message', 'etc'],
        callDetail: 'frequency',
        callState: 'time',
        inOut: ['incomming', 'outgoing']
      },
      validError: {},
      callDetailItems: [
        {
          label: '빈도',
          value: 'frequency'
        },
        {
          label: '통화량',
          value: 'callAmount'
        }
      ],
      callStateItems: [
        {
          label: '시간대별',
          value: 'time'
        },
        {
          label: '요일별',
          value: 'day'
        },
        {
          label: '일별',
          value: 'date'
        },
        {
          label: '월별',
          value: 'month'
        }
      ],
      // In Modal Popup
      chartList: '',
      chartItems: [
        {
          type: 'Area Chart',
          icon: 'mdi-equalizer'
        },
        {
          type: 'Bar Chart',
          icon: 'mdi-elevation-rise'
        },
        {
          type: 'Bubble Chart',
          icon: 'mdi-circle-slice-7'
        }
      ],
      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true
    }
  },
  computed: {
    totalCount: {
      get: function() {
        return NumberUtils.numberWithCommas(this.gridInfo.count)
      },
      set: function() {}
    }
  },
  methods: {
    show() {
      this.isShow = true
    },
    hide() {
      this.isShow = false
    },
    getColumns() {
      this.$refs.grid.setColumns(this.gridInfo.columns)
    },
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    toggleCallType() {
      this.$nextTick(() => {
        if (this.filter.callType.length === 3) {
          this.filter.callType = []
        } else {
          this.filter.callType = ['call', 'message', 'etc']
        }
      })
    },
    toggleInOut() {
      this.$nextTick(() => {
        if (this.filter.inOut.length === 2) {
          this.filter.inOut = []
        } else {
          this.filter.inOut = ['incomming', 'outgoing']
        }
      })
    }
  }
}
</script>
