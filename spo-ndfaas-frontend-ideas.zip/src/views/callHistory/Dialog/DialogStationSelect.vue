<template>
  <v-menu v-model="isShow" close-on-content-click>
    <template v-slot:activator="{ on, attrs }">
      <dea-text-field
        v-model="selectedText"
        dense
        outlined
        :label="label"
        :placeholder="placeholder"
        prepend-inner-icon="mdi-map-marker-outline"
        v-bind="attrs"
        v-on="on"
      ></dea-text-field>
    </template>
    <dea-dialog v-model="isShow" title="기지국 선택" width="1200px">
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">
                    기지국을 선택하세요
                  </div>
                  <dea-button outlined @click="allMapShow" v-if="this.sido"
                    >전체보기</dea-button
                  >
                  <!-- <template v-if="!admnm">{{ sido }} {{ sggnm }}</template> {{ admnm }} -->
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-sheet class="pa-4">
                  <section class="dea-section">
                    <div class="inner">
                      <dea-card class="pa-0 ba-0">
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <dea-text-field
                              label="찾고자 하는 주소를 입력하세요"
                              append-icon="mdi-magnify"
                              style="width:240px;"
                              classes="flex-0"
                              v-model="selectedLabel"
                            ></dea-text-field>
                            <dea-select label="시,도 선택"></dea-select>
                            <dea-select label="시,군,구 선택"></dea-select>
                            <dea-select label="읍,면,동 선택"></dea-select>
                            <dea-button
                              color="primary"
                              prepend-icon="mdi-magnify"
                            >
                              검색
                            </dea-button>
                          </v-col>
                        </v-row>
                      </dea-card>
                    </div>
                  </section>
                  <section class="dea-section">
                    <div class="inner chart-wrap">
                      <dea-card class="pa-0">
                        <v-sheet height="611">
                          <div ref="mapWrapper" class="map-wrapper"></div>
                        </v-sheet>
                      </dea-card>
                    </div>
                  </section>
                </v-sheet>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                textindent
                outlined
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                @click="doSelectedList"
              >
                우측으로 이동
              </dea-button>
              <dea-button
                icon
                textindent
                outlined
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                @click="delSelectedList"
              >
                좌측으로 이동
              </dea-button>
            </v-col>
            <v-col cols="4">
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">
                    선택된 기지국
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="707" class="overflow-y-auto">
                  <v-list-item-group multiple v-model="selected">
                    <v-list-item
                      v-for="(address, index) in selectedList"
                      :key="index"
                    >
                      <v-list-item-content class="flex-row">
                        <v-list-item-title
                          class="text-truncate-none"
                          style="width:80%;"
                        >
                          {{ address }}
                        </v-list-item-title>
                        <v-list-item-action>
                          <dea-button
                            icon
                            textindent
                            outlined
                            prepend-icon="mdi-close"
                            @click="doDelete(index)"
                          >
                            삭제
                          </dea-button>
                        </v-list-item-action>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="isShow = !isShow">취소</dea-button>
          <dea-button color="primary" @click="onClickOk">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
  </v-menu>
</template>

<script>
import * as d3 from 'd3'
export default {
  props: {
    label: {
      type: String,
      default: undefined
    },
    placeholder: {
      type: String,
      default: undefined
    },
    value: {
      default: []
    }
  },
  data() {
    return {
      isShow: false,
      selectedText: '',
      selectedLabel: '',
      d3: d3,
      width: 700,
      height: 700,
      initialScale: 1,
      centered: undefined,
      center: undefined,
      states: undefined,
      color: undefined,
      path: undefined,
      g: undefined,
      background: undefined,
      icons: undefined,
      projection: undefined,
      sido: '',
      sggnm: '',
      admnm: '',
      loc1: '서울특별시',
      locItems1: [],
      dongGeoJson: {},
      sidoGeoJson: {},
      tooltip: undefined,
      selectedList: [],
      selected: []
    }
  },
  watch: {
    async isShow(value) {
      if (value) {
        this.sidoGeoJson = await this.getSidoGeoJson()
        await this.allMapShow()
        this.dongGeoJson = await this.getDongGeoJson()
      }
    },
    value(val) {
      if (!val) {
        this.selectedText = ''
        this.selectedList = []
        this.selected = []
      }
    }
  },
  created() {
    // if (this.$route.name === 'BaseStationAnalysis') this.isShow = true
  },
  methods: {
    async getDongGeoJson() {
      return await this.$api.private.get('/api/geo.dong.json').then((res) => {
        return res.data
      })
    },
    async getSidoGeoJson() {
      return await this.$api.private.get('/api/geo.sido.json').then((res) => {
        return res.data
      })
    },
    doDelete(index) {
      this.selectedList.splice(index, 1)
    },
    doSelectedList() {
      if (this.selectedLabel) {
        this.selectedList.push(this.selectedLabel)
        this.selectedList = [...new Set(this.selectedList)]
        this.selectedLabel = ''
        this.allMapShow()
      }
    },
    delSelectedList() {
      this.selectedList = this.selectedList.filter((item, index) => {
        if (!this.selected.includes(index)) {
          return item
        }
      })
    },
    onClickOk() {
      this.selectedText = this.selectedList
      this.$emit('input', this.selectedText)
      this.hide()
    },
    setLocItems(features) {
      const _locItems1 = features.map((item) => {
        return { text: item.properties.sidonm, value: item.properties.sidonm }
      })
      return [...new Set(_locItems1)]
    },
    async setGeoJson() {
      let geojson
      if (this.sido) {
        geojson = { ...this.dongGeoJson }
        geojson.features = geojson.features.filter((item) => {
          return item.properties.sidonm === this.sido
        })
      } else {
        let count = [
          1666,
          30,
          3,
          275,
          5,
          15,
          5,
          7,
          2040,
          41,
          17,
          151,
          20,
          9,
          16,
          18,
          29
        ]
        geojson = { ...this.sidoGeoJson }
        geojson.features = geojson.features.map((item, index) => {
          item.properties.count = count[index]
          return item
        })
      }
      return await geojson
    },
    async drawMap() {
      d3.select('.map-svg').remove()
      // 지도정보
      const geojson = await this.setGeoJson()
      console.log(geojson)

      // 지도의 중심점 찾기
      // this.center = d3.geoCentroid(geojson)

      /* 현재의 브라우저의 크기 계산 */
      const divWidth = 700
      this.width = divWidth < 1000 ? divWidth * 0.9 : 1000
      this.height = this.width * 0.9

      // 지도를 그리기 위한 svg 생성
      const svg = d3
        .select(this.$refs.mapWrapper)
        .append('svg')
        .attr('width', this.width)
        .attr('height', this.height)
        .attr('class', 'map-svg')

      /* 배경 그리기 */
      this.background = svg
        .append('rect')
        .attr('class', 'background')
        .attr('width', this.width)
        .attr('height', this.height)

      const zoom = d3
        .zoom()
        .scaleExtent([1, 8])
        .on('zoom', this.zoomed)
      svg.call(zoom)

      // 지도가 그려지는 그래픽 노드
      this.states = svg.append('g').attr('class', 'states-layer')

      // 지도의 출력 방법을 선택(메로카토르)
      this.projection = d3
        // .center(this.center)
        .geoMercator()
        .scale(this.initialScale)
        .translate([0, 0])

      // svg 그림의 크기에 따라 출력될 지도의 크기를 다시 계산
      this.path = d3.geoPath().projection(this.projection)
      const bounds = this.path.bounds(geojson)
      const widthScale = (bounds[1][0] - bounds[0][0]) / this.width
      const heightScale = (bounds[1][1] - bounds[0][1]) / this.height
      const scale = 0.95 / Math.max(widthScale, heightScale)
      const xoffset =
        this.width / 2 - (scale * (bounds[1][0] + bounds[0][0])) / 2 + 0
      const yoffset =
        this.height / 2 - (scale * (bounds[1][1] + bounds[0][1])) / 2 + 0
      const offset = [xoffset, yoffset]
      this.projection.scale(scale).translate(offset)

      // 지도 그리기
      this.states
        .selectAll('path')
        .data(geojson.features)
        .enter()
        .append('path')
        .attr('d', this.path)
        .attr('id', (d) => {
          let code = d.properties.code ? d.properties.code : d.properties.adm_cd
          return `path-${code}`
        })
        .attr('title', (d) => this.nameFn(d))
        .attr('vector-effect', 'non-scaling-stroke')
        .style('fill', (d) => this.fillFn(d))
        .on('mouseover', this.mouseover)
        .on('mouseout', this.mouseout)
        .on('click', this.clicked)

      if (this.sido) {
        this.tooltip = this.states.append('text').attr('class', 'tooltip')
      } else {
        this.states
          .selectAll('text')
          .data(geojson.features)
          .enter()
          .append('text')
          .attr('transform', (d) => {
            return this.translateTolabel(d)
          })
          .attr('text-anchor', 'middle')
          .attr('dy', '.35em')
          .text((d) => this.nameFn(d))
          .on('mouseover', this.mouseover)
          .on('mouseout', this.mouseout)
          .on('click', this.clicked)
      }

      /*
      this.icons = svg.append('g').classed('icons-layer', true)
      const mapInfo = [
        { name: '다성일식', lat: 37.5569016, lon: 126.9329799 }
      ]
      let _this = this
      this.icons
        .selectAll('circle')
        .data(mapInfo)
        .enter()
        .append('circle')
        .attr('cx', (d) => _this.projection([d.lon, d.lat])[0])
        .attr('cy', (d) => _this.projection([d.lon, d.lat])[1])
        .attr('r', 1.5)
      this.icons
        .selectAll('text')
        .data(mapInfo)
        .enter()
        .append('text')
        .attr('x', (d) => _this.projection([d.lon, d.lat])[0] + 0.3)
        .attr('y', (d) => _this.projection([d.lon, d.lat])[1] + 0.3)
        .text((d) => d.name)
        */
    },
    async allMapShow() {
      this.sido = ''
      this.sggnm = ''
      this.admnm = ''
      await this.drawMap()
    },

    async clicked(e, d) {
      if (d.properties.name) {
        this.sido = d.properties.name
        this.selectedLabel = d.properties.name
        await this.drawMap()
      } else {
        this.sggnm = d.properties.sggnm
        this.admnm = d.properties.adm_nm
        this.selectedLabel = d.properties.adm_nm
      }
    },
    mouseover(e, d) {
      let _d = d
      this.states
        .selectAll('path')
        .style('fill', (d) => {
          return _d && d === _d ? 'rgba(0, 147, 0, 0.1)' : this.fillFn(d)
        })
        .style('stroke-width', (d) => {
          return _d && d === _d ? '1px' : '0.4px'
        })

      if (this.sido) {
        this.tooltip
          .text(this.nameFn(d))
          .attr('text-anchor', 'middle')
          .attr('dy', '.35em')
          .attr('transform', this.translateTolabel(d))
          .style('opacity', 1)
      } else {
        this.states.selectAll('text').style('font-weight', (d) => {
          return _d && d === _d ? 'bold' : 'normal'
        })
      }
    },
    mouseout() {
      this.states
        .selectAll('path')
        .style('fill', (d) => this.fillFn(d))
        .style('stroke-width', '0.4px')

      if (this.sido) {
        this.tooltip.style('opacity', 0)
      }
    },
    zoomed(event) {
      const { transform } = event
      this.states.attr('transform', transform)
      this.states.attr('stroke-width', 1 / transform.k)
    },
    // Get province name
    nameFn(d) {
      let name = d.properties.name ? d.properties.name : d.properties.adm_nm
      let count = d.properties.count ? d.properties.count : null
      return d.properties.count ? `${name} (${count})` : name
    },

    // Get province color
    fillFn(d) {
      let count = d.properties.count ? d.properties.count : 0
      let color = d3
        .scaleLinear()
        .domain([1, 200])
        .clamp(true)
        .range(['#fff', '#CC6633'])
      return color(count)
    },
    translateTolabel(d) {
      let arr = this.path.centroid(d)
      if (typeof d.properties.code !== 'undefined') {
        if (d.properties.code == 11) {
          //서울 특별시
          arr[0] += 15
        } else if (d.properties.code == 23) {
          // 인천광역시
          arr[0] -= 3
          arr[1] += 10
        } else if (d.properties.code == 31) {
          // 경기도
          arr[0] -= 5
          arr[1] -= 35
        } else if (d.properties.code == 33) {
          // arr[0] -= 10
          arr[1] -= 20
        } else if (d.properties.code == 34) {
          // 충청남도
          arr[0] -= 10
          arr[1] -= 25
        }
      }
      return 'translate(' + arr + ')'
    },
    show() {
      this.isShow = true
    },
    hide() {
      this.isShow = false
    }
  }
  /*async mounted() {
    if (!this.states) {
      await this.drawMap()
    }
  }*/
}
</script>
<style>
.map-wrapper {
  position: relative;
}
.map-svg {
  margin: 0 auto;
  /* border: 1px solid #000; */
}
.background {
  /* fill: #021019; */
  fill: transparent;
  pointer-events: all;
}
.map-layer {
  fill: #08304b;
  stroke: #021019;
  stroke-width: 1px;
}
.states-layer path {
  fill: #585858;
  stroke: #000000;
  stroke-width: 0.4px;
  cursor: pointer;
}
/*.states-layer path:hover {
  fill: rgba(0, 147, 0, 0.2) !important;
  stroke-width: 1px;
}*/
.states-layer text {
  cursor: pointer;
  font-size: 10px;
  letter-spacing: -1px;
  font-weight: normal;
  fill: #000;
  opacity: 1;
}
.states-layer text.tooltip {
  position: absolute;
  height: auto;
  padding: 0 5px;
  background: #fff;
  border-radius: 5px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.4);
  pointer-events: none;
  font-size: 11px;
  letter-spacing: -1px;
  font-weight: bold;
}
.icons-layer circle {
  fill: #ff0000;
  cursor: pointer;
}
.icons-layer text {
  fill: #fff;
  font-size: 0.7px;
  font-weight: normal;
  letter-spacing: 0.01px;
}
</style>
