<template>
  <v-menu
    v-model="menu"
    :disabled="disabled"
    :close-on-click="false"
    :close-on-content-click="false"
  >
    <template v-slot:activator="{ on, attrs }">
      <dea-text-field
        v-model="selectedText"
        dense
        outlined
        label="인물선택"
        placeholder="인물선택"
        :disabled="disabled"
        prepend-inner-icon="mdi-account-check-outline"
        v-bind="attrs"
        v-on="on"
      ></dea-text-field>
    </template>
    <dea-dialog
      v-model="menu"
      title="인물 선택"
      width="800px"
      @dialog:close="onDialogClose"
    >
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  label="인물유형 선택"
                  placeholder="종류를 선택하세요"
                  style="width:200px;"
                  class="flex-0"
                  :items="personTypeItems"
                  v-model="personType"
                  @change="onChangePersonType"
                ></dea-select>
                <dea-text-field
                  v-model="searchText"
                  label="인물을 검색하세요"
                  @click:clear="onInitSearch"
                ></dea-text-field>
                <dea-button prepend-icon="mdi-magnify" @click="onSearch"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">검색결과 ({{ pagination.total }})</div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group
                    v-model="shuttleLeftModel"
                    :multiple="multiple"
                  >
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="`shuttleLeftItem-${i}`"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              style="max-width: 50%"
                              v-text="shuttleLeftItem.isrtyNm"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.telno"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>

            <v-col class="btn-wrap">
              <dea-button
                icon
                textindent
                outlined
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                @click="onClickMoveRight"
              >
                우측으로 이동
              </dea-button>
              <dea-button
                icon
                textindent
                outlined
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                @click="onClickMoveLeft"
              >
                좌측으로 이동
              </dea-button>
            </v-col>

            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">
                    선택된 인물 ({{ shuttleRightItems.length }})
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleRightModel" multiple>
                    <template
                      v-for="(shuttleRightItem, i) in shuttleRightItems"
                    >
                      <v-list-item
                        :key="`shuttleRightItem-${i}`"
                        :value="shuttleRightItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              style="max-width: 50%"
                              v-text="shuttleRightItem.isrtyNm"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleRightItem.telno"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>

      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="onClickCancel">취소</dea-button>
          <dea-button color="primary" @click="onClickOk">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
  </v-menu>
</template>

<script>
import apiMixin from '@/mixins/apiMixin'
export default {
  name: 'DialogSelectPerson',
  mixins: [apiMixin],
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    label: {
      type: String,
      default: undefined
    },
    multiple: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: undefined
    },
    showOnLoad: {
      type: Boolean,
      default: false
    },
    value: {
      default: function() {
        return []
      }
    }
  },
  data() {
    return {
      menu: false,
      shuttleLeftModel: [],
      shuttleLeftItems: [],
      shuttleRightModel: [],
      shuttleRightItems: [],
      searchItems: [],
      searchText: '',
      personType: 'all',
      personTypeItems: [
        {
          text: '전체',
          value: 'all'
        }
      ],
      /*personTypeItems: [
        {
          text: '전체',
          value: 71,
          disabled: true
        },
        {
          text: '주요인물',
          value: 61
        },
        {
          text: '피의자',
          value: 11
        },
        {
          text: '혐의자',
          value: 21
        },
        {
          text: '참고인',
          value: 31
        },
        {
          text: '피해자',
          value: 41
        },
        {
          text: '기타',
          value: 51
        }
      ],*/
      localData: []
    }
  },
  computed: {
    computedItems: function() {
      if (this.searchItems.length) {
        return this.shuttleLeftItems.filter((e) =>
          this.searchItems.some((s) => e.name.includes(s))
        )
      }
      return this.shuttleLeftItems
    },
    selectedText: {
      get: function() {
        if (this.localData.length == 1) {
          return this.localData[0].isrtyNm
        } else if (this.localData.length > 1) {
          return (
            this.localData[0].isrtyNm +
            ' 외 ' +
            (this.localData.length - 1) +
            '명'
          )
        }
        return ''
      },
      set: function() {}
    }
  },
  watch: {
    value(val) {
      if (!val.length) this.resetData()
    },
    async menu(flag) {
      if (flag) {
        this.init()
      }
    }
  },
  mounted() {
    if (this.showOnLoad) this.menu = true
    // this.init()
  },
  methods: {
    getPersonTypeCode() {
      this.$personTypeCode().then((res) => {
        let personTypeItems = res
        this.personTypeItems = this.personTypeItems.concat(
          personTypeItems.map((item) => {
            return { text: item.cmmnCodeNm, value: item.cmmnCode }
          })
        )
        this.personTypeItems.sort()
      })
    },
    async init() {
      this.getPersonTypeCode()
      this.shuttleLeftItems = []
      this.shuttleLeftModel = []
      this.shuttleRightItems = []
      this.shuttleRightModel = []
      // this.localData = []
      this.loadItems()
    },
    async loadItems() {
      this.shuttleLeftItems = []
      this.shuttleLeftModel = []
      this.apiUrl = '/isrty/isrtys'
      this.pagination.limit = 500
      this.loading = this.$loading.show()
      let res = await this.$requestApi({ url: this.uri })
      res = this.apiCodeValidate(res)
      if (res) {
        this.loading.hide()
        let result = res.data.result
        this.shuttleLeftItems = result.data
        this.shuttleLeftItems.sort()
        this.pagination.total = result.pageInfo.rowAllCnt
        this.syncRightItems()
      }
    },
    onClickMoveRight() {
      if (this.multiple) {
        this.shuttleLeftModel.forEach((e) => {
          if (this.shuttleRightItems.some((v) => v.isrtyId === e.isrtyId))
            return true
          this.shuttleRightItems.push(e)
          // this.shuttleLeftItems.splice(this.shuttleLeftItems.indexOf(e), 1)
        })
        this.shuttleLeftModel = []
        this.shuttleRightItems.sort()
      } else {
        if (this.shuttleLeftModel.isrtyNm !== undefined) {
          if (this.shuttleRightItems.length > 0) {
            if (
              this.shuttleLeftModel.isrtyId !==
              this.shuttleRightItems[0].isrtyId
            )
              this.$alert('한명의 인물만 선택 할 수 있습니다.')
            else this.shuttleLeftModel = {}
          } else {
            this.shuttleRightItems.push(this.shuttleLeftModel)
            this.shuttleLeftModel = {}
          }
        }
      }
    },
    onClickMoveLeft() {
      this.shuttleRightModel.forEach((e) => {
        // this.shuttleLeftItems.push(e)
        this.shuttleRightItems.splice(this.shuttleRightItems.indexOf(e), 1)
      })
      this.shuttleRightModel = []
      // this.shuttleLeftItems.sort()
    },
    onClickCancel() {
      this.menu = false
      this.syncRightItems()
    },
    onClickOk() {
      this.menu = false
      this.localData = Array.from(this.shuttleRightItems, (e) => {
        return e
      })
      this.$emit(
        'input',
        Array.from(this.shuttleRightItems, (e) => {
          return e.isrtyId
        })
      )
    },
    onSearch() {
      this.searchText = this.searchText === null ? '' : this.searchText
      this.personType = this.personType === 'all' ? '' : this.personType
      this.apiParams = 'prsnTyCode={0}&searchKwrd={1}'.format(
        this.personType,
        this.searchText
      )
      this.loadItems()
    },
    onInitSearch() {
      this.searchItems = []
      this.searchText = ''
    },
    resetData() {
      this.localData = []
      this.init()
      //this.$emit('input', [])
    },
    onChangePersonType(value) {
      this.apiParams = 'prsnTyCode={0}'.format(value === 'all' ? '' : value)
      this.loadItems()
    },
    syncRightItems() {
      this.shuttleLeftModel = []
      this.shuttleRightModel = []
      this.shuttleRightItems = []

      this.localData.forEach((e) => {
        this.shuttleRightItems.push(e)
      })
    },
    onDialogClose() {
      this.syncRightItems()
    }
  }
}
</script>
