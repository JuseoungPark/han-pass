<template>
  <dea-dialog v-model="isShow" title="통화내역처리현황" width="1100px">
    <section class="dea-section">
      <div class="inner">
        <v-row no-gutters>
          <v-col class="d-flex valign-middle">
            <div class="info-message">
              <strong>{{ updateDate }}</strong>
              <label class="ml-2">업데이트</label>
            </div>
            <v-btn
              text
              class="dea-btn--textindent"
              :loading="loading"
              @click="updateData"
            >
              <v-icon>mdi-cached</v-icon>
              갱신
            </v-btn>
          </v-col>
        </v-row>
        <dea-card>
          <dea-grid
            ref="grid"
            :api="gridInfo[dataTabSelected].api"
            :columns="gridInfo[dataTabSelected].columns"
            :return-value.sync="tabItemsName[dataTabSelected].count"
            use-pagination
            disable-auto-load
          >
            <template #header-left>
              <v-col class="d-flex">
                <dea-tabs
                  v-model="dataTabSelected"
                  :tabItems="tabItems"
                  v-if="tabShow"
                  @change="updateData"
                ></dea-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button color="primary" @click="hide">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import moment from 'moment'
import { NumberUtils } from '@/utils/NumberUtils'
import listTemplate from '@/mixins/listTemplate'
import CellIcon from '@/components/grid/CellIcon'
import CellButton from '@/components/grid/CellButton'
export default {
  name: 'DialogCallHistoryStatus',
  mixins: [listTemplate],
  props: {
    tabSelected: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      isShow: false,
      tabShow: false,
      updateDate: '',
      dataTabSelected: 0,
      tabItemsName: [
        { name: '완료파일', count: 0 },
        { name: '실패파일', count: 0 }
      ],
      gridInfo: [
        {
          api: 'talk/dtls-prcs-sttus-cmptns',
          columns: [
            {
              headerName: '파일등록일시',
              field: 'fileRegDt',
              sortable: true,
              unSortIcon: true,
              width: 120,
              cellClass: 'align-center'
            },
            {
              headerName: '분류',
              field: 'cl',
              sortable: true,
              unSortIcon: true,
              cellClass: 'align-center'
            },
            {
              headerName: '파일명',
              field: 'fileNm',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통신사',
              field: 'telecom',
              sortable: true,
              unSortIcon: true,
              cellClass: 'align-center'
            },
            {
              headerName: '파일크기',
              field: 'fileSize',
              sortable: true,
              unSortIcon: true,
              cellClass: 'align-right'
            },
            {
              headerName: '성공',
              field: 'scsCnt',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-right'
            },
            {
              headerName: '실패',
              field: 'failrCnt',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-right'
            },
            {
              headerName: '중복',
              field: 'dplctCnt',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-right'
            },
            {
              headerName: '제외',
              field: 'exclCnt',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-right'
            },
            {
              headerName: '삭제',
              field: 'del',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-center',
              cellRendererFramework: CellIcon,
              cellRendererParams: () => {
                return {
                  icon: 'mdi-delete',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            },
            {
              headerName: '저장',
              field: 'download',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-center',
              cellRendererFramework: CellIcon,
              cellRendererParams: () => {
                return {
                  icon: 'mdi-download',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            },
            {
              headerName: '상세보기',
              field: 'detail',
              sortable: true,
              unSortIcon: true,
              width: 100,
              cellClass: 'align-center',
              cellRendererFramework: CellButton,
              cellRendererParams: () => {
                return {
                  label: '상세보기',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            }
          ]
        },
        {
          api: 'talk/dtls-prcs-sttus-failrs',
          columns: [
            {
              headerName: '파일등록일시',
              field: 'regDate',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '분류',
              field: 'source',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '파일명',
              field: 'filename',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '파일크기',
              field: 'filesize',
              sortable: true,
              unSortIcon: true,
              cellClass: 'align-right'
            },
            {
              headerName: '실패이유',
              field: 'fileFailReason',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '실패파일 확인',
              field: 'fileFailCheck',
              sortable: true,
              unSortIcon: true,
              width: 100,
              cellClass: 'align-center',
              cellRendererFramework: CellButton,
              cellRendererParams: (params) => {
                return {
                  label: params.value ? '확인' : '',
                  click: (params) => {
                    console.log(params)
                  }
                }
              },
              valueGetter: (params) => {
                return params.data.fileFailCheck ? '확인' : ''
              }
            },
            {
              headerName: '삭제',
              field: '',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-center',
              cellRendererFramework: CellIcon,
              cellRendererParams: () => {
                return {
                  icon: 'mdi-delete',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            },
            {
              headerName: '저장',
              field: '',
              sortable: true,
              unSortIcon: true,
              width: 60,
              cellClass: 'align-center',
              cellRendererFramework: CellIcon,
              cellRendererParams: () => {
                return {
                  icon: 'mdi-download',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            },
            {
              headerName: '실패파일 재분석',
              field: '',
              sortable: true,
              unSortIcon: true,
              cellClass: 'align-center',
              cellRendererFramework: CellIcon,
              cellRendererParams: () => {
                return {
                  icon: 'mdi-reload',
                  click: (params) => {
                    console.log(params)
                  }
                }
              }
            }
          ]
        }
      ],
      loading: false
    }
  },
  computed: {
    tabItems() {
      return this.tabItemsName.map((item) => {
        return {
          name: `${item.name} (${NumberUtils.numberWithCommas(item.count)})`
        }
      })
    }
  },
  watch: {
    isShow(flag) {
      if (flag) {
        this.dataTabSelected = this.tabSelected
        this.tabShow = flag
        // this.getData()
      } else {
        this.tabShow = flag
      }
    }
    // dataTabSelected() {
    //   this.updateData()
    // }
  },
  methods: {
    getColumns() {
      this.$nextTick(() => {
        this.$refs.grid.setColumns(this.gridInfo[this.dataTabSelected].columns)
      })
    },
    getData() {
      this.getColumns()
      let datas = [
        {
          no: 1,
          regDate: '2020-09-31 18:01',
          source: '통화내역파일',
          filename: '0830KT.csv',
          telecom: 'KT',
          filesize: '14kb',
          success: 554,
          fail: 0,
          overlap: 0,
          except: 0,
          fileFailReason: '',
          fileFailCheck: 0,
          status: 1
        },
        {
          no: 2,
          regDate: '2020-09-31 18:02',
          source: '통화내역파일',
          filename: '0830KT.csv',
          telecom: 'KT',
          filesize: '14kb',
          success: 554,
          fail: 0,
          overlap: 0,
          except: 0,
          fileFailReason: '',
          fileFailCheck: 1,
          status: 0
        },
        {
          no: 3,
          regDate: '2020-09-31 18:03',
          source: '통화내역파일',
          filename: '0830KT.csv',
          telecom: 'KT',
          filesize: '14kb',
          success: 554,
          fail: 0,
          overlap: 0,
          except: 0,
          fileFailReason: '',
          fileFailCheck: 0,
          status: 0
        }
      ]
      let rowsFail = datas.filter((item) => item.status === 0)
      this.tabItemsName[1].count = rowsFail.length
      let rowsComplate = datas.filter((item) => item.status === 1)
      this.tabItemsName[0].count = rowsComplate.length
      this.$nextTick(() => {
        let rows = []
        if (this.dataTabSelected === 1) {
          rows = rowsFail
        } else {
          rows = rowsComplate
        }
        this.$refs.grid.setRowData(rows)
      })
    },
    show: function() {
      this.isShow = true
      this.updateData()
    },
    hide: function() {
      this.isShow = false
    },
    updateData() {
      this.$nextTick(() => {
        this.loading = true

        this.$refs.grid.setApi(this.gridInfo[this.dataTabSelected].api)
        this.loadData()

        this.updateDate = moment().format('YYYY-MM-DD HH:mm')
        this.loading = false
      })
    }
  },
  created() {
    this.tabShow = this.isShow
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
