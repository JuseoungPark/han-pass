<template>
  <!-- 기지국중심 발신기준 통화내역 : Layer Popup -->
  <dea-dialog
    v-model="isShow"
    title="기지국중심 발신기준 통화내역"
    width="1200px"
  >
    <section class="dea-section">
      <div class="inner detail-view">
        <dea-card>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기지국 정보</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">{{ filter.station }}</div>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <v-layout class="divide pa-0 ba-0">
          <v-col cols="4">
            <dea-card>
              <dea-grid
                ref="outgoingNumber"
                :api="gridInfo.outgoingNumber.api"
                :columns="gridInfo.outgoingNumber.columns"
                :etc-options="gridInfo.outgoingNumber.options"
                :return-value.sync="gridInfo.outgoingNumber.totalCount"
                :config="gridInfo.config"
                use-pagination
                disableAutoLoad
              >
                <template slot="header-left">
                  <dea-tabs
                    v-model="tabSelected"
                    :tabItems="tabItemsLeft"
                  ></dea-tabs>
                </template>
              </dea-grid>
            </dea-card>
          </v-col>
          <v-col>
            <dea-card>
              <!-- dea-grid -->
              <dea-grid
                ref="grid"
                :api="gridInfo.callHistory.api"
                :columns="gridInfo.callHistory.columns"
                :etc-options="gridInfo.callHistory.options"
                :return-value.sync="gridInfo.callHistory.totalCount"
                :config="gridInfo.config"
                use-pagination
                row-selection-multiple
                suppress-row-click-selection
                async
              >
                <!-- header-left -->
                <template #header-left>
                  <dea-tabs
                    v-model="tabSelected"
                    :tabItems="tabItemsRight"
                  ></dea-tabs>
                </template>
                <!-- header-left // -->
                <!-- header-right -->
                <template #header-right>
                  <grid-comm-btn
                    @goBookmark="goBookmark"
                    @goExcept="goExcept"
                  ></grid-comm-btn>
                </template>
                <!-- header-right // -->
              </dea-grid>
              <!-- dea-grid // -->
            </dea-card>
          </v-col>
        </v-layout>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button color="primary" @click="isShow = !isShow">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
  <!-- //기지국중심 발신기준 통화내역 : Layer Popup -->
</template>

<script>
import CellBookmark from '@/components/grid/CellBookmark'
import CellExcept from '@/components/grid/CellExcept'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import GridCommBtn from '../include/GridCommBtn'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'
import { NumberUtils } from '@/utils/NumberUtils'
import { StringUtils } from '@/utils/StringUtils'
import { GridFormatter } from '@/utils/GridFormatter'

export default {
  name: 'DialogStationOutgoingNumList',
  mixins: [GridCommMixins, eventBus],
  components: {
    GridCommBtn
  },
  data() {
    return {
      isShow: false,
      station: '',
      number: '',
      filter: {
        station: '',
        address: '',
        user: '',
        number: ''
      },
      tabSelected: 0,
      gridInfo: {
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 10
          },
          height: 'fixed'
        },
        outgoingNumber: {
          tabName: '발신 전화번호',
          api: '/api/call/station/outgoingnumber',
          options: {
            onRowSelected: this.onRowSelected.bind(this)
          },
          columns: [
            {
              headerName: '실사용자명',
              field: 'outgoingUser',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '전화번호',
              field: 'outgoingNumber',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '빈도',
              field: 'callCount',
              sortable: true,
              unSortIcon: true,
              valueFormatter: GridFormatter.numberWithCommas,
              width: 60,
              cellClass: 'align-right'
            }
          ],
          totalCount: 0
        },
        callHistory: {
          api: '/api/call/station/outgoingnumber/callhistory',
          tabName: '통화 내역',
          columns: [
            {
              headerName: '열 선택',
              field: 'rowSelector',
              width: 20,
              headerComponentFramework: CellCheckboxHeader,
              cellRendererFramework: CellCheckbox
            },
            {
              headerName: '북마크',
              field: 'bookmark',
              width: 50,
              cellRendererFramework: CellBookmark
            },
            {
              headerName: '제외',
              field: 'except',
              width: 50,
              cellRendererFramework: CellExcept,
              cellRendererParams: {
                except: 'Y'
              }
            },
            {
              headerName: '실사용자명',
              field: 'incommingUser',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '착신전화번호',
              field: 'incommingNumber',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통화시작일시',
              field: 'dateTime',
              sortable: true,
              unSortIcon: true
            },
            {
              headerName: '통화량',
              field: 'length',
              sortable: true,
              unSortIcon: true,
              valueFormatter: GridFormatter.timeWithColons,
              width: 80,
              cellClass: 'align-right'
            },
            {
              headerName: '구분',
              field: 'type',
              sortable: true,
              unSortIcon: true
            }
          ],
          totalCount: 0,
          options: {
            overlayNoRowsTemplate:
              '<span class="ag-overlay-loading-center">좌측 영역에서 발신전화번호를 클릭하면, </br> 상세 통화 내역을 확인할 수 있습니다.</span>'
          }
        }
      }
    }
  },
  computed: {
    tabItemsLeft() {
      return [
        {
          name: `${
            this.gridInfo.outgoingNumber.tabName
          } (${NumberUtils.numberWithCommas(
            this.gridInfo.outgoingNumber.totalCount
          )})`
        }
      ]
    },
    tabItemsRight() {
      return [
        {
          name: `${
            this.gridInfo.callHistory.tabName
          } (${NumberUtils.numberWithCommas(
            this.gridInfo.callHistory.totalCount
          )})`
        }
      ]
    }
  },
  watch: {
    isShow(flag) {
      if (!flag) this.$refs.grid.dataReset()
    }
  },
  methods: {
    show(params, queryString = '') {
      this.isShow = true
      this.gridInfo.callHistory.totalCount = 0
      this.filter.station = params.data.station
      this.filter.address = params.data.address
      this.$nextTick(() => {
        this.$refs.outgoingNumber.setVisiblePage(2)
        this.$refs.outgoingNumber.setFilter(
          '&station={0}&address={1}{2}'.format(
            this.filter.station,
            this.filter.address,
            queryString
          )
        )
        this.$refs.outgoingNumber.loadData()
      })
    },
    onRowSelected(event) {
      if (event.node.selected) {
        this.filter.user = event.data.outgoingUser
        this.filter.number = event.data.outgoingNumber
        let queryStr = StringUtils.objQueryString(this.filter)
        this.$refs.grid.setFilter(queryStr)
        this.$refs.grid.loadData()
      }
    }
  }
}
</script>
