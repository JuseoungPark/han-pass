<template>
  <dea-dialog
    v-model="isShow"
    title="통화 전화번호 빈도(건수) 현황"
    width="1024px"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card class="detail-view">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">
                {{ outgoingUser }}({{ outgoingNumber }}) -
                {{ incommingUser }}({{ incommingNumber }}) 간 {{ postfix }}
              </div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div class="text">{{ dateStart }} ~ {{ dateEnd }}</div>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-card class="chart-wrap">
          <div class="frequency-charts" ref="frequencyCharts"></div>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button color="primary" @click="hide">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import am4themes_animated from '@amcharts/amcharts4/themes/animated'
import am4themes_dark from '@amcharts/amcharts4/themes/dark'
import '@/utils/StringUtils'

am4core.useTheme(am4themes_animated)

export default {
  name: 'DialogFrequencyGraph',
  components: {},
  data() {
    return {
      isShow: false,
      charts: null,
      chartsData: [],
      apiUri:
        '/api/call/history/frequency-number?outgoingNumber={0}&incommingNumber={1}',
      callData: null
    }
  },
  computed: {
    outgoingUser() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData)) return this.callData[0].outgoingUser
      return this.callData.outgoingUser
    },
    outgoingNumber() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData)) return this.callData[0].outgoingNumber
      return this.callData.outgoingNumber
    },
    incommingUser() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData)) return this.callData[0].incommingUser
      return this.callData.incommingUser
    },
    incommingNumber() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData)) return this.callData[0].incommingNumber
      return this.callData.incommingNumber
    },
    callCount() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData)) return this.callData[0]['count(*)']
      return this.callData['count(*)']
    },
    dateStart() {
      if (!this.chartsData.length) return ''
      return this.getFormatDate(this.chartsData[0].date)
    },
    dateEnd() {
      if (!this.chartsData.length) return ''
      return this.getFormatDate(
        this.chartsData[this.chartsData.length - 1].date
      )
    },
    postfix() {
      if (!this.callData) return ''
      if (Array.isArray(this.callData))
        return '외 {0} 건'.format(this.callData.length - 1)
      return '{0} 건'.format(this.callData['count(*)'])
    },
    name() {
      return this.outgoingUser + '-' + this.incommingUser
    }
  },
  methods: {
    show(params) {
      this.callData = params.data
      this.isShow = true
      this.chartsData = []

      // TODO: Better way ???
      setTimeout(() => {
        this.createCharts()
        this.loadData(this.callData)
      }, 200)
    },
    showMultiple(rows) {
      if (!rows || !Array.isArray(rows) || rows.length == 0) {
        this.$alert('선택된 데이터가 없습니다')
        return false
      }

      this.callData = rows
      this.isShow = true
      this.chartsData = []

      // TODO: Better way ???
      setTimeout(() => {
        this.createCharts()
        this.charts.legend = new am4charts.Legend()
        this.callData.forEach((e) => {
          this.loadData(e)
        })
      }, 200)
    },
    hide() {
      this.isShow = false
      if (this.charts) this.charts.dispose()
    },
    getFormatDate(date) {
      var year = date.getFullYear()
      var month = 1 + date.getMonth()
      month = month >= 10 ? month : '0' + month
      var day = date.getDate()
      day = day >= 10 ? day : '0' + day
      return year + '-' + month + '-' + day
    },
    genName(outgoingUser, incommingUser) {
      return outgoingUser + '-' + incommingUser
    },
    loadData(data) {
      let element = {}
      let name = this.genName(data.outgoingUser, data.incommingUser)
      this.$api.private
        .get(this.apiUri.format(data.outgoingNumber, data.incommingNumber))
        .then((res) => {
          res.data.rows.forEach((e) => {
            element = {}
            element.date = new Date(e.date)
            element[name] = e.count
            this.chartsData.push(element)
          })
          this.createData(name, name)
        })
    },
    createCharts() {
      if (this.$vuetify.theme.dark) am4core.useTheme(am4themes_dark)
      else am4core.unuseTheme(am4themes_dark)

      let chart = am4core.create(this.$refs.frequencyCharts, am4charts.XYChart)

      chart.paddingRight = 20
      chart.logo.disabled = true

      chart.data = this.chartsData

      let dateAxis = chart.xAxes.push(new am4charts.DateAxis())
      dateAxis.renderer.grid.template.location = 0

      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis())
      valueAxis.tooltip.disabled = true
      valueAxis.renderer.minWidth = 35

      chart.cursor = new am4charts.XYCursor()

      let scrollbarX = new am4charts.XYChartScrollbar()
      chart.scrollbarX = scrollbarX

      chart.scrollbarY = new am4core.Scrollbar()
      chart.scrollbarY.parent = chart.leftAxesContainer
      // chart.scrollbarY.toBack()

      this.charts = chart
    },
    createData(field, name) {
      let series = this.charts.series.push(new am4charts.LineSeries())
      series.dataFields.dateX = 'date'
      series.dataFields.valueY = field
      series.name = name
      series.tooltipText = '{name}: {valueY.value}'

      this.charts.scrollbarX.series.push(series)
      // this.charts.scrollbarY.series.push(series)
    }
  }
}
</script>

<style scoped>
.frequency-charts {
  width: 100%;
  height: 400px;
}
</style>
