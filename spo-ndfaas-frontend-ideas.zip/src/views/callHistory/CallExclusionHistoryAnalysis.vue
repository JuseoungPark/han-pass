<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>전화번호</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                label="전화번호"
                placeholder="전화번호를 입력하세요"
                v-model="filter.exceptnumber"
                @keyup="checkTelNumber"
              ></dea-text-field>
              <!-- <dea-select
                label="통신사"
                style="width:30%;"
                class="flex-0"
              ></dea-select> -->
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['number'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>제외자</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                label="제외자"
                placeholder="제외자를 입력하세요"
                prepend-inner-icon="mdi-account-check-outline"
                v-model="filter.exceptuser"
              ></dea-text-field>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['exceptUser'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>제외일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                :close-on-content-click="false"
                transition="scale-transition"
                label="제외일"
                offset-y
                v-model="filter.exceptdate"
              ></dea-date-picker-range>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['exceptDate'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  prepend-icon="mdi-magnify"
                  color="primary"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  prepend-icon="mdi-restore"
                  @click="resetFilter"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.totalCount"
          row-selection-multiple
          suppress-row-click-selection
          disableAutoLoad
          use-pagination
          @ready="onReady"
        >
          <template #header-left>
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </template>
          <template #header-right>
            <dea-button @click="goExcept">복원</dea-button>
          </template>
        </dea-grid>
      </div>
    </section>
  </v-container>
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import CellExcept from '@/components/grid/CellExcept'

import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import GridCommMixins from '@/mixins/callHistory/GridComm'
import eventBus from '@/mixins/eventBus'
import listTemplate from '@/mixins/listTemplate'
import { StringUtils } from '@/utils/StringUtils'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'

export default {
  name: 'CallExclusionHistoryAnalysis',
  mixins: [GridCommMixins, listTemplate, eventBus],
  data() {
    return {
      tabSelected: 0,
      tabName: '제외내역',
      filter: {
        except: 'Y',
        exceptnumber: '',
        exceptuser: '',
        exceptdate: ['2016-11-01', '2021-01-01']
      },
      gridInfo: {
        api: '/talk/excl-dtls',
        totalCount: 0,
        columns: [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: 'No',
                field: '',
                width: 60,
                cellClass: 'align-right'
              },
              {
                headerName: '제외자',
                field: 'lastChgUserNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '제외일',
                field: 'lastChgDt',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '발신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '사용자',
                field: 'dsptchUserNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '가입자',
                field: 'dsptchSbscrberNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'dsptchTelno',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '착신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '사용자',
                field: 'rcvUserNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '가입자',
                field: 'rcvSbscrberNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '전화번호',
                field: 'rcvTelno',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '통화정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작일시',
                field: 'talkBgngDt',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '통화시간',
                field: 'talkQy',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.timeWithColons,
                cellClass: 'align-right'
              },
              {
                headerName: '통화구분',
                field: 'talkTyNm',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '기지국',
                field: 'linkRelateLcNm',
                sortable: true,
                unSortIcon: true,
                tooltipField: 'station'
              },
              {
                headerName: '복원',
                field: 'restore',
                width: 70,
                cellRendererFramework: CellExcept,
                cellRendererParams: {
                  except: 'N'
                }
              }
            ]
          }
        ],
        onCellButtonClicked: (params) => {
          if (params.event == 'subscriber') {
            this.$refs.dialogSubscriberInfo.show(params.value)
          } else if (params.event == 'outgoingNumber') {
            this.$refs.dialogCallHistory.show(params)
          }
        }
      }
    }
  },
  computed: {
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo.totalCount
          )})`
        }
      ]
    },
    getParams() {
      return {
        exclDtBegin: ''
      }
    }
  },
  methods: {
    onReady() {
      this.loadData()
    },
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    checkTelNumber(e) {
      // e.target.value = e.target.value.replace(/[^0-9]/g, '')
      e.target.value = StringUtils.getPhoneMask(e.target.value)
    }
  },
  mounted() {
    this.except = 'N'
  }
}
</script>
