<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <dialog-select-person
                v-model="filter.users"
                use-pagination
                label="인물 선택"
                multiple
              ></dialog-select-person>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['users'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>착발신구분</dea-label>
            </v-col>
            <v-col class="d-flex" cols="4">
              <dea-checkbox
                label="전체"
                :disabled="filter.users.length === 0 ? true : false"
                :indeterminate="
                  filter.inOut.length > 0 && filter.inOut.length < 2
                "
                :true-value="true"
                :value="filter.inOut.length === 2 ? true : false"
                @click="toggle"
              />
              <dea-checkbox
                v-model="filter.inOut"
                label="착신"
                :disabled="filter.users.length === 0 ? true : false"
                cvalue="incomming"
              />
              <dea-checkbox
                v-model="filter.inOut"
                label="발신"
                :disabled="filter.users.length === 0 ? true : false"
                cvalue="outgoing"
              />
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col class="d-flex">
              <dea-button outlined @click="showDialogSelectDate"
                >검색 기간 추가</dea-button
              >
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdayTime"
              ></dialog-select-day-time>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdayTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1" />
            <v-col class="d-flex" cols="4" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner chart-wrap">
        <v-row no-gutters class="chart-top">
          <v-col class="d-flex d-block align-right">
            <dea-button>다른 차트로 보기</dea-button>
          </v-col>
        </v-row>
        <dea-card class="pa-0">
          <div class="chord-charts" ref="chordCharts">
            <v-row no-gutters style="height: 100%">
              <v-col class="d-flex align-center valign-middle">
                <h1>데이터가 없습니다.</h1>
              </v-col>
            </v-row>
          </div>
        </dea-card>
      </div>
    </section>

    <section class="dea-section" v-show="false">
      <div class="inner">
        <dea-grid ref="grid"></dea-grid>
      </div>
    </section>

    <!-- 발신건수 및 통화량 : Layer Popup -->
    <dea-dialog
      v-model="sendCallCountCallTotal"
      title="발신건수 및 통화량"
      width="480px"
    >
      <section class="dea-section">
        <div class="inner detail-view">
          <dea-card class="ba-0">
            <v-simple-table dense fixed-header>
              <template v-slot:default>
                <colgroup>
                  <col width="25%" />
                  <col width="25%" />
                  <col width="25%" />
                  <col width="25%" />
                </colgroup>
                <thead>
                  <tr>
                    <th>발신자</th>
                    <th>건수</th>
                    <th>통화량</th>
                    <th>내역보기</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{{ sendCallCountCallTotalData.fromName }}</td>
                    <td class="align-right">
                      {{ callCount }}
                    </td>
                    <td>{{ callLength }}</td>
                    <td rowspan="2">
                      <a class="text-decoration-none" @click="showGrid"
                        >자세히보기</a
                      >
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button
            color="primary"
            @click="sendCallCountCallTotal = !sendCallCountCallTotal"
            >확인</dea-button
          >
          <v-icon>mdi-flag-variant</v-icon>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //발신건수 및 통화량 : Layer Popup -->

    <!-- 기간 선택 : Layer Popup -->
    <dialog-select-date
      ref="dialogSelectDate"
      v-model="filter.date"
    ></dialog-select-date>
    <!-- //기간 선택 : Layer Popup -->

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
import DialogSelectPerson from './Dialog/DialogSelectPerson'
import DialogSelectDate from './Dialog/DialogSelectDate'
import DialogSelectDayTime from './Dialog/DialogSelectDayTime'
import DialogCallHistory from './Dialog/DialogCallHistory' // 통화내역
import * as am4core from '@amcharts/amcharts4/core'
import * as am4charts from '@amcharts/amcharts4/charts'
import am4themes_animated from '@amcharts/amcharts4/themes/animated'
import am4themes_dark from '@amcharts/amcharts4/themes/dark'

am4core.useTheme(am4themes_animated)

var SlotContent = {
  name: 'SlotContent',
  template: `
    <v-row no-gutters class="ml-4">
      <v-col>
        <dea-radio-group
          class="dea-btn-radio"
          v-model="child.filter.chartType"
          row
          :mandatory="false"
          :items="child.listTypeItems"
          @change="onChange"
        ></dea-radio-group>
      </v-col>
    </v-row>
    `,
  props: {
    child: {}
  },
  methods: {
    onChange() {
      this.child.onSearch()
    }
  }
}

export default {
  name: 'BetweenKeyPeopleAnalysis',
  mixins: [listTemplate],
  components: {
    DialogSelectPerson,
    DialogSelectDate,
    DialogSelectDayTime,
    DialogCallHistory
  },
  data() {
    return {
      chartsApi: '/api/call/between-key-person/charts',
      filter: {
        chartType: 'user',
        type: 'list',
        users: [],
        outgoingUsers: [],
        incommingUsers: [],
        date: [
          new Date().toISOString().substr(0, 10),
          new Date().toISOString().substr(0, 10)
        ],
        weekofdayTime: '',
        inOut: ['incomming', 'outgoing']
      },
      dateMin: '',
      dateMax: '',
      validError: {},
      listTypeItems: [
        {
          label: '실사용자',
          value: 'user'
        },
        {
          label: '전화번호',
          value: 'number'
        }
      ],
      sendCallCountCallTotal: false,
      sendCallCountCallTotalData: {},
      charts: null,
      chartsData: []
    }
  },
  computed: {
    ...mapGetters(['incidentInfo']),
    callCount() {
      return NumberUtils.numberWithCommas(this.sendCallCountCallTotalData.value)
    },
    callLength() {
      return NumberUtils.timeWithColons(this.sendCallCountCallTotalData.length)
    },
    capitalizeFirstLetterType() {
      return (
        this.filter.chartType.charAt(0).toUpperCase() +
        this.filter.chartType.slice(1)
      )
    }
  },
  mounted() {
    this.$emit('slot-content:add', {
      name: this.$options.name,
      component: SlotContent,
      child: this
    })

    this.$api.analysis.handler.getDateMinMax(
      this.incidentInfo.id,
      (dateMin, dateMax) => {
        if (dateMin && dateMax) {
          this.dateMin = dateMin
          this.dateMax = dateMax
          this.filter.date = [dateMin, dateMax]

          this.setInitFilter(this.filter)
          this.updateFilter()
          // this.loadChartsData()
        }
      }
    )
  },
  destroyed() {
    this.$emit('slot-content:delete', this.$options.name)
  },
  methods: {
    getColumns() {
      this.$refs.grid.setColumns([])
    },
    toggle() {
      this.$nextTick(() => {
        if (this.filter.inOut.length === 2) {
          this.filter.inOut = []
        } else {
          this.filter.inOut = ['incomming', 'outgoing']
        }
      })
    },
    onSearch() {
      // this.$refs.grid.reset()
      // this.loadData()
      // this.loadChartsData()
    },
    loadChartsData() {
      let queryString = this.objQueryString(this.filter)
      this.$api.private.get(this.chartsApi + '?' + queryString).then((res) => {
        this.chartsData = res.data.rows
        this.createCharts()
      })
    },
    showDialogSelectDate() {
      this.$refs.dialogSelectDate.show()
    },
    onChartClick() {
      this.sendCallCountCallTotal = true
    },
    createCharts() {
      if (this.charts) this.charts.dispose()

      if (this.$vuetify.theme.dark) am4core.useTheme(am4themes_dark)
      else am4core.unuseTheme(am4themes_dark)

      let chart = am4core.create(this.$refs.chordCharts, am4charts.ChordDiagram)

      chart.logo.disabled = true

      // colors of main characters
      chart.colors.saturation = 0.45
      chart.colors.step = 3
      var colors = {
        Rachel: chart.colors.next(),
        Monica: chart.colors.next(),
        Phoebe: chart.colors.next(),
        Ross: chart.colors.next(),
        Joey: chart.colors.next(),
        Chandler: chart.colors.next()
      }

      chart.data = this.chartsData

      chart.dataFields.fromName = 'outgoing' + this.capitalizeFirstLetterType
      chart.dataFields.fromUser = 'outgoingUser'
      chart.dataFields.fromNumber = 'outgoingNumber'
      chart.dataFields.toName = 'incomming' + this.capitalizeFirstLetterType
      chart.dataFields.toUser = 'incommingUser'
      chart.dataFields.toNumber = 'incommingNumber'
      chart.dataFields.value = 'count'
      chart.dataFields.length = 'length'

      chart.nodePadding = 0.5
      chart.minNodeSize = 0.01
      chart.startAngle = 80
      chart.endAngle = chart.startAngle + 360
      chart.sortBy = 'count'
      chart.fontSize = 10

      var nodeTemplate = chart.nodes.template
      nodeTemplate.readerTitle = 'Click to show/hide or drag to rearrange'
      nodeTemplate.showSystemTooltip = true
      nodeTemplate.propertyFields.fill = 'color'
      nodeTemplate.tooltipText = '{name}의 통화: {total}'

      // when rolled over the node, make all the links rolled-over
      nodeTemplate.events.on('over', function(event) {
        var node = event.target
        node.outgoingDataItems.each(function(dataItem) {
          if (dataItem.toNode) {
            dataItem.link.isHover = true
            dataItem.toNode.label.isHover = true
          }
        })
        node.incomingDataItems.each(function(dataItem) {
          if (dataItem.fromNode) {
            dataItem.link.isHover = true
            dataItem.fromNode.label.isHover = true
          }
        })

        node.label.isHover = true
      })

      // when rolled out from the node, make all the links rolled-out
      nodeTemplate.events.on('out', function(event) {
        var node = event.target
        node.outgoingDataItems.each(function(dataItem) {
          if (dataItem.toNode) {
            dataItem.link.isHover = false
            dataItem.toNode.label.isHover = false
          }
        })
        node.incomingDataItems.each(function(dataItem) {
          if (dataItem.fromNode) {
            dataItem.link.isHover = false
            dataItem.fromNode.label.isHover = false
          }
        })

        node.label.isHover = false
      })

      var label = nodeTemplate.label
      label.relativeRotation = 90

      label.fillOpacity = 0.4
      let labelHS = label.states.create('hover')
      labelHS.properties.fillOpacity = 1

      nodeTemplate.cursorOverStyle = am4core.MouseCursorStyle.pointer
      // this adapter makes non-main character nodes to be filled with color of the main character which he/she kissed most
      nodeTemplate.adapter.add('fill', function(fill, target) {
        let node = target
        let counters = {}
        let mainChar = false
        node.incomingDataItems.each(function(dataItem) {
          if (colors[dataItem.toName]) {
            mainChar = true
          }

          if (isNaN(counters[dataItem.fromName])) {
            counters[dataItem.fromName] = dataItem.value
          } else {
            counters[dataItem.fromName] += dataItem.value
          }
        })
        if (mainChar) {
          return fill
        }

        // let count = 0
        // let color
        let biggest = 0
        let biggestName

        for (var name in counters) {
          if (counters[name] > biggest) {
            biggestName = name
            biggest = counters[name]
          }
        }
        if (colors[biggestName]) {
          fill = colors[biggestName]
        }

        return fill
      })

      // link template
      var linkTemplate = chart.links.template
      linkTemplate.strokeOpacity = 0
      linkTemplate.fillOpacity = 0.15
      linkTemplate.tooltipText = '{fromName} -> {toName}:{value.value}'

      var hoverState = linkTemplate.states.create('hover')
      hoverState.properties.fillOpacity = 0.7
      hoverState.properties.strokeOpacity = 0.7

      linkTemplate.events.on('hit', this.showPopupDetail)

      this.charts = chart
    },
    showPopupDetail(event) {
      this.sendCallCountCallTotalData = event.target.dataItem
      this.sendCallCountCallTotal = true
    },
    showGrid() {
      let title = ''
      let filter = '&chartType={0}&type={1}&date={2}'.format(
        this.filter.chartType,
        this.filter.type,
        this.filter.date.join(',')
      )
      if (this.filter.chartType === 'user') {
        filter += '&outgoingUsers={0}&incommingUsers={1}'.format(
          this.sendCallCountCallTotalData.fromUser,
          this.sendCallCountCallTotalData.toUser
        )
        title =
          this.sendCallCountCallTotalData.fromName +
          '-' +
          this.sendCallCountCallTotalData.toName
      } else {
        filter += '&outgoingNumber={0}&incommingNumber={1}'.format(
          this.sendCallCountCallTotalData.fromNumber,
          this.sendCallCountCallTotalData.toNumber
        )
        title =
          this.sendCallCountCallTotalData.fromNumber +
          '-' +
          this.sendCallCountCallTotalData.toNumber
      }
      this.sendCallCountCallTotal = false
      this.$refs.dialogCallHistory.showByFilter(title, filter)
    }
  }
}
</script>

<style scope>
.chord-charts {
  width: 100%;
  height: 1024px;
}
</style>
