<template>
  <fragment>
    <dea-button
      v-if="!disableBookmark"
      icon
      textindent
      fab
      title="북마크"
      prepend-icon="mdi-bookmark-multiple"
      bottom
      @click="goBookmark(true)"
    >
      북마크
    </dea-button>
    <dea-button
      v-if="!disableBookmark"
      icon
      textindent
      title="북마크해제"
      prepend-icon="mdi-bookmark-multiple-outline"
      bottom
      outlined
      @click="goBookmark(false)"
    >
      북마크해제
    </dea-button>
    <dea-button
      icon
      textindent
      fab
      title="제외"
      prepend-icon="mdi-minus-circle-outline"
      bottom
      @click="goExcept()"
    >
      제외
    </dea-button>
  </fragment>
</template>

<script>
export default {
  name: 'GridCommBtn',
  props: {
    disableBookmark: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    goBookmark(flag) {
      this.$emit('goBookmark', flag)
    },
    async goExcept() {
      this.$emit('goExcept')
    }
  }
}
</script>
