<template>
  <v-container>
    <section class="dea-section">
      <!-- {{ filter }} -->
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>가입자명</dea-label>
            </v-col>
            <v-col class="d-flex" cols="3">
              <dea-text-field
                clearable
                label="가입자명"
                v-model="filter.sbscrberNm"
              />
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['subscriber'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>전화번호</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                clearable
                v-model="filter.telno"
                @keyup="checkTelNumber"
                label="전화번호"
              />
              <dea-select
                label="통신사"
                v-model="filter.telecom"
                style="width:30%;"
                class="flex-0"
                :items="telecomItems"
              >
              </dea-select>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['number'])"
              >
                초기화
              </dea-button>
            </v-col>
            <!-- <v-col class="d-flex" cols="1" /> -->
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>주요인물</dea-label>
            </v-col>
            <v-col class="d-flex" cols="3">
              <dea-radio-group
                v-model="filter.mainIsrtyYn"
                row
                :items="majorPersonItems"
              ></dea-radio-group>
            </v-col>
            <v-col cols="1">
              <dea-label>가입일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="join.type"
                row
                :items="join.items"
              ></dea-radio-group>
              <dea-date-picker-range
                v-model="filter.joinDate"
                :close-on-content-click="false"
                label="가입일"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col cols="1">
              <dea-label>해지일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-radio-group
                v-model="termination.type"
                row
                :items="termination.items"
              ></dea-radio-group>
              <dea-date-picker-range
                v-model="filter.terminationDate"
                :close-on-content-click="false"
                label="해지일"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['joinDate', 'terminationDate'])"
              >
                초기화
              </dea-button>
            </v-col>
            <!-- <v-col class="d-flex" cols="1" /> -->
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  color="primary"
                  prepend-icon="mdi-magnify"
                  @click="onSearch"
                  title="조회"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  @click="resetFilter"
                  prepend-icon="mdi-restore"
                  title="초기화"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          use-pagination
          :columns="gridInfo.columns"
          :api="gridInfo.api"
          :return-value.sync="gridInfo.totalCount"
          @cellButtonClicked="gridInfo.onCellButtonClicked"
        >
          <!-- disableAutoLoad
          @ready="onReady" -->
          <template #header-left>
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </template>
        </dea-grid>
      </div>
    </section>
  </v-container>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'
import listTemplate from '@/mixins/listTemplate'
import { NumberUtils } from '@/utils/NumberUtils'
export default {
  name: 'SubscriberAnalysis',
  mixins: [listTemplate],
  data() {
    return {
      params: {
        sbscrberNm: '',
        telecom: '',
        telno: '',
        mainIsrtyYn: 'N',
        joinBgngYmd: '',
        joinEndYmd: '',
        trmnatBgngYmd: '',
        trmnatEndYmd: ''
      },
      filter: {
        sbscrberNm: '',
        telecom: '',
        telno: '',
        mainIsrtyYn: 'N',
        joinDate: ['1982-06-30', new Date().toISOString().substr(0, 10)],
        terminationDate: ['1989-11-04', '2017-02-15']
      },
      join: {
        type: 'all',
        items: [
          {
            label: '전체',
            value: 'all'
          },
          {
            label: '',
            value: 'date'
          }
        ],
        date: ['1982-06-30', new Date().toISOString().substr(0, 10)]
      },
      termination: {
        type: 'all',
        items: [
          {
            label: '전체',
            value: 'all'
          },
          {
            label: '',
            value: 'date'
          }
        ],
        date: ['1989-11-04', '2017-02-15']
      },
      gridInfo: {
        api: '/talk/sbscrber-dtls',
        // api: '/api/call/subscriber',
        columns: [
          {
            headerName: 'No',
            field: 'no',
            width: 60,
            cellClass: 'align-right'
          },
          {
            headerName: '실사용자명',
            field: 'rluserNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '가입자명',
            field: 'sbscrberNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '통신사',
            field: 'telecom',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '전화번호',
            field: 'telno',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '주소',
            field: 'adres',
            sortable: true,
            unSortIcon: true,
            tooltipField: 'address'
          },
          {
            headerName: '가입일',
            field: 'joinYmd',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '해지일',
            field: 'trmnatYmd',
            sortable: true,
            unSortIcon: true
          }
        ],
        totalCount: 0,
        onCellButtonClicked: (params) => {
          console.log(params)
        }
      },
      tabName: '가입자내역',
      tabSelected: 0,
      telecomItems: [{ text: '전체', value: 'all' }],
      majorPersonItems: [
        {
          label: '등록',
          value: 'Y'
        },
        {
          label: '미등록',
          value: 'N'
        }
      ]
    }
  },
  computed: {
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo.totalCount
          )})`
        }
      ]
    },
    getParams() {
      let params = {
        sbscrberNm: this.filter.sbscrberNm,
        telecom: this.filter.telecom,
        telno: this.filter.telno,
        mainIsrtyYn: this.filter.mainIsrtyYn,
        joinBgngYmd: this.join.type === 'all' ? '' : this.filter.joinDate[0],
        joinEndYmd: this.join.type === 'all' ? '' : this.filter.joinDate[1],
        trmnatBgngYmd:
          this.termination.type === 'all' ? '' : this.filter.terminationDate[0],
        trmnatEndYmd:
          this.termination.type === 'all' ? '' : this.filter.terminationDate[1]
      }
      return params
    }
  },
  methods: {
    onSearch() {
      this.$refs.grid.reset()
      // if (this.join.type === 'all' || this.termination.type === 'all') {
      //   let _filter = { ...this.filter }
      //   if (this.join.type === 'all') {
      //     _filter.joinDate = ''
      //   }
      //   if (this.termination.type === 'all') {
      //     _filter.terminationDate = ''
      //   }
      //   this._setFilter(_filter)
      //   this.$refs.grid.loadData()
      // } else {
      //   this.loadData()
      // }
      this.loadData()
    },
    checkTelNumber(e) {
      // e.target.value = e.target.value.replace(/[^0-9]/g, '')
      e.target.value = StringUtils.getPhoneMask(e.target.value)
    },
    async getTelecom() {
      return await this.$api.private
        .get(`/api/call/telecom`)
        .then((res) => {
          return res.data.rows.map((item) => {
            return { text: item.telecom, value: item.telecom }
          })
        })
        .catch(function(error) {
          return { error: error }
        })
    },
    onReady() {
      this.loadData()
    }
  },
  async created() {
    let t = await this.getTelecom()
    this.telecomItems = this.telecomItems.concat(t)
  }
}
</script>
