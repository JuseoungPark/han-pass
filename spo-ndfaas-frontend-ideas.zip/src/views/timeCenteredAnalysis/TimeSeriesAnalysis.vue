<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <v-menu close-on-click offset-y>
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">화면저장</v-btn>
                </template>
                <!-- 화면저장 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:240px;">
                  <v-container class="pa-0">
                    <section class="dea-section">
                      <div class="inner">
                        <v-list dense>
                          <v-list-item-group>
                            <v-list-item>
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col class="d-flex valign-middle">
                                      화면을 PC에 저장
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-list-item>
                              <v-list-item-content>
                                <v-list-item-title>
                                  <v-row no-gutters>
                                    <v-col class="d-flex valign-middle">
                                      저장화면 불러오기
                                    </v-col>
                                  </v-row>
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장 : Layer Popup -->
              </v-menu>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-col>
            <v-col class="d-flex align-center">
              <dea-select
                label="대상인물"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <dea-select
                label="공통노드"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <dea-select
                label="노드그룹"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <v-menu close-on-click offset-y>
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">
                    <v-icon>mdi-magnify</v-icon>
                    인물찾기
                  </v-btn>
                </template>
                <!-- 화면저장 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:400px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <v-row no-gutters>
                          <v-col class="d-flex">
                            <dea-text-field
                              label="분석하고자 하는 인물을 검색하세요"
                              append-icon="mdi-magnify"
                            ></dea-text-field>
                          </v-col>
                        </v-row>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //화면저장 : Layer Popup -->
              </v-menu>
            </v-col>
            <v-col class="d-flex align-right">
              <dea-select
                label="보기설정"
                style="width:120px;"
                class="flex-0"
              ></dea-select>
              <v-menu v-model="settingAnalysis" close-on-click offset-y>
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on" color="primary">분석설정</v-btn>
                </template>
                <!-- 분석설정 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:450px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <template slot="title">인물설정</template>
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <dialog-ts-select-person
                                v-model="filter.users"
                                label="인물을 검색하세요"
                              ></dialog-ts-select-person>
                              <!-- <dea-text-field
                                placeholder="인물을 검색하세요"
                                prepend-inner-icon="mdi-account-check-outline"
                                append-icon="mdi-magnify"
                              ></dea-text-field> -->
                            </v-col>
                          </v-row>
                        </dea-card>
                      </div>
                      <div class="btn-group">
                        <v-col class="align-center">
                          <dea-button @click="settingAnalysis = false"
                            >닫기</dea-button
                          >
                          <dea-button
                            prepend-icon="mdi-magnify"
                            color="primary"
                            @click="onClickLoadGraph"
                          >
                            조회
                          </dea-button>
                          <dea-button outlined prepend-icon="mdi-restore">
                            초기화
                          </dea-button>
                        </v-col>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //분석설정 : Layer Popup -->
              </v-menu>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-timebase-graph ref="deaTimebaseGraph" />
      </div>
    </section>
  </v-container>
</template>

<script>
import DeaTimebaseGraph from '@/components/graphs/DeaTimebaseGraph'
import DialogTsSelectPerson from './Dialog/DialogTsSelectPerson'

export default {
  name: 'TimeSeriesAnalysis',
  components: {
    DeaTimebaseGraph,
    DialogTsSelectPerson
  },
  data() {
    return {
      filter: {
        users: []
      },
      loader: null,
      loading: false,
      settingAnalysis: false
    }
  },
  methods: {
    onClickLoadGraph() {
      // this.$refs.deaTimebaseGraph.setUsers(this.filter.users)
      // this.$refs.deaTimebaseGraph.reRenderObjects()
    }
  }
}
</script>
