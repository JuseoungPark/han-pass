<template>
  <v-menu v-model="menu" close-on-content-click>
    <template v-slot:activator="{ on, attrs }">
      <v-text-field
        v-model="selectedText"
        dense
        outlined
        :label="label"
        :placeholder="placeholder"
        prepend-inner-icon="mdi-account-check-outline"
        v-bind="attrs"
        v-on="on"
      ></v-text-field>
    </template>
    <dea-dialog
      v-model="menu"
      title="인물 선택"
      width="800px"
      ref="dialog"
      @dialog:close="onDialogClose"
    >
      <section class="dea-section">
        <div class="search-box">
          <dea-card>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-radio-group
                  v-model="personType"
                  row
                  :mandatory="false"
                  :items="personTypeItems"
                ></dea-radio-group>
              </v-col>
            </v-row>
            <v-row no-gutters>
              <v-col class="d-flex">
                <dea-select
                  v-model="group"
                  :items="groupItems"
                  label="그룹선택"
                  style="width:200px;"
                  class="flex-0"
                ></dea-select>
                <dea-text-field
                  v-model="searchText"
                  label="인물을 검색하세요"
                ></dea-text-field>
                <dea-button color="primary" prepend-icon="mdi-magnify"
                  >조회</dea-button
                >
              </v-col>
            </v-row>
          </dea-card>
        </div>
      </section>
      <section class="dea-section">
        <div class="inner">
          <v-layout class="shuttle">
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>검색결과 ({{ shuttleLeftItems.length }})</v-tab>
                  </v-tabs>
                  <div class="text text-nowrap">
                    인물을 선택해주세요.
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleLeftModel" multiple>
                    <template v-for="(shuttleLeftItem, i) in shuttleLeftItems">
                      <v-list-item
                        :key="'shuttleLeftItem' + i"
                        :value="shuttleLeftItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleLeftItem.name"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleLeftItem.number"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
            <v-col class="btn-wrap">
              <dea-button
                icon
                textindent
                outlined
                title="우측으로 이동"
                prepend-icon="mdi-arrow-right-thick"
                bottom
                @click="onClickMoveRight"
              >
                우측으로 이동
              </dea-button>
              <dea-button
                icon
                textindent
                outlined
                title="좌측으로 이동"
                prepend-icon="mdi-arrow-left-thick"
                bottom
                @click="onClickMoveLeft"
              >
                좌측으로 이동
              </dea-button>
            </v-col>
            <v-col>
              <v-row no-gutters class="list-top">
                <v-col class="d-flex">
                  <div class="text">
                    선택된 인물 ({{ shuttleRightItems.length }})
                  </div>
                </v-col>
              </v-row>
              <dea-card class="pa-0">
                <v-list dense height="380" class="overflow-y-auto">
                  <v-list-item-group v-model="shuttleRightModel" multiple>
                    <template
                      v-for="(shuttleRightItem, i) in shuttleRightItems"
                    >
                      <v-list-item
                        :key="'shuttleRightItem' + i"
                        :value="shuttleRightItem"
                      >
                        <template v-slot:default="{ active }">
                          <v-list-item-action>
                            <v-checkbox :input-value="active"></v-checkbox>
                          </v-list-item-action>
                          <v-list-item-content class="flex-row">
                            <v-list-item-title
                              v-text="shuttleRightItem.name"
                            ></v-list-item-title>
                            <v-list-item-subtitle
                              v-text="shuttleRightItem.number"
                            ></v-list-item-subtitle>
                          </v-list-item-content>
                        </template>
                      </v-list-item>
                    </template>
                  </v-list-item-group>
                </v-list>
              </dea-card>
            </v-col>
          </v-layout>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="onClickCancel">취소</dea-button>
          <dea-button color="primary" @click="onClickOk">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
  </v-menu>
</template>

<script>
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DialogTsSelectPerson',
  mixins: [apiMixin],
  props: {
    label: {
      type: String,
      default: undefined
    },
    placeholder: {
      type: String,
      default: undefined
    },
    showOnLoad: {
      type: Boolean,
      default: false
    },
    value: {
      default: function() {
        return []
      }
    }
  },
  data() {
    return {
      menu: false,
      personType: 61,
      personTypeItems: [
        {
          label: '주요인물',
          value: 61
        },
        {
          label: '피의자',
          value: 11
        },
        {
          label: '혐의자',
          value: 21
        },
        {
          label: '참고인',
          value: 31
        },
        {
          label: '피해자',
          value: 41
        },
        {
          label: '기타',
          value: 51
        }
      ],
      group: '인물그룹 전체',
      groupItems: ['인물그룹 전체', '그룹1', '그룹2', '그룹3'],
      shuttleLeftModel: [],
      shuttleLeftItems: [],
      shuttleRightModel: [],
      shuttleRightItems: [],
      searchText: '',
      localData: []
    }
  },
  computed: {
    selectedText: {
      get: function() {
        if (this.localData.length == 1) {
          return this.localData[0].name
        } else if (this.localData.length > 1) {
          return (
            this.localData[0].name + ' 외 ' + (this.localData.length - 1) + '명'
          )
        }
        return ''
      },
      set: function() {}
    }
  },
  watch: {
    value(val) {
      if (!val.length) this.init()
    },
    personType() {
      this.loadItems()
    }
  },
  mounted() {
    this.apiUrl = '/api/person-management/persons'
    this.init()
  },
  methods: {
    init() {
      this.shuttleLeftItems = []
      this.shuttleLeftModel = []
      this.shuttleRightItems = []
      this.shuttleRightModel = []
      this.localData = []

      this.loadItems()
    },
    loadItems() {
      this.shuttleLeftItems = []
      this.shuttleLeftModel = []
      this.filter = 'personType={0}&limit=-1&page=1'.format(this.personType)

      this.requestApiAsync((res) => {
        res.data.rows.forEach((e) => {
          this.shuttleLeftItems.push({ name: e.name, number: e.phoneNumber })
        })
        this.shuttleLeftItems.sort()
      })
    },
    onClickMoveRight() {
      this.shuttleLeftModel.forEach((e) => {
        if (this.shuttleRightItems.some((v) => v.name === e.name)) return true
        this.shuttleRightItems.push(e)
        // this.shuttleLeftItems.splice(this.shuttleLeftItems.indexOf(e), 1)
      })
      this.shuttleLeftModel = []
      this.shuttleRightItems.sort()
    },
    onClickMoveLeft() {
      this.shuttleRightModel.forEach((e) => {
        // this.shuttleLeftItems.push(e)
        this.shuttleRightItems.splice(this.shuttleRightItems.indexOf(e), 1)
      })
      this.shuttleRightModel = []
      // this.shuttleLeftItems.sort()
    },
    onClickCancel() {
      this.menu = false
      this.syncRightItems()
    },
    onClickOk() {
      this.menu = false
      this.localData = Array.from(this.shuttleRightItems, (e) => {
        return e
      })
      this.$emit(
        'input',
        Array.from(this.shuttleRightItems, (e) => {
          return e.name
        })
      )
    },
    resetData() {
      this.init()
      this.$emit('input', [])
    },
    syncRightItems() {
      this.shuttleLeftModel = []
      this.shuttleRightModel = []
      this.shuttleRightItems = []

      this.localData.forEach((e) => {
        this.shuttleRightItems.push(e)
      })
    },
    onDialogClose() {
      this.syncRightItems()
    }
  }
}
</script>
