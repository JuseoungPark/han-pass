<template>
  <v-container>
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <dea-grid use-pagination>
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>예약 다운로드 목록 (4)</v-tab>
                </v-tabs>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
export default {
  name: 'FileStorageManagement'
}
</script>
