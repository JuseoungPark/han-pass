<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>검색어</dea-label>
            </v-col>
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-select
                    v-model="selectLists"
                    :items="selectItems"
                    label="검색어 범위"
                    style="width:200px;"
                    class="flex-0"
                  ></dea-select>
                  <dea-text-field
                    label="검색어"
                    placeholder="파일명, 파일경로, 또는 본문 내용을 입력하여 검색하세요"
                  ></dea-text-field>
                  <dea-checkbox label="결과내 검색"></dea-checkbox>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-text-field
                    label="일치하는 단어"
                    prepend-inner-icon="mdi-check"
                  ></dea-text-field>
                  <dea-text-field
                    label="반드시 포함하는 단어"
                    prepend-inner-icon="mdi-plus"
                  ></dea-text-field>
                  <dea-text-field
                    label="제외하는 단어"
                    prepend-inner-icon="mdi-minus"
                  ></dea-text-field>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </v-row>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                label="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
                style="width:200px;"
                class="flex-0"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>파일크기</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                label="파일 크기"
                style="width:100px;"
                class="flex-0"
              ></dea-text-field>
              <div class="text">kb 이상</div>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
              <dea-button outlined>검색 기간 추가</dea-button>
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdaytTime"
              ></dialog-select-day-time>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdaytTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>전체목록 (14)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex">
                <dea-button>파일저장</dea-button>
                <dea-button
                  icon
                  textindent
                  fab
                  prepend-icon="mdi-bookmark-multiple-outline"
                >
                  북마크
                </dea-button>
                <dea-button
                  icon
                  textindent
                  fab
                  prepend-icon="mdi-minus-circle-outline"
                >
                  북마크 제외
                </dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>

    <!-- 페이지내 좌측메뉴 -->
    <v-navigation-drawer
      class="treeLeft"
      :class="collapsibleLeft ? 'foldTreeLeft' : 'expandTreeLeft'"
    >
      <v-list dense class="collapsible-btn">
        <v-list-item @click="collapsibleLeft = !collapsibleLeft">
          <v-list-item-action>
            <v-icon>
              {{ collapsibleLeft ? 'mdi-exit-to-app' : 'mdi-exit-to-app' }}
            </v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>
              {{
                collapsibleLeft ? '디렉토리 영역 닫기' : '디렉토리 영역 열기'
              }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      <v-treeview
        v-model="folderTree"
        :open="open"
        :items="items"
        item-key="name"
        activatable
        open-on-click
      >
        <template v-slot:prepend="{ item, open }">
          <v-icon v-if="!item.file">
            {{ open ? 'mdi-folder-open' : 'mdi-folder' }}
          </v-icon>
          <v-icon v-else>
            {{ files[item.file] }}
          </v-icon>
        </template>
      </v-treeview>
    </v-navigation-drawer>
    <!-- //페이지내 좌측메뉴 -->

    <!-- 파일경로내 파일목록 : Layer Popup -->
    <!-- <dea-dialog
      v-model="filePathList"
      title="파일경로내 파일목록"
      width="800px"
    >
      <section class="dea-section">
        <div class="inner">
          <dea-card>
            <template slot="title">mail/imgage/user01/</template>
            <dea-grid use-pagination :columns="gridInfo.columns">
              <template #header-left>
                <v-col class="d-flex">
                  <v-tabs class="dea-tabs">
                    <v-tab>파일목록 (2)</v-tab>
                  </v-tabs>
                </v-col>
              </template>
              <template #header-right>
                <v-col class="d-flex">
                  <dea-button>파일저장</dea-button>
                  <dea-button
                    icon
                    fab
                    prepend-icon="mdi-bookmark-multiple-outline"
                  ></dea-button>
                  <dea-button
                    icon
                    fab
                    prepend-icon="mdi-minus-circle-outline"
                  ></dea-button>
                </v-col>
              </template>
            </dea-grid>
          </dea-card>
        </div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="filePathList = !filePathList"
            >닫기</dea-button
          >
        </v-col>
      </div>
    </dea-dialog> -->
    <!-- //파일경로내 파일목록 : Layer Popup -->
  </v-container>
</template>

<script>
import DialogSelectDayTime from '../callHistory/Dialog/DialogSelectDayTime'

export default {
  name: 'FileTypeAnalysis',
  components: {
    DialogSelectDayTime
  },
  data() {
    return {
      gridInfo: {
        api: '',
        count: 0,
        columns: []
      },
      filter: {
        date: [
          new Date().toISOString().substr(0, 10),
          new Date().toISOString().substr(0, 10)
        ],
        weekofdaytTime: []
      },
      // Modal Popup
      filePathList: false,
      selectLists: '전체',
      selectItems: ['전체'],
      // 페이지내 좌측메뉴
      collapsibleLeft: false,
      open: ['문서 (145)'],
      files: {
        person: 'mdi-account',
        document: 'mdi-file-document',
        cellphone: 'mdi-cellphrone-iphone',
        notebook: 'mdi-laptop-windows',
        picture: 'mdi-image',
        movie: 'mdi-play-box',
        voice: 'mdi-text-to-speech',
        zip: 'mdi-zip-box',
        etc: 'mdi-dots-horizontal',
        email: 'mdi-email',
        restore: 'mdi-restore-alert',
        virus: 'mdi-security',
        password: 'mdi-lock-open'
      },
      folderTree: [],
      items: [
        {
          name: '문서 (145)',
          file: 'document',
          children: [
            { name: '실사용자1 PC', file: 'person' },
            { name: '실사용자1 스마트폰', file: 'person' },
            { name: '실사용자1 노트북', file: 'person' }
          ]
        },
        { name: '그림/사진 (123)', file: 'picture' },
        { name: '동영상 (13)', file: 'movie' },
        { name: '음성 (4)', file: 'voice' },
        { name: '압축 (23)', file: 'zip' },
        { name: '기타 (21)', file: 'etc' },
        { name: '이메일 (432)', file: 'email' },
        { name: '실패복구 (23)', file: 'restore' },
        { name: '바이러스감지 (1)', file: 'virus' },
        { name: '암호파일 (1)', file: 'password' }
      ]
    }
  }
}
</script>
