<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>검색어</dea-label>
            </v-col>
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-select
                    v-model="selectLists"
                    :items="selectItems"
                    label="검색어 범위"
                    style="width:200px;"
                    class="flex-0"
                  ></dea-select>
                  <dea-text-field
                    label="검색어"
                    placeholder="파일명, 파일경로, 또는 본문 내용을 입력하여 검색하세요"
                  ></dea-text-field>
                  <dea-checkbox label="결과내 검색"></dea-checkbox>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-text-field
                    label="일치하는 단어"
                    prepend-inner-icon="mdi-check"
                  ></dea-text-field>
                  <dea-text-field
                    label="반드시 포함하는 단어"
                    prepend-inner-icon="mdi-plus"
                  ></dea-text-field>
                  <dea-text-field
                    label="제외하는 단어"
                    prepend-inner-icon="mdi-minus"
                  ></dea-text-field>
                  <dea-button icon textindent prepend-icon="mdi-restore">
                    초기화
                  </dea-button>
                </v-col>
              </v-row>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물선택</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                label="인물 선택"
                prepend-inner-icon="mdi-account-check-outline"
                style="width:200px;"
                class="flex-0"
              ></dea-text-field>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
            <v-col cols="1">
              <dea-label>파일크기</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <dea-text-field
                label="파일 크기"
                style="width:100px;"
                class="flex-0"
              ></dea-text-field>
              <div class="text">kb 이상</div>
              <dea-button icon textindent prepend-icon="mdi-restore">
                초기화
              </dea-button>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>기간선택</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-date-picker-range
                v-model="filter.date"
                label="기간 선택"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
              ></dea-date-picker-range>
              <dea-button outlined>검색 기간 추가</dea-button>
              <dialog-select-day-time
                label="요일 시간 선택"
                v-model="filter.weekofdaytTime"
              ></dialog-select-day-time>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['date', 'weekofdaytTime'])"
              >
                초기화
              </dea-button>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>전체목록 (14)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex">
                <dea-button>파일저장</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
import DialogSelectDayTime from '../callHistory/Dialog/DialogSelectDayTime'

export default {
  name: 'IndexFailureFile',
  components: {
    DialogSelectDayTime
  },
  data() {
    return {
      gridInfo: {
        columns: []
      },
      selectLists: '전체',
      selectItems: ['전체'],
      filter: {
        date: [
          new Date().toISOString().substr(0, 10),
          new Date().toISOString().substr(0, 10)
        ],
        weekofdaytTime: []
      }
    }
  }
}
</script>
