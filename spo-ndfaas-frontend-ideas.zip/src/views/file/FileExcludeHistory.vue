<template>
  <v-container>
    <section class="dea-section">
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>검색어</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="selectLists"
                :items="selectItems"
                label="검색어 범위"
                style="width:200px;"
                class="flex-0"
              ></dea-select>
              <dea-text-field
                label="검색어"
                placeholder="파일명, 파일경로, 또는 본문 내용을 입력하여 검색하세요"
              ></dea-text-field>
            </v-col>
            <v-col class="d-flex" cols="3" />
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button prepend-icon="mdi-magnify" color="primary">
                  조회
                </dea-button>
                <dea-button outlined prepend-icon="mdi-restore">
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid use-pagination :columns="gridInfo.columns">
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs class="dea-tabs">
                  <v-tab>전체목록 (14)</v-tab>
                </v-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex">
                <dea-button>복원</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
export default {
  name: 'FileExcludeHistory',
  data() {
    return {
      gridInfo: {
        columns: []
      },
      selectLists: '전체',
      selectItems: ['전체']
    }
  }
}
</script>
