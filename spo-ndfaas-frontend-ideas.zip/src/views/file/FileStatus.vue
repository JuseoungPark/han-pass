<template>
  <v-container class="file-process-status">
    <section class="dea-section status-field">
      <div class="inner">
        <dea-card class="mx-auto" title-class="align-left">
          <template slot="title"
            >파일처리현황
            <v-layout class="v-toolbar valign-middle flex-0 ml-4">
              <div class="info-message">
                <strong>2020-10-12 19:03</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="loader = 'loading'"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-layout>
          </template>
          <v-card class="dea-card-field status-list-wrap">
            <v-card-actions>
              <div class="btn-group align-center">
                <v-tooltip top>
                  <template v-slot:activator="{ on, attrs }">
                    <div
                      class="text pl-4 pr-4 fontsize-big3"
                      v-bind="attrs"
                      v-on="on"
                    >
                      전체처리대상 <strong>0</strong>
                    </div>
                  </template>
                  <span>최근 1주일이내 처리된 디지털증거수</span>
                </v-tooltip>
                <v-divider vertical class="ma-0" />
                <div class="text pl-4 pr-4 fontsize-big3">
                  처리진행중 <strong>0</strong>
                </div>
                <v-divider vertical class="ma-0" />
                <div class="text pl-4 pr-4 fontsize-big3">
                  실사용자 <strong>0</strong>
                </div>
              </div>
            </v-card-actions>
            <v-card-text>
              <div class="status-list">
                <v-list v-model="callStatusList" class="d-flex flex-wrap">
                  <v-list-item
                    v-for="(callStatusItem, i) in callStatusItems"
                    :key="i"
                    style="max-width:20%; height:140px"
                    class="active"
                  >
                    <v-list-item-content>
                      <v-list-item-subtitle
                        :class="[callStatusItem.stateClass]"
                      >
                        <span>{{ callStatusItem.subtitle }}</span>
                      </v-list-item-subtitle>
                      <v-list-item-title class="mt-2">
                        {{ callStatusItem.title }}
                      </v-list-item-title>
                    </v-list-item-content>
                  </v-list-item>
                </v-list>
              </div>
            </v-card-text>
          </v-card>
          <template slot="actions">
            <v-row>
              <v-col cols="3">
                <dea-button large block>북마크내역</dea-button>
              </v-col>
              <v-col cols="9">
                <v-btn
                  large
                  block
                  color="primary"
                  @click="goLinkByName('RegisteredExtractionFile')"
                >
                  파일내역분석 자세히보기
                  <v-icon>mdi-plus</v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section quick-menu">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title">
            디지털증거 통합분석 <strong>Quick Menu</strong>
          </template>
          <v-row>
            <v-col cols="3">
              <dea-button
                block
                large
                color="primary"
                @click="goLinkByName('PersonManagementSub')"
              >
                <v-icon>mdi-account-alert</v-icon>
                주요인물관리
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button
                block
                large
                @click="goLinkByName('IntegratedCorrelationChart')"
              >
                <v-icon>mdi-account-multiple</v-icon>
                인물중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button
                block
                large
                @click="goLinkByName('TimeSeriesAnalysis')"
              >
                <v-icon>mdi-clock-time-three-outline</v-icon>
                시간중심분석
              </dea-button>
            </v-col>
            <v-col cols="3">
              <dea-button block large>
                <v-icon>mdi-map-marker-radius</v-icon>
                위치중심분석
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
  </v-container>
</template>

<script>
import routeMixin from '@/mixins/route'

export default {
  name: 'FileStatus',
  mixins: [routeMixin],
  data() {
    return {
      loader: null,
      loading: false,
      callStatusList: null,
      callStatusItems: [
        {
          title: '문서파일',
          subtitle: '0'
        },
        {
          title: '압축파일',
          subtitle: '0'
        },
        {
          title: '동영상파일',
          subtitle: '0'
        },
        {
          title: '음성파일',
          subtitle: '0'
        },
        {
          title: '사진/그림',
          subtitle: '0'
        },
        {
          title: '이메일',
          subtitle: '0'
        },
        {
          title: '암호파일',
          subtitle: '0'
        },
        {
          title: 'VIRUS파일',
          subtitle: '0'
        },
        {
          title: '색인실패파일',
          subtitle: '0'
        },
        {
          title: '기타',
          subtitle: '0'
        }
      ]
    }
  },
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
