import apiMixin from '@/mixins/apiMixin'
export default {
  mixins: [apiMixin],
  data() {
    return {
      gridSelected: [],
      sourceItems: [],
      source: ''
    }
  },
  methods: {
    errorMsg(error) {
      this.$toast.error(error)
      console.log(error)
    },
    async getOriginSeCode() {
      let originSeCode = await this.$originSeCode() //출처구분코드
      originSeCode = this.apiCodeValidate(originSeCode)
      if (originSeCode) {
        this.sourceItems = Object.keys(originSeCode).map((item) => {
          return { label: originSeCode[item], value: item }
        })
        this.source = this.sourceItems.map((item) => item.value)
      }
    },
    async getBootmarkFolderList() {
      let req = {
        url: `/bookmark/categories`,
        params: 'incdntId={0}'.format(this.incidentInfo.id)
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async getFolderDetail(idx) {
      let req = {
        url: `/bookmark/category`,
        params: 'incdntId={0}&bkmkClId={1}'.format(this.incidentInfo.id, idx)
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async addBootmarkFolder(params) {
      let req = {
        method: 'post',
        url: `/bookmark/category`,
        params: {
          incdntId: this.incidentInfo.id,
          hexColorCode: params.color,
          bkmkClNm: params.title
        }
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async editBookmarkFolder(params) {
      let req = {
        method: 'put',
        url: `/bookmark/category`,
        params: {
          incdntId: this.incidentInfo.id,
          bkmkClId: params.bkmkClId,
          hexColorCode: params.hexColorCode,
          bkmkClNm: params.bkmkClNm
        }
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async delBookmarkFolder(bkmkClId) {
      let req = {
        method: 'delete',
        url: `/bookmark/category`,
        params: {
          incdntId: this.incidentInfo.id,
          bkmkClId: bkmkClId
        }
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async getBookmarkDetail(bkmkId) {
      let req = {
        url: `/bookmark/bookmark`,
        params: 'incdntId={0}&bkmkId={1}'.format(this.incidentInfo.id, bkmkId)
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    async setImportant(params) {
      let req = {
        method: 'put',
        url: `/bookmark/bookmark`,
        params: [
          {
            incdntId: this.incidentInfo.id,
            bkmkId: params.data.bkmkId,
            imprtncYn: params.value === 'Y' ? 'N' : 'Y'
          }
        ]
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    // { incdntId:incdntId, bkmkId: bkmkId, bkmkClId: bkmkClId, bkmkClNm: bkmkClNm}
    async setItemBookmarkFolder(params) {
      let req = {
        method: 'put',
        url: `/bookmark/bookmark`,
        params: params
      }
      this.loading = this.$loading.show()
      let res = await this.$requestApi(req)
      res = this.apiCodeValidate(res)
      return res
    },
    /*{ memoArr: [ { no:no, memo:memo } ], updateUser: updateUser }*/
    async editBookmarkMemo(params) {
      return await this.$api.private
        .post(`/api/bookmark/update/memo`, params)
        .then((res) => {
          return res.data.result
        })
        .catch(function(error) {
          return { error: error }
        })
    },
    // 북마크해제
    async delBookmark() {
      let resData = this.$refs.grid.rowData
      if (this.$options.name === 'DialogBookmarkMgmt') {
        this.gridSelected = this.$refs.grid.getSelectedRows()
        resData = resData.filter((item) => {
          return !this.gridSelected.includes(item)
        })
      } else {
        this.gridSelected = this.$refs.grid.rowData
        resData = []
      }
      if (this.gridSelected.length > 0) {
        let res = await this.deleteBootmark()
        if (res) {
          this.$refs.grid.setRowData(resData)
          await this.$eventBus.$emit('refresh')
          await this.$toast(
            `총 ${this.gridSelected.length}개의 통화내역이 북마크에서 해제되었습니다.`
          )
          if (this.$refs.grid.rowData.length === 0) this.doCancel()
        }
      } else {
        this.$toast.error(`북마크에서 해제할 내역을 먼저 선택해주세요`)
      }
    },
    getEvidenceInfo(params) {
      let val = '-'
      //let source = this.sourceItems.map((item) => item.value)
      switch (params.data.bkmkOriginSeCode) {
        case 'TELNO':
          switch (params.field) {
            case 'trgPrsn':
              val = '발신자: 이름'
              break
            case 'trgDt':
              val = '통화시작: YYYY:MM:DD HH:MM:SS'
              break
            case 'trgCn':
              val = '수신자 : 이름 전화번호 (통화구분)'
              break
          }
          break
      }
      if (params.field === 'trgCn') {
        return `<div title="${val}">${val}</div>`
      } else {
        return val
      }
    }
  }
}
