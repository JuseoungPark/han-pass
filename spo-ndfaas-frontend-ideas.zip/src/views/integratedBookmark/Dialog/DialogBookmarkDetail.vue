<template>
  <!-- 북마크 내역 : Layer Popup -->
  <dea-dialog v-model="isShow" title="북마크 내역" width="1280px">
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <!-- :api="gridInfo.api" -->
                <dea-grid
                  ref="grid"
                  :columns="gridInfo.columns"
                  :config="gridInfo.config"
                  disable-auto-load
                >
                  <template #header-right>
                    <v-col class="d-flex align-right">
                      <dea-button @click="delBookmark">북마크해제</dea-button>
                    </v-col>
                  </template>
                </dea-grid>
              </dea-card>
            </div>
          </section>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <section class="dea-section">
            <div class="inner">
              <dea-card>
                <template slot="title">변경이력</template>
                <dea-grid
                  ref="modHistory"
                  :api="modHistory.api"
                  :columns="modHistory.columns"
                  :config="modHistory.config"
                  :etc-options="modHistory.options"
                >
                </dea-grid>
              </dea-card>
            </div>
          </section>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="doCancel">취소</dea-button>
        <dea-button color="primary" @click="doOK">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
  <!-- //북마크 내역 : Layer Popup -->
</template>

<script>
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import { GridFormatter } from '@/utils/GridFormatter'
import handler from '../Mixins/handler'
import GridCommMixins from '@/mixins/callHistory/GridComm'

export default {
  name: 'DialogBookmarkDetail',
  mixins: [handler, GridCommMixins],
  props: {
    value: {
      type: Boolean,
      default: false
    },
    selected: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      isShow: false,
      gridInfo: {
        api: '/bookmark/bookmark',
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 1
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: '발신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'dsptchUserNm'
              },
              {
                headerName: '전화번호',
                field: 'dsptchTelno'
              }
            ]
          },
          {
            headerName: '착신자',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '실사용자',
                field: 'rcvUserNm'
              },
              {
                headerName: '전화번호',
                field: 'rcvTelno'
              }
            ]
          },
          {
            headerName: '통화정보',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '통화시작',
                field: 'talkBgngDt'
              },
              {
                headerName: '통화시간',
                field: 'talkQy',
                valueFormatter: GridFormatter.timeWithColons,
                width: 80,
                cellClass: 'align-right'
              },
              {
                headerName: '구분',
                field: 'talkTyNm'
              },
              {
                headerName: '기지국',
                field: 'linkRelateAdres',
                tooltipField: 'linkRelateAdres'
              }
            ]
          }
        ]
      },
      modHistory: {
        api: '',
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        options: {
          overlayNoRowsTemplate:
            '<span class="ag-overlay-loading-center">변경이력이 없습니다.</span>'
        },
        columns: [
          {
            headerName: 'No',
            field: 'RowNum',
            cellClass: 'align-right'
          },
          {
            headerName: '폴더명',
            field: 'title',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '중요체크',
            field: 'important',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '변경일',
            field: 'modDate',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '메모',
            field: 'content',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록자',
            field: 'regUser',
            sortable: true,
            unSortIcon: true
          }
        ]
      }
    }
  },
  watch: {
    value(flag) {
      this.isShow = flag
    },
    async isShow(flag) {
      if (flag) {
        let bkmkId = this.selected[0].bkmkId
        let res = await this.getBookmarkDetail(bkmkId)
        if (res) {
          this.$nextTick(() => {
            let data = [
              {
                ...res.data.result.talkUnityDtlsResVo,
                bkmkId: bkmkId
              }
            ]
            this.$refs.grid.setRowData(data)
          })
        }
      } else {
        this.$refs.grid.dataReset()
      }
      this.$emit('input', flag)
    }
  },
  methods: {
    doOK() {
      this.doCancel()
    },
    doCancel() {
      this.isShow = false
    }
  },
  created() {
    this.isShow = this.value
  },
  mounted() {}
}
</script>
