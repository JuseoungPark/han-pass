<template>
  <!-- 북마크관리 : Layer Popup -->
  <dea-dialog v-model="isShow" title="북마크관리" width="1280px">
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <section class="dea-section">
            <div class="inner">
              <dea-card title-class="title-align">
                <template slot="title">내역정보</template>
                <dea-grid
                  ref="grid"
                  :columns="gridInfo.columns"
                  :config="gridInfo.config"
                  :etcOptions="gridInfo.options"
                  row-selection-multiple
                  suppress-row-click-selection
                  @onRowsTextChange="gridInfo.onRowsTextChange"
                >
                  <template #header-right>
                    <v-col class="d-flex align-right">
                      <dea-button @click="delBookmark">북마크해제</dea-button>
                    </v-col>
                  </template>
                </dea-grid>
              </dea-card>
            </div>
          </section>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner detail-view">
        <dea-card>
          <template slot="title">폴더설정</template>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>폴더명</dea-label>
            </v-col>
            <v-col class="d-flex">
              <div
                v-if="folderSelected.bkmkClNm"
                class="align-self-center mr-5"
              >
                <div
                  style="display:inline-block;width:11px; height:11px;"
                  class="dea-color-picker"
                  :style="{ backgroundColor: folderSelected.hexColorCode }"
                ></div>
                {{ folderSelected.bkmkClNm }}
              </div>

              <v-menu close-on-click close-on-content-click offset-y>
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on">폴더변경</v-btn>
                </template>
                <!-- Context Menu : Layer Popup -->
                <v-sheet class="dea-popup" style="width:180px;">
                  <v-container class="pa-0">
                    <section class="dea-section">
                      <div class="inner">
                        <v-list dense>
                          <v-list-item-group v-model="folderIdx">
                            <v-list-item v-if="folderItems.length === 0">
                              <v-list-item-content>
                                <v-list-item-title>
                                  폴더가 없습니다. <br />
                                  북마크폴더를 생성하세요.
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-list-item
                              v-for="(item, i) in folderItems"
                              :key="i"
                              @click="getSelectedFolder(item)"
                            >
                              <v-list-item-content>
                                <v-list-item-title>
                                  <div
                                    style="display:inline-block;width:10px; height:10px;"
                                    class="dea-color-picker"
                                    :style="{
                                      backgroundColor: item.hexColorCode
                                    }"
                                  ></div>
                                  {{ item.bkmkClNm }} ({{ item.bkmkRows }})
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                          </v-list-item-group>
                        </v-list>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //Context Menu : Layer Popup -->
              </v-menu>
              <dea-button @click="newFolderCollapsible = !newFolderCollapsible"
                >새로운 폴더</dea-button
              >
            </v-col>
          </v-row>
          <v-row no-gutters v-show="newFolderCollapsible">
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>새로운 폴더명</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-text-field
                    v-model="newFolder.title"
                    placeholder="제목을 입력하세요"
                  ></dea-text-field>
                  <dea-color-picker
                    v-model="newFolder.color"
                  ></dea-color-picker>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>등록</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">{{ userInfo.userName }} {{ now }}</div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>비고</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <dea-text-field
                    v-model="newFolder.content"
                    placeholder="비고"
                  ></dea-text-field>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col class="d-flex align-right">
                  <dea-button outlined @click="doNewFolderCancel"
                    >취소</dea-button
                  >
                  <dea-button color="primary" @click="doNewFolder"
                    >등록</dea-button
                  >
                </v-col>
              </v-row>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="doCancel">취소</dea-button>
        <dea-button color="primary" @click="doOK">저장</dea-button>
      </v-col>
    </div>
  </dea-dialog>
  <!-- //북마크관리 : Layer Popup -->
</template>

<script>
import { mapGetters } from 'vuex'
// import { GridFormatter } from '@/utils/GridFormatter'
import CellIcon from '@/components/grid/CellIcon'
import CellFullWidthText from '@/components/grid/CellFullWidthText'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import handler from '../Mixins/handler'
import GridCommMixins from '@/mixins/callHistory/GridComm'
// import { StringUtils } from '@/utils/StringUtils'

export default {
  name: 'DialogBookmarkMgmt',
  mixins: [handler, GridCommMixins],
  props: {
    value: {
      type: Boolean,
      default: false
    },
    selected: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      //userName: '김수사관',
      isShow: false,
      pickerColor: '#1976d2ff',
      newFolderCollapsible: false,
      folderIdx: null,
      folderSelected: {},
      folderItems: [],
      newFolder: {
        bookmarkLevel: 1,
        color: '#1976d2ff',
        title: '',
        content: '',
        regUser: '',
        count: 0
      },
      inputMemoData: [],
      gridInfo: {
        api: '',
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 6
          },
          height: 'fixed'
        },
        options: {
          fullWidthCellRendererFramework: CellFullWidthText,
          isFullWidthCell: (rowNode) => {
            return rowNode.data.isFullWidth
          },
          onCellValueChanged: async (rowNode) => {
            let params = {
              no: rowNode.data.no,
              memo: rowNode.data.memo,
              updateUser: this.userInfo.userName
            }
            let result = await this.editBookmarkMemo(params)
            if (result === 1) {
              this.$toast(`수정되었습니다.`)
              this.$eventBus.$emit('refresh')
            } else {
              if (result.error) {
                console.log(result.error)
                this.$toast(`${result.error}`)
                return
              }
              this.$toast(`실패하였습니다.`)
            }
            console.log(rowNode.data.memo)
          }
        },

        onRowsTextChange: async (rowNode, value) => {
          let params = {
            no: rowNode.data.no,
            memo: value,
            updateUser: this.userInfo.userName
          }
          let result = await this.editBookmarkMemo(params)
          if (result === 1) {
            this.$toast(`수정되었습니다.`)
            this.$eventBus.$emit('refresh')
          } else {
            if (result.error) {
              console.log(result.error)
              this.$toast(`${result.error}`)
              return
            }
            this.$toast(`실패하였습니다.`)
          }
          /*let objIndex = this.inputMemoData.findIndex(
            (item) => item.no == rowNode.data.no
          )
          this.inputMemoData[objIndex].memo = value
          */
        },
        columns: [
          {
            headerName: '열 선택',
            field: 'rowSelector',
            width: 20,
            headerComponentFramework: CellCheckboxHeader,
            cellRendererFramework: CellCheckbox
          },
          {
            headerName: '출처',
            field: 'bkmkOriginSeCode',
            sortable: true,
            unSortIcon: true,
            width: 60,
            cellClass: 'align-center',
            valueGetter: (params) => {
              let source = this.sourceItems.find((item) => {
                return item.value === params.data.bkmkOriginSeCode
              })
              if (source) {
                return source.label
              } else {
                return '-'
              }
            }
          },
          {
            headerName: '중요',
            field: 'imprtncYn',
            sortable: true,
            unSortIcon: true,
            width: 50,
            cellRendererFramework: CellIcon,
            cellRendererParams: (params) => {
              return {
                icon:
                  params.value === 'Y'
                    ? 'mdi-flag-variant'
                    : 'mdi-flag-variant-outline',
                color: params.value === 'Y' ? 'red' : 'grey'
              }
            }
          },
          /*{
            headerName: '폴더',
            field: 'color',
            sortable: true,
            unSortIcon: true,
            width: 70,
            cellRendererFramework: CellIcon,
            cellRendererParams: (params) => {
              return {
                icon: params.value ? 'mdi-folder' : '',
                text: params.value ? '' : '미분류',
                color: params.value
              }
            }
          },
          {
            headerName: '제목',
            field: 'title',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens
          },*/
          {
            headerName: '인물',
            field: 'person',
            sortable: true,
            unSortIcon: true,
            cellRenderer: this.getEvidenceInfo,
            cellRendererParams: {
              field: 'person'
            }
          },
          {
            headerName: '일시',
            field: 'dateTime',
            sortable: true,
            unSortIcon: true,
            cellRenderer: this.getEvidenceInfo,
            cellRendererParams: {
              field: 'dateTime'
            }
          },
          {
            headerName: '내용',
            field: 'contents',
            sortable: true,
            unSortIcon: true,
            cellRenderer: this.getEvidenceInfo,
            cellRendererParams: {
              field: 'contents'
            }
          },
          {
            headerName: '메모',
            field: 'memo',
            sortable: true,
            unSortIcon: true,
            width: 150,
            editable: true,
            singleClickEdit: true
          }
        ]
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    now() {
      return this.$moment().format('YYYY-MM-DD HH:mm:ss')
    }
  },
  watch: {
    value(flag) {
      this.isShow = flag
    },
    async isShow(flag) {
      if (flag) {
        this.getOriginSeCode()
        this.getFolderList()
        this.inputMemoData = this.selected.map(function(item) {
          return { no: item.no, memo: item.memo }
        })
        let evenAddData = []
        this.selected.forEach((item) => {
          let i = 0
          while (i < 2) {
            if (i === 0) {
              item.isFullWidth = 0
              evenAddData.push(item)
            } else {
              evenAddData.push({ no: item.no, memo: item.memo, isFullWidth: 1 })
            }
            i++
          }
        })
        // console.log(evenAddData)
        this.$nextTick(() => {
          //this.$refs.grid.setRowData(evenAddData)
          this.$refs.grid.setRowData(this.selected)
        })
      } else {
        this.folderSelected = {}
      }
      this.$emit('input', flag)
    }
  },
  methods: {
    getSelectedFolder(item) {
      this.folderSelected = item
      this.doNewFolderCancel()
    },
    setComparator(type) {
      console.log('setComparator', type)
    },
    async doNewFolder() {
      this.newFolder.regUser = this.userInfo.userName
      let res = await this.addBootmarkFolder(this.newFolder)
      // console.log(result, StringUtils.isEmptyObject(result))
      if (res) {
        this.getFolderList()
        this.folderSelected = res.data.result
        this.doNewFolderCancel()
      }
    },
    async getFolderList() {
      let res = await this.getBootmarkFolderList()
      if (res) {
        this.loading.hide()
        this.folderItems = res.data.result.filter((item) => {
          return item.bkmkClId !== 0
        })
      }
    },
    doNewFolderCancel() {
      this.newFolder = {}
      this.newFolderCollapsible = false
    },
    doOK() {
      this.inputMemoData = this.inputMemoData.filter((item, index) => {
        return item.memo !== this.selected[index].memo
      })
      this.$emit('doOK', this.folderSelected)
    },
    doCancel() {
      this.isShow = false
    }
  },
  created() {
    this.isShow = this.value
  }
}
</script>
