<template>
  <fragment>
    <!-- search-box -->
    <section
      class="dea-section"
      v-if="this.$route.name === 'IntegratedBookmark'"
    >
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>출처</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                v-model="allSelSource"
                @change="selAllSource"
                :indeterminate="
                  source.length > 0 && source.length !== sourceItems.length
                "
              ></dea-checkbox>
              <dea-checkbox
                v-for="(item, index) in sourceItems"
                v-model="source"
                :label="item.label"
                :cvalue="item.value"
                :key="index"
                @change="selSource"
              ></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>검색</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                style="width:200px;"
                class="flex-0"
                label="검색범위"
                :items="selectItems"
                v-model="filter.searchType"
              ></dea-select>
              <dea-text-field
                label="검색어를 입력하세요"
                v-model="filter.searchTxt"
              ></dea-text-field>
              <dea-button
                icon
                textindent
                prepend-icon="mdi-restore"
                @click="resetFilterEach(['searchType', 'searchTxt'])"
              >
                초기화
              </dea-button>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  prepend-icon="mdi-magnify"
                  color="primary"
                  title="조회"
                  @click="onSearch"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  prepend-icon="mdi-restore"
                  title="초기화"
                  @click="resetFilter"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>
    <!-- search-box // -->
    <section
      class="dea-section"
      v-if="$route.name === 'IntegratedBookmarkDetail' && folder.bkmkClId"
    >
      <div class="inner detail-view">
        <dea-card>
          <v-row no-gutters v-if="isModify">
            <v-col cols="1">
              <dea-label>제목</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field v-model="folder.bkmkClNm"></dea-text-field>
            </v-col>
            <v-col class="d-flex flex-0 align-right">
              <dea-color-picker
                v-model="folder.hexColorCode"
              ></dea-color-picker>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>등록자</dea-label>
            </v-col>
            <v-col class="d-flex" cols="2">
              <dea-text-field
                v-model="folder.firstRegUserNm"
                v-if="isModify"
              ></dea-text-field>
              <div class="text" v-else>{{ folder.firstRegUserNm }}</div>
            </v-col>
            <v-col cols="1">
              <dea-label>등록일</dea-label>
            </v-col>
            <v-col class="d-flex">
              <!-- <dea-date-picker
                v-model="folder.firstRegDt"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                min-width="290px"
                v-if="isModify"
              ></dea-date-picker>
              <div class="text" v-else>{{ folder.firstRegDt }}</div> -->
              <div class="text">{{ folder.firstRegDt }}</div>
            </v-col>
            <v-col class="d-flex flex-0 align-right" v-if="!isModify">
              <div class="dea-color-picker" :style="swatchStyle" />
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-textarea
                v-model="folder.content"
                placeholder="내용을 입력하세요"
                v-if="isModify"
              ></dea-textarea>
              <div class="text" v-else>{{ folder.content }}</div>
            </v-col>
            <v-col class="d-flex flex-0 align-right" v-if="!isModify">
              <dea-button
                icon
                prepend-icon="mdi-playlist-edit"
                @click="goEdit"
              ></dea-button>
            </v-col>
          </v-row>
          <v-row no-gutters v-if="isModify">
            <v-col class="d-flex align-right">
              <dea-button outlined @click="doEditCancel">취소</dea-button>
              <dea-button color="primary" @click="doEdit">수정</dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <!-- 북마크 목록 -->
    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid
            ref="grid"
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :return-value.sync="gridInfo.totalCount"
            row-selection-multiple
            suppress-row-click-selection
            use-pagination
            @ready="onReady"
            disableAutoLoad
          >
            <!-- disableAutoLoad -->
            <template #header-left>
              <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <!-- <dea-button>보고서생성</dea-button> -->
                <dea-button
                  @click="goBookmarkMgmt"
                  v-if="
                    $route.name === 'IntegratedBookmark' ||
                      $route.params.idx === 'unfolder'
                  "
                  >북마크관리</dea-button
                >
                <dea-button v-else @click="goDelItemFolder">제외</dea-button>
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <!-- 북마크 목록 //-->
    <!-- 북마크관리 팝업 -->
    <dialog-bookmark-mgmt
      v-model="bookmarkMgmt.show"
      :selected="gridSelected"
      @doOK="ModFolder"
    ></dialog-bookmark-mgmt>
    <!-- 북마크관리 팝업 // -->
    <!-- 북마크상세 팝업 -->
    <dialog-bookmark-detail
      v-model="bookmarkDetail.show"
      :selected="gridSelected"
    ></dialog-bookmark-detail>
    <!-- 북마크상세 팝업 // -->
  </fragment>
</template>

<script>
import { mapGetters } from 'vuex'
import listTemplate from '@/mixins/listTemplate'
import routeMixin from '@/mixins/route'
import { NumberUtils } from '@/utils/NumberUtils'
import { StringUtils } from '@/utils/StringUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import { CustomHeaderGroup } from '@/utils/customHeaderGroup'
import CellIcon from '@/components/grid/CellIcon'
import CellButton from '@/components/grid/CellButton'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import DialogBookmarkMgmt from '../Dialog/DialogBookmarkMgmt'
import DialogBookmarkDetail from '../Dialog/DialogBookmarkDetail'
import handler from '../Mixins/handler'
import eventBus from '@/mixins/eventBus'

export default {
  name: 'IntegratedBookmarkList',
  mixins: [listTemplate, routeMixin, handler, eventBus],
  components: {
    DialogBookmarkMgmt,
    DialogBookmarkDetail
  },
  data() {
    return {
      idx: null,
      eventBusName: null,
      exeInt: 0,
      initFolder: {},
      folder: {
        bkmkClId: null,
        hexColorCode: '#1976d2ff',
        bkmkClNm: '제목없음',
        content: ''
      },
      isModify: false,
      tabSelected: 0,
      tabName: '북마크 목록',
      filter: {
        source: [],
        searchType: 'all',
        searchTxt: ''
      },
      allSelSource: true,
      source: [],
      sourceItems: [],
      selectItems: [
        { text: '전체', value: 'all' },
        { text: '미분류', value: '0' },
        { text: '중요파일', value: 'Y' }
      ],
      bookmarkMgmt: {
        show: false
      },
      bookmarkDetail: {
        show: false
      },
      gridInfo: {
        api: '/bookmark/bookmarks',
        columns: [
          {
            headerName: '',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '열 선택',
                field: 'rowSelector',
                width: 20,
                headerComponentFramework: CellCheckboxHeader,
                cellRendererFramework: CellCheckbox
              },
              {
                headerName: 'No',
                field: 'no',
                width: 50,
                cellClass: 'align-right'
              }
            ]
          },
          {
            headerName: '북마크',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '출처',
                field: 'bkmkOriginSeCode',
                sortable: true,
                unSortIcon: true,
                width: 60,
                cellClass: 'align-center',
                valueGetter: (params) => {
                  let source = this.sourceItems.find((item) => {
                    return item.value === params.data.bkmkOriginSeCode
                  })
                  if (source) {
                    return source.label
                  } else {
                    return '-'
                  }
                }
              },
              {
                headerName: '중요',
                field: 'imprtncYn',
                sortable: true,
                unSortIcon: true,
                width: 60,
                cellClass: 'align-center',
                cellRendererFramework: CellIcon,
                cellRendererParams: (params) => {
                  return {
                    icon:
                      params.value === 'Y'
                        ? 'mdi-flag-variant'
                        : 'mdi-flag-variant-outline',
                    color: params.value === 'Y' ? 'red' : 'grey',
                    click: async (params) => {
                      let result = await this.setImportant(params)
                      if (result) {
                        this.loading.hide()
                        if (params.value === 'Y') {
                          this.$toast(`중요파일에서 제외 되었습니다.`)
                        } else {
                          this.$toast(`중요파일에 등록 되었습니다.`)
                        }
                      }
                      this.$eventBus.$emit('refresh')
                    }
                  }
                }
              },
              {
                headerName: '폴더',
                field: 'hexColorCode',
                sortable: true,
                unSortIcon: true,
                width: 70,
                cellClass: 'align-center',
                cellRenderer: (params) => {
                  if (params.value) {
                    return `<div class="dea-color-picker" style="width:25px; height:25px;background:${params.value};"></div>`
                  } else {
                    return '미분류'
                  }
                }
              },
              /*{
                headerName: '폴더',
                field: 'color',
                sortable: true,
                unSortIcon: true,
                width: 70,
                cellRendererFramework: CellIcon,
                cellRendererParams: (params) => {
                  return {
                    icon: params.value ? 'mdi-folder' : '',
                    text: params.value ? '' : '미분류',
                    color: params.value
                  }
                }
              },*/
              {
                headerName: '제목',
                field: 'bkmkClNm',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.emptyWithHyphens
              },
              {
                headerName: '메모',
                field: 'bkmkSjNm',
                sortable: true,
                unSortIcon: true,
                valueFormatter: GridFormatter.emptyWithHyphens
              },
              {
                headerName: '등록일',
                field: 'firstRegDt',
                sortable: true,
                unSortIcon: true,
                cellClass: 'align-center'
              },
              {
                headerName: '등록자',
                field: 'firstRegUserNm',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '증거',
            headerGroupComponent: CustomHeaderGroup,
            children: [
              {
                headerName: '인물',
                field: 'trgPrsn',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '일시',
                field: 'trgDt',
                sortable: true,
                unSortIcon: true
              },
              {
                headerName: '내용',
                field: 'trgCn',
                sortable: true,
                unSortIcon: true
              }
            ]
          },
          {
            headerName: '기능',
            width: 110,
            cellRendererFramework: CellButton,
            cellRendererParams: (params) => {
              return {
                btnList: [
                  {
                    label: '보기',
                    click: () => {
                      this.bookmarkDetail.show = true
                      this.gridSelected = [params.data]
                    }
                  },
                  {
                    label: '저장',
                    click: () => {
                      console.log('저장', params)
                    }
                  }
                ]
              }
            }
          }
        ],
        totalCount: 0
      },
      rowData: []
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    getParams() {
      if (this.$route.name === 'IntegratedBookmark') {
        return {
          bkmkOriginSeCodeList: this.filter.source,
          bkmkClId:
            this.filter.searchType === '0' ? this.filter.searchType : '',
          imprtncYn:
            this.filter.searchType === 'Y' ? this.filter.searchType : '',
          keyword: this.filter.searchTxt ? this.filter.searchTxt : ''
        }
      } else {
        return {}
      }
    },
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.gridInfo.totalCount
          )})`
        }
      ]
    },
    swatchStyle() {
      return {
        backgroundColor: this.folder.hexColorCode,
        height: '32px',
        width: '32px'
      }
    }
  },

  methods: {
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    filterSearch() {
      let srchRes = []
      if (this.filter.source.length > 0) {
        srchRes = this.rowData.filter((item) => {
          return this.filter.source.includes(item.source)
        })
      } else {
        srchRes = [...this.rowData]
      }
      this.$refs.grid.reset()
      this.$refs.grid.setRowData(srchRes)
    },
    selSource(value) {
      if (value.length > 0) {
        this.allSelSource = false
        this.filter.source = value
        if (value.length === this.sourceItems.length) {
          this.allSelSource = true
          this.filter.source = []
        }
      } else {
        this.allSelSource = true
      }
    },
    selAllSource(flag) {
      if (flag) {
        this.source = this.sourceItems.map((item) => item.value)
        this.filter.source = []
      } else {
        this.source = []
      }
    },
    goBookmarkMgmt() {
      this.gridSelected = this.$refs.grid.getSelectedRows()
      if (this.gridSelected.length > 0) {
        this.bookmarkMgmt.isDetail = false
        this.bookmarkMgmt.show = true
      } else {
        this.$toast.error(`북마크 관리할 내역을 선택해주세요`)
      }
    },
    async goDelItemFolder() {
      this.gridSelected = this.$refs.grid.getSelectedRows()
      if (this.gridSelected.length > 0) {
        let selected = this.gridSelected.map((item) => {
          return {
            incdntId: item.incdntId,
            bkmkId: item.bkmkId,
            bkmkClId: 0,
            bkmkClNm: ''
          }
        })
        let res = await this.setItemBookmarkFolder(selected)
        if (res) {
          this.$toast(`북마크폴더에서 제외되었습니다.`)
          this.$eventBus.$emit('refresh')
        }
      } else {
        this.$toast.error(`북마크폴더에서 제외할 내역을 선택해주세요`)
      }
    },
    folderDelComponent() {
      this.$emit('folderDelComponent', {
        name: this.$route.name,
        component: {
          name: 'SlotContent',
          template: `
    <v-row no-gutters class="ml-4">
      <v-col>
        <dea-button outlined @click="child.doFolderDel">삭제</dea-button>
      </v-col>
    </v-row>
    `,
          props: {
            child: {}
          }
        },
        child: this
      })
    },
    folderDelComponentDelete() {
      this.$emit('folderDelComponentDelete', this.$route.name)
    },
    async doFolderDel() {
      await this.$confirm('폴더를 삭제하시겠습니까?').then(async (confirm) => {
        if (confirm) {
          let res = await this.delBookmarkFolder(this.folder.bkmkClId)
          if (res) {
            if (res.data.code === '200') {
              this.$toast(`폴더가 삭제되었습니다.`)
              this.$router.push('/integratedBookmark')
            }
          }
        }
      })
    },
    async ModFolder(folderSelected) {
      // console.log(this.gridSelected, folderSelected)
      if (StringUtils.isEmptyObject(folderSelected)) {
        this.bookmarkMgmt.show = false
        return
      }

      let selected = this.gridSelected.map((item) => {
        return {
          incdntId: item.incdntId,
          bkmkId: item.bkmkId,
          bkmkClId: folderSelected.bkmkClId,
          bkmkClNm: folderSelected.bkmkClNm
        }
      })
      let result = await this.setItemBookmarkFolder(selected)
      if (result) this.$eventBus.$emit('refresh')
      this.bookmarkMgmt.show = false
    },
    goEdit() {
      this.isModify = true
    },
    async doEdit() {
      // console.log(this.folder)
      let res = await this.editBookmarkFolder(this.folder)
      if (res) {
        if (res.data.code === '200') {
          this.$route.meta.title = this.folder.bkmkClNm
          this.$parent.$parent.$parent.updateBreadItems()
          this.$refs.grid.reset()
          this.loadData()
          this.$toast(`수정되었습니다.`)
          this.isModify = false
        }
      }
    },
    async doEditCancel() {
      this.isModify = false
      this.folder = { ...this.initFolder }
      this.folder.bkmkClId = this.idx
      let res = await this.getFolderDetail(this.folder.bkmkClId)
      if (res) {
        this.loading.hide()
        this.folder = res.data.result
      }
    },
    eventBusInit(eventBusName) {
      this.eventBusName = eventBusName
    },
    async _setInitFilter() {
      this.initFolder = { ...this.folder }
      this.filter = { ...this.initFilter }
      this.folder = { ...this.initFolder }
      this.idx = this.$route.params.idx
      if (this.idx !== undefined) {
        this.filter = {}
        if (this.idx === 'unfolder') {
          this.filter.bkmkClId = 0
        } else if (this.idx === 'important') {
          this.filter.imprtncYn = 'Y'
        } else {
          this.filter.bkmkClId = this.idx
        }
      }
    },
    async setBreadcrumbs() {
      if (this.idx !== undefined) {
        if (this.idx === 'unfolder') {
          this.$route.meta.title = '미분류'
        } else if (this.idx === 'important') {
          this.$route.meta.title = '중요파일'
        } else {
          if (this.idx !== null) {
            let res = await this.getFolderDetail(this.idx)
            if (res) {
              this.loading.hide()
              this.folder = res.data.result
            }
            this.$route.meta.title = StringUtils.isEmptyObject(this.folder)
              ? '제목없음'
              : this.folder.bkmkClNm
          }
        }
        // console.log('================= mounted folder', this.folder.title)
        this.$parent.$parent.$parent.updateBreadItems()
      }
    },
    onReady() {
      this.updateFilter()
      this.loadData()
    },
    async init() {
      await this.setBreadcrumbs()
      if (this.idx) {
        if (isNaN(this.idx)) {
          this.folderDelComponentDelete()
        } else {
          this.folderDelComponent()
        }
      }
    }
  },
  watch: {
    $route(to, from) {
      if (this.$options.name === 'IntegratedBookmarkList') {
        if (
          to.name === 'IntegratedBookmarkDetail' &&
          from.name === 'IntegratedBookmark' &&
          this.idx === this.eventBusName
        ) {
          this.filter = {}
          if (isNaN(this.idx)) {
            this.folderDelComponentDelete()
          } else {
            this.folderDelComponent()
          }
          if (this.idx === 'unfolder') {
            this.filter.bkmkClId = 0
            this.$route.meta.title = '미분류'
          } else if (this.idx === 'important') {
            this.filter.imprtncYn = 'Y'
            this.$route.meta.title = '중요파일'
          } else {
            this.filter.bkmkClId = this.idx
            this.$route.meta.title = this.folder.title
          }
          this.$parent.$parent.$parent.updateBreadItems()
          this.$refs.grid.reset()
          this.loadData()
        }
      }
    }
  },
  async created() {
    this.getOriginSeCode()
    this._setInitFilter()
  },
  async mounted() {
    await this.init()
  }
}
</script>
