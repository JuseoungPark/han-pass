<template>
  <fragment>
    <!-- 북마크 폴더 -->
    <section class="dea-section total-bookmark-folder">
      <div class="inner list-wrap">
        <v-row no-gutters class="list-top">
          <v-col class="d-flex">
            <v-tabs class="dea-tabs">
              <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
            </v-tabs>
          </v-col>
          <!-- <v-col class="d-flex align-right">
            <dea-button>보고서생성</dea-button>
          </v-col> -->
        </v-row>
        <div class="divide">
          <v-col cols="2">
            <v-list dense>
              <v-list-item-group v-model="folderSelectedEtc">
                <v-list-item
                  v-for="(item, index) in folderItemsEtc"
                  :key="index"
                  :color="item.bkmkClNm === '중요파일' ? 'primary' : ''"
                  @click="
                    goDetail(
                      item.bkmkClNm === '중요파일' ? 'important' : 'unfolder'
                    )
                  "
                >
                  <v-list-item-content>
                    <v-list-item-icon
                      class="align-center"
                      v-if="item.bkmkClNm === '중요파일'"
                    >
                      <v-icon>mdi-flag-variant</v-icon>
                    </v-list-item-icon>
                    <v-list-item-title class="align-center">{{
                      item.bkmkClNm
                    }}</v-list-item-title>
                    <v-list-item-subtitle class="align-center"
                      >{{ item.bkmkRows }}개의 파일</v-list-item-subtitle
                    >
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-col>
          <v-col>
            <v-list dense>
              <v-list-item-group
                v-model="folderSelected"
                class="flex-row flex-wrap"
              >
                <v-list-item
                  v-for="(item, index) in folderItems"
                  :key="index"
                  @click="goDetail(item.bkmkClId)"
                >
                  <v-list-item-content>
                    <v-list-item-icon>
                      <v-icon
                        :color="item.hexColorCode"
                        class="mdi mdi-label"
                      ></v-icon>
                    </v-list-item-icon>
                    <v-list-item-title class="align-center">
                      {{ item.bkmkClNm }}
                    </v-list-item-title>
                    <v-list-item-subtitle class="align-center">
                      {{ item.bkmkRows }}개 파일
                    </v-list-item-subtitle>
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-col>
        </div>
      </div>
    </section>
    <!-- 북마크 폴더 // -->
  </fragment>
</template>

<script>
import { NumberUtils } from '@/utils/NumberUtils'
import handler from '../Mixins/handler'
export default {
  name: 'IntegratedBookmarkFolder',
  mixins: [handler],
  data() {
    return {
      tabSelected: 0,
      tabName: '북마크 폴더',
      unfolderCount: 0,
      importantCount: 0,
      folderTotalCount: 0,
      folderSelected: null,
      folderItems: [],
      folderSelectedEtc: null,
      folderItemsEtc: []
    }
  },
  computed: {
    tabItems() {
      return [
        {
          name: `${this.tabName} (${NumberUtils.numberWithCommas(
            this.folderTotalCount
          )})`
        }
      ]
    },
    getParams() {
      return {
        incdntId: this.incidentInfo.id
      }
    }
  },
  watch: {
    $route(to, from) {
      if (this.$options.name === 'IntegratedBookmarkFolder') {
        if (
          to.name === 'IntegratedBookmark' &&
          from.name === 'IntegratedBookmarkDetail'
        ) {
          // console.log(to.name, from.name, this.$options.name)
          this.init()
        }
      }
    }
  },
  methods: {
    async init() {
      // console.log('============ folderList')
      this.folderSelected = null
      this.folderSelectedEtc = null
      let res = await this.getBootmarkFolderList()
      if (res) {
        this.loading.hide()
        // console.log(res.data.result.filter((item)=>item.bkmkClId !== 0))
        this.folderItemsEtc = res.data.result.filter(
          (item) => item.bkmkClId === 0
        )
        this.folderItems = res.data.result.filter((item) => item.bkmkClId !== 0)
        /*this.folderItems = res.data.rows
        this.folderTotalCount = res.data.total
        this.unfolderCount = res.data.unfolder
        this.importantCount = res.data.important*/
      }
    },
    async goDetail(idx) {
      await this.$eventBus.$emit('eventBusInit', `${idx}`)
      this.$router.push(`/integratedBookmark/${idx}`)
    }
  },
  mounted() {
    this.init()
  }
}
</script>
