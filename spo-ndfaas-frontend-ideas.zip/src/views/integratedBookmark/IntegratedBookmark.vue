<template>
  <v-container>
    <bookmark-list
      v-if="listTypeSelected === 'list'"
      @folderDelComponent="folderDelComponent"
      @folderDelComponentDelete="folderDelComponentDelete"
    ></bookmark-list>
    <bookmark-folder v-else></bookmark-folder>
  </v-container>
</template>

<script>
import BookmarkFolder from './Include/IntegratedBookmarkFolder'
import BookmarkList from './Include/IntegratedBookmarkList'
export default {
  name: 'IntegratedBookmark',
  components: {
    BookmarkFolder,
    BookmarkList
  },
  data() {
    return {
      listTypeSelected: 'list',
      listTypeItems: [
        {
          label: '목록형',
          value: 'list'
        },
        {
          label: '분류형',
          value: 'folder'
        }
      ],
      prevRoute: null,
      slotContents: []
    }
  },
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      if (
        to.name === 'IntegratedBookmark' &&
        from.name === 'CallHistoryAnalysisBookmark'
      )
        vm.listTypeSelected = 'list'
    })
  },
  destroyed() {
    this.$emit('slot-content:delete', this.$route.name)
  },
  methods: {
    listTypeComponent() {
      this.$emit('slot-content:add', {
        name: this.$route.name,
        component: {
          name: 'SlotContent',
          template: `
    <v-row no-gutters class="ml-4">
      <v-col>
        <dea-radio-group
          class="dea-btn-radio"
          v-model="child.listTypeSelected"
          row
          :mandatory="false"
          :items="child.listTypeItems"
        ></dea-radio-group>
      </v-col>
    </v-row>
    `,
          props: {
            child: {}
          }
        },
        child: this
      })
    },
    folderDelComponent(slot) {
      this.$emit('slot-content:add', slot)
    },
    folderDelComponentDelete(name) {
      this.$emit('slot-content:delete', name)
    }
  },
  created() {
    if (this.$route.name === 'IntegratedBookmark') this.listTypeComponent()
  }
}
</script>
