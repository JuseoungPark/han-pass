<template>
  <v-row no-gutters>
    <v-col cols="1">
      <dea-label class="valign-top">{{ contactType }}</dea-label>
    </v-col>
    <v-col class="d-flex flex-wrap" ref="refContactItems">
      <!-- 기본 4개의 입력란을 표시함(디자인) -->
      <fragment v-for="(item, index) in contactItems" :key="index">
        <!-- 연락처가 있음 | 2020-12-09 화면설계서 출처파일 삭제-->
        <v-col v-if="item.text" class="d-flex">
          <v-layout>
            <dea-text-field
              v-model="item.text"
              readonly
              :label="`${contactType} ${index + 1}`"
              @click:clear="onClear(index)"
            ></dea-text-field>
          </v-layout>
        </v-col>
        <!-- // 연락처가 있음 -->

        <!-- 연락처가 없음 | (클릭시 정보 체크창 뜸) -->
        <v-col v-else class="d-flex">
          <v-layout class="dea-text-field">
            <v-text-field
              :placeholder="contactType + '를 입력해주세요'"
              :label="`${contactType} ${index + 1}`"
              dense
              outlined
              @click="
                $emit('dialog-source-file-search-show', index, contactType)
              "
            ></v-text-field>
            <v-icon icon>mdi-magnify</v-icon>
          </v-layout>
        </v-col>
        <!-- // 연락처가 없음 | (클릭시 정보 체크창 뜸) -->
      </fragment>
    </v-col>
    <v-col class="d-flex flex-column flex-0">
      <dea-button
        icon
        fab
        color="primary"
        prepend-icon="mdi-plus"
        @click="onPlus(contactItems)"
      ></dea-button>
      <dea-button
        icon
        outlined
        prepend-icon="mdi-minus"
        @click="onMinus(contactItems)"
      ></dea-button>
    </v-col>
  </v-row>
</template>

<script>
export default {
  props: {
    contactType: {
      type: String,
      default: undefined
    },
    contactItems: {
      type: Array,
      default: undefined
    }
  },
  data() {
    return {}
  },
  methods: {
    onPlus(contactItems) {
      contactItems.push({
        text: ''
      })
    },
    // - 버튼 클릭시.
    onMinus(contactItems) {
      if (contactItems.length <= 4) {
        // 입력 정보값이 4칸 이하일때 값만 삭제
        for (let i = contactItems.length - 1; i >= 0; i--) {
          if (contactItems[i].text) {
            this.$toast.error(
              `입력된 ${contactItems[i].text}가 삭제되었습니다.`
            )
            contactItems[i].text = ''
            break
          }
        }
        // 이상이면 row삭제
      } else {
        let text = contactItems.pop().text
        if (text) {
          this.$toast.error(`입력된 ${text}가 삭제되었습니다.`)
        }
      }
    },
    // 입력란에서 x 버튼으로 삭제시.
    onClear(index) {
      this.contactItems.splice(index, 1, {
        text: ''
      })
    }
  }
}
</script>

<style lang="scss" scoped></style>
