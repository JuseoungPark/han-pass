<template>
  <v-container class="personManagement">
    <section class="dea-section">
      <!-- 마지막 정장 날짜 & 저장 아이콘 -->
      <v-row no-gutters>
        <v-col class="d-flex valign-middle">
          <div class="info-message">
            <strong>{{ lastUpdateTime }}</strong>
            <label class="ml-2">업데이트</label>
          </div>
          <v-btn
            text
            class="dea-btn--textindent"
            :loading="loading"
            @click="loader = 'loading'"
          >
            <v-icon>mdi-cached</v-icon>
            갱신
          </v-btn>
        </v-col>
      </v-row>
      <!-- // 마지막 정장 날짜 & 저장 아이콘 -->
      <!-- 검색 키워드 입력란 -->
      <div class="search-box search-box-field">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-text-field
                v-model="keyword"
                label="키워드 검색"
                class="align-center"
                append-icon="mdi-magnify"
                placeholder="인물과 관련된 정보로 키워드를 검색하세요."
                @click:append="searchKeyword"
                @keydown.enter="searchKeyword"
              ></dea-text-field>
            </v-col>
          </v-row>
        </dea-card>
      </div>
      <!-- // 검색 키워드 입력란 -->
    </section>

    <!-- 그리드 -->
    <section class="dea-section">
      <div class="inner">
        <dea-card class="grid-wrap">
          <dea-grid
            ref="grid"
            disableAutoLoad
            row-selection-multiple
            use-pagination
            suppress-row-click-selection
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :return-value.sync="gridInfo.totalCount"
            @ready="onReady"
            @cellButtonClicked="onCellButtonClicked"
            @cellSelectChange="onCellSelectChange"
          >
            <!-- 탭버튼 영역 -->
            <template #header-left>
              <v-col class="d-flex">
                <v-tabs :show-arrows="false" class="dea-tabs">
                  <v-tab
                    v-for="(personType, index) in totalByPersonType"
                    :key="index"
                    :class="personType.class"
                    @click="tabClickEventHandler(personType.prsnTyCode)"
                    >{{ `${personType.PrsnTyNm}(${personType.count})` }}</v-tab
                  >
                </v-tabs>
              </v-col>
            </template>
            <!-- // 탭버튼 영역 -->
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button
                  color="primary"
                  @click="personRegDialog = !personRegDialog"
                  >인물등록</dea-button
                >
                <dea-button @click="btnMergeClickEventHandler"
                  >인물병합</dea-button
                >
                <dea-button @click="personGrpMgmt = !personGrpMgmt"
                  >인물그룹관리</dea-button
                >
                <dea-button @click="btnGrpSelectClickEventHandler"
                  >인물그룹지정</dea-button
                >
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <!-- // 그리드 -->

    <!-- 인물등록(방법선택) : Layer Popup -->
    <dialog-person-reg
      :visible.sync="personRegDialog"
      @dialog-individual-reg-show="dialogIndividualRegShow"
      @dialog-person-batch-reg-show="personBatchReg = !personBatchReg"
    />
    <!-- //인물등록(방법선택) : Layer Popup -->

    <!-- 인물등록 / 인물수정 : Layer Popup -->
    <dialog-individual-reg
      ref="refIndividualReg"
      :visible.sync="individualReg"
      :personInfo.sync="searchedPerson"
      :contactItem.sync="contactItem"
      @dialog-person-search-show="dialogPersonSearchShow"
      @dialog-source-file-search-show="dialogSourceFileSearchShow"
      @dialog-person-grp-mgmt-show="personGrpMgmt = !personGrpMgmt"
      @dialog-company-depart-mgmt-show="companyDepartMgmt = !companyDepartMgmt"
      @update-now="updateNow"
    />
    <!-- //인물등록 / 인물수정 : Layer Popup -->

    <!-- 정보가 사용되는 인물 유무 검사 : Layer Popup -->
    <dialog-source-file-search
      :visible.sync="sourceFileSearch"
      :contactType.sync="contactType"
      @source-file-search-data="sourceFileSearchData"
    />
    <!-- //정보가 사용되는 인물 유무 검사 : Layer Popup -->

    <!-- 인물검색 (등록여부 확인) : Layer Popup -->
    <dialog-person-search
      :visible.sync="personSearch"
      :name="personSearchName"
      @person-registration="personRegistration"
      @dialog-individual-show="dialogIndividualShow"
    />
    <!-- //인물검색 (등록여부 확인) : Layer Popup -->

    <!-- 회사/부서관리 : Layer Popup -->
    <dialog-company-depart-mgmt
      :visible.sync="companyDepartMgmt"
      :params.sync="companyDepartMgmtParams"
      @update-now="updateNow"
    />
    <!-- //회사/부서관리 : Layer Popup -->

    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :_params.sync="individualDetailParams"
      :readOnly.sync="individualReadOnly"
      @dialog-individual-reg-show="dialogIndividualRegShow"
    />
    <!-- //인물정보 상세 : Layer Popup -->

    <!-- 인물정보 일괄등록 : Layer Popup -->
    <dialog-person-batch-reg :visible.sync="personBatchReg" />
    <!-- //인물정보 일괄등록 : Layer Popup -->

    <!-- 인물그룹지정 : Layer Popup -->
    <dialog-person-grp-select
      :visible.sync="personGrpSelect"
      :params.sync="selectedPersons"
      @update-now="updateNow"
    />
    <!-- //인물그룹지정 : Layer Popup -->

    <!-- 인물그룹관리 : Layer Popup -->
    <dialog-person-grp-mgmt
      :visible.sync="personGrpMgmt"
      @update-now="updateNow"
    />
    <!-- //인물그룹관리 : Layer Popup -->

    <!-- 인물병합 : Layer Popup -->
    <dialog-person-merge
      :visible.sync="personMerge"
      :params="selectedPersons"
      @person-info="onCellButtonClicked"
      @update-now="updateNow"
    />
    <!-- //인물병합 : Layer Popup -->

    <!-- 인물분리 : Layer Popup -->
    <dialog-person-divide
      :visible.sync="personDivide"
      :params.sync="personDivideParams"
      @update-now="updateNow"
    />
    <!-- //인물그룹지정 : Layer Popup -->

    <!-- 발신 통화 내역 : Layer Popup -->
    <dialog-call-history ref="dialogCallHistory" />
    <!-- // 발신 통화 내역 : Layer Popup -->
  </v-container>
</template>

<script>
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'
import DialogCallHistory from '@/views/callHistory/Dialog/DialogCallHistory' // 통화내역
import DialogPersonGrpSelect from '@/views/personManagement/Dialog/DialogPersonGrpSelect'
import DialogPersonGrpMgmt from '@/views/personManagement/Dialog/DialogPersonGrpMgmt'
import DialogPersonMerge from '@/views/personManagement/Dialog/DialogPersonMerge'
import DialogIndividualReg from '@/views/personManagement/Dialog/DialogIndividualReg'
import DialogPersonSearch from '@/views/personManagement/Dialog/DialogPersonSearch'
import DialogPersonDivide from '@/views/personManagement/Dialog/DialogPersonDivide'
import DialogPersonReg from '@/views/personManagement/Dialog/DialogPersonReg'
import DialogSourceFileSearch from '@/views/personManagement/Dialog/DialogSourceFileSearch'
import DialogPersonBatchReg from '@/views/personManagement/Dialog/DialogPersonBatchReg'
import DialogCompanyDepartMgmt from '@/views/personManagement/Dialog/DialogCompanyDepartMgmt'
import CellButton from '@/components/grid/CellButton'
import CellSelectBox from '@/components/grid/CellSelectBox'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import { NumberUtils } from '@/utils/NumberUtils'
import { StringUtils } from '@/utils/StringUtils'
import apiMixin from '@/mixins/apiMixin'
import listTemplate from '@/mixins/listTemplate'

export default {
  name: 'PersonManagement',
  mixins: [apiMixin, listTemplate],
  components: {
    DialogIndividual,
    DialogCallHistory,
    DialogPersonGrpSelect,
    DialogPersonGrpMgmt,
    DialogPersonMerge,
    DialogIndividualReg,
    DialogPersonSearch,
    DialogPersonDivide,
    DialogPersonReg,
    DialogSourceFileSearch,
    DialogPersonBatchReg,
    DialogCompanyDepartMgmt
  },
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/

      // grid setting
      gridInfo: {
        api: '/isrty/isrtys',
        totalCount: 0,
        columns: [
          {
            headerName: '열 선택',
            field: 'rowSelector',
            width: 20,
            headerComponentFramework: CellCheckboxHeader,
            cellRendererFramework: CellCheckbox
          },
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'person-info'
            }
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyCode',
            width: 160,
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellSelectBox,
            cellRendererParams: {
              items: [
                { text: '피의자', value: 'SUSPCT' },
                { text: '혐의자', value: 'SUSPIC' },
                { text: '참고인', value: 'REFE' },
                { text: '피해자', value: 'SUFRER' },
                { text: '기타', value: 'ETC' },
                { text: '미분류', value: 'NCL' }
              ]
            }
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'telno',
            width: 160,
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'outgoingNumber'
            },
            valueGetter(params) {
              return params.data.telno ? params.data.telno : ''
            }
          },
          // {
          //   headerName: '이메일',
          //   field: 'email',
          //   sortable: true,
          //   unSortIcon: true,
          //   hide: true
          // },
          {
            headerName: '별칭',
            field: 'rprsIsrtyNcm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록일',
            field: 'firstRegDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          // {
          //   headerName: '메모',
          //   field: 'memo',
          //   sortable: true,
          //   unSortIcon: true,
          //   hide: true
          // },
          // {
          //   headerName: '키워드',
          //   field: 'keyword',
          //   sortable: true,
          //   unSortIcon: true,
          //   hide: true
          // },
          {
            headerName: '병합인물분리',
            field: 'mrgYn',
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              outlined: true,
              event: 'person-merge'
            },
            valueGetter(params) {
              return params.data.mrgYn === 'Y' ? '분리' : ''
            }
          }
        ]
      },
      // 탭버튼 정의
      totalByPersonType: [
        {
          PrsnTyNm: '전체',
          class: 'font-bold',
          count: 0,
          countId: 'totalCnt',
          prsnTyCode: null
        },
        {
          PrsnTyNm: '주요인물',
          class: 'font-bold',
          count: 0,
          countId: 'mainCnt',
          prsnTyCode: 'MAIN'
        },
        {
          PrsnTyNm: '피의자',
          class: 'child-tab fontsize-small2',
          count: 0,
          countId: 'suspctCnt',
          prsnTyCode: 'SUSPCT'
        },
        {
          PrsnTyNm: '혐의자',
          class: 'child-tab fontsize-small2',
          count: 0,
          countId: 'suspicCnt',
          prsnTyCode: 'SUSPIC'
        },
        {
          PrsnTyNm: '참고인',
          class: 'child-tab fontsize-small2',
          count: 0,
          countId: 'refeCnt',
          prsnTyCode: 'REFE'
        },
        {
          PrsnTyNm: '피해자',
          class: 'child-tab fontsize-small2',
          count: 0,
          countId: 'sufrerCnt',
          prsnTyCode: 'SUFRER'
        },
        {
          PrsnTyNm: '기타',
          class: 'font-bold',
          count: 0,
          countId: 'etcCnt',
          prsnTyCode: 'ETC'
        }
      ],

      // Modal Popup
      companyDepartMgmt: false, // 부서관리
      individualDetail: false, // 인물정보 상세
      individualReadOnly: true, // 인물정보 상세(수정버튼사용여부)
      individualReg: false, // 인물등록 > 개별 > 인물등록 or 인물수정
      personBatchReg: false, // 인물정보 일괄등록
      personDivide: false, // 인물분리
      personGrpMgmt: false, // 인물그룹관리
      personGrpSelect: false, // 인물그룹지정
      personMerge: false, // 인물병합
      personRegDialog: false, // 인물등록(방법선택)
      personSearch: false, // 인물등록 > 개별 > 인물검색
      sourceFileSearch: false, // 사용중인 인물 검사

      // Modal Popup Params
      companyDepartMgmtParams: {}, // 회사/부서관리
      contactItem: {}, // 인물등록 > 개별 > 정보추가(사용중인 인물 검사)
      contactType: '',
      individualDetailParams: {}, // 인물정보(열람)
      personDivideParams: {}, // 인물리스트 > 병합분리 > 팝업(병합된 코드)
      personSearchName: '', // 인물등록 > 인물검색(입력된 이름으로 검색)
      searchedPerson: {}, // 인물등록 > 개별 > 인물검색 > 선택한인물정보.
      selectedPersons: [], // 그리드에서 선택된 rows

      filter: '', // api param
      limit: 20, // api param > 기본 row 수
      lastUpdateTime: '', // 최근저장 시간.
      keyword: '', // keyword search

      loader: null, // 마지막 업데이트 일시 > 아이콘
      loading: false // 마지막 업데이트 일시 > 아이콘
    }
  },
  mounted() {},
  watch: {
    loader() {
      const l = this.loader
      this[l] = !this[l]

      setTimeout(() => (this[l] = false), 3000)

      this.loader = null
    }
  },
  methods: {
    onReady() {
      this.$refs.grid.dataReset()
      this.$refs.grid.loadData()
      this.getLastUpdateTime()
      this.totalByPersonTypeData()
    },
    // 탭버튼 선택 > 인물유형 검색됨.
    tabClickEventHandler(prsnTyCode) {
      this.apiParams = prsnTyCode ? `&prsnTyCode=${prsnTyCode}` : ''
      this.$refs.grid.dataReset()
      this.$refs.grid.setFilter(this.apiParams)
      this.$refs.grid.loadData()
    },
    // 전체 | 주요인물 | 피의자 | 혐의자 | 참조인 | 피해자 | 기타 탭버튼의 count값 추가.
    totalByPersonTypeData() {
      this.apiUrl = '/isrty/isrty-prsn-ty-cnt'
      this.apiParams = StringUtils.objQueryString({
        // incdntId: this.incidentInfo.id
      })

      this.requestApiAsync((res) => {
        console.log('탭버튼의 count값 추가 호출', res)
        // this.grpItems = res.data.result
        if (res !== false) {
          this.totalByPersonType.forEach((tab) => {
            // console.log('탭버튼의 count값 forEach', res)
            const num = res.data.result[0][tab.countId]
            tab.count = NumberUtils.numberWithCommas(num)
          })
        }
      })
    },
    // 마지막 저장 시간.
    getLastUpdateTime() {
      this.apiUrl = '/isrty/isrtys-last-chg-dt'
      this.apiType = 'analysis'

      this.apiParams = StringUtils.objQueryString({
        requestPage: this.pagination.page,
        rowCntByPage: this.pagination.limit
      })

      this.requestApiAsync((res) => {
        if (res !== false) {
          console.log('마지막저장시간호출', res)
          this.lastUpdateTime = res.data.result.data
        }
      })
    },
    // 키워드 검색.
    searchKeyword() {
      if (!this.keyword) {
        this.$toast.error('검색어를 입력하세요')
        return
      }
      this.$refs.grid.dataReset()

      this.apiParams = StringUtils.objQueryString({
        searchKwrd: this.keyword
      })

      this.$refs.grid.setFilter(this.apiParams)
      this.$refs.grid.loadData()
    },
    // 그리드 내부 버튼 클릭시.
    onCellButtonClicked(params) {
      if (params.event == 'person-info') {
        this.individualDetailParams = params
        this.individualDetail = true
        this.individualReadOnly = false
      }
      if (params.event == 'person-merge') {
        this.personDivideParams = params
        this.personDivide = true
      }
      if (params.event == 'outgoingNumber') {
        params.data['outgoingNumber'] = params.value
        this.$refs.dialogCallHistory.show(params)
      }
    },
    // 그리드 인물유형 셀렉트 박스 변경시.
    onCellSelectChange(params, value) {
      this.$api.analysis
        .put('/isrty/isrtys', {
          incdntId: this.incidentInfo.id,
          isrtysSubPutReqVos: [
            {
              isrtyId: params.data.isrtyId,
              isrtyPrsnTyCode: value
            }
          ]
        })
        .then((res) => {
          if (res.data.result) {
            this.$toast('인물유형이 변경 되었습니다.')
            this.updateNow()
          }
        })
        .catch((err) => {
          this.$toast.error('인물유형이 변경이 실패했습니다.')
          console.log('그리드 인물유형 셀렉트 박스 변경시', err)
        })
    },
    // 인물등록 > 개별 > 인물등록 팝업 or 인물상세 > 인물수정
    dialogIndividualRegShow(personInfo) {
      if (personInfo) {
        this.searchedPerson = personInfo
      }
      this.individualReg = true
    },
    // 인물그룹지정.
    btnGrpSelectClickEventHandler() {
      const rows = this.$refs.grid.gridApi.getSelectedRows()
      if (!rows.length) {
        this.$toast.error('선택된 인물이 없습니다.')
        return
      }
      const groupName = rows[0].isrgrpNm
      if (rows.some((person) => person.isrgrpNm !== groupName)) {
        this.$toast.error('속해있는 그룹이 다른 인물이 있습니다.')
        return
      }
      this.selectedPersons = rows
      this.personGrpSelect = true
    },
    // 그리드 위에 인물병합 버튼으로 인물병합시.
    btnMergeClickEventHandler() {
      const rows = this.$refs.grid.gridApi.getSelectedRows()
      if (!rows.length) {
        this.$toast.error('선택된 인물이 없습니다.')
        return
      }
      if (rows.some((person) => person.mrgYn === 'Y')) {
        this.$toast.error('인물중에 이미 병합된 인물이 있습니다.')
        return
      }
      this.personMerge = true
      this.selectedPersons = rows
    },
    // 인물등록 > 개별 > 인물검색팝업.
    dialogPersonSearchShow(name) {
      this.personSearchName = name
      this.personSearch = true
    },
    // 인물등록 > 개별 > 인물검색(중복검색) > 인물등록 -> 인물수정(검색된인물)
    personRegistration(personInfo) {
      this.searchedPerson = personInfo
    },
    // 인물등록 > 개별 > 인물 중복 검색 > 인물정보(팝업)
    dialogIndividualShow(person) {
      this.individualDetailParams = person
      this.individualDetail = true
    },
    // 인물등록 > 개별 > 전화번호...모바일앱 추출파일 등록.
    sourceFileSearchData(contactItem) {
      this.contactItem = { ...contactItem }
    },
    // 인물등록/수정 > 정보를 사용중인 인물을 검사.
    dialogSourceFileSearchShow(contactType) {
      this.contactType = contactType
      this.sourceFileSearch = true
    },
    // 데이타 변경후 새로운 정보 불러옴.
    updateNow() {
      console.log('새로고침!!')
      this.getLastUpdateTime()
      // this.$refs.grid.dataReset()
      this.$refs.grid.loadData()
      this.totalByPersonTypeData()
      // 인물수정중일때 변경된 정보가 있다면
      if (this.individualReg) {
        this.$refs.refIndividualReg.initGroups()
        this.$refs.refIndividualReg.initCompanyItems()
      }
    }
  }
}
</script>

<style scoped>
/*** loader ***/
@keyframes loader {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
