<template>
  <dea-dialog
    v-model="visible"
    title="인물분리"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text fontsize-big3 pa-4">
              병합된 인물을 다음처럼 다시 분리합니다.
            </div>
          </v-col>
        </v-row>
        <dea-card>
          <dea-grid
            ref="refDialogPersonDivideGrid"
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
            disableAutoLoad
            @ready="onReady"
          ></dea-grid>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOk">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DialogPersonDivide',
  mixins: [apiMixin],
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    params: {
      type: Object,
      default: undefined
    }
  },
  data() {
    return {
      // grid setting
      gridInfo: {
        api: '/isrty/mrg-isrtys',
        count: 0,
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: 'No',
            field: 'no',
            width: 90,
            hide: true,
            cellClass: 'align-right'
          },
          {
            headerName: '대표자',
            field: 'isrtyPrsnYn',
            sortable: true,
            unSortIcon: true,
            valueGetter(params) {
              return params.data.isrtyPrsnYn === 'Y' ? '대표자' : ''
            }
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물유형코드',
            field: 'isrtyPrsnTyCode',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'rprsTelno',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'telnos',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '별칭',
            field: 'rprsIsrtyNcm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록일',
            field: 'firstRegDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          }
        ]
      },
      filter: ''
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        this.$refs.refDialogPersonDivideGrid.dataReset()
        this.$emit('update:params', undefined)
      }
    },
    params() {
      if (this.visible) {
        // 병합분리 리스트 호출
        this.initData()
        console.log(
          '병합분리(팝업) 열림',
          this.visible,
          '인물아이디',
          this.params.data.isrtyId
        )
      } else {
        console.log('병합분리(팝업) 닫힘')
      }
    }
  },
  methods: {
    onReady() {
      this.initData()
    },
    // 병합분리 리스트 호출
    initData() {
      // http://10.220.140.208:8090/isrty/mrg-isrtys?incdntId=1160100000000000373&isrtyId=SCFT1a372353d5d34096b6790a65f6b236cd35
      let filter = StringUtils.objQueryString({
        isrtyId: this.params.data.isrtyId
      })

      if (this.$refs.refDialogPersonDivideGrid) {
        this.$refs.refDialogPersonDivideGrid.setFilter(filter)
        this.$refs.refDialogPersonDivideGrid.loadDataSync().then(() => {
          this.personMergeNum = this.$refs.refDialogPersonDivideGrid.rowData.length
          console.log('병합분리(팝업) 리스트 호출 완료')
        })
      }
    },
    // 병합 분리 요청.
    onOk() {
      this.$api.analysis
        .post(`/isrty/seprat-isrty`, {
          incdntId: this.incidentInfo.id,
          isrtyId: this.params.data.isrtyId
        })
        .then((res) => {
          console.log('병합분리결과', res)
          this.$emit('update-now')
          this.$toast('병합을 분리했습니다.')
          this.$emit('update:visible', !this.visible)
        })
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
