<template>
  <dea-dialog
    v-model="visible"
    :title="personInfo.isrtyNm"
    width="1000px"
    @dialog:close="onDialogClose"
  >
    <!-- 인물정보 -->
    <section v-show="currentTab === 'person'" class="dea-section">
      <div class="search-box">
        <dea-card>
          <!-- <template slot="title">개인정보</template> -->
          <v-layout class="divide">
            <v-col class="flex-0">
              <v-row no-gutters class="flex-column" style="height:100%;">
                <v-col class="d-flex">
                  <v-layout
                    class="img-wrap"
                    style="width:140px; padding-top:120%;"
                  >
                    <img
                      :src="loadImg(personInfo.isrtyId) || '/img/no_image.jpg'"
                      :alt="
                        isPhoto ? `${personInfo.isrtyId} 이미지` : `이미지 없음`
                      "
                    />
                  </v-layout>
                </v-col>
                <v-col class="d-flex flex-0 align-center">
                  <!-- <div class="text">모바일</div> -->
                </v-col>
              </v-row>
            </v-col>
            <v-col>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>이름</dea-label>
                </v-col>
                <v-col class="d-flex flex-0">
                  <div class="text">
                    {{ personInfo && personInfo.isrtyNm }}
                  </div>
                </v-col>
                <v-col class="d-flex pl-1">
                  <v-chip small>{{
                    getIsrtyPrsnTyName(personInfo.isrtyPrsnTyCode)
                  }}</v-chip>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>별칭</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">
                    {{ personInfo && personInfo.rprsIsrtyNcm }}
                  </div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>회사</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">
                    {{ personInfo && personInfo.upperIsrtyPsitnOrgnztNm }}
                  </div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>부서</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <div class="text">
                    {{ personInfo && personInfo.isrtyPsitnOrgnztNm }}
                  </div>
                </v-col>
              </v-row>
              <v-row no-gutters>
                <v-col cols="1">
                  <dea-label>그룹</dea-label>
                </v-col>
                <v-col class="d-flex">
                  <template
                    v-for="(group, index) in personInfo.isrgrpIsrtyResVos"
                  >
                    <div class="text mr-4" :key="index">
                      {{ group.isrgrpNm }}
                    </div>
                  </template>
                </v-col>
              </v-row>
            </v-col>
          </v-layout>
        </dea-card>
      </div>
    </section>
    <section v-if="currentTab === 'person'" class="dea-section">
      <div class="inner">
        <dea-card>
          <!-- 전화번호 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>전화번호</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(telno, index) in personInfo.telnos">
                <v-chip small :key="index">
                  {{ telno.acntIdntfcValue }}
                </v-chip>
              </template>
            </v-col>
          </v-row>
          <!-- // 전화번호 -->

          <!-- 이메일 -->
          <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>이메일</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(email, index) in personInfo.emails">
                <v-chip small :key="index">
                  {{ email }}
                </v-chip>
              </template>
            </v-col>
          </v-row>
          <!-- // 이메일 -->

          <!-- 계좌번호 -->
          <!-- <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>계좌번호</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(acnutno, index) in personInfo.acnutnos">
                <v-chip small :key="index">
                  {{ acnutno }}
                </v-chip>
              </template>
            </v-col>
          </v-row> -->
          <!-- 계좌번호 -->

          <!-- 모바일 -->
          <!-- <v-row no-gutters>
            <v-col cols="1" class="valign-top">
              <dea-label>모바일</dea-label>
            </v-col>
            <v-col class="d-flex flex-wrap">
              <template v-for="(mobileApp, index) in personInfo.mobileApps">
                <v-chip small :key="index">
                  {{ mobileApp }}
                </v-chip>
              </template>
            </v-col>
          </v-row> -->
          <!-- // 모바일 -->
          <v-divider />
          <!-- 메모 -->
          <v-row no-gutters v-if="personInfo.isrtyMemoCn">
            <v-col cols="1">
              <dea-label class="valign-top">메모</dea-label>
            </v-col>
            <v-col class="d-flex d-block">
              <v-row no-gutters>
                <v-col class="d-flex">
                  <v-sheet class="text">
                    {{ personInfo && personInfo.isrtyMemoCn }}
                  </v-sheet>
                </v-col>
              </v-row>
            </v-col>
          </v-row>
          <!-- // 메모 -->
        </dea-card>
      </div>
    </section>
    <!-- // 인물정보 -->

    <!-- 병합정보 -->
    <section v-show="currentTab === 'merge'" class="dea-section">
      <div class="inner grid-wrap">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text fontsize-big3 pa-4">
              {{ personMergeNum }}명의 인물이 병합되어 있습니다.
            </div>
          </v-col>
        </v-row>
        <dea-card>
          <template slot="title">병합정보</template>
          <dea-grid
            ref="refDialogIndividualGrid"
            disableAutoLoad
            use-pagination
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
            :return-value.sync="gridInfo.totalCount"
            @ready="onReady"
          ></dea-grid>
        </dea-card>
      </div>
    </section>
    <!-- // 병합정보 -->

    <!-- 수정이력 -->
    <section v-show="currentTab === 'history'" class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <template slot="title">수정이력</template>
          <v-row>
            <v-col
              cols="6"
              v-for="(modifyHistory, index) in modifyHistorys"
              :key="index"
            >
              <v-card class="dea-card-field pa-0">
                <v-list class="history-list pa-0">
                  <v-list-item-group>
                    <v-list-item>
                      <v-list-item-content class="flex-column">
                        <v-layout class="flex-auto">
                          <v-list-item-title>
                            {{ modifyHistory.firstRegDt }}
                          </v-list-item-title>
                          <v-list-item-title>
                            &nbsp; / 등록자: {{ modifyHistory.firstRegUserNm }}
                          </v-list-item-title>
                        </v-layout>
                        <v-layout class="flex-auto">
                          <div
                            class="text"
                            v-text="modifyHistory.dataOcrnMbyTyNm"
                          ></div>
                        </v-layout>
                        <v-layout>
                          <v-list-item-subtitle
                            v-for="(item,
                            idx) in modifyHistory.isrtyInfoChgHistGetResSubVos"
                            :key="idx"
                          >
                            [{{ item.dataChgTyNm }}]{{ item.dataTy }}:
                            {{ item.dataDc }}
                          </v-list-item-subtitle>
                        </v-layout>
                      </v-list-item-content>
                    </v-list-item>
                  </v-list-item-group>
                </v-list>
              </v-card>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <!-- // 수정이력 -->
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button v-if="!readOnly" outlined @click="dialogIndividualRegShow"
          >수정</dea-button
        >
        <dea-button color="primary" @click="$emit('update:visible', !visible)"
          >확인</dea-button
        >
        <dea-button @click="onPrint">인쇄</dea-button>
      </v-col>
    </div>
    <template #header-btn-radio>
      <dea-radio-group
        class="dea-btn-radio"
        v-model="currentTab"
        row
        :mandatory="false"
        :items="listTypeItems"
        @change="onChange"
      ></dea-radio-group>
    </template>
  </dea-dialog>
</template>
<script>
import apiMixin from '@/mixins/apiMixin'
import { StringUtils } from '@/utils/StringUtils'

export default {
  name: 'DialogIndividual',
  mixins: [apiMixin],
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    _params: {
      type: Object,
      default: undefined
    },
    readOnly: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      // 인물정보
      personInfo: {},
      // 인물병합된 인물수
      personMergeNum: 0,
      // 이미지 호출값이 이미지인가.
      isPhoto: false,
      // 탭버튼 현재 이름
      currentTab: 'person',
      // checkbox, radio
      listTypeItems: [
        {
          label: '인물정보',
          value: 'person'
        },
        {
          label: '병합정보',
          value: 'merge'
        },
        {
          label: '수정이력',
          value: 'history'
        }
      ],

      // 수정이력정보
      modifyHistorys: [],

      // grid setting
      gridInfo: {
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        api: 'isrty/mrg-isrtys',
        totalCount: 0,
        columns: [
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            sortable: true,
            unSortIcon: true,
            hide: true,
            cellClass: 'align-right'
          },
          {
            headerName: '대표자',
            field: 'isrtyPrsnYn',
            sortable: true,
            unSortIcon: true,
            valueGetter(params) {
              return params.data.isrtyPrsnYn === 'Y' ? '대표자' : ''
            }
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          // {
          //   headerName: '인물유형코드',
          //   field: 'isrtyPrsnTyCode',
          //   width: 160,
          //   sortable: true,
          //   unSortIcon: true
          // },
          // {
          //   headerName: '전화번호',
          //   field: 'rprsTelno',
          //   width: 160,
          //   sortable: true,
          //   unSortIcon: true
          // },
          {
            headerName: '전화번호',
            field: 'telnos',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '별칭',
            field: 'rprsIsrtyNcm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록일',
            field: 'firstRegDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          }
        ]
      }
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0
        this.personInfo = {}
        this.personMergeNum = 0
        this.currentTab = 'person'
        this.$refs.refDialogIndividualGrid.dataReset()
        this.$emit('update:_params', undefined)
        this.$emit('update:readOnly', true)
      }
    },
    _params() {
      if (!this._params) {
        return
      }
      // 인물 id로 인물정보 호출
      console.log('인물정보상세팝업 this._params >> ', this._params)
      console.log(
        '인물정보상세팝업 this._params.data.isrtyId >> ',
        this._params.data.isrtyId
      )

      // 인물 전반적인 데이타 적용.
      this.loadPersonInfo()
      // 정보수정 이력 호출
      this.loadModifyHistorys()
      // 인물병합내역 호출
      this.loadPersonMerge()
    }
  },
  computed: {},
  methods: {
    // 인물 기본 정보 호출
    loadPersonInfo() {
      this.apiUrl = '/isrty/isrty'
      this.apiParams = StringUtils.objQueryString({
        isrtyId: this._params.data.isrtyId
      })

      this.requestApiAsync((res) => {
        console.log('인물 기본 정보 호출', res.data.result)
        this.personInfo = res.data.result
      })
    },
    // 수정 이력 정보
    loadModifyHistorys() {
      this.apiUrl = '/isrty/isrty-info-chg-hists'
      this.apiParams = StringUtils.objQueryString({
        isrtyId: this._params.data.isrtyId
      })

      this.requestApiAsync((res) => {
        console.log('수정 이력 정보', res)
        this.modifyHistorys = res.data.result
      })
    },
    // 병합인물리스트
    loadPersonMerge() {
      // http://10.220.140.208:8090/isrty/mrg-isrtys?incdntId=1160100000000000373&isrtyId=SCFTa3d8af7389984ac7a417f1f5a9ef0ba582
      let filter = StringUtils.objQueryString({
        isrtyId: this._params.data.isrtyId
      })

      if (this.$refs.refDialogIndividualGrid) {
        this.$refs.refDialogIndividualGrid.setFilter(filter)
        this.$refs.refDialogIndividualGrid.loadDataSync().then(() => {
          this.personMergeNum = this.$refs.refDialogIndividualGrid.rowData.length
          console.log('병합인물리스트 호출 완료')
        })
      }
    },
    // 병합정보 호출
    onReady() {
      this.loadPersonMerge()
    },
    // 인물수정팝업(인물정보넘김)
    dialogIndividualRegShow() {
      this.$emit('update:visible', !this.visible)
      // this.$emit('dialog-individual-reg-show')
      this.$emit('dialog-individual-reg-show', this.personInfo)
    },
    // 탭버튼 변동시
    onChange() {},
    // 프린트 포멧 임시.
    onPrint() {
      const deaApp = document.querySelector('.v-overlay__scrim ')
      const deaAppCssText = deaApp.style
      const dialogActive = document.querySelector('.v-dialog--active')
      const deaSections = dialogActive.querySelectorAll('.dea-section')
      const hideDeaSections = Array.from(deaSections).filter(
        (element) => element.style.display === 'none'
      )
      hideDeaSections.forEach((element) => (element.style.display = 'block'))
      dialogActive.style.transform = 'scale(1.05)'
      deaApp.style.backgroundColor = '#fff'
      deaApp.style.opacity = '1'
      window.print()
      hideDeaSections.forEach((element) => (element.style.display = 'none'))
      dialogActive.style.transform = 'scale(1)'
      deaApp.style.cssText = deaAppCssText
    },
    // 이미지 로드
    loadImg(isrtyId) {
      // todo : 이미지 호출 하기.
      console.log('이미지 호출', isrtyId)

      this.isPhoto = false
      return null
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    },
    getIsrtyPrsnTyName(code) {
      let res = '미분류'
      switch (code) {
        case 'SUSPCT':
          res = '피의자'
          break
        case 'SUSPIC':
          res = '혐의자'
          break
        case 'REFE':
          res = '참고인'
          break
        case 'SUFRER':
          res = '피해자'
          break
        case 'ETC':
          res = '기타'
          break
        default:
          res = '미분류' // NCL
          break
      }
      return res
    }
  }
}
</script>
