<template>
  <dea-dialog
    v-model="visible"
    title="인물정보 일괄등록"
    width="600px"
    @dialog:close="onDialogClose"
  >
    <section v-if="!isUploading" class="dea-section">
      <div class="inner">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text">
              대량의 인물정보를 파일 형태로 일괄 등록합니다.
            </div>
            <div class="text"><a href="#">표준서식 다운받기</a></div>
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <dea-file-input
              :show-size="1000"
              ref="reffileInput"
              counter
              placeholder="로컬 PC에서 작성한 파일을 불러옵니다"
              prepend-icon="mdi-folder-open-outline"
            >
            </dea-file-input>
          </v-col>
        </v-row>
      </div>
    </section>

    <section v-else class="dea-section">
      <div class="inner">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div
              v-for="(fileName, index) in fileNames"
              :key="index"
              class="text fontsize-big3 font-bold fontcolor-primary"
            >
              <v-icon class="fontsize-big3 fontcolor-primary"
                >mdi-file-excel-outline</v-icon
              >
              {{ fileName }}
            </div>
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text">
              업로드가 완료되어, 등록 처리 진행중입니다.
            </div>
          </v-col>
        </v-row>
      </div>
    </section>
    <div class="btn-group">
      <v-col v-show="isUploading" class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >확인</dea-button
        >
      </v-col>
      <v-col v-show="!isUploading" class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onUpload">업로드</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
export default {
  name: 'DialogPersonBatchReg',
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    }
  },
  data() {
    return {
      isUploading: false,
      fileNames: []
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        this.isUploading = false
        this.fileNames = []
      }
    }
  },
  methods: {
    onUpload() {
      if (this.$refs.reffileInput.files.length < 1) {
        this.$toast.error('불러온 파일이 없습니다.')
        return
      }
      this.fileNames = this.$refs.reffileInput.files.map((file) => file.name)
      this.isUploading = true
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
