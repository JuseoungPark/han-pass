<template>
  <dea-dialog
    v-model="visible"
    :title="title"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <!-- 이름/인물검색 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label required>이름</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                v-model="personInfo.isrtyNm"
                placeholder="이름을 입력해 주세요"
              ></dea-text-field>
              <dea-button
                v-if="!this.personInfo.isrtyId"
                color="primary"
                prepend-icon="mdi-magnify"
                title="이미 등록된 인물인지 검색으로 확인해주세요"
                @click="dialogPersonSearchShow"
                >인물검색</dea-button
              >
            </v-col>
          </v-row>
          <!-- // 이름/인물검색 -->

          <!-- 별칭 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>별칭</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                v-model="personInfo.rprsIsrtyNcm"
                placeholder="별칭을 입력해주세요. 복수 입력시에는 콤마(,)로 구분해주세요."
              ></dea-text-field>
            </v-col>
          </v-row>
          <!-- // 별칭 -->

          <!-- 인물유형 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label required>유형</dea-label>
            </v-col>
            <v-col class="d-flex">
              <v-radio-group
                v-model="personInfo.isrtyPrsnTyCode"
                row
                :mandatory="false"
              >
                <v-radio label="피의자" value="SUSPCT"></v-radio>
                <v-radio label="혐의자" value="SUSPIC"></v-radio>
                <v-radio label="참고인" value="REFE"></v-radio>
                <v-radio label="피해자" value="SUFRER"></v-radio>
                <v-radio label="기타" value="ETC"></v-radio>
                <v-radio label="미분류" value="NCL"></v-radio>
              </v-radio-group>
            </v-col>
          </v-row>
          <!-- // 인물유형 -->

          <!-- 인물그룹 : Layer Popup -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>인물그룹</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="grpValues"
                :items="grpItems"
                multiple
                deaPrependSelectAll
                itemText="isrgrpNm"
                itemValue="isrgrpId"
                placeholder="인물 그룹을 선택해 주세요"
              >
              </dea-select>
              <dea-button @click="$emit('dialog-person-grp-mgmt-show')"
                >인물그룹관리</dea-button
              >
            </v-col>
          </v-row>
          <!-- // 인물그룹 : Layer Popup -->

          <!-- 회사/부서 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>회사/부서</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-select
                v-model="companyItem"
                :items="companyItems"
                label="회사명"
                itemText="upperIsrtyPsitnOrgnztNm"
                itemValue="upperIsrtyPsitnOrgnztId"
                filterable
                placeholder="회사를 입력해주세요"
                @change="onCompanyChange"
              ></dea-select>
              <dea-select
                v-model="departmentItem"
                :items="departmentItems"
                label="부서명"
                itemText="isrtyPsitnOrgnztNm"
                itemValue="isrtyPsitnOrgnztId"
                filterable
                placeholder="부서를 입력해주세요"
              ></dea-select>
              <dea-button @click="$emit('dialog-company-depart-mgmt-show')"
                >회사/부서관리</dea-button
              >
            </v-col>
          </v-row>
          <!-- 회사/부서 -->

          <!-- 사진등록 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>사진등록</dea-label>
            </v-col>
            <v-col class="d-flex flex-0">
              <v-layout
                class="img-wrap"
                style="width:120px; padding-top:120%;"
                @click="onClickImg"
              >
                <img
                  :src="personInfo.photo || '/img/no_image.jpg'"
                  :alt="
                    personInfo.photo
                      ? `${personInfo.name} 이미지`
                      : `이미지 없음`
                  "
                />
              </v-layout>
              <!-- <v-layout
                class="img-wrap"
                style="width:120px; height:120px; border-radius: 70%; overflow: hidden;"
                @click="onClickImg"
              >
                <img
                  style="width: 100%; height: 100%; object-fit: cover;"
                  :src="personInfo.photo || '/img/no_image.jpg'"
                  :alt="personInfo.photo ? `${personInfo.name} 이미지` : `이미지 없음`"
                />
              </v-layout> -->
              <v-file-input
                ref="refFileInput"
                v-model="files"
                v-show="false"
                :rules="rules"
                accept="image/png, image/jpeg, image/bmp"
                hide-input
                @change="onUploadImg"
                >파일업로드
              </v-file-input>
            </v-col>
          </v-row>
          <!-- // 사진등록 -->

          <v-divider />

          <!-- 전화번호 -->
          <add-contact-comm-input
            contactType="전화번호"
            :contactItems.sync="phoneNumbers"
            @dialog-source-file-search-show="onFileSearch"
          />
          <!-- // 전화번호 -->

          <!-- 계좌번호 -->
          <!-- <add-contact-comm-input
            contactType="계좌번호"
            :contactItems="bankAccountNumbers"
            @dialog-source-file-search-show="onFileSearch"
          /> -->
          <!-- // 계좌번호 -->

          <!-- 이메일 -->
          <add-contact-comm-input
            contactType="이메일"
            :contactItems.sync="emails"
            @dialog-source-file-search-show="onFileSearch"
          />
          <!-- // 이메일 -->

          <!-- 모바일앱 -->
          <!-- <add-contact-comm-input
            contactType="모바일앱"
            :contactItems="apps"
            @dialog-source-file-search-show="onFileSearch"
          /> -->
          <!-- // 모바일앱 -->

          <v-divider />

          <!-- 메모 -->
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label class="valign-top">메모</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-textarea
                v-model="personInfo.isrtyMemoCn"
                no-resize
                placeholder="메모를 입력할 수 있습니다"
                counter="1000"
              ></dea-textarea>
            </v-col>
          </v-row>
          <!-- // 메모 -->
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOk">저장</dea-button>
        <!-- <dea-button>미리보기</dea-button> -->
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import apiMixin from '@/mixins/apiMixin'
import { StringUtils } from '@/utils/StringUtils'
import AddContactCommInput from '../include/AddContactCommInput'

export default {
  name: 'DialogIndividualReg',
  mixins: [apiMixin],
  components: { AddContactCommInput },
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    personInfo: {
      defaulte: undefined
    },
    // 정보를 중복으로 사용되는지 확인시.
    contactItem: {
      type: Object,
      default: undefined
    }
  },
  data() {
    return {
      files: undefined, // 이미지 업로드
      rules: [
        (value) =>
          !value ||
          value.size < 2000000 ||
          'Avatar size should be less than 2 MB!'
      ],
      title: '인물등록',

      contactItemIndex: null, // 전화 계좌 번호 or 주소 추가할 index
      contactType: '',

      phoneNumbers: [{ text: '' }, { text: '' }, { text: '' }, { text: '' }],
      emails: [{ text: '' }, { text: '' }, { text: '' }, { text: '' }],
      // bankAccountNumbers: [], // 계좌번호리스트
      // apps: [], // 모바일앱리스트

      grpItems: [
        {
          isrgrpId: 13,
          isrgrpNm: '테스트그룹',
          dataOcrnMbyTyCode: 'USER'
        }
      ], // 그룹리스트
      grpItem: '', // 선택된 그룹명
      grpValues: [], // 선택된 그룹리스트

      // menu 옵션
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: true,
      offsetX: false,
      offsetY: true,

      // 회사리스트
      companyItems: [
        {
          upperIsrtyPsitnOrgnztId: '18',
          upperIsrtyPsitnOrgnztNm: '삼성전자'
        }
      ],
      companyItem: null,
      // 부사리스트
      departmentItems: [
        {
          upperIsrtyPsitnOrgnztId: '18',
          upperIsrtyPsitnOrgnztNm: '삼성전자',
          isrtyPsitnOrgnztId: '20',
          isrtyPsitnOrgnztNm: 'LCD사업부'
        }
      ],
      departmentItem: null
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0

        this.contactItemIndex = null
        this.$emit('update:personInfo', {})
        this.$emit('update:contactItem', {})
        this.$emit('update:contactType', null)
      } else {
        // this.initData() // 초기값 설정
        this.grpItems = []
        this.grpItem = ''
        this.grpValues = []
        // 전화번호리스트
        this.phoneNumbers = [
          { text: '' },
          { text: '' },
          { text: '' },
          { text: '' }
        ]
        // 이메일리스트
        this.emails = [{ text: '' }, { text: '' }, { text: '' }, { text: '' }]
        this.$nextTick(() => {
          this.initGroups() // 그룹리스트 호출
          this.initCompanyItems() // 회사리스트 호출 > 첫번째 회사의 부서를 호출
          // this.getEmails() // 이메일 주소들을 호출
          // this.getPhoneNumbers() // 전화번호들을 호출
        })
      }
    },
    // 중복인물 확인후 넘겨받은 정보를 타입맞게 등록
    contactItem() {
      console.log('contactItem', this.contactItem)
      if (!this.contactItem) {
        return
      }
      switch (this.contactType) {
        case '전화번호':
          this.addSourceFile(this.phoneNumbers)
          break
        case '이메일':
          this.addSourceFile(this.emails)
          break
        // case '계좌번호':
        //   this.addSourceFile(this.bankAccountNumbers)
        //   break
        // case '모바일앱':
        //   this.addSourceFile(this.apps)
        //   break
        default:
          break
      }
    },
    personInfo() {
      // 넘어온 인물정보가 있다면.
      if (!this.visible) {
        return
      }
      this.title = this.personInfo.isrtyId ? '인물수정' : '인물등록'
    }
  },
  computed: {
    phoneNumberTexts() {
      return this.phoneNumbers.filter((p) => p.text).map((p) => p.text)
    },
    emailTexts() {
      console.log('등록된이메일', this.emails)
      return this.emails.filter((e) => e.text).map((e) => e.text)
    },
    personFilter() {
      let filter = '?'
      // filter += `name=${this.personInfo.isrtyNm}`
      // filter += `&photo=${this.personInfo.photo ? this.personInfo.photo : ''}`
      // filter += `&personType=${this.personType(
      //   this.personInfo.isrtyPrsnTyCode
      // )}`
      // // 대표전화번호
      // filter += `&phoneNumber=${
      //   this.phoneNumberTexts[0] ? this.phoneNumberTexts[0] : ''
      // }`
      // filter += `&nickname=${
      //   this.personInfo.rprsIsrtyNcm ? this.personInfo.rprsIsrtyNcm : ''
      // }`
      // // 대표이메일
      // filter += `&email=${this.emailTexts[0] ? this.emailTexts[0] : ''}`
      // // 회사
      // filter += `&company=${this.companyItem ? this.companyItem : 1}`
      // // 부서
      // filter += `&division=${this.departmentItem ? this.departmentItem : 1}`
      // filter += `&registeredUser=김00수사관`
      // filter += `&evidenceNumber=증거번호234`
      // filter += `&memo=${
      //   this.personInfo.isrtyMemoCn ? this.personInfo.isrtyMemoCn : ''
      // }`
      // filter += `&keyword=${
      //   this.personInfo.keyword ? this.personInfo.keyword : ''
      // }`
      // filter += `&merge=${this.personInfo.merge ? this.personInfo.merge : ''}`
      // filter += `&represent=${
      //   this.personInfo.represent ? this.personInfo.represent : ''
      // }`
      return filter
    }
  },
  methods: {
    initData() {
      this.grpItems = []
      this.grpItem = ''
      this.grpValues = []

      // 전화번호리스트
      this.phoneNumbers = [
        { text: '' },
        { text: '' },
        { text: '' },
        { text: '' }
      ]
      // 이메일리스트
      this.emails = [{ text: '' }, { text: '' }, { text: '' }, { text: '' }]
    },
    // 그룹 select item 호출
    initGroups() {
      // http://10.220.140.208:8090/isrty/isrgrps?incdntId=1160100000000000373
      this.apiUrl = '/isrty/isrgrps'
      this.apiType = 'analysis'
      this.apiParams = StringUtils.objQueryString({
        incdntId: this.incidentInfo.id,
        isrtyId: this.personInfo.isrtyId
      })

      this.requestApiAsync((res) => {
        console.log('그룹 select item 호출', res)
        this.grpItems = res.data.result
      })

      console.log(
        'this.personInfo.isrgrpIsrtyResVos',
        this.personInfo.isrgrpIsrtyResVos
      )

      // 수정으로 들어온 데이터 적용 value값으로 매칭.
      if (this.personInfo.isrgrpIsrtyResVos.length <= 0) {
        return
      }
      const gpNames = this.personInfo.isrgrpIsrtyResVos
      for (let i = 0; i < gpNames.length; i++) {
        const grpid = gpNames[i].isrgrpId
        for (let j = 0; j < this.grpItems.length; j++) {
          const item = this.grpItems[j]
          if (item.isrgrpId === grpid) {
            this.grpValues.push(item.isrgrpId)
          }
        }
      }
    },
    // 회사 select itme 호출
    initCompanyItems() {
      // http://10.220.140.208:8090/isrty/upper-psitn-orgnzts?incdntId=1160100000000000373
      //       {
      //   "code": "200",
      //   "msg": "정상처리 되었습니다.",
      //   "result": [
      //     {
      //       "upperIsrtyPsitnOrgnztId": "18",
      //       "upperIsrtyPsitnOrgnztNm": "삼성전자",
      //       "isrtyPsitnOrgnztId": "20",
      //       "isrtyPsitnOrgnztNm": "LCD사업부"
      //     }
      //   ]
      // }
      this.apiUrl = '/isrty/upper-psitn-orgnzts'
      this.apiType = 'analysis'
      this.apiParams = StringUtils.objQueryString({
        incdntId: this.incidentInfo.id,
        isrtyId: this.personInfo.isrtyId
      })

      this.requestApiAsync((res) => {
        console.log('회사 select itme 호출', res)
        this.companyItems = res.data.result
      })

      // 넘어온 회사 값이 있다면 매칭.
      if (this.personInfo.upperIsrtyPsitnOrgnztId) {
        this.companyItems.forEach((item) => {
          if (
            this.personInfo.upperIsrtyPsitnOrgnztId ===
            item.upperIsrtyPsitnOrgnztId
          ) {
            this.companyItem = item.upperIsrtyPsitnOrgnztId
          }
        })
      } else {
        this.companyItem = 1
      }
      if (!this.companyItem) {
        this.initDivisions(1)
      } else {
        this.initDivisions(this.companyItem)
      }
    },
    // 부서 select item 호출
    initDivisions(upperIsrtyPsitnOrgnztId) {
      console.log('부서 select item 호출', upperIsrtyPsitnOrgnztId)
      // http://10.220.140.208:8090/isrty/psitn-orgnzts?incdntId=1160100000000000373&isrtyPsitnOrgnztId=13
      //     {
      //   "code": "200",
      //   "msg": "정상처리 되었습니다.",
      //   "result": [
      //     {
      //       "upperIsrtyPsitnOrgnztId": "18",
      //       "upperIsrtyPsitnOrgnztNm": "삼성전자"
      //     }
      //   ]
      // }
      this.apiUrl = '/isrty/upper-psitn-orgnzts'
      this.apiType = 'analysis'
      this.apiParams = StringUtils.objQueryString({
        incdntId: this.incidentInfo.id,
        isrtyId: this.personInfo.isrtyId,
        isrtyPsitnOrgnztId: upperIsrtyPsitnOrgnztId
      })

      this.requestApiAsync((res) => {
        console.log('회사 select itme 호출', res)
        this.departmentItems = res.data.result
      })
      // let filter = `?comId=${comId}`
      // this.$api.private
      //   .get('/api/person-management/divisions' + filter)
      //   .then((res) => {
      //     this.departmentItems = res.data.rows
      //     // 넘어온 데이타 매칭
      //     if (this.personInfo.divName) {
      //       this.departmentItems.forEach((item) => {
      //         if (this.personInfo.divName === item.divName) {
      //           this.departmentItem = item.divId
      //         }
      //       })
      //     }
      //   })
      //   .catch((err) => {
      //     console.log('/api/person-management/divisions', err)
      //   })
    },
    // 인물이름으로 인물중복 확인창 호출
    dialogPersonSearchShow() {
      if (this.visible) {
        this.$emit('dialog-person-search-show', this.personInfo.isrtyNm)
      }
    },
    // 회사를 변경시 부서 정보 호출
    onCompanyChange(upperIsrtyPsitnOrgnztId) {
      this.initDivisions(upperIsrtyPsitnOrgnztId)
    },
    // 수정 / 등록 요청시.
    onOk() {
      if (!this.personInfo.isrtyNm) {
        this.$toast.error('입력된 이름이 없습니다.')
        return
      }
      if (!this.personInfo.isrtyPrsnTyCode) {
        this.$toast.error('선택된 인물유형이 없습니다.')
        return
      }

      /**
       * 인물 no키로 신규구분
       */
      if (!this.personInfo.isrtyId) {
        // 신규 인물 등록
        this.joinPerson(this.personFilter)
      } else {
        // 인물 수정
        this.updatePerson(this.personFilter)
      }
    },
    // 입력하려는 정보가 사용중인 인물이 있는지 확인.
    onFileSearch(index, contactType) {
      this.contactItemIndex = index
      this.contactType = contactType
      this.$emit('dialog-source-file-search-show', contactType)
    },
    // 사용중인 인물이 없는 정보 등록
    addSourceFile(traget) {
      if (traget.some((item) => item.text === this.contactItem.text)) {
        this.$toast.error('중복된 내용입니다.')
        return
      }
      traget.splice(this.contactItemIndex, 1, {
        ...this.contactItem
      })
      this.$toast('등록되었습니다.')
    },
    // 이미지 업로드
    onUploadImg(e) {
      if (!e) {
        return
      }
      this.personInfo.photo = URL.createObjectURL(this.files)
    },
    // 이미지를 클릭시 이미지 업로드
    onClickImg() {
      this.$refs.refFileInput.$el.querySelector('.v-file-input__text').click()
    },
    // 인물유형
    personType(ptName) {
      let res = 'NCL'
      switch (ptName) {
        case '피의자':
          res = 'SUSPCT'
          break
        case '혐의자':
          res = 'SUSPIC'
          break
        case '참고인':
          res = 'REFE'
          break
        case '피해자':
          res = 'SUFRER'
          break
        case '기타':
          res = 'ETC'
          break
        default:
          res = 'NCL' // 미분류
          break
      }
      return res
    },
    // 신규인물등록
    joinPerson(personFilter) {
      console.log('신규인물등록', personFilter)
      // this.$api.private
      //   .post('/api/person-management/person' + personFilter)
      //   .then((res) => {
      //     console.log('res', res)
      //     // 그룹등록(다수)
      //     if (this.grpValues.length > 0) {
      //       this.updateGroup(res.data.currentNo)
      //     }
      //     // 전화번호등록(다수)
      //     if (this.phoneNumberTexts.length > 0) {
      //       this.updatePhoneNumbers(res.data.currentNo)
      //     }
      //     // 이메일등록(다수)
      //     if (this.emailTexts.length > 0) {
      //       this.updateEmails(res.data.currentNo)
      //     }

      //     setTimeout(() => {
      //       this.$toast(`새로운 인물로 추가 되었습니다.`)
      //       this.$emit('update-now')
      //       this.$emit('update:visible', !this.visible)
      //     }, 500)
      //   })
    },
    // 인물수정
    updatePerson(personFilter) {
      console.log('인물수정', personFilter)
      // personFilter += `&no=${this.person.no}`
      // // 그룹등록(다수)
      // this.updateGroup(this.person.no)
      // // 전화번호등록(다수)
      // this.updatePhoneNumbers(this.person.no)
      // // 이메일등록(다수)
      // this.updateEmails(this.person.no)

      // this.$api.private
      //   .patch('/api/person-management/person' + personFilter)
      //   .then((res) => {
      //     console.log('res', res)

      //     setTimeout(() => {
      //       this.$toast(`정보가 수정 되었습니다.`)
      //       this.$emit('update-now')
      //       this.$emit('update:visible', !this.visible)
      //     }, 500)
      //   })
    },
    // 그룹업데이트
    updateGroup(personNo) {
      console.log('그룹업데이트', personNo)
      // 인물의 그룹 삭제
      // this.$api.private
      //   .delete(`/api/person-management/persons/groups?no=${personNo}`)
      //   .then((res1) => {
      //     if (res1.statusText !== 'OK') {
      //       this.$toast.error('그룹등록이 실패 했습니다.')
      //       return
      //     }
      //     let filter2 = '?'
      //     filter2 += `pmId=${personNo}`
      //     filter2 += '&pgId='
      //     filter2 += this.grpValues.join('&pgId=')

      //     this.$api.private
      //       .post(`/api/person-management/persons/groups${filter2}`)
      //       .then((res2) => {
      //         if (res2.statusText !== 'OK') {
      //           this.$toast.error('그룹등록이 실패 했습니다.')
      //           return
      //         }
      //       })
      //   })
    },
    // 전화번호(다수) 업데이트
    updatePhoneNumbers(currentNo) {
      console.log('전화번호(다수) 업데이트', currentNo)
      // let filter = `?pmId=${currentNo}`
      // this.phoneNumberTexts.forEach(function(item, i) {
      //   filter += '&pnId='
      //   filter += i + 1
      //   filter += '&phoneNumber='
      //   filter += item
      // })
      // // 기존전화번호 삭제
      // this.$api.private
      //   .delete(`/api/person-management/phoneNumbers?pmId=${currentNo}`)
      //   .then((res) => {
      //     console.log('기존전화번호모두삭제완료', res)

      //     this.$api.private
      //       .post(`/api/person-management/phoneNumbers${filter}`)
      //       .then((res) => {
      //         console.log('새로운전화번호추가완료', res)
      //       })
      //   })
    },
    // 메일(다수) 업데이트
    updateEmails(currentNo) {
      console.log('메일(다수) 업데이트', currentNo)
      // let filter = `?pmId=${currentNo}`
      // this.emailTexts.forEach(function(item, i) {
      //   filter += '&emId='
      //   filter += i + 1
      //   filter += '&email='
      //   filter += item
      // })

      // // 기존이메일 삭제
      // this.$api.private
      //   .delete(`/api/person-management/emails?pmId=${currentNo}`)
      //   .then((res) => {
      //     console.log('기존이메일모두삭제완료', res)
      //     this.$api.private
      //       .post(`/api/person-management/emails${filter}`)
      //       .then((res) => {
      //         console.log('새로운이메일추가완료', res)
      //       })
      //   })
    },
    // 전화번호들을 호출
    getPhoneNumbers() {
      if (!this.person.no) {
        return
      }
      // this.$api.private
      //   .get(`/api/person-management/phoneNumbers?pmId=${this.person.no}`)
      //   .then((res) => {
      //     // 4개는 항목은 유지
      //     res.data.rows.forEach((item, i) => {
      //       if (i < 4) {
      //         this.phoneNumbers[i].text = item.phoneNumber
      //       } else {
      //         this.phoneNumbers.push({ text: item.phoneNumber })
      //       }
      //     })
      //   })
      //   .catch((err) => console.log('전화번호 호출 err', err))
    },
    // 이메일 주소들을 호출
    getEmails() {
      if (!this.person.no) {
        return
      }
      //   this.$api.private
      //     .get(`/api/person-management/emails?pmId=${this.person.no}`)
      //     .then((res) => {
      //       console.log('이메일 주소들호출', res)
      //       // 4개는 항목은 유지
      //       res.data.rows.forEach((item, i) => {
      //         if (i < 4) {
      //           this.emails[i].text = item.email
      //         } else {
      //           this.emails.push({ text: item.email })
      //         }
      //       })
      //     })
      //     .catch((err) => console.log('이메일 호출 err', err))
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>
