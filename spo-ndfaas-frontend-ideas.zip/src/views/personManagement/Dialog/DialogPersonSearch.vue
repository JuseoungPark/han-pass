<template>
  <dea-dialog
    v-model="visible"
    title="중복확인"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text word-break fontsize-big3 pa-4">
                등록하고자 하는 인물이 있는지 확인해주세요.
              </div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-text-field
                v-model.trim="personName"
                placeholder="인물을 입력하세요"
                :error="isError"
              ></dea-text-field>
              <dea-button
                color="primary"
                prepend-icon="mdi-magnify"
                @click="onSearch"
                >검색</dea-button
              >
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <template slot="title">검색 결과({{ total }})</template>
          <dea-grid
            ref="refDialogPersonSearchGrid"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
            @cellButtonClicked="onCellButtonClicked"
          ></dea-grid>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-card class="align-center">
          <template slot="sub-title" v-if="total"
            >신규 인물 등록을 취소하고 선택한 인물의 수정화면으로
            이동하시겠습니까?
          </template>
          <template slot="sub-title" v-else-if="personName"
            >중복으로 검색되는 인물이 없습니다. 인물 등록을 계속 진행해주세요
          </template>
          <template slot="sub-title" v-else></template>
        </dea-card>
      </div>
    </section>
    <div class="btn-group" v-if="total">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOkMod">확인</dea-button>
      </v-col>
    </div>
    <div class="btn-group" v-else-if="personName">
      <v-col class="align-center">
        <dea-button color="primary" @click="onOkReg">확인</dea-button>
      </v-col>
    </div>
    <div class="btn-group" v-else>
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
// import { StringUtils } from '@/utils/StringUtils.js'
import CellButton from '@/components/grid/CellButton'

export default {
  name: 'DialogPersonSearch',
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    name: {
      type: String,
      default: undefined
    },
    personSearch: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      personName: '', // 조회할 이름(검색란)
      // filter: '', // 조회시 필터
      isError: false, // 입력란 에러표시 여부
      total: 0, // 조회된 인물수
      gridInfo: {
        count: 0,
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        columns: [
          // {
          //   headerName: '',
          //   field: 'header-00',
          //   width: 20,
          //   headerCheckboxSelection: true,
          //   headerCheckboxSelectionFilteredOnly: true,
          //   checkboxSelection: true
          // },
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            sortable: true,
            unSortIcon: true,
            hide: true,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'name',
            width: 150,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물유형',
            field: 'ptName',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '전화번호',
            field: 'phoneNumber',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '별칭',
            field: 'nickname',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'pgName',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '회사',
            field: 'comName',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '부서',
            field: 'divName',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록일',
            field: 'joinDate',
            width: 200,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'updateDate',
            width: 200,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '메모',
            field: 'memo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '키워드',
            field: 'keyword',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '기능',
            field: '',
            width: 150,
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              text: true,
              color: 'primary',
              event: 'person-info'
            },
            valueGetter() {
              return '인물정보보기'
            }
          }
        ]
      }
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0
        this.$emit('update:name', undefined)
        this.isError = false
        this.personName = ''
        this.total = 0
        this.$refs.refDialogPersonSearchGrid.rowData = null
      } else {
        if (!this.name) {
          return
        }
        this.personName = this.name
        this.api(this.name)
      }
    },
    personName() {
      this.isError = false
    }
  },
  methods: {
    onOkMod() {
      const rows = this.$refs.refDialogPersonSearchGrid.gridApi.getSelectedRows()
      if (!rows.length) {
        this.$toast.error('선택된 인물이 없습니다.')
        return
      }
      this.$toast.error(
        `인물수정 창으로 이동합니다. ${rows[0].name}(인물정보)로 입력되었습니다.`
      )
      this.$emit('person-registration', rows[0])
      this.$emit('update:visible', !this.visible)
    },
    onOkReg() {
      // this.$toast('새로운 인물로 등록합니다. 인물이름과 정보를 입력해주세요.')
      this.$emit('update:visible', !this.visible)
    },
    // 그리드 내부 버튼 클릭시.
    onCellButtonClicked(params) {
      console.log('params', params)
      if (params.event == 'person-info') {
        this.$emit('dialog-individual-show', params)
      }
    },
    onSearch() {
      if (!this.personName) {
        this.$toast.error('입력된 정보가 없습니다.')
        this.isError = true
        return
      }
      if (!this.$refs.refDialogPersonSearchGrid) {
        return
      }

      this.api(this.personName)
    },
    api(name) {
      // this.filter = StringUtils.objQueryString({ name: this.personName })

      // 전화번호 검색 결과 표시.
      let api = '/api/person-management/persons'
      api += '?page=1'
      api += '&limit=10000'
      api += '&name='
      api += name
      this.$api.private.get(api).then((res) => {
        if (!res.data.rows) {
          return
        }
        this.total = res.data.total
        this.$refs.refDialogPersonSearchGrid.setRowData(res.data.rows)
      })
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
