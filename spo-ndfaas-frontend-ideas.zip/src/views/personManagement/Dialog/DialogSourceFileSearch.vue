<template>
  <dea-dialog
    v-model="visible"
    title="중복 확인"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text word-break fontsize-big3 pa-4">
                입력하고자 하는 정보가 있는지 확인합니다.
              </div>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-text-field
                v-model.trim="keyword"
                :placeholder="`${contactType}를 입력하세요`"
                :error="isError"
                @keyup="checkTelNumber"
              ></dea-text-field>
              <dea-button
                color="primary"
                prepend-icon="mdi-magnify"
                @click="onSearch"
                >검색</dea-button
              >
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <section v-if="!isSearch" class="dea-section">
      <div class="inner">
        <dea-card>
          <v-layout
            v-if="names"
            class="text word-break fontsize-big3 align-center"
          >
            {{ names }}(인물이름)에 등록되어 있습니다.
          </v-layout>
          <v-layout v-else class="text word-break fontsize-big3 align-center">
            검색결과가 없습니다. 등록합니다.
          </v-layout>
        </dea-card>
      </div>
    </section>
    <div class="btn-group" v-if="!isSearch">
      <v-col class="d-flex align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button v-if="!names" color="primary" @click="onOk"
          >확인</dea-button
        >
      </v-col>
    </div>
    <div class="btn-group" v-else>
      <v-col class="d-flex align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'

export default {
  name: 'DialogSourceFileSearch',
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    contactType: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      // flase 검색후
      isSearch: true,
      isError: false,
      // 번호나 주소 추출파일정보
      contactItem: {
        text: ''
      },
      // 입력값
      keyword: '',
      // 검색된 인물정보
      names: '',
      persons: []
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        this.contactItem.text = ''
        this.isError = false
        this.isSearch = true
        this.keyword = ''
        this.names = ''
        this.persons = []

        this.$emit('update:contactType', '')
      }
    },
    keyword() {
      this.isError = false
      this.isSearch = true
      this.names = ''
    }
  },
  computed: {},
  methods: {
    onSearch() {
      if (!this.keyword) {
        this.$toast.error('입력된 정보가 없습니다.')
        this.isError = true
        return
      }
      console.log('검사전', this.keyword)
      if (!this.keywordErrors()) {
        console.log('검사후', this.keyword)
        this.$toast.error(`유효하지 않는 ${this.contactType}입니다`)
        this.isError = true
        return
      }

      // 전화번호 검색 결과 표시.
      let api = '/api/person-management/persons'
      api += '?page=1'
      api += '&limit=1000'
      api += '&keyword='
      api += this.keyword
      this.$api.private.get(api).then((res) => {
        // console.log('전화번호나 메일주소로 인물검색 res', res)
        if (!res.data.rows) {
          return
        }
        this.persons = res.data.rows.map((row) => row.name)
        this.names = this.persons.join(', ')
        this.isSearch = false
        // console.log('전화번호나 메일주소로 인물검색', this.persons)
      })
    },
    onOk() {
      if (!this.keyword) {
        this.$toast.error('입력된 정보가 없습니다.')
        this.isError = true
        return
      }
      this.contactItem.text = this.keyword
      this.$emit('source-file-search-data', { ...this.contactItem })
      this.$emit('update:visible', !this.visible)
    },
    keywordErrors() {
      let isOk = false
      switch (this.contactType) {
        case '전화번호':
          isOk = StringUtils.isTelNumber(this.keyword)
          break
        case '이메일':
          isOk = StringUtils.isEmailAddress(this.keyword)
          break

        default:
          console.log('contactType이 다름:', this.contactType)
          break
      }

      return isOk
    },
    // 전화번호 '-'자동 입력
    checkTelNumber() {
      if (this.contactType === '전화번호') {
        // e.target.value = StringUtils.getPhoneMask(e.target.value)
        this.keyword = StringUtils.getPhoneMask(this.keyword)
      }
    },
    // 상단 오른쪽 X표버튼으로 닫기
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
