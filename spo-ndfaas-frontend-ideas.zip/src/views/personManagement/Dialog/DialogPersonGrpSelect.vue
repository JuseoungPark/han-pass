<template>
  <dea-dialog
    v-model="visible"
    title="인물그룹지정"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <template slot="title">선택한 인물</template>
          <dea-grid
            ref="personGrpSelectGrid"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
          >
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <template slot="title">그룹지정</template>
          <template slot="sub-title"
            >새로운 그룹을 생성하려면 그룹관리 기능을 이용해주세요.</template
          >
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-select
                v-model="grpValues"
                :items="grpItems"
                label="그룹명 선택"
                multiple
                deaPrependSelectAll
                item-text="isrgrpNm"
                item-value="isrgrpId"
                placeholder="인물 그룹을 선택해 주세요"
              >
              </dea-select>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOk">저장</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DialogPersonGrpSelect',
  mixins: [apiMixin],
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    params: {
      type: Array,
      default: undefined
    }
  },
  data() {
    return {
      isShow: false,
      grpItems: [],
      grpValues: [],
      gridInfo: {
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150
          },
          {
            headerName: '사진',
            field: 'photo',
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160
          },
          {
            headerName: '인물유형코드',
            field: 'isrtyPrsnTyCode',
            width: 160,
            hide: true
          },
          {
            headerName: '전화번호(대표)',
            field: 'rprsTelno',
            width: 160,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'telno',
            width: 160
          },
          {
            headerName: '별칭',
            field: 'rprsIsrtyNcm'
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            hide: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            hide: true
          },
          {
            headerName: '등록일',
            field: 'firstRegDt',
            width: 190,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            hide: true
          }
        ]
      }
    }
  },
  updated() {
    this.addData()
  },
  watch: {
    visible() {
      if (!this.visible) {
        this.grpValues = []
        this.grpItems = []
        this.isShow = false
        document.querySelector('.v-dialog--active').scrollTop = 0
      } else {
        this.getGrpItems()
      }
    },
    params() {
      this.addData()
      console.log('그룹지정 넘어온 데이터 this.params', this.params)
    }
  },
  computed: {
    getIsrgrpId() {
      return this.grpValues.map((values) => {
        return { isrgrpId: values }
      })
    },
    getIsrtyId() {
      return this.params.map((param) => {
        return { isrtyId: param.isrtyId }
      })
    }
  },
  methods: {
    addData() {
      if (this.$refs.personGrpSelectGrid) {
        this.$refs.personGrpSelectGrid.rowData = this.params
      }
      // console.log(this.selectedPersons)
    },
    getGrpItems() {
      // http://10.220.140.208:8090/isrty/isrgrps?incdntId=1160100000000000544

      this.apiUrl = '/isrty/isrgrps'
      this.apiParams = StringUtils.objQueryString({
        // incdntId: this.incidentInfo.id
      })

      this.requestApiAsync((res) => {
        console.log('그룹리스트 호출 완료 res', res)
        this.grpItems = res.data.result
      })
    },
    onOk() {
      // console.log('incdntId', this.incidentInfo.id)
      // console.log('isrtyIsrgrpIsrgrpsPostReqVos', this.getIsrgrpId)
      // console.log('isrtyIsrgrpIsrtysPostReqVos', this.getIsrtyId)

      console.log({
        incdntId: this.incidentInfo.id,
        isrtyIsrgrpIsrgrpsPostReqVos: this.getIsrgrpId,
        isrtyIsrgrpIsrtysPostReqVos: this.getIsrtyId
      })

      this.apiUrl = '/isrty/isrty-isrgrp'
      this.$api.analysis
        .post(this.apiUrl, {
          incdntId: this.incidentInfo.id,
          isrtyIsrgrpIsrgrpsPostReqVos: this.getIsrgrpId,
          isrtyIsrgrpIsrtysPostReqVos: this.getIsrtyId
        })
        .then((res) => {
          if (res.data.code !== '200') {
            this.$toast.error('그룹등록이 실패 했습니다.')
            return
          }
          this.$emit('update-now')
          this.$emit('update:visible', !this.visible)
          this.$toast('그룹으로 등록되었습니다.')
        })
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>
