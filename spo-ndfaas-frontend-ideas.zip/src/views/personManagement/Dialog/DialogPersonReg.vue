<template>
  <dea-dialog
    v-model="visible"
    title="인물등록"
    width="600px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <v-row no-gutters>
          <v-col class="d-flex align-center">
            <div class="text info-message fontsize-big3 font-bold pa-8">
              인물을 등록하기 위한 방식을 선택해 주세요.
            </div>
          </v-col>
        </v-row>
        <div class="divide space-around">
          <v-col cols="5">
            <v-card
              class="dea-card-field active align-center valign-middle"
              height="150"
              @click="dialogIndividualRegShow"
            >
              <v-card-title class="text-truncate-none fontsize-big3 pa-4"
                >개별등록</v-card-title
              >
              <v-card-subtitle class="text-truncate-none word-break pa-4">
                각 인물을 개별적으로 수동 등록합니다.</v-card-subtitle
              >
            </v-card>
          </v-col>
          <v-col cols="5">
            <v-card
              class="dea-card-field active align-center valign-middle"
              height="150"
              @click="onDialogPersonBatchRegShow"
            >
              <v-card-title class="text-truncate-none fontsize-big3 pa-4"
                >일괄등록</v-card-title
              >
              <v-card-subtitle class="text-truncate-none word-break pa-4">
                표준서식을 사전에 작성하여 일괄 등록합니다.</v-card-subtitle
              >
            </v-card>
            <v-row no-gutters>
              <v-col class="d-flex align-center">
                <div class="text"><a href="#">표준서식 다운받기</a></div>
              </v-col>
            </v-row>
          </v-col>
        </div>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >닫기</dea-button
        >
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
export default {
  name: 'DialogPersonReg',
  props: {
    visible: {
      ttype: Boolean,
      require: true,
      default: false
    }
  },
  data() {
    return {}
  },
  methods: {
    dialogIndividualRegShow() {
      this.$emit('dialog-individual-reg-show')
      this.$emit('update:visible', !this.visible)
    },
    onDialogPersonBatchRegShow() {
      this.$emit('dialog-person-batch-reg-show')
      this.$emit('update:visible', !this.visible)
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
