<template>
  <dea-dialog
    v-model="visible"
    title="인물병합"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid
            ref="refPersonMergeGrid"
            :columns="gridInfo.columns"
            :config="gridInfo.config"
            row-selection-multiple
            suppress-row-click-selection
            disableAutoLoad
            @ready="onReady"
            @cellButtonClicked="onCellButtonClicked"
          >
            <template #header-right>
              <v-col class="d-flex align-right">
                <div class="text">선택한 인물</div>
                <dea-button outlined @click="onDelete">제외</dea-button>
              </v-col>
            </template>
          </dea-grid>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div v-if="represent.isrtyNm" class="text fontsize-big3 pa-4">
                위의 인물 목록을 {{ represent.isrtyNm }}이(가) 대표자로
                병합합니다.
              </div>
              <div v-else class="text fontsize-big3 pa-4">
                위의 인물 목록을 병합합니다.
              </div>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOk">확인</dea-button>
        <!-- <dea-button>미리보기</dea-button> -->
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import CellButton from '@/components/grid/CellButton'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DialogPersonMerge',
  mixins: [apiMixin],
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    params: {
      default: undefined
    }
  },
  data() {
    return {
      rowData: [],
      represent: {}, // 선택된 대표자 정보.
      gridInfo: {
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 5
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: '열 선택',
            field: 'rowSelector',
            width: 20,
            headerComponentFramework: CellCheckboxHeader,
            cellRendererFramework: CellCheckbox
          },
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true
            // cellRendererFramework: CellButton,
            // cellRendererParams: {
            //   text: true,
            //   color: 'primary',
            //   event: 'person-info'
            // }
          },
          {
            headerName: '사진',
            field: 'photo',
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물유형코드',
            field: 'isrtyPrsnTyCode',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'rprsTelno',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '전화번호',
            field: 'telno',
            width: 160,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '별칭',
            field: 'rprsIsrtyNcm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물그룹',
            field: 'isrgrpNm',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '회사',
            field: 'upperIsrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '부서',
            field: 'isrtyPsitnOrgnztNm',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '등록일',
            field: 'firstRegDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '수정일',
            field: 'lastChgDt',
            width: 190,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '등록자',
            field: 'registeredUser',
            width: 135,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '증거번호',
            field: 'evidenceNumber',
            width: 160,
            sortable: true,
            unSortIcon: true,
            hide: true
          },
          {
            headerName: '대표자',
            field: 'represent',
            width: 85,
            sortable: true,
            unSortIcon: true,
            cellRendererFramework: CellButton,
            cellRendererParams: {
              outlined: true,
              label: '선택',
              event: 'person-represent'
            }
          }
        ]
      }
    }
  },
  // updated() {
  //   this.addData()
  // },
  watch: {
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0
        this.represent = {}
        this.$emit('update:params', undefined)
      }
    },
    params() {
      // 넘어온 데이터 그리드에 입력
      this.initData()
    }
  },
  methods: {
    onReady() {
      this.initData()
    },
    initData() {
      // 최초 로딩시 그리드 미준비시.
      if (!this.$refs.refPersonMergeGrid) {
        return
      }
      console.log('병함 등록된 데이타', this.params)
      this.$refs.refPersonMergeGrid.rowData = this.params
    },
    // 그리드 > 대표자 선택 버튼
    onCellButtonClicked(params) {
      if (params.event == 'person-represent') {
        console.log('memberRows', params)
        this.represent = params.data
      }
    },
    // 인물병합 팝업창 > 인물제외
    onDelete() {
      const rows = this.$refs.refPersonMergeGrid.gridApi.getSelectedRows()
      if (!rows.length) {
        this.$toast.error('선택된 인물이 없습니다.')
        return
      }
      // 삭제대상이 대표자 일때 대표자 초기화.
      if (rows.some((row) => row.isrtyId === this.represent.isrtyId)) {
        this.represent = {}
      }
      // 그리드의 rowData index로 직접 삭제
      rows.forEach((row) => {
        const findItem = this.$refs.refPersonMergeGrid.rowData.find(
          (rowData) => rowData.isrtyId == row.isrtyId
        )
        const rowIndex = this.$refs.refPersonMergeGrid.rowData.indexOf(findItem)

        if (rowIndex > -1) {
          this.$refs.refPersonMergeGrid.rowData.splice(rowIndex, 1)
        }
      })
    },
    // 인물병합 >
    onOk() {
      const rows = this.$refs.refPersonMergeGrid.rowData

      if (rows.length <= 1) {
        this.$toast.error('병합할 인물이 없습니다.')
        return
      } else if (!this.represent.isrtyNm) {
        this.$toast.error('대표자로 선택된 인물이 없습니다.')
        return
      }

      // 대표인물 제외한 맴버리스트 처리.
      // const memberRows = rows
      //   .filter((row) => row.isrtyId !== this.represent.isrtyId)
      //   .map((row) => {
      //     return {
      //       isrtyId: row.isrtyId,
      //       isrtyNm: row.isrtyNm,
      //       isrtyType: row.isrtyPrsnTyCode
      //     }
      //   })
      // console.log('memberRows', memberRows)

      // 대표인물 포함한 맴버리스트 처리.
      const memberRows = rows.map((row) => {
        return {
          isrtyId: row.isrtyId,
          isrtyNm: row.isrtyNm,
          isrtyType: row.isrtyPrsnTyCode
        }
      })
      console.log('memberRows', memberRows)

      // todo : 인물병합 전송
      this.$api.analysis
        .post('/isrty/mrg-isrty', {
          incdntId: this.incidentInfo.id,
          isrtyId: this.represent.isrtyId,
          isrtyReqVos: memberRows
        })
        .then((res) => {
          console.log('병합결과', res)
          if (res.data.code === '200') {
            this.$toast(
              `${this.represent.isrtyNm}이(가) 대표자로 병합되었습니다.`
            )
          } else {
            this.$toast.error(`병합에 실패했습니다.`)
          }

          this.$emit('update-now')
          this.$emit('update:visible', !this.visible)
        })
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>
