<template>
  <dea-dialog
    v-model="visible"
    title="회사/부서관리"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <dea-text-field
                v-model="addCompanyItemName"
                placeholder="회사명을 입력해주세요"
                @keydown.enter="addCompanyItem"
              ></dea-text-field>
              <dea-button @click="addCompanyItem">추가</dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
      <div class="inner">
        <dea-card>
          <v-list dense height="480" class="overflow-y-auto box-wrap">
            <v-list-group
              v-for="(companyItem, index) in companyItems"
              :key="index"
              sub-group
            >
              <template v-slot:activator>
                <v-list-item-content
                  class="flex-row"
                  @click="removeCompanyItem($event, index)"
                >
                  <v-list-item-title
                    v-text="companyItem.comName"
                  ></v-list-item-title>
                  <v-list-item-action>
                    <dea-button
                      icon
                      outlined
                      prepend-icon="mdi-close"
                    ></dea-button>
                  </v-list-item-action>
                </v-list-item-content>
              </template>
              <v-list-item-group>
                <v-list-item
                  v-for="(departmentItem, i) in companyItems[index][
                    'departmentItems'
                  ]"
                  :key="i"
                >
                  <template>
                    <v-list-item-content
                      class="flex-row"
                      @click="removeDepartmentItem($event, index, i)"
                    >
                      <v-list-item-title
                        v-text="departmentItem.divName"
                      ></v-list-item-title>
                      <v-list-item-action>
                        <dea-button
                          icon
                          outlined
                          prepend-icon="mdi-close"
                        ></dea-button>
                      </v-list-item-action>
                    </v-list-item-content>
                  </template>
                </v-list-item>
                <v-list-item>
                  <v-list-item-content class="flex-row">
                    <v-list-item-title>
                      <v-row no-gutters>
                        <v-col class="d-flex">
                          <dea-text-field
                            v-model="companyItems[index].addDepartmentItemName"
                            placeholder="부서를 입력해주세요"
                            @keydown.enter="addDepartmentItem(index)"
                          ></dea-text-field>
                        </v-col>
                      </v-row>
                    </v-list-item-title>
                    <v-list-item-action>
                      <dea-button @click="addDepartmentItem(index)"
                        >추가</dea-button
                      >
                    </v-list-item-action>
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list-group>
          </v-list>
        </dea-card>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >닫기</dea-button
        >
        <!-- <dea-button outlined @click="$emit('update:visible', !visible)"
          >취소</dea-button
        >
        <dea-button color="primary" @click="onOk">확인</dea-button> -->
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
export default {
  name: 'DialogCompanyDepartMgmt',
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    },
    params: {
      type: Object,
      default: undefined
    }
  },
  data() {
    return {
      addCompanyItemName: '',
      companyItems: [],
      departmentItems: []
      // newCompanyItems: [],
      // newDepartmentItems: []
      // companyItems: [
      //   {
      //     text: '0_SS그룹',
      //     value: '0_SS그룹',
      //     departmentItems: [
      //       { text: '0_기획팀', value: '0_기획팀' },
      //       { text: '0_사업관리', value: '0_사업관리' },
      //       { text: '0_회계팀', value: '0_회계팀' }
      //     ],
      //     addDepartmentItemName: ''
      //   },
      //   {
      //     text: '1_SS(주)',
      //     value: '1_SS(주)',
      //     departmentItems: [
      //       { text: '1_기획팀', value: '1_기획팀' },
      //       { text: '1_사업관리', value: '1_사업관리' },
      //       { text: '1_회계팀', value: '1_회계팀' }
      //     ],
      //     addDepartmentItemName: ''
      //   },
      //   {
      //     text: '2_SS전자',
      //     value: '2_SS전자',
      //     departmentItems: [
      //       { text: '2_기획팀', value: '2_기획팀' },
      //       { text: '2_사업관리', value: '2_사업관리' },
      //       { text: '2_회계팀', value: '2_회계팀' }
      //     ],
      //     addDepartmentItemName: ''
      //   }
      // ]
      // departmentItems: [
      //   { text: '기획팀' },
      //   { text: '사업관리' },
      //   { text: '회계팀' }
      // ]
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        this.addCompanyItemName = ''
        this.companyItems = []
        this.departmentItems = []
        this.$emit('update:params', {})
      } else {
        this.initData()
      }
    },
    companyItems() {
      this.$emit('update-now')
    }
  },
  methods: {
    // 회사와 부서 데이타로 트리뷰 만듬.
    initData() {
      const makeTreery = (arrayData) => {
        const companyItems = arrayData[0] // 회사 리스트
        const departmentItems = arrayData[1] // 부서 리스트
        companyItems.forEach((companyItem) => {
          const comId = companyItem.comId
          companyItem['departmentItems'] = departmentItems.filter(
            (item) => item.comId === comId
          )
        })
        return companyItems
      }

      Promise.all([
        this.$api.private
          .get('/api/person-management/companys')
          .then((result) => {
            return result.data.rows
          }),
        this.$api.private
          .get('/api/person-management/divisions')
          .then((res) => {
            return res.data.rows
          })
      ]).then((arrayData) => {
        this.companyItems = makeTreery(arrayData)
      })
    },
    // 회사명 추가
    addCompanyItem() {
      const index = this.companyItems.length + 1 // 1부터시작시 length + 1 // 0부터시작시 length
      const comName = this.addCompanyItemName
      if (this.companyItems.some((item) => item.comName === comName)) {
        this.$toast.error('이미 추가된 회사 이름입니다.')
        return
      }

      const newItem = {
        comId: index,
        comName: comName,
        departmentItems: []
      }

      let filter = `?comId=${index}&comName=${comName}`
      this.$api.private
        .post('/api/person-management/company' + filter)
        .then((res) => {
          console.log('회사 등록', res)
          this.companyItems.push(newItem)
          this.addCompanyItemName = '' // 등록된 회사 이름 초기화
          this.$toast.error(`${comName}(로) 회사이름을 등록했습니다.`)
        })
        .catch((err) => this.$toast(`${err}가 발생했습니다.`))
    },
    // 부서명 추가
    addDepartmentItem(index) {
      const companyItem = this.companyItems[index]
      const divItems = companyItem.departmentItems
      const divName = companyItem.addDepartmentItemName
      const divId = divItems.length + 1

      if (divItems.some((item) => item.divName === divName)) {
        this.$toast.error('이미 추가된 부서 이름입니다.')
        return
      }

      const newItem = {
        comId: companyItem.comId,
        divId: divId, // 1부터시작시 length + 1 // 0부터시작시 length
        divName: divName
      }

      let filter = `?comId=${companyItem.comId}&divId=${divId}&divName=${divName}`
      this.$api.private
        .post('/api/person-management/division' + filter)
        .then((res) => {
          console.log('부서 등록', res)
          divItems.push(newItem)
          companyItem.addDepartmentItemName = '' // 등록된 부서 이름 초기화
          this.$toast.error(`${divName}(로) 부서이름을 등록했습니다.`)
        })
        .catch((err) => this.$toast(`${err}가 발생했습니다.`))
    },
    removeCompanyItem(e, i) {
      const isIcon = e.target.classList.contains('v-icon')
      if (!isIcon) {
        return
      }
      e.stopPropagation()
      const companyItem = this.companyItems.splice(i, 1)

      let filter = `?comId=${companyItem[0].comId}`
      this.$api.private
        .delete('/api/person-management/company' + filter)
        .then((res) => {
          console.log('회사 삭제', res)
          this.$toast.error(
            `[${companyItem[0].comName}] 회사이름을 삭제했습니다.`
          )
        })
        .catch((err) => this.$toast(`${err}가 발생했습니다.`))
    },
    removeDepartmentItem(e, index, i) {
      const isIcon = e.target.classList.contains('v-icon')
      if (!isIcon) {
        return
      }
      const divisionItem = this.companyItems[index]['departmentItems'].splice(
        i,
        1
      )

      let filter = `?comId=${divisionItem[0].comId}&divId=${divisionItem[0].divId}`
      this.$api.private
        .delete('/api/person-management/division' + filter)
        .then((res) => {
          console.log('부서 삭제', res)
          this.$toast.error(
            `[${divisionItem[0].divName}] 부서이름을 삭제했습니다.`
          )
        })
        .catch((err) => this.$toast(`${err}가 발생했습니다.`))
    },
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped></style>
