<template>
  <dea-dialog
    v-model="visible"
    title="인물그룹관리"
    width="800px"
    @dialog:close="onDialogClose"
  >
    <v-layout class="divide pa-0 ba-0">
      <v-col cols="5">
        <v-card v-scroll.self="onScroll" class="overflow-y-auto" height="240">
          <div v-if="totalNumByGroup.length > 0">
            <v-tabs class="dea-tabs" vertical @change="tabsChange" value="0">
              <v-tab
                v-for="(group, index) in totalNumByGroup"
                :key="index"
                class="align-left"
              >
                <span>{{ `${group.isrgrpNm}(${group.isrtyCnt})` }}</span>
                <dea-button
                  icon
                  outlined
                  prepend-icon="mdi-close"
                  @click="deleteGroup(group)"
                ></dea-button>
              </v-tab>
            </v-tabs>
          </div>
        </v-card>
        <div v-if="totalNumByGroup.length <= 0">
          <v-tabs class="dea-tabs" vertical>
            <v-tab class="align-left">
              <span>등록된 그룹이 없습니다.</span>
            </v-tab>
          </v-tabs>
        </div>
        <section class="dea-section">
          <div class="inner"></div>
          <v-row no-gutters>
            <v-col class="d-flex position-relative">
              <v-snackbar
                :timeout="-1"
                :value="true"
                absolute
                centered
                top
                rounded
                elevation="0"
                color="info"
                class="d-flex"
              >
                <v-icon class="mr-2">mdi-check-bold</v-icon>
                <div class="text word-break">
                  그룹을 삭제하면 해당 그룹으로 등록된 인물의 그룹 정보가
                  초기화됩니다.
                </div>
              </v-snackbar>
            </v-col>
          </v-row>
        </section>
        <section class="dea-section">
          <div class="inner">
            <dea-card>
              <v-row no-gutters>
                <v-col class="d-flex">
                  <dea-text-field
                    v-model.trim="newGroupName"
                    @keydown.enter="addNewGroupName"
                    placeholder="신규 추가할 그룹명을 입력하세요"
                  ></dea-text-field>
                  <dea-button @click="addNewGroupName">추가</dea-button>
                </v-col>
              </v-row>
            </dea-card>
          </div>
        </section>
      </v-col>
      <v-col>
        <section class="dea-section">
          <div class="inner grid-wrap">
            <dea-card>
              <dea-grid
                ref="refPersonGrpMgmtGrid"
                :api="gridInfo.api"
                :columns="gridInfo.columns"
                :config="gridInfo.config"
              ></dea-grid>
            </dea-card>
          </div>
        </section>
      </v-col>
    </v-layout>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button outlined @click="$emit('update:visible', !visible)"
          >닫기</dea-button
        >
        <!-- <dea-button color="primary">확인</dea-button> -->
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DialogPersonGrpMgmt',
  mixins: [apiMixin],
  props: {
    visible: {
      type: Boolean,
      require: true,
      default: false
    }
  },
  data() {
    return {
      personGrpMgmt: false,
      selectedGroupItem: null,
      totalNumByGroup: [],
      newGroupName: '',
      gridInfo: {
        // api: `/api/person-management/groups/persons`,
        api: `/isrty/isrty-isrgrps`,
        config: {
          excelButton: false,
          pagination: {
            limitView: false,
            limit: 8
          },
          height: 'fixed'
        },
        columns: [
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            cellClass: 'align-right'
          },
          {
            headerName: '이름',
            field: 'isrtyNm',
            width: 150,
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '인물유형',
            field: 'isrtyPrsnTyNm',
            width: 160,
            sortable: true,
            unSortIcon: true
          }
        ]
      }
    }
  },
  watch: {
    visible() {
      if (!this.visible) {
        document.querySelector('.v-dialog--active').scrollTop = 0
        this.totalNumByGroup = []
      } else {
        this.init()
      }
    }
  },
  methods: {
    init() {
      // todo : 그룹별 인원수 api
      // http://10.220.140.208:8090/isrty/isrgrps?incdntId=1160100000000000544

      this.apiUrl = '/isrty/isrgrps'
      this.apiParams = StringUtils.objQueryString({
        // incdntId: this.incidentInfo.id
      })

      console.log('그룹별 인원수 호출 init()')

      this.requestApiAsync((res) => {
        console.log('그룹별 인원수 호출', res)
        this.totalNumByGroup = res.data.result
        console.log(this.totalNumByGroup)
        if (!this.totalNumByGroup || !this.totalNumByGroup.length) {
          this.totalNumByGroup = []
          this.getGroupMembers(null)
          return
        }
        // 첫번째 그룹의 인물리스트 호출.
        const isrgrpId = res.data.result[0].isrgrpId
        console.log('첫번째 그룹의 인물리스트 호출 isrgrpId', isrgrpId)
        this.getGroupMembers(isrgrpId)
      })

      // this.$api.private
      //   .get(`/api/person-management/groups/persons-num`)
      //   .then((response) => {
      //     this.totalNumByGroup = response.data.rows
      //     if (!this.totalNumByGroup || !this.totalNumByGroup.length) {
      //       this.totalNumByGroup = []
      //       this.getGroupMembers(null)
      //       return
      //     }
      //     const pgId = response.data.rows[0].pgId
      //     this.getGroupMembers(pgId)
      //   })
    },
    // 그룹 id로 리스트 호출
    getGroupMembers(isrgrpId) {
      if (!isrgrpId) {
        return
      }
      this.apiParams = StringUtils.objQueryString({ isrgrpId: isrgrpId })
      this.$refs.refPersonGrpMgmtGrid.setFilter(this.apiParams)
      this.$refs.refPersonGrpMgmtGrid.loadData()
    },
    deleteGroup(group) {
      this.$confirm(
        `${group.isrgrpNm}그룹을 삭제하면 ${group.isrgrpNm}그룹으로 등록된 인물의 그룹 정보가 초기화됩니다.`
      ).then((confirm) => {
        if (confirm) {
          this.apiUrl = '/isrty/isrgrps'
          this.apiType = 'analysis'
          this.params = `incdntId=${group.isrgrpId}`

          // todo: 인물그룹 삭제 api
          this.requestApi((res) => {
            this.totalNumByGroup = res.data.result
            this.$emit('update-now')
          })
        }
      })
    },
    tabsChange(index) {
      if (index === undefined) {
        return
      }
      let isrgrpId = this.totalNumByGroup[index].isrgrpId
      this.getGroupMembers(isrgrpId)
    },
    addNewGroupName() {
      if (this.newGroupName === '') {
        this.$toast.error('그룹명을 입력해주세요.')
        return
      }

      let isSome = this.totalNumByGroup.some(
        (item) => item.isrgrpNm === this.newGroupName
      )

      if (isSome) {
        this.$toast.error('이미 등록된 그룹명입니다.')
        return
      }

      // todo: 그룹추가 api
      if (this.newGroupName) {
        // this.apiUrl = '/isrty/isrgrp'
        // this.apiType = 'analysis'
        this.$api.analysis
          .post(`/isrty/isrgrp`, {
            incdntId: this.incidentInfo.id,
            isrgrpNm: this.newGroupName
          })
          .then((res) => {
            console.log('그룹추가성공:', res)
            this.newGroupName = ''
            // todo: 그룹 호출 api
            // this.totalNumByGroup = res.data.result
            // this.$nextTick(() => {
            //   document.querySelector('.overflow-y-auto').scrollTop = 10000
            //   this.$emit('update-now')
            // })
          })
      }
    },
    onScroll() {},
    onDialogClose() {
      this.$emit('update:visible', !this.visible)
    }
  }
}
</script>

<style lang="scss" scoped>
.v-tab {
  text-transform: none;
}
</style>
