<template>
  <v-container>
    <section class="dea-section">
      <!-- {{ filter }} -->
      <div class="search-box">
        <dea-card expandable class="side-btn-group">
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>증거유형</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                v-model="allSelType"
                @change="selAllType"
                :indeterminate="
                  type.length > 0 && type.length !== typeItems.length
                "
              ></dea-checkbox>
              <dea-checkbox
                v-for="(item, index) in typeItems"
                v-model="type"
                :label="item.label"
                :cvalue="item.value"
                :key="index"
                @change="selType"
              ></dea-checkbox>
            </v-col>
            <v-col cols="1">
              <dea-label>처리상태</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-checkbox
                label="전체"
                v-model="allSelStatus"
                @change="selAllStatus"
                :indeterminate="
                  status.length > 0 && status.length !== statusItems.length
                "
              ></dea-checkbox>
              <dea-checkbox
                v-for="(item, index) in statusItems"
                v-model="status"
                :label="item.label"
                :cvalue="item.value"
                :key="index"
                @change="selStatus"
              ></dea-checkbox>
            </v-col>
          </v-row>
          <v-row no-gutters>
            <v-col cols="1">
              <dea-label>검색</dea-label>
            </v-col>
            <v-col class="d-flex">
              <dea-text-field
                placeholder="처리중인 파일은 검색되지 않으니, 처리상태 완료여부를 확인하신후 검색해주세요"
                v-model="filter.evdncSrchwrd"
              ></dea-text-field>
            </v-col>
          </v-row>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-center">
                <dea-button
                  prepend-icon="mdi-magnify"
                  color="primary"
                  title="조회"
                  @click="onSearch"
                >
                  조회
                </dea-button>
                <dea-button
                  outlined
                  prepend-icon="mdi-restore"
                  title="초기화"
                  @click="resetFilter"
                >
                  초기화
                </dea-button>
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section">
      <div class="inner grid-wrap">
        <dea-card>
          <dea-grid
            ref="grid"
            :api="gridInfo.api"
            :columns="gridInfo.columns"
            :return-value.sync="tabItemsName[0].count"
            row-selection-multiple
            suppress-row-click-selection
            use-pagination
          >
            <template #header-left>
              <v-col class="d-flex">
                <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
              </v-col>
            </template>
            <template #header-right>
              <v-col class="d-flex align-right">
                <dea-button @click="doFileDownload('extfile')"
                  >추출목록파일저장</dea-button
                >
                <!-- <dea-button color="primary" @click="doFileDownload('file')">
                  파일저장
                </dea-button> -->
              </v-col>
            </template>
          </dea-grid>
        </dea-card>
      </div>
    </section>
    <!-- 다운로드 컨펌창 -->
    <dea-confirm v-model="downloadConfirm.show">
      <template slot="message">
        다운로드할 파일의 범위를 선택해주세요
      </template>
      <template slot="actions">
        <dea-button color="primary" @click="downloadConfirm.allDownload"
          >목록 전체</dea-button
        >
        <dea-button color="primary" @click="downloadConfirm.curDownload"
          >현재 페이지</dea-button
        >
        <dea-button outlined @click="downloadConfirm.cancel"
          >다시 선택</dea-button
        >
      </template>
    </dea-confirm>
    <!-- 다운로드 컨펌창 // -->
  </v-container>
</template>

<script>
import { NumberUtils } from '@/utils/NumberUtils'
import { GridFormatter } from '@/utils/GridFormatter'
import listTemplate from '@/mixins/listTemplate'
import CellCheckbox from '@/components/grid/CellCheckbox'
import CellCheckboxHeader from '@/components/grid/CellCheckboxHeader'

export default {
  name: 'EvidenceAnalysisProcessStatus',
  mixins: [listTemplate],
  data() {
    return {
      downloadConfirm: {
        kind: 'file', // extfile, file
        show: false,
        allDownload: () => {
          this.$confirm(
            '다운로드가 예약되었습니다.<br>파일저장관리에서 확인하실 수 있습니다.<br><br>파일저장관리로 이동하시겠습니까?'
          ).then((confirm) => {
            if (confirm)
              this.$router.push('/fileStorageManagement/fileStorageManagement')
          })
          // this.$toast(`다운로드가 예약되었습니다. 파일저장관리에서 확인해주세요.`)
          this.downloadConfirm.show = false
        },
        curDownload: () => {
          if (this.downloadConfirm.kind === 'extfile') {
            this.$toast(`추출목록파일이 다운로드 되었습니다.`)
          } else {
            this.$toast(`파일이 다운로드 되었습니다.`)
          }
          this.downloadConfirm.show = false
        },
        cancel: () => {
          this.downloadConfirm.show = false
        }
      },
      gridInfo: {
        api: '/talk/dgtl-evdnc-prcs-sttus',
        columns: [
          {
            headerName: '열 선택',
            field: 'rowSelector',
            width: 20,
            headerComponentFramework: CellCheckboxHeader,
            cellRendererFramework: CellCheckbox
          },
          {
            headerName: 'No',
            field: 'no',
            width: 70,
            cellClass: 'align-right'
          },
          {
            headerName: '증거번호',
            field: 'evdncNo',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '유형',
            field: 'evdncTy',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '회사',
            field: 'co',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '부서',
            field: 'dept',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '실사용자',
            field: 'rlUser',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '증거등록일시',
            field: 'evdncRegDt',
            sortable: true,
            unSortIcon: true
          },
          {
            headerName: '추출파일최종등록일시',
            field: 'extrFileLastRegDt',
            sortable: true,
            unSortIcon: true,
            valueFormatter: (params) => {
              if (!params.value) return '미등록'
            },
            cellStyle: (params) => {
              if (!params.value) return { color: '#ff0000' }
            }
          },
          {
            headerName: '색인완료일시',
            field: 'indexCmptnDt',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens
          },
          {
            headerName: '색인완료',
            field: 'indexCmptn',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens,
            cellClass: 'align-right'
          },
          {
            headerName: '암호탐지',
            field: 'passwordDetct',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens,
            cellClass: 'align-right'
          },
          {
            headerName: 'DRM탐지',
            field: 'drnDetct',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens,
            cellClass: 'align-right'
          },
          {
            headerName: 'Virus탐지',
            field: 'cptvrDetct',
            sortable: true,
            unSortIcon: true,
            valueFormatter: GridFormatter.emptyWithHyphens,
            cellClass: 'align-right'
          }
        ]
      },
      gridSelected: [],
      tabSelected: 0,
      tabItemsName: [
        { name: '총 디지털증거수', count: 0 },
        { name: '완료', count: 0 },
        {
          name: '신규',
          count: 0,
          tooltip: '최근 1주일이내 처리된 디지털증거수'
        },
        { name: '진행', count: 0 }
        /* { name: '미등록', count: 0 } */
      ],
      filter: {
        type: [],
        status: [],
        evdncSrchwrd: ''
      },
      allSelType: true,
      type: [],
      typeItems: [
        { label: '회사/부서', value: '회사/부서' },
        { label: '실사용자', value: '실사용자' },
        { label: '증거번호', value: '증거번호' }
      ],
      allSelStatus: true,
      status: [],
      statusItems: [
        { label: '처리중', value: '처리중' },
        { label: '완료', value: '완료' },
        { label: '미등록', value: '미등록' }
      ],
      validError: {}
    }
  },
  computed: {
    tabItems() {
      return this.tabItemsName.map((item) => {
        return {
          name: `${item.name} (${NumberUtils.numberWithCommas(item.count)})`,
          tooltip: item.tooltip ? item.tooltip : ''
        }
      })
    }
  },
  methods: {
    onSearch() {
      this.$refs.grid.reset()
      this.loadData()
    },
    doFileDownload(kind) {
      let notRegchk = this.$refs.grid.getSelectedRows().filter((item) => {
        return item.extFileRegDate === ''
      }).length
      this.gridSelected = this.$refs.grid.getSelectedRows().filter((item) => {
        return item.extFileRegDate !== ''
      })
      // console.log('doFileDownload', this.gridSelected, notRegchk)
      if (notRegchk > 0) {
        this.$toast.error(`미등록 파일은 다운로드 할 수 없습니다.`)
      }
      if (this.gridSelected.length > 0) {
        if (kind === 'extfile') {
          this.$toast(`추출목록파일이 다운로드 되었습니다.`)
        } else {
          this.$toast(`파일이 다운로드 되었습니다.`)
        }
      } else {
        this.downloadConfirm.kind = kind
        this.downloadConfirm.show = true
      }
    },
    selType(value) {
      if (value.length > 0) {
        this.allSelType = false
        this.filter.type = value
        if (value.length === this.typeItems.length) {
          this.allSelType = true
          this.filter.type = []
        }
      }
    },
    selAllType(flag) {
      if (flag) {
        this.type = this.typeItems.map((item) => item.value)
        this.filter.type = []
      } else {
        this.type = []
      }
    },
    selStatus(value) {
      if (value.length > 0) {
        this.allSelStatus = false
        this.filter.status = value
        if (value.length === this.statusItems.length) {
          this.allSelStatus = true
          this.filter.status = []
        }
      }
    },
    selAllStatus(flag) {
      if (flag) {
        this.status = this.statusItems.map((item) => item.value)
        this.filter.status = []
      } else {
        this.status = []
      }
    }
  },
  created() {
    this.type = this.typeItems.map((item) => item.value)
    this.status = this.statusItems.map((item) => item.value)
  }
}
</script>
