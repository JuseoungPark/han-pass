<template>
  <v-container class="dea-home">
    <section class="dea-section search-field">
      <div class="search-box search-box-field">
        <dea-card class="mx-auto">
          <v-row no-gutters>
            <v-col class="d-flex flex-0">
              <v-layout class="dea-text-field ma-0">
                <v-menu
                  :disabled="disabled"
                  :absolute="absolute"
                  :open-on-hover="openOnHover"
                  :close-on-click="closeOnClick"
                  :close-on-content-click="closeOnContentClick"
                  :offset-x="offsetX"
                  :offset-y="offsetY"
                >
                  <template v-slot:activator="{ on, attrs }">
                    <dea-text-field
                      dense
                      outlined
                      clearable
                      class="align-center"
                      placeholder="디지털증거분석결과를 검색합니다."
                      v-bind="attrs"
                      v-on="on"
                      v-model="searchText"
                      style="width:500px;"
                      @keyup.enter="goSearch"
                    ></dea-text-field>
                  </template>
                  <!-- 검색어 자동완성 : Layer Popup -->
                  <v-sheet class="dea-popup" style="width:100%;">
                    <v-container class="pa-4">
                      <section class="dea-section">
                        <div class="inner">
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <div class="text font-bold">
                                최근검색어
                              </div>
                            </v-col>
                            <v-col class="d-flex align-right">
                              <dea-button text outlined>전체삭제</dea-button>
                            </v-col>
                          </v-row>
                          <v-list dense>
                            <v-list-item-group v-model="searchList">
                              <v-list-item
                                v-for="(searchItem, i) in searchItems"
                                :key="i"
                                @click="goSearchItem(searchItem)"
                              >
                                <v-list-item-content class="flex-row">
                                  <v-list-item-title
                                    v-text="searchItem.text"
                                  ></v-list-item-title>
                                  <v-list-item-subtitle
                                    class="align-right flex-0"
                                    style="width:150px;"
                                    v-text="searchItem.date"
                                  ></v-list-item-subtitle>
                                </v-list-item-content>
                                <v-list-item-action>
                                  <dea-button
                                    icon
                                    prepend-icon="mdi-close"
                                  ></dea-button>
                                </v-list-item-action>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                          <v-divider />
                          <v-row no-gutters>
                            <v-col class="d-flex align-right">
                              <dea-switch
                                inset
                                value
                                label="자동완성"
                                input-value="true"
                              ></dea-switch>
                            </v-col>
                          </v-row>
                        </div>
                      </section>
                    </v-container>
                  </v-sheet>
                  <!-- //검색어 자동완성 : Layer Popup -->
                </v-menu>
              </v-layout>
              <dea-button
                textindent
                prepend-icon="mdi-magnify"
                @click="goSearch"
                title="검색"
              >
              </dea-button>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section status-field">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title" title-class="align-left">
            디지털증거처리현황
            <v-layout class="v-toolbar valign-middle flex-0 ml-4">
              <div class="info-message">
                <strong>{{ updateDate }}</strong>
                <label class="ml-2">업데이트</label>
              </div>
              <v-btn
                text
                class="dea-btn--textindent"
                :loading="loading"
                @click="updateStatus"
              >
                <v-icon>mdi-cached</v-icon>
                갱신
              </v-btn>
            </v-layout>
          </template>
          <v-row>
            <v-col cols="3" v-for="(item, i) in evidenceStatusItems" :key="i">
              <v-card :class="getStatusClass(item)" height="140px">
                <v-card-title
                  style="cursor:pointer"
                  @click="goRouter(item.link)"
                >
                  <v-icon>{{ item.icon }}</v-icon>
                  {{ item.title }}
                </v-card-title>
                <v-card-text
                  class="primary--text"
                  style="cursor:pointer"
                  @click="goRouter(item.link)"
                >
                  {{ item.count | numberWithCommas }}
                </v-card-text>
                <!-- <v-btn text :loading="loading" @click="loader = 'loading'">
                  <v-icon>mdi-cached</v-icon>
                  처리중
                </v-btn> -->
              </v-card>
            </v-col>
          </v-row>
          <template slot="actions">
            <v-row>
              <v-col cols="3">
                <dea-button large block>분석대상파일 업로드</dea-button>
              </v-col>
              <v-col cols="9">
                <v-btn
                  block
                  large
                  color="primary"
                  @click="goLinkByName('EvidenceAnalysisProcessStatus')"
                >
                  디지털증거처리현황 자세히보기
                  <v-icon>mdi-plus</v-icon>
                </v-btn>
              </v-col>
            </v-row>
          </template>
        </dea-card>
      </div>
    </section>

    <section class="dea-section quick-menu">
      <div class="inner">
        <dea-card class="mx-auto">
          <template slot="title">
            디지털증거 통합분석 <strong>Quick Menu</strong>
          </template>
          <v-row>
            <v-col cols="3">
              <v-btn
                block
                large
                color="primary"
                @click="goLinkByName('PersonManagement')"
              >
                <v-icon>mdi-account-alert</v-icon>
                주요인물관리
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn
                block
                large
                @click="goLinkByName('IntegratedCorrelationChart')"
              >
                <v-icon>mdi-account-multiple</v-icon>
                인물중심분석
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn block large @click="goLinkByName('TimeSeriesAnalysis')">
                <v-icon>mdi-clock-time-three-outline</v-icon>
                시간중심분석
              </v-btn>
            </v-col>
            <v-col cols="3">
              <v-btn block large>
                <v-icon>mdi-map-marker-radius</v-icon>
                위치중심분석
              </v-btn>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <v-snackbar
      v-model="snackbar"
      :timeout="1500"
      :value="true"
      absolute
      top
      centered
      color="pink"
      elevation="8"
    >
      선택한 사건의 서비스기간이 7일 남았습니다. 연장해주세요.
      <dea-button text outlined>기간연장 바로가기</dea-button>
      <template v-slot:action="{ attrs }">
        <v-icon v-bind="attrs" @click="snackbar = false">mdi-close</v-icon>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'
import routeMixin from '@/mixins/route'

export default {
  name: 'EvidenceAnalysisHome',
  mixins: [routeMixin],
  data() {
    return {
      searchText: '',
      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,
      updateDate: '',
      // In Modal Popup
      searchList: null,
      searchItems: [
        {
          text: '홍길동',
          date: '2020.10.06'
        },
        {
          text: '인천 횡령 사건',
          date: '2020.10.05'
        },
        {
          text: '사건번호2020교육203956',
          date: '2020.10.05'
        },
        {
          text: '박길동',
          date: '2020.10.04'
        }
      ],

      // Setting for Publishing
      snackbar: false,
      loading: false,
      evidenceStatusList: null,
      evidenceStatusItems: [
        {
          title: '통화내역',
          count: 0,
          icon: 'mdi-phone-settings',
          link: 'CallAnalysysHome',
          active: true
        },
        {
          title: '계좌내역',
          count: 0,
          icon: 'mdi-cash-multiple',
          link: ''
        },
        {
          title: '회계내역',
          count: 0,
          icon: 'mdi-account-cash',
          link: ''
        },
        {
          title: '',
          count: 0,
          icon: 'mdi-dots-horizontal',
          link: '',
          noData: true
        },
        {
          title: '비정형파일',
          count: 0,
          icon: 'mdi-grain',
          link: 'FileStatus',
          active: true
        },
        {
          title: '이메일',
          count: 0,
          icon: 'mdi-email',
          link: ''
        },
        {
          title: '모바일',
          count: 0,
          icon: 'mdi-cellphone-iphone',
          link: ''
        },
        {
          title: '암호파일',
          count: 0,
          icon: 'mdi-lock',
          link: ''
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['incidentInfo'])
  },
  beforeMount() {
    this.$eventBus.$on('update:evidence-home', () => {
      this.updateStatus()
    })
  },
  mounted() {
    // this.updateStatus()
  },
  methods: {
    goSearch() {
      if (this.searchText.length > 0)
        this.goLinkByName('IntegrationSearch', { searchText: this.searchText })
      else this.$alert('검색어를 입력해주세요')
      /*this.$router.push({
        name: 'IntegrationSearch',
        params: { searchText: this.searchText }
      })*/
    },
    goSearchItem(item) {
      this.searchText = item.text
    },
    getStatusClass(object) {
      return {
        'dea-card-field': true,
        active: object.active === true,
        nodata: object.noData == true
      }
    },
    goRouter(name) {
      if (name) this.goLinkByName(name)
    },
    updateStatus() {
      this.loading = true

      this.$axios
        .all([
          this.$api.analysis.get(
            `talk/dtls-prcs-cmptn-cnt?incdntId=${this.incidentInfo.id}`
          ),
          this.$api.analysis.get(
            `talk/ad-hoc-file-prcs-cmptn-cnt?incdntId=${this.incidentInfo.id}`
          )
        ])
        .then(
          this.$axios.spread((...responses) => {
            if (responses[0].data.code === '200') {
              this.evidenceStatusItems[0].count =
                responses[0].data.result.prcsCmptnCnt
            }
            if (responses[1].data.code === '200') {
              this.evidenceStatusItems[4].count =
                responses[1].data.result.prcsCmptnCnt
            }

            this.updateDate = moment().format('YYYY-MM-DD HH:mm')
            this.loading = false
          })
        )
    }
  }
}
</script>
