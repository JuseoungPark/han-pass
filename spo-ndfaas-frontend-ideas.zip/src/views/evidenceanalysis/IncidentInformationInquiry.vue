<template>
  <v-container>
    <p>{{ $t('menu.evidenceAnalysis.incidentInformationInquiry') }}</p>
  </v-container>
</template>

<script>
export default {
  name: 'IncidentInformationInquiry'
}
</script>
