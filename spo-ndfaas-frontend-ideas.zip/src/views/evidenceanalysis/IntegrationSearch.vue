<template>
  <v-container class="dea-search">
    <section class="dea-section search-field">
      <div class="search-box search-box-field">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex">
              <v-layout class="dea-text-field">
                <v-menu
                  :disabled="disabled"
                  :absolute="absolute"
                  :open-on-hover="openOnHover"
                  :close-on-click="closeOnClick"
                  :close-on-content-click="closeOnContentClick"
                  :offset-x="offsetX"
                  :offset-y="offsetY"
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      dense
                      outlined
                      clearable
                      class="align-center"
                      placeholder="디지털증거분석결과를 검색합니다."
                      v-bind="attrs"
                      v-on="on"
                      v-model="searchText"
                    ></v-text-field>
                    <dea-button icon prepend-icon="mdi-magnify"></dea-button>
                  </template>
                  <!-- 검색어 자동완성 : Layer Popup -->
                  <v-sheet class="dea-popup" style="width:100%;">
                    <v-container class="pa-4">
                      <section class="dea-section">
                        <div class="inner">
                          <v-row no-gutters>
                            <v-col class="d-flex">
                              <div class="text font-bold">
                                최근검색어
                              </div>
                            </v-col>
                            <v-col class="d-flex align-right">
                              <dea-button text outlined>전체삭제</dea-button>
                            </v-col>
                          </v-row>
                          <v-list dense>
                            <v-list-item-group v-model="searchList">
                              <v-list-item
                                v-for="(searchItem, i) in searchItems"
                                :key="i"
                              >
                                <v-list-item-content class="flex-row">
                                  <v-list-item-title
                                    v-text="searchItem.text"
                                  ></v-list-item-title>
                                  <v-list-item-subtitle
                                    class="align-right flex-0"
                                    style="width:150px;"
                                    v-text="searchItem.date"
                                  ></v-list-item-subtitle>
                                </v-list-item-content>
                                <v-list-item-action>
                                  <dea-button
                                    icon
                                    prepend-icon="mdi-close"
                                  ></dea-button>
                                </v-list-item-action>
                              </v-list-item>
                            </v-list-item-group>
                          </v-list>
                          <v-divider />
                          <v-row no-gutters>
                            <v-col class="d-flex align-right">
                              <dea-switch
                                inset
                                value
                                label="자동완성"
                                input-value="true"
                              ></dea-switch>
                            </v-col>
                          </v-row>
                        </div>
                      </section>
                    </v-container>
                  </v-sheet>
                  <!-- //검색어 자동완성 : Layer Popup -->
                </v-menu>
              </v-layout>
              <dea-button @click="keywordTopic = !keywordTopic"
                >본문 검색어 토픽</dea-button
              >
              <v-menu
                :disabled="disabled"
                :absolute="absolute"
                :open-on-hover="openOnHover"
                :close-on-click="closeOnClick"
                :close-on-content-click="closeOnContentClick"
                :offset-x="offsetX"
                :offset-y="offsetY"
              >
                <template v-slot:activator="{ on }">
                  <v-btn color="primary" v-on="on">상세검색</v-btn>
                </template>
                <!-- 추출파일 목록 : Layer Popup -->
                <v-sheet class="dea-popup" style="width:480px;">
                  <v-container class="pa-4">
                    <section class="dea-section">
                      <div class="inner">
                        <dea-card>
                          <v-row no-gutters>
                            <v-col cols="1" class="valign-top">
                              <dea-label>기본검색</dea-label>
                            </v-col>
                            <v-col class="d-flex d-block">
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    hint="여러 단어를 입력하실 때에는 쉼표(,)로 구분해주세요"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-checkbox
                                    label="입력한 단어가 하나 이상 포함된 파일 검색"
                                  ></dea-checkbox>
                                </v-col>
                              </v-row>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1" class="valign-top">
                              <dea-label>상세검색</dea-label>
                            </v-col>
                            <v-col class="d-flex d-block">
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    label="일치하는 단어"
                                    prepend-inner-icon="mdi-check"
                                    hint="여러 단어를 입력하실 때에는 쉼표(,)로 구분해주세요"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    label="반드시 포함하는 단어"
                                    prepend-inner-icon="mdi-plus"
                                    hint="여러 단어를 입력하실 때에는 쉼표(,)로 구분해주세요"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-text-field
                                    label="제외하는 단어"
                                    prepend-inner-icon="mdi-minus"
                                    hint="여러 단어를 입력하실 때에는 쉼표(,)로 구분해주세요"
                                  ></dea-text-field>
                                </v-col>
                              </v-row>
                            </v-col>
                          </v-row>
                          <v-row no-gutters>
                            <v-col cols="1" class="valign-top">
                              <dea-label>기간범위</dea-label>
                            </v-col>
                            <v-col class="d-flex d-block">
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-radio-group
                                    v-model="radios"
                                    row
                                    :mandatory="false"
                                    :items="radioItems"
                                  ></dea-radio-group>
                                </v-col>
                              </v-row>
                              <v-row no-gutters>
                                <v-col class="d-flex">
                                  <dea-date-picker
                                    :close-on-content-click="false"
                                    transition="scale-transition"
                                    offset-y
                                    range
                                  ></dea-date-picker>
                                </v-col>
                              </v-row>
                            </v-col>
                          </v-row>
                          <template slot="actions">
                            <div class="btn-group">
                              <v-col class="align-center">
                                <dea-button outlined>닫기</dea-button>
                                <dea-button color="primary">검색</dea-button>
                                <dea-button>초기화</dea-button>
                              </v-col>
                            </div>
                          </template>
                        </dea-card>
                      </div>
                    </section>
                  </v-container>
                </v-sheet>
                <!-- //추출파일 목록 : Layer Popup -->
              </v-menu>
            </v-col>
          </v-row>
        </dea-card>
      </div>
    </section>

    <section class="dea-section search-result">
      <div class="inner">
        <v-row no-gutters class="grid-top mb-4">
          <v-col class="d-flex">
            <dea-tabs v-model="tabSelected" :tabItems="tabItems"></dea-tabs>
          </v-col>
          <v-col class="d-flex align-right">
            <div class="text">
              <strong class="red--text">'{{ searchText }}'</strong>에 대한 총
              <strong class="red--text">{{ allItems.count }}</strong
              >건의 검색결과가 있습니다.
            </div>
          </v-col>
        </v-row>
      </div>
      <div class="inner">
        <dea-card v-for="(item, index) in resKindItems" :key="index">
          <template slot="title">{{ item.name }}</template>
          <v-list class="pa-0">
            <v-list-item-group>
              <v-list-item v-for="(res, i) in result" :key="i">
                <v-list-item-content class="flex-column">
                  <v-layout class="flex-auto">
                    <v-list-item-title v-html="res.title1"></v-list-item-title>
                    <v-list-item-title>
                      등록: {{ res.title2 }}
                    </v-list-item-title>
                    <v-list-item-title>
                      출처: {{ res.title3 }}
                    </v-list-item-title>
                  </v-layout>
                  <v-layout class="flex-auto">
                    <v-list-item-subtitle>
                      등록: {{ res.subtitle1 }}
                    </v-list-item-subtitle>
                    <v-list-item-subtitle>
                      수정: {{ res.subtitle2 }}
                    </v-list-item-subtitle>
                    <v-list-item-subtitle>
                      접근: {{ res.subtitle3 }}
                    </v-list-item-subtitle>
                  </v-layout>
                  <v-layout class="flex-auto">
                    <div class="text" v-html="res.text"></div>
                  </v-layout>
                </v-list-item-content>

                <v-list-item-action>
                  <dea-button>내용보기</dea-button>
                  <dea-button>다운로드</dea-button>
                </v-list-item-action>
              </v-list-item>
            </v-list-item-group>
          </v-list>
          <template slot="actions">
            <div class="btn-group">
              <v-col class="align-right">
                <dea-button text prepend-icon="mdi-plus"
                  >{{ item.title }} 더 보기</dea-button
                >
              </v-col>
            </div>
          </template>
        </dea-card>
      </div>
    </section>

    <!-- 본문 검색어 토픽 : Layer Popup -->
    <dea-dialog v-model="keywordTopic" title="본문 검색어 토픽" width="1100px">
      <section class="dea-section">
        <div class="inner"></div>
      </section>
      <div class="btn-group">
        <v-col class="align-center">
          <dea-button outlined @click="keywordTopic = !keywordTopic">
            취소
          </dea-button>
          <dea-button color="primary">확인</dea-button>
        </v-col>
      </div>
    </dea-dialog>
    <!-- //본문 검색어 토픽 : Layer Popup -->
  </v-container>
</template>

<script>
import { NumberUtils } from '@/utils/NumberUtils'
export default {
  name: 'IntegrationSearch',
  data() {
    return {
      tabSelected: 0,
      allItems: [{ title: '통합검색', count: 23 }],
      kindItems: [
        { title: '통화내역', count: 12 },
        { title: '계좌내역', count: 5 },
        { title: '파일', count: 6 }
      ],
      searchText: '',
      // v-menu setting
      disabled: false,
      absolute: false,
      openOnHover: false,
      closeOnClick: true,
      closeOnContentClick: false,
      offsetX: false,
      offsetY: true,

      // Modal Popup
      keywordTopic: false,

      // In Modal Popup
      searchList: null,
      searchItems: [
        {
          text: '홍길동',
          date: '2020.10.06'
        },
        {
          text: '인천 횡령 사건',
          date: '2020.10.05'
        },
        {
          text: '사건번호2020교육203956',
          date: '2020.10.05'
        },
        {
          text: '박길동',
          date: '2020.10.04'
        }
      ],
      radios: 'radio-1',
      radioItems: [
        {
          label: '1일',
          value: 'radio-1'
        },
        {
          label: '1주일',
          value: 'radio-2'
        },
        {
          label: '1개월',
          value: 'radio-3'
        },
        {
          label: '6개월',
          value: 'radio-4'
        },
        {
          label: '1년',
          value: 'radio-5'
        }
      ],
      searchResults: '',
      resKindItems: [],
      result: [],
      resDummy: [
        {
          title1: '파일제목파일제목.xls',
          title2: '시스템',
          title3: 'KT',
          subtitle1: '2020.10.01 11:00:01',
          subtitle2: '2020.10.01 11:50:00',
          subtitle3: '2020.10.04 12:00:00',
          text:
            '파일내용 검색부분 중 0101112222가 포함되어 있는 부분의 내용을 일부 가져와서 보여줌.'
        },
        {
          title1: '파일제목파일제목.xls',
          title2: '시스템',
          title3: 'KT',
          subtitle1: '2020.10.01 11:00:01',
          subtitle2: '2020.10.01 11:50:00',
          subtitle3: '2020.10.04 12:00:00',
          text:
            '파일내용 검색부분 중 0101112222가 포함되어 있는 부분의 내용을 일부 가져와서 보여줌.'
        },
        {
          title1: '파일제목파일제목.xls',
          title2: '시스템',
          title3: 'KT',
          subtitle1: '2020.10.01 11:00:01',
          subtitle2: '2020.10.01 11:50:00',
          subtitle3: '2020.10.04 12:00:00',
          text:
            '파일내용 검색부분 중 0101112222가 포함되어 있는 부분의 내용을 일부 가져와서 보여줌.'
        },
        {
          title1: '파일제목파일제목.xls',
          title2: '시스템',
          title3: 'KT',
          subtitle1: '2020.10.01 11:00:01',
          subtitle2: '2020.10.01 11:50:00',
          subtitle3: '2020.10.04 12:00:00',
          text:
            '파일내용 검색부분 중 0101112222가 포함되어 있는 부분의 내용을 일부 가져와서 보여줌.'
        },
        {
          title1: '파일제목파일제목.xls',
          title2: '시스템',
          title3: 'KT',
          subtitle1: '2020.10.01 11:00:01',
          subtitle2: '2020.10.01 11:50:00',
          subtitle3: '2020.10.04 12:00:00',
          text:
            '파일내용 검색부분 중 0101112222가 포함되어 있는 부분의 내용을 일부 가져와서 보여줌.'
        }
      ]
    }
  },

  computed: {
    tabItems() {
      let allItem = this.allItems.map((item) => {
        return {
          ...item,
          name: `${item.title} (${NumberUtils.numberWithCommas(item.count)})`
        }
      })
      let kindItems = this.kindItems.map((item) => {
        return {
          ...item,
          name: `${item.title} (${NumberUtils.numberWithCommas(item.count)})`
        }
      })
      return [...allItem, ...kindItems]
    }
  },
  watch: {
    tabSelected(value) {
      this.getResult(value)
    }
  },
  methods: {
    getResult(index) {
      if (index === 0) {
        this.resKindItems = [...this.tabItems]
        this.resDummy.forEach((item) => {
          Object.keys(item).forEach((key) => {
            item[key] = item[key].replace(
              this.searchText,
              `<strong class='red--text'>'${this.searchText}'</strong>`
            )
            console.log(key, item[key])
          })
        })
        this.result = [...this.resDummy.filter((item, index) => index > 2)]
      } else {
        this.resKindItems = [this.tabItems[index]]
        this.result = [...this.resDummy]
      }
    }
  },
  created() {
    this.searchText = this.$route.params.searchText
    this.getResult(this.tabSelected)
  }
}
</script>
