const express = require('express')
var cors = require('cors')
var fs = require('fs')
var moment = require('moment')

var path = require('path')

var json2xlsx = require('node-json-xlsx')

require('dotenv').config()

const SERVER_PORT = Number(process.env.VUE_APP_USE_API_SERVER_PORT) || 8090

let DBSOURCE = ''
let jsonFilePath = ''
let manualFilePath = ''
if (process.env.NODE_ENV !== 'production') {
  DBSOURCE = './src/apiServer/develop.sqlite'
  jsonFilePath = './public/api/'
  manualFilePath =
    './public/docs/NDFAAS-디지털증거분석시스템-사용자매뉴얼_v0.9_20201217_1.pdf'
} else {
  DBSOURCE = path
    .join(__dirname, '/src/apiServer/develop.sqlite')
    .replace('\\app.asar', '')
  jsonFilePath = path.join(__dirname, '/public/api/').replace('\\app.asar', '')
  manualFilePath = path
    .join(
      __dirname,
      '/public/docs/NDFAAS-디지털증거분석시스템-사용자매뉴얼_v0.9_20201217_1.pdf'
    )
    .replace('\\app.asar', '')
}

var db = require('./database.js')(DBSOURCE)

module.exports = function() {
  var apiServer = {}
  const server = express()

  server.excelLimitCount = 5000

  server.use(cors({ exposedHeaders: ['Content-Disposition'] }))
  server.use(express.json())

  server.use((req, res, next) => {
    if (req.url.includes('.json'))
      req.url = req.url.substring(0, req.url.indexOf('.json') + 5)

    if (req.headers.accept === 'application/vnd.openxmlformats') {
      res.responseFileName =
        req._parsedUrl.pathname
          .split('/')
          .join('_')
          .substring(1) +
        '_' +
        moment().format('YYYYMMDD_HHmmss') +
        '.xlsx'
      res.responseType = 'xlsx'
      res.responseDataAll = false
      if (req.query.excel && req.query.excel === 'all') {
        res.responseDataAll = true
        req.query.limit = -1
        req.query.page = 1
      }
    } else {
      res.setHeader('Content-Type', 'application/json; charset=utf-8')
      res.responseType = 'json'
    }

    res.response = function(result) {
      if (this.responseType === 'json') this.json(result)
      else if (this.responseType === 'xlsx') {
        if (!res.responseDataAll || result.total < server.excelLimitCount) {
          var xlsx = json2xlsx(result.rows, { fieldNames: [] })
          this.setHeader('Content-Type', 'application/vnd.openxmlformats')
          this.setHeader(
            'Content-Disposition',
            'attachment; filename=' + this.responseFileName
          )
          this.end(xlsx, 'binary')
        } else {
          this.setHeader('Content-Type', 'application/vnd.openxmlformats')
          this.setHeader(
            'Content-Disposition',
            'url=/api/download/' + this.responseFileName
          )
          this.status(202).send()
        }
      }
    }

    next()
  })

  require('./handlerHome.js')(server)
  require('./handlerCall.js')(server, db)
  require('./handlerPerson.js')(server, db)
  require('./handlerBookmark.js')(server, db)

  server.post('/api/excel', (req, res) => {
    let response = {
      total: req.body.rows.length,
      rows: req.body.rows
    }

    res.responseFileName =
      req.body.url
        .split('?')[0]
        .split('/')
        .join('_')
        .substring(1) +
      '_' +
      moment().format('YYYYMMDD_HHmmss') +
      '.xlsx'

    res.response(response)
  })

  server.get('/api/:file.json', (req, res) => {
    var filePath = jsonFilePath + req.params.file + '.json'

    try {
      if (fs.existsSync(filePath)) {
        var readable = fs.createReadStream(filePath)
        readable.pipe(res)
      } else {
        res.status(404).send({ error: 'File not exist' })
      }
    } catch (err) {
      res.status(500).send({ error: err })
    }
  })

  server.get('/api/manual', (req, res) => {
    try {
      if (fs.existsSync(manualFilePath)) {
        var readable = fs.createReadStream(manualFilePath)
        res.setHeader('Content-Type', 'application/pdf; charset=utf-8')
        res.setHeader(
          'Content-Disposition',
          'attachment; filename=' +
            encodeURI(
              'NDFAAS-디지털증거분석시스템-사용자매뉴얼_v0.9_20201217_1.pdf'
            )
        )
        readable.pipe(res)
      } else {
        res.status(404).send({ error: 'File not exist' })
      }
    } catch (err) {
      console.log(err)
      res.status(500).send({ error: err })
    }
  })

  server.get('/spo-ndfaas/api/incdnts/:page/:limit', (req, res) => {
    let filePath = jsonFilePath + 'incdnts.json'
    try {
      if (fs.existsSync(filePath)) {
        var readable = fs.createReadStream(filePath)
        readable.pipe(res)
      } else {
        res.status(404).send({ error: 'File not exist' })
      }
    } catch (err) {
      res.status(500).send({ error: err })
    }
  })

  server.get('/istry-analy/display', (req, res) => {
    let filePath = jsonFilePath + 'istry-analy_display.json'
    try {
      if (fs.existsSync(filePath)) {
        var readable = fs.createReadStream(filePath)
        readable.pipe(res)
      } else {
        res.status(404).send({ error: 'File not exist' })
      }
    } catch (err) {
      res.status(500).send({ error: err })
    }
  })

  server.get('/isrty/isrty', (req, res) => {
    let filePath = jsonFilePath + 'isrty_isrty.json'
    try {
      if (fs.existsSync(filePath)) {
        var readable = fs.createReadStream(filePath)
        readable.pipe(res)
      } else {
        res.status(404).send({ error: 'File not exist' })
      }
    } catch (err) {
      res.status(500).send({ error: err })
    }
  })

  apiServer.start = () => {
    db.connect()

    server.listen(SERVER_PORT, () => {
      console.log(
        'Start API server on port %PORT%'.replace('%PORT%', SERVER_PORT)
      )
    })
  }

  return apiServer
}
