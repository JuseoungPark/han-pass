var apiServer = require('./apiServer')(true)

apiServer.start()
