module.exports = function(db, dbHandle) {
  //db.getCallHistoryBookmarkCount = function(filter) {
  //  var sql = 'select count(*) as count from bookmark {0}'.format(filter)
  db.getCallHistoryBookmarkCount = function(filter) {
    const sql = 'select count(*) as count from callHistory a, bookmark b where a.no = b.mediaNo and mediaType = "통화" and restore = "N" {0}'.format(
      filter
    )

    return new Promise(function(resolve) {
      0
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallHistoryBookmark = (page, limit, filter, order) => {
    const sql = 'select row_number() over (order by {1}) RowNum, a.*, b.mediaNo as bookmark from callHistory a, bookmark b where a.no = b.mediaNo and mediaType = "통화" and restore = "N" {0} order by {1} limit ? offset ?'.format(
      filter,
      order
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getEachBookmarkFolderCount = function(folderNo) {
    const sql = 'select count(*) as count from bookmark where folderNo={0}'.format(
      folderNo
    )

    return new Promise(function(resolve) {
      0
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getBookmarkUnFolderCount = function(filter) {
    const sql = 'select count(*) as count from bookmark where folderNo=0 {0}'.format(
      filter
    )

    return new Promise(function(resolve) {
      0
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getBookmarkImportantCount = function(filter) {
    const sql = 'select count(*) as count from bookmark where bookmarkLevel > 1 {0}'.format(
      filter
    )

    return new Promise(function(resolve) {
      0
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getIntegratedBookmarkCount = function(filter) {
    const sql = 'select count(*) as count from callHistory a, bookmark b {0}'.format(
      filter
    )

    return new Promise(function(resolve) {
      0
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getIntegratedBookmark = (page, limit, filter, order) => {
    const sql = 'select row_number() over (order by registeredDate desc) RowNum, b.*, bf.color, bf.title, a.outgoingUser, a.dateTime, a.incommingUser, a.incommingNumber from callHistory a, bookmark b left outer join BookmarkFolder bf ON b.folderNo = bf.no {0} order by {1} limit ? offset ?'.format(
      filter,
      order
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertBookmark = (filter) => {
    const sql = `
    INSERT INTO Bookmark(mediaNo, bookmarkLevel, memo,mediaType, registeredUser, registeredDate, restore) VALUES{0}`.format(
      filter
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.deleteBookmark = (filter) => {
    const sql = `DELETE FROM Bookmark WHERE mediaNo in ({0})`.format(filter)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.updateBookmark = (update, where) => {
    const sql = `UPDATE Bookmark SET {0} WHERE {1}`.format(update, where)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.getBookmarkFolder = (filter) => {
    let cols =
      'a.no, a.bookmarkLevel, a.color, a.title, a.content, a.regUser, a.regDate, a.updateUser, a.updateDate, b.count'
    let table =
      'BookmarkFolder as a, (select folderNo, count(*) as count from bookmark group by folderNo) as b'
    const sql = 'select {0} from {1} where a.no = b.folderNo {2}'.format(
      cols,
      table,
      filter
    )
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getLastInsertRowid = () => {
    const sql = 'select last_insert_rowid() as lastId'
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertBookmarkFolder = (filter) => {
    const sql = `
    INSERT INTO BookmarkFolder(bookmarkLevel, color, title, content, regUser, regDate) VALUES{0}`.format(
      filter
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.updateBookmarkFolder = (update, where) => {
    const sql = `UPDATE BookmarkFolder SET {0} WHERE {1}`.format(update, where)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.deleteBookmarkFolder = (filter) => {
    const sql = `DELETE FROM BookmarkFolder WHERE no in ({0})`.format(filter)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }
}
