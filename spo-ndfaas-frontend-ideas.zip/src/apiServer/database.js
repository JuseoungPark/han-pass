var sqlite3 = require('sqlite3').verbose()

String.prototype.format = function() {
  var formatted = this
  for (var i = 0; i < arguments.length; i++) {
    var regexp = new RegExp('\\{' + i + '\\}', 'gi')
    formatted = formatted.replace(regexp, arguments[i])
  }
  return formatted
}

module.exports = function(dbSource) {
  var db = {}
  var dbHandle = null

  db.connect = () => {
    dbHandle = new sqlite3.Database(dbSource, sqlite3.OPEN_READWRITE, (err) => {
      if (err) {
        console.log(err.message)
        throw err
      } else {
        console.log('Connected to the SQLiet database.')
        require('./databaseCall.js')(db, dbHandle)
        require('./databasePerson.js')(db, dbHandle)
        require('./databaseBookmark.js')(db, dbHandle)
      }
    })
  }

  db.getOffset = (page, limit) => {
    return (page - 1) * limit
  }

  db.getPrevPage = (page) => {
    if (page <= 1) return null
    return page - 1
  }

  db.getNextPage = (page, limit, total) => {
    if (total / limit > page) return page + 1
    return null
  }

  return db
}
