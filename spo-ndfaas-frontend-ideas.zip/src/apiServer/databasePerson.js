module.exports = function(db, dbHandle) {
  db.getPersonManagementCount = (filter) => {
    const sql = `
      SELECT 
        count(*) as count 
      FROM PersonManagement as p
      INNER JOIN PersonType as t
      on t.ptId = p.personType
      INNER JOIN Company as c
      on c.comId = p.company
      INNER JOIN Division as d
      on d.comId = p.company AND d.divId = p.division
      LEFT OUTER JOIN (
        SELECT
        pmg.pmId as pmId,
        GROUP_CONCAT( DISTINCT g.pgName ) as pgName
        FROM pm_pg as pmg
        INNER JOIN personGroup as g
        on g.pgId = pmg.pgId
        GROUP by pmg.pmId
      ) as pmpg
      on pmpg.pmId = p.no
      WHERE p.merge = ''
      {0}
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getPersonManagement = (page, limit, filter) => {
    const sql = `
    SELECT
      no, name, photo, personType, t.ptName, phoneNumber, email, nickname, pmpg.pgName as pgName, c.comName, d.divName, joinDate, updateDate, registeredUser, evidenceNumber, memo, keyword, merge, represent
    FROM PersonManagement as p
      INNER JOIN PersonType as t
      on t.ptId = p.personType
      INNER JOIN Company as c
      on c.comId = p.company
      INNER JOIN Division as d
      on d.comId = p.company AND d.divId = p.division
      LEFT OUTER JOIN (
        SELECT
        pmg.pmId as pmId,
        GROUP_CONCAT( DISTINCT g.pgName ) as pgName
        FROM pm_pg as pmg
        INNER JOIN personGroup as g
        on g.pgId = pmg.pgId
        GROUP by pmg.pmId
      ) as pmpg
    on pmpg.pmId = p.no
    WHERE p.merge = ''
    {0}
    LIMIT ? OFFSET ?
    `.format(filter)

    console.log('인물전체검색', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getPersonManagementNextNoId = () => {
    const sql = `
    SELECT no FROM PersonManagement where no = (SELECT MAX(no)  FROM PersonManagement)
    `

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getTotalNumByPersonType = () => {
    const sql = `
    select 
      count(*) as '전체', 
      count(case when personType < 51 then 1 end) as '주요인물', 
      count(case when personType = 11 then 1 end) as '피의자', 
      count(case when personType = 21 then 1 end) as '혐의자',
      count(case when personType = 31 then 1 end) as '참고인',
      count(case when personType = 41 then 1 end) as '피해자',
      count(case when personType = 51 then 1 end) as '기타',
      count(case when personType = 99 then 1 end) as '그외'
    from PersonManagement
    where merge = ''
    `
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getLastUpdateTime = () => {
    const sql = `
    select updateDate 
    from PersonManagement 
    order by updateDate desc 
    limit 1
    `
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getPersonsMergeCount = (filter) => {
    const sql = `
      select 
        count(*) as count 
        from PersonManagement as p
        inner join PersonType as t
        on t.ptId = p.personType
        inner join Company as c
        on c.comId = p.company
        inner join Division as d
        on d.comId = p.company and d.divId = p.division
        left outer join (
          select 
          pmg.pmId as pmId, 
          GROUP_CONCAT( DISTINCT g.pgName ) as pgName 
          from pm_pg as pmg
          inner join personGroup as g
          on g.pgId = pmg.pgId
          group by pmg.pmId
        ) as pmpg
      on pmpg.pmId = p.no
      {0}
      LIMIT ? OFFSET ?
      `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getPersonsMerge = (page, limit, filter) => {
    const sql = `
    select 
      no, name, photo, personType, t.ptName, phoneNumber, email, nickname, pmpg.pgName as pgName, c.comName, d.divName, joinDate, updateDate, registeredUser, evidenceNumber, memo, keyword, merge, represent
    from PersonManagement as p
      inner join PersonType as t
      on t.ptId = p.personType
      inner join Company as c
      on c.comId = p.company
      inner join Division as d
      on d.comId = p.company and d.divId = p.division
      left outer join (
        select 
        pmg.pmId as pmId, 
        GROUP_CONCAT( DISTINCT g.pgName ) as pgName 
        from pm_pg as pmg
        inner join personGroup as g
        on g.pgId = pmg.pgId
        group by pmg.pmId
      ) as pmpg
    on pmpg.pmId = p.no
    {0}
    LIMIT ? OFFSET ?
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getTotalNumByGroup = () => {
    const sql = `
    select
      pg.pgName as pgName,
      pg.pgId as pgId,
      count(pmpg.pgId) as count
    from personGroup as pg
    left outer join pm_pg as pmpg
    on pmpg.pgId = pg.pgId
    where pg.pgId != 1
    group by pg.pgId
    order by pg.pgId
    `
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getGroupMemberList = (filter) => {
    const sql = `
    select 
      no,
      name,
      t.ptName as ptName
    from PersonManagement as m
    inner join PersonType as t
    on m.personType = t.ptId
    where no in (
      select 
        pmId
      from pm_pg pmpg
      {0}
      group by pmpg.pmId
    )
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getPersonGroupList = () => {
    const sql = `
    select pgid as value, pgName as text 
    from PersonGroup where pgId != 1`

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCompanyList = () => {
    const sql = `
    select * from company
    `

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getDivisionList = (filter) => {
    const sql = `
    select * from division {0}
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getPhoneNumberList = (filter) => {
    const sql = `
    select * from PhoneNumbers {0}
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getEmailList = (filter) => {
    const sql = `
    select * from Emails {0}
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.updatePersonManagement = (filter) => {
    const sql = `
    update PersonManagement {0}`.format(filter)

    // console.log(sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.updatePersonManagementUpdateDate = (filter) => {
    const sql = `
    update PersonManagement set updateDate = datetime('now','localtime') where no in ({0})`.format(
      filter
    )

    console.log(sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.updatePerson = (filter1, filter2, filter3) => {
    const sql = `
    update PersonManagement set ({0}) = ({1}) where {2}
    `.format(filter1, filter2, filter3)

    console.log('인물정보 수정 ', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deletePersonGroup = (filter) => {
    const sql = `
    delete from PersonGroup  {0}`.format(filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deletePersonGroupMembers = (filter) => {
    const sql = `delete from pm_pg {0}`.format(filter)
    console.log('그룹에서 인물 삭제', sql)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deleteCompany = (filter) => {
    const sql = 'delete from company {0}'.format(filter)

    console.log('company delete :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deleteDivision = (filter) => {
    const sql = 'delete from division {0}'.format(filter)

    console.log('division delete :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deletePhoneNumbers = (filter) => {
    const sql = 'delete from PhoneNumbers {0}'.format(filter)

    console.log('deletePhoneNumbers :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.deleteEmails = (filter) => {
    const sql = 'delete from emails {0}'.format(filter)

    console.log('deleteEmails :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertPersonGroups = (filter) => {
    const sql = `
    insert into PersonGroup(pgName) values("{0}")`.format(filter)

    console.log('인물 그룹 넣기', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertPm_Pg = (filter) => {
    const sql = `insert into pm_pg(pmId, pgId) values {0}`.format(filter)

    console.log('insertPm_Pg', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertCompany = (filter) => {
    const sql = 'insert into company(comId, comName) values({0})'.format(filter)

    console.log('company :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertDivision = (filter) => {
    const sql = 'insert into division(comId, divId, divName) values({0})'.format(
      filter
    )

    console.log('division :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertPerson = (filter1, filter2) => {
    const sql = 'insert into PersonManagement({0}) values({1})'.format(
      filter1,
      filter2
    )

    console.log('insertPerson :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertPhoneNumbers = (filter) => {
    const sql = 'insert into PhoneNumbers(pmId, pnId, phoneNumber) values {0}'.format(
      filter
    )

    console.log('insertPhoneNumbers :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.insertEmails = (filter) => {
    const sql = 'insert into emails(pmId, emId, email) values {0}'.format(
      filter
    )

    console.log('insertEmails :', sql)

    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }
}
