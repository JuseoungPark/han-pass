module.exports = function(db, dbHandle) {
  db.getCallHistoryCount = function(filter) {
    var sql = 'select count(*) as count from callHistory {0}'.format(filter)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallHistory = (page, limit, filter, order) => {
    var sql = 'select row_number() over (order by {1}) RowNum, *, (select no from Bookmark b where b.mediaNo = a.no and b.mediaType = "통화" and b.restore = "N") as bookmark from callHistory a {0} order by {1} limit ? offset ?'.format(
      filter,
      order
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallHistoryDateMinMax = (filter) => {
    var sql = 'select min(date) as min, max(date) as max from callHistory {0}'.format(
      filter
    )

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve({ min: '', max: '' })
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallHistoryFrequencyCount = function(filter) {
    var sql = 'select count(*) as count from (select count(*) from CallHistory{0} group by outgoingNumber, incommingNumber)'.format(
      filter
    )
    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallHistoryFrequency = (page, limit, filter, order) => {
    // var sql = 'select row_number () over (order by count(*) desc) as no, outgoingUser, outgoingSubscriber, outgoingNumber, incommingUser, incommingSubscriber, incommingNumber, count(*) as count from CallHistory{0} group by outgoingNumber, incommingNumber order by count desc limit ? offset ?'.format(
    //   filter
    // )
    var sql = 'select row_number() over (order by {1}) RowNum, outgoingUser, outgoingSubscriber, outgoingNumber, incommingUser, incommingSubscriber, incommingNumber, count(*) from CallHistory{0} group by outgoingNumber, incommingNumber order by {1} limit ? offset ?'.format(
      filter,
      order
    )

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallHistoryFrequencyByNumber = (outgoingNumber, incommingNumber) => {
    var sql =
      'select date, count(*) as count from CallHistory where outgoingNumber = ? and incommingNumber = ? group by date order by date'

    return new Promise(function(resolve) {
      dbHandle.all(sql, [outgoingNumber, incommingNumber], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallHistoryUsersOutgoing = () => {
    return new Promise(function(resolve) {
      dbHandle.all(
        'select distinct outgoingUser as name from CallHistory',
        (err, row) => {
          if (err) resolve([])
          else {
            resolve(row)
          }
        }
      )
    })
  }

  db.getCallHistoryUsersIncomming = () => {
    return new Promise(function(resolve) {
      dbHandle.all(
        'select distinct incommingUser as name from CallHistory',
        (err, row) => {
          if (err) resolve([])
          else {
            resolve(row)
          }
        }
      )
    })
  }

  db.updateHistory = (update, where) => {
    const sql = `UPDATE CallHistory SET {0} WHERE {1}`.format(update, where)
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err) => {
        if (err) resolve(err)
        else {
          resolve(1)
        }
      })
    })
  }

  db.getCallStationCount = function(filter) {
    // var sql = 'select count(*) as count from CallStation {0}'.format(filter)
    var sql = `
    SELECT
      row_number() over () count
    FROM
      CallHistory
    {0}
    group by station, address
    order by count desc
    limit 1
    `.format(filter)
    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallStation = (page, limit, filter) => {
    // var sql = 'select station, address, callCount, numberCount from CallStation {0} order by station limit ? offset ?'.format(
    //   filter
    // )
    var sql = `
    SELECT
      station,
      address,
      count(date) as callCount,
      count(distinct outgoingNumber) as numberCount
    FROM
      CallHistory
    {0}
    group by station, address
    order by station asc
    limit ? offset ?
    `.format(filter)
    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallStationMoveCount = function(filter) {
    var sql = 'select count(*) as count from (select outgoingUser, outgoingSubscriber, outgoingNumber, station as station1, address as address1, dateTime, count(*) as callCount1 from CallHistory {0} group by outgoingUser, outgoingSubscriber, station, address)'.format(
      filter
    )
    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallStationMove = (page, limit, filter, order) => {
    var sql = `
      select
        outgoingUser,
        outgoingSubscriber,
        outgoingNumber,
        station as station1,
        address as address1,
        dateTime,
        length,
        count(*) as callCount1
      from CallHistory
      {0}
      group by outgoingUser, outgoingSubscriber, outgoingNumber, station, address
      order by {1}
      limit ? offset ?
    `.format(filter, order)
    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallStationOutgoingNumberCount = function(filter) {
    var sql = 'select count(*) as count from (select count(no) from CallHistory {0} group by outgoingNumber, outgoingUser)'.format(
      filter
    )
    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallStationOutgoingNumber = (page, limit, filter) => {
    var sql = 'select no, outgoingUser, outgoingNumber, count(*) as callCount from CallHistory {0} group by outgoingNumber, outgoingUser order by datetime limit ? offset ?'.format(
      filter
    )
    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallSubscriberCount = (filter) => {
    var sql = `
      select
        count(*) as count
      from CallSubscriber
      where name in (select outgoingSubscriber as name from callHistory union select incommingSubscriber from callHistory)
      {0}`.format(filter)
    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallSubscriber = (page, limit, filter, order) => {
    var sql = `
      select
        row_number() over (order by {1}) RowNum,
        no,
        name,
        telecom,
        number as subscriberNumber,
        address,
        joinDate,
        terminationDate,
        comment
      from CallSubscriber
      where name in (select outgoingSubscriber as name from callHistory union select incommingSubscriber from callHistory)
      {0}
      order by {1} limit ? offset ?`.format(filter, order)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallTelecom = () => {
    const sql = 'select telecom from CallSubscriber group by telecom'
    return new Promise(function(resolve) {
      dbHandle.all(sql, (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallNumberCount = (filter, filter2) => {
    var sql = `
      select
        count(*) as count
      from (
        select outgoingNumber as number, outgoingUser as user from callHistory {0}
        union
        select incommingNumber as number, incommingUser as user from callHistory {0}
      )
      {1}
    `.format(filter, filter2)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallNumber = (page, limit, filter, filter2, order) => {
    var sql = `
      select
        *
      from (
        select outgoingUser as user, outgoingNumber as number from CallHistory {0}
        union
        select incommingUser as user, incommingNumber as number from CallHistory {0}
      )
      {1}
      order by {2}
      limit ? offset ?`.format(filter, filter2, order)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallCharacteristicCount = function(filter) {
    var sql = `
    select
      count(numberTable.number) as count
    from 
      (
        select outgoingNumber as number from CallHistory where exceptYN="N" {0}
        union
        select incommingNumber as number from CallHistory where exceptYN="N" {0}
      ) numberTable
    `.format(filter)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallCharacteristic = (page, limit, filter, order) => {
    var sql = `
    select
      row_number() over () RowNum,
      numberTable.number as number,
      (
        select outgoingUser as user from CallHistory where outgoingNumber = numberTable.number 
        union 
        select incommingUser as user from CallHistory where incommingNumber = numberTable.number
      ) as user,
      (
        select outgoingSubscriber as subscriber from CallHistory where outgoingNumber = numberTable.number 
        union 
        select incommingSubscriber as subscriber from CallHistory where incommingNumber = numberTable.number
      ) as subscriber,
      (
        select
          count(distinct incommingNumber)
        from CallHistory
        where exceptYN="N"
        and outgoingNumber = numberTable.number
        and incommingNumber not in (select outgoingNumber from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {0})
        {0}
      ) as inNumberCount,
      (
        select
          count(distinct outgoingNumber)
        from CallHistory
        where exceptYN="N"
        and incommingNumber = numberTable.number
        and outgoingNumber not in (select incommingNumber from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {0})
        {0}
      ) as outNumberCount,
      (
        select
          count(distinct incommingNumber)
        from CallHistory
        where exceptYN="N"
        and outgoingNumber = numberTable.number
        and incommingNumber in (select outgoingNumber from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {0})
        {0}
      ) as inOutNumberCount,
      (
        select count(date) from CallHistory where
          exceptYN="N" and
          ((outgoingNumber = numberTable.number) or
          (incommingNumber = numberTable.number) or
          (outgoingNumber in (select incommingNumber from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number)
            and incommingNumber = numberTable.number))
          {0}
      ) as totalNumberCount,
      (select count(date) from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {0}) as outCallCount,
      (select count(date) from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {0}) as inCallCount,
      (select count(date) from CallHistory where exceptYN="N" and (incommingNumber = numberTable.number or outgoingNumber = numberTable.number) {0}) as totalCallCount
    from 
      (
        select outgoingNumber as number from CallHistory where exceptYN="N" {0}
        union
        select incommingNumber as number from CallHistory where exceptYN="N" {0}
      ) numberTable
      limit ? offset ?
    `.format(filter, order)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getBetweenKeyPersonChart = (type, outgoing, incomming, filter) => {
    let outSql = `
      select
        outgoingUser,
        outgoingNumber,
        incommingUser,
        incommingNumber,
        count(date) as count,
        sum(length) as length
      from
        CallHistory
      {1}
      {2}
      group by outgoing{0}, incomming{0}
    `.format(type, outgoing, filter)
    let inSql = `
      select
        outgoingUser,
        outgoingNumber,
        incommingUser,
        incommingNumber,
        count(date) as count,
        sum(length) as length
      from
        CallHistory
      {1}
      {2}
      group by incomming{0}, outgoing{0}
    `.format(type, incomming, filter)
    let sql = ''
    if (outgoing !== null && incomming !== null) {
      sql = '{0} union {1}'.format(outSql, inSql)
    } else if (outgoing !== null) {
      sql = outSql
    } else if (incomming !== null) {
      sql = inSql
    } else return []

    return new Promise(function(resolve) {
      dbHandle.all(sql, [], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallSingularCount = function(filter, filter2) {
    var sql = `
    SELECT
      count(numberTable.number) as count
    FROM
      CallHistoryDistinctNumber numberTable,
      (
        SELECT
          numberTable.user as user,
          numberTable.number as number,
          (select count(date) from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {1}) as outgoingCount,
          (select count(date) from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {1}) as incommingCount,
          ((select count(date) from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {1}) + (select count(date) from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {1})) as inOutSum
        FROM
          CallHistoryDistinctNumber numberTable
      ) inOutTable
    where numberTable.number = inOutTable.number
    {0}
    `.format(filter, filter2)

    return new Promise(function(resolve) {
      dbHandle.each(sql, (err, row) => {
        if (err) resolve(0)
        else {
          resolve(row.count)
        }
      })
    })
  }

  db.getCallSingular = (page, limit, filter, filter2, order) => {
    var sql = `
    SELECT
      row_number() over (order by inOutTable.{2}) RowNum,
      numberTable.user as user,
      numberTable.number as number,
      inOutTable.outgoingCount as outgoingCount,
      inOutTable.incommingCount as incommingCount,
      inOutTable.inOutSum as inOutSum
    FROM
      CallHistoryDistinctNumber numberTable,
      (
        SELECT
          numberTable.user as user,
          numberTable.number as number,
          (select count(date) from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {1}) as outgoingCount,
          (select count(date) from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {1}) as incommingCount,
          ((select count(date) from CallHistory where exceptYN="N" and outgoingNumber = numberTable.number {1}) + (select count(date) from CallHistory where exceptYN="N" and incommingNumber = numberTable.number {1})) as inOutSum
        FROM
          CallHistoryDistinctNumber numberTable
      ) inOutTable
    where numberTable.number = inOutTable.number
    {0}
    order by inOutTable.{2}
    limit ? offset ?
    `.format(filter, filter2, order)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit, db.getOffset(page, limit)], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallDensityGetIncommingList = (user) => {
    var sql = `
    SELECT
      incommingUser as user,
      incommingNumber as number
    FROM
      CallHistory
    where outgoingUser = "{0}"
    group by incommingNumber
    union
    SELECT
      outgoingUser as user,
      outgoingNumber as number
    FROM
      CallHistory
    where incommingUser = "{0}"
    group by outgoingNumber
    `.format(user)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallDensityGetIncommingNumberList = (user, number, filter) => {
    var sql = `
    SELECT
      strftime('%s', dateTime) as epoch,
      *
    FROM
      CallHistory
    WHERE exceptYN="N"
    AND outgoingUser = "{0}"
    AND incommingNumber = "{1}"
    {2}
    union
    SELECT
      strftime('%s', dateTime) as epoch,
      *
    FROM
      CallHistory
    WHERE exceptYN="N" 
    AND outgoingNumber = "{1}"
    AND incommingUser = "{0}"
    {2}
    order by dateTime
      `.format(user, number, filter)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallDensity = async (
    user,
    minutes,
    count,
    page,
    limit,
    filter,
    order
  ) => {
    let incomming = []
    let incommingDetail = []
    let intervals = minutes * 60
    let i
    let j
    let k
    let l
    let offset = 0
    let found = false
    let partialCount = 0
    let rows = []
    let row = {}
    let result = {
      total: 0,
      rows: []
    }
    let ret
    let aValue
    let bValue
    let totalNo = []
    let outgoingNo = []
    let incommingNo = []

    incomming = await db.getCallDensityGetIncommingList(user)

    for (i = 0; i < incomming.length; i++) {
      incommingDetail = await db.getCallDensityGetIncommingNumberList(
        user,
        incomming[i].number,
        filter
      )

      for (j = 0; j < incommingDetail.length; j++) {
        partialCount = 1
        found = false
        for (k = j + 1; k < incommingDetail.length; k++) {
          if (
            incommingDetail[k].epoch - incommingDetail[j].epoch <=
            intervals
          ) {
            partialCount++
            found = true
          } else {
            if (partialCount >= count && found) {
              row = {
                user: '',
                number: '',
                startDatetime: '',
                endDatetime: '',
                inOutCount: 0,
                outgoingCount: 0,
                incommingCount: 0,
                totalLength: 0,
                totalNo: '',
                outgoingNo: '',
                incommingNo: ''
              }
              totalNo = []
              outgoingNo = []
              incommingNo = []
              if (incommingDetail[j].outgoingUser === user) {
                row.user = incommingDetail[j].incommingUser
                row.number = incommingDetail[j].incommingNumber
              } else {
                row.user = incommingDetail[j].outgoingUser
                row.number = incommingDetail[j].outgoingNumber
              }
              row.startDatetime = incommingDetail[j].dateTime
              row.endDatetime = incommingDetail[k - 1].dateTime

              for (l = j; l < k; l++) {
                row.totalLength += incommingDetail[l].length
                if (incommingDetail[l].outgoingUser === user) {
                  row.outgoingCount++
                  outgoingNo.push(incommingDetail[l].no)
                } else {
                  row.incommingCount++
                  incommingNo.push(incommingDetail[l].no)
                }
                row.inOutCount++
                totalNo.push(incommingDetail[l].no)
              }
              row.totalNo = totalNo.join(',')
              row.outgoingNo = outgoingNo.join(',')
              row.incommingNo = incommingNo.join(',')
              rows.push(row)

              // j = k
              break
            }
          }
        }
      }
    }

    rows.sort((a, b) => {
      ret = 0
      aValue = a[order[0]]
      bValue = b[order[0]]

      if (aValue < bValue) ret = -1
      else if (aValue > bValue) ret = 1

      if (order[1] === 'desc') ret = ret * -1
      return ret
    })

    offset = db.getOffset(page, limit)
    result.total = rows.length
    result.rows = rows.slice(offset, offset + limit)

    return result
  }

  db.getCallMaxCountUsers = (limit) => {
    var sql =
      'select user from CallHistoryDistinctNumberInOutCount group by user order by inOutSum desc limit ?'

    return new Promise(function(resolve) {
      dbHandle.all(sql, [limit], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }

  db.getCallTimebase = (user, baseDate, startDate, interval, unit) => {
    var sql = `
    select
      row_number() over (order by dateTime) RowNum,
      case when a.outgoingUser = "{0}" then a.outgoingUser else a.incommingUser end as user,
      case when a.outgoingUser = "{0}" then a.outgoingSubscriber else a.incommingSubscriber end as subscriber,
      case when a.outgoingUser = "{0}" then a.outgoingNumber else a.incommingNumber end as number,
      case when a.outgoingUser = "{0}" then a.incommingUser else a.outgoingUser end as toUser,
      case when a.outgoingUser = "{0}" then a.incommingSubscriber else a.outgoingSubscriber end as toSubscriber,
      case when a.outgoingUser = "{0}" then a.incommingNumber else a.outgoingNumber end as toNumber,
      case when a.outgoingUser = "{0}" then "outgoing" else "incomming" end as callDirection,
      strftime('%s', a.dateTime) as epoch,
      strftime('%s', a.dateTime) - strftime('%s', "{1}") as dateCreated,
      a.dateTime,
      a.day,
      a.length,
      a.type,
      a.station,
      a.address,
      a.exceptYN,
      b.no as bookmark
    from callHistory a
    left outer join Bookmark b on b.mediaNo = a.no and b.mediaType = "통화" and b.restore = "N"
    where (a.outgoingUser = "{0}" or a.incommingUser = "{0}")
    and (a.date >= "{2}" and a.date < date("{2}", "+{3} {4}"))
    order by dateTime
    `.format(user, baseDate, startDate, interval, unit)

    return new Promise(function(resolve) {
      dbHandle.all(sql, [], (err, row) => {
        if (err) resolve([])
        else {
          resolve(row)
        }
      })
    })
  }
}
