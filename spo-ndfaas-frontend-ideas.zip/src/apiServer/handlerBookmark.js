module.exports = function(server, db) {
  //-- Start of Call Bookmark(통화내역북마크), add by Dennis
  server.get('/api/call/history/bookmark', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }

    var filter = ''
    var type = 'list'
    var order = ''

    if (req.query.type) {
      type = req.query.type
    }

    if (req.query.order) {
      order = req.query.order
    } else if (type == 'list') order = 'registeredDate desc'
    //else order = 'count(*) desc'

    if (type == 'list') {
      response.total = await db.getCallHistoryBookmarkCount(filter)
      //response.total = await db.getCallHistoryBookmarkCount()
      response.rows = await db.getCallHistoryBookmark(
        response.page,
        response.limit,
        filter,
        order
      )
    }

    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.post(`/api/history/bookmark/add`, async (req, res) => {
    let response = {
      result: null,
      total: 0
    }

    if (req.body.mediaNo.length > 0) {
      let values = ''
      req.body.mediaNo.forEach((no) => {
        // mediaNo, bookmarkLevel, memo,mediaType, registeredUser, registeredDate, restore
        if (values) values += ','
        values += '({0}, 1, "test","통화", "user", DATETIME(), "N")'.format(no)
      })

      let result = await db.insertBookmark(values)
      response.result = result
      // response.total = await db.getCallHistoryBookmarkCount('')
    }
    res.response(response)
  })

  server.post(`/api/history/bookmark/delete`, async (req, res) => {
    let response = {
      result: null,
      total: 0
    }
    if (req.body.mediaNo) {
      let result = await db.deleteBookmark(req.body.mediaNo)
      response.result = result
    }
    res.response(response)
  })
  //-- End of Call Bookmark(통화내역북마크), add by Dennis

  server.post(`/api/history/except`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no.length > 0) {
      let update = 'exceptYN="{0}", exceptUser="{1}", exceptDate = DATETIME()'.format(
        req.body.except,
        req.body.user
      )
      let where = 'no in ({0})'.format(req.body.no)
      let result = await db.updateHistory(update, where)
      response.result = result
    }
    res.response(response)
  })

  /*   통합북마크 리스트
     let folderList = [
      { title: '', file: 13, color: '', content: '' },
      { title: '폴더 제목 A', file: 13, color: '#ff0000ff', content: '' },
      { title: '폴더 제목 B', file: 5, color: '#ffc000ff', content: '' },
      { title: '폴더 제목 D', file: 2, color: '#00b050ff', content: '' },
      { title: '폴더 제목 F', file: 2, color: '#00b050ff', content: '' },
      { title: '폴더 제목 H', file: 14, color: '#ff0000ff', content: '' },
      { title: '폴더 제목 C', file: 3, color: '#ffff00ff', content: '' },
      { title: '폴더 제목 E', file: 5, color: '#00b0f0ff', content: '' },
      { title: '폴더 제목 G', file: 7, color: '#7030a0ff', content: '' }
    ]
*/

  server.get('/api/bookmark/integrated/list', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }

    var filter = 'where a.no = b.mediaNo and restore = "N"'
    var order = 'registeredDate desc'

    if (req.query.idx) {
      if (filter.length > 0) filter += ' and '
      filter += 'b.no = {0}'.format(req.query.idx)
    }

    if (req.query.folderNo) {
      if (filter.length > 0) filter += ' and '
      filter += 'b.folderNo = {0}'.format(req.query.folderNo)
    }

    if (req.query.bookmarkLevel) {
      if (filter.length > 0) filter += ' and '
      filter += 'b.bookmarkLevel = {0}'.format(req.query.bookmarkLevel)
    }

    if (req.query.source) {
      let source = req.query.source.split(',')
      if (filter.length > 0) filter += ' and '
      filter += 'mediaType in ('
      source.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < source.length - 1) filter += ', '
      })
      filter += ')'
    }
    if (req.query.searchType && req.query.searchTxt) {
      if (filter.length > 0) filter += ' and '
      filter += '(outgoingUser like "%{0}%" or outgoingSubscriber like "%{0}%" or outgoingNumber like "%{0}%"'.format(
        req.query.searchTxt
      )
      filter += ' or incommingUser like "%{0}%" or incommingSubscriber like "%{0}%" or incommingNumber like "%{0}%")'.format(
        req.query.searchTxt
      )
    }

    if (req.query.order) {
      order = req.query.order
    }

    const sql = 'select row_number() over (order by registeredDate desc) RowNum, b.*, bf.color, bf.title, a.outgoingUser, a.dateTime, a.incommingUser, a.incommingNumber from callHistory a, bookmark b left outer join BookmarkFolder bf ON b.folderNo = bf.no {0} order by {1} limit ? offset ?'.format(
      filter,
      order
    )

    console.log(sql)
    response.total = await db.getIntegratedBookmarkCount(filter)
    response.rows = await db.getIntegratedBookmark(
      response.page,
      response.limit,
      filter,
      order
    )

    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  // 통합북마크 폴더리스트
  server.get('/api/bookmark/integrated/folder', async (req, res) => {
    var response = {
      total: 0,
      rows: [],
      unfolder: 0,
      important: 0
    }
    let filter = ''
    response.rows = await db.getBookmarkFolder(filter)
    response.unfolder = await db.getBookmarkUnFolderCount(filter)
    response.important = await db.getBookmarkImportantCount(filter)
    response.total = response.rows.length
    res.response(response)
  })

  // 통합북마크 폴더상세
  server.get('/api/bookmark/integrated/folder/:idx', async (req, res) => {
    var response = {
      rows: []
    }
    let filter = ''
    if (req.params.idx) {
      filter = 'and no = {0}'.format(req.params.idx)
    }
    let result = await db.getBookmarkFolder(filter)
    if (result.length > 0) response.rows = result[0]
    res.response(response)
    /*let folderList = [
      { title: '폴더 제목 A', file: 13, color: '#ff0000ff', content: '' },
      { title: '폴더 제목 B', file: 5, color: '#ffc000ff', content: '' },
      { title: '폴더 제목 D', file: 2, color: '#00b050ff', content: '' },
      { title: '폴더 제목 F', file: 2, color: '#00b050ff', content: '' },
      { title: '폴더 제목 H', file: 14, color: '#ff0000ff', content: '' },
      { title: '폴더 제목 C', file: 3, color: '#ffff00ff', content: '' },
      { title: '폴더 제목 E', file: 5, color: '#00b0f0ff', content: '' },
      { title: '폴더 제목 G', file: 7, color: '#7030a0ff', content: '' }
    ]*/
  })

  server.post(`/api/bookmark/integrated/folder/update`, async (req, res) => {
    let response = {
      result: null
    }
    console.log(req.body)
    if (req.body.no) {
      let update = 'color="{0}", title="{1}", content="{2}", updateUser="{3}", updateDate = DATETIME()'.format(
        req.body.color,
        req.body.title,
        req.body.content,
        req.body.updateUser
      )
      let where = 'no = {0}'.format(req.body.no)
      let res_update = await db.updateBookmarkFolder(update, where)
      if (res_update === 1) {
        let filter = 'and no = {0}'.format(req.body.no)
        let result = await db.getBookmarkFolder(filter)
        if (result.length > 0) {
          response.result = result[0]
        } else {
          response.result = result
        }
      } else {
        response.result = null
      }
    }
    res.response(response)
  })

  server.post(`/api/bookmark/integrated/folder/delete`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no) {
      let where = 'folderNo in ({0})'.format(req.body.no)
      let update = 'folderNo=0, updateUser="{0}", updateDate = DATETIME()'.format(
        req.body.updateUser
      )
      let res_update = await db.updateBookmark(update, where)
      let result = null
      if (res_update === 1) {
        result = await db.deleteBookmarkFolder(req.body.no)
      }
      response.result = result
    }
    res.response(response)
  })

  server.post(`/api/bookmark/integrated/folder/add`, async (req, res) => {
    let response = {
      result: null
    }
    let values = ''
    if (values) values += ','
    values += '({0}, "{1}", "{2}", "{3}", "{4}", DATETIME())'.format(
      req.body.bookmarkLevel,
      req.body.color,
      req.body.title,
      req.body.content,
      req.body.regUser
    )

    let result = []
    let res_insert = await db.insertBookmarkFolder(values)
    if (res_insert === 1) {
      let resLastId = await db.getLastInsertRowid()
      if (resLastId.length > 0) {
        let resGetFolder = await db.getBookmarkFolder(
          'and no = {0}'.format(resLastId[0].lastId)
        )
        if (resGetFolder.length > 0) {
          result = resGetFolder
        }
      }
    } else {
      result = res_insert
    }
    response.result = result
    res.response(response)
  })

  server.post(`/api/bookmark/integrated/folder/itemadd`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no.length > 0) {
      let update = 'folderNo="{0}", updateUser="{1}", updateDate = DATETIME()'.format(
        req.body.folderno,
        req.body.updateUser
      )
      let result = null
      let where = 'no in ({0})'.format(req.body.no)
      let resUpdate = await db.updateBookmark(update, where)
      if (resUpdate === 1) {
        let count = await db.getEachBookmarkFolderCount(req.body.folderno)
        update = 'count = {0}'.format(count)
        where = 'no = {0}'.format(req.body.folderno)
        result = await db.updateBookmarkFolder(update, where)
      }
      response.result = result
    }
    res.response(response)
  })

  server.post(`/api/bookmark/integrated/folder/itemdel`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no.length > 0) {
      let result = 0
      let update = 'folderNo=0, updateUser="{0}", updateDate = DATETIME()'.format(
        req.body.updateUser
      )
      let where = 'no in ({0})'.format(req.body.no)
      let resUpdate = await db.updateBookmark(update, where)

      if (resUpdate === 1) {
        let count = await db.getEachBookmarkFolderCount(req.body.folderno)
        update = 'count = {0}'.format(count)
        where = 'no = {0}'.format(req.body.folderno)
        result = await db.updateBookmarkFolder(update, where)
      }
      response.result = result
    }
    res.response(response)
  })

  server.post(`/api/bookmark/important`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no) {
      let update = 'bookmarkLevel={0}, updateUser="{1}", updateDate = DATETIME()'.format(
        req.body.bookmarkLevel,
        req.body.updateUser
      )
      let where = 'no in ({0})'.format(req.body.no)
      console.log(update, where)
      let result = await db.updateBookmark(update, where)
      response.result = result
    }
    res.response(response)
  })

  server.post(`/api/bookmark/update/memo`, async (req, res) => {
    let response = {
      result: null
    }
    if (req.body.no) {
      let update = 'memo="{0}", updateUser="{1}", updateDate = DATETIME()'.format(
        req.body.memo,
        req.body.updateUser
      )
      let where = 'no in ({0})'.format(req.body.no)
      console.log(update, where)
      let result = await db.updateBookmark(update, where)
      response.result = result
    }
    res.response(response)
  })

  // 변경이력
  server.get('/api/bookmark/integrated/modihistory', async (req, res) => {
    var response = {
      total: 0,
      rows: []
    }
    let dummy = {
      RowNum: 1,
      source: '통화',
      title: '통화분석',
      modDate: '2020-10-11 15:30',
      content: '수신자 홍길동',
      regUser: '등록자'
    }
    let i = 0
    while (i < 10) {
      let row = {
        ...dummy,
        RowNum: dummy.RowNum + i,
        regUser: `${dummy.regUser}${i}`
      }
      response.rows.push(row)
      i++
    }
    response.total = response.rows.length
    res.response(response)
  })
}
