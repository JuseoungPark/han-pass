module.exports = function(server, db) {
  server.parseWeekofdayTime = (query) => {
    let weekofdayTime = query.split(',')
    let filter = ''

    filter += ' ('
    weekofdayTime.forEach((e, eIndex) => {
      let [day, week] = e.split('|')
      let wItem

      if (eIndex > 0) filter += ' or '

      filter += '('

      day.split(':').forEach((d, dIndex) => {
        if (!d.length) return false
        if (dIndex === 0) filter += 'day in ('
        if (dIndex > 0) filter += ','
        filter += '"{0}"'.format(d)
        if (dIndex === day.split(':').length - 1) filter += ')'
      })

      if (day.length && week.length) filter += ' and'

      if (week.length) filter += ' ('
      week.split('!').forEach((w, wIndex) => {
        if (!w.length) return false
        if (wIndex !== 0) filter += ' or '
        wItem = w.split(':')
        if (wItem.length === 1) {
          filter += '(time >= "{0}:00:00" and time <= "{1}:59:59")'.format(
            wItem[0].length === 1 ? '0' + wItem[0] : wItem[0],
            wItem[0].length === 1 ? '0' + wItem[0] : wItem[0]
          )
        } else {
          filter += '(time >= "{0}:00:00" and time <= "{1}:59:59")'.format(
            wItem[0].length === 1 ? '0' + wItem[0] : wItem[0],
            wItem[1].length === 1 ? '0' + wItem[1] : wItem[1]
          )
        }
      })
      if (week.length) filter += ')'

      filter += ')'
    })
    filter += ')'

    return filter
  }

  server.parseCallType = (query) => {
    let filter = ''
    let type = query.split(',')
    if (type.length !== 3) {
      filter += ' ('
      type.forEach((e, i) => {
        if (e === 'call') {
          filter +=
            ' type in ("국내음성통화", "망내통화", "망외통화", "VOLTE 음성", "VOLTE-망내음성", "VOLTE-망내음성(VOLTE간)", "VOLTE-망외음성", "VOLTE-망외음성(VOLTE간)", "음성", "음성[듀얼번호발신]", "로밍 SMS 착신 3G", "화상전화", "KT114 직접연결서비스 통화", "PSVT-4G망내영상", "통합사서함(음성)", "컬러메일통화", "폰메일통화")'
        }
        if (e === 'message') {
          filter +=
            ' type in ("140byte초과 장문메시지", "VOLTE 문자", "메시지송신", "MMS", "SMS", "멀티메일(100k byte초과 그림/소리포함)", "멀티메일(30~100k byte 그림/소리포함)", "멀티메일(30k byte이하 그림/소리포함)")'
        }
        if (e === 'etc') {
          filter +=
            ' type in ("3G", "KT114 안내료", "갤럭시아컴즈_미납가산금", "데이타정보", "디지털컨텐츠(SK플래닛)", "디지털컨텐츠(다날)", "디지털컨텐츠(모빌리언스)", "모빌리언스_미납가산금", "선불가입자 일기본료 총합 feature", "실물2(SK플래닛)", "실물2(갤럭시아컴즈)", "실물2(다날)", "실물2(모빌리언스)", "실물3(모빌리언스)", "안드로이드마켓:안드로이드마켓")'
        }
        if (i < type.length - 1) filter += ' or'
      })
      filter += ')'
    }

    return filter
  }

  server.parseDate = (query) => {
    let date = query.split(',')
    let filter = ''

    filter += ' ('
    date.forEach((e, i) => {
      if (i % 2 == 0) {
        filter += ' (date >= "{0}" and date <= "{1}")'.format(
          date[i],
          date[i + 1]
        )
        if (i < date.length - 2) filter += ' or'
      }
    })
    filter += ')'

    return filter
  }

  server.get('/api/call/count', async (req, res) => {
    var response = {
      historyCount: 0,
      subscriberCount: 0,
      numberCount: 0
    }

    response.historyCount = await db.getCallHistoryCount('')
    response.subscriberCount = await db.getCallSubscriberCount('')
    response.numberCount = await db.getCallNumberCount('')

    res.response(response)
  })

  server.get('/api/call/history/users/outgoing', async (req, res) => {
    res.response({ rows: await db.getCallHistoryUsersOutgoing() })
  })

  server.get('/api/call/history/users/incomming', async (req, res) => {
    res.response({ rows: await db.getCallHistoryUsersIncomming() })
  })

  server.get('/api/call/history/date-min-max', async (req, res) => {
    var response = {
      min: '',
      max: ''
    }
    var data = {}

    var filter = ''
    if (req.query.outgoingUser) {
      if (filter.length == 0) filter += ' where'
      filter += ' outgoingUser in ({0})'.format(req.query.outgoingUser)
    }

    if (req.query.incommingUser) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' incommingUser in ({0})'.format(req.query.incommingUser)
    }

    if (req.query.outgoingNumber) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' outgoingNumber = "{0}"'.format(req.query.outgoingNumber)
    }

    data = await db.getCallHistoryDateMinMax(filter)
    response.min = data.min
    response.max = data.max

    res.response(response)
  })

  server.get('/api/call/history', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    var filter = ''
    var type = 'list'
    var order = ''
    var users = []

    if (req.query.type) {
      type = req.query.type
    }

    if (req.query.except) {
      filter = ' where exceptYN="Y"'
    } else {
      filter = ' where exceptYN="N"'
    }

    if (req.query.exceptnumber) {
      filter += ' and (outgoingNumber like "%{0}%" or incommingNumber like "%{0}%")'.format(
        req.query.exceptnumber
      )
    }

    if (req.query.exceptuser) {
      filter += ' and exceptUser like "%{0}%"'.format(req.query.exceptuser)
    }

    if (req.query.exceptdate) {
      let d = req.query.exceptdate.split(',')
      if (d.length === 2) {
        filter += ' and (exceptDate >= "{0}" and exceptDate <= "{1}")'.format(
          d[0],
          d[1]
        )
      }
    }

    if (req.query.outgoingUsers) {
      users = req.query.outgoingUsers.split(',')
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += ' outgoingUser in ('
      users.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < users.length - 1) filter += ', '
      })
      filter += ')'
    }

    if (req.query.incommingUsers) {
      users = req.query.incommingUsers.split(',')
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += ' incommingUser in ('
      users.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < users.length - 1) filter += ', '
      })
      filter += ')'
    }

    if (req.query.outgoingNumber) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' outgoingNumber = "{0}"'.format(req.query.outgoingNumber)
    }

    if (req.query.incommingNumber) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' incommingNumber = "{0}"'.format(req.query.incommingNumber)
    }

    if (req.query.station) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' station like "%{0}%"'.format(req.query.station)
    }

    if (req.query.date) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += server.parseDate(req.query.date)
    }

    if (req.query.callType) {
      let type = req.query.callType.split(',')
      if (type.length !== 3) {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'

        filter += server.parseCallType(req.query.callType)
      }
    }

    if (req.query.weekofdayTime) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    if (req.query.order) {
      order = req.query.order
    } else if (type == 'list') order = 'dateTime desc'
    else order = 'count(*) desc'

    if (req.query.except) order = 'exceptDate desc'

    if (type == 'list') {
      response.total = await db.getCallHistoryCount(filter)
      if (response.limit !== -1 || response.total < server.excelLimitCount) {
        response.rows = await db.getCallHistory(
          response.page,
          response.limit,
          filter,
          order
        )
      }
    } else if (type == 'frequency') {
      response.total = await db.getCallHistoryFrequencyCount(filter)
      if (response.limit !== -1 || response.total < server.excelLimitCount) {
        response.rows = await db.getCallHistoryFrequency(
          response.page,
          response.limit,
          filter,
          order
        )
      }
    }
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )
    // console.log(filter)
    res.response(response)
  })

  server.get('/api/call/history/popup', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    let valus = []
    let users = []
    var filter = ''
    var order = 'dateTime desc'
    filter = ' where exceptYN="N"'

    if (req.query.users) {
      let users = req.query.users.split(',')
      let inFilter = ''
      let outFilter = ''

      inFilter += 'incommingUser in ('
      outFilter += 'outgoingUser in ('
      users.forEach((e, i) => {
        inFilter += '"{0}"'.format(e)
        outFilter += '"{0}"'.format(e)
        if (i < users.length - 1) {
          inFilter += ', '
          outFilter += ', '
        }
      })
      inFilter += ')'
      outFilter += ')'

      filter += ' and ({0} or {1})'.format(inFilter, outFilter)
    }

    if (req.query.outgoingUsers) {
      users = req.query.outgoingUsers.split(',')

      filter += ' and outgoingUser in ('
      users.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < users.length - 1) filter += ', '
      })
      filter += ')'
    }

    if (req.query.outgoingUser !== undefined) {
      filter += ' and outgoingUser = "{0}"'.format(req.query.outgoingUser)
    }

    if (req.query.outgoingSubscriber !== undefined) {
      filter += ' and outgoingSubscriber = "{0}"'.format(
        req.query.outgoingSubscriber
      )
    }

    if (req.query.outgoingNumber !== undefined) {
      filter += ' and outgoingNumber = "{0}"'.format(req.query.outgoingNumber)
    }

    if (req.query.incommingUsers) {
      users = req.query.incommingUsers.split(',')

      filter += ' and incommingUser in ('
      users.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < users.length - 1) filter += ', '
      })
      filter += ')'
    }

    if (req.query.incommingNumber) {
      filter += ' and incommingNumber = "{0}"'.format(req.query.incommingNumber)
    }

    if (req.query.outgoingIncommingNumber) {
      filter += ' and (outgoingNumber = "{0}" or incommingNumber = "{0}")'.format(
        req.query.outgoingIncommingNumber
      )
    }

    if (req.query.date) {
      if (filter.length !== 0) filter += ' and'
      filter += server.parseDate(req.query.date)
    }

    if (req.query.weekofdayTime) {
      if (filter.length !== 0) filter += ' and'
      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    if (req.query.address) {
      filter += ' and address = "{0}"'.format(req.query.address)
    }

    if (req.query.station !== undefined) {
      filter += ' and station = "{0}"'.format(req.query.station)
    }

    if (req.query.callType) {
      let type = req.query.callType.split(',')
      if (type.length !== 3) {
        if (filter.length !== 0) filter += ' and'

        filter += server.parseCallType(req.query.callType)
      }
    }

    if (req.query.order) {
      order = req.query.order
    }

    if (req.query.nos) {
      valus = req.query.nos.split(',')

      filter = '  where exceptYN="N" and no in ('
      valus.forEach((e, i) => {
        filter += '{0}'.format(e)
        if (i < valus.length - 1) filter += ', '
      })
      filter += ')'
    }

    response.total = await db.getCallHistoryCount(filter)
    if (response.limit !== -1 || response.total < server.excelLimitCount) {
      response.rows = await db.getCallHistory(
        response.page,
        response.limit,
        filter,
        order
      )
    }
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )
    console.log(filter)
    res.response(response)
  })

  server.get('/api/call/history/frequency-number', async (req, res) => {
    var response = {
      rows: []
    }

    response.rows = await db.getCallHistoryFrequencyByNumber(
      req.query.outgoingNumber,
      req.query.incommingNumber
    )

    res.response(response)
  })

  server.get('/api/call/station', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    var filter = ''
    var order = 'dateTime desc'
    if (req.query.date) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      if (req.query.date.includes(',')) {
        let date = req.query.date.split(',')
        filter += ' date >= "{0}" and date <= "{1}"'.format(date[0], date[1])
      } else {
        filter += ' date = "{0}"'.format(req.query.date)
      }
    }

    if (req.query.outgoingUsers) {
      req.query.outgoingUsers = req.query.outgoingUsers
        .split(',')
        .map((user) => {
          return '"{0}"'.format(user)
        })
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' outgoingUser in ({0})'.format(req.query.outgoingUsers)
    }

    if (req.query.incommingUsers) {
      req.query.incommingUsers = req.query.incommingUsers
        .split(',')
        .map((user) => {
          return '"{0}"'.format(user)
        })
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' incommingUser in ({0})'.format(req.query.incommingUsers)
    }

    if (req.query.station) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' station like "%{0}%"'.format(req.query.station)
    }

    if (req.query.addrType) {
      if (req.query.addrType === 'success') {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'
        filter += ' address <> ""'
      } else if (req.query.addrType === 'fail') {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'
        filter += ' address = ""'
      }
    }

    if (req.query.weekofdayTime) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }
    if (req.query.type === 'mv') {
      response.total = await db.getCallStationMoveCount(filter)
      response.rows = await db.getCallStationMove(
        response.page,
        response.limit,
        filter,
        order
      )
    } else {
      response.total = await db.getCallStationCount(filter)
      response.rows = await db.getCallStation(
        response.page,
        response.limit,
        filter
      )
    }
    res.response(response)
  })

  server.get('/api/call/station/outgoingnumber', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    var filter = ' where exceptYN="N"'
    if (req.query.outgoingUsers) {
      let users = req.query.outgoingUsers.split(',')
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += ' outgoingUser in ('
      users.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < users.length - 1) filter += ', '
      })
      filter += ')'
    }
    if (req.query.date) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += server.parseDate(req.query.date)
    }
    if (req.query.weekofdayTime) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }
    if (req.query.station) {
      if (filter.length == 0) filter += ' where'
      else filter += ' and'
      filter += ' station = "{0}"'.format(req.query.station)
    }
    response.total = await db.getCallStationOutgoingNumberCount(filter)
    response.rows = await db.getCallStationOutgoingNumber(
      response.page,
      response.limit,
      filter
    )
    res.response(response)
  })

  server.get(
    '/api/call/station/outgoingnumber/callhistory',
    async (req, res) => {
      var response = {
        total: 0,
        limit: req.query.limit ? Number(req.query.limit) : 20,
        page: req.query.page ? Number(req.query.page) : 1,
        prevPage: 0,
        nextPage: 0,
        rows: []
      }
      var filter = ' where exceptYN="N"'
      if (req.query.user) {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'
        filter += ' outgoingUser = "{0}"'.format(req.query.user)
      }
      if (req.query.number) {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'
        filter += ' outgoingNumber = "{0}"'.format(req.query.number)
      }
      if (req.query.station) {
        if (filter.length == 0) filter += ' where'
        else filter += ' and'
        filter += ' station = "{0}"'.format(req.query.station)
      }
      let order = 'dateTime'
      if (req.query.number) {
        response.total = await db.getCallHistoryCount(filter)
        response.rows = await db.getCallHistory(
          response.page,
          response.limit,
          filter,
          order
        )
      }
      res.response(response)
    }
  )

  server.get('/api/call/subscriber', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    var filter = ''
    var order = 'name'

    if (req.query.name) {
      filter += ' and name in ({0})'.format(req.query.name)
    }

    if (req.query.subscriber) {
      filter += ' and name like "%{0}%"'.format(req.query.subscriber)
    }

    if (req.query.number) {
      filter += ' and number like "%{0}%"'.format(req.query.number)
    }

    if (req.query.telecom && req.query.telecom !== 'all') {
      if (req.query.telecom === 'LG U ') req.query.telecom = 'LG U+'
      filter += ' and telecom like "%{0}%"'.format(req.query.telecom)
    }

    if (req.query.joinDate) {
      let date = req.query.joinDate.split(',')
      filter += ' and (joinDate >= "{0}" and joinDate <= "{1}")'.format(
        date[0],
        date[1]
      )
    }

    if (req.query.terminationDate) {
      let date = req.query.terminationDate.split(',')
      //  or terminationDate="개통" or terminationDate=""
      filter += ' and ((terminationDate >= "{0}" and terminationDate <= "{1}"))'.format(
        date[0],
        date[1]
      )
    }

    if (req.query.order) {
      order = req.query.order
    }
    console.log(filter)
    response.total = await db.getCallSubscriberCount(filter)
    response.rows = await db.getCallSubscriber(
      response.page,
      response.limit,
      filter,
      order
    )
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  // 통신사 선택
  server.get('/api/call/telecom', async (req, res) => {
    var response = {
      total: 0,
      rows: []
    }
    response.rows = await db.getCallTelecom()
    response.total = response.rows.length
    res.response(response)
  })

  server.get('/api/call/number', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    var filter = ''
    var filter2 = ''
    var order = 'user'

    if (req.query.users) {
      let users = req.query.users.split(',')

      filter2 += ' where user in ('

      users.forEach((e, i) => {
        filter2 += '"{0}"'.format(e)
        if (i < users.length - 1) {
          filter2 += ', '
        }
      })
      filter2 += ')'
    }

    if (req.query.name) {
      if (filter.length === 0) filter += ' where'
      else filter += ' and'
      filter += ' name in ({0})'.format(req.query.name)
    }

    if (req.query.incommingNumberOnly) {
      if (filter.length === 0) filter += ' where'
      else filter += ' and'

      filter += `
        number in (
          select
            distinct outgoingNumber as number
          from CallHistory
          where incommingNumber = "{0}"
          and outgoingNumber not in (select incommingNumber from CallHistory where outgoingNumber = "{0}")
        )
      `.format(req.query.incommingNumberOnly)
    }

    if (req.query.outgoingNumberOnly) {
      if (filter.length === 0) filter += ' where'
      else filter += ' and'

      filter += `
        number in (
          select
            distinct incommingNumber as number
          from CallHistory
          where outgoingNumber = "{0}"
          and incommingNumber not in (select outgoingNumber from CallHistory where incommingNumber = "{0}")
        )
      `.format(req.query.outgoingNumberOnly)
    }

    if (req.query.outgoingIncommingNumberSum) {
      if (filter.length === 0) filter += ' where'
      else filter += ' and'

      filter += `
        number in (
          select
            distinct outgoingNumber as number
          from CallHistory
          where incommingNumber = "{0}"
          and outgoingNumber in (select incommingNumber from CallHistory where outgoingNumber = "{0}")
        )
      `.format(req.query.outgoingIncommingNumberSum)
    }

    if (req.query.numbers) {
      let numbers = req.query.numbers.split(',')
      if (filter.length == 0) filter += ' where'
      else filter += ' and'

      filter += ' number in ('
      numbers.forEach((e, i) => {
        filter += '"{0}"'.format(e)
        if (i < numbers.length - 1) filter += ', '
      })
      filter += ')'
    }

    if (req.query.order) {
      order = req.query.order
    }

    response.total = await db.getCallNumberCount(filter, filter2)
    response.rows = await db.getCallNumber(
      response.page,
      response.limit,
      filter,
      filter2,
      order
    )
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.get('/api/call/characteristic', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }

    var filter = ''
    var order = ''

    if (req.query.users) {
      let users = req.query.users.split(',')
      let inFilter = ''
      let outFilter = ''

      inFilter += 'incommingUser in ('
      outFilter += 'outgoingUser in ('
      users.forEach((e, i) => {
        inFilter += '"{0}"'.format(e)
        outFilter += '"{0}"'.format(e)
        if (i < users.length - 1) {
          inFilter += ', '
          outFilter += ', '
        }
      })
      inFilter += ')'
      outFilter += ')'

      filter += ' and ({0} or {1})'.format(inFilter, outFilter)
    }

    if (req.query.date) {
      filter += ' and'
      filter += server.parseDate(req.query.date)
    }

    if (req.query.callType) {
      let type = req.query.callType.split(',')
      if (type.length !== 3) {
        filter += ' and'

        filter += server.parseCallType(req.query.callType)
      }
    }

    if (req.query.weekofdayTime) {
      filter += ' and'

      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    response.total = await db.getCallCharacteristicCount(filter)
    response.rows = await db.getCallCharacteristic(
      response.page,
      response.limit,
      filter,
      order
    )

    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.get('/api/call/between-key-person/charts', async (req, res) => {
    var response = {
      rows: []
    }
    let type = 'user'
    let capitalizeFirstLetterType = ''
    let filter = ''
    let users = []
    let rows = []
    let outgoing = ''
    let incomming = ''
    let usersString = ''
    let inOut = 'incomming,outgoing'
    let i

    let userRows = await db.getPersonManagement(1, -1, ' AND p.personType < 51')
    userRows.forEach((e) => {
      users.push(e.name)
    })

    for (i = 0; i < users.length; i++) {
      usersString += '"{0}"'.format(users[i])
      if (i < users.length - 1) {
        usersString += ', '
      }
    }

    if (req.query.chartType) {
      type = req.query.chartType
    }
    capitalizeFirstLetterType = type.charAt(0).toUpperCase() + type.slice(1)

    if (req.query.inOut) inOut = req.query.inOut

    if (req.query.date) {
      if (filter.length > 0) filter += ' and'
      filter += server.parseDate(req.query.date)
    }

    if (req.query.weekofdayTime) {
      if (filter.length > 0) filter += ' and'
      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    if (req.query.users) {
      users = req.query.users.split(',')
      // } else if (type === 'number' && req.query.numbers) {
      //   condition = req.query.numbers.split(',')
      for (i = 0; i < users.length; i++) {
        outgoing = 'where outgoingUser = "{0}" and incommingUser in ({1})'.format(
          users[i],
          usersString
        )
        incomming = 'where incommingUser = "{0}" and outgoingUser in ({1})'.format(
          users[i],
          usersString
        )

        rows = await db.getBetweenKeyPersonChart(
          capitalizeFirstLetterType,
          inOut.includes('outgoing') ? outgoing : null,
          inOut.includes('incomming') ? incomming : null,
          ' and {0}'.format(filter)
        )
        response.rows = response.rows.concat(rows)
      }
    } else {
      outgoing = 'where outgoingUser in ({0}) and incommingUser in ({0})'.format(
        usersString
      )
      incomming = 'where incommingUser in ({0}) and outgoingUser in ({0})'.format(
        usersString
      )

      rows = await db.getBetweenKeyPersonChart(
        capitalizeFirstLetterType,
        inOut.includes('outgoing') ? outgoing : null,
        inOut.includes('incomming') ? incomming : null,
        ' and {0}'.format(filter)
      )
      response.rows = response.rows.concat(rows)
    }

    res.response(response)
  })

  server.get('/api/call/singular', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    let filter = ''
    let filter2 = ''
    let order = 'outgoingCount desc'
    let inOutSum = 50
    let difference = 90

    if (req.query.inOutSum) {
      inOutSum = Number(req.query.inOutSum)
    }
    filter += 'and inOutTable.inOutSum >= {0}'.format(inOutSum)

    if (req.query.difference) {
      difference = Number(req.query.difference)
    }
    filter += ' and (cast(abs(inOutTable.outgoingCount - inOutTable.incommingCount) as real) / cast((case when(inOutTable.outgoingCount >= inOutTable.incommingCount) then inOutTable.outgoingCount else inOutTable.incommingCount end) as real) * 100) >= {0}'.format(
      difference
    )

    if (req.query.date) {
      filter2 += ' and'
      filter2 += server.parseDate(req.query.date)
    }

    if (req.query.callType) {
      let type = req.query.callType.split(',')
      if (type.length !== 3) {
        filter2 += ' and'

        filter2 += server.parseCallType(req.query.callType)
      }
    }

    if (req.query.weekofdayTime) {
      filter2 += ' and'

      filter2 += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    if (req.query.order) {
      order = req.query.order
    }

    response.total = await db.getCallSingularCount(filter, filter2)
    response.rows = await db.getCallSingular(
      response.page,
      response.limit,
      filter,
      filter2,
      order
    )

    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.get('/api/call/density', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    let filter = ''
    let order = ['startDatetime', 'asc']
    let result = {}
    let user = ''
    let minutes = 60
    let count = 2

    if (req.query.users) {
      user = req.query.users
    }

    if (req.query.minutes) {
      minutes = Number(req.query.minutes)
    }

    if (req.query.count) {
      count = Number(req.query.count)
    }

    if (req.query.date) {
      filter += ' and'
      filter += server.parseDate(req.query.date)
    }

    if (req.query.weekofdayTime) {
      filter += ' and'
      filter += server.parseWeekofdayTime(req.query.weekofdayTime)
    }

    if (req.query.callCondition) {
      if (req.query.callCondition === 'call') {
        filter += ' and'
        filter += server.parseCallType(req.query.callCondition)
      }
    }

    if (req.query.order) {
      order = req.query.order.split(' ')
    }

    // response.total = await db.getCallDensityCount()
    result = await db.getCallDensity(
      user,
      minutes,
      count,
      response.page,
      response.limit,
      filter,
      order
    )

    response.total = result.total
    response.rows = result.rows
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.get('/api/call/max-count-users', async (req, res) => {
    var response = {
      rows: []
    }

    let limit = req.query.limit ? Number(req.query.limit) : 5

    response.rows = await db.getCallMaxCountUsers(limit)

    res.response(response)
  })

  server.get('/api/call/timebase', async (req, res) => {
    var response = {
      rows: []
    }

    let users = req.query.users ? req.query.users.split(',') : []
    let baseDate = req.query.baseDate ? req.query.baseDate : ''
    let startDate = req.query.startDate ? req.query.startDate : ''
    let interval = req.query.interval ? Number(req.query.interval) : 5
    let unit = req.query.unit ? req.query.unit : 'day'
    let i
    let rows = []

    if (users.length > 0 && baseDate !== '' && startDate !== '') {
      for (i = 0; i < users.length; i++) {
        rows = await db.getCallTimebase(
          users[i],
          baseDate,
          startDate,
          interval,
          unit
        )
        response.rows = response.rows.concat(rows)
      }
    }

    res.response(response)
  })
}
