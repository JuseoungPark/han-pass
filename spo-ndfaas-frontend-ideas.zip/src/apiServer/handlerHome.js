module.exports = function(server) {
  // 디지털증거처리현황
  server.get('/api/evidence/process/status', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    let dummy = {
      RowNum: 1,
      code: 1234500,
      type: '통화내역',
      company: '㈜OO',
      depth: '회계팀',
      rUser: '홍길동',
      regDate: '2020-10-10 20:00',
      extFileCode: 'ABC001',
      extFileRegDate: '2020-10-10 20:00',
      indexCompleteDate: '2020-10-10 20:00',
      indexComplete: 20,
      cryptoDetect: 3,
      DRMDetect: 10,
      virusDetect: 3
    }
    let i = 0
    while (i < 20) {
      let row = { ...dummy, RowNum: dummy.RowNum + i, code: dummy.code + i }
      if (i > 5 && i < 15) {
        row.extFileRegDate = ''
        row.indexComplete = 0
        row.cryptoDetect = 0
        row.DRMDetect = 0
        row.virusDetect = 0
        row.indexCompleteDate = ''
      }
      response.rows.push(row)
      i++
    }
    response.rows.sort((a, b) => {
      return b.RowNum - a.RowNum
    })
    response.total = response.rows.length
    response.prevPage = 0
    response.nextPage = 0
    res.response(response)
  })
}
