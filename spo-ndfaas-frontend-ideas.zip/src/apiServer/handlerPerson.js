module.exports = function(server, db) {
  server.get('/api/person-management/persons', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }
    let filter = ''

    // 주요인물 선택시 personType = 61, 61 입력시 기타 51번 이하(피의,혐의,참고,피해)검색
    if (req.query.personType) {
      if (req.query.personType < 61) {
        filter += ' AND p.personType = {0}'.format(req.query.personType)
      } else {
        filter += ' AND p.personType < 51'.format(req.query.personType)
      }
    }

    if (req.query.name) {
      filter += ' AND p.name = "{0}"'.format(req.query.name)
    }

    if (req.query.keyword) {
      // filter += filter.length == 0 ? ' where' : ' and'
      filter += ' AND ( no || name || t.ptName || phoneNumber || email || nickname || c.comName || d.divName || joinDate || updateDate || registeredUser || evidenceNumber || memo || keyword ) like "%{0}%"'.format(
        req.query.keyword
      )
    }

    response.total = await db.getPersonManagementCount(filter)
    response.rows = await db.getPersonManagement(
      response.page,
      response.limit,
      filter
    )
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )

    res.response(response)
  })

  server.get(
    '/api/person-management/totalNumByPersonType',
    async (req, res) => {
      let response = {
        rows: []
      }

      response.rows = await db.getTotalNumByPersonType()

      res.response(response)
    }
  )

  server.get('/api/person-management/persons/update-date', async (req, res) => {
    let response = {
      lastUpdateTime: ''
    }

    response.lastUpdateTime = await db.getLastUpdateTime()

    res.response(response)
  })

  server.get('/api/person-management/persons/merge', async (req, res) => {
    var response = {
      total: 0,
      limit: req.query.limit ? Number(req.query.limit) : 20,
      page: req.query.page ? Number(req.query.page) : 1,
      prevPage: 0,
      nextPage: 0,
      rows: []
    }

    let filter = ''
    if (req.query.mergeId) {
      filter = ` 
      WHERE p.merge = '${req.query.mergeId}'
      OR p.represent = '${req.query.mergeId}'
      `
    }

    response.total = await db.getPersonsMergeCount(filter)
    response.rows = await db.getPersonsMerge(
      response.page,
      response.limit,
      filter
    )
    response.prevPage = db.getPrevPage(response.page)
    response.nextPage = db.getNextPage(
      response.page,
      response.limit,
      response.total
    )
    res.response(response)
  })

  server.get('/api/person-management/groups/persons-num', async (req, res) => {
    let response = {
      rows: []
    }

    response.rows = await db.getTotalNumByGroup()

    res.response(response)
  })

  server.get('/api/person-management/groups/persons', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.personGroup) {
      filter = ` WHERE pmpg.pgId = ${req.query.personGroup}`
    }

    response.rows = await db.getGroupMemberList(filter)

    res.response(response)
  })

  server.get('/api/person-management/groups', async (req, res) => {
    let response = {
      rows: []
    }

    response.rows = await db.getPersonGroupList()

    res.response(response)
  })

  server.get('/api/person-management/companys', async (req, res) => {
    let response = {
      rows: []
    }
    response.rows = await db.getCompanyList()
    res.response(response)
  })

  server.get('/api/person-management/divisions', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.comId) {
      filter = 'where comId = {0}'.format(req.query.comId)
    }
    response.rows = await db.getDivisionList(filter)
    res.response(response)
  })

  server.get('/api/person-management/phoneNumbers', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pmId) {
      filter = 'where pmId = {0}'.format(req.query.pmId)
    }
    response.rows = await db.getPhoneNumberList(filter)
    res.response(response)
  })

  server.get('/api/person-management/emails', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pmId) {
      filter = 'where pmId = {0}'.format(req.query.pmId)
    }
    response.rows = await db.getEmailList(filter)
    res.response(response)
  })

  server.delete('/api/person-management/groups', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pgId) {
      filter = ` set personGroup = 1 
      where personGroup = {0}`.format(req.query.pgId)
    }
    await db.updatePersonManagement(filter)

    if (req.query.pgId) {
      filter = ` where pgId = {0}`.format(req.query.pgId)
    }
    await db.deletePersonGroup(filter)

    response.rows = await db.getTotalNumByGroup()
    res.response(response)
  })

  server.delete('/api/person-management/persons/groups', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.no) {
      if (req.query.no) {
        filter = ' where pmId in ({0})'.format(req.query.no)
      }
    }
    // console.log('그룹에서 인물 삭제', filter)

    response.rows = await db.deletePersonGroupMembers(filter)
    res.response(response)
  })

  server.delete('/api/person-management/persons/merge', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.mergeId) {
      filter = ` set represent = null, merge = null, updateDate = datetime('now')`
      filter += ` where represent = '{0}' or merge = '{0}'`.format(
        req.query.mergeId
      )
    }

    response.rows = await db.updatePersonManagement(filter)
    res.response(response)
  })

  server.delete('/api/person-management/company', async (req, res) => {
    let response = {}

    let filter = ''
    if (req.query.comId) {
      filter += 'where comId = {0}'.format(req.query.comId)
    }

    await db.deleteDivision(filter)
    await db.deleteCompany(filter)

    res.response(response)
  })

  server.delete('/api/person-management/division', async (req, res) => {
    let response = {}

    let filter = ''
    if (req.query.comId && req.query.divId) {
      filter += 'where comId = {0} and divId = {1}'.format(
        req.query.comId,
        req.query.divId
      )
    }

    await db.deleteDivision(filter)
    res.response(response)
  })

  server.delete('/api/person-management/phoneNumbers', async (req, res) => {
    let response = {}

    let filter = ''
    if (req.query.pmId) {
      filter += 'where pmId = {0}'.format(req.query.pmId)
    }

    await db.deletePhoneNumbers(filter)
    res.response(response)
  })

  server.delete('/api/person-management/emails', async (req, res) => {
    let response = {}

    let filter = ''
    if (req.query.pmId) {
      filter += 'where pmId = {0}'.format(req.query.pmId)
    }

    console.log('이메일 삭제', req.query.pmId)

    await db.deleteEmails(filter)
    res.response(response)
  })

  server.post(`/api/person-management/groups`, async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pgName) {
      filter = `{0}`.format(req.query.pgName)
    }

    await db.insertPersonGroups(filter)
    response.rows = await db.getTotalNumByGroup()
    res.response(response)
  })

  // 인문그룹 업데이트
  server.post('/api/person-management/persons/groups', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pmId && req.query.pgId) {
      let pmIds = []
      let pgIds = []
      let arr = []
      // 문자열일때 배열로 변환
      if (typeof req.query.pmId === 'string') {
        pmIds.push(req.query.pmId)
      } else {
        pmIds = req.query.pmId
      }
      if (typeof req.query.pgId === 'string') {
        pgIds.push(req.query.pgId)
      } else {
        pgIds = req.query.pgId
      }
      // 배열만큼 쿼리로 변환
      for (let i = 0; i < pmIds.length; i++) {
        const pmId = pmIds[i]
        for (let j = 0; j < pgIds.length; j++) {
          const pgId = pgIds[j]
          arr.push(` ({0}, {1})`.format(pmId, pgId))
        }
      }
      filter += arr.join(',')
    }
    // console.log('인물그룹 새로 입력', filter)
    await db.updatePersonManagementUpdateDate(req.query.pmId)
    response.rows = await db.insertPm_Pg(filter)
    res.response(response)
  })

  server.post('/api/person-management/company', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.comId && req.query.comName) {
      filter += '{0}, "{1}"'.format(req.query.comId, req.query.comName)
    }

    response.rows = await db.insertCompany(filter)
    res.response(response)
  })

  server.post('/api/person-management/division', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.comId && req.query.divId && req.query.divName) {
      filter += '{0}, {1}, "{2}"'.format(
        req.query.comId,
        req.query.divId,
        req.query.divName
      )
    }

    response.rows = await db.insertDivision(filter)
    res.response(response)
  })

  server.post('/api/person-management/person', async (req, res) => {
    let response = {
      rows: [],
      currentNo: null
    }

    let filter1 =
      'name, photo, personType, phoneNumber, nickname, email, company, division, joinDate, updateDate, registeredUser, evidenceNumber, memo, keyword, merge, represent'

    let filter2 = ''
    filter2 += '"{0}", '.format(req.query.name)
    filter2 += '"{0}", '.format(req.query.photo)
    filter2 += '{0}, '.format(req.query.personType)
    filter2 += '"{0}", '.format(req.query.phoneNumber)
    filter2 += '"{0}", '.format(req.query.nickname)
    filter2 += '"{0}", '.format(req.query.email)
    filter2 += '{0}, '.format(req.query.company)
    filter2 += '{0}, '.format(req.query.division)
    filter2 += "datetime('now','localtime'), " // joinDate
    filter2 += "datetime('now','localtime'), " // updateDate
    filter2 += '"{0}", '.format(req.query.registeredUser)
    filter2 += '"{0}", '.format(req.query.evidenceNumber)
    filter2 += '"{0}", '.format(req.query.memo)
    filter2 += '"{0}", '.format(req.query.keyword)
    filter2 += '"{0}", '.format(req.query.merge)
    filter2 += '"{0}"'.format(req.query.represent)

    response.rows = await db.insertPerson(filter1, filter2)
    const rowNo = await db.getPersonManagementNextNoId()
    response.currentNo = rowNo[0].no

    console.log('라스트', response.currentNo)

    res.response(response)
  })

  server.post('/api/person-management/phoneNumbers', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pmId && req.query.pnId && req.query.phoneNumber) {
      let pnIds = []
      let phoneNumbers = []
      let arr = []
      // 문자열일때 배열로 변환
      if (typeof req.query.pnId === 'string') {
        pnIds.push(req.query.pnId)
      } else {
        pnIds = req.query.pnId
      }
      if (typeof req.query.phoneNumber === 'string') {
        phoneNumbers.push(req.query.phoneNumber)
      } else {
        phoneNumbers = req.query.phoneNumber
      }
      // 배열만큼 쿼리로 변환
      for (let i = 0; i < phoneNumbers.length; i++) {
        const pgId = pnIds[i]
        const phoneNumber = phoneNumbers[i]
        arr.push(` ({0}, {1}, "{2}")`.format(req.query.pmId, pgId, phoneNumber))
      }
      filter += arr.join(',')
    }

    response.rows = await db.insertPhoneNumbers(filter)
    res.response(response)
  })

  server.post('/api/person-management/emails', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.pmId && req.query.emId && req.query.email) {
      let emIds = []
      let emails = []
      let arr = []
      // 문자열일때 배열로 변환
      console.log('emId', typeof req.query.emId)
      if (typeof req.query.emId === 'string') {
        emIds.push(req.query.emId)
      } else {
        emIds = req.query.emId
      }
      console.log('email', typeof req.query.email)
      if (typeof req.query.email === 'string') {
        emails.push(req.query.email)
      } else {
        emails = req.query.email
      }
      console.log('emails', emails)
      // 배열만큼 쿼리로 변환
      for (let i = 0; i < emails.length; i++) {
        const emId = emIds[i]
        const email = emails[i]
        arr.push(` ({0}, {1}, "{2}")`.format(req.query.pmId, emId, email))
      }
      filter += arr.join(',')
    }

    console.log('@', req.query.pmId, req.query.emId, req.query.email)

    response.rows = await db.insertEmails(filter)
    res.response(response)
  })

  server.patch(
    '/api/person-management/persons/person-types',
    async (req, res) => {
      let response = {
        rows: []
      }

      let filter = ''
      if (req.query.personType) {
        filter = ` set personType = {0}`.format(req.query.personType)
        filter += `, updateDate = datetime('now')`
      }

      if (req.query.no) {
        filter += ` where no = {0}`.format(req.query.no)
      }

      response.rows = await db.updatePersonManagement(filter)
      res.response(response)
    }
  )

  server.patch('/api/person-management/persons/represent', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.mergeId) {
      filter = ` set represent = '{0}'`.format(req.query.mergeId)
      filter += `, updateDate = datetime('now')`
    }

    if (req.query.no) {
      filter += ` where no = {0}`.format(req.query.no)
    }

    response.rows = await db.updatePersonManagement(filter)
    res.response(response)
  })

  server.patch('/api/person-management/persons/merge', async (req, res) => {
    let response = {
      rows: []
    }

    let filter = ''
    if (req.query.mergeId) {
      filter = ` set merge = '{0}'`.format(req.query.mergeId)
      filter += `, updateDate = datetime('now')`
    }

    if (req.query.no) {
      filter += ` where no in ({0})`.format(req.query.no)
    }

    response.rows = await db.updatePersonManagement(filter)
    res.response(response)
  })

  server.patch('/api/person-management/person', async (req, res) => {
    let response = {
      rows: []
    }

    let filter1 =
      'name, photo, personType, phoneNumber, nickname, email, company, division, updateDate, registeredUser, evidenceNumber, memo, keyword, merge, represent'
    let filter2 = ''
    let filter3 = ''

    filter2 += '"{0}", '.format(req.query.name)
    filter2 += '"{0}", '.format(req.query.photo)
    filter2 += '{0}, '.format(req.query.personType)
    filter2 += '"{0}", '.format(req.query.phoneNumber)
    filter2 += '"{0}", '.format(req.query.nickname)
    filter2 += '"{0}", '.format(req.query.email)
    filter2 += '{0}, '.format(req.query.company)
    filter2 += '{0}, '.format(req.query.division)
    filter2 += "datetime('now','localtime'), " // updateDate
    filter2 += '"{0}", '.format(req.query.registeredUser)
    filter2 += '"{0}", '.format(req.query.evidenceNumber)
    filter2 += '"{0}", '.format(req.query.memo)
    filter2 += '"{0}", '.format(req.query.keyword)
    filter2 += '"{0}", '.format(req.query.merge)
    filter2 += '"{0}"'.format(req.query.represent)

    filter3 += 'no = {0}'.format(req.query.no)

    response.rows = await db.updatePerson(filter1, filter2, filter3)
    res.response(response)
  })
}
