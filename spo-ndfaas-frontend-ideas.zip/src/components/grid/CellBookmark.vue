<template>
  <div
    class="d-flex justify-center valign-middle"
    style="width:100%;height:100%;cursor:pointer;"
    @click="goBookmarkCell"
  >
    <v-btn icon class="dea-btn--textindent">
      <v-icon :color="getColor" :title="getBookmarkTit">mdi-star</v-icon>
      {{ getBookmarkTit }}
    </v-btn>
  </div>
</template>

<script>
import Vue from 'vue'
import GridCommMixins from '@/mixins/callHistory/GridComm'
export default Vue.extend({
  name: 'bookmark',
  mixins: [GridCommMixins],
  computed: {
    getColor() {
      return this.setbookmark ? '#fe7c10' : '#d7d7d7'
    }
  },
  methods: {
    async goBookmarkCell() {
      //북마크해제
      if (this.setbookmark) {
        let result = await this.deleteBootmark()
        if (result === 1) {
          await this.$eventBus.$emit('refresh')
          await this.$toast(`북마크가 해제 되었습니다.`)
        } else {
          this.$toast.error(`북마크해제에 실패하였습니다. ${result}`)
        }
        //북마크설정
      } else {
        let result = await this.setBootmark()
        if (result === 1) {
          await this.$eventBus.$emit('refresh')
          await this.$toast(
            `북마크 되었습니다.\n자세한 내역은 통화내역 북마크에서 확인할 수 있습니다`
          )
        } else {
          this.$toast.error(`북마크등록에 실패하였습니다. ${result}`)
        }
      }
    }
  },
  created() {
    this.gridSelected = [this.params.data.no]
    this.setbookmark = this.params.data.bookmark ? true : false
  }
})
</script>
