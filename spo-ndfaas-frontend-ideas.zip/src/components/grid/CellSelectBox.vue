<template>
  <v-layout fill-height align-center>
    <dea-select
      :items="params.items"
      v-model="selected"
      @change="onCellSelectChange"
    ></dea-select>
  </v-layout>
</template>

<script>
/*
<dea-grid ref="grid" @cellSelectChange="onCellSelectChange" />
import CellSelectBox from '@/components/grid/CellSelectBox'
{
  headerName: '셀렉트박스test',
  field: 'selectbox',
  cellRendererFramework: CellSelectBox,
  cellRendererParams: {
    items: [
      { text: 'Ireland', value: 'IE' },
      { text: 'UK', value: 'UK' },
      { text: 'France', value: 'FR' }
    ]
  },
}
*/

import Vue from 'vue'
export default Vue.extend({
  name: 'cellSelectBox',
  data() {
    return {
      selected: ''
    }
  },
  created() {
    this.selected = this.params.value
  },
  methods: {
    onCellSelectChange(value) {
      this.params.context.componentParent.onCellSelectChange(this.params, value)
    }
  }
})
</script>
