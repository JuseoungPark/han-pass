<template>
  <div>
    <template v-if="params.type === 'txtbtn'">
      <span>{{ params.value }}</span>
      <dea-button
        classes="mt-1"
        absolute
        right
        :outlined="this.params.outlined"
        :text="this.params.text"
        :color="this.params.color"
        @click="onCellButtonClicked"
        v-if="isBtn"
      >
        {{ label }}
      </dea-button>
      <template v-if="params.textStr.length > 0">
        <p
          v-for="(text, index) in params.textStr"
          :key="index"
          :style="`line-height:1;margin:0;color:${text.color};`"
        >
          {{ text.value }}
        </p>
      </template>
    </template>
    <template v-else>
      <template v-if="btnList.length > 0">
        <dea-button
          v-for="(btn, index) in btnList"
          :outlined="btn.outlined"
          :text="btn.text"
          :color="btn.color"
          @click="btn.click"
          :key="index"
        >
          {{ btn.label }}
        </dea-button>
      </template>
      <template v-else>
        <dea-button
          :outlined="this.params.outlined"
          :text="this.params.text"
          :color="this.params.color"
          @click="onCellButtonClicked"
          v-if="label"
        >
          {{ label }}
        </dea-button>
      </template>
    </template>
  </div>
</template>

<script>
import Vue from 'vue'

export default Vue.extend({
  name: 'CellButton',
  data() {
    return {
      isBtn: true,
      btnList: []
    }
  },
  computed: {
    label() {
      return this.params.label
        ? this.params.label
        : this.params.value === 0
        ? '0'
        : this.params.valueFormatted
        ? this.params.valueFormatted
        : this.params.value
        ? this.params.value
        : ''
    }
  },
  methods: {
    onCellButtonClicked() {
      if (typeof this.params.click === 'undefined') {
        this.params.context.componentParent.onCellButtonClicked(this.params)
      } else {
        this.params.click(this.params)
      }
    }
  },
  beforeMount() {},
  mounted() {
    if (typeof this.params.showBtn === 'undefined') {
      this.isBtn = true
    } else {
      this.isBtn = this.params.showBtn
    }
    if (typeof this.params.btnList === 'undefined') {
      this.btnList = []
    } else {
      this.btnList = this.params.btnList
    }
  }
})
</script>
<style>
.ag-theme-alpine .ag-cell .v-btn + .v-btn {
  margin-left: 8px;
}
</style>
