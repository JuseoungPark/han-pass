<template>
  <div
    class="d-flex justify-center"
    style="width:100%;height:100%"
    :style="getStyleCursor"
    @click="doClick"
  >
    <v-icon
      class="mdi"
      :color="params.color"
      :class="params.icon"
      :title="params.text"
      style="font-size:24px;"
      v-if="params.icon"
    ></v-icon>
    <span v-else>{{ params.text }}</span>
  </div>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'CellIcon',
  data() {
    return {
      iconShow: true
    }
  },
  computed: {
    getStyleCursor() {
      if (this.params.click) return 'cursor:pointer;'
      return ''
    }
  },
  methods: {
    doClick() {
      if (this.params.click) {
        this.params.click(this.params)
      }
    }
  },
  created() {
    // console.log(this.params.click)
  }
})
</script>
