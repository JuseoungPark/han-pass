<template>
  <div
    class="d-flex justify-center valign-middle"
    style="width:100%;height:100%;cursor:pointer;"
    @click="onClick"
  >
    <v-btn icon class="dea-btn--textindent">
      <v-icon :title="title">{{ icon }}</v-icon>
      {{ title }}
    </v-btn>
  </div>
</template>

<script>
import Vue from 'vue'

export default Vue.extend({
  name: 'CellCheckbox',
  data() {
    return {}
  },
  computed: {
    title() {
      return this.params.node.isSelected() ? '선택 해제' : '선택'
    },
    icon() {
      return this.params.node.isSelected()
        ? 'mdi-checkbox-marked-outline'
        : 'mdi-checkbox-blank-outline'
    }
  },
  methods: {
    onClick() {
      if (this.params.node.isSelected()) this.params.node.setSelected(false)
      else this.params.node.setSelected(true)
    }
  }
})
</script>
