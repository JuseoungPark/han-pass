<template>
  <v-layout
    fill-height
    align-center
    style="padding-left:40px;padding-right:20px;"
  >
    <dea-text-field
      label="메모입력"
      v-model="memo"
      @change="onRowsTextChange"
    ></dea-text-field>
  </v-layout>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'CellFullWidthText',
  data() {
    return {
      memo: ''
    }
  },
  methods: {
    onRowsTextChange(value) {
      this.params.context.componentParent.onRowsTextChange(this.params, value)
    }
  },
  created() {
    this.memo = `${this.params.data.memo}`
  }
})
</script>
