<template>
  <div
    class="d-flex justify-center valign-middle"
    style="width:100%;height:100%;cursor:pointer;"
    @click="onClick"
  >
    <v-btn icon class="dea-btn--textindent">
      <v-icon :title="title">{{ icon }}</v-icon>
      {{ title }}
    </v-btn>
  </div>
</template>

<script>
import Vue from 'vue'

export default Vue.extend({
  name: 'CellCheckbox',
  data() {
    return {
      state: 0,
      titles: ['모두 선택', '모두 선택', '모두 선택 해제'],
      icons: [
        'mdi-checkbox-blank-outline',
        'mdi-minus-box-outline',
        'mdi-checkbox-marked-outline'
      ]
    }
  },
  computed: {
    title() {
      return this.titles[this.state]
    },
    icon() {
      return this.icons[this.state]
    }
  },
  methods: {
    onClick() {
      if (this.isSelectedAll()) this.params.api.deselectAll()
      else this.params.api.selectAll()
    },
    isSelectedAll() {
      return (
        this.params.api.getSelectedRows().length ===
        this.params.api.getDisplayedRowCount()
      )
    }
  },
  created() {
    this.params.api.addEventListener('selectionChanged', () => {
      if (
        this.params.api.getSelectedRows().length ===
        this.params.api.getDisplayedRowCount()
      )
        this.state = 2
      else if (this.params.api.getSelectedRows().length === 0) this.state = 0
      else this.state = 1
    })
  },
  destroyed() {
    this.params.api.removeEventListener('selectionChanged')
  }
})
</script>
