<template>
  <div
    class="d-flex justify-center valign-middle"
    style="width:100%;height:100%;cursor:pointer;"
    @click="goExceptCell"
  >
    <v-btn icon class="dea-btn--textindent">
      <v-icon
        class="mdi"
        :class="getIcon"
        :title="`${getExceptTit}하기`"
      ></v-icon>
      {{ getExceptTit }}하기
    </v-btn>
  </div>
  <!-- 제외하기-->
</template>

<script>
import Vue from 'vue'
import GridCommMixins from '@/mixins/callHistory/GridComm'
export default Vue.extend({
  name: 'except',
  mixins: [GridCommMixins],
  computed: {
    getIcon() {
      return this.params.except === 'Y'
        ? 'mdi-minus-circle-outline'
        : 'mdi-plus-circle-outline'
    }
  },
  methods: {
    async goExceptCell() {
      if (this.params.except === 'Y' && this.params.data.bkmkId > 0) {
        this.$toast.error(`북마크가 되어 있는 경우는 제외가 불가능합니다.`)
      } else {
        let result = await this.setExcept()
        if (result) {
          await this.$eventBus.$emit('refresh')
          if (this.params.except === 'Y') {
            await this.$toast(
              `제외 되었습니다.\n제외 내역 메뉴에서 다시 검토할 수 있습니다.`
            )
          } else {
            await this.$toast(`제외에서 복원되었습니다.`)
          }
        } else {
          this.$toast.error(
            `${this.getExceptTit}에 실패하였습니다. ${result.msg}`
          )
        }
      }
    }
  },
  created() {
    this.except = this.params.except
    if (this.except === 'Y') this.gridSelected.push(this.params.data.linkId)
    else this.gridSelected.push(this.params.data.linkExclId)
  }
})
</script>
