<template>
  <div class="dea-chart-container">
    <highcharts
      :options="detailChartOptions"
      v-bind:style="detailChartStyles"
    ></highcharts>
    <highcharts
      :options="masterChartOptions"
      v-bind:style="masterChartStyles"
      :callback="masterChartCallback"
    ></highcharts>
  </div>
</template>

<script>
import Vue from 'vue'
import HighchartsVue from 'highcharts-vue'
Vue.use(HighchartsVue)

import Highcharts from 'highcharts'
import usdeur from '@/api/usdeur'

var data = usdeur

export default {
  name: 'DeaHighchartsMasterDetail',
  computed: {
    masterChartOptions: function() {
      return this.masterChartOption
    },
    detailChartOptions: function() {
      return this.detailChartOption
    },
    masterChartStyles: function() {
      return this.masterChartStyle
    },
    detailChartStyles: function() {
      return this.detailChartStyle
    },
    detailStarts: function() {
      return this.detailStart
    }
  },
  data() {
    return {
      // Master chart options
      masterChartOption: {
        chart: {
          reflow: true,
          borderWidth: 0,
          backgroundColor: null,
          marginLeft: 50,
          marginRight: 20,
          zoomType: 'x',
          events: {
            // listen to the selection event on the master chart to update the
            // extremes of the detail chart
            selection: function(event) {
              var extremesObject = event.xAxis[0],
                series = this.$children[1].chart.series[0],
                detailChart = this.$children[0].chart,
                min = extremesObject.min,
                max = extremesObject.max,
                detailData = [],
                xAxis = event.xAxis[0].axis

              // reverse engineer the last part of the data
              Highcharts.each(series.data, function(point) {
                if (point.x > min && point.x < max) {
                  detailData.push([point.x, point.y])
                }
              })

              // move the plot bands to reflect the new detail span
              xAxis.removePlotBand('mask-before')
              xAxis.addPlotBand({
                id: 'mask-before',
                from: data[0][0],
                to: min,
                color: 'rgba(0, 0, 0, 0.2)'
              })

              xAxis.removePlotBand('mask-after')
              xAxis.addPlotBand({
                id: 'mask-after',
                from: max,
                to: data[data.length - 1][0],
                color: 'rgba(0, 0, 0, 0.2)'
              })

              detailChart.series[0].setData(detailData)

              return false
            }.bind(this)
          }
        },
        title: {
          text: null
        },
        xAxis: {
          type: 'datetime',
          showLastTickLabel: true,
          maxZoom: 14 * 24 * 3600000, // fourteen days
          plotBands: [
            {
              id: 'mask-before',
              from: data[0][0],
              to: data[data.length - 1][0],
              color: 'rgba(0, 0, 0, 0.2)'
            }
          ],
          title: {
            text: null
          }
        },
        yAxis: {
          gridLineWidth: 0,
          labels: {
            enabled: false
          },
          title: {
            text: null
          },
          min: 0.6,
          showFirstLabel: false
        },
        tooltip: {
          formatter: function() {
            return false
          }
        },
        legend: {
          enabled: false
        },
        credits: {
          enabled: false
        },
        plotOptions: {
          series: {
            fillColor: {
              linearGradient: [0, 0, 0, 70],
              stops: [
                [0, Highcharts.getOptions().colors[0]],
                [1, 'rgba(255,255,255,0)']
              ]
            },
            lineWidth: 1,
            marker: {
              enabled: false
            },
            shadow: false,
            states: {
              hover: {
                lineWidth: 1
              }
            },
            enableMouseTracking: false
          }
        },

        series: [
          {
            type: 'area',
            name: 'USD to EUR',
            pointInterval: 24 * 3600 * 1000,
            pointStart: data[0][0],
            data: data
          }
        ],

        exporting: {
          enabled: false
        }
      },
      // Master chart style
      masterChartStyle: {
        position: 'absolute',
        top: 320 + 'px',
        height: 100 + 'px',
        width: '99%'
      },
      // Detail start
      detailStart: data[0][0],
      // Master chart callback
      masterChartCallback(masterChart) {
        var detailData = []

        // $.each(masterChart.series[0].data, function() {
        //   if (this.x >= this.detailStart) {
        //     detailData.push(this.y)
        //   }
        // })

        masterChart.series[0].data.forEach((value) => {
          if (value.x >= value.detailStart) {
            detailData.push(value.y)
          }
        })

        // Array.forEach(masterChart.series[0].data, function(point) {
        //   if (point.x >= point.detailStart) {
        //     detailData.push(point.y)
        //   }
        // })
      },
      // Detail chart options
      detailChartOption: {
        chart: {
          marginBottom: 120,
          reflow: true,
          marginLeft: 50,
          marginRight: 20,
          style: {
            position: 'absolute'
          }
        },
        credits: {
          enabled: false
        },
        title: {
          text: 'Historical USD to EUR Exchange Rate'
        },
        subtitle: {
          text: 'Select an area by dragging across the lower chart'
        },
        xAxis: {
          type: 'datetime'
        },
        yAxis: {
          title: {
            text: null
          },
          maxZoom: 0.1
        },
        tooltip: {
          formatter: function() {
            var point = this.points[0]
            return (
              '<b>' +
              point.series.name +
              '</b><br/>' +
              Highcharts.dateFormat('%A %B %e %Y', this.x) +
              ':<br/>' +
              '1 USD = ' +
              Highcharts.numberFormat(point.y, 2) +
              ' EUR'
            )
          },
          shared: true
        },
        legend: {
          enabled: false
        },
        plotOptions: {
          series: {
            marker: {
              enabled: false,
              states: {
                hover: {
                  enabled: true,
                  radius: 3
                }
              }
            }
          }
        },
        series: [
          {
            name: 'USD to EUR',
            pointStart: this.detailStarts,
            pointInterval: 24 * 3600 * 1000,
            data: data
          }
        ],

        exporting: {
          enabled: false
        }
      },
      // Detail chart style
      detailChartStyle: {
        //position: 'absolute',
        //top: 300 + 'px',
        height: 400 + 'px',
        width: '100%'
      }
    }
  },
  mounted() {
    this.masterChartStyle = {
      position: 'absolute',
      top: 320 + 'px',
      height: 100 + 'px',
      width: '99%'
    }

    this.detailChartStyle = {
      //position: 'absolute',
      //top: 300 + 'px',
      height: 400 + 'px',
      width: '100%'
    }
  }
}
</script>

<style scoped>
.dea-chart-container {
  width: 100%;
  height: 100%;
}
</style>
