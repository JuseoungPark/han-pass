<template>
  <div class="dea-chart-container">
    <highcharts :options="chartOptions" />
  </div>
</template>

<script>
import Vue from 'vue'
import HighchartsVue from 'highcharts-vue'
Vue.use(HighchartsVue)

import Highcharts from 'highcharts'
import Sankey from 'highcharts/modules/sankey'
import DependencyWheel from 'highcharts/modules/dependency-wheel'
import NetworkGraph from 'highcharts/modules/networkgraph'
Sankey(Highcharts)
DependencyWheel(Highcharts)
NetworkGraph(Highcharts)

export default {
  name: 'DeaHighcharts',
  props: {
    jsonFile: {
      type: String,
      required: true,
      default: ''
    }
  },
  computed: {
    chartOptions: function() {
      return this.chartOption
    }
  },
  data() {
    return {
      chartOption: {}
    }
  },
  beforeCreate: function() {},
  mounted: function() {
    var self = this
    this.$api.private.get('/api/' + this.jsonFile).then((response) => {
      this.chartOption = response.data
      this.chartOption.series.events.click = function() {
        self.$emit('chartClick')
      }
    })
  }
}
</script>

<style scoped>
.dea-chart-container {
  width: 100%;
  height: 100%;
}
</style>
