<template>
  <div id="dea-chart-container">
    <div id="3d-graph"></div>
  </div>
</template>

<script>
import ForceGraph3D from '3d-force-graph'
import SpriteText from 'three-spritetext'
import * as THREE from 'three'

export default {
  name: 'Dea3dForceGraph',
  props: {
    jsonFile: {
      type: String,
      required: true,
      default: ''
    },
    findNodeName: {
      type: String,
      default: ''
    },
    parentWidth: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      gData: {},
      Graph: null,
      highlightNodes: null,
      highlightLinks: null,
      hoverNode: null
    }
  },
  created() {},
  mounted() {
    this.initData()
  },
  watch: {
    findNodeName() {
      this.findNode()
    }
  },
  methods: {
    initData() {
      this.highlightNodes = new Set()
      this.highlightLinks = new Set()

      this.$api.private.get(`/api/${this.jsonFile}`).then((response) => {
        let data = response.data
        let nodesIds = data.nodes.map((o) => o.id)

        data.links.forEach((link) => {
          const a = data.nodes[nodesIds.indexOf(link.source)]
          const b = data.nodes[nodesIds.indexOf(link.target)]

          !a.neighbors && (a.neighbors = [])
          !b.neighbors && (b.neighbors = [])

          a.neighbors.push(b)
          b.neighbors.push(a)

          !a.links && (a.links = [])
          !b.links && (b.links = [])
          a.links.push(link)
          b.links.push(link)
        })

        this.gData = data
        this.initRender()
      })
    },
    initRender() {
      console.log('initRender()')
      this.Graph = ForceGraph3D({ controlType: 'orbit' })(
        document.getElementById('3d-graph')
      ).width(this.parentWidth)

      this.Graph.graphData(this.gData)
        .linkDirectionalArrowLength(3)
        .linkDirectionalArrowRelPos(1)
        .linkCurvature(0.25)
        .linkColor('rgba(255,160,0,0.5)')
        .linkWidth((link) => (this.highlightLinks.has(link) ? 2 : 0))
        .linkDirectionalParticles((link) =>
          this.highlightLinks.has(link) ? 6 : 3
        )
        .linkDirectionalParticleWidth((link) =>
          this.highlightLinks.has(link) ? 2 : 1
        )
        .linkDirectionalParticleSpeed((d) => d.value * 0.001)
        .enableNodeDrag(false)
        .nodeLabel('id')
        .nodeAutoColorBy('group')
        .nodeThreeObject((node) => {
          let obj
          let isOver = !this.highlightNodes.has(node)
          let sphereGeometryValue = isOver ? 5 : 10
          let opacityValue = isOver ? 0 : 0.8
          let textHeightValue = isOver ? 1 : 3

          obj = new THREE.Mesh(
            new THREE.SphereGeometry(sphereGeometryValue),
            new THREE.MeshBasicMaterial({
              depthWrite: false,
              transparent: true,
              opacity: opacityValue
            })
          )
          const sprite = new SpriteText(`${node.id}\n${node.name}`)
          sprite.color = node.color
          sprite.textHeight = textHeightValue
          sprite.strokeWidth = 1
          sprite.strokeColor = 'darkesilver'
          sprite.padding = 3
          obj.add(sprite)

          return obj
        })
        .onNodeClick((node) => {
          this.cameraMovement(node)
        })
        .onNodeHover((node) => {
          if (
            (!node && !this.highlightNodes.size) ||
            (node && this.hoverNode === node)
          )
            return

          this.highlightNodes.clear()
          this.highlightLinks.clear()

          if (node) {
            this.highlightNodes.add(node)
            node.neighbors.forEach((neighbor) =>
              this.highlightNodes.add(neighbor)
            )
            node.links.forEach((link) => this.highlightLinks.add(link))
          }
          this.hoverNode = node || null
          this.updateHighlight()
        })
        .onLinkHover((link) => {
          this.highlightNodes.clear()
          this.highlightLinks.clear()

          if (link) {
            this.highlightLinks.add(link)
            this.highlightNodes.add(link.source)
            this.highlightNodes.add(link.target)
          }

          this.updateHighlight()
        })
    },
    updateHighlight() {
      this.Graph
        // .nodeColor(this.Graph.nodeColor())
        .nodeThreeObject(this.Graph.nodeThreeObject())
        .linkWidth(this.Graph.linkWidth())
        .linkDirectionalParticles(this.Graph.linkDirectionalParticles())
    },
    findNode() {
      const id = this.findNodeName
      this.Graph.graphData().nodes.forEach((node) => {
        if (node.id === id) {
          this.cameraMovement(node)
          return
        }
      })
    },
    cameraMovement(node) {
      const distance = 60
      const distRatio = 1 + distance / Math.hypot(node.x, node.y, node.z)

      this.Graph.cameraPosition(
        {
          x: node.x * distRatio,
          y: node.y * distRatio,
          z: node.z * distRatio
        },
        node,
        3000
      )
    }
  }
}
</script>
