<template>
  <div>
    <div id="dea-timebase-graph-container" ref="timeGraphContainer"></div>
    <v-layout class="datetime-slider-wrapper">
      <v-row no-gutters>
        <v-col class="d-flex align-center" style="color:white" cols="1">
          {{ baseDateText }}
        </v-col>
        <v-col class="d-flex align-center">
          <v-slider
            v-model="slider"
            :thumb-size="72"
            @mouseup="onMouseUpSlider"
          >
            <template v-slot:thumb-label="{ value }">
              {{ sliderToDatetime(value) }}
            </template>
          </v-slider>
        </v-col>
        <v-col class="d-flex align-center" style="color:white" cols="1">
          {{ maxDateText }}
        </v-col>
      </v-row>
    </v-layout>
    <v-layout class="datetime-current">
      <v-row no-gutters>
        <v-col class="d-flex align-center" style="color:white">
          현재 위치 : {{ currentDatetime }}
        </v-col>
      </v-row>
    </v-layout>
    <v-layout v-show="hoverInfoObject != null">
      <a id="object-hover-info" class="visible">
        <div class="object-hover-title">
          {{ popupTitle }}
        </div>
        <div class="object-hover-culture">
          <v-row no-gutters>
            <v-col class="d-flex align-center" cols="2">발신자</v-col>
            <v-col class="d-flex align-center">{{ popupOutgoingUser }}</v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center" cols="2">착신자</v-col>
            <v-col class="d-flex align-center">{{ popupIncommingUser }}</v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center" cols="2">통화량</v-col>
            <v-col class="d-flex align-center">{{ popupCallLength }}</v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center" cols="2">기지국</v-col>
            <v-col class="d-flex align-center">{{ popupBasestation }}</v-col>
          </v-row>
          <v-row no-gutters>
            <v-col class="d-flex align-center">내역보기</v-col>
          </v-row>
        </div>
      </a>
    </v-layout>
    <v-layout v-show="hoverInfoContextObject != null">
      <v-list id="object-hover-info-context">
        <v-list-item-group v-model="contextSelection">
          <v-list-item @click="showPersonInformation">
            <v-list-item-content>
              <v-list-item-title>인물 정보 보기</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>1인 중심 분석</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>이벤트 내역</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-layout>
    <!-- 인물정보 상세 : Layer Popup -->
    <dialog-individual
      :visible.sync="individualDetail"
      :params.sync="individualDetailParams"
    />
  </div>
</template>

<script>
import moment from 'moment'
import { mapGetters } from 'vuex'
import * as THREE from 'three'
import Detector from '@/utils/Detector'
import xor4096 from '@/utils/xor4096.min'
import { NumberUtils } from '@/utils/NumberUtils'
import DialogIndividual from '@/views/personManagement/Dialog/DialogIndividual'

//var xorgen = new xor4096('heabllo.')
//var loaderXorgen = new xor4096('alflog.')
var objectXorgen = new xor4096('hello.')

// const unitDateTime = 432000 // 5 days, 540
// const unitDateTime = 259200 // 3 days, 324
const unitDateTime = 172800 // 2 days, 432
const unitDivider = 43200 // 12 hours

export default {
  name: 'ITime',
  components: {
    DialogIndividual
  },
  data() {
    return {
      api: this.$api.private,
      prevDatetime: '',
      currentDatetime: '',
      slider: 0,
      loadingText: null,
      units: {
        baseDate: undefined,
        maxDate: undefined,
        interval: 2,
        unit: 'day',
        currentZLocation: 0,
        currentDatetime: undefined,
        currentDataIndex: 0,
        data: [
          {
            startDate: undefined,
            minDateCreated: 0,
            maxDateCreated: unitDateTime,
            datetimes: [],
            objectArray: [],
            objectsByPersonType: {},
            objectIndex: {},
            objects: null,
            dividers: null,
            yearTicks: null,
            completed: false
          }
        ]
      },
      camera: null,
      scene: null,
      renderer: null,
      webgl: null,
      users: [],
      userLane: {},
      colors: [0xffba0a, 0xf14f11, 0x8dc73c, 0x0071bc, 0x9e005d],
      datetimes: [],
      blobTextures: [],
      landscapeShaderMaterial: null,
      canvasShaderMaterial: null,
      lineShaderMaterial: null,
      cameraMotionType: '3DToolBar',
      hoverInfoX: 0,
      hoverInfoY: 0,
      loadingPercentage: 0,
      lastFrameTime: 0.0,
      frameElapsed: 0,
      width: 0,
      height: 0,
      windowHalfX: 0,
      windowHalfY: 0,
      cameraYOffset: 0.5,
      itemGeometry: null,
      labelScene: null,
      cameraVelocity: null,
      lanes: null,
      // dividers: null,
      lines: null,
      linesPlane: null,
      timeArrow: null,
      personType: null,
      personTypeToggled: false,
      objectIndex: {},
      objects: null,
      blobIndex: {},
      introState: 4,
      introTime: 0,
      introLength: 100,
      cameraXOffset: 0,
      cameraY: 0,
      cameraZMotion: 0,
      cameraZTarget: null,
      labels: null,
      toolBar3D: null,
      hoverInfoObject: null,
      hoverInfoContextObject: null,
      overlaysEl: null,
      mouseX: -1,
      mouseY: -1,
      selectedUser: null,
      hoveredUser: null,
      active: true,
      loadingPercentageMax: 0,
      eventData: {
        mouseCurrent: { clientX: 0, clientY: 0 },
        activeTouch: null,
        ongoingTouches: {},
        touchMode: false,
        down: false,
        clickActive: true,
        lastX: 0,
        lastY: 0,
        downY: 0,
        downX: 0,
        offset: {
          left: 0,
          top: 0
        }
      },
      individualDetail: false,
      individualDetailParams: {}, // 인물정보(팝업/열람)
      contextSelection: null
    }
  },
  computed: {
    ...mapGetters(['appbar']),
    popupTitle() {
      if (!this.hoverInfoObject) return ''
      return this.hoverInfoObject.objectData.dateTime
    },
    popupOutgoingUser() {
      if (!this.hoverInfoObject) return ''
      if (this.hoverInfoObject.objectData.callDirection === 'outgoing')
        return this.hoverInfoObject.objectData.user
      return this.hoverInfoObject.objectData.toUser
    },
    popupIncommingUser() {
      if (!this.hoverInfoObject) return ''
      if (this.hoverInfoObject.objectData.callDirection === 'outgoing')
        return this.hoverInfoObject.objectData.toUser
      return this.hoverInfoObject.objectData.user
    },
    popupCallLength() {
      if (!this.hoverInfoObject) return ''
      return NumberUtils.timeWithColons(this.hoverInfoObject.objectData.length)
    },
    popupBasestation() {
      if (!this.hoverInfoObject) return ''
      return this.hoverInfoObject.objectData.station
    },
    baseDateText() {
      if (this.units.baseDate) return this.units.baseDate.format('YYYY-MM-DD')
      return ''
    },
    maxDateText() {
      if (this.units.maxDate) return this.units.maxDate.format('YYYY-MM-DD')
      return ''
    }
  },
  created() {
    var self = this
    for (var i = 0; i < 16; i++) {
      var tex = new THREE.TextureLoader().load(
        '/img/blob_' + i + '.png',
        function() {
          self.loadingPercentageMax += 2
        },
        function() {
          self.loadingPercentageMax += 2
        },
        function() {
          self.loadingPercentageMax += 2
        }
      )
      tex.premultiplyAlpha = true
      this.blobTextures.push(tex)
    }

    this.landscapeShaderMaterial = new THREE.ShaderMaterial({
      vertexShader: [
        'uniform float scale;',
        'uniform float time;',
        // 'varying float fog;',
        'varying vec3 vColor;',
        'void main() {',
        '	vColor = color;',
        '	vec4 p = modelViewMatrix * vec4(position, 1.0);',
        '	p.xyz += (0.1+0.00001*p.z*p.z)*vec3( sin(time+position.x+position.z), cos(time+position.y+position.z), sin(time+position.x+position.y+position.z) );',
        // '	fog = clamp(1.0 - pow(min(1.0, max(0.0, -(p.z+100.0) / 300.0)), 2.0), 0.0, 1.0);',
        '	gl_Position = projectionMatrix * p;',
        '	gl_PointSize = scale * 350.0 / length( p.xyz );',
        '}'
      ].join('\n'),
      fragmentShader: [
        'uniform sampler2D map;',
        // 'varying float fog;',
        'varying vec3 vColor;',
        'void main() {',
        '  gl_FragColor = vec4(vColor.xyz, 0.25 * pow(texture2D( map, vec2( gl_PointCoord.x, 1.0 - gl_PointCoord.y )).a, 2.0));',
        '}'
      ].join('\n'),
      vertexColors: true,
      blending: THREE.AdditiveBlending,
      uniforms: {
        time: { type: 'f', value: 0 },
        scale: { type: 'f', value: 1 },
        map: { type: 't', value: null }
      },
      transparent: true,
      depthWrite: false
    })

    this.canvasShaderMaterial = new THREE.ShaderMaterial({
      vertexShader: [
        'varying vec2 vUv;',
        'varying float fog;',
        'void main() {',
        '  vUv = uv;',
        '  vec4 p = modelViewMatrix * vec4(position, 1.0);',
        '  fog = pow(min(1.0, max(0.0, -(p.z+100.0) / 300.0)), 2.0);',
        '  gl_Position = projectionMatrix * p;',
        '}'
      ].join('\n'),
      fragmentShader: [
        'uniform sampler2D map;',
        'uniform vec3 color;',
        'varying vec2 vUv;',
        'varying float fog;',
        'void main() {',
        '  gl_FragColor = vec4(mix(color, vec3(0.4, 0.408, 0.365), fog), pow(texture2D(map, vUv).a, 2.0));',
        '}'
      ].join('\n'),
      uniforms: {
        map: { type: 't', value: null },
        color: { type: 'v3', value: null }
      },
      transparent: true,
      depthWrite: false
    })

    this.lineShaderMaterial = new THREE.ShaderMaterial({
      vertexShader: [
        'varying float fog;',
        'void main() {',
        '  vec4 p = modelViewMatrix * vec4(position, 1.0);',
        '  fog = pow(min(1.0, max(0.0, -(p.z+100.0) / 300.0)), 2.0);',
        '  gl_Position = projectionMatrix * p;',
        '}'
      ].join('\n'),
      fragmentShader: [
        'uniform vec3 color;',
        'varying float fog;',
        'void main() {',
        '  gl_FragColor = vec4(mix(color, vec3(0.4, 0.408, 0.365), fog), 1.0);',
        '}'
      ].join('\n'),
      uniforms: {
        color: { type: 'v3', value: null }
      },
      transparent: false,
      depthWrite: true
    })
  },
  methods: {
    sliderToDatetime(value) {
      if (!this.units.baseDate || !this.units.maxDate) return ''
      let start = this.units.baseDate.unix()
      let end = this.units.maxDate.unix()
      return moment
        .unix(this.units.baseDate.unix() + value * ((end - start) / 100))
        .format('YYYY-MM-DD')
    },
    dateTimeToSlider(datetime) {
      if (this.units.baseDate && this.units.maxDate) {
        if (this.prevDatetime !== datetime) {
          let start = this.units.baseDate.unix()
          let end = this.units.maxDate.unix()

          this.slider =
            (moment(datetime, 'YYYY-MM-DD').unix() -
              this.units.baseDate.unix()) /
            ((end - start) / 100)
          this.prevDatetime = datetime
        }
      }
    },
    setCurrentDatetime(offset) {
      this.currentDatetime = moment
        .unix(this.units.baseDate.unix() + offset * 432)
        .format('YYYY-MM-DD')
      this.dateTimeToSlider(this.currentDatetime)
    },
    now: function() {
      return window.performance.now()
    },
    mapYearToLandscapeZ: function(year) {
      return (year / 432) * -1
    },
    makeLine: function(geo, mat) {
      var smat = this.lineShaderMaterial.clone()
      smat.uniforms = {
        color: {
          type: 'v3',
          value: new THREE.Vector3(mat.color.r, mat.color.g, mat.color.b)
        }
      }
      return new THREE.Line(geo, smat)
    },
    destroyObjectArray: function() {
      this.objectArray = []
      this.objectIndex = {}
    },
    createObjectArray: function(index, objectData) {
      var self = this.units.data[index]
      self.objectArray = objectData

      self.objectArray.forEach(function(obj) {
        obj.personType = obj.personType + ''
        if (obj.personType === '') {
          obj.personType = '기타'
        }
        var personType = self.objectsByPersonType[obj.personType]
        if (!personType) {
          personType = self.objectsByPersonType[obj.personType] = []
        }
        personType.push(obj)
        obj.personTypeObjects = personType
        // obj.bullet = obj.bullet.replace(/[^a-z0-9]/gi, '-')
        obj.bullet = 'feather-cloak'
        if (!self.objectIndex[obj.bullet]) {
          self.objectIndex[obj.bullet] = obj
          // this.objects.push(obj)
          // TODO: ???
          // obj.mapParams = {
          //   center: { lat: obj.lat, lng: obj.lng },
          //   zoom: obj.zoomLevel
          // }
        } else {
          //console.log('duplicate object!', obj.bullet);
        }

        // obj.audioClips.forEach(function(audio) {
        //   audio.mainURL = $sce.trustAsResourceUrl(audio.mainURL)
        // })

        // obj.youTubeIds = []
        // if (obj.youtubeVideo && isYouTubeID(obj.youtubeVideo)) {
        //   obj.youTubeIds.push({ mainURL: obj.youtubeVideo })
        // }
      })
    },
    createDatetimeLine: function(index) {
      let data = this.units.data[index]
      let i
      var line
      data.dividers = new THREE.Object3D()

      // Line Color
      var lineMaterial = new THREE.LineBasicMaterial({
        color: 0xcccccc,
        fog: true
      })

      var timelineGeometry = new THREE.Geometry()
      timelineGeometry.vertices.push(new THREE.Vector3(-1, 0, 0))
      timelineGeometry.vertices.push(new THREE.Vector3(1, 0, 0))

      var yearTickGeometry = new THREE.Geometry()

      var lastYearZ = null

      this.lanes.add(data.dividers)

      for (i = 0; i < data.datetimes.length; i++) {
        var dateTime = data.datetimes[i].dateTime
        var z = this.mapYearToLandscapeZ(dateTime)
        data.datetimes[i].zLocation = z
        // console.log(dateTime + ': ' + z)

        var lineContainer = new THREE.Object3D()
        line = this.makeLine(timelineGeometry, lineMaterial)
        line.scale.set(30, 1, 1)
        lineContainer.position.set(0, -10, z)
        lineContainer.add(line) // TODO: need
        data.dividers.add(lineContainer) // TODO: need

        var textCanvas = document.createElement('canvas')
        textCanvas.width = 256
        textCanvas.height = 32

        var ctx = textCanvas.getContext('2d')
        ctx.font = 'bold 30px Lato, Arial'
        ctx.fillStyle = '#FFFFFF'
        ctx.fillText(data.datetimes[i].text, 2, 28)

        var tex = new THREE.Texture(textCanvas)
        tex.needsUpdate = true

        var mat = this.canvasShaderMaterial.clone()
        var color = new THREE.Color(0xffffff)
        mat.uniforms = {
          map: { type: 't', value: tex },
          color: {
            type: 'v3',
            value: new THREE.Vector3(color.r, color.g, color.b)
          }
        }

        var text = new THREE.Mesh(
          new THREE.PlaneBufferGeometry(
            textCanvas.width / 25,
            textCanvas.height / 25
          ),
          mat
        )
        text.position.set(-30 + 5, -1, 0)

        lineContainer.add(text)

        if (lastYearZ !== null) {
          for (var j = 0; j <= 10; j++) {
            var f = j / 10
            var tickZ = (1 - f) * lastYearZ + f * z
            yearTickGeometry.vertices.push(
              new THREE.Vector3(-18, -10, tickZ),
              new THREE.Vector3(-18 + (j === 5 ? -2 : -1), -10, tickZ),
              new THREE.Vector3(-18, -10, tickZ)
            )
          }
        }
        lastYearZ = z
      }

      // left tick
      data.yearTicks = this.makeLine(yearTickGeometry, lineMaterial)
      this.lanes.add(data.yearTicks) // TODO: need year tick
    },
    createLanes: function() {
      var i
      var line
      var lineGeometry = new THREE.Geometry()
      for (i = 0; i <= 1500; i += 5) {
        lineGeometry.vertices.push(new THREE.Vector3(0, 0, -i)) // TODO: common middle, right lane
      }

      // Line Color
      var lineMaterial = new THREE.LineBasicMaterial({
        color: 0xcccccc,
        fog: true
      })

      var lanes = new THREE.Object3D()
      var lines = new THREE.Object3D()
      var linesPlane = new THREE.Mesh(
        new THREE.PlaneBufferGeometry(144, 144),
        new THREE.MeshBasicMaterial({ color: 0xff00ff })
      )

      linesPlane.material.side = THREE.DoubleSide
      linesPlane.position.y = 0
      linesPlane.position.z = 10
      linesPlane.visible = false
      lines.add(linesPlane)

      lanes.linesPlane = linesPlane

      lines.position.z = 1000

      var itemLanes = this.users.length

      for (i = 0; i < itemLanes; i++) {
        line = this.makeLine(lineGeometry, lineMaterial)
        line.position.set(
          (6 / 5) * 6 * (i - (itemLanes - 1) / 2) - (6 / 5) * 3,
          -10,
          0
        )
        lines.add(line) // TODO: common middle lane
      }
      line = this.makeLine(lineGeometry, lineMaterial)
      line.position.set(
        (6 / 5) * 6 * (i - (itemLanes - 1) / 2) - (6 / 5) * 3,
        -10,
        0
      )
      lines.add(line) // TODO: common light lane

      lanes.add(lines) // TODO: need middle, right lane
      lanes.lines = lines

      return lanes
    },
    createTimeArrow: function() {
      var lineMaterial = new THREE.LineBasicMaterial({
        color: 0xcccccc,
        fog: true
      })

      var upArrowGeo = new THREE.Geometry()
      upArrowGeo.vertices.push(new THREE.Vector3(-1, 1, -1))
      upArrowGeo.vertices.push(new THREE.Vector3(0, 0, 0))
      upArrowGeo.vertices.push(new THREE.Vector3(1, -1, -1))

      var downArrowGeo = new THREE.Geometry()
      downArrowGeo.vertices.push(new THREE.Vector3(-1, 1, 1))
      downArrowGeo.vertices.push(new THREE.Vector3(0, 0, 0))
      downArrowGeo.vertices.push(new THREE.Vector3(1, -1, 1))

      var arrowLineGeo = new THREE.Geometry()
      arrowLineGeo.vertices.push(new THREE.Vector3(0, 0, 0))
      arrowLineGeo.vertices.push(new THREE.Vector3(0, 0, 1))

      var arrowLineSeparatorGeo = new THREE.Geometry()
      arrowLineSeparatorGeo.vertices.push(new THREE.Vector3(0, 0, 0))
      arrowLineSeparatorGeo.vertices.push(new THREE.Vector3(1, 0, 0))

      var upSeparator = new THREE.Line(arrowLineSeparatorGeo, lineMaterial)
      var downSeparator = new THREE.Line(arrowLineSeparatorGeo, lineMaterial)

      var upArrow = new THREE.Line(upArrowGeo, lineMaterial)
      var downArrow = new THREE.Line(downArrowGeo, lineMaterial)

      var upArrowLine = new THREE.Line(arrowLineGeo, lineMaterial)
      var downArrowLine = new THREE.Line(arrowLineGeo, lineMaterial)

      var textCanvas = document.createElement('canvas')
      textCanvas.width = 128
      textCanvas.height = 32

      var ctx = textCanvas.getContext('2d')
      ctx.font = '30px Lato, Arial'
      ctx.fillStyle = '#FFFFFF'
      var textWidth = ctx.measureText('TIME').width
      ctx.fillText('TIME', (textCanvas.width - textWidth) / 2, 28)

      var tex = new THREE.Texture(textCanvas)
      tex.needsUpdate = true

      var mat = this.canvasShaderMaterial.clone()
      var color = new THREE.Color(0xcccccc)
      mat.uniforms = {
        map: { type: 't', value: tex },
        color: {
          type: 'v3',
          value: new THREE.Vector3(color.r, color.g, color.b)
        }
      }

      var text = new THREE.Mesh(
        new THREE.PlaneBufferGeometry(
          textCanvas.width / 25,
          textCanvas.height / 25
        ),
        mat
      )
      text.position.set(64 / 25, 16 / 25, 0)
      text.rotation.x = -0.4

      upSeparator.position.y = 16 / 25 - (16 / 25) * Math.cos(text.rotation.x)
      upSeparator.position.z = (-16 / 25) * Math.sin(text.rotation.x)
      downSeparator.position.y = 16 / 25 + (16 / 25) * Math.cos(text.rotation.x)
      downSeparator.position.z = (+16 / 25) * Math.sin(text.rotation.x)

      upSeparator.scale.set(128 / 25, 1, 1)
      downSeparator.scale.set(128 / 25, 1, 1)

      upArrowLine.position.set(
        64 / 25,
        upSeparator.position.y,
        upSeparator.position.z
      )
      upArrowLine.scale.set(1, 1, 20)
      downArrowLine.position.set(
        64 / 25,
        downSeparator.position.y,
        downSeparator.position.z
      )
      downArrowLine.scale.set(1, 1, -20)

      upArrow.position.copy(upArrowLine.position)
      upArrow.position.z += upArrowLine.scale.z

      downArrow.position.copy(downArrowLine.position)
      downArrow.position.z += downArrowLine.scale.z

      var timeLane = new THREE.Object3D()

      timeLane.position.set(-35, -5, 0)
      timeLane.zOffset = -60

      timeLane.add(text)
      timeLane.add(upSeparator)
      timeLane.add(downSeparator)

      timeLane.add(upArrow)
      timeLane.add(upArrowLine)

      timeLane.add(downArrow)
      timeLane.add(downArrowLine)

      return timeLane
    },
    createObjects: function(objectArray) {
      var blobs = new THREE.Object3D()
      blobs.frustumCulled = false

      var sticks = new THREE.Object3D()
      sticks.frustumCulled = false

      // this.units.data[index].objects = {
      //   blobs: blobs,
      //   sticks: sticks
      // }

      var users = this.users
      var userLane = this.userLane
      var colors = this.colors

      var blobLayoutGrid = {}
      var fitBlob = function(v) {
        var vx = Math.floor(v.x / 2)
        var vy = Math.floor(v.y / 2)
        var vz = Math.floor(v.z / 2)
        var k = [vx, vy, vz].join(':')
        if (!blobLayoutGrid[k]) {
          for (var x = -1; x <= 1; x++) {
            for (var y = -1; y <= 1; y++) {
              for (var z = -1; z <= 1; z++) {
                k = [vx + x, vy + y, vz + z].join(':')
                blobLayoutGrid[k] = true
              }
            }
          }

          return true
        }
        return false
      }
      var blobShift = function(v) {
        var i = 0
        while (!fitBlob(v)) {
          if (i === 0) {
            v.x += 2
          } else if (i === 1) {
            v.x += -4
          } else if (i === 2) {
            v.x += 2
            v.y += 2
          } else if (i === 3) {
            v.x += 0
            v.y += -4
          } else if (i === 4) {
            v.x += 2
            v.y += 0
          } else if (i === 5) {
            v.x += -4
            v.y += 0
          } else if (i === 6) {
            v.x += 0
            v.y += 4
          } else if (i === 7) {
            v.x += 4
            v.y += 0
          } else if (i === 8) {
            v.z += 4
            break
          }
          i++
        }
      }

      var clamp = function(x) {
        return x > 1 ? 1 : x < 0 ? 0 : x
      }

      var shaderMaterial = this.canvasShaderMaterial

      objectArray = objectArray.filter(function(obj) {
        return userLane[obj.user] !== undefined
      })

      for (var i = 0; i < objectArray.length; i++) {
        var obj = objectArray[i]
        var lane = userLane[obj.user]

        var color = new THREE.Color(colors[lane] || 0x0)
        obj.backgroundColor = color.getStyle()

        color.r = clamp(color.r * (1 + (Math.random() - 0.5) * 0.2))
        color.g = clamp(color.g * (1 + (Math.random() - 0.5) * 0.2))
        color.b = clamp(color.b * (1 + (Math.random() - 0.5) * 0.2))

        var mat = shaderMaterial.clone()
        mat.color = color
        mat.colorChangeSpeed = 0.25
        mat.colorChangeDelay = Math.ceil(Math.random() * 30)
        mat.uniforms = {
          map: {
            type: 't',
            value: this.blobTextures[i % this.blobTextures.length]
          },
          color: {
            type: 'v3',
            value: new THREE.Vector3(color.r, color.g, color.b)
          }
        }
        var blob = new THREE.Mesh(this.itemGeometry, mat)

        blob.rotation.z = Math.random() * Math.PI * 2

        blob.laneIndex = lane

        blob.objectData = obj
        this.blobIndex[obj.bullet] = blob

        blob.connections = []
        blob.frustumCulled = false
        blob.sticksContainer = new THREE.Object3D()
        blob.sticksContainer.visible = false
        blob.sticksContainer.frustumCulled = false
        blob.sticksContainer.tick = this.scene.tick
        blob.frustumCulled = false
        // TODO: set position
        blob.position.set(
          6 * (6 / 5) * (lane - (users.length - 1) / 2) +
            4 * (objectXorgen() - 0.5),
          -10 + objectXorgen() * 5,
          this.mapYearToLandscapeZ(obj.dateCreated, true)
        )

        blobShift(blob.position)
        blob.originalPosition = blob.position.clone()

        blob.scale.multiplyScalar(1.5)
        blob.relativePos = new THREE.Vector3()
        blob.targetPos = new THREE.Vector3()
        blob.velocity = new THREE.Vector3()
        blob.floatVec = new THREE.Vector3()
        blob.posDelta = new THREE.Vector3()
        var self = this
        blob.tick = function() {
          // var blob = this
          if (
            self.selectedUser &&
            this.objectData.user !== self.selectedUser
            // ($scope.category &&
            //   this.objectData.categoryName !== $scope.category)
          ) {
            if (this.originalColor === undefined) {
              this.originalColor = this.material.color.getHex()
            }
            if (!this.disabled) {
              this.material.colorChangeDelay = Math.max(
                0,
                -Math.floor(
                  (this.position.z - self.camera.position.z) / 10 +
                    3 * Math.random()
                )
              )
              this.material.color.setHex(0x7b7e6d)
              this.disabled = true
            }
          } else if (this.originalColor !== undefined) {
            if (this.disabled) {
              this.material.colorChangeDelay = Math.max(
                0,
                -Math.floor(
                  (this.position.z - self.camera.position.z) / 10 +
                    3 * Math.random()
                )
              )
              this.material.color.setHex(this.originalColor)
              this.disabled = false
            }
          }

          this.relativePos.x = 0
          this.relativePos.y = this.originalPosition.y - this.position.y
          this.relativePos.z = 0

          if (this.material.colorChangeDelay === 0) {
            var s
            if (this.selected) {
              this.velocity.multiplyScalar(0)
              s = this.scale.x + (3 * (1.25 * 0.75) - this.scale.x) * 0.1
            } else if (this.connectionSelected) {
              s = this.scale.x + (3 * (1.0 * 0.75) - this.scale.x) * 0.1
            } else if (this.disabled) {
              s = this.scale.x + (3 * (0.5 * 0.5) - this.scale.x) * 0.1
            } else if (this.hovered) {
              s = this.scale.x + (3 * (1.15 * 0.75) - this.scale.x) * 0.1
            } else {
              s = this.scale.x + (3 * (0.75 * 0.75) - this.scale.x) * 0.1
            }
            this.scale.set(s, s, s)
          }

          this.velocity.z = 0

          this.position.add(this.velocity)
          this.velocity.multiplyScalar(0.95)

          if (this.selected) {
            if (!this.sticksContainer.parent) {
              self.units.data[0].objects.sticks.add(this.sticksContainer)
              this.sticksContainer.visible = true
            }
          } else if (this.sticksContainer.parent) {
            this.sticksContainer.parent.remove(this.sticksContainer)
            this.sticksContainer.visible = false
          }

          if (this.material.colorChangeDelay === 0) {
            var c0 = this.material.uniforms.color.value
            var c1 = this.material.color
            this.material.uniforms.color.value.set(
              c0.x + (c1.r - c0.x) * this.material.colorChangeSpeed,
              c0.y + (c1.g - c0.y) * this.material.colorChangeSpeed,
              c0.z + (c1.b - c0.z) * this.material.colorChangeSpeed
            )
          } else {
            this.material.colorChangeDelay--
          }
        }

        blob.sticks = []

        // addBlobConnection
        blob.addConnection = function(connection) {
          var i
          if (
            connection.objectData &&
            this.objectData.bullet === connection.objectData.bullet
          ) {
            // console.log("You're doing it wrong");
          }
          var stick = new THREE.Mesh(
            new THREE.BoxGeometry(1, 1, 1),
            new THREE.MeshBasicMaterial({ vertexColors: THREE.VertexColors })
          )
          stick.frustumCulled = false
          var stickContainer = new THREE.Object3D()
          stickContainer.tick = function() {
            this.position.set(
              (this.start.position.x + this.end.position.x) * 0.5,
              (this.start.position.y + this.end.position.y) * 0.5,
              (this.start.position.z + this.end.position.z) * 0.5
            )
            this.lookAt(this.start.position)
            var distance = this.start.position.distanceTo(this.end.position)
            if (distance === 0) {
              // console.log('something is broken in sticks')
            }
            this.stick.scale.set(0.1, 0.1, distance)

            var c1 = this.start.material.uniforms.color.value
            this.stick.startColor.r = c1.x
            this.stick.startColor.g = c1.y
            this.stick.startColor.b = c1.z

            var c2 = this.end.material.uniforms.color.value
            this.stick.endColor.r = c2.x
            this.stick.endColor.g = c2.y
            this.stick.endColor.b = c2.z

            this.stick.geometry.colorsNeedUpdate = true
          }
          stickContainer.stick = stick
          stickContainer.start = this
          stickContainer.end = connection
          if (this.connections.length > 6) {
            var nearest = this.connections[1]
            var minLen = 1 / 0
            for (i = 1; i < this.connections.length; i++) {
              var obj = this.connections[i]
              var len = obj.position.distanceTo(connection.position)
              if (
                minLen > len &&
                obj.objectData.bullet !== connection.objectData.bullet
              ) {
                minLen = len
                nearest = obj
              }
            }
            stickContainer.start = nearest
          }
          this.connections.push(connection)
          var color1 = stickContainer.end.material.color.clone()
          var color2 = stickContainer.start.material.color.clone()
          stick.endColor = color1
          stick.startColor = color2
          var faceIndices = ['a', 'b', 'c']
          for (i = 0; i < stick.geometry.faces.length; i++) {
            var f = stick.geometry.faces[i]
            for (var j = 0; j < 3; j++) {
              var vertexIndex = f[faceIndices[j]]
              var p = stick.geometry.vertices[vertexIndex]
              f.vertexColors[j] = p.z < 0.0 ? color1 : color2
            }
          }
          stick.geometry.colorsNeedUpdate = true

          stickContainer.add(stick)

          this.sticks.push(stickContainer)
          this.sticksContainer.add(stickContainer)
        }

        blob.hoverConnectionTarget = blob.clone()
        blob.hoverConnectionTarget.scale.set(0.01, 0.01, 0.01)
        blob.addConnection(blob.hoverConnectionTarget)

        blobs.add(blob)
      }

      return { blobs: blobs, sticks: sticks }
    },
    findObjectUnderEvent: function(ev) {
      let i
      let objects = undefined
      for (i = 0; i < this.units.data.length; i++) {
        if (!this.units.data[i].completed) continue
        objects = this.units.data[i].objects
        this.mouseX = this.clientX(ev)
        this.mouseY = this.clientY(ev)
        var mouse3D = new THREE.Vector3(
          (this.clientX(ev) / this.width) * 2 - 1,
          -(this.clientY(ev) / this.height) * 2 + 1,
          0.5
        )

        mouse3D.unproject(this.camera)
        mouse3D.sub(this.camera.position)
        mouse3D.normalize()
        var raycaster = new THREE.Raycaster(this.camera.position, mouse3D)
        var intersects = raycaster.intersectObjects(
          objects.blobs.children.filter(function(c) {
            return !c.disabled
          })
        )
        if (intersects.length > 0) {
          var obj = intersects[0].object
          return obj
        }
      }
    },
    findToolbarUnderEvent: function(ev) {
      if (!this.toolBar3D) {
        return
      }
      this.mouseX = this.clientX(ev)
      this.mouseY = this.clientY(ev)
      var mouse3D = new THREE.Vector3(
        (this.clientX(ev) / this.width) * 2 - 1,
        -(this.clientY(ev) / this.height) * 2 + 1,
        0.5
      )
      mouse3D.unproject(this.camera)
      mouse3D.sub(this.camera.position)
      mouse3D.normalize()
      var raycaster = new THREE.Raycaster(this.camera.position, mouse3D)
      var intersects = raycaster.intersectObjects(this.toolBar3D.buttons)
      if (intersects.length > 0) {
        var obj = intersects[0].object
        return obj
      }
    },
    tick: function(t, el, secondTick) {
      if (!this.active) return
      var cameraMinZ =
        this.mapYearToLandscapeZ(
          this.units.maxDate.unix() - this.units.baseDate.unix()
        ) - 100
      var cameraMaxZ = this.mapYearToLandscapeZ(0) + 40

      var scene = this.scene
      var camera = this.camera
      var introState = this.introState
      var introTime = this.introTime
      var cameraY = this.cameraY
      var cameraZMotion = this.cameraZMotion
      var cameraZTarget = this.cameraZTarget

      if (this.introTime < this.introLength + 16) {
        introTime = Math.max(0, this.introTime - (this.introLength - 3000))

        // if ($scope.introState < 3 && introTime > 0) {
        //   $scope.advanceIntro()
        //   $scope.$digest()
        // }

        camera.position.y = Math.max(
          cameraY,
          cameraY + 40 * Math.pow(Math.max(0, 1 - introTime / 3000), 3.0)
        )
        camera.position.z =
          this.mapYearToLandscapeZ(0) +
          28 +
          -800 * Math.max(0, 1 - Math.pow(introTime / 3000, 2))

        camera.target.x = 0
        camera.target.y = camera.position.y + 40 * (1 - introTime / 3000) - 10
        camera.target.z = camera.position.z - 50

        this.lines.position.z = this.camera.position.z

        camera.lookAt(camera.target)

        if (introState >= 2) {
          this.introTime += 16
        }
        // if ($scope.showIntroHelp && this.introTime >= this.introLength + 16) {
        //   $scope.$apply(function() {
        //     $scope.scrollHelp = true
        //   })
        // }
        // if (this.introBlobs) {
        //   this.introBlobs.position.copy(camera.target)
        //   this.introBlobs.lookAt(camera.position)
        // }
      }

      camera.position.z += cameraZMotion * 0.1
      if (cameraZMotion > 0 && cameraZMotion < 20) {
        cameraZMotion += 0.25
      } else if (cameraZMotion < 0 && cameraZMotion > -20) {
        cameraZMotion -= 0.25
      }
      if (cameraZMotion === 0) {
        if (
          cameraZTarget &&
          Math.abs(cameraZTarget - camera.position.z) < 0.001
        ) {
          cameraZTarget = null
        }
        if (cameraZTarget !== null) {
          camera.position.z += (cameraZTarget - camera.position.z) * 0.05
        }
      }
      this.cameraZMotion = cameraZMotion
      this.cameraZTarget = cameraZTarget

      if (this.introTime >= this.introLength + 16) {
        // if ($scope.introState < 4) {
        //   $scope.advanceIntro()
        //   $scope.$digest()
        // }
        this.linesPlane.visible = false

        camera.position.z += this.cameraVelocity.z

        if (Math.abs(this.cameraVelocity.z) < 1) {
          this.cameraVelocity.z *= 0.9
        } else {
          this.cameraVelocity.z *= 0.95
        }

        if (Math.abs(this.cameraVelocity.z) < 0.01) {
          this.cameraVelocity.z = 0
        }

        this.cameraXOffset += this.cameraVelocity.x
        if (this.cameraXOffset > 1) this.cameraXOffset = 1
        if (this.cameraXOffset < -1) this.cameraXOffset = -1
        this.cameraVelocity.x *= 0.9

        camera.position.x +=
          (this.cameraXOffset * 10 - camera.position.x) * 0.05
        camera.position.y +=
          (cameraY + 8 + this.cameraYOffset * 3 - camera.position.y) * 0.05

        camera.target.x +=
          (Math.sin(this.cameraXOffset * 0.5) * 30 - camera.target.x) * 0.1
        camera.target.y +=
          (cameraY + 8 - 20 + this.cameraYOffset * 5 - camera.target.y) * 0.1
        camera.target.z =
          camera.position.z - Math.cos(this.cameraXOffset * 0.5) * 50

        this.terrain.position.set(0, -20, camera.target.z)
        this.loadingText.position.set(0, -5, camera.target.z)
        // console.log(camera.target.z)
        camera.lookAt(camera.target)

        this.setCurrentDatetime(camera.target.z * -1)

        camera.updateProjectionMatrix()
        camera.updateMatrix()

        this.labels.visible = true
        this.toolBar3D.visible = true
        this.labels.position.z = camera.position.z - 25
        this.toolBar3D.position.z = camera.position.z - 25

        this.lines.position.z = this.toolBar3D.position.z

        if (camera.position.z > cameraMaxZ) {
          camera.position.z += (cameraMaxZ - camera.position.z) * 0.1
        } else if (camera.position.z < cameraMinZ) {
          camera.position.z += (cameraMinZ - camera.position.z) * 0.1
        }

        if (this.cameraZTarget > cameraMaxZ) {
          this.cameraZTarget += (cameraMaxZ - this.cameraZTarget) * 0.1
        } else if (this.cameraZTarget < cameraMinZ) {
          this.cameraZTarget += (cameraMinZ - this.cameraZTarget) * 0.1
        }

        // TODO: render future
        let currentIndex = 0
        let currentData = {}
        let found = false
        for (
          currentIndex = 0;
          currentIndex < this.units.data.length;
          currentIndex++
        ) {
          if (!this.units.data[currentIndex].completed) continue

          if (
            this.units.data[currentIndex].datetimes[0].zLocation >=
              camera.target.z &&
            camera.target.z >
              this.units.data[currentIndex].datetimes[3].zLocation
          ) {
            found = true
            break
          }
        }

        if (found) {
          // TODO: render future
          currentData = this.units.data[currentIndex]
          if (
            currentData.datetimes[2].zLocation > camera.target.z &&
            this.units.data[currentIndex + 1] === undefined &&
            this.units.maxDate >
              moment(this.units.data[currentIndex].startDate).add(
                this.units.interval,
                'days'
              )
          ) {
            if (this.units.data.length === 2) {
              // console.log(
              //   this.units.data.length + ': this.destroyObjectsPast()'
              // )
              this.destroyObjectsPast()
            }

            // console.log(
            //   camera.target.z +
            //     ':' +
            //     currentData.datetimes[20].zLocation +
            //     ' this.renderObjectsFuture()'
            // )
            // this.loadingText.position.set(0, 0, camera.target.z)
            this.loadingText.visible = true
            this.renderObjectsFuture()
          }
          // TODO: render past
          else if (
            currentData.datetimes[1].zLocation < camera.target.z &&
            currentIndex === 0 &&
            currentData.datetimes[0].zLocation !== 0
          ) {
            if (this.units.data.length === 2) {
              // console.log(
              //   this.units.data.length + ': this.destroyObjectsFuture()'
              // )
              this.destroyObjectsFuture()
            }

            // console.log(
            //   camera.target.z +
            //     ':' +
            //     currentData.datetimes[10].zLocation +
            //     ' this.renderObjectsPast()'
            // )
            // this.loadingText.position.set(0, 0, camera.target.z)
            this.loadingText.visible = true
            this.renderObjectsPast()
          }
        }

        if (
          this.hoverInfoObject &&
          this.active &&
          (this._inactive === false || this._inactive === null)
        ) {
          var hoverInfoEl = document.getElementById('object-hover-info')
          scene.updateMatrixWorld()
          this.linesPlane.updateMatrixWorld()
          this.hoverInfoObject.hoverConnectionTarget.updateMatrixWorld()
          this.moveToScreenCoords(
            this.hoverInfoObject.hoverConnectionTarget,
            camera,
            hoverInfoEl.getBoundingClientRect()
          )
        } else if (
          this.hoverInfoContextObject &&
          this.active &&
          (this._inactive === false || this._inactive === null)
        ) {
          var hoverInfoContextEl = document.getElementById(
            'object-hover-info-context'
          )
          scene.updateMatrixWorld()
          this.linesPlane.updateMatrixWorld()
          this.hoverInfoContextObject.hoverConnectionTarget.updateMatrixWorld()
          this.moveToScreenCoords(
            this.hoverInfoContextObject.hoverConnectionTarget,
            camera,
            hoverInfoContextEl.getBoundingClientRect()
          )
        }
      }

      this.landscapeShaderMaterial.uniforms.time.value += 0.016

      scene.tick()

      if (this.frameElapsed > 25 && (!secondTick || secondTick < 4)) {
        this.frameElapsed -= 25
        this.tick(time, undefined, (secondTick || 0) + 1)
      } else {
        var time = this.now()
        this.frameElapsed = time - this.lastFrameTime
        this.lastFrameTime = time
        this.render()

        if (
          this.findToolbarUnderEvent(this.eventData.mouseCurrent) ||
          this.findObjectUnderEvent(this.eventData.mouseCurrent)
        ) {
          this.overlaysEl.style.cursor = 'pointer'
        } else {
          this.overlaysEl.style.cursor = 'default'
        }

        window.requestAnimationFrame(this.tick)
      }
    },
    moveToScreenCoords: function(obj, camera, rect) {
      var x =
        2.0 * ((rect.left - this.eventData.offset.left + 10) / this.width) - 1
      var y =
        -2.0 * ((rect.top - this.eventData.offset.top + 10) / this.height) + 1

      var mouse3D = new THREE.Vector3(x, y, 0.5)
      mouse3D.unproject(camera)
      mouse3D.sub(camera.position)
      mouse3D.normalize()

      var raycaster = new THREE.Raycaster(camera.position, mouse3D)
      var intersects = raycaster.intersectObjects([this.linesPlane])

      if (intersects.length > 0) {
        obj.position.copy(intersects[0].point)
      }
    },
    clientX(event) {
      return event.clientX - this.eventData.offset.left
    },
    clientY(event) {
      return event.clientY - this.eventData.offset.top
    },
    eventHandlerResize: function() {
      // let topContainer = document.getElementById('top')
      // frag size
      if (this._inactive) return

      this.width = Number(
        document.getElementsByClassName('dea-section')[0].clientWidth
      )
      this.height =
        window.innerHeight -
        Number(
          document.getElementsByClassName('page-header-wrap')[0].clientHeight
        ) -
        Number(document.getElementsByClassName('search-box')[0].clientHeight) -
        72
      // topContainer.style.paddingTop.split('px')[0] -
      // 80 -
      // 80
      if (this.appbar.show) {
        this.height =
          this.height -
          Number(document.getElementsByClassName('dea-app-bar')[0].clientHeight)
      }

      this.windowHalfX = this.width / 2
      this.windowHalfY = this.height / 2

      this.camera.aspect = this.width / this.height
      this.camera.updateProjectionMatrix()

      this.renderer.setSize(this.width, this.height)

      this.landscapeShaderMaterial.uniforms.scale.value =
        this.renderer.domElement.width / 1000

      this.eventData.offset.left = this.$refs.timeGraphContainer.getBoundingClientRect().left
      this.eventData.offset.top = this.$refs.timeGraphContainer.getBoundingClientRect().top

      document.getElementsByClassName(
        'datetime-slider-wrapper'
      )[0].style.width = this.width + 'px'
    },
    eventHandlerTouchStart: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (event.target.id !== 'overlays') return
      var touches = event.changedTouches
      for (var i = 0; i < touches.length; i++) {
        this.eventData.ongoingTouches[touches[i].identifier] = touches[i]
      }

      if (this.eventData.activeTouch === null) {
        this.eventData.touchMode = true
        window.onmousedown(touches[0])
        this.eventData.activeTouch = touches[0].identifier
      }
      event.preventDefault()
    },
    eventHandlerTouchEnd: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (event.target.id !== 'overlays') return
      var touches = event.changedTouches
      for (var i = 0; i < touches.length; i++) {
        delete this.eventData.ongoingTouches[touches[i].identifier]
        if (touches[i].identifier === this.eventData.activeTouch) {
          window.onmouseup(touches[i])
          this.eventData.activeTouch = null
          this.eventData.touchMode = false
        }
      }
      event.preventDefault()
    },
    eventHandlerTouchCancel: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (event.target.id !== 'overlays') return
      var touches = event.changedTouches
      for (var i = 0; i < touches.length; i++) {
        delete this.eventData.ongoingTouches[touches[i].identifier]
        if (touches[i].identifier === this.eventDataactiveTouch) {
          window.onmouseup(touches[i])
          this.eventDataactiveTouch = null
          this.eventData.touchMode = false
        }
      }
      event.preventDefault()
    },
    eventHandlerTouchMove: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (event.target.id !== 'overlays') return
      var touches = event.changedTouches
      for (var i = 0; i < touches.length; i++) {
        delete this.eventData.ongoingTouches[touches[i].identifier]
        if (touches[i].identifier === this.eventData.activeTouch) {
          this.eventHandlerMouseMove(touches[i])
        }
      }
      event.preventDefault()
    },
    eventHandlerMouseDown: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (!self.active) return
      this.eventData.down = true
      this.eventData.downX = this.eventData.lastX = this.clientX(event)
      this.eventData.downY = this.eventData.lastY = this.clientY(event)
      this.cameraVelocity.multiplyScalar(0)
      this.eventData.clickActive = true
      if (event.preventDefault) {
        event.preventDefault()
      }
    },
    eventHandlerMouseMove: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return

      this.eventData.mouseCurrent.clientX = event.clientX
      this.eventData.mouseCurrent.clientY = event.clientY

      if (this.active && this.eventData.down) {
        var dy = this.clientY(event) - this.eventData.lastY
        var dx = this.clientX(event) - this.eventData.lastX
        this.cameraVelocity.z = this.eventData.touchMode
          ? this.cameraVelocity.z / 2 + -dy / 3 / 2
          : this.cameraVelocity.z / 2 + -dy
        this.eventData.lastY = this.clientY(event)
        this.eventData.lastX = this.clientX(event)
        if (
          Math.abs(this.eventData.downY - this.eventData.lastY) > 5 ||
          Math.abs(this.eventData.downX - this.eventData.lastX) > 5
        ) {
          this.eventData.clickActive = false
        }
        if (this.eventData.touchMode) {
          this.cameraVelocity.x =
            this.cameraVelocity.x / 2 + (-4 * dx) / this.width / 2
          if (dx * dx > dy * dy) {
            this.cameraVelocity.z = 0
          } else {
            this.cameraVelocity.x = 0
          }
          if (this.cameraXOffset > 1) {
            this.cameraXOffset = 1
            this.cameraVelocity.x = 0
          }
          if (this.cameraXOffset < -1) {
            this.cameraXOffset = -1
            this.cameraVelocity.x = 0
          }
        }
      } else if (this.active) {
        // var previousHovered = null
        // this.objects.blobs.children.forEach(function(c) {
        // if (c.hovered) {
        //   previousHovered = c
        // }
        //   c.hovered = false
        // })
        let i
        let objects = undefined
        for (i = 0; i < this.units.data.length; i++) {
          if (!this.units.data[i].completed) continue
          objects = this.units.data[i].objects
          objects.blobs.children.forEach(function(c) {
            c.hovered = false
          })
        }
        var obj = this.findToolbarUnderEvent(event)
        if (obj) {
          this.hoveredUser = obj.userName
        } else {
          this.hoveredUser = null
          obj = this.findObjectUnderEvent(event)
          if (obj) {
            obj.hovered = true
            // if (
            //   obj !== previousHovered &&
            //   (obj.soundLastPlayed == null ||
            //     Date.now() - obj.soundLastPlayed > 200)
            // ) {
            //   obj.soundLastPlayed = Date.now()
            //   if (obj.soundIndex === undefined) {
            //     obj.soundIndex = -4 * obj.position.y
            //   }
            //   this.audioManager.playSoundEffect(obj.soundIndex)
            // }
          }
        }
      }
      // var mouse3D = new THREE.Vector3(
      //   (this.clientX(event) / this.width) * 2 - 1,
      //   -(this.clientY(event) / this.height) * 2 + 1,
      //   0.5
      // )
      // if (this.introTime > this.introLength) {
      //   this.cameraXOffset = this.eventData.touchMode
      //     ? this.cameraXOffset
      //     : mouse3D.x
      //   this.cameraYOffset = this.eventData.touchMode
      //     ? this.width > this.height
      //       ? 1
      //       : 0.5
      //     : mouse3D.y
      // }
      if (event.preventDefault) {
        event.preventDefault()
      }
    },
    eventHandlerMouseUp: function(event) {
      var obj
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (!this.active) return
      this.eventData.down = false
      this.cameraZMotion = 0
      this.cameraZTarget = null
      if (event.preventDefault) {
        event.preventDefault()
      }
      // console.log(ev.target);
      if (this.eventData.clickActive && event.which === 1) {
        obj = this.findToolbarUnderEvent(event)
        if (obj) {
          if (this.selectedUser === obj.userName) {
            this.selectedUser = null
          } else {
            this.selectedUser = obj.userName
          }
        } else {
          obj = this.findObjectUnderEvent(event)
          let i

          let objects = undefined
          for (i = 0; i < this.units.data.length; i++) {
            if (!this.units.data[i].completed) continue
            objects = this.units.data[i].objects
            objects.blobs.children.forEach(function(c) {
              c.selected = false
              c.connectionSelected = false
            })
          }

          var needDigest = false
          if (obj) {
            obj.selected = true
            if (
              !this.personTypeToggled &&
              this.personType !== obj.objectData.personType
            ) {
              this.personType = (obj.objectData.personType + '').toLowerCase()
              needDigest = true
            }
            obj.connections.forEach(function(c) {
              c.connectionSelected = true
            })
          } else if (!this.personTypeToggled && this.personType !== null) {
            this.personType = null
            needDigest = true
          }
          if (this.hoverInfoObject !== obj) {
            this.hoverInfoObject = obj
            this.hoverInfoContextObject = null
            needDigest = true
            if (needDigest) {
              // $scope.$digest()
            }
            if (this.hoverInfoObject) {
              var hoverInfoEl = document.getElementById('object-hover-info')
              let clientX = this.clientX(event)
              let clientY = this.clientY(event)
              if (clientX + 480 > this.width && clientX - 480 < 0) {
                hoverInfoEl.style.left = this.width / 2 - 460 / 2 + 'px'
                hoverInfoEl.style.right = 'auto'
              } else if (clientX + 460 > this.width) {
                hoverInfoEl.style.right = this.width - (clientX - 50) + 'px'
                hoverInfoEl.style.left = 'auto'
              } else {
                hoverInfoEl.style.right = 'auto'
                hoverInfoEl.style.left = clientX + 100 + 'px'
              }
              if (clientY + 200 > this.height) {
                hoverInfoEl.style.top = 'auto'
                hoverInfoEl.style.bottom = this.height - (clientY - 30) + 'px'
              } else {
                hoverInfoEl.style.bottom = 'auto'
                hoverInfoEl.style.top =
                  event.clientY - this.eventData.offset.top + 180 + 'px'
              }

              var hoverInfoTitleEl = document.getElementsByClassName(
                'object-hover-title'
              )[0]

              if (this.hoverInfoObject.laneIndex < 3)
                hoverInfoTitleEl.style.color = '#484946'
              else hoverInfoTitleEl.style.color = '#ffffff'
              hoverInfoEl.style.backgroundColor = this.hoverInfoObject.objectData.backgroundColor
            }
          } else if (obj && this.hoverInfoObject === obj) {
            let objects = undefined
            for (i = 0; i < this.units.data.length; i++) {
              if (!this.units.data[i].completed) continue
              objects = this.units.data[i].objects
              objects.blobs.children.forEach(function(c) {
                c.selected = false
                c.connectionSelected = false
              })
            }
            this.hoverInfoObject = null
            this.hoverInfoContextObject = null
            // $scope.$digest()
            if (obj.objectData) {
              // this.active = false // TODO: check, why set to false?
              // $scope.$apply(function() {
              //   $location.path('/object/' + obj.objectData.bullet)
              // })
            }
          } else {
            this.selectedUser = null
          }
        }
      }
    },
    eventHandlerMouseWheel: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (!this.active) return
      if (this.introState < 4) {
        if (event.wheelDelta < 0) {
          // $scope.$digest()
        }
      } else if (this.introTime >= this.introLength + 16) {
        this.cameraZTarget =
          (this.cameraZTarget || this.camera.position.z) -
          event.wheelDelta * 0.15
      }
    },
    eventHandlerContextMenu: function(event) {
      if (event.target !== document.getElementsByTagName('canvas')[0]) return
      if (!this.active) return

      if (event.preventDefault) {
        event.preventDefault()
      }

      let obj

      if (this.eventData.clickActive) {
        obj = this.findObjectUnderEvent(event)

        let i

        let objects = undefined
        for (i = 0; i < this.units.data.length; i++) {
          if (!this.units.data[i].completed) continue
          objects = this.units.data[i].objects
          objects.blobs.children.forEach(function(c) {
            c.selected = false
            c.connectionSelected = false
          })
        }

        if (obj) {
          obj.selected = true
          obj.connections.forEach(function(c) {
            c.connectionSelected = true
          })
          this.hoverInfoObject = null
          this.hoverInfoContextObject = obj
          this.contextSelection = null

          var hoverInfoEl = document.getElementById('object-hover-info-context')
          let clientX = this.clientX(event)
          let clientY = this.clientY(event)
          if (clientX + 480 > this.width && clientX - 480 < 0) {
            hoverInfoEl.style.left = this.width / 2 - 460 / 2 + 'px'
            hoverInfoEl.style.right = 'auto'
          } else if (clientX + 460 > this.width) {
            hoverInfoEl.style.right = this.width - (clientX - 50) + 'px'
            hoverInfoEl.style.left = 'auto'
          } else {
            hoverInfoEl.style.right = 'auto'
            hoverInfoEl.style.left = clientX + 100 + 'px'
          }
          if (clientY + 200 > this.height) {
            hoverInfoEl.style.top = 'auto'
            hoverInfoEl.style.bottom = this.height - (clientY - 30) + 'px'
          } else {
            hoverInfoEl.style.bottom = 'auto'
            hoverInfoEl.style.top =
              event.clientY - this.eventData.offset.top + 180 + 'px'
          }
        } else {
          this.hoverInfoObject = null
          this.hoverInfoContextObject = null
        }
      }
    },
    destroyEventListeners: function() {
      window.removeEventListener('resize', this.eventHandlerResize, false)

      window.removeEventListener(
        'touchstart',
        this.eventHandlerTouchStart,
        false
      )
      window.removeEventListener('touchend', this.eventHandlerTouchEnd, false)
      window.removeEventListener(
        'touchcancel',
        this.eventHandlerTouchCancel,
        false
      )
      window.removeEventListener('touchmove', this.eventHandlerTouchMove, false)

      window.removeEventListener('mousedown', this.eventHandlerMouseDown, false)
      window.removeEventListener('mousemove', this.eventHandlerMouseMove, false)
      window.removeEventListener('mouseup', this.eventHandlerMouseUp, false)
      window.removeEventListener(
        'mousewheel',
        this.eventHandlerMouseWheel,
        false
      )
      window.removeEventListener(
        'contextmenu',
        this.eventHandlerContextMenu,
        false
      )
    },
    setupEventListeners: function() {
      window.addEventListener('resize', this.eventHandlerResize, false)

      window.addEventListener('touchstart', this.eventHandlerTouchStart, false)
      window.addEventListener('touchend', this.eventHandlerTouchEnd, false)
      window.addEventListener(
        'touchcancel',
        this.eventHandlerTouchCancel,
        false
      )
      window.addEventListener('touchmove', this.eventHandlerTouchMove, false)

      window.addEventListener('mousedown', this.eventHandlerMouseDown, false)
      window.addEventListener('mousemove', this.eventHandlerMouseMove, false)
      window.addEventListener('mouseup', this.eventHandlerMouseUp, false)
      window.addEventListener('mousewheel', this.eventHandlerMouseWheel, false)
      window.addEventListener(
        'contextmenu',
        this.eventHandlerContextMenu,
        false
      )

      this.overlaysEl = document.getElementById('dea-timebase-graph-container')
      // this.overlaysEl.addEventListener(
      //   'mousemove',
      //   function(ev) {
      //     this.mouseCurrent.clientX = ev.clientX
      //     this.mouseCurrent.clientY = ev.clientY
      //   },
      //   false
      // )
    },
    initWebGL: function() {
      let container = document.getElementById('dea-timebase-graph-container')
      // let topContainer = document.getElementById('top')

      this.renderer = new THREE.WebGLRenderer({ antialias: true })
      this.renderer.setPixelRatio(window.devicePixelRatio || 1)

      this.lastFrameTime = this.now()

      // frag size
      this.width = Number(
        document.getElementsByClassName('dea-section')[0].clientWidth
      )
      this.height =
        window.innerHeight -
        Number(
          document.getElementsByClassName('page-header-wrap')[0].clientHeight
        ) -
        Number(document.getElementsByClassName('search-box')[0].clientHeight) -
        72

      if (this.appbar.show) {
        this.height =
          this.height -
          Number(document.getElementsByClassName('dea-app-bar')[0].clientHeight)
      }

      this.renderer.setSize(this.width, this.height)

      this.renderer.setClearColor(0x66685d, 1.0)
      //this.renderer.setClearColor(0xdadce0, 1.0)

      this.windowHalfX = this.width / 2
      this.windowHalfY = this.height / 2

      if (this.width > this.height) {
        this.cameraYOffset = 1
      }

      this.eventData.offset.left = this.$refs.timeGraphContainer.getBoundingClientRect().left
      this.eventData.offset.top = this.$refs.timeGraphContainer.getBoundingClientRect().top

      document.getElementsByClassName(
        'datetime-slider-wrapper'
      )[0].style.width = this.width + 'px'

      container.appendChild(this.renderer.domElement)

      this.itemGeometry = new THREE.PlaneBufferGeometry(1, 1)
      this.initScene()
    },
    initScene: function() {
      this.scene = new THREE.Scene()
      this.scene.frustumCulled = false

      this.camera = new THREE.PerspectiveCamera(
        50,
        this.width / this.height,
        1,
        3000
      )

      this.camera.position.z = 100
      this.camera.position.y = 2

      this.camera.target = new THREE.Vector3()
      this.camera.target.copy(this.camera.position)

      this.scene.fog = new THREE.Fog(0x66685d, 100, 400)

      window.camera = this.camera
      this.scene.add(this.camera)

      this.labelScene = new THREE.Scene()
      this.labelScene.fog = this.scene.fog

      this.cameraVelocity = new THREE.Vector3()

      this.scene.tick = function() {
        // TODO: Check this.
        for (var i = 0; i < this.children.length; i++) {
          if (this.children[i].tick) {
            this.children[i].tick()
          }
        }
      }
    },
    initTimeArrow: function() {
      this.timeArrow = this.createTimeArrow()
      this.scene.add(this.timeArrow)
      var self = this
      this.timeArrow.tick = function() {
        this.position.z = self.camera.position.z + this.zOffset
      }
    },
    destroyLandscape: function() {
      this.scene.remove(this.lanes)
      this.scene.remove(this.objects.blobs, this.objects.sticks)
      this.lanes = null
      this.objects.blobs = null
      this.objects.sticks = null
      this.objects = null
    },
    renderLandscape: function(index, rows) {
      let data = this.units.data[index]
      this.createObjectArray(index, rows)

      this.createDatetimeLine(index)

      data.objects = this.createObjects(data.objectArray)
      data.objects.blobs.tick = this.scene.tick
      data.objects.sticks.tick = this.scene.tick

      this.scene.add(data.objects.blobs, data.objects.sticks)
      data.completed = true

      // TODO: Check, memory leak
      // var blobs = this.objects.blobs
      // var processBlobs = function(i) {
      //   var startTime = Date.now()
      //   for (; Date.now() - startTime < 12 && i < blobs.children.length; i++) {
      //     var blob = blobs.children[i]
      //     var obj = blob.objectData
      //     var c = obj.dateCreated
      //     var bullet = obj.bullet
      //     obj.personTypeObjects.sort(function(a, b) {
      //       return Math.abs(a.dateCreated - c) - Math.abs(b.dateCreated - c)
      //     })
      //     for (var j = 0; j < obj.personTypeObjects.length; j++) {
      //       var related = self.blobIndex[obj.personTypeObjects[j].bullet]
      //       if (related && related.objectData.bullet !== bullet) {
      //         blob.addConnection(blob, related)
      //       }
      //     }
      //   }
      //   return i
      // }

      // var ival = setInterval(function() {
      //   // console.log(i);
      //   i = processBlobs(i)
      //   if (i === blobs.children.length) {
      //     // console.log('done');
      //     clearInterval(ival)
      //     self.loadingPercentageMax += 10
      //     // console.timeEnd('blobs');
      //     return
      //   }
      // }, 16)
    },
    initToolbar: function() {
      this.toolBar3D = new THREE.Object3D()
      this.toolBar3D.buttons = []
      this.toolBar3D.tick = this.scene.tick

      this.labels = new THREE.Object3D()
      this.labels.position.copy(this.toolBar3D.position)

      var textGeo = new THREE.PlaneBufferGeometry(256 / 45, 32 / 45)

      for (var i = 0; i < this.users.length; i++) {
        var obj = new THREE.Object3D()
        var bg = new THREE.Mesh(
          new THREE.PlaneBufferGeometry((6 / 5) * 6, 1),
          new THREE.MeshBasicMaterial({ color: this.colors[i] })
        )
        obj.position.set(
          (6 / 5) * 6 * (i - (this.users.length - 1) / 2),
          -10.5,
          0
        )
        bg.userName = this.users[i]
        var self = this
        // toolbarTick
        bg.tick = function() {
          var s
          if (self.selectedUser && this.userName !== self.selectedUser) {
            if (this.originalColor === undefined) {
              this.originalColor = this.material.color.getHex()
            }
            this.material.color.setHex(0x484946)
          } else if (this.originalColor !== undefined) {
            this.material.color.setHex(this.originalColor)
          }

          if (self.hoveredUser === this.userName) {
            this.position.y += (+0.36 / 2 - this.position.y) * 0.1
            this.scale.y += (1.36 - this.scale.y) * 0.1
            this.label.scale.x += (1.2 - this.label.scale.x) * 0.1
            s = this.label.scale.x
            this.label.scale.set(s, s, s)
            this.label.position.y = this.position.y - 10.5
          } else {
            this.position.y += (0 - this.position.y) * 0.1
            this.scale.y += (1 - this.scale.y) * 0.1
            this.label.scale.x += (1 - this.label.scale.x) * 0.1
            s = this.label.scale.x
            this.label.scale.set(s, s, s)
            this.label.position.y = this.position.y - 10.5
          }
        }
        obj.add(bg)

        obj.tick = function() {
          this.children[0].tick(this.children[0])
        }

        this.toolBar3D.buttons.push(bg)

        var textCanvas = document.createElement('canvas')
        textCanvas.width = 256
        textCanvas.height = 32

        var tex = new THREE.Texture(textCanvas)
        tex.minFilter = THREE.LinearFilter

        setTimeout(
          (function(textCanvas, tex, title) {
            return function() {
              // console.log(title)
              var ctx = textCanvas.getContext('2d')
              ctx.fillStyle = '#000000'
              ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height)

              ctx.font = 'lighter 30px Lato, sans-serif'
              ctx.fillStyle = '#FFFFFF'
              var w = ctx.measureText(title).width
              ctx.fillText(title, (ctx.canvas.width - w) / 2, 28)
              tex.needsUpdate = true
            }
          })(textCanvas, tex, this.users[i]),
          500
        )

        var mat = new THREE.MeshBasicMaterial({
          map: tex,
          side: THREE.DoubleSide,
          blending: THREE.AdditiveBlending
        })
        mat.transparent = true
        mat.depthWrite = false
        mat.depthTest = false

        var text = new THREE.Mesh(textGeo, mat)
        text.position.copy(obj.position)
        bg.label = text
        this.labels.add(text)
        text.position.z = 0.01

        this.toolBar3D.add(obj)
      }
      this.toolBar3D.visible = false
      this.labels.visible = false
      this.scene.add(this.toolBar3D)
      this.labelScene.add(this.labels)
    },
    destroyToolbar() {
      this.scene.remove(this.toolBar3D)
      this.labelScene.remove(this.labels)
      this.toolBar3D = null
      this.labels = null
    },
    createTerrain: function() {
      var terrain = new THREE.Object3D()

      var mat1 = new THREE.PointsMaterial({
        vertexColors: true,
        sizeAttenuation: true,
        map: this.blobTextures[0],
        transparent: true,
        opacity: 0.25
      })
      mat1.blending = THREE.AdditiveBlending
      var mat2 = new THREE.PointsMaterial({
        vertexColors: true,
        sizeAttenuation: true,
        map: this.blobTextures[0],
        transparent: true,
        opacity: 0.25
      })
      mat2.blending = THREE.AdditiveBlending

      mat1 = mat2 = this.landscapeShaderMaterial
      mat2.blending = THREE.AdditiveBlending
      this.landscapeShaderMaterial.uniforms.map.value = this.blobTextures[0]

      terrain.add(
        new THREE.Points(this.landscapeGeo1, mat1),
        new THREE.Points(this.landscapeGeo2, mat2)
      )
      terrain.frustumCulled = false

      terrain.scale.set(2, 2, 4.5)
      terrain.position.set(0, -20, 0)

      return terrain
    },
    initTerrain: function() {
      this.api.get('/api/landscapeCoords.json').then((res) => {
        this.renderTerrain(res.data)
      })
    },
    renderTerrain: function(landscapeCoords) {
      var i
      var verts = new Float32Array(landscapeCoords[0].coords)
      var colors = new Float32Array(landscapeCoords[0].colors)
      for (i = 0; i < verts.length; i++) {
        verts[i] = (verts[i] / 65535) * 447 - 227
        colors[i] = (colors[i] / 16) * (0.63 - 0.365) + 0.365
      }
      this.landscapeGeo1 = new THREE.BufferGeometry()
      this.landscapeGeo1.setAttribute(
        'position',
        new THREE.BufferAttribute(verts, 3)
      )
      this.landscapeGeo1.setAttribute(
        'color',
        new THREE.BufferAttribute(colors, 3)
      )

      verts = new Float32Array(landscapeCoords[1].coords)
      colors = new Float32Array(landscapeCoords[1].colors)
      for (i = 0; i < verts.length; i++) {
        verts[i] = (verts[i] / 65535) * 447 - 216
        colors[i] = (colors[i] / 16) * (0.63 - 0.365) + 0.365
      }
      this.landscapeGeo2 = new THREE.BufferGeometry()
      this.landscapeGeo2.setAttribute(
        'position',
        new THREE.BufferAttribute(verts, 3)
      )
      this.landscapeGeo2.setAttribute(
        'color',
        new THREE.BufferAttribute(colors, 3)
      )

      this.terrain = this.createTerrain()
      this.scene.add(this.terrain)
    },
    render: function() {
      this.renderer.autoClear = false
      this.renderer.clear()
      this.renderer.render(this.scene, this.camera)
      this.renderer.render(this.labelScene, this.camera)
    },
    init: function() {
      this.webgl = Detector.webgl

      this.initWebGL()
      this.setupEventListeners()
      this.initTerrain()
      this.eventHandlerResize()
      this.render()
    },
    getMaxCountUsers: function() {
      return new Promise((resolve) => {
        this.api.get('/api/call/max-count-users').then((res) => {
          let users = Array.from(res.data.rows, (e) => {
            return e.user
          })

          this.setUsers(users)
          resolve()
        })
      })
    },
    getDateMinMax: function() {
      return new Promise((resolve) => {
        this.api.get('/api/call/history/date-min-max').then((res) => {
          if (res.data.min && res.data.max) {
            this.units.baseDate = moment(res.data.min, 'YYYY-MM-DD')
            this.units.maxDate = moment(res.data.max, 'YYYY-MM-DD')
          }
          resolve()
        })
      })
    },
    setUsers: function(users) {
      if (Array.isArray(users)) {
        this.users = []
        this.userLane = {}
        users.forEach((e, i) => {
          this.users.push(e)
          this.userLane[e] = i
        })

        this.lanes = this.createLanes()
        this.lines = this.lanes.lines
        this.linesPlane = this.lanes.linesPlane
        this.scene.add(this.lanes)

        this.initTimeArrow()
        this.tick()
      }

      this.initToolbar()
      this.creaetLoadingText()
    },
    creaetLoadingText: function() {
      var textCanvas = document.createElement('canvas')
      textCanvas.width = 1024
      textCanvas.height = 220

      var ctx = textCanvas.getContext('2d')
      ctx.font = 'bold 200px Lato, Arial'
      ctx.fillStyle = '#FFFFFF'
      ctx.fillText('Loading...', 0, 160)

      var tex = new THREE.Texture(textCanvas)
      tex.needsUpdate = true

      var mat = this.canvasShaderMaterial.clone()
      var color = new THREE.Color(0xffffff)
      mat.uniforms = {
        map: { type: 't', value: tex },
        color: {
          type: 'v3',
          value: new THREE.Vector3(color.r, color.g, color.b)
        }
      }

      var text = new THREE.Mesh(
        new THREE.PlaneBufferGeometry(
          textCanvas.width / 25,
          textCanvas.height / 25
        ),
        mat
      )
      text.visible = true
      // text.position.set(10, -300, 0)

      this.scene.add(text)

      this.loadingText = text
    },
    reRenderObjects: function() {
      this.destroyObject()
      this.renderObjects(0)
    },
    destroyObject: function() {
      // this.active = false
      this.destroyToolbar()
      this.destroyObjectArray()
      this.destroyLandscape()
    },
    destroyObjectsPast: function() {
      this.destroyObjects(0)
    },
    destroyObjectsFuture: function() {
      this.destroyObjects(this.units.data.length - 1)
    },
    destroyObjects: function(index) {
      let data = this.units.data[index]

      data.objectArray = []
      data.objectIndex = {}

      this.scene.remove(data.objects.blobs, data.objects.sticks)
      data.objects.blobs = null
      data.objects.sticks = null
      data.objects = null

      this.lanes.remove(data.dividers)
      this.lanes.remove(data.yearTicks)
      data.dividers = null
      data.yearTicks = null

      if (index === 0) this.units.data.shift()
      else this.units.data.pop()
    },
    renderObjectsPast: function() {
      let current = this.units.data[0]
      let past = {
        startDate: moment(current.startDate).subtract(
          this.units.interval,
          'days'
        ),
        minDateCreated: current.minDateCreated - unitDateTime,
        maxDateCreated: current.minDateCreated,
        datetimes: [],
        objectArray: [],
        objectsByPersonType: {},
        objectIndex: {},
        objects: null,
        dividers: null,
        yearTicks: null,
        completed: false
      }

      this.units.data.unshift(past)
      this.renderObjects(0)
    },
    renderObjectsTarget: function(datetime) {
      let i
      let length = this.units.data.length
      this.loadingText.visible = true
      for (i = 0; i < length; i++) this.destroyObjects(0)

      let targetDate = moment(datetime, 'YYYY-MM-DD')
      let data = {
        startDate: targetDate,
        minDateCreated: targetDate.unix() - this.units.baseDate.unix(),
        maxDateCreated:
          targetDate.unix() - this.units.baseDate.unix() + unitDateTime,
        datetimes: [],
        objectArray: [],
        objectsByPersonType: {},
        objectIndex: {},
        objects: null,
        dividers: null,
        yearTicks: null,
        completed: false
      }
      this.units.data.push(data)
      this.renderObjects(0)
      this.cameraZTarget = null
      this.camera.position.z = this.mapYearToLandscapeZ(
        data.minDateCreated + unitDivider
      )
    },
    renderObjectsFuture: function() {
      let current = this.units.data[this.units.data.length - 1]
      let future = {
        startDate: moment(current.startDate).add(this.units.interval, 'days'),
        minDateCreated: current.maxDateCreated,
        maxDateCreated: current.maxDateCreated + unitDateTime,
        datetimes: [],
        objectArray: [],
        objectsByPersonType: {},
        objectIndex: {},
        objects: null,
        dividers: null,
        yearTicks: null,
        completed: false
      }

      this.units.data.push(future)
      this.renderObjects(this.units.data.length - 1)
    },
    renderObjects: function(index) {
      let data = this.units.data[index]
      this.api
        .get(
          '/api/call/timebase?users={0}&baseDate={1}&startDate={2}&interval={3}&unit=day'.format(
            this.users.join(','),
            this.units.baseDate.format('YYYY-MM-DD'),
            data.startDate.format('YYYY-MM-DD'),
            this.units.interval
          )
        )
        .then((res) => {
          // let dateBase = moment('2016-02-01', 'YYYY-MM-DD').unix()
          let minDateCreated = data.minDateCreated
          let maxDateCreated = data.maxDateCreated
          let divider = unitDivider
          let dateTime

          data.datetimes = []
          for (
            dateTime = minDateCreated;
            dateTime <= maxDateCreated;
            dateTime += divider
          ) {
            data.datetimes.push({
              start: dateTime,
              end: dateTime + divider,
              dateTime: dateTime,
              text: moment
                .unix(this.units.baseDate.unix() + dateTime)
                .format('YYYY-MM-DD HH:mm'),
              zLocation: 0
            })
          }
          this.renderLandscape(index, res.data.rows)
          this.loadingText.visible = false
        })
    },
    onMouseUpSlider() {
      this.renderObjectsTarget(this.sliderToDatetime(this.slider))
    },
    showPersonInformation() {
      let i
      let objects = undefined

      this.individualDetailParams = {
        data: {
          no: 0,
          name: this.hoverInfoContextObject.objectData.user,
          photo: '',
          ptName: '피의자',
          phoneNumber: this.hoverInfoContextObject.objectData.number,
          nickname: '별칭',
          pgName: null,
          comName: '',
          divName: '',
          joinDate: '2017-02-11 14:37',
          updateDate: '2017-02-11 14:37',
          registeredUser: '등록자명',
          evidenceNumber: '증거번호234',
          memo: '',
          keyword: '',
          merge: null,
          represent: null
        }
      }

      this.individualDetail = true
      this.hoverInfoContextObject = null

      for (i = 0; i < this.units.data.length; i++) {
        if (!this.units.data[i].completed) continue
        objects = this.units.data[i].objects
        objects.blobs.children.forEach(function(c) {
          c.selected = false
          c.connectionSelected = false
        })
      }
      this.contextSelection = null
    }
  },
  mounted() {
    this.getDateMinMax().then(() => {
      this.init()
      this.getMaxCountUsers().then(() => {
        this.units.data[0].startDate = this.units.baseDate
        this.setCurrentDatetime(0)

        this.renderObjects(0)
      })
    })
  },
  destroyed() {
    this.active = false
    this.renderer = null
    this.camera = null
    this.scene = null
    this.objects = null
    this.objectArray = null
    this.objectIndex = null
    this.destroyEventListeners()
  }
}
</script>

<style scoped>
#object-hover-info.visible {
  opacity: 1;
  pointer-events: all;
}

#object-hover-info {
  position: absolute;
  display: block;
  text-decoration: none;
  left: 50%;
  top: 50%;
  width: 416px;
  min-height: 120px;
  box-sizing: border-box;
  z-index: 2;
  padding-left: 19px;
  padding-top: 10px;
  padding-right: 19px;
  padding-bottom: 14px;
  color: white;
  box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
  pointer-events: none;
  opacity: 0;
  transition: 0.5s;
  -webkit-animation: bounce 0.5s 1 both;
  animation: bounce 0.5s 1 both;
  color: #484946;
}

#object-hover-info > * {
  vertical-align: top;
}

.object-hover-title {
  font-family: 'Lato', sans-serif;
  font-weight: normal;
  font-size: 14px;
  text-align: center;
  padding-bottom: 4px;
  margin-bottom: 3px;
  text-transform: uppercase;
}

.object-hover-culture {
  font-family: 'Lato', sans-serif;
  font-weight: normal;
  font-size: 14px;
  background: #f0f0f3;
}

.object-hover-culture .row {
  border-color: #484946;
  border-top: 1px solid;
  border-left: 1px solid;
  border-right: 1px solid;
  min-height: 30px !important;
}

.object-hover-culture .row:last-child {
  border-bottom: 1px solid;
}

.object-hover-culture .col {
  min-height: 30px !important;
}

.object-hover-culture .col:nth-child(2) {
  border-left: 1px solid;
}

.object-hover-explore {
  font-family: 'Lato', sans-serif;
  font-weight: normal;
  font-size: 14px;
  display: inline-block;
  text-transform: uppercase;
  border: 1px solid white;
  padding-left: 12px;
  padding-right: 12px;
  padding-top: 3px;
  padding-bottom: 3px;
}

#object-hover-info .object-category-thumb {
  width: 170px;
  height: 100%;
  position: absolute;
  border: 0;
  top: 0px;
  right: 7px;
}

.datetime-slider-wrapper {
  position: absolute;
  left: 55px;
  top: 159px;
  width: 1737px;
  height: 44px;
  background: #484946;
}

.datetime-current {
  position: absolute;
  left: 65px;
  top: 210px;
  width: 180px;
  height: 44px;
  border-radius: 8px;
  background: #484946;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

#object-hover-info-context {
  opacity: 1;
  pointer-events: all;
  position: absolute;
  display: block;
  text-decoration: none;
  left: 50%;
  top: 50%;
  width: 140px;
  min-height: 120px;
  box-sizing: border-box;
  z-index: 2;
  color: white;
  box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
  transition: 0.5s;
  -webkit-animation: bounce 0.5s 1 both;
  animation: bounce 0.5s 1 both;
  color: #484946;
  background: #ffffff;
  border: thin solid #d6d6dc;
  border-radius: 5px;
}
</style>
