<template>
  <div class="dea-chart-container">
    <div id="cy" />
  </div>
</template>

<script>
import cola from 'cytoscape-cola'
import compoundDragAndDrop from 'cytoscape-compound-drag-and-drop'
import cxtmenu from 'cytoscape-cxtmenu'
import cytoscape from 'cytoscape'
import dagre from 'cytoscape-dagre'

cytoscape.use(cola)
cytoscape.use(compoundDragAndDrop)
cytoscape.use(cxtmenu)
cytoscape.use(dagre)

export default {
  name: 'DeaCytoscape',
  props: {
    jsonDataFile: {
      type: String,
      required: true,
      default: ''
    },
    jsonStyleFile: {
      type: String,
      required: true,
      default: ''
    },
    layoutOpts: {
      type: Object,
      default: null
    },
    layoutSaves: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      edgeWeight: 5
    }
  },
  mounted() {
    this.init()
  },
  watch: {
    layoutOpts() {
      // console.log('watch')
      this.layoutChange(this.layoutOpts)
    }
  },
  methods: {
    init() {
      Promise.all([
        this.$api.private.get(this.jsonStyleFile).then((res) => {
          console.log(res)
          if (!res.data.length) {
            console.log('스타일정보가 없습니다!!')
            return
          }
          return res.data
        }),
        this.$api.analysis.get(this.jsonDataFile).then((res) => {
          let nodes = res.data.result.nodes
          let egdes = res.data.result.egdes
          let data = nodes.concat(egdes)
          if (!nodes.length) {
            console.log('노드정보가 없습니다!!')
            return
          }
          if (!egdes.length) {
            console.log('엣지정보가 없습니다!!')
            return
          }
          console.log(res)
          console.log(data)
          return data
        })
      ]).then((dataArray) => {
        // console.log(dataArray)
        this.reander(dataArray)
      })
    },
    reander(dataArray) {
      let cy = (window.cy = cytoscape({
        container: document.getElementById('cy'),
        style: dataArray[0],
        elements: dataArray[1],
        layout: { name: 'random' },
        wheelSensitivity: 0.5
      }))

      cy.cxtmenu({
        selector: 'node',
        commands: [
          {
            content: '인물정보',
            select: function(ele) {
              console.log('노드 선택됨', ele.data())
              cy.emit('person-info', [ele.data()])
            }
          }
        ]
      })

      cy.cxtmenu({
        selector: 'edge',
        commands: [
          {
            content: '통화통합내역',
            select: function(ele) {
              console.log('엣지 선택됨', ele.data())
              cy.emit('call-history-info', [ele.data()])
            }
          }
        ]
      })

      // cy.cxtmenu({
      //   selector: 'core',
      //   commands: [
      //     {
      //       content: 'bg1',
      //       select: function() {
      //         console.log('bg1')
      //       }
      //     },
      //     {
      //       content: 'bg2',
      //       select: function() {
      //         console.log('bg2')
      //       }
      //     }
      //   ]
      // })

      let layout = cy.makeLayout({
        name: 'random'
      })

      layout.run()

      cy.compoundDragAndDrop()

      cy.on('person-info', this.onPersonInfo)

      cy.on('call-history-info', this.onCallHistoryInfo)

      cy.on('layoutChange', function(e, opts) {
        layout.stop()

        if (opts.fn) {
          opts.fn()
        }

        layout = cy.makeLayout(opts)
        layout.run()
      })

      cy.on('layoutSave', () => {
        const date = new Date().toLocaleString()
        const elesData = cy.json()

        this.layoutSaves.push({ title: '수사관1', date: date, value: elesData })
      })

      cy.on('layoutLoad', (e, data) => {
        cy.add(data)
        edgeWidthStyleChange(data)
      })

      const edgeWidthStyleChange = (data) => {
        let nodeNum = data.filter((el) => (el.group = 'nodes')).length / 5
        console.log('>> 노드의 숫자', nodeNum)
        cy.style()
          // .resetToDefault()
          .selector('edge')
          .style('width', `mapData(weight, 0, 1, 1, ${nodeNum})`)
          .update()
      }
      // 최초 노드의 숫자로 edge width 값 변경.
      edgeWidthStyleChange(dataArray[1])

      cy.on('layoutSelectedNode', () => {
        let layout = cy
          .elements()
          .filter(':selected')
          .layout({
            name: 'grid',
            cols: 1
          })
        layout.run()
      })

      cy.on('selectedNodeLock', () => {
        cy.elements()
          .filter(':selected')
          .lock()
      })

      cy.on('removeData', () => {
        layout.stop()
        cy.elements().remove()
      })

      cy.on('fit', () => {
        cy.resize()
      })

      cy.on('center', (e, data) => {
        let nodes = cy.filter('node[name = "' + data + '"]')
        console.log(`노드찾기`, data, nodes)
        cy.zoom(3)
        cy.center(nodes)
      })
    },
    layoutChange(opts) {
      window.cy.trigger('fit')
      setTimeout(() => {
        window.cy.trigger('layoutChange', [opts])
      }, 300)
    },
    // 차트모양 저장
    layoutSave() {
      window.cy.trigger('layoutSave')
    },
    // 저장된 차트모양 로드
    layoutLoad(data) {
      window.cy.trigger('layoutLoad', [data])
    },
    // 노드를 종열로 만듬
    layoutSelectedNode() {
      window.cy.trigger('layoutSelectedNode')
    },
    // 선택된 노드 잠금
    selectedNodeLock() {
      window.cy.trigger('selectedNodeLock')
    },
    // 모드 노드 삭제
    removeData() {
      window.cy.trigger('removeData')
    },
    //인물정보 팝업 호출
    onPersonInfo(e, data) {
      console.log('인물정보', data)
      this.$emit('person-info', data)
    },
    // 통화내역조회 팝업 호출
    onCallHistoryInfo(e, data) {
      console.log('엣지정보', data)
      this.$emit('call-history-info', data)
    },
    // 노드를 중앙으로 이동
    center(data) {
      console.log('노드를 중앙으로 이동', data)
      window.cy.trigger('center', [data])
    }
  }
}
</script>

<style scoped>
#cy {
  width: 100%;
  height: 100%;
}
</style>
