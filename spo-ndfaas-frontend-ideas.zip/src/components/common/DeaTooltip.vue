<template>
  <!-- <v-layout> -->
  <v-tooltip :bottom="bottom" :top="top" :left="left" :right="right">
    <template v-slot:activator="{ on, attrs }">
      <slot name="activator" :attrs="attrs" :on="on"></slot>
    </template>
    <template v-if="content">
      <span>{{ content }}</span>
    </template>
    <template v-else>
      <slot name="content" v-if="$slots.content"></slot>
    </template>
  </v-tooltip>
  <!-- <v-layout> -->
</template>

<script>
export default {
  name: 'DeaTooltip',
  props: {
    bottom: {
      type: Boolean,
      default: false
    },
    top: {
      type: Boolean,
      default: false
    },
    left: {
      type: Boolean,
      default: false
    },
    right: {
      type: Boolean,
      default: false
    },
    content: {
      type: [String, Array, Object]
    }
  },
  mounted() {
    // console.log(this.$slots.content)
  }
}
</script>
