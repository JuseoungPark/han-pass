<template>
  <v-layout class="dea-time-picker">
    <v-col v-if="!text" class="d-flex flex-0">
      <v-autocomplete
        dense
        outlined
        v-model="localTime.hour"
        :items="hours"
        no-data-text="Invalid hour"
        @change="onChange"
      >
        <template v-slot:item="{ item }">
          <v-list-item-content class="dea-time-picker-content">
            <v-list-item-title>{{ item.text }}</v-list-item-title>
          </v-list-item-content>
        </template>
      </v-autocomplete>
      <span>:</span>
      <v-autocomplete
        dense
        outlined
        v-model="localTime.minute"
        :items="others"
        no-data-text="Invalid minutes"
        @change="onChange"
      >
        <template v-slot:item="{ item }">
          <v-list-item-content class="dea-time-picker-content">
            <v-list-item-title>{{ item.text }}</v-list-item-title>
          </v-list-item-content>
        </template>
      </v-autocomplete>
      <span>:</span>
      <v-autocomplete
        dense
        outlined
        v-model="localTime.second"
        :items="others"
        no-data-text="Invalid second"
        @change="onChange"
      >
        <template v-slot:item="{ item }">
          <v-list-item-content class="dea-time-picker-content">
            <v-list-item-title>{{ item.text }}</v-list-item-title>
          </v-list-item-content>
        </template>
      </v-autocomplete>
    </v-col>
    <v-col v-else class="d-flex flex-0">
      <dea-text-field
        :clearable="false"
        v-model="localTime.hour"
        :rules="[hourRules.required, otherRules.min, otherRules.max]"
        @change="onChange"
      ></dea-text-field>
      <span>:</span>
      <dea-text-field
        :clearable="false"
        v-model="localTime.minute"
        :rules="[hourRules.required, otherRules.min, otherRules.max]"
        @change="onChange"
      ></dea-text-field>
      <span>:</span>
      <dea-text-field
        :clearable="false"
        v-model="localTime.second"
        :rules="[hourRules.required, otherRules.min, otherRules.max]"
        @change="onChange"
      ></dea-text-field>
    </v-col>
  </v-layout>
</template>

<script>
import { StringUtils } from '@/utils/StringUtils'

export default {
  name: 'DeaTimePicker',
  components: {},
  props: {
    text: {
      type: Boolean,
      default: false
    },
    value: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      localTime: {
        hour: 0,
        minute: 0,
        second: 0
      },
      hours: [],
      others: [],
      hourRules: {
        required: (value) => !!value || 'Required.',
        min: (value) => (value && value >= 0) || 'Min 00',
        max: (value) => (value && value <= 23) || 'Max 23'
      },
      otherRules: {
        required: (value) => !!value || 'Required.',
        min: (value) => (value && value >= 0) || 'Min 00',
        max: (value) => (value && value <= 59) || 'Max 59'
      }
    }
  },
  computed: {
    timeString() {
      return (
        StringUtils.lPad(this.localTime.hour.toString(), 2, '0') +
        StringUtils.lPad(this.localTime.minute.toString(), 2, '0') +
        StringUtils.lPad(this.localTime.second.toString(), 2, '0')
      )
    }
  },
  methods: {
    initTime() {
      this.hours = Array.from({ length: 24 }, (v, k) => {
        return { text: StringUtils.lPad(k.toString(), 2, '0'), value: k }
      })

      this.others = Array.from({ length: 60 }, (v, k) => {
        return { text: StringUtils.lPad(k.toString(), 2, '0'), value: k }
      })
    },
    setCurrentTime() {
      let date = new Date()
      this.localTime = {
        hour: date.getHours(),
        minute: date.getMinutes(),
        second: date.getSeconds()
      }
      this.$emit('input', this.timeString)
    },
    onChange() {
      this.$emit('input', this.timeString)
    }
  },
  created() {
    this.initTime()
    this.setCurrentTime()
  }
}
</script>
