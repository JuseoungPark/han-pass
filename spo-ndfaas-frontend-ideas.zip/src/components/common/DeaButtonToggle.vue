<template>
  <v-btn-toggle
    dense
    :color="color"
    :class="[classes, textIndentAddClass]"
    :mandatory="mandatory"
    :textindent="textindent"
  >
    <dea-button
      v-for="item in items"
      :key="item.label"
      :prepend-icon="item.icon"
      :disabled="disabled"
      >{{ item.text }}</dea-button
    >
  </v-btn-toggle>
</template>

<script>
export default {
  name: 'DeaButtonToggle',
  components: {},
  props: {
    /**
     * Classes for button
     */
    classes: {
      type: String,
      default: undefined
    },
    /**
     * Applies specified color to the control
     */
    color: {
      type: String,
      default: undefined
    },
    disabled: {
      type: Boolean,
      default: false
    },
    mandatory: {
      type: String,
      default: undefined
    },
    items: {
      type: Array,
      default() {
        return []
      }
    },
    textindent: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    textIndentAddClass() {
      return { 'dea-btn--textindent': this.textindent }
    }
  }
}
</script>
