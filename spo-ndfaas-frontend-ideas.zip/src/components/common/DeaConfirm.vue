<template>
  <!-- 시스템 팝업 : System Popup -->
  <dea-dialog v-model="isShow" width="320px" class-prop="dea-dialog dea-alert">
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <template v-if="message">
                <div class="text" v-html="message"></div>
              </template>
              <template v-else>
                <slot name="message"> </slot>
              </template>
            </v-col>
          </v-row>
          <div class="btn-group">
            <v-col class="align-center">
              <template v-if="$slots.actions">
                <slot name="actions"> </slot>
              </template>
              <template v-else>
                <template v-if="alert">
                  <dea-button outlined @click="isShow = !isShow"
                    >확인</dea-button
                  >
                </template>
                <template v-else>
                  <dea-button outlined @click="doCancle">아니오</dea-button>
                  <dea-button color="primary" @click="doOK">예</dea-button>
                </template>
              </template>
            </v-col>
          </div>
        </dea-card>
      </div>
    </section>
  </dea-dialog>
</template>

<script>
export default {
  name: 'DeaConfirm',
  props: {
    value: {
      type: Boolean,
      default: false
    },
    alert: {
      type: Boolean,
      default: false
    },
    message: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      isShow: false
    }
  },
  watch: {
    value(flag) {
      this.isShow = flag
    },
    isShow(flag) {
      this.$emit('input', flag)
    }
  },
  methods: {
    doCancle() {
      this.$emit('doCancle')
      this.isShow = false
    },
    doOK() {
      this.$emit('doOK')
      this.isShow = false
    }
  },
  mounted() {
    this.isShow = this.value
  }
}
</script>
