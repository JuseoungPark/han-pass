<template>
  <!-- 시스템 팝업 : System Popup -->
  <dea-dialog v-model="isShow" width="320px" class-prop="dea-dialog dea-alert">
    <section class="dea-section">
      <div class="inner">
        <dea-card>
          <v-row no-gutters>
            <v-col class="d-flex align-center">
              <div class="text" v-html="message"></div>
            </v-col>
          </v-row>
          <div class="btn-group">
            <v-col class="align-center">
              <template v-if="alert">
                <dea-button outlined @click="doOK">확인</dea-button>
              </template>
              <template v-else>
                <dea-button outlined @click="doCancle">아니오</dea-button>
                <dea-button color="primary" @click="doOK">예</dea-button>
              </template>
            </v-col>
          </div>
        </dea-card>
      </div>
    </section>
  </dea-dialog>
</template>

<script>
/**
 * Common Confirm component.
 *
 * ex>
 * this.$alert('alert message')
 *
 * this.$alert('alert message').then(() => {
 *   console.log('this message will be showed after closing alert popup')
 * })
 *
 * this.$confirm('confirm message').then((confirm) => {
 *   if (confirm) console.log('click ok')
 *   else console.log('click')
 * })
 * @displayName DeaConfirmCommon
 */
export default {
  name: 'DeaConfirmCommon',
  data() {
    return {
      isShow: false,
      alert: false,
      message: '',
      onConfirm: {}
    }
  },
  beforeMount() {
    this.$eventBus.$on('confirm', (options, resolve) => {
      this.show(options, resolve)
    })
  },
  methods: {
    show(options, resolve) {
      this.message = options.message
      this.alert = options.alert

      this.onConfirm = resolve
      this.isShow = true
    },
    doCancle() {
      if (typeof this.onConfirm === 'function') this.onConfirm(false)
      this.isShow = false
    },
    doOK() {
      if (typeof this.onConfirm === 'function') this.onConfirm(true)
      this.isShow = false
    }
  }
}
</script>
