<template>
  <div>
    <v-tabs
      v-model="tabValue"
      class="dea-tabs"
      v-if="tabLoading"
      @change="tabsChanged"
    >
      <template v-for="(tabItem, index) in tabItems">
        <template v-if="tabItem.tooltip">
          <v-tooltip top :key="index">
            <template v-slot:activator="{ on, attrs }">
              <v-tab v-bind="attrs" v-on="on">
                {{ tabItem.name }}
              </v-tab>
            </template>
            <span>{{ tabItem.tooltip }}</span>
          </v-tooltip>
        </template>
        <template v-else>
          <v-tab :key="index">
            {{ tabItem.name }}
          </v-tab>
        </template>
      </template>
    </v-tabs>
    <v-tabs-items>
      <template v-if="tabItems[tabValue].hasOwnProperty('content')">
        {{ tabItems[tabValue].content }}
      </template>
      <template v-else>
        <slot></slot>
      </template>
    </v-tabs-items>
  </div>
</template>

<script>
/**
 * Tab component.
 * @displayName DeaTab
 */
export default {
  name: 'DeaTab',
  props: {
    tabItems: {
      type: Array,
      default: () => {
        return [
          /* {name: 'name', tooltip: 'tooltip content'} */
        ]
      }
    },
    // 부모에서 보내준 값
    value: {
      type: Number,
      default: 0
    }
  },
  updated() {
    if (this.tabItems.length > 0) this.tabLoading = true
  },
  watch: {
    tabValue(index) {
      this.$emit('input', index)
    },
    tabItems() {
      this.tabLoading = false
    }
  },
  data() {
    return {
      tabLoading: false,
      tabValue: 0
    }
  },
  methods: {
    tabsChanged() {
      this.$emit('change')
    }
  },
  mounted() {
    if (this.tabItems.length > 0) this.tabLoading = true
    if (this.value) this.tabValue = this.value
  }
}
</script>
