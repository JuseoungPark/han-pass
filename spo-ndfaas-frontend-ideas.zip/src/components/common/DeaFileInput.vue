<template>
  <v-file-input
    dense
    outlined
    :append-outer-icon="appendOuterIcon"
    :counter="counter"
    :label="label"
    :multiple="multiple"
    :placeholder="placeholder"
    :prepend-icon="prependIcon"
    :show-size="showSize"
    :single-line="singleLine"
    v-model="files"
    @click="onClick"
  >
    <template v-slot:selection="{ index, text }">
      <v-chip v-if="index < 2" small>
        {{ text }}
        <v-icon class="ml-1" @click="removeFile(index)">
          mdi-close
        </v-icon>
      </v-chip>
      <span v-else-if="index === 2" class="caption">
        (+{{ files.length - 2 }} Files)
      </span>
    </template>
  </v-file-input>
</template>

<script>
/**
 * File input component.
 * @displayName DeaFileInput
 */
export default {
  name: 'DeaFileInput',
  props: {
    /**
     * Appends an icon to the outside the component’s input, uses same syntax as v-icon
     */
    appendOuterIcon: {
      type: String,
      default: undefined
    },
    /**
     * Creates counter for input length; if no number is specified, it defaults to 25. Does not apply any validation.
     */
    counter: {
      type: [Boolean, Number, String],
      default: undefined
    },
    /**
     * Sets input label
     */
    label: {
      type: String,
      default: undefined
    },
    /**
     * Adds the multiple attribute to the input, allowing multiple file selections.
     */
    multiple: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * Prepends an icon to the component, uses the same syntax as v-icon
     */
    prependIcon: {
      type: String,
      default: undefined
    },
    /**
     * Sets the displayed size of selected file(s). When using true will default to 1000 displaying (kB, MB, GB) while 1024 will display (KiB, MiB, GiB).
     */
    showSize: {
      type: [Boolean, Number],
      default: false
    },
    /**
     * Label does not move on focus/dirty
     */
    singleLine: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      files: [],
      remove: false
    }
  },
  methods: {
    removeFile(index) {
      this.remove = true
      this.files.splice(index, 1)
    },
    onClick(event) {
      if (this.remove) {
        event.preventDefault()
        this.remove = false
      }
    }
  }
}
</script>
