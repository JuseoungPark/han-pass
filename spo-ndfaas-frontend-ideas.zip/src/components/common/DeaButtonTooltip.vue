<template>
  <div>
    <template v-if="tooltip">
      <dea-tooltip :content="tooltip" bottom>
        <v-btn
          :class="classes"
          :dark="dark"
          :disabled="disabled"
          :color="color"
          :fab="fab"
          :icon="icon"
          :outlined="outlined"
          :text="text"
          :depressed="depressed"
          @click="onClick"
        >
          <v-icon v-if="prependIcon" :dark="dark">{{ prependIcon }}</v-icon>
          <!-- @slot Use this slot default -->
          <slot></slot>
          <v-icon v-if="appendIcon" :dark="dark">{{ appendIcon }}</v-icon>
          <!-- @slot Use this slot default -->
        </v-btn>
      </dea-tooltip>
    </template>
    <template v-else>
      <v-btn
        :class="classes"
        :dark="dark"
        :disabled="disabled"
        :color="color"
        :fab="fab"
        :icon="icon"
        :outlined="outlined"
        :text="text"
        :depressed="depressed"
        @click="onClick"
      >
        <v-icon v-if="prependIcon" :dark="dark">{{ prependIcon }}</v-icon>
        <!-- @slot Use this slot default -->
        <slot></slot>
        <v-icon v-if="appendIcon" :dark="dark">{{ appendIcon }}</v-icon>
        <!-- @slot Use this slot default -->
      </v-btn>
    </template>
  </div>
</template>

<script>
/**
 * Button component.
 * @displayName DeaButton
 */
export default {
  name: 'DeaButton',
  props: {
    /**
     * icon name after label
     */
    appendIcon: {
      type: String,
      default: undefined
    },
    /**
     * Applies the dark theme variant to the component. You can find more information on the Material Design documentation for dark themes.
     */
    dark: {
      type: Boolean,
      default: undefined
    },
    /**
     * Removes the ability to click or target the component.
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * Applies specified color to the control
     */
    color: {
      type: String,
      default: undefined
    },
    /**
     * Designates the button as a floating-action-button - round.
     */
    fab: {
      type: Boolean,
      default: false
    },
    /**
     * Designates the button as icon - round and flat
     */
    icon: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the background transparent and applies a thin border.
     */
    outlined: {
      type: Boolean,
      default: false
    },
    /**
     * icon name before label
     */
    prependIcon: {
      type: String,
      default: undefined
    },
    /**
     * Makes the background transparent.
     */
    text: {
      type: Boolean,
      default: false
    },
    /**
     * Removes the button box shadow.
     */
    depressed: {
      type: Boolean,
      default: true
    },
    tooltip: {
      type: String,
      default: ''
    },
    bottom: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    classes() {
      return {
        'white--bg': this.outlined
      }
    }
  },
  methods: {
    /**
     * Gets called when the user clicks on the button
     */
    onClick() {
      this.$emit('click')
    }
  }
}
</script>
