<template>
  <v-menu close-on-click close-on-content-click offset-y>
    <template v-slot:activator="{ on }">
      <div class="dea-color-picker" :style="swatchStyle" v-on="on" />
    </template>
    <!-- 칼라픽커 : Layer Popup -->
    <v-sheet class="dea-popup">
      <v-container class="pa-4">
        <section class="dea-section">
          <div class="inner">
            <dea-card>
              <v-row justify="space-around">
                <v-color-picker
                  v-model="color"
                  class="ma-2"
                  show-swatches
                ></v-color-picker>
              </v-row>
            </dea-card>
          </div>
        </section>
      </v-container>
    </v-sheet>
    <!-- //칼라픽커 : Layer Popup -->
  </v-menu>
</template>

<script>
export default {
  name: 'colorPicker',
  props: {
    value: {
      type: String,
      default: '#1976d2ff'
    }
  },
  data() {
    return {
      color: '#1976d2ff'
    }
  },
  watch: {
    color(value) {
      this.$emit('input', value)
    }
  },
  computed: {
    swatchStyle() {
      return {
        backgroundColor: this.color,
        cursor: 'pointer',
        height: '32px',
        width: '32px'
      }
    }
  },
  created() {
    this.color = this.value
  }
}
</script>
<style>
.dea-app .dea-color-picker {
  border: 1px solid #c1c1c7;
}
</style>
