<template>
  <v-radio-group
    v-model="localValue"
    :disabled="disabled"
    :mandatory="mandatory"
    :readonly="readonly"
    :row="row"
    @change="onChange"
  >
    <v-radio
      v-for="item in items"
      :key="item.label"
      :label="item.label"
      :value="item.value"
    ></v-radio>
  </v-radio-group>
</template>

<script>
export default {
  name: 'DeaRadioGroup',
  props: {
    /**
     * Disable the input
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * Forces a value to always be selected (if available).
     */
    mandatory: {
      type: Boolean,
      default: false
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    /**
     * Displays radio buttons in row
     */
    row: {
      type: Boolean,
      default: false
    },
    items: {
      type: Array,
      default() {
        return []
      }
    },
    /**
     * The input’s value
     */
    value: {
      default: undefined
    }
  },
  data() {
    return {
      localValue: undefined
    }
  },
  watch: {
    value: function(value) {
      this.localValue = value
    }
  },
  methods: {
    onChange(value) {
      this.$emit('input', value)
      this.$emit('change', value)
    }
  },
  created() {
    this.localValue = this.value
  }
}
</script>
