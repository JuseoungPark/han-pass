<template>
  <v-switch
    v-model="localValue"
    :disabled="disabled"
    :input-value="inputValue"
    :inset="inset"
    :label="label"
    :readonly="readonly"
  ></v-switch>
</template>

<script>
export default {
  name: 'DeaSwitch',
  props: {
    /**
     * Disable the input
     */
    disabled: {
      type: Boolean,
      default: undefined
    },
    /**
     * The v-model bound value
     */
    inputValue: {
      default: undefined
    },
    /**
     * Enlarge the v-switch track to encompass the thumb
     */
    inset: {
      type: Boolean,
      default: undefined
    },
    /**
     * Sets input label
     */
    label: {
      type: String,
      default: undefined
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    /**
     * The input’s value
     */
    value: {
      default: undefined
    }
  },
  data() {
    return {
      localValue: undefined
    }
  },
  methods: {},
  created() {
    if (this.inputValue) this.localValue = this.inputValue
    else this.localValue = this.value
  }
}
</script>
