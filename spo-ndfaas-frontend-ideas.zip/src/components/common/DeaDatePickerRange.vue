<template>
  <v-menu
    ref="menu"
    v-model="menu"
    content-class="dea-date-picker-content"
    :close-on-content-click="closeOnContentClick"
    min-width="290px"
    :offset-y="offsetY"
    :transition="transition"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-layout class="dea-date-picker">
        <v-text-field
          v-model="txtDate"
          dense
          outlined
          :label="label"
          :rules="txtDateRules"
          :class="classes"
          :placeholder="placeholder"
          :style="styles"
          v-bind="attrs"
          @change="onChangeTxtDate"
        ></v-text-field>
        <v-btn text class="dea-btn--textindent">
          <v-icon v-on="on">mdi-calendar-month</v-icon>
          달력
        </v-btn>
      </v-layout>
    </template>
    <v-layout style="width: 600px">
      <v-row no-gutters>
        <v-col class="d-flex">
          <v-date-picker
            ref="startDatePicker"
            full-width
            v-model="localDateReverse"
            :locale="locale"
            :day-format="getDate"
            no-title
            scrollable
            range
            @input="onInputStartDate"
          ></v-date-picker>
          <v-date-picker
            ref="endDatePicker"
            full-width
            v-model="localDate"
            :locale="locale"
            :day-format="getDate"
            no-title
            scrollable
            range
            @input="onInputEndDate"
          ></v-date-picker>
        </v-col>
      </v-row>
    </v-layout>
  </v-menu>
</template>

<script>
export default {
  name: 'DeaDatePickerRange',
  props: {
    /**
     * Classes for text field
     */
    classes: {
      type: String,
      default: undefined
    },
    /**
     * Designates if menu should close when its content is clicked
     */
    closeOnContentClick: {
      type: Boolean,
      default: true
    },
    label: {
      type: String,
      default: undefined
    },
    /**
     * Offset the menu on the y-axis. Works in conjunction with direction top/bottom
     */
    offsetY: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * The value that is updated when the menu is closed - must be primitive. Dot notation is supported
     */
    returnValue: {
      default: undefined
    },
    styles: {
      type: String,
      default: undefined
    },
    /**
     * Sets the component transition. Can be one of the built in transitions or one your own.
     */
    transition: {
      type: [Boolean, String],
      default: 'v-menu-transition'
    },
    value: {
      default: null
    }
  },
  data() {
    return {
      menu: false,
      startDate: '',
      endDate: '',
      localDate: [],
      txtDate: '',
      txtDateRules: [
        (v) => !!v || 'Date is required',
        (v) =>
          //this.matchFormatTxtDate(v) || 'Date is invalid'
          /(^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01]) ~ \d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01]))$/.test(
            v
          ) || 'Date is invalid'
      ]
    }
  },
  computed: {
    localDateReverse: {
      get: function() {
        return [this.localDate[1], this.localDate[0]]
      },
      set: function() {}
    },
    locale() {
      return process.env.VUE_APP_I18N_LOCALE || 'kr'
    }
  },
  watch: {
    value(val) {
      this.setDate(val)
    }
  },
  created() {
    if (this.value && Array.isArray(this.value) && this.value.length == 2) {
      this.setDate(this.value)
    } else {
      // this.initDate()
    }
  },
  methods: {
    matchFormatTxtDate(value) {
      return value.match(
        /(^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01]) ~ \d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01]))$/
      )
    },
    onChangeTxtDate(value) {
      if (this.matchFormatTxtDate(value)) {
        this.setDate(value.split(' ~ '))
        this.$emit('input', this.localDate)
      } else {
        this.syncDate()
      }
    },
    getDate(date) {
      return new Date(date).getDate()
    },
    initDate() {
      this.startDate = new Date().toISOString().substr(0, 10)
      this.endDate = new Date().toISOString().substr(0, 10)
      this.syncDate()
    },
    setDate(date) {
      this.startDate = date[0]
      this.endDate = date[1]
      this.syncDate()
    },
    syncDate() {
      this.localDate = [this.startDate, this.endDate]
      this.txtDate = this.localDate.join(' ~ ')
      if (this.$refs.startDatePicker)
        this.$refs.startDatePicker.tableDate = this.startDate.substr(0, 7)
      if (this.$refs.endDatePicker)
        this.$refs.endDatePicker.tableDate = this.endDate.substr(0, 7)
    },
    onInputStartDate(value) {
      let date = value.length == 2 ? value[1] : value[0]

      if (date > this.endDate) {
        this.$alert('종료 날짜보다 작은 날짜를 선택해야합니다')
      } else {
        this.startDate = date
      }
      this.syncDate()
      this.$emit('input', this.localDate)
    },
    onInputEndDate(value) {
      let date = value.length == 2 ? value[1] : value[0]

      if (date < this.startDate) {
        this.$alert('시작 날짜보다 큰 날짜를 선택해야합니다')
      } else {
        this.endDate = date
      }
      this.syncDate()
      this.$emit('input', this.localDate)
    }
  }
}
</script>
