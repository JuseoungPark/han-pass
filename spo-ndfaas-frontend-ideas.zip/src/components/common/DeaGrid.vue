<template>
  <dea-card class="grid-wrap">
    <v-row no-gutters class="grid-top">
      <v-col v-if="$scopedSlots['header-left']" class="d-flex align-left">
        <!-- @slot Use this slot header-left -->
        <slot name="header-left"></slot>
      </v-col>
      <v-col
        v-if="$scopedSlots['header-right']"
        class="d-flex align-right flex-0"
      >
        <!-- @slot Use this slot header-left -->
        <slot name="header-right"></slot>
      </v-col>
      <v-col class="d-flex align-right flex-0">
        <!-- <div> -->
        <dea-button
          v-if="config.excelButton"
          icon
          textindent
          fab
          prepend-icon="mdi-file-excel-outline"
          title="엑셀다운로드"
          @click="doExcelDownload"
        >
          엑셀다운로드
        </dea-button>
        <!-- </div> -->
        <dea-select
          v-if="config.pagination.limitView"
          label="테이블 열"
          class="flex-0"
          style="width:120px"
          v-model="pagination.limit"
          :items="selectLimitItems"
          @change="onChangeLimit"
        ></dea-select>
      </v-col>
    </v-row>
    <ag-grid-vue
      v-resize="sizeToFit"
      :class="gridTheme"
      :gridOptions="gridOptions"
      :rowData="rowData"
      :columnDefs="columnDefs"
      :modules="modules"
      :context="context"
      :return-value.sync="pagination.total"
      @grid-ready="onReady"
      @contextmenu.prevent.native="onContextMenu"
      :style="setHeight"
    >
    </ag-grid-vue>
    <div v-if="usePagination" :class="gridPaginationTheme">
      <v-row no-gutters>
        <v-col class="d-flex align-left flex-0" style="width:150px;">
          <div class="text font-bold">{{ gridPagination.start }}</div>
          <div class="text">to</div>
          <div class="text font-bold">{{ gridPagination.end }}</div>
          <div class="text">of</div>
          <div class="text font-bold">{{ gridPagination.total }}</div>
        </v-col>
        <v-col class="d-flex align-center">
          <v-pagination
            v-model="pagination.page"
            :length="pagination.totalPage"
            :total-visible="pagination.visiblePage"
            @input="loadData"
            @next="loadData"
            @previous="loadData"
          ></v-pagination>
        </v-col>
        <v-col class="d-flex align-right flex-0" style="width:150px;">
          <!-- <dea-select
            class="flex-0"
            style="width:120px"
            v-model="pagination.limit"
            :items="selectLimitItems"
            @change="onChangeLimit"
          ></dea-select> -->
        </v-col>
      </v-row>
    </div>
    <v-menu
      v-model="showMenu"
      :position-x="x"
      :position-y="y"
      :close-on-content-click="false"
      absolute
      offset-y
    >
      <v-list>
        <v-list-item-group v-model="showColumns" multiple>
          <template v-for="column in allColumns">
            <v-list-item
              :key="column.value"
              :value="column.value"
              @change="onChangeColumnState(column.value)"
            >
              <template v-slot:default="{ active }">
                <v-list-item-action class="mt-0 mb-0">
                  <v-checkbox :input-value="active"></v-checkbox>
                </v-list-item-action>
                <v-list-item-content>
                  <v-list-item-title v-text="column.text"></v-list-item-title>
                </v-list-item-content>
              </template>
            </v-list-item>
          </template>
        </v-list-item-group>
      </v-list>
    </v-menu>
    <dea-confirm v-model="excelConfirm.show">
      <template slot="message">
        다운로드할 파일의 범위를 선택해주세요
      </template>
      <template slot="actions">
        <dea-button color="primary" @click="excelConfirm.allDownload"
          >목록 전체</dea-button
        >
        <dea-button color="primary" @click="excelConfirm.curDownload"
          >현재 페이지</dea-button
        >
        <dea-button
          outlined
          @click="excelConfirm.cancel"
          v-if="rowSelectionMultiple"
          >다시 선택</dea-button
        >
        <dea-button outlined @click="excelConfirm.cancel" v-else
          >취소</dea-button
        >
      </template>
    </dea-confirm>
  </dea-card>
</template>

<script>
import 'ag-grid-community/dist/styles/ag-grid.css'
import 'ag-grid-community/dist/styles/ag-theme-alpine.css'
import 'ag-grid-community/dist/styles/ag-theme-alpine-dark.css'
import { AgGridVue } from 'ag-grid-vue'
import '@/utils/StringUtils'
import { NumberUtils } from '@/utils/NumberUtils'
import apiMixin from '@/mixins/apiMixin'

export default {
  name: 'DeaGrid',
  components: { AgGridVue },
  mixins: [apiMixin],
  props: {
    async: {
      type: Boolean,
      default: false
    },
    columns: {
      default: () => {
        return []
      }
    },
    disableAutoLoad: {
      type: Boolean,
      default: false
    },
    rowSelectionMultiple: {
      type: Boolean,
      default: false
    },
    suppressRowClickSelection: {
      type: Boolean,
      default: false
    },
    config: {
      type: Object,
      default: () => {
        return {
          excelButton: true,
          pagination: {
            limitView: true,
            limit: 20
          },
          height: 'auto' // fixed, auto, 픽셀값
        }
      }
    },
    etcOptions: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      loading: null,
      rowData: [],
      gridApi: null,
      gridColumnApi: null,
      modules: null,
      context: { componentParent: this },
      gridColumns: [],
      selectLimitItems: [
        { text: '20개씩 보기', value: 20 },
        { text: '50개씩 보기', value: 50 },
        { text: '100개씩 보기', value: 100 }
      ],
      showMenu: false,
      x: 0,
      y: 0,
      gridHeight: null,
      excelConfirm: {
        show: false,
        allDownload: () => {
          this.executeExcelDownload(true)
          this.excelConfirm.show = false
        },
        curDownload: () => {
          this.executeExcelDownload(false)
          this.excelConfirm.show = false
        },
        cancel: () => {
          this.excelConfirm.show = false
        }
      }
    }
  },
  computed: {
    columnDefs() {
      return this.gridColumns
    },
    isGroupColumn() {
      let flag = false
      if (this.gridColumns.length > 0) {
        if (this.gridColumns[0].children) {
          flag = true
        } else {
          flag = false
        }
      }
      return flag
    },
    setHeight() {
      if (this.gridHeight === null) {
        return false
      } else {
        return `height:${this.gridHeight}px`
      }
    },
    gridOptions() {
      return {
        defaultColDef: {
          width: 100,
          resizable: true
        },
        headerHeight: 40,
        suppressRowClickSelection: this.suppressRowClickSelection,
        rowSelection: this.rowSelectionMultiple ? 'multiple' : 'single',
        onCellClicked: this.onCellClicked,
        onDisplayedColumnsChanged: this.onDisplayedColumnsChanged,
        onGridSizeChanged: this.onGridSizeChanged,
        onSortChanged: this.onSortChanged,
        overlayNoRowsTemplate:
          '<span class="ag-overlay-loading-center">데이터가 없습니다.</span>',
        debug: false,
        enableBrowserTooltips: true,
        icons: {
          sortUnSort:
            '<div class="ag-header-icon--textindent"><i class="ag-icon ag-icon-none"></i>정렬</div>',
          sortAscending:
            '<div class="ag-header-icon--textindent"><i class="ag-icon ag-icon-asc"></i>오름차순</div>',
          sortDescending:
            '<div class="ag-header-icon--textindent"><i class="ag-icon ag-icon-desc"></i>내림차순</div>'
        },
        ...this.etcOptions
      }
    },
    showColumns: {
      get: function() {
        if (this.gridColumnApi) {
          return Array.from(
            this.gridColumnApi.getAllDisplayedColumns(),
            (e) => {
              return e.colId
            }
          )
        }

        return []
      },
      set: function() {}
    },
    allColumns() {
      if (this.gridColumnApi) {
        let text
        return Array.from(this.gridColumnApi.getAllColumns(), (e) => {
          text = e.colDef.headerName
          if (
            e.parent &&
            e.parent.originalColumnGroup.colGroupDef.headerName !== ''
          ) {
            text = text.replace(
              /^/,
              e.parent.originalColumnGroup.colGroupDef.headerName + ' - '
            )
          }
          return {
            value: e.colId,
            text: text,
            visible: e.visible
          }
        })
      }
      return []
    },
    gridPagination() {
      return {
        start: NumberUtils.numberWithCommas(this.pagination.start),
        end: NumberUtils.numberWithCommas(this.pagination.end),
        total: NumberUtils.numberWithCommas(this.pagination.total)
      }
    },
    gridTheme() {
      return this.$vuetify.theme.dark
        ? 'ag-theme-alpine-dark'
        : 'ag-theme-alpine'
    },
    gridPaginationTheme() {
      return this.$vuetify.theme.dark
        ? 'dea-ag-grid-pagination-dark'
        : 'dea-ag-grid-pagination'
    }
  },
  created() {
    this.pagination.limit = this.config.pagination.limit
  },
  /*watch: {
    gridApi(api) {
      console.log('==================== watch gridApi', api)
    }
  },*/
  methods: {
    onReady(params) {
      this.gridApi = params.api
      // console.log('==================== onReady gridApi', this.gridApi)
      this.gridColumnApi = params.columnApi
      this.gridColumns = this.columns
      this.getHeight()
      this.sizeToFit()
      if (this.disableAutoLoad) {
        this.$emit('ready')
      } else {
        this.loadData()
      }
    },
    hideOverlay() {
      if (this.gridApi) this.gridApi.hideOverlay()
    },
    async loadData() {
      // console.log('==================== loadData gridApi', this.gridApi)
      if (this.api.length > 0) {
        if (this.gridApi) this.gridApi.hideOverlay()
        // this.gridApi.hideOverlay()
        // this.rowData = null
        this.$nextTick(() => {
          if (this.async) this.loadDataAsync()
          else this.loadDataSync()
        })
      }
    },
    loadDataAsync() {
      this.showLoading(true)
      this.requestApiAsync((res) => {
        this.setResultData(res)
      })
    },
    async loadDataSync() {
      this.showLoading(true)
      const res = await this.requestApiSync()
      this.setResultData(res)
    },
    setResultData(res) {
      // console.log('==================== setResultData', res)
      if (res.data) {
        if (this.apiType === 'analysis') {
          if (res.data.result.length > 0) {
            this.rowData = res.data.result
            this.pagination.total = this.rowData.length
          }
          if (res.data.result.data) {
            this.rowData = res.data.result.data
          } else {
            this.rowData = []
          }
        } else if (this.apiType === 'incident') {
          this.rowData = res.data
        } else {
          this.rowData = res.data.rows
        }
        this.$emit('update:return-value', this.pagination.total)
      } else {
        if (res.error) this.$toast.error(`${res.error}`)
        this.rowData = []
        this.$emit('update:return-value', 0)
      }
      this.setDataAfter()
    },
    setRowData(rows) {
      this.rowData = rows
      this.pagination.total = this.rowData ? this.rowData.length : 0
      this.$emit('update:return-value', this.pagination.total)
      this.setDataAfter()
    },
    setDataAfter() {
      this.showLoading(false)
      if (this.pagination.total === 0) {
        this.gridApi.showNoRowsOverlay()
      }
      this.getHeight()
      this.sizeToFit()
    },
    getHeight() {
      if (!this.gridApi) return
      this.gridHeight = null
      if (this.config.height === 'fixed') {
        let headerHight =
          this.gridApi.getSizesForCurrentTheme().headerHeight + 3
        if (this.isGroupColumn) headerHight += 48
        let minRowHeight = this.gridApi.getSizesForCurrentTheme().rowHeight
        this.gridApi.setDomLayout('normal')
        if (this.usePagination) {
          this.gridHeight = headerHight + minRowHeight * this.pagination.limit
        } else {
          this.gridHeight = headerHight + minRowHeight * this.pagination.limit
        }
      } else if (
        typeof this.config.height === 'number' &&
        this.config.height > 0
      ) {
        this.gridApi.setDomLayout('normal')
        this.gridHeight = this.config.height
      } else {
        this.gridApi.setDomLayout('autoHeight')
      }
    },
    getSelectedRowData() {
      let selectedNodes = this.gridApi.getSelectedNodes()
      // let selectedData = selectedNodes.map((node) => node.data)
      return selectedNodes
    },
    showLoading(flag) {
      if (this.gridApi) {
        if (flag) {
          // this.gridApi.showLoadingOverlay()
          this.gridApi.hideOverlay()
          this.loading = this.$loading.show()
        } else {
          // this.gridApi.hideOverlay()
          this.loading = null
        }
      }
    },
    sizeToFit() {
      if (this.gridApi) this.gridApi.sizeColumnsToFit()
    },
    pageGotoFirst() {
      if (this.pagination.page == 1) return

      this.pagination.page = 1
      this.loadData()
    },
    pageGotoLast() {
      if (
        !this.pagination.total ||
        this.pagination.page == this.pagination.totalPage
      )
        return

      this.pagination.page = this.pagination.totalPage
      this.loadData()
    },
    pageGotoPrev() {
      if (this.pagination.page == 1) return

      this.pagination.page = this.pagination.page - 1
      this.loadData()
    },
    pageGotoNext() {
      if (
        !this.pagination.total ||
        this.pagination.page == this.pagination.totalPage
      )
        return

      this.pagination.page = this.pagination.page + 1
      this.loadData()
    },
    setColumns(columns) {
      this.gridColumns = columns
    },
    onCellClicked(params) {
      this.$emit('cellClicked', params)
    },
    onDisplayedColumnsChanged() {
      this.sizeToFit()
    },
    onChangeLimit() {
      this.loadData()
    },
    onContextMenu(e) {
      let isColumnHeader = false
      event.target.classList.forEach((element) => {
        if (element.includes('ag-header')) {
          isColumnHeader = true
          return false
        }
      })
      if (isColumnHeader) {
        e.preventDefault()
        this.showMenu = false
        this.x = e.clientX
        this.y = e.clientY
        this.$nextTick(() => {
          this.showMenu = true
        })
      }
    },
    onChangeColumnState(colId) {
      var value = this.gridColumnApi
        .getAllDisplayedColumns()
        .some((e) => e.colId === colId)

      this.gridColumnApi.setColumnVisible(colId, !value)
    },
    setVisiblePage(visiblePage) {
      this.pagination.visiblePage = visiblePage
    },
    onGridSizeChanged() {
      // this.sizeToFit()
    },
    onCellButtonClicked(params) {
      this.$emit('cellButtonClicked', params)
    },
    onCellSelectChange(params, selected) {
      this.$emit('cellSelectChange', params, selected)
    },
    onRowsTextChange(params, selected) {
      this.$emit('onRowsTextChange', params, selected)
    },
    onSortChanged() {
      var columnState = this.gridColumnApi.getColumnState()
      var sortState = columnState.filter((e) => e.sort)
      if (sortState.length == 0) this.order = ''
      else {
        let column = this.gridColumnApi.getColumn(sortState[0].colId)
        if (this.apiType === 'analysis') {
          this.order = 'orderBy={0}&sortType={1}'.format(
            column.colDef.field,
            sortState[0].sort
          )
        } else {
          this.order = 'order=' + column.colDef.field + ' ' + sortState[0].sort
        }
      }
      this.resetPagination()
      this.loadData()
    },
    resetColumnState() {
      if (this.gridColumnApi) this.gridColumnApi.resetColumnState()
    },
    reset() {
      this.resetPagination()
      this.resetOrder()
      this.resetColumnState()
    },
    dataReset() {
      this.reset()
      this.rowData = []
    },
    getSelectedRows() {
      return this.gridApi.getSelectedRows()
    },
    s2ab: function(s) {
      var buf = new ArrayBuffer(s.length) //convert s to arrayBuffer
      var view = new Uint8Array(buf) //create uint8array as viewer
      for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xff //convert to octet
      return buf
    },
    doExcelDownload() {
      if (this.getSelectedRows().length > 0) {
        let data = {
          url: this.uri,
          rows: this.getSelectedRows()
        }
        this.executeExcelDownload(false, data)
      } else {
        this.excelConfirm.show = true
      }
    },
    executeExcelDownload(isAll, data = undefined) {
      this.$api[this.apiType]({
        url:
          (data === undefined ? this.uri : '/api/excel') +
          (isAll ? (this.uri.includes('?') ? '&excel=all' : '?excel=all') : ''),
        method: data === undefined ? 'GET' : 'POST',
        data: data !== undefined ? data : '',
        responseType: 'blob',
        headers: {
          Accept: 'application/vnd.openxmlformats'
        }
      }).then((res) => {
        let disposition = res.headers['content-disposition']
        if (disposition.includes('filename')) {
          var fileURL = window.URL.createObjectURL(new Blob([res.data]))
          var fileLink = document.createElement('a')

          fileLink.href = fileURL
          fileLink.setAttribute(
            'download',
            disposition.split('=')[1] || 'response.xlsx'
          )
          document.body.appendChild(fileLink)

          fileLink.click()

          this.$toast(`엑셀이 다운로드 되었습니다.`)
        } else {
          this.$toast(
            `다운로드가 예약되었습니다. 파일저장관리에서 확인해주세요.`
          )
          console.log(
            'file url is ' + disposition.split('=')[1] || 'response.xlsx'
          )
        }
      })
    },
    loadPreviousPageIfEmptyData() {
      if (
        this.pagination.page > this.pagination.totalPage &&
        this.pagination.page > 1
      ) {
        this.pagination.page = this.pagination.page - 1
        this.loadDataAsync()
      }
    }
  }
}
</script>
