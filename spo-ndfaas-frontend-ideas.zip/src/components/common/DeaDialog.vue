<template>
  <v-container>
    <v-dialog
      v-model="isShow"
      :width="width"
      :content-class="classProp"
      :persistent="persistent"
      scrollable
    >
      <v-card>
        <v-card-title>
          <v-layout class="page-header-slot flex-0 pr-4">
            {{ title }}
          </v-layout>
          <v-layout v-if="!!$scopedSlots['header-btn-radio']">
            <!-- @slot Use this slot header-btn-radio -->
            <slot name="header-btn-radio"></slot>
          </v-layout>
          <v-layout justify-end v-if="classProp !== 'dea-dialog dea-alert'">
            <dea-button
              icon
              small
              textindent
              prepend-icon="mdi-close"
              @click="close"
            >
              팝업창 닫기
            </dea-button>
          </v-layout>
        </v-card-title>
        <v-container>
          <slot></slot>
        </v-container>
        <v-card-actions>
          <slot name="actions"></slot>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
export default {
  name: 'DeaDialog',
  props: {
    title: {
      type: String,
      default: undefined
    },
    width: {
      type: [String, Number],
      default: undefined
    },
    persistent: {
      type: Boolean,
      default: true
    },
    value: {
      type: Boolean,
      default: false
    },
    classProp: {
      type: String,
      default: 'dea-dialog'
    }
  },
  data() {
    return {
      isShow: {
        type: Boolean,
        default: false
      }
    }
  },
  watch: {
    value: function(value) {
      this.isShow = value
    },
    isShow: function(value) {
      this.$emit('input', value)
    }
  },
  methods: {
    close: function() {
      this.isShow = false
      this.$emit('dialog:close')
    }
  },
  created() {
    this.isShow = this.value
  }
}
</script>
