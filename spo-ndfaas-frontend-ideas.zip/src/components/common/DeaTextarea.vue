<template>
  <v-textarea
    v-model="localValue"
    dense
    outlined
    :single-line="singleLine"
    :counter="counter"
    :filled="filled"
    :height="height"
    :hint="hint"
    :label="label"
    :no-resize="noResize"
    :persistent-hint="persistentHint"
    :placeholder="placeholder"
    :readonly="readonly"
    :disabled="disabled"
  ></v-textarea>
</template>

<script>
/**
 * Textarea component.
 * @displayName DeaTextarea
 */
export default {
  name: 'DeaTextarea',
  props: {
    /**
     * Creates counter for input length; if no number is specified, it defaults to 25. Does not apply any validation.
     */
    counter: {
      type: [Boolean, Number, String],
      default: undefined
    },
    /**
     * Label does not move on focus/dirty
     */
    singleLine: {
      type: Boolean,
      default: false
    },
    /**
     * Applies the alternate filled input style
     */
    filled: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the height of the input
     */
    height: {
      type: [Number, String],
      default: undefined
    },
    /**
     * Hint text
     */
    hint: {
      type: String,
      default: undefined
    },
    /**
     * Appends an icon to the outside the component’s input, uses same syntax as v-icon
     */
    label: {
      type: String,
      default: undefined
    },
    /**
     * Remove resize handle
     */
    noResize: {
      type: Boolean,
      default: false
    },
    /**
     * Forces hint to always be visible
     */
    persistentHint: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    /**
     * Disable the input
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * The input’s value
     */
    value: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      localValue: ''
    }
  },
  watch: {
    localValue(value) {
      this.$emit('input', value)
    }
  },
  created() {
    this.localValue = this.value
  }
}
</script>
