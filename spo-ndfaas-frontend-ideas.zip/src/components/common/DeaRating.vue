<template>
  <v-rating v-model="localData" @input="onInput"></v-rating>
</template>

<script>
export default {
  name: 'DeaRating',
  props: {
    value: {
      default: undefined
    }
  },
  data() {
    return {
      localData: undefined
    }
  },
  methods: {
    onInput(value) {
      this.$emit('input', value)
    }
  },
  created() {
    this.localData = this.value
  }
}
</script>
