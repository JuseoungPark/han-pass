<template>
  <v-menu
    ref="menu"
    v-model="menu"
    content-class="dea-date-picker-content"
    :close-on-content-click="closeOnContentClick"
    min-width="290px"
    :offset-y="offsetY"
    :return-value.sync="localDate"
    :transition="transition"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-layout class="dea-date-picker" :class="classes" :style="styles">
        <v-text-field
          v-model="txtDate"
          dense
          outlined
          readonly
          :label="label"
          :placeholder="placeholder"
          v-bind="attrs"
        ></v-text-field>
        <v-btn text class="dea-btn--textindent">
          <v-icon v-on="on">mdi-calendar-month</v-icon>
          달력
        </v-btn>
      </v-layout>
    </template>
    <v-date-picker v-model="localDate" no-title scrollable :range="range">
      <v-spacer></v-spacer>
      <v-btn text color="primary" @click="menu = false">Cancel</v-btn>
      <v-btn text color="primary" @click="updateDate">OK</v-btn>
    </v-date-picker>
  </v-menu>
</template>

<script>
export default {
  name: 'DeaDatePicker',
  props: {
    /**
     * Classes for text field
     */
    classes: {
      type: String,
      default: undefined
    },
    /**
     * Designates if menu should close when its content is clicked
     */
    closeOnContentClick: {
      type: Boolean,
      default: true
    },
    label: {
      type: String,
      default: undefined
    },
    /**
     * Offset the menu on the y-axis. Works in conjunction with direction top/bottom
     */
    offsetY: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * The value that is updated when the menu is closed - must be primitive. Dot notation is supported
     */
    returnValue: {
      default: undefined
    },
    styles: {
      type: String,
      default: undefined
    },
    /**
     * Sets the component transition. Can be one of the built in transitions or one your own.
     */
    transition: {
      type: [Boolean, String],
      default: 'v-menu-transition'
    },
    value: {
      default: undefined
    },
    /**
     * Allow the selection of date range
     */
    range: {
      type: Boolean,
      default: undefined
    }
  },
  data() {
    return {
      menu: false,
      localDate: undefined
    }
  },
  computed: {
    txtDate() {
      if (this.range) {
        return Array(this.localDate)
          .sort()
          .toString()
          .replace(',', ' ~ ')
      }
      return this.localDate
    }
  },
  watch: {
    value(val) {
      if (!val) this.initDate()
      else this.localDate = val
    }
  },
  methods: {
    initDate() {
      if (this.value) {
        this.localDate = this.value
        this.updateDate()
      } else {
        if (!this.placeholder) {
          if (this.range) {
            this.localDate = [new Date().toISOString().substr(0, 10)]
          } else {
            this.localDate = new Date().toISOString().substr(0, 10)
          }
          this.updateDate()
        }
      }
    },
    updateDate() {
      this.$refs.menu.save(this.localDate)
      this.$emit('input', this.localDate)
    }
  },
  mounted() {
    this.initDate()
  },
  created() {}
}
</script>
