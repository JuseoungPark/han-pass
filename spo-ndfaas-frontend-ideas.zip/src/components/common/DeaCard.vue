<template>
  <v-card :flat="flat" :height="height" class="dea-card">
    <v-card-title v-if="!!$scopedSlots['title']" :class="titleClass">
      <!-- @slot Use this slot title -->
      <slot name="title"></slot>
    </v-card-title>

    <v-card-subtitle v-if="!!$scopedSlots['sub-title']">
      <!-- @slot Use this slot sub-title -->
      <slot name="sub-title"></slot>
    </v-card-subtitle>

    <div class="dea-card__text" :class="cardTextClasses">
      <v-card-text>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-icon
              class="collapsible-btn"
              v-bind="attrs"
              v-on="on"
              v-if="expandable"
              @click="expanded = !expanded"
            >
              {{ expandIcon }}
            </v-icon>
          </template>
          <span>{{ expanded ? '접기' : '펼치기' }}</span>
        </v-tooltip>
        <!-- @slot Use this slot default -->
        <slot></slot>
      </v-card-text>

      <v-card-actions v-if="!!$scopedSlots['actions']">
        <!-- @slot Use this slot actions -->
        <slot name="actions"></slot>
      </v-card-actions>
    </div>
  </v-card>
</template>

<script>
/**
 * Card component.
 * @displayName DeaCard
 */
export default {
  name: 'DeaCard',
  props: {
    expandable: {
      type: Boolean,
      default: false
    },
    /**
     * Removes the card’s elevation
     */
    flat: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the height for the component.
     */
    height: {
      type: [Number, String],
      default: undefined
    },
    /**
     * Title of card
     */
    title: {
      type: String,
      default: undefined
    },
    /**
     * Title Class of card
     */
    titleClass: {
      type: String,
      default: undefined
    },
    /**
     * Sub title of card
     * @displayName sub-title
     */
    subTitle: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      expanded: true
    }
  },
  computed: {
    cardTextClasses() {
      return {
        'dea-card--collapsible dea-card--expanded':
          this.expandable && this.expanded,
        'dea-card--collapsible dea-card--folded':
          this.expandable && !this.expanded
      }
    },
    expandIcon() {
      return this.expanded ? 'mdi-chevron-up' : 'mdi-chevron-down'
    }
  }
}
</script>
