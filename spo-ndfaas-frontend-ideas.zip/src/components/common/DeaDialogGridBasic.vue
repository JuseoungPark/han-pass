<template>
  <dea-dialog
    v-model="isShow"
    :title="title"
    :width="width"
    @dialog:close="onDialogClose"
  >
    <slot name="header"></slot>
    <section class="dea-section">
      <div class="inner">
        <dea-grid
          ref="grid"
          row-selection-multiple
          suppress-row-click-selection
          use-pagination
          :columns="columns"
          :api="api"
          :apiType="apiType"
          :return-value.sync="count"
        >
          <template #header-left>
            <div v-if="gridTabitems.length === 0" class="text">
              총 {{ totalCount }} 건
            </div>
            <dea-tabs
              v-else
              v-model="tabSelected"
              :tabItems="tabItems"
            ></dea-tabs>
          </template>
          <template #header-right>
            <div class="d-flex col align-right ma-0">
              <template v-if="!!$scopedSlots['header-right']">
                <!-- @slot Use this slot header-right -->
                <slot name="header-right"></slot>
              </template>
            </div>
          </template>
        </dea-grid>
      </div>
    </section>
    <div class="btn-group">
      <v-col class="align-center">
        <dea-button color="primary" @click="hide">확인</dea-button>
      </v-col>
    </div>
  </dea-dialog>
</template>

<script>
import { NumberUtils } from '@/utils/NumberUtils'

export default {
  name: 'DeaDialogGridBasic',
  props: {
    api: {
      type: String,
      default: ''
    },
    columns: {
      default: []
    },
    title: {
      type: String,
      default: ''
    },
    width: {
      type: [String, Number],
      default: undefined
    },
    gridTabitems: {
      type: Array,
      default: () => []
    },
    apiType: {
      type: String,
      default: 'analysis'
    }
  },
  data() {
    return {
      isShow: false,
      count: 0,
      filter: '',
      tabSelected: 0
    }
  },
  computed: {
    tabItems() {
      return this.gridTabitems.map((item) => {
        return {
          name: `${item.name} (${NumberUtils.numberWithCommas(this.count)})`
        }
      })
    },
    totalCount() {
      return NumberUtils.numberWithCommas(this.count)
    }
  },
  watch: {
    isShow(value) {
      if (value) {
        // this.$refs.grid.setVisiblePage(7)
        this.count = 0
        this.$nextTick(() => {
          // console.log(this.filter)
          this.$refs.grid.dataReset()
          this.$refs.grid.setFilter(this.filter)
          this.loadData()
          document.getElementsByClassName('v-dialog--active')[0].scrollTop = 0
        })
      }
    }
  },
  methods: {
    show() {
      this.isShow = true
    },
    hide() {
      this.isShow = false
    },
    setFilter(filter) {
      this.filter = filter
    },
    getSelectedRows() {
      return this.$refs.grid.getSelectedRows()
    },
    loadData() {
      if (this.$refs.grid) this.$refs.grid.loadData()
    },
    loadDataSync() {
      if (this.$refs.grid) this.$refs.grid.loadDataSync()
    },
    loadPreviousPageIfEmptyData() {
      if (this.$refs.grid) this.$refs.grid.loadPreviousPageIfEmptyData()
    },
    onDialogClose() {
      this.$emit('dialog:close')
    }
  }
}
</script>
