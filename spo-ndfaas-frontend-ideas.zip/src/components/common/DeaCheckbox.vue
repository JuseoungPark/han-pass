<template>
  <v-checkbox
    v-model="localValue"
    :disabled="disabled"
    :hint="hint"
    :indeterminate="indeterminate"
    :input-value="inputValue"
    :label="label"
    :persistent-hint="persistentHint"
    :readonly="readonly"
    :true-value="trueValue"
    :value="cvalue"
    @change="onChange"
    @click="onClick"
  ></v-checkbox>
</template>

<script>
export default {
  name: 'DeaCheckbox',
  props: {
    cvalue: {
      default: undefined
    },
    /**
     * Disable the input
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * Hint text
     */
    hint: {
      Type: String,
      default: undefined
    },
    /**
     * Sets an indeterminate state for the checkbox
     */
    indeterminate: {
      type: Boolean,
      default: undefined
    },
    /**
     * The v-model bound value
     */
    inputValue: {
      default: undefined
    },
    /**
     * Sets input label
     */
    label: {
      type: String,
      default: undefined
    },
    /**
     * Forces hint to always be visible
     */
    persistentHint: {
      type: Boolean,
      default: false
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    trueValue: {
      default: undefined
    },
    /**
     * The input’s value
     */
    value: {
      default: undefined
    }
  },
  data() {
    return {
      localValue: undefined
    }
  },
  watch: {
    value: function(value) {
      this.localValue = value
    },
    localValue: function(value) {
      this.$emit('input', value)
    }
  },
  methods: {
    onChange(value) {
      this.$emit('change', value)
    },
    onClick() {
      this.$emit('click')
    }
  },
  created() {
    if (this.inputValue) this.localValue = this.inputValue
    else this.localValue = this.value
  }
}
</script>
