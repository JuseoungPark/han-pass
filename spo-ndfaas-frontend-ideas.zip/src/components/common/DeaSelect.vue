<template>
  <v-select
    v-if="!filterable"
    dense
    outlined
    :append-icon="appendIcon"
    :append-outer-icon="appendOuterIcon"
    :class="classes"
    :disabled="disabled"
    :hint="hint"
    :items="localItems"
    :item-text="itemText"
    :item-value="itemValue"
    :label="label"
    :multiple="multiple"
    :persistent-hint="persistentHint"
    :placeholder="placeholder"
    :prepend-icon="prependIcon"
    :prepend-inner-icon="prependInnerIcon"
    :readonly="readonly"
    :single-line="singleLine"
    :small-chips="smallChips"
    :style="styles"
    :value="localValues"
    :menu-props="{ bottom: true, offsetY: true }"
    @change="onChange"
    @click="onClick"
  >
    <template v-if="multiple && deaPrependSelectAll" v-slot:prepend-item>
      <v-list-item ripple @click="toggle">
        <v-list-item-action>
          <v-icon :color="localValues.length > 0 ? 'indigo darken-4' : ''">{{
            icon
          }}</v-icon>
        </v-list-item-action>
        <v-list-item-content>
          <v-list-item-title>Select All</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
      <v-divider class="mt-2"></v-divider>
    </template>
    <template v-if="multiple" v-slot:selection="{ item, index }">
      <v-chip v-if="selectionsSummary && index === 0" small>
        <span>{{ text(item) }}</span>
      </v-chip>
      <span v-if="selectionsSummary && index === 1" class="caption"
        >(+{{ localValues.length - 1 }} others)</span
      >
      <v-chip v-if="!selectionsSummary" small>
        <span>{{ text(item) }}</span>
        <v-icon
          v-if="selectionsEraseable"
          @click.prevent.stop="removeItem(index)"
          >mdi-close</v-icon
        >
      </v-chip>
    </template>
  </v-select>
  <v-autocomplete
    v-else
    dense
    outlined
    :append-icon="appendIcon"
    :append-outer-icon="appendOuterIcon"
    :class="classes"
    :disabled="disabled"
    :hint="hint"
    :items="localItems"
    :item-text="itemText"
    :item-value="itemValue"
    :label="label"
    :multiple="multiple"
    :no-data-text="noDataText"
    :persistent-hint="persistentHint"
    :placeholder="placeholder"
    :prepend-icon="prependIcon"
    :prepend-inner-icon="prependInnerIcon"
    :readonly="readonly"
    :single-line="singleLine"
    :small-chips="smallChips"
    :style="styles"
    :value="localValues"
    @change="onChange"
    @click="onClick"
  >
    <template v-if="deaPrependSelectAll" v-slot:prepend-item>
      <v-list-item ripple @click="toggle">
        <v-list-item-action>
          <v-icon :color="localValues.length > 0 ? 'indigo darken-4' : ''">{{
            icon
          }}</v-icon>
        </v-list-item-action>
        <v-list-item-content>
          <v-list-item-title>Select All</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
      <v-divider class="mt-2"></v-divider>
    </template>
    <template v-if="multiple" v-slot:selection="{ item, index }">
      <v-chip v-if="selectionsSummary && index === 0" small>
        <span>{{ text(item) }}</span>
      </v-chip>
      <span v-if="selectionsSummary && index === 1" class="caption"
        >(+{{ localValues.length - 1 }} others)</span
      >
      <v-chip v-if="!selectionsSummary" small>
        <span>{{ text(item) }}</span>
        <v-icon
          v-if="selectionsEraseable"
          @click.prevent.stop="removeItem(index)"
          >mdi-close</v-icon
        >
      </v-chip>
    </template>
  </v-autocomplete>
</template>

<script>
import i18n from '@/plugins/i18n'

export default {
  name: 'DeaSelect',
  props: {
    /**
     * Appends an icon to the component, uses the same syntax as v-icon
     */
    appendIcon: {
      type: String,
      default: undefined
    },
    /**
     * Appends an icon to the outside the component’s input, uses same syntax as v-icon
     */
    appendOuterIcon: {
      type: String,
      default: undefined
    },
    /**
     * Classes for text field
     */
    classes: {
      type: String,
      default: undefined
    },
    /**
     * Prepend select all
     */
    deaPrependSelectAll: {
      type: Boolean,
      default: false
    },
    /**
     * Custom selection
     */
    deaSelections: {
      type: Boolean,
      default: false
    },
    /**
     * Disables the input
     */
    disabled: {
      type: Boolean,
      default: false
    },
    filterable: {
      type: Boolean,
      default: false
    },
    /**
     * Hint text
     */
    hint: {
      type: String,
      default: undefined
    },
    /**
     * Sets input label
     */
    label: {
      type: String,
      default: undefined
    },
    /**
     * Changes select to multiple. Accepts array for value
     */
    multiple: {
      type: Boolean,
      default: false
    },
    noDataText: {
      type: String,
      default: i18n.tc('text.noData')
    },
    /**
     * Forces hint to always be visible
     */
    persistentHint: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * Prepends an icon to the component, uses the same syntax as v-icon
     */
    prependIcon: {
      type: String,
      default: undefined
    },
    /**
     * Prepends an icon inside the component’s input, uses the same syntax as v-icon
     */
    prependInnerIcon: {
      type: String,
      default: undefined
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    /**
     * Selection eraseable
     */
    selectionsEraseable: {
      type: Boolean,
      default: false
    },
    /**
     * Selection summary
     */
    selectionsSummary: {
      type: Boolean,
      default: false
    },
    /**
     * Label does not move on focus/dirty
     */
    singleLine: {
      type: Boolean,
      default: false
    },
    /**
     * Changes display of selections to chips with the small property
     */
    smallChips: {
      type: Boolean,
      default: false
    },
    /**
     * Style for text field
     */
    styles: {
      type: String,
      default: undefined
    },
    /**
     * The item list
     */
    items: {
      type: Array,
      default() {
        return []
      }
    },
    /**
     * value
     */
    value: {
      default: undefined
    },
    /**
     * Set property of items’s text value
     */
    itemText: {
      type: String,
      default: undefined
    },
    /**
     * Set property of items’s value - must be primitive.
     */
    itemValue: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      localItems: [],
      localValues: [],
      remove: false
    }
  },
  watch: {
    items() {
      this.localItems = this.items
    },
    value(val) {
      this.localValues = val
    }
  },
  computed: {
    isSelectedAll() {
      return this.localValues.length === this.localItems.length
    },
    isSelectedSome() {
      return this.localValues.length > 0 && !this.isSelectedAll
    },
    icon() {
      if (this.isSelectedAll) return 'mdi-close-box'
      if (this.isSelectedSome) return 'mdi-minus-box'
      return 'mdi-checkbox-blank-outline'
    }
  },
  methods: {
    onChange(value) {
      this.localValues = value
      this.$emit('input', value)
      this.$emit('change', value)
    },
    toggle() {
      this.$nextTick(() => {
        let value = []
        if (this.isSelectedAll) {
          value = []
        } else {
          value = this.localItems.map((item) =>
            item['value'] ? item['value'] : item
          )
        }
        this.onChange(value)
      })
    },
    removeItem(index) {
      this.remove = true
      this.localValues.splice(index, 1)
    },
    onClick(event) {
      if (this.remove) {
        event.preventDefault()
        this.remove = false
      }
    },
    text(item) {
      return typeof item === 'object' ? item[this.itemText] : item
    }
  },
  created() {
    this.localItems = this.items
    if (this.value) this.localValues = this.value
  }
}
</script>
