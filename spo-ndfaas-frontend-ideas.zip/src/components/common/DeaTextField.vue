<template>
  <v-text-field
    v-model="localValue"
    dense
    outlined
    :append-icon="appendIcon"
    :append-outer-icon="appendOuterIcon"
    :class="classes"
    :clearable="clearable"
    :counter="counter"
    :disabled="disabled"
    :error="error"
    :filled="filled"
    :hint="hint"
    :label="label"
    :persistent-hint="persistentHint"
    :placeholder="placeholder"
    :prepend-icon="prependIcon"
    :prepend-inner-icon="prependInnerIcon"
    :readonly="readonly"
    :rules="rules"
    :single-line="singleLine"
    :style="styles"
    :type="type"
    @click:prepend="onClickPrepend"
    @click:prepend-inner="onClickPrependInner"
    @click:append="onClickAppend"
    @click:append-outer="onClickAppendOuter"
    @click:clear="onClickClear"
    @change="onChange"
    @input="onInput"
    @keyup="onKeyup"
    @keydown="onKeydown"
    @mousedown="onMousedown"
    v-bind="$attrs"
    v-bind:value="value"
    v-on="inputListeners"
  ></v-text-field>
</template>

<script>
/**
 * Text field component.
 * @displayName DeaTextField
 */
export default {
  name: 'DeaTextField',
  props: {
    /**
     * Appends an icon to the component, uses the same syntax as v-icon
     */
    appendIcon: {
      type: String,
      default: undefined
    },
    /**
     * Appends an icon to the outside the component’s input, uses same syntax as v-icon
     */
    appendOuterIcon: {
      type: String,
      default: undefined
    },
    /**
     * Classes for text field
     */
    classes: {
      type: String,
      default: undefined
    },
    /**
     * Add input clear functionality, default icon is Material Design Icons mdi-clear
     */
    clearable: {
      type: Boolean,
      default: true
    },
    counter: {
      type: [Boolean, Number, String],
      default: undefined
    },
    /**
     * Disable the input
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * Puts the input in a manual error state
     */
    error: {
      type: Boolean,
      default: false
    },
    /**
     * Applies the alternate filled input style
     */
    filled: {
      type: Boolean,
      default: false
    },
    /**
     * Hint text
     */
    hint: {
      type: String,
      default: undefined
    },
    /**
     * Sets input label
     */ label: {
      type: String,
      default: undefined
    },
    /**
     * Forces hint to always be visible
     */
    persistentHint: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the input’s placeholder text
     */
    placeholder: {
      type: String,
      default: undefined
    },
    /**
     * Prepends an icon to the component, uses the same syntax as v-icon
     */
    prependIcon: {
      type: String,
      default: undefined
    },
    /**
     * Prepends an icon to the inside the component’s input, uses the same syntax as v-icon
     */
    prependInnerIcon: {
      type: String,
      default: undefined
    },
    /**
     * Puts input in readonly state
     */
    readonly: {
      type: Boolean,
      default: false
    },
    /**
     * Accepts an array of functions that take an input value as an argument and return either true / false or a string with an error message
     */
    rules: {
      type: Array,
      default: function() {
        return []
      }
    },
    /**
     * Label does not move on focus/dirty
     */
    singleLine: {
      type: Boolean,
      default: false
    },
    /**
     * Style for text field
     */
    styles: {
      type: String,
      default: undefined
    },
    /**
     * Sets input type
     */
    type: {
      type: String,
      default: 'text',
      validator: function(value) {
        // The value must match one of these strings
        return ['text', 'password', 'password'].indexOf(value) !== -1
      }
    },
    /**
     * The input’s value
     */
    value: {
      // type: String,
      default: undefined
    }
  },
  data() {
    return {
      localValue: ''
    }
  },
  computed: {
    inputListeners: function() {
      var vm = this
      // `Object.assign` 는 오브젝트를 새로운 오브젝트로 병합합니다.
      return Object.assign(
        {},
        // 우선 부모 엘리먼트의 모든 리스너를 추가합니다.
        this.$listeners,
        // 그 다음, 기존 리스너를 override하는
        // 커스텀 리스터를 추가할 수 있습니다.
        {
          // 아래 구문을 사용하면 v-model과 같이 동작하도록 만들 수 있습니다.
          input: function(event) {
            if (event.target) {
              vm.$emit('input', event.target.value)
            } else {
              vm.$emit('input', event)
            }
          }
        }
      )
    }
  },
  watch: {
    value: function(value) {
      this.localValue = value
    }
  },
  methods: {
    setValue(value) {
      if (value !== undefined) this.localValue = value
      else this.localValue = ''
      this.$emit('input', value)
    },
    onClickPrepend() {
      this.$emit('click:prepend')
    },
    onClickPrependInner() {
      this.$emit('click:prepend-inner')
    },
    onClickAppend() {
      this.$emit('click:append')
    },
    onClickAppendOuter() {
      this.$emit('click:append-outer')
    },
    onClickClear() {
      this.setValue('')
      this.$emit('click:clear')
    },
    onChange(value) {
      // this.$emit('input', value)
      this.$emit('change', value)
    },
    onInput(value) {
      this.$emit('input', value)
    },
    onKeyup(value) {
      this.$emit('keyup', value)
    },
    onKeydown(value) {
      this.$emit('keydown', value)
    },
    onMousedown(value) {
      this.$emit('mousedown', value)
    }
  },
  created() {
    this.setValue(this.value)
  }
}
</script>
