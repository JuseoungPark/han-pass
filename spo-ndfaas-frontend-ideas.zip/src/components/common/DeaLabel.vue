<template>
  <v-subheader :class="classes">
    <label>
      <slot></slot>
    </label>
  </v-subheader>
</template>

<script>
/**
 * Lable component.
 * @displayName DeaLabel
 */
export default {
  name: 'DeaLabel',
  props: {
    required: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    classes() {
      return {
        'dea-label--required': this.required
      }
    }
  },
  methods: {}
}
</script>
