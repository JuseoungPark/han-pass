<template>
  <fragment>
    <template v-if="title">
      <dea-tooltip :content="title" bottom class="btn">
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            :class="[classes, outlinedAddClass, textIndentAddClass]"
            :dark="dark"
            :disabled="disabled"
            :color="color"
            :fab="fab"
            :icon="icon"
            :outlined="outlined"
            :text="text"
            :rounded="rounded"
            :depressed="depressed"
            :block="block"
            :small="small"
            :x-small="xSmall"
            :large="large"
            :x-large="xLarge"
            :width="width"
            @click="onClick"
            v-bind="title ? attrs : false"
            v-on="title ? on : false"
          >
            <v-icon v-if="prependIcon" :dark="dark">{{ prependIcon }}</v-icon>
            <!-- @slot Use this slot default -->
            <slot></slot>
            <v-icon v-if="appendIcon" :dark="dark">{{ appendIcon }}</v-icon>
            <!-- @slot Use this slot default -->
          </v-btn>
        </template>
      </dea-tooltip>
    </template>
    <template v-else>
      <v-btn
        :class="[classes, outlinedAddClass, textIndentAddClass]"
        :absolute="absolute"
        :fixed="fixed"
        :dark="dark"
        :left="left"
        :right="right"
        :disabled="disabled"
        :color="color"
        :fab="fab"
        :icon="icon"
        :outlined="outlined"
        :text="text"
        :rounded="rounded"
        :depressed="depressed"
        :block="block"
        :small="small"
        :x-small="xSmall"
        :large="large"
        :x-large="xLarge"
        :width="width"
        @click="onClick"
        v-bind="title ? attrs : false"
        v-on="title ? on : false"
      >
        <v-icon v-if="prependIcon" :dark="dark">{{ prependIcon }}</v-icon>
        <!-- @slot Use this slot default -->
        <slot></slot>
        <v-icon v-if="appendIcon" :dark="dark">{{ appendIcon }}</v-icon>
        <!-- @slot Use this slot default -->
      </v-btn>
    </template>
  </fragment>
</template>

<script>
/**
 * Button component.
 * @displayName DeaButton
 */
export default {
  name: 'DeaButton',
  props: {
    /**
     * Classes for button
     */
    classes: {
      type: String,
      default: undefined
    },
    absolute: {
      type: Boolean,
      default: false
    },
    fixed: {
      type: Boolean,
      default: false
    },
    left: {
      type: Boolean,
      default: false
    },
    right: {
      type: Boolean,
      default: false
    },
    /**
     * icon name after label
     */
    appendIcon: {
      type: String,
      default: undefined
    },
    /**
     * Applies the dark theme variant to the component. You can find more information on the Material Design documentation for dark themes.
     */
    dark: {
      type: Boolean,
      default: undefined
    },
    /**
     * Removes the ability to click or target the component.
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * Applies specified color to the control
     */
    color: {
      type: String,
      default: undefined
    },
    /**
     * Designates the button as a floating-action-button - round.
     */
    fab: {
      type: Boolean,
      default: false
    },
    /**
     * Designates the button as icon - round and flat
     */
    icon: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the background transparent and applies a thin border.
     */
    outlined: {
      type: Boolean,
      default: false
    },
    /**
     * icon name before label
     */
    prependIcon: {
      type: String,
      default: undefined
    },
    /**
     * Expands the button to 100% of available space.
     */
    text: {
      type: Boolean,
      default: false
    },
    /**
     * Applies a large border radius on the button.
     */
    rounded: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the background transparent.
     */
    depressed: {
      type: Boolean,
      default: false
    },
    /**
     * Removes the button box shadow.
     */
    block: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the component small.
     */
    small: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the component extra small.
     */
    xSmall: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the component large.
     */
    large: {
      type: Boolean,
      default: false
    },
    /**
     * Makes the component extra large.
     */
    xLarge: {
      type: Boolean,
      default: false
    },
    /**
     * Sets the width for the component.
     */
    width: {
      type: [Number, String],
      default: undefined
    },
    title: {
      type: String,
      default: ''
    },
    bottom: {
      type: Boolean,
      default: false
    },
    textindent: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    outlinedAddClass() {
      return {
        'white--bg': this.outlined
      }
    },
    textIndentAddClass() {
      return { 'dea-btn--textindent': this.textindent }
    }
  },
  methods: {
    /**
     * Gets called when the user clicks on the button
     */
    onClick() {
      this.$emit('click')
    }
  }
}
</script>
