<template>
  <v-container fluid>
    <article>
      <section class="dea-section">
        <v-sheet>영역 1</v-sheet>
      </section>
      <section class="dea-section">
        <v-sheet>영역 2</v-sheet>
      </section>
    </article>
  </v-container>
</template>

<script>
export default {
  name: 'HelloWorld',
  components: {},
  props: {
    /** Set Ref **/
    /** Set Number **/
    /** Set String **/
    /** Set Array **/
    /** Set Object **/
    /** Set Boolean **/
  },
  watch: {},
  data() {
    return {
      /** Set Ref **/
      /** Set Number **/
      /** Set String **/
      /** Set Array **/
      /** Set Object **/
      /** Set Boolean **/
    }
  },
  beforeMount() {},
  mounted() {
    this.initialize()
  },
  computed: {},
  methods: {
    /** Initialize after mount **/
    initialize() {}

    /** Function **/

    /** Event Handler **/
  },
  beforeDestroy() {}
}
</script>
