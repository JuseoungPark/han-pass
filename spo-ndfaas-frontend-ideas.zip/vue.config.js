const mode = process.env.NODE_ENV || 'development'
module.exports = {
  devServer: {
    port: process.env.VUE_APP_PORT || 8080
  },
  transpileDependencies: ['vuetify'],
  runtimeCompiler: true,
  pluginOptions: {
    i18n: {
      locale: 'kr',
      fallbackLocale: 'kr',
      localeDir: 'locales',
      enableInSFC: false
    },
    electronBuilder: {
      preload: 'src/preload.js',
      builderOptions: {
        extraResources: [
          'src/apiServer/develop.sqlite',
          'public/api',
          'public/docs'
        ]
      }
    }
  },
  css: {
    // Enable CSS source maps.
    sourceMap: mode !== 'production'
  }
}
