<template>
  <div class="-fdp-dropdown">
    <div :class="{'-fdp-dropdown__button': !disabled, '-fdp-dropdown--disabled': disabled}" v-dropdown-click-outside="toggleItemOuter">
      <input v-if="autocomplete" class="-fdp-dropdown__autocomplete-input" type="text" :placeholder="placeholder" :value="inputValue" @input="onChangeInput" @keydown.tab.prevent="complete(0)" @click="autoCompleteToggleItem">
      <div v-else class="-fdp-dropdown__selected" @click="toggleItem">{{ selectedTitle }}</div>

      <div class="-fdp-dropdown__icon--up" v-if="isItemShowing" @click="toggleItem" />
      <div class="-fdp-dropdown__icon--down" v-else @click="toggleItem"/>
    </div>
    <transition name="-fdp-dropdown__move-down">
      <div class="-fdp-dropdown__items" v-show="isItemShowing">
        <div v-for="(item, index) in items" :key="index" @click.stop="onClickItem(item, index)" :class="['-fdp-dropdown__items-wrapper', { '-fdp-dropdown--selected': isSelectedItem(index) }]">
          <div v-if="custom" class="-fdp-dropdown__custom-item-wrapper">
            <slot :item ="item" :bold="bold" :getHighlightTitle="getHighlightTitle"></slot>
          </div>
          <div v-else class="-fdp-dropdown__default-item-wrapper">
            <span v-if="autocomplete && bold" class="-fdp-dropdown__autocomplete-item" v-html="getHighlightTitle(item[title]? item[title] : item)"></span>
            <span v-else class="-fdp-dropdown__default-item">{{(title === 'no-title')? item  : item[title]}}</span>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'fdp-dropdown',
  props: {
    items: [Array, Object],
    value: [Number, String, Object],
    current: [Number, String],
    placeholder: {
      type: String,
      default: 'input value'
    },
    autocomplete: {
      type: Boolean,
      default: false
    },
    bold: {
      type: Boolean,
      default: false
    },
    custom: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: 'no-title' // 객체가 아닌 순수 값으로 이루어진 배열을 받을 때는 no-title
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      inputValue: '',
      isItemShowing: false,
      currentItem: -1,
      inputDelay: true,
      selectedTitle: ''
    }
  },
  watch: {
    inputValue: function (val) {
      this.selectedTitle = val
    }
  },
  methods: {
    getHighlightTitle (title) {
      const regex = new RegExp(`(${this.inputValue})`, 'gi')
      return title.replace(regex, '<b>$1</b>')
    },
    onChangeInput (input) {
      this.inputValue = input.target.value

      var _this = this
      // Delay 0.5s
      if (this.inputDelay) {
        this.inputDelay = false
        setTimeout(() => {
          this.$emit('changeInput', this.inputValue)
          this.inputDelay = true

          _this.currentItem = -1
        }, 500)
      }
    },
    onClickItem (item, index, e) {
      this.$emit('input', item)

      this.currentItem = index

      // dropbox 화면에, no-title이면 객체로, 아니면 값으로 변경 -> watch에서 실제 처리
      this.inputValue = (this.title === 'no-title') ? item : this.items[index][this.title]

      // 옵션 목록 toggle
      this.toggleItem()
    },
    toggleItem () {
      this.isItemShowing = this.disabled ? this.isItemShowing : !this.isItemShowing
    },
    autoCompleteToggleItem () {
      this.isItemShowing = true
    },
    toggleItemOuter () {
      this.isItemShowing = false
    },
    isSelectedItem (index) {
      return index === Number(this.currentItem)
    },
    complete (i) {
      this.inputValue = (this.title === 'no-title') ? this.value : this.items[i][this.title]
    },
    changeValue () {
      // 리스트 객체에서 this.title 로 받은 항목을 return
      if (this.items !== 'undefiend' && this.items.length > 0) {
        let that = this

        // item 배열 중 item value와 동일한 값의 객체의 index 찾기
        this.items.some((item, idx) => {
          if (item.value === that.value) {
            that.currentItem = idx
          }
          return (item.value === that.value)
        })

        // items 배열의 currentItem에 있는 객체의 this.title에 해당하는 속성의 값을 return
        return this.items[this.currentItem][this.title]
      }
    }
  },
  mounted () {
    this.selectedTitle = (this.title === 'no-title') ? this.value : this.changeValue()
  },
  directives: {
    'dropdown-click-outside': {
      bind: function (el, binding) {
        // Define Handler and cache it on the element
        const handler = (e) => {
          if ((!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },

      unbind: function (el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      }
    }
  }
}
</script>

<style>

</style>
