<template>
    <div class="-fdp-card">
        <slot></slot>
    </div>
</template>

<script>
export default {
  name: 'fdp-card'
}
</script>

<style>

</style>
