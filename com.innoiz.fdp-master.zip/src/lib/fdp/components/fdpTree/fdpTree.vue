<template>
  <div :class="classes" role="tree" onselectstart="return false">
    <ul :class="containerClasses" role="group">
      <tree-item v-for="(child, index) in data"
                 :key="index"
                 :data="child"
                 :text-field-name="textFieldName"
                 :value-field-name="valueFieldName"
                 :whole-row="wholeRow"
                 :show-checkbox="showCheckbox"
                 :height="sizeHight"
                 :parent-item="data"
                 :draggable="draggable"
                 :on-item-click="onItemClick"
                 :on-item-toggle="onItemToggle"
                 :on-item-drag-start="onItemDragStart"
                 :on-item-drag-end="onItemDragEnd"
                 :on-item-drop="onItemDrop"
                 :klass="index === data.length-1?'tree-last':''"/>
    </ul>
  </div>
</template>
<script>
import TreeItem from './fdpTreeItem.vue'

let ITEM_ID = 0
let ITEM_HEIGHT_SMALL = 24
let ITEM_HEIGHT_DEFAULT = 24
let ITEM_HEIGHT_LARGE = 32

export default {
  name: 'fdp-tree',
  components: {
    TreeItem
  },
  props: {
    data: {type: Array, required: true}, // 트리 소스 데이터
    size: {type: String, validator: value => ['large', 'small', ''].indexOf(value) > -1, default: 'small'}, // 사이즈 large or small
    showCheckbox: {type: Boolean, default: false}, // 체크박스 표시 여부
    wholeRow: {type: Boolean, default: false}, // 체크된 item 줄 전체 표시
    noDots: {type: Boolean, default: false}, // 가이드라인삭제 여부
    multiple: {type: Boolean, default: false}, // 다중선택 가능 여부
    allowBatch: {type: Boolean, default: false}, // 다중선택 시, 부모 선택하면 자식 모두 선택 여부
    textFieldName: {type: String, default: 'text'},
    valueFieldName: {type: String, default: 'value'},
    async: {type: Function, default: null},
    loadingText: {type: String, default: 'Loading...'},
    draggable: {type: Boolean, default: false}, // 드래그 가능 여부
    klass: {type: String, default: ''}
  },
  data () {
    return {
      draggedItem: null,
      draggedElm: null,
      rootNode: {}
    }
  },
  computed: {
    classes () {
      return [
        {'tree': true},
        {'tree-default': !this.size},
        {[`tree-default-${this.size}`]: !!this.size},
        {'tree-checkbox-selection': !!this.showCheckbox},
        {[this.klass]: !!this.klass}
      ]
    },
    containerClasses () {
      return [
        {'tree-container-ul': true},
        {'tree-children': true},
        {'tree-wholerow-ul': !!this.wholeRow},
        {'tree-no-dots': !!this.noDots}
      ]
    },
    sizeHight () {
      switch (this.size) {
        case 'large':
          return ITEM_HEIGHT_LARGE
        case 'small':
          return ITEM_HEIGHT_SMALL
        default:
          return ITEM_HEIGHT_DEFAULT
      }
    }
  },
  watch: {
    data () {
      ITEM_ID = 0
      this.initializeData(this.data)
    }
  },
  created () {
    ITEM_ID = 0
    this.initializeData(this.data)
  },
  mounted () {
    if (this.async) {
      this.$set(this.data, 0, this.initializeLoading())
      this.handleAsyncLoad(this.data, this)
    }
    // IE9에 draggable 가능하게 하는 로직
    if (document.doctype && navigator.appVersion.indexOf('MSIE 9') > -1) {
      document.addEventListener('selectstart', function (e) {
        for (var el = e.target; el; el = el.parentNode) {
          if (el.attributes && el.attributes['draggable']) {
            e.preventDefault()
            e.stopImmediatePropagation()
            el.dragDrop()
            return false
          }
        }
      })
    }
  },
  methods: {
    initializeData (items) {
      if (items && items.length > 0) {
        for (let i in items) {
          var dataItem = this.initializeDataItem(items[i])
          if (dataItem.id === 0) {
            this.rootNode = dataItem
          }
          items[i] = dataItem
          this.initializeData(items[i].children)
        }
      }
    },
    initializeDataItem (item) {
      function Model (item, textFieldName, valueFieldName) {
        this.id = item.id || ITEM_ID++
        this[textFieldName] = item[textFieldName] || ''
        this[valueFieldName] = item[valueFieldName] || item[textFieldName]
        this.icon = item.icon || ''
        this.opened = item.opened || false
        this.selected = item.selected || false
        this.disabled = item.disabled || false
        this.loading = item.loading || false
        this.children = item.children || []
      }
      let node = Object.assign(new Model(item, this.textFieldName, this.valueFieldName), item)
      let self = this
      node.addBefore = function (data, selectedNode) {
        let newItem = self.initializeDataItem(data)
        let index = selectedNode.parentItem.indexOf(node)
        selectedNode.parentItem.splice(index, 0, newItem)
      }
      node.addAfter = function (data, selectedNode) {
        let newItem = self.initializeDataItem(data)
        let index = selectedNode.parentItem.indexOf(node) + 1
        selectedNode.parentItem.splice(index, 0, newItem)
      }
      node.addChild = function (data) {
        let newItem = self.initializeDataItem(data)
        node.children.push(newItem)
      }
      node.openChildren = function () {
        node.opened = true
        self.handleRecursionNodeChildren(node, node => {
          node.opened = true
        })
      }
      node.closeChildren = function () {
        node.opened = false
        self.handleRecursionNodeChildren(node, node => {
          node.opened = false
        })
      }
      return node
    },
    initializeLoading () {
      var item = {}
      item[this.textFieldName] = this.loadingText
      item.disabled = true
      item.loading = true
      return this.initializeDataItem(item)
    },
    handleRecursionNodeChildren (node, func) {
      if (node.children && node.children.length > 0) {
        for (let childNode of node.children) {
          func(childNode)
          this.handleRecursionNodeChildren(childNode, func)
        }
      }
    },
    onItemClick (oriNode, oriItem) {
      if (this.multiple) {
        if (this.allowBatch) {
          this.handleBatchSelectItems(oriNode, oriItem)
        }
      } else {
        this.handleSingleSelectItems(oriNode, oriItem)
      }
      this.$emit('item-click', oriNode, oriItem)
    },
    handleSingleSelectItems (oriNode, oriItem) {
      this.handleRecursionNodeChilds(this, node => {
        node.model.selected = false
      })
      oriNode.model.selected = true
    },
    handleBatchSelectItems (oriNode, oriItem) {
      this.handleRecursionNodeChilds(oriNode, node => {
        if (node.model.disabled) return
        node.model.selected = oriNode.model.selected
      })
    },
    handleRecursionNodeChilds (node, func) {
      if (node.$children && node.$children.length > 0) {
        for (let childNode of node.$children) {
          if (!childNode.disabled) {
            func(childNode)
            this.handleRecursionNodeChilds(childNode, func)
          }
        }
      }
    },
    onItemToggle (oriNode, oriItem) {
      if (oriNode.model.opened) {
        this.handleAsyncLoad(oriNode.model.children, oriNode, oriItem)
      }
      this.$emit('item-toggle', oriNode, oriItem)
    },
    handleAsyncLoad (oriParent, oriNode, oriItem) {
      var self = this
      if (this.async) {
        if (oriParent[0].loading) {
          this.async(oriNode, (data) => {
            if (data.length > 0) {
              for (let i in data) {
                data[i].children = [self.initializeLoading()]
                var dataItem = self.initializeDataItem(data[i])
                self.$set(oriParent, i, dataItem)
              }
            } else {
              oriNode.model.children = []
            }
          })
        }
      }
    },
    onItemDragStart (e, oriNode, oriItem) {
      if (!this.draggable) { return false }
      e.dataTransfer.effectAllowed = 'move'
      e.dataTransfer.setData('text', '')
      this.draggedElm = e.target
      this.draggedItem = {
        item: oriItem,
        parentItem: oriNode.parentItem,
        index: oriNode.parentItem.indexOf(oriItem)
      }
    },
    onItemDragEnd (e, oriNode, oriItem) {
      if (!this.draggable) { return false }
      this.draggedItem = null
    },
    onItemDrop (e, oriNode, oriItem) {
      if (!this.draggable) { return false }
      if (this.draggedElm === e.target || this.draggedElm.contains(e.target)) {
        return
      }
      if (this.draggedItem) {
        if (this.draggedItem.parentItem === oriItem.children ||
            this.draggedItem.item === oriItem ||
            (oriItem.children && oriItem.children.indexOf(this.draggedItem.item) !== -1)) {
          return
        }
        oriItem.children = oriItem.children ? oriItem.children.concat(this.draggedItem.item) : [this.draggedItem.item]
        var draggedItem = this.draggedItem
        this.$nextTick(() => {
          draggedItem.parentItem.splice(draggedItem.index, 1)
        })
      }
    },
    openAllNodes () {
      // if (!_.isEmpty(this.rootNode)) {
      if (this.rootNode !== null && !!Object.keys(this.rootNode).length) {
        this.rootNode.openChildren()
      }
    },
    closeAllNodes () {
      if (this.rootNode !== null && !!Object.keys(this.rootNode).length) {
        this.rootNode.closeChildren()
      }
    },
    addRootNode (param) {
      if (this.rootNode !== null && !!Object.keys(this.rootNode).length) {
        this.rootNode.addChild(param)
      }
    }
  }
}
</script>
