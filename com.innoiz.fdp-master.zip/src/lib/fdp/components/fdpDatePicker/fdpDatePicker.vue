<template>
<div class="-fdp-date-picker" :class="classes">
  <date-picker ref="fdpDatepicker"
               v-model="state"
               typeable
               calendarButton
               calendarButtonIcon="-fdp-date-picker--icon"
               :disabled="disabled"
               :disabledDates="disabledDates"
               :placeholder="placeholder"
               :format="format"
               :language="ko"
               :minimumView="minimumView"
               :maximumView="maximumView"
               :initialView="initialView"
               @input="onInput"
               @selected="selected"
               v-date-picker-click-outside="toggleItemOuter">
  </date-picker>
</div>
</template>

<script>
/**
 * 이름 : fdp-date-picker
 * 설명 : vuejs-date-picker (open source)를 wrapping하여 개발
 * 최종 수정 일시 : 2018 - 09 - 05
 */
import DatePicker from './vuejs-date-picker/components/Datepicker.vue'
import {ko} from './vuejs-date-picker/locale'

export default {
  name: 'fdp-date-picker',
  components: {DatePicker},
  props: {
    value: { type: String, default: new Date().toISOString() }, // 부모로부터 입력 받은 날짜
    format: { type: String, default: 'yyyy-MM-dd' }, // 화면에 날짜를 표시하는 포맷
    placeholder: { type: String },
    disabled: {type: Boolean, default: false}, // 해당 component의 diabled 여부
    minimumView: { type: String, default: 'day' }, // 달력 모양을 표시/선택하는 최소 범위
    maximumView: { type: String, default: 'year' }, // 달력 모양을 표시/선택하는 최대 범위
    initialView: { type: String, default: 'day' }, // 달력 모양을 표시/선택하는 초기 범위
    disabledDates: { type: Object }, // 달력에서 선택할 수 없는(disabled) 날짜 범위. 예) { 'from': new Date(), 'to': null }
    up: {type: Boolean, default: false},
    alignRight: {type: Boolean, default: false}
  },
  data () {
    return {
      // state: fdp-date-picker 내에서 사용하는 date 값(value는 props이기 때문에 변경할 수 없으므로 따로 선언)
      state: this.value ? new Date(this.value) : this.placeholder ? '' : new Date(),
      // locale (언어 설정)
      ko: ko
    }
  },
  watch: {
    state: function () {
      // date 값이 바뀔 때마다 부모에게 전달
      if (!this.state) return
      this.$emit('input', this.state.toISOString())
    },
    value: function () {
      // 부모로부터 받은 날짜와 fdp-date-picker의 date(날짜)가 다르면, 부모로부터 받은 값으로 내부 값을 변경
      if (!this.state || !this.value) return
      if (this.state.toISOString().substring(0, 10) !== this.value.substring(0, 10)) {
        this.state = new Date(this.value)
      }
    }
  },
  computed: {
    classes () {
      return [
        {'-fdp-date-picker--disabled': this.disabled},
        {'-fdp-date-picker--up': this.up},
        {'-fdp-date-picker--align-right': this.alignRight}
      ]
    }
  },
  mounted: function () {
    // 내부 날짜에 값이 있으면 부모에게 전달
    if (this.state.length !== 0) {
      this.$emit('input', this.state.toISOString())
    }
  },
  methods: {
    // 선택한 날짜를 @selected로 부모에게 전달
    selected: function (date) {
      this.$emit('selected', date)
    },
    onInput (date) {
      if (date) {
        this.$emit('input', date.toISOString())
      } else {
        this.$emit('input', date)
      }
    },
    // 달력 외부를 선택하면 달력 끄는 동작
    toggleItemOuter () {
      this.$refs.fdpDatepicker.close()
    }
  },
  directives: {
    // 달력 외부를 선택하면 달력 끄는 동작 directive 연결
    'date-picker-click-outside': {
      bind: function (el, binding) {
        // Define Handler and cache it on the element
        const handler = (e) => {
          if ((!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function (el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      }
    }
  }
}
</script>
