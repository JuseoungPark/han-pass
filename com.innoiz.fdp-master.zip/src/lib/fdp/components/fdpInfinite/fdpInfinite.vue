<template>
  <div class="-fdp-infinite" :style="{'height':(tableHeaderHeight + tableBodyHeight) + 'px'}">
    <table class="-fdp-infinite__table" :style="{'min-width': tableMinWidth + 'px'}">
      <thead class="-fdp-infinite__thead">
        <slot name="header"></slot>
      </thead>
      <tbody  class="-fdp-infinite__tbody" @scroll="onScroll" ref="fdpInfiniteBody">
        <template  v-if="items.length ===0 ">
          <slot name="emptyView"></slot>
        </template>
        <template v-else>
        <div v-for="(item,index) in items" :key="item.id" style="vertical-align: middle;"
             :class="{ '-fdp-infinite__tbody-row': true, '-fdp-infinite--selected': isSelected(item), '-fdp-infinite--last-child': index === items.length-1 }">
          <tr @click="onClickRow(item)" :value="index" @dblclick.stop="onDbclick(item)">
            <slot :item="item" :index="index"></slot>
          </tr>
          <transition name="-fdp-infinite__expand" @after-enter="transitionComplete" @before-leave="willLeave">
            <div class="-fdp-infinite__tbody-expand-div" v-if="item.showExpand">
              <tr>
                <slot name="expand" :item="item"></slot>
              </tr>
            </div>
          </transition>
        </div>
        <tr v-show="showLoadingStatus && isLoading"
            class="-fdp-infinite__loading">
          <td class="-fdp-infinite__loading-text"
              :colspan="headerColspan" >
            Loading</td>
        </tr>
        </template>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'fdp-infinite',
  props: {
    items: {
      type: [Array, String, Object]
    },
    tableHeaderHeight: {
      type: [String, Number],
      default: 0
    },
    tableBodyHeight: {
      type: [String, Number],
      default: 400
    },
    tableMinWidth: {
      type: [String, Number],
      default: 1024
    },
    singleSelect: {
      type: Boolean,
      default: false
    },
    multiSelect: {
      type: Boolean,
      default: false
    },
    showLoadingStatus: {
      type: Boolean,
      default: false
    },
    isLoading: {
      type: Boolean,
      default: false
    },
    expandable: {
      type: Boolean,
      default: false
    },
    headerColspan: {
      type: Number,
      default: 0
    },
    expandHeight: {
      type: [String, Number],
      default: 48
    },
    value: {
      type: [Array, Object],
      default: () => []
    }
  },
  data () {
    return {
      currentScrollPoint: 0,
      selected: []
    }
  },
  watch: {
    value: function (val) {
      this.selected = val
    }
  },
  methods: {
    isSelected (b) {
      if (this.selected.length) {
        return (this.selected.indexOf(b) >= 0)
      } else {
        return (this.selected === b)
      }
    },
    onClickRow (b) {
      if (this.expandable) {
        if (!this.multiSelect) {
          for (let item of this.items) {
            if (b === item) {
              continue
            }
            if (item.showExpand) {
              item.showExpand = false
            }
          }
        }

        b.showExpand = !b.showExpand
      }
      this.$emit('clickRow', b)
      if (!this.multiSelect && !this.singleSelect) { return }
      if (this.multiSelect) {
        if (this.selected.indexOf(b) >= 0) {
          this.selected.splice(this.selected.indexOf(b), 1)
        } else {
          this.selected.push(b)
        }
        this.$emit('input', this.selected)
      } else {
        if (this.selected === b) {
          return
        } else {
          this.selected = b
          // this.selected.push(b)
        }
        this.$emit('input', this.selected)
      }
    },
    onScroll (e) {
      this.currentScrollPoint = e.srcElement.scrollTop

      if (!this.isLoading && this.currentScrollPoint >= (e.srcElement.scrollHeight - this.tableBodyHeight)) {
        this.$emit('loading-data')
      }
    },
    transitionComplete: function (el) {
      // el.style.height = this.expandHeight + 'px'
    },
    willLeave: function (el) {
      el.style.height = '0px'
    },
    onDbclick (row) {
      this.$emit('dbClick', row)
    },
    moveScrollTop () {
      this.$refs['fdpInfiniteBody'].scrollTop = 0
    },
    moveScrollBottom () {
      this.$refs['fdpInfiniteBody'].scrollTop = this.$refs['fdpInfiniteBody'].scrollHeight
    }
  }
}
</script>

<style>

</style>
