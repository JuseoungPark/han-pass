<template>
  <fdp-dropdown custom :title="title" autocomplete bold :items="items"
                        @clickItem="onClickItemCustom" @changeInput="onKeywordChangeCustom"
                        class="-fdp-auto-complete"
                        :placeholder="placeholder">
    <template slot-scope="props">
      <slot :item ="props.item" :getHighlightTitle="props.getHighlightTitle"></slot>
    </template>
  </fdp-dropdown>
</template>

<script>
export default {
  name: 'fdp-auto-complete',
  props: {
    items: {
      type: [Array, Object],
      default: () => []
    },
    placeholder: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      required: true
    }
  },
  methods: {
    onClickItemCustom (item) {
      this.$emit('click-item', item)
    },
    onKeywordChangeCustom (inputValue) {
      if (inputValue && inputValue.length >= 2) {
        this.$emit('change-input', inputValue)
      }
    }
  }
}
</script>

<style>
</style>
