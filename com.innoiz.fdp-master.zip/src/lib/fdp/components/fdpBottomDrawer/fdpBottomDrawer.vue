<template>
  <div :class="['-fdp-bottom-drawer' , {'-fdp-bottom-drawer--up': isUp}]">
    <div class="-fdp-bottom-drawer__header">
      <slot name="drawerHeader"></slot>
    </div>
    <button type="button" :class="['-fdp-bottom-drawer__handle-button', {'-fdp-bottom-drawer__handle-button--up': isUp}]"
            @click="bottomClicked"></button>
    <slot name="drawerBody"></slot>
  </div>
</template>

<script>
export default {
  name: 'fdp-bottom-drawer',
  props: {
    value: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      isUp: this.value
    }
  },
  methods: {
    bottomClicked () {
      this.isUp = !this.isUp
      this.$emit('input', this.isUp)
    }
  },
  watch: {
    value (newValue) {
      this.isUp = newValue
    }
  }
}
</script>

<style>

</style>
