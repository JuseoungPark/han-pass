<template>
  <transition name="-fdp-modal--fade">
    <div v-if="value" class="-fdp-modal" v-modal-auto-set-z-index name="-fdp-modal">
      <div class="-fdp-modal__background" @click="onClose('outside')"></div>
      <div class="-fdp-modal__container">
        <div class="-fdp-modal__close-button" v-if="quit">
          <button type="button" class="-fdp-modal--cursor" @click.prevent="onClose"></button>
        </div>
        <div class="-fdp-modal__contents">
          <slot></slot>
        </div>
      </div>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'fdp-modal',
  props: {
    value: {
      type: Boolean,
      default: false
    },
    quit: {
      type: Boolean,
      default: false
    },
    preventOutsideClose: {
      type: Boolean,
      default: false
    },
    modalType: {
      type: String,
      default: ''
    }
  },
  methods: {
    onClose (param) {
      if (param === 'outside' && this.preventOutsideClose) {
        return
      }
      this.$emit('input', !this.value)
    }
  },
  directives: {
    'modal-auto-set-z-index': {
      bind: function (el, binding, vnode) {
        let createdModal = document.getElementsByName('-fdp-modal')
        let maxZIndex = 2000
        for (var i = 0, len = createdModal.length; i < len; i++) {
          maxZIndex = (maxZIndex < createdModal[i].style.zIndex) ? createdModal[i].style.zIndex : maxZIndex
        }
        if (vnode.context.$props.modalType === 'popup') {
          maxZIndex = maxZIndex - 100
        }
        el.style.zIndex = Number(maxZIndex) + 2
      }
    }
  }
}
</script>

<style>
</style>
