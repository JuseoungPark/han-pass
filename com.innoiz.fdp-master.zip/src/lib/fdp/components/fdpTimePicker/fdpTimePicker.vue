<template>
  <vue-timepicker v-model="localTimeValue" :format="format" :minute-interval="minuteInterval" :second-interval="secondInterval" :hide-clear-button="hideClearButton" :ko="ko" :disabled="disabled"></vue-timepicker>
</template>

<script>
import VueTimepicker from './vue2-timepicker/vue-timepicker'

export default {
  name: 'fdp-time-picker',
  components: {
    VueTimepicker
  },
  props: {
    value: {
      type: Object,
      default: undefined
    },
    format: {
      type: String,
      default: 'HH:mm'
    },
    minuteInterval: {
      type: Number,
      default: undefined
    },
    secondInterval: {
      type: Number,
      default: undefined
    },
    hideClearButton: {
      type: Boolean,
      default: false
    },
    ko: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      localTimeValue: this.value
    }
  },
  watch: {
    value (newValue) {
      this.localTimeValue = newValue
    },
    localTimeValue (newValue) {
      this.$emit('input', newValue)
    }
  }
}
</script>

<style>
</style>
