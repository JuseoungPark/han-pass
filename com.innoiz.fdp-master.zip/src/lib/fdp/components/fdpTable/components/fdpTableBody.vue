<template>
  <div :class="wrapperClass" :style="wrapperStyle" @scroll="moveScroll" ref="fdpTableBodyScrollWrapper">
    <!-- [EMPTY] Empty table :: MESSAGE -->
    <div v-if="isEmpty && !(_slots.empty)">
      {{ops.emptyMessage}}
    </div>
    <span v-else-if="isEmpty && (_slots.empty)">
      <slot name="empty"></slot>
    </span>
    <!-- [BODY] ROWS -->
    <div v-for="(bRow, bRowIdx) in items" :key="bRowIdx">
      <div :class="rowClass(bRow)" :style="[rowStyle, hoverStyle(bRow), rowOddEvenStyle(bRowIdx)]" @click="onClickRow(bRow)" @mouseover="onMouseOver(bRow)" @mouseleave="onMouseleave(bRow)">
        <table-cell v-for="(bCol, bIdx) in ops.cols" :key="bCol.key" :item="bRow" :col="bCol" :ops="ops" :traceToColumnWidth="traceToColumnWidth" :idx="bIdx" @clickCustom="clickCustom"/>
      </div>
      <table-expand-row v-if="ops.expandable" v-show="(showExpandRows.indexOf(bRow) >= 0)" :item="bRow" :ops="ops"></table-expand-row>
    </div>
      <!-- [BODY] ROWS END -->
    <div v-show="ops.enableToIndexScroll && showIndexScroll" class="-fdp-table__body__index-scroll" :style="{'top' : (ops.headerHeight + Number(5)) + 'px', 'height': (ops.tableHeight - ops.headerHeight) + 'px'}">
      <div class="-fdp-table__body__index-scroll-alphabet" v-for="(alpha, aIdx) in alphabet" :key="aIdx" @click.stop="onClickIndexScroll(alpha)">{{alpha}}</div>
    </div>
  </div>
</template>

<script>
import CONST from '../util/tableConst'
import UTIL from '../util/tableUtil'

import tableCell from './fdpTableBodyCell'
import tableExpandRow from './fdpTableExpandRow'

export default {
  name: 'fdpTableBody',
  props: {
    ops: {},
    items: [Array, Object],
    value: [Array, Object],
    hover: [Array, Object],
    fixed: {
      type: Number,
      default: 0
    },
    traceToColumnWidth: {
      type: Boolean,
      default: false
    },
    _slots: {
      type: Object
    }
  },
  data () {
    return {
      isMounted: false,
      selected: [],
      showExpandRows: [],
      showIndexScroll: true,
      alphabet: ['ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ', 'A', 'F', 'O', 'Z'],
      indexer: {
        'ㄱ': 0,
        'ㄴ': 0,
        'ㄷ': 0,
        'ㄹ': 0,
        'ㅁ': 0,
        'ㅂ': 0,
        'ㅅ': 0,
        'ㅇ': 0,
        'ㅈ': 0,
        'ㅊ': 0,
        'ㅋ': 0,
        'ㅌ': 0,
        'ㅍ': 0,
        'ㅎ': 0,
        'A': 0,
        'F': 0,
        'O': 0,
        'Z': 0
      }
    }
  },
  components: {tableCell, tableExpandRow},
  created () {
    if (this._slots) {
      this.$slots = this._slots
    }
  },
  mounted () {
    this.isMounted = true
    this.selected = this.value
    if (this.ops.enableToIndexScroll) {
      this.setIndexScroll()
    }
  },
  computed: { /* no args, cacheable here */
    isEmpty: function () { return !UTIL.isArr(this.items) },

    wrapperClass: function () {
      var clazz = (this.fixed > 0) ? CONST.CLZ_BODY_WRAPPER_FIXED : CONST.CLZ_BODY_WRAPPER
      if (this.isEmpty) { clazz += ' ' + CONST.CLZ_BODY_EMPTY }
      return clazz
    },
    rowStyle: function () {
      return {
        'height': this.ops.rowHeight + 'px',
        'line-height': (this.ops.rowHeight - 1) + 'px'
      }
    },
    wrapperStyle: function () {
      if (!this.ops.noHeight && !this.isEmpty) {
        if (this.isMounted) {
          // 스크롤바 사이즈가 그려진 후 재계산을 위해 넣음.
          return {'height': getBodyHeight(this.ops, this.fixed, this) + 'px'}
        }
        return {'height': getBodyHeight(this.ops, this.fixed, this) + 'px'}
      } else {
        return {}
      }
    }
  },
  methods: {
    setIndexScroll () {
      let pivot = this.ops.enableToIndexScroll
      let that = this
      let scrollHeight = this.$el.scrollHeight
      let eachScrollHeight = (scrollHeight / this.items.length)
      let sumScrollValue = 0
      this.items.map((item, iIdx) => {
        let firstChar = UTIL.getFirstChar(item[pivot])
        let firstCharCode = firstChar.charCodeAt()
        if (that.indexer[firstChar] === undefined) {
          that.indexer[firstChar] = 0
        }
        if (firstCharCode >= 66 && firstCharCode <= 69) {
          // B to E in A
          that.indexer['A']++
          that.indexer[firstChar] = 0
        } else if (firstCharCode >= 71 && firstCharCode <= 78) {
          // G to N in F
          that.indexer['F']++
          that.indexer[firstChar] = 0
        } else if (firstCharCode >= 80 && firstCharCode <= 89) {
          // P to Y in O
          that.indexer['O']++
          that.indexer[firstChar] = 0
        } else {
          that.indexer[firstChar]++
        }
      })

      for (var key in this.indexer) {
        sumScrollValue += (this.indexer[key] * eachScrollHeight)
        this.indexer[key] = (sumScrollValue - (this.indexer[key] * eachScrollHeight))
      }
    },
    onClickIndexScroll (keyword) {
      this.$el.scrollTop = this.indexer[keyword]
    },
    moveScroll () {
      /* [EVENT] scroll : 마우스 스크롤 하면 이벤트를 위로(emit) 올립니다. */
      // 속도에 문제가 있을때는 따다다닥 하지 않게 기능 추가

      let scrollY = this.$el.scrollTop
      let scrollX = this.$el.scrollLeft
      let scrollHeight = this.$el.scrollHeight
      let scrollClassName = this.$el.className
      if (scrollClassName === CONST.CLZ_BODY_WRAPPER) {
        this.$emit(CONST.EVENT_SCROLL_MOVE, scrollX, scrollY, scrollHeight)
      }
    },
    onClickRow (bRow) {
      // expandable
      if (this.ops.expandable) {
        let expandRowIdx = this.showExpandRows.indexOf(bRow)
        if (expandRowIdx >= 0) {
          this.showExpandRows.splice(expandRowIdx, 1)
        } else {
          if (!this.ops.multiSelect) {
            this.showExpandRows.length = 0
          }
          this.showExpandRows.push(bRow)
        }
      }
      // clickable
      this.$emit(CONST.EVENT_CLICK_ROW, bRow)
      // if(!this.selected){return ''}
      if (!this.ops.multiSelect && !this.ops.singleSelect) { return }
      if (this.ops.multiSelect) {
        let selectedIdx = this.selected.indexOf(bRow)
        if (selectedIdx >= 0) {
          this.selected.splice(selectedIdx, 1)
        } else {
          this.selected.push(bRow)
        }
      } else {
        if (this.selected === bRow) {
          return
        } else {
          this.selected = bRow
        }
      }
      this.$emit(CONST.EVENT_INPUT, this.selected)
    },
    rowClass: function (bRow) {
      if (!this.selected) { return CONST.CLZ_BODY_ROW }

      return (this.selected.length) ? (((this.selected.indexOf(bRow) >= 0))
        ? CONST.CLZ_BODY_ROW_SELECTED : CONST.CLZ_BODY_ROW)
        : ((this.selected === bRow) ? CONST.CLZ_BODY_ROW_SELECTED : CONST.CLZ_BODY_ROW)
      // if(this.selected.length){
      // return ((this.selected.indexOf(bRow) >= 0))? CONST.CLZ_BODY_ROW_SELECTED : CONST.CLZ_BODY_ROW;
      // }
      // else{
      //   return (this.selected == bRow)? CONST.CLZ_BODY_ROW_SELECTED : CONST.CLZ_BODY_ROW;
      // }
    },
    hoverStyle (bRow) {
      return (this.hover === bRow) ? {
        'background-color': '#eee'
      } : {}
    },
    rowOddEvenStyle (rowIdx) {
      return (this.ops.rowOddEven) ? { 'background-color': (rowIdx % 2 === 0) ? this.ops.rowOddEvenOps.even : this.ops.rowOddEvenOps.odd } : {}
    },
    onMouseOver (bRow) {
      this.$emit(CONST.EVENT_MOUSE_OVER, bRow)
    },
    onMouseleave (bRow) {
      this.$emit(CONST.EVENT_MOUSE_LEAVE, [])
    },
    clickCustom (item) {
      this.$emit(CONST.EVENT_CLICK_CUSTOM, item)
    }
  }
}

/****************************
 * PRIVATE UTIL FUNCTIONS
 ****************************/

/** [BODY][UTIL] Body wrapper의 높이는 얼마일까? **/
function getBodyHeight (ops, fix, _this) {
  // 1. 전체 높이
  var totalHeight = ops.tableHeight
  // 2. header 개수
  var headerCount = 1 + ops.headerGroup.length
  // 3. header 높이
  var headerHeight = ops.headerHeight

  // 3. Bottom Scroll 넓이
  var bottomScrollBarSize = ops.bottomScrollBarSize
  if (Object.keys(_this.$refs).length > 0) {
    // 스크롤바 사이즈가 그려진 후 재계산을 위해 넣음.
    bottomScrollBarSize = _this.$refs.fdpTableBodyScrollWrapper.offsetHeight - _this.$refs.fdpTableBodyScrollWrapper.clientHeight
  }
  // x. calc Body height :: 전체 - (h개수 * h높이)
  return (fix > 0) ? (totalHeight - (headerCount * headerHeight)) : (totalHeight - (headerCount * headerHeight)) + bottomScrollBarSize
};
</script>

<style>/* @see fdp-component.css*/</style>
