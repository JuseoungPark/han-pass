<!-- <template>
    <component :is="cellComponent" :class="cellClass" :style="cellStyle" :item='item' :col="col"/>
</template> -->

<script>
import CONST from '../util/tableConst'

import cellDefault from './cells/fdpTableCellDefault'
import cellCode from './cells/fdpTableCellCode'
import cellDate from './cells/fdpTableCellDate'

/** * DOC : cell type
 * [default] : ---
 * code      : 코드 유형
 * date      : 날짜 타입
 * time      : (TBD) 날짜 + 시간?
 * number    : (TBD) 숫자 유형(abbr. = num)
 **/

export default {
  name: 'fdpTableCell',
  props: ['item', 'col', 'ops'],
  components: {
    cellDefault,
    cellCode,
    cellDate,
    customCellComp: function () {
      if (this.col.component && typeof this.col.component !== 'string') {
        return this.col.component
      }
    }},
  computed: {
    cellClass: function () {
      let clazz = CONST.CLZ_BODY_CELL
      if (this.col.type === 'right') { clazz += ' ' + CONST.CLZ_BODY_CELL_RIGHT }
      return clazz
    },
    cellStyle: function () { return {'width': this.col.widthText} },
    cellComponent: function () {
      let col = this.col
      if (col.component) {
        if (col.component !== 'string') { return col.component } else { return this.customCellComp }
      }

      switch (col.type) {
        case 'code' : return 'cell-code'
        case 'date' : return 'cell-date'
        case 'num' : return 'cell-default'
        case 'number': return 'cell-default'
        default: return 'cell-default'
      }
    }
  },
  methods: {
    clickCustom (item) {
      this.$emit(CONST.EVENT_CLICK_CUSTOM, item)
    },
  },
  render: function (createElement) {
    // 1. choose component
    let component = this.cellComponent
    // 2. arguments
    // 2.1 default args
    let args = {}
    args['style'] = this.cellStyle
    args['class'] = this.cellClass
    args['props'] = {item: this.item, col: this.col}
    args['on'] = {clickCustom: this.clickCustom}
    // 3 additional something...
    // 3.1 date component : 포멧이 필요해요, 이거때매 render로 뺀거긴 함니다요...
    if (this.col.type === 'date') {
      args['props']['dateFormat'] = this.ops.value.dateFormat
    }
    return createElement(component, args)
  }
}
</script>

<style>/* @see fdp-component.css*/</style>
