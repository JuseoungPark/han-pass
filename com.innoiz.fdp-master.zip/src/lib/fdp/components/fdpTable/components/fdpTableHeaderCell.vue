<template>
  <div :class="elClass" :style="[headerCellStyle, headerCellOpsStyle]">
    <fdp-checkbox v-if="item.type === 'checkbox'" v-model="headerCheckboxModel" @click.native="onHeaderClickCk"></fdp-checkbox>
    <div v-else :class="{'-fdp-table__header__selected-header':(selectedHeaderKey === item.name)}" @click.stop="onClickHeaderCell">
      {{ item.name }}
      <div v-if="item.sort" :class="{'-fdp-table__sort-icon-desc': (item.sort === 'desc'), '-fdp-table__sort-icon-asc': (item.sort === 'asc')}"
           @click="onSortClick"></div>
      <div :class="moveBarClass" v-if="ops.headerResize" :style="headerMoveBarCellStyle"
           @mouseover="onTraceHeaderWidthOver" @mouseleave="onTraceHeaderWidthLeave" @mousedown="onTraceHeaderWidthDown" @mouseup="onMouseUpCell"></div>
    </div>
  </div>
</template>

<script>
import CONST from '../util/tableConst'
import UTIL from '../util/tableUtil'

export default {
  name: 'fdpTableHeaderCell',
  props: {
    item: {},
    ops: {
      type: Object,
      default: () => ({})
    },
    allSelected: {
      type: [Array, Object]
    },
    dataMaxCnt: {
      type: Number,
      default: 0
    },
    idx: {
      type: [Number, String],
      default: 0
    },
    selectedHeaderKey: {
      type: [Number, String],
      default: -1
    }
  },
  components: {},
  data () {
    return {
      headerCheckboxModel: false,
      mouse: false
    }
  },
  mounted () {
    // console.log('header cell mounted')
    // document.documentElement.addEventListener('mouseup', this.onMouseUp);
  },
  beforeDestroy: function () {
    // document.documentElement.removeEventListener('mouseup', this.onMouseUp);
  },
  watch: {
    allSelected (newValue) {
      this.headerCheckboxModel = (this.allSelected.length === this.dataMaxCnt)
    }
  },
  computed: {
    elClass () { return CONST.CLZ_HEADER_ELEMENT },
    moveBarClass () { return CONST.CLZ_HEADER_MOVE_BAR },
    headerMoveBarCellStyle () {
      return {
        'height': (this.ops.headerHeight * (this.item.spanCnt || 1)) + 'px',
        'left': (UTIL.regNum(this.item.width) - 10) + 'px',
        'border-right': this.mouse && this.ops.headerResize ? '2px solid #aaa' : '2px dashed #aaa'
      }
    },
    hHeight: function () { return this.ops.headerHeight },
    headerCellOpsStyle () {
      return (this.item.headerStyle)
    },
    // 각 헤더 Cell별 Style
    headerCellStyle () {
      let rtn = {}
      rtn['width'] = this.item.width
      rtn['left'] = this.item.left // 여기서 뿌려주면 되지.
      rtn['bottom'] = '0'
      rtn['height'] = (this.hHeight * (this.item.spanCnt || 1)) + 'px'
      rtn['line-height'] = (this.hHeight * (this.item.spanCnt || 1)) + 'px'
      rtn['cursor'] = this.item.sort ? 'pointer' : ''
      return rtn
    }

  },
  methods: {
    onTraceHeaderWidthOver (e) {
      this.mouse = true
    },
    onTraceHeaderWidthLeave () {
      this.mouse = false
    },
    onTraceHeaderWidthDown (e) {
      this.$emit(CONST.EVENT_TRACE_HEADER_WIDTH, e.pageX, UTIL.regNum(this.item.width), this.idx)
    },
    onMouseUpCell (e) {
      this.$emit(CONST.EVENT_MOUSE_UP, e)
    },
    onHeaderClickCk () {
      this.$emit(CONST.EVENT_HEADER_CHECKBOX, this.item)
    },
    onSortClick () {
      this.$emit(CONST.EVENT_HEADER_SORT, this.item)
    },
    onClickHeaderCell () {
      this.$emit(CONST.EVENT_CLICK_HEADER_CELL, this.item)
    }
  }
}
</script>

<style>/* @see fdp-component.css*/</style>
