<!-- <template>
    <component :is="cellComponent" :class="cellClass" :style="cellStyle" :item='item' :col="col"/>
</template> -->

<script>
import CONST from '../util/tableConst'

import cellDefault from './cells/fdpTableCellDefault'
import cellCode from './cells/fdpTableCellCode'
import cellDate from './cells/fdpTableCellDate'

/** * DOC : cell type
 * [default] : ---
 * code      : 코드 유형
 * date      : 날짜 타입
 * time      : (TBD) 날짜 + 시간?
 * number    : (TBD) 숫자 유형(abbr. = num)
 **/

export default {
  name: 'fdpTableBodyCell',
  props: {
    item: {},
    col: {
      type: [Array, Object],
      default: () => ({})
    },
    ops: {
      type: Object,
      default: () => ({})
    },
    idx: {
      type: [Number, String],
      default: 0
    },
    traceToColumnWidth: {
      type: Boolean,
      default: false
    }
  },
  components: {
    cellDefault,
    cellCode,
    cellDate,
    customCellComp: function () {
      if (this.col.component && typeof this.col.component !== 'string') {
        return this.col.component
      }
    }
  },
  beforeUpdate () {
    // console.log('==== Body Cell Before Update ====')
  },
  updated () {
    // console.log('==== Body Cell Update ====')
  },
  computed: {
    cellClass: function () {
      let clazz = CONST.CLZ_BODY_CELL
      if (this.col.type === 'right') { clazz += ' ' + CONST.CLZ_BODY_CELL_RIGHT }
      return clazz
    },

    cellOpsStyle: function () {
      return (this.col.bodyStyle) ? (this.col.bodyStyle) : {}
    },
    cellComponent: function () {
      let col = this.col
      if (col.component) {
        if (col.component !== 'string') { return col.component } else { return this.customCellComp }
      }

      switch (col.type) {
        case 'code' : return 'cell-code'
        case 'date' : return 'cell-date'
        case 'num' : return 'cell-default'
        case 'number': return 'cell-default'
        default: return 'cell-default'
      }
    }
  },
  render: function (createElement) {
    // console.log('==== Body Cell Render ====')
    // 1. choose component
    let component = this.cellComponent
    // 2. arguments
    // 2.1 default args
    let args = {}
    args['style'] = [this.cellStyle(), this.cellOpsStyle]
    args['class'] = this.cellClass
    // args['props'] = {item:this.item, col:this.col};
    args['props'] = {item: this.item, col: this.col, traceToColumnWidth: this.traceToColumnWidth}
    args['on'] = {clickCustom: this.clickCustom}
    // 3 additional something...
    // 3.1 date component : 포멧이 필요해요, 이거때매 render로 뺀거긴 함니다요...
    if (this.col.type === 'date') {
      args['props']['dateFormat'] = (this.col.dateFormat) ? this.col.dateFormat : 'yyyy-mm-dd'
    }
    return createElement(component, args)
  },
  methods: {
    cellStyle () {
      return {'width': this.ops.cols[this.idx].widthText}
      // return {'width':this.col.widthText};
    },
    clickCustom (item) {
      this.$emit(CONST.EVENT_CLICK_CUSTOM, item)
    }
  }
}
</script>

<style>/* @see fdp-component.css*/</style>
