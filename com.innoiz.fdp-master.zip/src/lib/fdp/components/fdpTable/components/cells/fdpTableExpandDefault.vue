<template>
  <div>
    <b>{{item.idx}}.</b> {{item.exp}}
  </div>
</template>

<script>
export default {
  name: 'expand-default',
  props: ['item']
}
</script>

<style>
</style>
