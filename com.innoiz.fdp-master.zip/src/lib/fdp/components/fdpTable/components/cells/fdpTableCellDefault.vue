<template>
    <div>{{item[col.key]}}</div>
</template>

<script>
/** 쪽지 :
 *    이게 구지 필요할까 싶긴 한데... 나중에 cell이 복잡해져서
 *    기본적인 기능을 가지고 있어야 하는 경우가 생긴다면
 *    (cell click이나, 우클릭 contenxt menu?)
 *    약간 template 느낌으로 갈 수도 있고,
 *    될렁가 모르겠는데, 혹시 mixins로 재활용도 가능하지 않을지...
 */
export default {
  props: ['item', 'col']
}
</script>
