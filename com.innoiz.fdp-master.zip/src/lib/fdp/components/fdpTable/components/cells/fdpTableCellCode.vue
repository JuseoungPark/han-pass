<template>
    <div :class="cellClass">{{myValue}}</div>
</template>

<script>
import CONST from '../../util/tableConst'

export default {
  props: ['item', 'col'],
  computed: {
    cellClass: function () { return CONST.CLZ_BODY_CELL_CODE },
    myValue: function () {
      let m = this.col.map
      let v = this.item[this.col.key]
      // 1. cannot found MAP
      if (!m) { return v }
      // 2. map is Map
      if (m instanceof Map) {
        return m.get(v)
      } else {
        return m[v]
      }
      // 3. map is not Map, Object base?
    }
  }
}
</script>
