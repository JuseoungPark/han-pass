<template>
</template>

<script>
/**
 * 개발 안했어요, 세자리 단위 콤마나, prefix/postfix
 * 천단위 끊어서 k,m,b,t 찝어준다거나 생각을 하긴 했는데...
 * 귀찮으면 그냥 모래로 묻어도... 
 */
export default {props:['item','col']}
</script>
