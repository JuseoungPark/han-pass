<template>
  <div :class="cellClass">{{myValue}}</div>
</template>

<script>
import CONST from '../../util/tableConst'
import UTIL from '../../util/tableUtil'

/** 쪽지 :
 *     만약 나중에 여기서 date, time, datetime을 처리할 생각이라면
 *     cols의 type을 까부숴서 그 type만 이쪽으로 props처리한담에
 *     myValue에서 UTIL function만 갈아 끼우는 선택을 할수도 있을듯요.
 */

export default {
  props: ['item', 'col', 'dateFormat'],
  computed: {
    cellClass: function () { return CONST.CLZ_BODY_CELL_CODE },
    myValue: function () {
      let v = this.item[this.col.key]
      return UTIL.dateFormat(new Date(v), this.dateFormat)
    }
  }
}
</script>
