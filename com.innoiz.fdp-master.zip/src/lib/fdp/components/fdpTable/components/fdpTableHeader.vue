<template>
  <div :class="wrapperClass">
    <div :class="rowClass" v-for="(hRow, hrIdx) in hModel" :key="hrIdx" :style="headerRowStyle()" @mouseup="onMouseUp" @mousemove="onMousemove">
      <!-- 여기가 컴포넌트 화 해야 할 듯-->
      <!-- 요 아래 하나하나가 Table Header Cell-->
      <!--<table-cell v-for="hItem in hRow" :item="hItem" :key="hItem.key"></table-cell>-->
      <div v-for="(hItem, hIdx) in hRow" :key="hIdx">
        <table-cell :item="hItem" :allSelected="allSelected" :dataMaxCnt="dataMaxCnt" :ops="ops" :idx="hIdx" :selectedHeaderKey="selectedHeaderKey"
                    @headerSort="onHeaderSort" @headerCheckbox="onHeaderCheckbox" @traceHeaderWidth="onTraceHeaderWidth" @clickHeaderCell="onClickHeaderCell"></table-cell>
        <!--{{hItem.name}}-->
      </div>
    </div>
  </div>
</template>

<script>
import CONST from '../util/tableConst'
import tableCell from './fdpTableHeaderCell'

/* 까먹을까바 남깁니다. TODO :
 *   나중에 저 headerEl 쪽은 component로 빠질 계획입니다.
 *   그 안에는 "정렬"용 icon과, "컬럼 폭 조정"용 객체라던지, "dragable?" 흐음...
 *   icon을 어떻게 할지도 고민해봐야 겠군요
 */

export default {
  name: 'fdpTableHeader',
  props: {
    hModel: {},
    ops: {},
    fixed: {
      type: Number,
      default: 0
    },
    allSelected: {
      type: [Array, Object]
    },
    dataMaxCnt: {
      type: Number,
      default: 0
    },
    traceClicked: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      beforeX: 0,
      currentWidth: 0,
      currentIdx: 0,
      // traceClicked: false,
      minimumCellWidth: 20,
      selectedHeaderKey: ''
    }
  },
  components: {tableCell},
  computed: {
    // 각 Row의 높이
    hHeight: function () { return this.ops.headerHeight },
    wrapperClass: function () { return (this.fixed > 0) ? CONST.CLZ_HEADER_WRAPPER_FIXED : CONST.CLZ_HEADER_WRAPPER },
    // 각 Row 클래스
    rowClass: function () { return CONST.CLZ_HEADER_ROW }
    // 각 헤더 Cell 클래스

  },
  methods: {
    // 각 헤더 Row별 Stryle
    headerRowStyle () {
      let hRowStyle = {}
      hRowStyle['background-color'] = (this.ops.headerBackgroundColor)
      hRowStyle['color'] = (this.ops.headerColor)
      hRowStyle['height'] = (this.hHeight + 'px')
      return hRowStyle
    },
    // 각 헤더 Row별 Stryle
    // headerFixedRowStyle() {
    //   let hFixedRowStyle = {};
    //   hFixedRowStyle['background-color'] = (this.ops.headerBackgroundColor);
    //   hFixedRowStyle['color'] = (this.ops.headerColor);
    //   hFixedRowStyle['height'] = (this.hHeight+"px");
    //   hFixedRowStyle['position'] = 'absolute';
    //   return hFixedRowStyle;
    // },
    onHeaderSort (hItem) {
      this.$emit(CONST.EVENT_HEADER_SORT, hItem.name, hItem.sort)
      hItem.sort = (hItem.sort === 'asc') ? 'desc' : 'asc'
    },
    onHeaderCheckbox (item) {
      this.$emit(CONST.EVENT_HEADER_CHECKBOX, item)
    },
    onMouseUp (e) {
      if (this.traceClicked) {
        let term = (e.pageX - this.beforeX)
        this.currentWidth += term
        this.$emit(CONST.EVENT_CHANGE_COLUMN_WIDTH,
          (this.currentWidth < this.minimumCellWidth) ? this.minimumCellWidth : this.currentWidth, this.currentIdx, false)
        // this.traceClicked = false
      }
    },
    onTraceHeaderWidth (beforeX, currentWidth, currentIdx) {
      this.beforeX = beforeX
      this.currentWidth = currentWidth
      this.currentIdx = currentIdx
      this.$emit(CONST.EVENT_HEADER_CELL_WIDTH_CLICK, true)
      // this.traceClicked = true
    },
    onMousemove (e) {
      if (this.traceClicked) {
        this.$emit(CONST.EVENT_TRACE_COLUMN_LINE, e.pageX)
      }
    },
    onClickHeaderCell (item) {
      this.selectedHeaderKey = item.name
    }
  }
}
</script>

<style>/* @see fdp-component.css*/</style>
