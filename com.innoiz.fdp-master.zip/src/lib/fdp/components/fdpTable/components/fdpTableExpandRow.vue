
<script>
import CONST from '../util/tableConst'
import UTIL from '../util/tableUtil'

import expandRowDefault from './cells/fdpTableExpandDefault'

export default {
  name: 'fdpTableExpandRow',
  props: {
    item: {},
    ops: {
      type: Object,
      default: () => ({})
    }
  },
  components: {
    expandRowDefault
  },
  computed: {
    expandRowClass: function () {
      return CONST.CLZ_EXPAND_ROW
    },
    expandRowStyle () {
      return {
        'line-height': (this.ops.expandOps.style && this.ops.expandOps.style['height']) ? ((UTIL.regNum(this.ops.expandOps.style['height']) - 1)) + 'px' : (this.ops.rowHeight - 1) + 'px'
      }
    },
    expandRowOpsStyle () {
      return this.ops.expandOps.style
    },
    expandRowComponent: function () {
      let ops = this.ops

      // custom row component 던질 경우
      if (ops.component) {
        if (ops.component !== 'string') { return ops.component } else { return this.customCellComp }
      }

      switch (ops.type) {
        // case 'code'  : return 'cell-code';
        // case 'date'  : return 'cell-date';
        // case 'num'   : return 'cell-default';
        // case 'number': return 'cell-default';
        default: return 'expand-row-default'
      }
    }
  },
  render: function (createElement) {
    // 1. choose component
    let component = this.expandRowComponent
    // 2. arguments
    // 2.1 default args
    let args = {}
    args['style'] = [this.expandRowStyle, this.expandRowOpsStyle]
    args['class'] = this.expandRowClass
    args['props'] = {item: this.item}
    // 3 additional something...
    // 3.1 date component : 포멧이 필요해요, 이거때매 render로 뺀거긴 함니다요...
    return createElement(component, args)
  }
}
</script>

<style>/* @see fdp-component.css*/</style>
