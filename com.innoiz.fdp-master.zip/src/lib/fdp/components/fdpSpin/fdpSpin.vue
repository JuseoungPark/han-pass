<template>
  <div class="-fdp-spin">
    <button type="button" class="-fdp-spin__button -fdp-spin--minus" @click="onStep('minus')" :disabled="localValue===min">-</button>
    <fdp-text-field type="number" class="-fdp-spin__input" v-model="localValue"
           @blur="onBlur" ref="spinInput" :readonly="readonly" :virtual="virtual"></fdp-text-field>
    <button type="button" class="-fdp-spin__button -fdp-spin--plus" @click="onStep('plus')" :disabled="localValue===max">+</button>
  </div>
</template>

<script>
export default {
  name: 'fdp-spin',
  props: {
    value: {
      type: Number,
      default: 0
    },
    step: {
      type: Number,
      default: 1
    },
    max: {
      type: Number,
      default: 1000
    },
    min: {
      type: Number,
      default: 0
    },
    readonly: {
      type: Boolean,
      default: false
    },
    virtual: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      localValue: this.value.toString()
    }
  },
  mounted () {
    this.localValue = this.checkNumber(this.value)
  },
  watch: {
    localValue (newValue) {
      this.$emit('input', Number(newValue))
    }
  },
  methods: {
    onBlur (param) {
      this.localValue = this.checkNumber(this.localValue)
    },
    checkNumber (targetNum) {
      targetNum = Number(targetNum)
      if (isNaN(targetNum) || targetNum < this.min) {
        targetNum = this.min
      } else if (targetNum > this.max) {
        targetNum = this.max
      }
      return Number(targetNum.toFixed(1)).toString()
    },
    onStep (type) {
      if (type === 'plus') {
        this.localValue = this.checkNumber(Number(this.localValue) + this.step)
      } else {
        this.localValue = this.checkNumber(Number(this.localValue) - this.step)
      }
    }
  }

}
</script>

<style>

</style>
