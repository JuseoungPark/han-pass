<template>
  <div class="-fdp-list" :class="{'-fdp-list--horizontal': horizontal}" :style="{'height': listHeight + 'px'}" @scroll="onScroll" ref="fdpList">
    <div v-if="listData.length === 0" class="-fdp-list__empty-view">
      <slot name="emptyView"></slot>
    </div>
    <ul class="-fdp-list__list" v-else>
      <li v-for="(item, index) in listData" :key="index" class="-fdp-list__item">
        <slot :item="item" :index="index"></slot>
      </li>
    </ul>
  </div>
</template>

<script>
/**
 * 이름 : fdp-list
 * 설명 : 추가 로드 기능이 있는 데이터 목록
 * 최종 수정 일시 : 2018 - 10 - 29
 */
export default {
  name: 'fdp-list',
  props: {
    listData: { // 화면에 표현될 데이터 목록
      type: Array,
      default: () => []
    },
    listHeight: { // 리스트가 화면에서 차지할 영역 높이. ( 추가로딩을 위해 필요 )
      type: [String, Number],
      default: 300
    },
    isLoading: { // 반복적 재로딩을 막기 위한 로딩상태
      type: Boolean,
      default: false
    },
    horizontal: { // 가로스크롤 list
      type: Boolean,
      default: false
    }
  },
  methods: {
    onScroll (e) { // 스크롤이 움직이는 순간에 항상 불리며, 아래 특정시점에 추가로드를 작동하도록 되어있다.
      if (this.horizontal) {
        // 가로스크롤인 경우 추가로드
        let currentScrollPoint = e.srcElement.scrollLeft
        // 로딩이 현재 진행중이 아니며&& 현재 리스트가 비어있지 않으며 (이미 노데이터상태가 아닌경우) && 현재 스크롤 포인트가 목록의 맨 오른쪽(실제로는 맨 오른쪽 30px 전)에 와 있는 경우
        if (!this.isLoading && this.listData.length > 0 && currentScrollPoint >= e.srcElement.scrollWidth - e.srcElement.clientWidth - 30) {
          this.$emit('loading-data') // 데이터 로딩하라고 부모에게 알려준다
        }
      } else {
        // 세로스크롤인 경우 추가로드
        let currentScrollPoint = e.srcElement.scrollTop
        // 로딩이 현재 진행중이 아니며&& 현재 리스트가 비어있지 않으며 (이미 노데이터상태가 아닌경우) && 현재 스크롤 포인트가 목록의 맨 마지막(실제로는 맨 아래 30px 전)에 와 있는 경우
        if (!this.isLoading && this.listData.length > 0 && currentScrollPoint >= e.srcElement.scrollHeight - e.srcElement.clientHeight - 30) {
          this.$emit('loading-data') // 데이터 로딩하라고 부모에게 알려준다
        }
      }
    },
    scrollStart () { // 스크롤을 맨 위 또는 맨 왼쪽으로 올려주는 메서드
      if (this.horizontal) {
        this.$refs.fdpList.scrollLeft = 0
      } else {
        this.$refs.fdpList.scrollTop = 0
      }
    }
  }
}
</script>

<style>
</style>
