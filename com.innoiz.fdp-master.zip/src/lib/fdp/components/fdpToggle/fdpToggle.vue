<template>
  <label class="-fdp-toggle" :class="{'-fdp-toggle--disabled':disabled}">
    <input class="-fdp-toggle__box-area" type="checkbox" v-model="value" :disabled="disabled" :class="{'-fdp-toggle--disabled':disabled}">
    <span class="-fdp-toggle__box-slider round" :class="{'-fdp-toggle--disabled':disabled}"></span>
  </label>
</template>
<script>
export default {
  name: 'fdp-toggle',
  props: {
    value: {type: Boolean, required: true, default: false},
    disabled: {type: Boolean, default: false}
  },
  watch: {
    value: function () {
      this.$emit('input', this.value)
    }
  }
}
</script>
<style>

</style>
