<template>
  <div class="cv-header">
    <div class="cv-header-nav">
      <button :disabled="!headerProps.previousPeriod" class="previousPeriod" @click="onInput(headerProps.previousPeriod)">&lt;</button>
      <fdp-date-picker format='yyyy 년 MM 월' v-model="inputDate" minimumView='month' initialView='month'></fdp-date-picker>
      <button :disabled="!headerProps.nextPeriod" class="nextPeriod" @click="onInput(headerProps.nextPeriod)">&gt;</button>
      <button class="currentPeriod" @click="onToday(headerProps.currentPeriod)">Today</button>
    </div>
  </div>
</template>
<script>
/**
 * 이름 : fdp-scheduler-header
 * 설명 : fdp-scheduler 에 넣어줄 달력 컴포넌트를 가지고 있는 header
 * 최종 수정 일시 : 2018 - 11 - 02
 */
export default {
  name: 'fdp-scheduler-header',
  props: {
    headerProps: { // 오픈소스에서 정의하고 있는 headerProps가 넘어온다. 오브젝트가 가지고 있는 속성이 너무 많아서, 세부내용은 CalendarView.vue파일의 동일한 이름의 객체 참고.
      type: Object,
      required: true
    }
  },
  data () {
    return {
      inputDate: '' // 달력 컴포넌트에 표기될 값
    }
  },
  watch: {
    // 화살표 버튼으로 이동한 경우 달력 컴포넌트에도 값을 동일하게 맞춰 주어야한다.
    inputDate: function () {
      this.$emit('input', new Date(this.inputDate))
    }
  },
  methods: {
    // 오늘날짜로 이동하는 함수
    onToday (d) {
      var timezoneOffset = d.getTimezoneOffset() * 60000
      this.inputDate = new Date(new Date() - timezoneOffset).toISOString()
    },
    // 앞뒤로 버튼을 누른 경우 해당 기간만큼 이동하도록 하는 함수
    onInput (d) {
      var timezoneOffset = d.getTimezoneOffset() * 60000
      this.inputDate = new Date(d - timezoneOffset).toISOString()
    }
  }
}
</script>
