<template>
      <calendar-view
          ref="calendarView"
          :show-date="showDate"
          class="-fdp-scheduler"
          :class="{'shrink':shrink}"
          :events ="events"
          @click-event="clickEvent"
          @click-date="clickDate"
          :displayPeriodUom = displayPeriodUom
          :displayPeriodCount = displayPeriodCount
          :period-changed-callback="periodChanged">
      <fdp-scheduler-header
          slot="header"
          slot-scope="t"
          class = "-fdp-scheduler__header"
          :header-props="t.headerProps"
          @input="setShowDate"/>
      </calendar-view>
</template>
<script>
/**
 * 이름 : fdp-scheduler
 * 설명 : 일정표기, 이벤트 표기 등을 위한 스케줄러 컴포넌트
 * 최종 수정 일시 : 2018 - 11 - 02
 */
// 오픈소스인 vue-simple-calendar의 소스를 수정하여사용하므로, node-modules 이용하지 않고 따로 이식하였다.
import {CalendarView} from './vueSimpleCalendar/components/bundle.js'
// 헤더 부분을 그려주기 위해서는 직접 다른 헤더 파일을 생성하거나, 혹은 현재 작성해둔 fdp-scheduler-header를 사용한다.
import fdpSchedulerHeader from './fdpSchedulerHeader'
export default {
  name: 'fdp-scheduler',
  props: {
    displayPeriodUom: { // 화면에 그려질 스케줄러 단위 ( 월 / 주 )
      type: String,
      default: 'month'
    },
    displayPeriodCount: { // 위의 displayPeriodUom 을 몇개씩 로드 할 것인지
      type: Number,
      default: 1
    },
    events: { // 스케줄러에 표기될 일정 정보를 오브젝트 어레이로 받는다.
      type: Array,
      required: true
    },
    shrink: { // 화면크기조정을 위해 shrink 여부를 받는다
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      showDate: new Date() // 기본적으로 로드시점에 오늘날짜로 포커스되게 만들었다. 필요한 경우 지정할 수 있도록 props로 빼도 괜찮다.
    }
  },
  components: {
    CalendarView,
    fdpSchedulerHeader
  },
  methods: {
    setShowDate (d) { // 헤더에서 날짜가 변경되면 해당 날짜로 아래 스케줄러부분도 동일하게 싱크를 맞춰준다.
      this.showDate = d
    },
    clickEvent (event) {
      // 일정(이벤트)가 클릭되는 경우 불린다.
      // 현재는 Event div가 날짜보다 뒤에 깔려 있는 구조라 불릴 일이 없으나. z-index를 화면에서 강제로 수정한다던지 하는 방법으로 위로 꺼내는 경우에는 사용 가능하다.
      this.$emit('click-event', event)
    },
    clickDate (date) {
      // 날짜 한 칸이 클릭되는 경우 불린다.
      // 클릭된 날의 스타일을 변경 해 주고, 그대로 언제가 클릭되었는지 부모에게 emit으로 전달한다.
      var tempDate = 'd' + new Date(date - date.getTimezoneOffset() * 60 * 1000).toISOString().substring(0, 10)
      if (document.getElementsByClassName('clicked-day').length > 0) {
        document.getElementsByClassName('clicked-day')[0].classList.remove('clicked-day')
      }
      document.getElementsByClassName(tempDate)[0].classList.add('clicked-day')
      this.$emit('click-date', date)
    },
    periodChanged (data) {
      // 화면에 보여지는 기간이 변경된경우, 외부화면으로 동일한 데이터 객체를 들고 emit하도록 하였다.
      this.$emit('period-changed', data)
    }
  }
}
// 스타일의 경우, 강제로 폰트값을 important지정하거나, 임시로 정의한 값이 있으니 적절히 수정 및 override 하여 사용하도록한다.
</script>
