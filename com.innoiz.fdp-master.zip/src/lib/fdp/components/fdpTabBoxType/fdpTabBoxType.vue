<template>
    <div class="-fdp-tab-box-type">
        <ul class="-fdp-tab-box-type__header">
            <li v-for="(item,idx) in tabItems" :key="idx" @click="changeIdx(idx)" :class="{'-fdp-tab-box-type--active':selectedIndex == idx, '-fdp-tab-box-type--checked':item.checked}" class="-fdp-tab-box-type__header-item">
                <strong class="-fdp-tab-box-type__header-item__title">{{item.tabTitle}}</strong>
                <span class="-fdp-tab-box-type__header-item__subTitle">{{item.tabSubTitle}}</span>
            </li>
        </ul>
        <div v-if="selectedIndex !==-1" class="-fdp-tab-box-type__cont">
            <keep-alive>
                <slot></slot>
            </keep-alive>
        </div>
    </div>
</template>

<script>
/**
 * 이름 : fdp-tab-box-type
 * 설명 : 박스모양으로 인덱스를 가지는tab 으로, 내부 내용에 대해 체크가 완료되면 인덱스에 완료표기가 된다.
 * 최종 수정 일시 : 2018 - 09 - 10
 */
export default {
  name: 'fdp-tab-box-type',
  props: {
    defaultSelectedIdx: {Type: Number, default: -1}, // 최초 선택된 탭 인덱스 번호 (default: -1 미선택)
    tabItems: {Type: Array, required: true} // tabTitle: 탭 제목, tabSubTitle: 탭 부제목, checked: 탭 체크 상태
  },
  data: function () {
    return {
      selectedIndex: this.defaultSelectedIdx // 현재 선택된 탭 인덱스 보관
    }
  },
  methods: {
    // 선택된 인덱스 번호가 바뀌는 경우 불리는 함수. (탭을 선택하면 불리고 외부에서 ref를 준경우 강제로 부를 수 도 있다) 부모 화면으로 @change-tab-idx를 통해 선택된 idx를 전달
    changeIdx (idx) {
      this.selectedIndex = idx
      this.$emit('change-tab-idx', idx)
    }
  }
}
</script>

<style>

</style>
