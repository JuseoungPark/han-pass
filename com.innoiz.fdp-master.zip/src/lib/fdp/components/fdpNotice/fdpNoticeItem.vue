<template>
  <transition name="-fdp-notice-item-fade">
    <div v-show="value" class="-fdp-notice-item" @click="noticeItemClick">
        <div class="-fdp-notice-item__icon"></div>
        <div class="-fdp-notice-item__type">{{noticeObject.noticeType}}</div>
        <div class="-fdp-notice-item__content">{{ noticeObject.content }}</div>
        <div class="-fdp-notice-item__close-image"  @click.stop="closeButtonClick"></div>
    </div>
  </transition>
</template>

<script>
/**
 * 이름 : fdp-notice-item
 * 설명 : 상단부 notice로 뜨는 객체
 * 최종 수정 일시 : 2018 - 09 - 06
 */
export default {
  name: 'fdp-notice-item',
  props: {
    value: {type: Boolean, default: true}, // 보임 여부 - 최초 1회
    duration: {type: Number, default: 300000}, // 지속 시간 ( 기본 : 5분 )
    noticeObject: {type: Object, required: true} // notice 를 구성할 object - noticeKey, noticeType, noticeContent를 포함
  },
  mounted () {
    // 생성됨과 동시에 타이머를 시작
    this.startTimer()
  },
  methods: {
    // 정의된 duration 시간 이후, 해당 noticeItem에 대해 destroyElement() 를 부르도록 하는 함수
    startTimer () {
      if (this.duration > 0) {
        let _this = this
        setTimeout(() => {
          _this.destroyElement()
        }, _this.duration)
      }
    },
    // noticeKey를 @change로 부모에게 전달 (자동으로 꺼지는 경우, transition 거쳐 꺼짐)
    destroyElement () {
      let _this = this
      setTimeout(() => {
        _this.$emit('change', _this.noticeObject.noticeKey)
      }, 500)
    },
    // noticeKey를 @change로 부모에게 전달 (닫기 버튼 누른 경우, 즉각적으로 꺼짐)
    closeButtonClick () {
      this.$emit('change', this.noticeObject.noticeKey)
    },
    // noticeObject를 @notice-item-click로 부모에게 전달
    noticeItemClick () {
      this.$emit('notice-item-click', this.noticeObject)
    }
  }
}
</script>

<style>

</style>
