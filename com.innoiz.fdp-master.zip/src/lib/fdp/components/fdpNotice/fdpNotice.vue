<template>
  <div class="-fdp-notice">
    <fdp-notice-item v-for="(notice) in localNoticeArray" :key="notice.noticeKey" @change="onChange"
                v-model="notice.isShow" :noticeObject="notice" @notice-item-click="noticeItemClick"></fdp-notice-item>
  </div>
</template>

<script>
/**
 * 이름 : fdp-notice
 * 설명 : noticeItem 을 wrapping하는 컴포넌트. 로컬형 공지 - 프로젝트에서는 vuex적용하여 사용
 * 최종 수정 일시 : 2018 - 09 - 05
 */
import fdpNoticeItem from './fdpNoticeItem'

export default {
  name: 'fdp-notice',
  components: {
    fdpNoticeItem
  },
  data () {
    return {
      localNoticeArray: [], // 해당 화면에서 관리하는 notice객체 배열
      uuid: 0 // notice 객체의 고유 noticeKey값을 부여하기 위한 변수
    }
  },
  methods: {
    // noticeItem을 추가하는 메서드. Object형으로 받은 경우와 string으로 메세지만 받은 경우로 나뉨
    makeNotice (noticeObject) {
      if (typeof (noticeObject) === 'object') {
        var noticeObjectModified = Object.create(noticeObject)
        if (!noticeObjectModified.noticeKey) {
          noticeObjectModified.noticeKey = this.uuid++
        }
        if (!noticeObjectModified.noticeType) {
          noticeObjectModified.noticeType = '시스템 공지'
        }
        if (!noticeObjectModified.content) {
          noticeObjectModified.content = ''
        }
        this.localNoticeArray.push(noticeObjectModified)
      } else {
        this.localNoticeArray.push({ noticeKey: this.uuid++, noticeType: '시스템 공지', content: noticeObject })
      }
    },
    // noticeKey로 해당 공지를 찾아서 array에서 제거
    onChange (noticeKey) {
      this.localNoticeArray.splice(this.localNoticeArray.map(x => x.noticeKey).indexOf(noticeKey), 1)
    },
    // 부모 화면에 noticeObject를 @notice-item-click로 전달 (화면 이동시, Key 외에도 필요한 변수가 있을 수 있음)
    noticeItemClick (noticeObject) {
      this.$emit('notice-item-click', noticeObject)
    }
  }
}
</script>
