<template>
  <div class="-fdp-pagination">
    <div v-show="showArrowBtn" class="-fdp-pagination__move-left-first" @click.stop="onClickLeftFirst" :style="{ 'cursor': this.isLeftEnd? 'default' : 'pointer' }"></div>
    <div v-show="showArrowBtn" class="-fdp-pagination__move-left"  @click.stop="onClickLeft" :style="{ 'cursor': this.isLeftEnd? 'default' : 'pointer' }"></div>
       <span v-for="(n, index) in range" :key="index" @click="onClickPage(n)" class="-fdp-pagination__range-area" :style="{ 'color': (n === value)? 'blue' : 'black' }">
        {{ n }}
      </span>
    <div v-show="showArrowBtn" class="-fdp-pagination__move-right" @click.stop="onClickRight"  :style="{ 'cursor': this.isRightEnd? 'default' : 'pointer' }"></div>
    <div v-show="showArrowBtn" class="-fdp-pagination__move-right-last" @click.stop="onClickRightEnd" :style="{ 'cursor': this.isRightEnd? 'default' : 'pointer' }"></div>
  </div>
</template>
<script>
export default {
  name: 'fdp-pagination',
  props: {
    total: {
      type: Number,
      default: 0
    },
    perPage: {
      type: Number,
      default: 10
    },
    value: {}
  },
  data () {
    return {
      action: false,
      lastPageIdx: 1,
      tenPageIdx: 10
    }
  },
  computed: {
    isLeftEnd () {
      return (this.value === 1)
    },
    isRightEnd () {
      return (this.value === this.lastPageIdx)
    },
    showArrowBtn () {
      return (this.lastPageIdx > 10)
    },
    range () {
      // let cnt = Math.ceil(this.total/this.perPage)
      let result = []

      if (this.lastPageIdx <= 10) {
        for (let i = 1; i <= this.lastPageIdx; i++) {
          result.push(i)
        }
        return result
      } else {
        if (this.value <= 6) {
          for (let i = 1; i <= 10; i++) {
            result.push(i)
          }
          return result
        } else if ((this.lastPageIdx - 4) < this.value) {
          for (let i = (this.lastPageIdx - 9); i <= this.lastPageIdx; i++) {
            result.push(i)
          }
          return result
        } else {
          for (let i = (this.value - 5); i <= (this.value + 4); i++) {
            result.push(i)
          }
          return result
        }
      }
    }
  },
  mounted () {
    this.lastPageIdx = Math.ceil(this.total / this.perPage)
  },
  methods: {
    onClickPage (n) {
      if (n === this.value) {
        return
      }
      this.$emit('input', n)
    },
    onClickLeftFirst () {
      if (this.isLeftEnd) {
        return
      }
      this.$emit('input', 1)
    },
    onClickLeft () {
      if (this.isLeftEnd) {
        return
      }
      this.$emit('input', (this.value - 1))
    },
    onClickRight () {
      if (this.isRightEnd) {
        return
      }
      this.$emit('input', (Number(this.value) + 1))
    },
    onClickRightEnd () {
      if (this.isRightEnd) {
        return
      }
      this.$emit('input', this.lastPageIdx)
    }
  }
}
</script>

<style>
</style>
