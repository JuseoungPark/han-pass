<template>
  <div class="-fdp-select" :class="classes">
    <div v-if="custom" class="-fdp-select__input--custom" :class="{'-fdp-select--disabled':disabled}"
         v-select-click-outside="toggleItemOuter" @click="optionClick">
         <slot :current="currLabel"></slot>
    </div>
    <div v-else class="-fdp-select__input" :class="inputClasses"
         v-select-click-outside="toggleItemOuter"
         @click="optionClick">{{ currLabel }}
    </div>
    <transition :name="up? '-fdp-select--up__transition' : '-fdp-select__transition'">
      <ul v-show="isActive" class="-fdp-select__ul" :style="listStyle">
          <li v-for="item in optionList" :key="item.key" class="-fdp-select__li" :class="{'-fdp-select--selected':item.key === value.key, '-fdp-select__item-disabled': item.disabled}"
              @click.stop="listClick(item)">
            {{ item.label }}
          </li>
      </ul>
    </transition>
  </div>
</template>

<script>
/**
 * 이름 : fdp-select
 * 설명 : ul,li 구조로 커스터마이즈를 가능케한 select
 * 최종 수정 일시 : 2018 - 10 - 15
 */
export default {
  name: 'fdp-select',
  directives: { // select가 아닌 외부 영역 click이벤트 발생시, 닫힘처리
    'select-click-outside': {
      bind: function (el, binding) {
        // Define Handler and cache it on the element
        const handler = (e) => {
          if ((!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },

      unbind: function (el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      }
    }
  },
  props: {
    value: { // 옵션리스트 중 선택된 값
      type: Object,
      required: true
    },
    optionList: { // 표기 대상인 옵션 리스트
      type: Array,
      default: () => []
    },
    placeholder: { // 최초 화면 구성시 보여질 값
      type: String,
      default: ''
    },
    disabled: { // 선택가능 여부
      type: Boolean,
      default: false
    },
    highlight: { // 선택이 완료 된 경우 input영역 하이라이트 컬러 값 적용 여부
      type: Boolean,
      default: false
    },
    custom: { // input영역 및 옵션리스트 영역 스타일 커스터마이즈 여부
      type: Boolean,
      default: false
    },
    up: { // 옵션 리스트 위로펼침 여부
      type: Boolean,
      default: false
    },
    alignRight: { // 옵션 리스트 오른쪽 맞춤 여부
      type: Boolean,
      default: false
    },
    ellipsis: { // 긴텍스트항목의 경우 말줄임표 처리 여부
      type: Boolean,
      default: false
    },
    listHeight: {
      type: [String, Number],
      default: ''
    }
  },
  data () {
    return {
      isActive: false, // 옵션 리스트 펼침 여부
      isSelected: this.value.label !== '' && !this.disabled, // 선택완료 되었는지 여부
      currLabel: this.value.label !== '' ? this.value.label : this.placeholder // 현재 선택된 값으로 노출 될 레이블 텍스트
    }
  },
  watch: {
    value: function () {
      // 선택 된 옵션이 바뀌면 선택완료 여부와 현재 선택된 값으로 노출될 레이블 텍스트를 변경하여준다
      this.isSelected = (this.value.key !== '' && !this.disabled)
      this.currLabel = this.value.label !== '' ? this.value.label : this.placeholder
    }
  },
  computed: {
    classes () { // 최상단 div에 적용될 class속성
      return [
        {'-fdp-select--active': this.isActive},
        {'-fdp-select--up': this.up},
        {'-fdp-select--align-right': this.alignRight},
        {'-fdp-select--ellipsis': this.ellipsis},
        {'-fdp-select--selected': this.isSelected && this.highlight}
      ]
    },
    inputClasses () { // input영역에 적용될 class속성
      return [
        {'-fdp-select--disabled': this.disabled},
        {'-fdp-select--selected': this.isSelected && this.highlight},
        {'-fdp-select--placeholder': this.currLabel === this.placeholder}
      ]
    },
    listStyle () {
      let listStyleArr = []
      if (this.listHeight) {
        listStyleArr.push({'max-height': this.listHeight + 'px'})
      }
      return listStyleArr
    }
  },
  methods: {
    optionClick () { // input영역 클릭 이벤트 발생 시 선택가능 여부에 따라 옵션 리스트 펼침 처리
      if (!this.disabled) {
        this.isActive = !this.isActive
      }
    },
    listClick (target) { // 옵션 리스트 클릭 이벤트 발생 시 선택된 옵션을 현재 선택값에 반영
      if (target.disabled) {
        return
      }
      this.currLabel = target.label
      this.$emit('input', target)
      this.isActive = false
      this.$emit('list-click', target)
    },
    toggleItemOuter () { // 외부 영역 클릭 이벤트 발생 시 자동닫힘 처리
      this.isActive = false
    }
  }

}
</script>

<style>
</style>
