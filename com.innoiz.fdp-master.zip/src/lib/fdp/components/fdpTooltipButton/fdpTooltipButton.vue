<template>
    <div class="-fdp-tooltip-button" :class="classes">
        <div class="-fdp-tooltip-button__arrow" v-show="tooltipStatus"></div>
        <button type="button" @click="tooltipClick" class="-fdp-tooltip-button__activator" v-tooltip-click-outside="clickOuter">
            <slot name="activator"></slot>
        </button>
        <div class="-fdp-tooltip-button__content" v-show="tooltipStatus">
            <button type="button" class="-fdp-tooltip-button__close-button"  @click="tooltipStatus = false"></button>
            <slot name="content"></slot>
        </div>
    </div>
</template>

<script>
export default {
  name: 'fdp-tooltip-button',
  directives: { // tooltip가 아닌 외부 영역 click이벤트 발생시, 닫힘처리
    'tooltip-click-outside': {
      bind: function (el, binding) {
        // Define Handler and cache it on the element
        const handler = (e) => {
          if ((!el.contains(e.target) && el !== e.target && el.parentElement.children[2] && !el.parentElement.children[2].contains(e.target))) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },

      unbind: function (el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      }
    }
  },
  props: {
    up: {
      type: Boolean,
      default: false
    },
    alignRight: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      tooltipStatus: false
    }
  },
  computed: {
    classes () {
      return [
        {'-fdp-tooltip-button--up': this.up},
        {'-fdp-tooltip-button--align-right': this.alignRight}
      ]
    }
  },
  methods: {
    tooltipClick () {
      this.tooltipStatus = true
    },
    clickOuter () { // 외부 영역 클릭 이벤트 발생 시 자동닫힘 처리
      this.tooltipStatus = false
    }
  }

}
</script>

<style>

</style>
