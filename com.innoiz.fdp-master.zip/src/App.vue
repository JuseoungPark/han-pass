<template>
  <div id="app">
    <gnb v-if="false"></gnb>
    <main class="container -pub-main" role="main">
      <router-view></router-view>
    </main>
  </div>
</template>
<script>
import gnb from '@/components/pages/2018-08-31/gnb'
import router from './core/router'
export default {
  components: {
    gnb
  },
  name: 'App',
  data () {
    return {}
  },
  router: router
}
</script>
