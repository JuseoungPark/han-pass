
//
//  Router 객체 생성 관리 (2018/06/01 정재윤)
// -
//

import Router from './router'

const router = Router.createInstance()

export default router
