
const language = () => import( /* webpackChunkName: "showFormPage" */ '~pages/contents/mainPage/lnb/language/main-page')
const customerMgmt = () => import( /* webpackChunkName: "showFormPage" */ '~pages/contents/mainPage/lnb/customerMgmt/main-page')
const showUserInfoList = () => import( /* webpackChunkName: "showUserInfoList" */ '~pages/contents/mainPage/lnb/customerMgmt/ShowUserInfoList')
const showUserInfo = () => import( /* webpackChunkName: "showUserInfo" */ '~pages/contents/mainPage/lnb/customerMgmt/ShowUserInfo')
const insertUserInfo = () => import( /* webpackChunkName: "crudPages" */ '~pages/contents/mainPage/lnb/customerMgmt/InsertUserInfo')
const updateUserInfo = () => import( /* webpackChunkName: "crudPages" */ '~pages/contents/mainPage/lnb/customerMgmt/UpdateUserInfo')

const customerMgmtPopup = () => import( /* webpackChunkName: "showFormPagePopup" */ '~pages/contents/mainPage/lnb/customerMgmtPopup/main-page')
const showUserInfoListPopup = () => import( /* webpackChunkName: "showUserInfoListPopup */ '~pages/contents/mainPage/lnb/customerMgmtPopup/ShowUserInfoListPopup')

const routes = [
  {
    path: 'lnb/lang',
    component: language
  },
  {
    path: 'lnb/customer1',
    component: customerMgmt,
    children: [
      {
        path: 'retrieve',
        name: 'Retrieve',
        component: showUserInfoList
      },
      {
        path: 'detail',
        name: 'Detail',
        component: showUserInfo
      },
      {
        path: 'insert',
        name: 'Insert',
        component: insertUserInfo,
        meta: {
          keepAlive: true
        }
      },
      {
        path: 'update',
        name: 'Update',
        component: updateUserInfo
      }
    ]
  },
  {
    path: 'lnb/customer2',
    component: customerMgmtPopup,
    children: [
      {
        path: 'retrieve',
        name: 'Retrieve',
        component: showUserInfoListPopup
      }
    ]
  }
]

export default routes
