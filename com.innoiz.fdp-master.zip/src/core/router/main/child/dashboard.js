/*
  > 비동기 컴포넌트 선언
*/
const dashboardPage = () => import( /* webpackChunkName: "dashboardPage" */ '~pages/contents/mainPage/dashboard/main-page')

const childroutes = [
  {
    path: 'dashboard',
    component: dashboardPage
  }
]

export default childroutes
