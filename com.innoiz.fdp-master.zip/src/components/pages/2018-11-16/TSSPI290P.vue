<!--
2개 화면이 있습니다.

지급금액 안보임 : START, 지급금액 나타남 : START
v-if="false, true" 설정하였습니다.
-pub-table-01, -pub-table-02로 스타일이 다릅니다.
mock데이터 key: 2 의 데이터에 <br /> 태그 넣을수있게 개발요청드립니다.
-->
<template>
        <fdp-popup class="-pub-popup" v-model="showPopup" title="보장내용" :prevent-outside-close="true">
            <div class="-pub-popup-page__slot -pub-popup-page__gua">
                <div class="-pub-popup__content">
                    <div class="-pub-popup__contents--name">
                        <div class="-pub-popup__gua--tit">특양명</div>
                        <div class="-pub-popup__gua--content">통합유니버설종신보험3.0(무배당, 보증비용부과형)</div>
                    </div>
                    <!-- 지급금액 안보임 : START -->
                    <fdp-infinite class="-pub-table -pub-table-01" :items="mockData" :table-body-height="660" :tableMinWidth="452" v-if="false">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column" style="width: 1390px;">지급사유</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column" style="width: 1390px;">{{props.item.content1}}</td>
                        </template>
                    </fdp-infinite>
                    <!-- 지급금액 안보임 : END -->

                    <!-- 지급금액 나타남 : START -->
                    <fdp-infinite class="-pub-table -pub-table-02" :items="mockData" :table-body-height="660" :tableMinWidth="452" v-if="true">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column" style="width: 1030px;">지급사유</th>
                                <th class="-pub-table-column" style="width: 340px;">지급금액</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column" style="width: 1030px;">{{props.item.content1}}</td>
                            <td class="-pub-table-column" style="width: 340px;">{{props.item.content2}}</td>
                        </template>
                    </fdp-infinite>
                    <!-- 지급금액 나타남 : END -->
                </div>
            </div>
        </fdp-popup>
</template>

<script>
export default {
  data () {
    return {
      showPopup: true,
      mockData: [
        {
          key: 1,
          content1: '「장기요양상태 보장개시일」 이후에 ‘장기요양상태’로 진단 확정되었을 경우',
          content2: '3,600만원 + 가산보험금'
        },
        {
          key: 2,
          content1: '「장기요양상태 보장개시일」 이후에 ‘장기요양상태’로 진단 확정되고, 장기요양진단보험금 지급사유 발생일부터 5년후 장기요양자금 지급해당을을 최초로 하여 5년동안 매년 장기요양자금 지급해당일에 살아있을 경우 (단, 5회를 최고 한도로 지급) 「장기요양상태 보장개시일」은 계약일[부활(효력회복)일]부터 그 날을 포함하여 90일이 지난 날의 다음날입니다. 다만, 재해를 직접적인 원인으로 ‘장기요양상태’가 발생한 경우 보장개시일은 보험개약일과 동일합니다.',
          content2: '매년 400만원'

        },
        {
          key: 3,
          content1: '장기요양진단보험금의 지급사유 발생 후 사망시',
          content2: '400만원'
        },
        {
          key: 4,
          content1: '장기요양진단보험금의 지급사유 발생 후 사망시',
          content2: '400만원 + 가산보험금'
        },
        {
          key: 5,
          content1: '「장기요양상태 보장개시일」 이후에 ‘장기요양상태’로 진단 확정되었을 경우',
          content2: '3,600만원 + 가산보험금'
        },
        {
          key: 6,
          content1: '장기요양진단보험금의 지급사유 발생 후 사망시',
          content2: '400만원'
        },
        {
          key: 7,
          content1: '장기요양진단보험금의 지급사유 발생 후 사망시',
          content2: '400만원 + 가산보험금'
        }
      ]
    }
  }
}
</script>

<style>

</style>
