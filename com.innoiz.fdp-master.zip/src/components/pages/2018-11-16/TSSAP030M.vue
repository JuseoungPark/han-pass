<template>
    <section class="-pub-activity -pub-visiblity">
        <div class="-pub-activity__event--mySchedule">
            <div class="-pub-page-header">
                <h3 class="-pub-page-header__title">이벤트 고객</h3><span class="-pub-page-header__subtitle">내 일정</span>
            </div>
            <div class="-pub-activity__event--mySchedule-calendar">
                <div class="-pub-calendar__header">
                    <div class="-pub-month">
                        <div class="btn-prev">뒤로 이동</div>
                        <div class="-pub-month-year">
                            <span class="-pub-year-num">2018년</span><span class="-pub-month-num">10월</span>
                        </div>
                        <div class="btn-next">앞으로 이동</div>
                    </div>
                    <div class="-pub-button-area">
                        <button type="submit" class="-pub-button -pub-button--purple -pub-button--light">오늘</button>
                    </div>
                    <div class="-pub-tab-area">
                        <fdp-validator name="Name" v-model="filter" :rules="'required'">
                            <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="filter" :data="filters"></fdp-segment-box>
                        </fdp-validator>
                    </div>
                </div>
                <div class="-pub-calendar__list">
                    <div class="-pub-calendar__list--header">
                        <table>
                            <colgroup>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="day sun"><span class="">일</span></th>
                                    <th class="day">월</th>
                                    <th class="day">화</th>
                                    <th class="day">수</th>
                                    <th class="day">목</th>
                                    <th class="day">금</th>
                                    <th class="day">토</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="-pub-calendar__list--body">
                        <table>
                            <colgroup>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td class="day old sun"><!-- old : 지난날 / sun : 일요일 / holiday : 휴일 -->
                                        <div class="-pub-day-notice">
                                            <span class="notice">특별한 날</span>
                                            <span class="day-num">30</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation"><!-- 이름/관계 둘다 나올경우 -->
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">10/1</span>
                                        </div>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">2</span>
                                        </div>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">3</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">김명숙숙</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">4</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day today">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">5</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">6</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">7</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">8</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">9</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">10</span>
                                        </div>
                                    </td>
                                    <td class="day holiday selected">
                                        <div class="-pub-day-notice">
                                            <span class="notice">부처님 오신 날날...</span>
                                            <span class="day-num">11</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">김명숙숙</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">12</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">13</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">14</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">15</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">16</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">17</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">배우자</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name-relation">
                                                    <span class="name">한연주</span><span class="relation">본인</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">18</span>
                                        </div>
                                    </td>
                                    <td class="day holiday">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">19</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">20</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">21</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">22</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">23</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">24</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">25</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">26</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">27</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">28</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">29</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">30</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">31</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">11/1</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">2</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">3</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  data () {
    return {
      filter: [{
        key: '1',
        label: '생일'
      }],
      filters: [{
        key: '1',
        label: '생일'
      },
      {
        key: '2',
        label: '계약1주년'
      },
      {
        key: '3',
        label: '상령일'
      },
      {
        key: '4',
        label: '만기일'
      }
      ]
    }
  }
}
</script>
