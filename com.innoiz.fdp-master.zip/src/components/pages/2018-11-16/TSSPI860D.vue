<template>
 <section>
     <!-- 비정상 세부내용 start -->
     <div class="-pub-product__info">
        <div class="-pub-product__info--title">
            <h2>비정상 세부내용</h2>
        </div>
        <div class="-pub-product__unusual">
          <fdp-infinite class="-pub-table" :items="mockData">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column">관계</th>
                        <th class="-pub-table-column" style="width:562px;">비정상내용</th>
                        <th class="-pub-table-column" style="width:240px;">가입금액</th>
                        <th class="-pub-table-column" style="width:240px;">한도금액</th>
                        <th class="-pub-table-column" style="width:240px;">초과금액</th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column">{{props.item.key}}</td>
                    <td class="-pub-table-column -pub-table-column--left-align point-text--pt-1" style="width:562px;">{{props.item.content}}</td>
                    <td class="-pub-table-column -pub-table-column--normal-letter -pub-table-column--right-align" style="width:240px;">{{props.item.price1}}</td>
                    <td class="-pub-table-column -pub-table-column--normal-letter -pub-table-column--right-align" style="width:240px;">{{props.item.price2}}</td>
                    <td class="-pub-table-column -pub-table-column--normal-letter -pub-table-column--right-align" style="width:240px;">{{props.item.price3}}</td>
                </template>
            </fdp-infinite>
        </div>
    </div>
    <!-- // 비정상 세부내용 end -->
    <!-- 발행불가사유 start -->
    <div class="-pub-product__info">
        <div class="-pub-product__info--title">
            <h2>발행불가사유</h2>
        </div>
        <div class="-pub-product__cause">
            <p class="-pub-product__cause--txt">기계약 합산 심사 오류입니다.<br>기계약심사 [주피 재해사망종합보장(직업군별) (한도:7000 / 초과:3000)]</p>
        </div>
    </div>
    <!-- 발행불가사유 end -->
 </section>
</template>
<script>
export default {
  data () {
    return {
      mockData: [
        {
          key: '계약자',
          content: '실제 소유자 확인서 첨부대상',
          price1: '0',
          price2: '0',
          price3: '0'
        },
        {
          key: '계약자',
          content: '지급정보 확인 후 가입가능',
          price1: '0',
          price2: '0',
          price3: '0'
        },
        {
          key: '계약자',
          content: '진단결과 비정상 인수기준 확인요망',
          price1: '0',
          price2: '0',
          price3: '0'
        }
      ]
    }
  }
}
</script>
