<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="상품선택" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--choice">
            <div class="-pub-product-join__choice--wrap">
                <!-- 상품선택 : 탭 -->
                <ul class="-pub-product-join__choice--wrap-tab">
                    <!-- 선택한 탭 li에 -pub-product-join__choice--wrap-tab-item-active 추가-->
                    <!-- 선택한 탭 li에 -pub-product-join__choice--wrap-tab-item-active 추가-->
                    <li class="-pub-product-join__choice--wrap-tab-item" :class="[{'-pub-product-join__choice--wrap-tab-item-active':menu.enable}]"
                     v-for="(menu, idx) in menuList" :key="idx" @click="selectTab(idx)">
                        <a href="#">{{menu.name}}</a>
                    </li>
                </ul>
                <!-- 상품목록 : 최근선택만 뱃지 있음 -->
                <ul class="-pub-product-join__choice--wrap-list" v-if="filteredList.length>0">
                    <li class="-pub-product-join__choice--wrap-list-item" v-for="(prd, idx) in filteredList" :key="idx">
                        <span class="-pub-badge-tag--product" v-if="isBadge">{{prd.cat}}</span>
                        <a href="#" @click="selectProduct(prd.name)">{{prd.name}}</a>
                    </li>
                </ul>
                <!-- no data 화면 : 상품 데이터가 없는 경우 -->
                <div class="-pub-product-join__choice--wrap-list" v-else>
                   <div class="-pub-table-empty-view">
                        <div class="empty-table-content__text">최근 선택한 상품이 없습니다.</div>
                    </div>
               </div>
            </div>
        </div>
         <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">취소</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  mounted () {
    this.selectTab(0)
  },
  data () {
    return {
      showPopup: true,
      isBadge: false, // 최근?
      menuList: [
        {name: '최근선택', enable: true},
        {name: '전체', enable: false},
        {name: '통합보험', enable: false},
        {name: '보장성(VUL)', enable: false},
        {name: '보장성(종신)', enable: false},
        {name: '보장성(기타)', enable: false},
        {name: '금융상품(연금)', enable: false},
        {name: '금융상품(변액/즉시)', enable: false},
        {name: '금융상품(저축)', enable: false},
        {name: '금융상품(연금저축)', enable: false},
        {name: '어린이', enable: false}
      ],
      recentList: [
        {cat: '통합보험', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '통합보험', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '통합보험', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'}
      ],
      productList: [
        {cat: '통합보험', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '통합보험', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '통합보험', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(변액/즉시)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(변액/즉시)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '보장성(종신)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '보장성(기타)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '보장성(기타)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '보장성(기타)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '보장성(기타)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(연금)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(저축)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(저축)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금저축)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '금융상품(연금저축)', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금저축)', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '금융상품(연금저축)', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '삼성생명 New인덱스변액연금보장보험(무배당)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설종신보장보험3.0(무배당,보증비용부과형)'},
        {cat: '어린이', name: '통합유니버설프라임종신보장보험1.0(무배당,보증비용부과형)'}
      ],
      filteredList: []
    }
  },
  methods: {
    selectTab (v) {
      this.isBadge = false
      this.filteredList = []

      for (let i = 0; i < this.menuList.length; i++) {
        this.menuList[i].enable = false
        if (i === v) {
          this.menuList[i].enable = true
        }
      }
      if (v === 0) {
        this.isBadge = true
        this.filteredList = this.recentList
      } else if (v === 1) {
        this.isBadge = true
        this.filteredList = this.productList
      } else {
        this.filterProduct(v)
      }
    },
    filterProduct (v) {
      this.filteredList = []
      for (let i = 0; i < this.productList.length; i++) {
        if (this.productList[i].cat === this.menuList[v].name) this.filteredList.push(this.productList[i])
      }
    }
  }
}
</script>
