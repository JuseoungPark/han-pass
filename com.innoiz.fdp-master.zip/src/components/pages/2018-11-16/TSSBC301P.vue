<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="설문조사" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup__business--survey"  ref="scrollWrapper">
            <h2>설문 정보</h2>
            <div class="-pub-popup__business--survey-info">
                <dl class="-pub-popup__business--survey-info-item">
                    <dt>설문 제목</dt>
                    <dd>설문대상 내용설문대상 내용설문대상 내용설문대상 내용 설문대상</dd>
                </dl>
                <dl class="-pub-popup__business--survey-info-item">
                    <dt>설문 개요</dt>
                    <dd>설문개요 내용설문개요 내용설문개요 내용설문개요 내용설문개요 내용 설문개요 설문개요 내용설문개요 내용설문개요 내용설문개요 내용설문개요 내용 설문개요</dd>
                </dl>
                <dl class="-pub-popup__business--survey-info-item">
                    <dt>설문 대상</dt>
                    <dd>설문대상 내용설문대상 내용설문대상 내용설문대상 내용설문대상 내용 설문대상 설문대상 내용설문대상 내용설문대상 내용설문대상 내용설문대상 내용 설문대상 설문대상 내용설문대상 내용설문대상 내용설문대상 내용설문대상 내용 설문대상</dd>
                </dl>
            </div>
            <ul class="-pub-popup__business--survey-list">
                <!-- 객관식일때 li에 -pub-popup__business--survey-list-item-multiple -->
                <!-- 주관식일때 li에 -pub-popup__business--survey-list-item-short -->
                <li v-for="(data, idx) in mockData" :key="idx"
                    :class="[{'-pub-popup__business--survey-list-item':true},
                             {'-pub-popup__business--survey-list-item-multiple': data.choiceQuestion},
                             {'-pub-popup__business--survey-list-item-short': !data.choiceQuestion}]"
                    ref="questionScroll">
                    <div class="-pub-popup__business--survey-list-item-tit">{{data.key + '. ' + data.question}}</div>
                    <ul v-if="data.choiceQuestion" class="-pub-popup__business--survey-list-item-check">
                        <li v-for="data2 in data.choice" :key="data2.key">
                            <fdp-radio class="-pub-radio -pub-radio--purple" v-model="answer[idx].selected" :value="data2" @input="clickRadio(idx+1, data2)"><span class="txt">{{data2.label}}</span></fdp-radio>
                            <div v-if="data2.inputText" class="-pub-input--field">
                                <fdp-validator :name="'tssbc301p-validator-' + data2.key" :display-name="(idx+1) + '번 질문의 ' + data2.key + '번 선택'" v-model="inputTextValidator" :rules="'required'">
                                    <fdp-text-field class="-pub-input--purple" v-model="answer[idx].text" :disabled="disabledInput(idx,data2)" @blur="doneText(idx+1)"></fdp-text-field>
                                </fdp-validator>
                            </div>
                        </li>
                    </ul>
                    <textarea v-else v-model="mailText" @blur="doneText(idx+1)"></textarea>
                </li>
            </ul>
        </div>
         <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                        <span class="-pub-button__text">제출</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
import {viewMemberMocks} from '@/components/mock/TSSBC301P.mock'
import {createScrollAnimateInstance} from '@/components/util/scroll-animate'
export default {
  data () {
    return {
      mockData: Array.prototype.slice.call(viewMemberMocks),
      showPopup: true,
      currentQuestion: 1,
      answer: [
        {
          selected: {},
          text: ''
        }, {
          selected: {},
          text: ''
        }, {
          selected: {},
          text: ''
        }
      ],
      inputRadio: {},
      inputTextValidator: '',
      mailText: '더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더'

    }
  },
  methods: {
    clearInputText (idx) {
      this.answer[idx].text = ''
    },
    clickRadio (index, radio) {
      console.log('## clickradio: ', index, ', current No: ', this.currentQuestion)
      debugger
      if (!radio.inputText) {
        if (index >= this.mockData.length) {
          this.currentQuestion = this.mockData.length
        } else {
          this.currentQuestion = index + 1 // 다음 질문으로 변경해줘야 하므로 '+2'
          this.moveScroll()
        }
      }
    },
    disabledInput (idx, radio) {
      if (Object.keys(this.answer[idx].selected).length > 0) {
        if (this.answer[idx].selected.inputText) {
          return false
        } else {
          this.clearInputText(idx)
          return true
        }
      } else {
        return true
      }
    },
    doneText (index) {
      if (index >= this.mockData.length) {
        this.currentQuestion = this.mockData.length
      } else {
        this.currentQuestion = index + 1 // 다음 질문으로 변경해줘야 하므로 '+2'
        this.moveScroll()
      }
    },
    moveScroll () {
      this.$nextTick(() => {
        let targetPoint = this.$refs.questionScroll[this.currentQuestion - 1].offsetTop - 100
        const scrollEl = this.$refs.scrollWrapper
        // const targetEl = this.$refs.questionScroll[this.currentQuestion]

        // 스크롤 애니메이션 인스턴스 생성 1000ms 후에 이동 이벤트 scrollAnimation 관련 scroll-animate.js 파일 참조
        const scrollXAnimate = createScrollAnimateInstance(scrollEl, 'y')
        // aguments 순서 (이동할 좌표픽셀값, 진행시간, 딜레이, 타이밍 function name, 애니메이션 끝난후 콜백 function)
        // scrollXAnimate.animate(500, 1500, 1000, 'easeInOut', _ => console.log('애니메이션 끝'))
        scrollXAnimate.animate(targetPoint, 1500, 0, 'easeInOut', _ => console.log('애니메이션 끝'))
      })
    }
  }
}
</script>
