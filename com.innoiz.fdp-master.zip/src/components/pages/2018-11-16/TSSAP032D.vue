<template>
    <section class="-pub-activity -pub-visiblity">
        <div class="-pub-activity__event--mySchedule">
            <div class="-pub-page-header">
                <h3 class="-pub-page-header__title">이벤트 고객</h3><span class="-pub-page-header__subtitle">내 일정</span>
            </div>
            <div class="-pub-activity__event--mySchedule-calendar left">
                <div class="-pub-calendar__header">
                    <div class="-pub-month">
                        <div class="btn-prev">뒤로 이동</div>
                        <div class="-pub-month-year">
                            <span class="-pub-year-num">2018년</span><span class="-pub-month-num">10월</span>
                        </div>
                        <div class="btn-next">앞으로 이동</div>
                    </div>
                    <div class="-pub-button-area">
                        <button type="submit" class="-pub-button -pub-button--purple -pub-button--light">오늘</button>
                    </div>
                    <div class="-pub-tab-area">
                        <fdp-validator name="Name" v-model="filter" :rules="'required'">
                            <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="filter" :data="filters"></fdp-segment-box>
                        </fdp-validator>
                    </div>
                </div>
                <div class="-pub-calendar__list">
                    <div class="-pub-calendar__list--header">
                        <table>
                            <colgroup>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="day sun">일</th>
                                    <th class="day">월</th>
                                    <th class="day">화</th>
                                    <th class="day">수</th>
                                    <th class="day">목</th>
                                    <th class="day">금</th>
                                    <th class="day">토</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="-pub-calendar__list--body">
                        <table>
                            <colgroup>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td class="day old sun"><!-- old : 지난날 / sun : 일요일 / holiday : 휴일 -->
                                        <div class="-pub-day-notice">
                                            <span class="notice">특별한 날</span>
                                            <span class="day-num">30</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">10/1</span>
                                        </div>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">2</span>
                                        </div>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">3</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">김명숙숙</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day old">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">4</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day today">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">5</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">6</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">7</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">8</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">9</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">10</span>
                                        </div>
                                    </td>
                                    <td class="day holiday selected">
                                        <div class="-pub-day-notice">
                                            <span class="notice">부처님 오...</span>
                                            <span class="day-num">11</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">김명숙숙</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">12</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">13</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">14</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">김명숙숙</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">15</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">16</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">17</span>
                                        </div>
                                        <ul class="-pub-event-customer__list">
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                            <li class="-pub-event-customer__list--item">
                                                <div class="-pub-item__name">
                                                    <span class="name">한연주</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">18</span>
                                        </div>
                                    </td>
                                    <td class="day holiday">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">19</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">20</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">21</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">22</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">23</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">24</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">25</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">26</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">27</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="day sun">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">28</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">29</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">30</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">31</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">11/1</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">2</span>
                                        </div>
                                    </td>
                                    <td class="day">
                                        <div class="-pub-day-notice">
                                            <span class="day-num">3</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="-pub-activity__event--mySchedule-detail" v-if="true">
                <!-- 계약1주년 start -->
                <div class="-pub-detail__wrap" v-if="true">
                    <div class="-pub-detail__header">
                        <span class="-pub-header-day">10월 11일</span>
                        <span class="-pub-header-week">목</span>
                        <div class="-pub-radio-area">
                            <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioValue1" value="1">당월</fdp-radio>
                            <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioValue2" value="2">차월</fdp-radio>
                        </div>
                        <button class="-pub-button--close">창닫기</button>
                    </div>
                    <div class="-pub-detail__list" :class="hasSelectItem ? '-pub-list-height__onBottom' : '-pub-list-height__offBottom'">
                        <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="mockData" single-select :list-height="981" ref="targetFdpList" >
                            <template slot="emptyView">
                                <div class="-pub-table-empty-view">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                            <template slot="default" slot-scope="props">
                                <div>
                                    <div class="-pub-list-day">{{props.item.day}}</div>
                                    <div class="-pub-list-box" v-for="(mock, index2) in props.item.data" :key="'b' + index2">
                                        <dl class="-pub-list-item">
                                            <dt class="-pub-list-item__title">
                                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                                                <span class="-pub-list-item__title--name">{{mock.name}}</span>
                                            </dt>
                                            <dd class="-pub-list-item__detail--01">
                                                <span class="-pub-list-item__contract">{{mock.contract}}</span>
                                                <span class="-pub-list-item__birthday">{{mock.birthday}}</span>
                                            </dd>
                                            <dd class="-pub-list-item__detail--02">
                                                <span class="-pub-list-item__product">{{mock.product}}</span>
                                            </dd>
                                        </dl>
                                    </div>
                                </div>
                            </template>
                        </fdp-list>
                    </div>
                    <div class="-pub-detail__bottom">
                        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" :page-fixed="true">
                            <ul class="-pub-bottom-nav">
                                <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered">
                                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox
                                    v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
                                </li>
                                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                                    <button class="-pub-button -pub-button--purple -pub-button--disabled-line" :disabled="hasSelectItem">
                                        <span class="-pub-button__text">이메일</span>
                                    </button><button class="-pub-button -pub-button--purple -pub-button--disabled-line" :disabled="hasSelectItem">
                                        <span class="-pub-button__text">문자</span>
                                    </button>
                                </li>
                            </ul>
                        </fdp-bottom-bar>
                    </div>
                </div>
                <!-- 계약1주년 end -->
            </div>
        </div>
    </section>
</template>
<script>
export default {
  data () {
    return {
      isSelectAll: false,
      bottomBarCheck: false,
      radioValue1: '1',
      radioValue2: '1',
      filter: [{
        key: '2',
        label: '계약1주년'
      }],
      filters: [{
        key: '1',
        label: '생일'
      },
      {
        key: '2',
        label: '계약1주년'
      },
      {
        key: '3',
        label: '상령일'
      },
      {
        key: '4',
        label: '만기일'
      }
      ],
      mockData: [
        {
          day: '10-11',
          data: [
            {
              name: '한연주주',
              relation: '본인생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '본인생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '배우자생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '자녀생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '본인생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            }
          ]
        },
        {
          day: '10-12',
          data: [
            {
              name: '한연주주',
              relation: '본인생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '배우자생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '자녀생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            }
          ]
        },
        {
          day: '10-13',
          data: [
            {
              name: '한연주주',
              relation: '본인생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '배우자생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            },
            {
              name: '한연주주',
              relation: '자녀생일',
              ageDate: '상령일자',
              maturity: '만기일자',
              birthday: '1988-06-13',
              contract: '계약00주년',
              product: '통합유니버설종신보험'
            }
          ]
        }
      ]
    }
  }
}
</script>
