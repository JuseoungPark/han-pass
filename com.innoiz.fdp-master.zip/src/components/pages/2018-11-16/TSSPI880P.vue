<!--
1. 화면 전환 스크립트 코드
isEmptySearchKeywordOrigin1: true, // 데이터가 존재하지 않습니다.
isEmptySearchKeywordOrigin2: false, // 검색결과가 존재하지 않습니다.
isEmptySearchKeywordOrigin3: false, // 고객명 입력 후 검색해 주세요.

-->
<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="단체검색" :prevent-outside-close="true">
        <div class="-pub-popup-page__slot -pub-popup-page__grpSearch">
            <div class="-pub-popup__edit-new_prt">
                <div class="-pub-popup__content-body">
                        <!-- HEADER : START -->
                        <div class="-pub-filter-menu__text">총 {{mockData.length}}건</div>
                        <div class="-pub-filter-menu__item--right">
                            <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple"
                                    placeholder="고객명" v-model="searchKeywordOrigin" clearable @keyup.enter="clickSearchKeywordOrigin"></fdp-text-field>
                            <button type="button" class="-pub-search-button -pub-filter-menu__item" @click="clickSearchKeywordOrigin">
                                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                            </button>
                        </div>
                        <!-- HEADER : START -->
                        <!-- TABLE : START -->
                        <fdp-infinite class="-pub-table" v-model="selectOrigin" single-select :items="mockData" :table-body-height="800" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">&nbsp;</th>
                                    <th class="-pub-table-column" style="width: 252px;">단체명</th>
                                    <th class="-pub-table-column" style="width: 252px;">단체코드</th>
                                    <th class="-pub-table-column" style="width: 252px;">대표자</th>
                                    <th class="-pub-table-column" style="width: 252px;">종업원</th>
                                    <th class="-pub-table-column" style="width: 246px;">상태</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-radio class="-pub-radiobox -pub-radiobox--empty-label -pub-radiobox--purple" v-model="selectOrigin" :value="props.item"></fdp-radio>
                                </td>
                                <td class="-pub-table-column" style="width: 252px;">{{props.item.name}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 252px;">{{props.item.code}}</td>
                                <td class="-pub-table-column" style="width: 252px;">{{props.item.name2}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 252px;">{{props.item.emp}}</td>
                                <td class="-pub-table-column" style="width: 246px;">{{props.item.sel}}</td>
                            </template>

                            <!-- 데이터가 존재하지 않습니다. : START -->
                            <template slot="emptyView">
                                <div class="empty-table-content" v-if="isEmptySearchKeywordOrigin1">
                                    <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>

                            <!-- 검색결과가 존재하지 않습니다. : START -->
                            <template slot="emptyView">
                                <div class="empty-table-content" v-if="isEmptySearchKeywordOrigin2">
                                    <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                                </div>
                            </template>

                            <!-- 고객명 입력 후 검색해 주세요. : START -->
                            <template slot="emptyView">
                                <div class="empty-table-content" v-if="isEmptySearchKeywordOrigin3">
                                    <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">고객명 입력 후 검색해 주세요.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                        <!-- TABLE : END -->
                </div>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar -pub-bottom-bar__190p">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--confirm">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSPI880P.mock'

export default {
  data () {
    return {
      showPopup: true,
      vipGroupName: '',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      searchKeywordOrigin: '',
      isEmptySearchKeywordOrigin1: true, // 데이터가 존재하지 않습니다.
      isEmptySearchKeywordOrigin2: false, // 검색결과가 존재하지 않습니다.
      isEmptySearchKeywordOrigin3: false, // 고객명 입력 후 검색해 주세요.
      selectOrigin: {},
      selectAddMember: {}
    }
  },
  methods: {
    clickSearchKeywordOrigin () {
      this.isEmptySearchKeywordOrigin1 = false
      this.isEmptySearchKeywordOrigin2 = false
      this.isEmptySearchKeywordOrigin3 = false
      this.mockData = []
      if (this.searchKeywordOrigin === '1') {
        this.isEmptySearchKeywordOrigin1 = true
      } else if (this.searchKeywordOrigin === '2') {
        this.isEmptySearchKeywordOrigin2 = true
      } else if (this.searchKeywordOrigin === '') {
        this.isEmptySearchKeywordOrigin3 = true
      } else {
        this.mockData = Array.prototype.slice.call(viewMemberMocks)
      }
    }
  }
}
</script>
