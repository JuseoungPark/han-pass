<template>
 <section>
     <!-- 전산심사결과 start -->
     <div class="-pub-product__info">
        <div class="-pub-product__info--title">
            <h2>전산심사결과</h2>
        </div>
        <div class="-pub-product__result">
            <ul class="-pub-product__result--list">
                <li class="-pub-product__result--list-item">
                    <strong class="tit">선납할인</strong>
                    <div class="price">1,123,456,789원</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">선납P</strong>
                    <div class="price">1,123,456,789원</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">합계보험료</strong>
                    <div class="price">1,123,456,789원</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">실입금액</strong>
                    <div class="price">1,123,456,789원</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">전산심사일</strong>
                    <div class="date">2017-05-12</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">건강진단일</strong>
                    <div class="date">2017-05-12</div>
                </li>
                <li class="-pub-product__result--list-item">
                    <strong class="tit">전산심사결과</strong>
                    <div class="-pub-result -pub-result--normal" v-show="true">정상</div>
                    <div class="-pub-result -pub-result--unusual" v-show="false">비정상</div>
                </li>
            </ul>
        </div>
    </div>
    <!-- // 전산심사결과 end -->
 </section>
</template>
<script>
export default {
  data () {
    return {
    }
  }
}
</script>
