<template>
 <section>
     <!-- 신계약 보장기준 합산금액과 start -->
     <div class="-pub-product__info">
        <div class="-pub-product__info--title">
            <h2>신계약 보장기준 합산금액</h2>
            <p class="unit">단위 : 만원</p>
        </div>
        <div class="-pub-product__total">
            <ul class="-pub-product__total--list">
                <!-- 주피 -->
                <li class="-pub-product__total--list-item">
                    <div class="-pub-product__total--list-person">
                        <label class="-pub-badge-tag -pub-product__total__tag--beneficiary">주피</label>
                        <strong class="name">김광용용</strong>
                    </div>
                    <div class="-pub-product__total--list-row">
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">일사</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">재사</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">장애</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">암진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">2대진단</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">수술합산</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">종별수술</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">암입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해입원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해상해</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">종합실손</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">질병실손</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">실손종합입원</strong>
                            <span class="price">550,500</span>
                            <strong class="tit">실손종합통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손상해입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손상해통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손질병통원</strong>
                            <span class="price">50,500</span>
                        </div>
                    </div>
                </li>
                <!-- 종피 -->
                <li class="-pub-product__total--list-item">
                    <div class="-pub-product__total--list-person">
                        <label class="-pub-badge-tag -pub-product__total__tag--insured-person">종피</label>
                        <strong class="name">김하늘늘</strong>
                    </div>
                    <div class="-pub-product__total--list-row">
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">일사</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">재사</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">장애</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">암진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">2대진단</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">수술합산</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">종별수술</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">암입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해입원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해상해</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">종합실손</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">질병실손</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">실손종합입원</strong>
                            <span class="price">550,500</span>
                            <strong class="tit">실손종합통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손상해입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손상해통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손질병통원</strong>
                            <span class="price">50,500</span>
                        </div>
                    </div>
                </li>
                <!-- 자녀1 -->
                <li class="-pub-product__total--list-item">
                    <div class="-pub-product__total--list-person">
                        <label class="-pub-badge-tag -pub-product__total__tag--child-person">자녀1</label>
                        <strong class="name">이주명명</strong>
                    </div>
                    <div class="-pub-product__total--list-row">
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">일사</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">재사</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">장애</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">암진단</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">2대진단</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">수술합산</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">종별수술</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">암입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해입원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">재해상해</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">종합실손</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">질병실손</strong>
                            <span class="price">36,800</span>
                        </div>
                        <div class="-pub-product__total--list-row-box">
                            <strong class="tit">실손종합입원</strong>
                            <span class="price">550,500</span>
                            <strong class="tit">실손종합통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손상해입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손상해통원</strong>
                            <span class="price">3,680</span>
                            <strong class="tit">실손질병입원</strong>
                            <span class="price">50,500</span>
                            <strong class="tit">실손질병통원</strong>
                            <span class="price">50,500</span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <!-- // 신계약 보장기준 합산금액 end -->
 </section>
</template>
<script>
export default {
  data () {
    return {
    }
  }
}
</script>
