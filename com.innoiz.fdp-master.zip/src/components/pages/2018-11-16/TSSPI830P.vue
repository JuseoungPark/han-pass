<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="전산심사" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--electronic-result">
            <TSSPI840D></TSSPI840D>
            <TSSPI860D></TSSPI860D>
            <TSSPI850D></TSSPI850D>
        </div>
         <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <!-- 심사결과 진행가능한 경우 -->
            <ul class="-pub-bottom-nav" v-show="true">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">당사실손세부조회</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">AEUS</span>
                    </button>
                     <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                        <span class="-pub-button__text">발행</span>
                    </button>
                </li>
            </ul>
            <!-- 심사결과 비정상일 경우 -->
            <ul class="-pub-bottom-nav" v-show="false">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">당사실손세부조회</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">AEUS</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">인수심사기준조회</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">재심사</span>
                    </button>
                     <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse" disabled>
                        <span class="-pub-button__text">발행</span>
                    </button>
                </li>
            </ul>
            <!-- 심사결과 발행불가일 경우 -->
            <ul class="-pub-bottom-nav" v-show="false">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item" disabled>
                        <span class="-pub-button__text">당사실손세부조회</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item" disabled>
                        <span class="-pub-button__text">AEUS</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">전자청약</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">전자서명</span>
                    </button>
                     <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse" disabled>
                        <span class="-pub-button__text">발행</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
import TSSPI840D from '@/components/pages/2018-11-16/TSSPI840D'
import TSSPI850D from '@/components/pages/2018-11-16/TSSPI850D'
import TSSPI860D from '@/components/pages/2018-11-16/TSSPI860D'
export default {
  components: {
    TSSPI840D,
    TSSPI850D,
    TSSPI860D
  },
  data () {
    return {
      showPopup: true
    }
  }
}
</script>
