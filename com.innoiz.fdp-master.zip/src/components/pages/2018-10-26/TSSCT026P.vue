<template>
    <section class="-pub-popup__detail-personal">
        <div class="-pub-popup__content--detail-personal">
            <!-- 라이프 분석 start -->
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">라이프 분석</span>
                <span class="-pub-popup__title-dec">※ 2018.09.10 라이프 분석 결과</span>
            </div>
            <div class="-pub-popup__content--detail-form01">
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">고객선택 가구형태</dt>
                    <dd class="-pub-form-input">부부가구</dd>
                </dl>
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">추가가족 구성원</dt>
                    <dd class="-pub-form-input">배우자(51), 자녀(10), 자녀2(-)</dd>
                </dl>
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">선택 라이프분석</dt>
                    <dd class="-pub-form-input">가족보장, 생활보장, 의료보장, 노후보장</dd>
                </dl>
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">관심 인생이벤트</dt>
                    <dd class="-pub-form-input">노후자금, 해외여행, 자기계발, 부채상환</dd>
                </dl>
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">은퇴크레바스 여부</dt>
                    <dd class="-pub-form-input">있음 (65세 이전 은퇴)</dd>
                </dl>
                <dl class="-pub-form-row__5">
                    <dt class="-pub-form-title">희망 노후생활비(월)</dt>
                    <dd class="-pub-form-input">250~350 만원</dd>
                </dl>
            </div>
            <!-- 라이프 분석 end -->
        </div>
    </section>
</template>
