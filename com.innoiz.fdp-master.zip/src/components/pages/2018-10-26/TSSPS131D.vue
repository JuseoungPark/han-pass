<template>
    <section class="-pub-electronic-signature__step-content -pub-contractor">
        <div class="-pub-contractor-desc">
            <span>계약 관계자 정보 확인</span><span>변경한 정보는 고객카드에 반영됩니다.</span>
        </div>
        <!-- 181026 TSSPS131D 계약 관계자 정보 확인 - 전체 스크롤에서 내부 스크롤로 변경 하면서 div로 둘러쌈 -->
        <div class="-pub-scroll-wrap">
            <div class="-pub-accordion__item -pub-accordion-open">
                <!-- 계약자정보 -->
                <div class="-pub-contractor-info -pub-accordion__header">
                    <!-- 기본정보 -->
                    <div class="-pub-info__item -pub-info__item--basic">
                        <label class="-pub-badge-tag -pub-electronic-signature__tag--contractor">계약자</label><span>{{contractor.name}}</span><span>{{contractor.age}}세</span>
                    </div>
                    <!-- 주민번호 -->
                    <div class="-pub-info__item -pub-info__item--id">
                        <label class="-pub-info__item--label">주민번호</label>
                        <span>{{contractor.ssno}}</span>
                    </div>
                    <!-- 직장명 -->
                    <div class="-pub-info__item -pub-info__item--company-name">
                        <label class="-pub-info__item--label">직장명 <span class="-pub-info__item--label-star">*</span></label>
                        <fdp-validator name="tssps131d-validator-1" display-name="직장명" v-model="contractor.job" :rules="'required'">
                            <fdp-text-field v-model="contractor.job"></fdp-text-field>
                        </fdp-validator>
                    </div>
                    <!-- 업종 -->
                    <div class="-pub-info__item -pub-info__item--sectors">
                        <label class="-pub-info__item--label">업종</label>
                        <fdp-text-field v-model="contractor.jobType"></fdp-text-field>
                    </div>
                    <!-- 하시는 일 -->
                    <div class="-pub-info__item -pub-info__item--job">
                        <label class="-pub-info__item--label">하시는 일 <span class="-pub-info__item--label-star">*</span></label>
                        <fdp-validator name="tssps131d-validator-2" display-name="하시는 일" v-model="contractor.work" :rules="'required'">
                            <fdp-text-field v-model="contractor.work"></fdp-text-field>
                        </fdp-validator>
                        <span>{{contractor.workNm}}<br><strong>{{contractor.workNo}}</strong></span>
                    </div>
                    <button type="button" class="-pub-accordion__img" >
                        <img v-if="!isContOpen" src="@/assets/img/ico_arrow_up_big.png" alt="" @click="isContOpen = !isContOpen">
                        <img v-else src="@/assets/img/ico_arrow_down_big.png" alt="" @click="isContOpen = !isContOpen">
                    </button>
                </div>
                <div class="-pub-contractor-info-setting -pub-accordion__body" v-show="isContOpen">
                    <div class="-pub-contractor-info-setting__contact-info">
                        <span class="-pub-setting__info--title">연락처정보</span>
                        <ul>
                            <li class="-pub-setting__item">
                                <label>휴대폰번호</label>
                                <span class="-pub-mobile-no">010-1234-5678</span>
                            </li>
                            <li class="-pub-setting__item">
                                <label>문자서비스 <span>*</span></label>
                                <fdp-validator name="tssps131d-validator-3" display-name="문자서비스" v-model="returnData1" :rules="'required'">
                                    <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData1" :data="segmentData1"></fdp-segment-box>
                                </fdp-validator>
                            </li>
                            <li class="-pub-setting__item -pub__item--home-tel">
                                <label>집전화번호</label>
                                <fdp-select v-model="homeTelSelect" :option-list="homeTelList"></fdp-select>
                                <fdp-text-field v-model="homeTel"></fdp-text-field>
                            </li>
                            <li class="-pub-setting__item -pub-foreign-resident">
                                <label>해외거주자/<br>납세의무자 여부 <span>*</span></label>
                                <fdp-validator name="tssps131d-validator-4" display-name="해외거주자/납세의무자 여부" v-model="returnData2" :rules="'required'">
                                    <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData2" :data="segmentData2"></fdp-segment-box>
                                </fdp-validator>
                            </li>
                            <li class="-pub-setting__item">
                                <label>거주구분 <span>*</span></label>
                                <fdp-validator name="tssps131d-validator-5" display-name="거주구분" v-model="returnData6" :rules="'required'">
                                    <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData6" :data="segmentData6"></fdp-segment-box>
                                </fdp-validator>
                            </li>
                        </ul>
                    </div>
                    <div class="-pub-contractor-info-setting__recipient-info">
                        <span class="-pub-setting__info--title">수령지정보</span>
                        <ul>
                            <li class="-pub-setting__item">
                                <label>이메일</label>
                                <span class="-pub-email">{{!contractor.email?'없음' : contractor.email}}</span>
                            </li>
                            <li class="-pub-setting__item">
                                <label>이메일서비스 <span>*</span></label>
                                <fdp-validator name="tssps131d-validator-6" display-name="이메일서비스" v-model="returnData11" :rules="'required'">
                                    <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData11" :data="segmentData1" :disabled="contractor.email.length<1"></fdp-segment-box>
                                </fdp-validator>
                            </li>
                            <li class="-pub-setting__item">
                                <div>
                                    <label>증권수령방법 <span>*</span></label>
                                    <fdp-validator name="tssps131d-validator-7" display-name="증권수령방법" v-model="returnData3" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--large -pub-segment__container" v-model="returnData3" :data="segmentData3"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </li>
                            <li class="-pub-setting__item -pub__item--email">
                                <fdp-select v-model="consultantdata" :option-list="consultant" placeholder="선택"></fdp-select>
                            </li>
                            <li class="-pub-setting__item">
                                <label>주소 <span>*</span></label>
                                <fdp-validator name="tssps131d-validator-8" display-name="주소" v-model="returnData5" :rules="'required'">
                                    <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData5" :data="segmentData5"></fdp-segment-box>
                                </fdp-validator>
                            </li>
                            <li class="-pub-setting__item">
                                <button type="button" class="-pub-button -pub-zipcode-button"><span>우편번호</span></button>
                                <fdp-text-field class="-pub-customer-register-form__input -pub-setting__item--addr" v-model="zipcode" readonly></fdp-text-field>
                                <span>주소는 자택/직장 중 현재 선택된 주소구분에 대한 정보만 수정됩니다<br>
                                        자택/직장 중 선택하여 입력한 주소구분에 따라 청약서상 기본우편물 수령처로 지정됩니다.</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- 계약자 정보 end -->
            </div>
            <div class="-pub-accordion__item -pub-accordion-open">
                <!-- 피보험자 정보 -->
                <div class="-pub-insured-person-info -pub-accordion__header">
                    <!-- 기본정보 -->
                    <div class="-pub-info__item -pub-info__item--basic">
                        <label class="-pub-badge-tag -pub-electronic-signature__tag--insured-person">피보험자</label><span>{{insuredPerson.name}}</span><span>{{insuredPerson.age}}세</span>
                    </div>
                    <!-- 주민번호 -->
                    <div class="-pub-info__item -pub-info__item--id">
                        <label class="-pub-info__item--label">주민번호</label>
                        <span>6{{insuredPerson.ssno}}</span>
                    </div>
                    <!-- 직장명 -->
                    <div class="-pub-info__item -pub-info__item--company-name">
                        <label class="-pub-info__item--label">직장명 <span class="-pub-info__item--label-star">*</span></label>
                        <fdp-validator name="tssps131d-validator-9" display-name="직장명" v-model="insuredPerson.job" :rules="'required'">
                            <fdp-text-field v-model="insuredPerson.job"></fdp-text-field>
                        </fdp-validator>
                    </div>
                    <!-- 업종 -->
                    <div class="-pub-info__item -pub-info__item--sectors">
                        <label class="-pub-info__item--label">업종</label>
                        <fdp-text-field v-model="insuredPerson.jobType"></fdp-text-field>
                    </div>
                    <!-- 하시는일 -->
                    <div class="-pub-info__item -pub-info__item--job">
                        <label class="-pub-info__item--label">하시는 일 <span class="-pub-info__item--label-star">*</span></label>
                        <fdp-validator name="tssps131d-validator-10" display-name="하시는 일" v-model="insuredPerson.work" :rules="'required'">
                            <fdp-text-field v-model="insuredPerson.work"></fdp-text-field>
                        </fdp-validator>
                        <span>{{insuredPerson.workNm}}<br><strong>{{insuredPerson.workNo}}</strong></span>
                    </div>
                    <button type="button" class="-pub-accordion__img" >
                        <img v-if="!isInsOpen" src="@/assets/img/ico_arrow_up_big.png" alt="" @click="isInsOpen = !isInsOpen">
                        <img v-else src="@/assets/img/ico_arrow_down_big.png" alt="" @click="isInsOpen = !isInsOpen">
                    </button>
                </div>
                <div class="-pub-contractor-info-setting -pub-accordion__body" v-show="isInsOpen">
                        <div class="-pub-contractor-info-setting__contact-info">
                            <span class="-pub-setting__info--title">연락처정보</span>
                            <ul>
                                <li class="-pub-setting__item">
                                    <label>휴대폰번호</label>
                                    <span class="-pub-mobile-no">010-1234-5678</span>
                                </li>
                                <li class="-pub-setting__item">
                                    <label>문자서비스 <span>*</span></label>
                                    <fdp-validator name="tssps131d-validator-11" display-name="문자서비스" v-model="returnData1" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData1" :data="segmentData1"></fdp-segment-box>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-setting__item -pub__item--home-tel">
                                    <label>집전화번호</label>
                                    <fdp-select v-model="homeTelSelect" :option-list="homeTelList"></fdp-select>
                                    <fdp-text-field v-model="homeTel"></fdp-text-field>
                                </li>
                                <li class="-pub-setting__item">
                                    <label>거주구분 <span>*</span></label>
                                    <fdp-validator name="tssps131d-validator-12" display-name="거주구분" v-model="returnData6" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData6" :data="segmentData6"></fdp-segment-box>
                                    </fdp-validator>
                                </li>
                            </ul>
                        </div>
                        <div class="-pub-contractor-info-setting__recipient-info">
                            <span class="-pub-setting__info--title">수령지정보</span>
                            <ul>
                                <li class="-pub-setting__item">
                                    <label>이메일</label>
                                    <span class="-pub-email">{{!insuredPerson.email?'없음' : insuredPerson.email}}</span>
                                </li>
                                <li class="-pub-setting__item">
                                    <label>이메일서비스 <span>*</span></label>
                                    <fdp-validator name="tssps131d-validator-13" display-name="이메일서비스" v-model="returnData113" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData113" :data="segmentData1" :disabled="insuredPerson.email.length<1"></fdp-segment-box>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-setting__item">
                                    <label>주소 <span>*</span></label>
                                    <fdp-validator name="tssps131d-validator-14" display-name="주소" v-model="returnData7" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData7" :data="segmentData5"></fdp-segment-box>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-setting__item">
                                    <button type="button" class="-pub-button -pub-zipcode-button"><span>우편번호</span></button>
                                    <fdp-text-field class="-pub-customer-register-form__input -pub-setting__item--addr" v-model="zipcode" readonly></fdp-text-field>
                                    <span>주소는 자택/직장 중 현재 선택된 주소구분에 대한 정보만 수정됩니다<br>
                                            자택/직장 중 선택하여 입력한 주소구분에 따라 청약서상 기본우편물 수령처로 지정됩니다.</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                <!-- 피보험자 정보 end -->
            </div>
            <div>
                <!-- 수익자 정보 -->
                <div class="-pub-beneficiary-info">
                    <!-- 기본정보 -->
                    <div class="-pub-info__item -pub-info__item--basic">
                        <label class="-pub-badge-tag -pub-electronic-signature__tag--beneficiary">수익자</label><span>김서현</span><span>22세</span>
                    </div>
                    <!-- 주민번호 -->
                    <div class="-pub-info__item -pub-info__item--id">
                        <label class="-pub-info__item--label">주민번호</label>
                        <span>660403-2136987</span>
                    </div>
                    <!-- 세부구분 -->
                    <div class="-pub-info__item -pub-info__item--detail">
                        <label class="-pub-info__item--label">세부구분</label>
                        <span>상해시</span>
                    </div>
                    <!-- 지급율 -->
                    <div class="-pub-info__item -pub-info__item--payment-rate">
                        <label class="-pub-info__item--label">지급율</label>
                        <span>100%</span>
                    </div>
                </div>
                <!-- 수익자 정보 end -->
            </div>
            <div>
                <!-- 수익자 정보 -->
                <div class="-pub-beneficiary-info">
                    <!-- 기본정보 -->
                    <div class="-pub-info__item -pub-info__item--basic">
                        <label class="-pub-badge-tag -pub-electronic-signature__tag--beneficiary">수익자</label><span>김서현</span><span>22세</span>
                    </div>
                    <!-- 주민번호 -->
                    <div class="-pub-info__item -pub-info__item--id">
                        <label class="-pub-info__item--label">주민번호</label>
                        <span>660403-2136987</span>
                    </div>
                    <!-- 세부구분 -->
                    <div class="-pub-info__item -pub-info__item--detail">
                        <label class="-pub-info__item--label">세부구분</label>
                        <span>상해시</span>
                    </div>
                    <!-- 지급율 -->
                    <div class="-pub-info__item -pub-info__item--payment-rate">
                        <label class="-pub-info__item--label">지급율</label>
                        <span>100%</span>
                    </div>
                </div>
                <!-- 수익자 정보 end -->
            </div>
        </div>

        <!-- 이전, 다음 버튼 bottom bar -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full" v-show="true">
            <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                <button type="button" class="-pub-button -pub-button--next" @click="$emit('move', 'next')">다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼"></button>
            </div>
        </fdp-bottom-bar>
    </section>
</template>
<script>
export default {
  data () {
    return {
      company: '삼성생명',
      sectors: 'IT서비스업',
      job: '관리직',
      zipcode: '(05510) 서울시 송파구 올림픽로 125길 35',
      isContOpen: true,
      isInsOpen: true,
      isDisable: true,
      returnData1: [],
      returnData2: [],
      returnData3: [],
      returnData5: [],
      returnData6: [],
      returnData7: [],
      returnData11: [],
      returnData113: [{
        'key': '111',
        'label': '수신'
      }],
      segmentData1: [{
        'key': '111',
        'label': '수신'
      },
      {
        'key': '222',
        'label': '수신안함'
      }],
      segmentData6: [{
        'key': '111',
        'label': '국내'
      },
      {
        'key': '222',
        'label': '해외'

      }],
      segmentData2: [{
        'key': '111',
        'label': '해당없음'
      },
      {
        'key': '222',
        'label': '해당함'
      }],
      segmentData3: [{
        'key': '111',
        'label': '이메일'
      },
      {
        'key': '222',
        'label': '자택 일반우편'
      },
      {
        'key': '333',
        'label': '직장 일반우편'
      },
      {
        'key': '444',
        'label': '컨설턴트 방문'
      }],
      segmentData4: [{
        'key': '111',
        'label': '모바일'
      },
      {
        'key': '222',
        'label': '종이책자'
      }],
      segmentData5: [{
        'key': '111',
        'label': '자택'
      },
      {
        'key': '222',
        'label': '직장'
      }],
      homeTel: '4567-7898',
      homeTelSelect: {
        label: '020',
        key: 'a'
      },
      homeTelList: [{
        label: '020',
        key: 'a'
      },
      {
        label: '030',
        key: 'b'
      },
      {
        label: '040',
        key: 'c'
      },
      {
        label: '050',
        key: 'd'
      }],
      email: '',
      emailItems: [{
        label: 'aaaaaaaaadfwfewfwfa.com',
        key: 'a'
      },
      {
        label: 'b.com',
        key: 'b'
      },
      {
        label: 'c.com',
        key: 'c'
      },
      {
        label: 'd.com',
        key: 'd'
      }],
      consultantdata: {
        key: '',
        label: ''
      },
      consultant: [{
        label: '고액낱장',
        key: 'a'
      },
      {
        label: '지점발행',
        key: 'b'
      }],
      selectedValue: {
        key: '',
        label: ''
      },
      contractor: { // 고객카드라고 가정
        name: '이주명',
        age: '52',
        ssno: '660403-2136987',
        job: '삼성생명',
        jobType: 'IT서비스업',
        work: '관리직',
        workNm: '사무원',
        workNo: '0423020',
        email: 'User0000@domain.com' // 빈값이면 이메일 서비스 비활성화
      },
      insuredPerson: { // 피보험자카드라고 가정
        name: '이주명',
        age: '52',
        ssno: '660403-2136987',
        job: '삼성생명',
        jobType: 'IT서비스업',
        work: '관리직',
        workNm: '사무원',
        workNo: '0423020',
        email: '' // 빈값이면 이메일 서비스 비활성화
      }
    }
  },
  watch: {
    returnData3 () {
      if (this.returnData3.length > 0 && this.returnData3[0].key === '444') {
        this.isDisable = false
      } else {
        this.isDisable = true
      }
    }
  }
}
</script>
