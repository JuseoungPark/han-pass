<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="일련번호 조회" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup__info--number">
            <div class="-pub-popup__info--number-wrap">
                <div class="-pub-filter-menu">
                    <div class="-pub-filter-menu__item--right">
                       <fdp-text-field class="-pub-filter-menu__item -pub-search-input" placeholder="일련번호" v-model="searchKeyword" clearable></fdp-text-field>
                            <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="clickSearch">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </div>
                    <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
                </div>
                <fdp-infinite class="-pub-table -pub-table-blue" single-select :items="mockData" v-model="radioSelected" :tableBodyHeight="376">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column--radiobox" style="width:78px;"></th>
                            <th class="-pub-table-column" style="width:140px;">구분</th>
                            <th class="-pub-table-column" style="width:1174px;">주민등록번호</th>
                        </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column--radiobox" style="width:78px;">
                            <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item"></fdp-radio>
                        </td>
                        <td class="-pub-table-column" style="width:140px"><strong>{{props.item.key}}</strong></td>
                        <td class="-pub-table-column en" style="width:1174px">{{props.item.num}}</td>
                    </template>
                    <!-- no data 화면 : 고객조회 데이터가 없는 경우 -->
                    <template slot="emptyView" v-if="showNoDataView">
                        <div class="-pub-table-empty-view">
                            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                        </div>
                    </template>
                    <!-- 검색결과 없을때 화면 : 고객조회 검색결과가 없는 경우 -->
                    <template slot="emptyView" v-if="showEmptyView">
                        <div class="-pub-table-empty-view -pub-table-empty-view--search">
                            <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                        </div>
                    </template>

                </fdp-infinite>
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button class="-pub-button -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      searchKeyword: '',
      keyword: '',
      showEmptyView: false,
      showNoDataView: false,
      radioSelected: {},
      tableItems: [],
      mockData: [],
      tableData: [
        {
          key: '1',
          num: '901205-2******'
        },
        {
          key: '2',
          num: '901205-2******'
        },
        {
          key: '3',
          num: '901205-2******'
        },
        {
          key: '4',
          num: '901205-2******'
        },
        {
          key: '5',
          num: '901205-2******'
        }
      ]
    }
  },
  methods: {
    clickSearch () {
      this.keyword = this.searchKeyword
      console.log('## keyword', this.keyword)

      // 디자인 검수용
      if (this.keyword === '123') { // 일련번호가 123 이면 '데이터가 존재하지 않습니다.' 보여주기
        this.mockData = []
        this.showEmptyView = false
        this.showNoDataView = true
      } else if (this.keyword === '111') { // 일련번호가 111 이면 '검색결과가 존재하지 않습니다.' 보여주기
        this.mockData = []
        this.showEmptyView = true
        this.showNoDataView = false
      } else { // 그 일련번호 값은 데이터 보여주기
        this.mockData = this.tableData
        this.showEmptyView = false
        this.showNoDataView = false
      }
    }
  },
  mounted () {
    this.mockData = this.tableData
  }
}
</script>
