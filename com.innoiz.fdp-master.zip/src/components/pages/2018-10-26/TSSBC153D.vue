<template>
  <div>
    <div class="-pub-notice">
        <fdp-notice ref="notice"></fdp-notice>
    </div>
    <div class="-pub-notice-btn-white-wrap">
      <a href="#" class="btn-white" @click="addSystemNotice">시스템공지1</a>
      <a href="#" class="btn-white" @click="addSystemNotice2">시스템공지2</a>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true
    }
  },
  computed: {},
  methods: {
    addSystemNotice () {
      this.$refs.notice.makeNotice('오늘은 시스템 업데이트로 8.11(목) 20:00~24:00까지 접속하실 수 없습니다.')
    },
    addSystemNotice2 () {
      this.$refs.notice.makeNotice('오늘은 시스템 업데이트로 8.11(목) 20:00~24:00까지 접속하실 수 없습니다.오늘은 시스템 업데이트로 8.11(목) 20:00~24:00까지 접속하실 수 없습니다.')
    }
  }
}
</script>
