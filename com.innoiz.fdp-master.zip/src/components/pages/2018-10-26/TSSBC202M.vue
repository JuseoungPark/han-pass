<template>
    <section class="-pub-container__customer--home-meet">
        <div class="-pub-container__customer--home-meet-sidebar">
            <div class="-pub-container__customer--home-meet-sidebar-header">
                <h2 class="tit"><strong class="name">이주현</strong>님<br>안녕하세요?</h2>
                <p class="desc">고객님을 위해 일하는<br><em class="corp">삼성생명</em>입니다.</p>
                <p class="txt">고객님과 삼성생명이<br>동반자가 된지</p>
                <p class="period"><em class="date">125</em> 일째</p>
            </div>
            <div class="box">
                <p class="desc">보장내용 등을 분석해드릴 수<br>있는 기간이 <em class="date1">15일</em> 남았습니다.</p>
                <div class="btn-area-right"><a href="#" class="btn-agree">동의연장</a></div>
            </div>
            <div class="box">
                <p class="desc">새로운 서비스 등을 안내드릴 수<br>있는 기간이 <em class="date2">90일</em> 남았습니다.</p>
                <div class="btn-area-right"><a href="#" class="btn-agree">동의연장</a></div>
            </div>
        </div>
        <div class="-pub-container__customer--home-meet-content">
            <h3 class="tit">이주현님의<br><strong class="imp">인생에서 가장 중요한 준비사항</strong>은 무엇인가요?</h3>
            <ul class="prepare-list">
                <li class="prepare-list-item">
                    <a href="#">
                        <img src="@/assets/img/img_home_family.png" alt="">
                        <strong class="stit">가족보장</strong>
                        <span class="txt">소중한 가족을 위한<br><em>보장준비</em></span>
                    </a>
                </li>
                <li class="prepare-list-item">
                    <a href="#">
                        <img src="@/assets/img/img_home_life.png" alt="">
                        <strong class="stit">생활보장</strong>
                        <span class="txt">큰 병에 걸려도 걱정없는<br><em>생활비 마련</em></span>
                    </a>
                </li>
                <li class="prepare-list-item">
                    <a href="#">
                        <img src="@/assets/img/img_home_medical.png" alt="">
                        <strong class="stit">의료보장</strong>
                        <span class="txt">병원비 부담을 줄이는<br><em>평생의료비 준비</em></span>
                    </a>
                </li>
                <li class="prepare-list-item">
                    <a href="#">
                        <img src="@/assets/img/img_home_old.png" alt="">
                        <strong class="stit">노후보장</strong>
                        <span class="txt">제2의 인생을 위한<br><em>노후준비</em></span>
                    </a>
                </li>
            </ul>
            <div class="btn-area-center">
                <a href="#" class="btn-analysis"><span class="ico-analysis">나의 보장분석</span></a>
                <a href="#" class="btn-plan"><span class="ico-plan">꼭 맞는 가입설계</span><span class="num">3</span></a>
            </div>
        </div>
   </section>
</template>
<script>
export default {
  methods: {
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    }
  }
}
</script>
