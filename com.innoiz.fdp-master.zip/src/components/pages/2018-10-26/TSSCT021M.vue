<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--full">
      <div class="-pub-consulting-content__scroll -pub-consulting-content__scroll--visible-shadow">
        <ul class="-pub-area" data-direction="horizontal" v-if="!isEmpty">
          <li class="-pub-card -pub-card--product-graph" v-for="(product, index) in productList" :key="index">
            <h1 class="-pub-card__title" >
              <span class="-pub-card__title-text">{{product.name}}</span>
              <span class="-pub-card__price">{{product.price}}<span class="-pub-card__price-unit">원</span></span>
              <button class="-pub-card__button">가입설계</button>
            </h1>
            <section class="-pub-card__content">
              <p class="-pub-card__desc">* 동일 보험료(30만원)납입에 따른 65세 연금 수령액 차이</p>
              <div class="-pub-card__graph-area">
                <div class="-pub-graph-zone"></div>
              </div>
            </section>
          </li>
        </ul>
        <div class="-pub-table-empty-view" v-else>
          <div class="empty-table-content__text">상품컨설팅 단계에서 추가한 상품이 없습니다.</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {productList} from '@/components/mock/TSSCT021M.mock'
export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }

  },
  data () {
    return {
      isEmpty: false,
      productList: Array.prototype.slice.call(productList)
    }
  }
}
</script>
