<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="질병 상세 정보" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__deaInfo">
        <div class="-pub-popup__content">
            <div class="-pub-popup__contents--name">
              <div class="-pub-popup__deaInfo--tit">질병명</div>
              <div class="-pub-popup__deaInfo--content">{{disease.name}}</div>
            </div>
            <div class="-pub-popup__contents--01" v-if="disease.definition">
              <div class="-pub-popup__deaInfo--tit">정의</div>
              <div class="-pub-popup__deaInfo--content">
                {{disease.definition}}
              </div>
            </div>
            <div class="-pub-popup__contents--02" v-if="disease.reason">
              <div class="-pub-popup__deaInfo--tit">원인</div>
              <div class="-pub-popup__deaInfo--content">
                {{disease.reason}}
              </div>
            </div>
            <div class="-pub-popup__contents--03" v-if="disease.symptom">
              <div class="-pub-popup__deaInfo--tit">증상</div>
              <div class="-pub-popup__deaInfo--content">
                {{disease.symptom}}
              </div>
            </div>
        </div>
        <div class="-pub-bottom-bar">
          <div class="-pub-confirm__content--right">
            <button type="button" class="-pub-button -pub-button--reverse" @click="showPopup = !showPopup">
              <span class="-pub-button__text">확인</span>
            </button>
          </div>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      disease: {
        name: '감기',
        definition: '감기는 바이러스에 의해 코와 목 부분을 포함한 상부 호흡기계의 감염 증상으로, 사람에게 나타나는 가장 흔한 급성 질환 중 하나이다. 재채기, 코막힘, 콧물, 인후통, 기침, 미열, 두통 및 근육통과 같은 증상이 나타나지만 대개는 특별한 치료 없이도 저절로 치유된다.',
        reason: '200여개 이상의 서로 다른 종류의 바이러스가 감기를 일으킨다. 그 중 30~50%가 리노바이러스(Rhinovirus)이고 10~15%가 코로나바이러스(Coronavirus)이다. 성인은 일년에 2~4회, 소아는 6~10회 정도 감기에 걸린다. 감기 바이러스는 사람의 코나 목을 통해 들어와 감염을 일으킨다. 감기 바이러스를 가지고 있는 환자의 코와 입에서 나오는 분비물이 재채기나 기침을 통해 외부로 나오게 되면 그 속에 있는 감기 바이러스가 공기 중에 존재하다가 건강한 사람의 입이나 코에 닿아 전파된다. 따라서 감기 환자와 가까이 있거나 사람이 많은 곳에 감기 환자가 있으면 감기 바이러스가 잘 전파된다. 이러한 호흡기 감염 경로 외에 감기 환자의 호흡기 분비물이 묻어있는 수건 등을 만진 후 그 손으로 눈이나 코, 입 등을 비볐을 때에도 감기 바이러스에 감염된다. 실내에서 생활하는 시간이 많은 가을과 겨울에 감기에 더 잘 걸리며, 겨울이 없는 지역에서는 우기에 감기에 더 잘 걸린다. 독감은 감기와 일부 증상이 비슷할 수 있지만 원인 바이러스가 다르며, 증상이나 합병증, 치료법도 다르다.',
        symptom: '감기 바이러스에 노출된 지 1~3일 후에 증상이 나타난다. 증상은 감기 바이러스가 상부 호흡기계에 어느 정도 침투했는가에 따라 다양하게 나타난다. 콧물, 코막힘, 목 부위의 통증, 기침과 근육통이 흔하게 나타나는 증상이다. 성인에게서 열이 나는 경우는 드물거나 미열에 그치지만, 소아에게서는 발열 증상이 흔하게 나타난다. 결막염이 동반되어 눈물이 날 수도 있다. 환자의 연령, 기존에 앓고 있었던 질환, 면역상태 등에 따라 증상의 정도가 달라질 수 있다. 감기의 경과 중에 다른 합병증이 없어도 콧물이 진해지고, 누렇거나 푸르게 변하기도 한다.'
      }
    }
  },
  methods: {
    // 질병 데이터 없을땐 아래 데이터로 바꿔서 확인
  //   changeDisease () {
  //     this.disease = {
  //       'name': '데이터 없는 질병',
  //       'definition': '',
  //       'reason': '',
  //       'symptom': ''
  //     }
  //   }
  }
}
</script>
