<template>
  <section class="-pub-suggest-thumbnail">
    <div class="-pub-page-header">
        <h3 class="-pub-page-header__title">제안스크립트</h3>
    </div>
    <div class="-pub-suggest-thumbnail__content">
      <div class="-pub-suggest-thumbnail__content--tablist">
        <ul>
          <li class="-pub-suggest-thumbnail__content--tab -pub-suggest-thumbnail__content--tab-5" :class="currIdx==='전체'? '-pub-tab-active':''" @click="selectTab('전체')">전체</li><!-- 선택시 추가 클래스 -pub-tab-active -->
          <li class="-pub-suggest-thumbnail__content--tab -pub-suggest-thumbnail__content--tab-1" :class="currIdx==='가족'? '-pub-tab-active':''" @click="selectTab('가족')">가족</li><!-- 선택시 추가 클래스 -pub-tab-active -->
          <li class="-pub-suggest-thumbnail__content--tab -pub-suggest-thumbnail__content--tab-2" :class="currIdx==='생활'? '-pub-tab-active':''" @click="selectTab('생활')">생활</li><!-- 선택시 추가 클래스 -pub-tab-active -->
          <li class="-pub-suggest-thumbnail__content--tab -pub-suggest-thumbnail__content--tab-3" :class="currIdx==='의료'? '-pub-tab-active':''" @click="selectTab('의료')">의료</li><!-- 선택시 추가 클래스 -pub-tab-active -->
          <li class="-pub-suggest-thumbnail__content--tab -pub-suggest-thumbnail__content--tab-4" :class="currIdx==='노후'? '-pub-tab-active':''" @click="selectTab('노후')">노후</li><!-- 선택시 추가 클래스 -pub-tab-active -->
        </ul>
      </div>
      <div class="-pub-suggest-thumbnail__content--list">
        <ul>
          <!-- thumbnail start -->
          <li v-for="(item, idx) in items" :key="idx" class="-pub-suggest-thumbnail__content--list-item" v-if="filter(item)">
            <div class="-pub-suggest-thumbnail__content--badge" :class="tabClass(item)">{{item.group}}</div>
            <div class="-pub-suggest-thumbnail__summary-tit">
              {{item.title}}
            </div>
            <div class="-pub-suggest-thumbnail__summary-cont">
              {{item.cont}}
            </div>
            <div class="-pub-suggest-thumbnail__img">
              <!-- 썸네일 이미지 위치-->
              <img :src="item.img">
            </div>
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  data () {
    return {
      currIdx: '전체',
      items: [
        {
          group: '가족',
          title: '내 가족을 위한 준비, 어떤 것이 필요할까요?',
          cont: '40대에는 삶 속에 숨어있는 보이지 않는 위험 에 대해 본인은 물론 배우자의 보장자산에 대한 점검하고 배우자의 보장자산에 대한...',
          img: require('../../../assets/img/suggest/img.png')
        },
        {
          group: '생활',
          title: '시간으로 복립의 마법을 두배로',
          cont: '40대인 고객님의 나이는 보장자산 준비와 ‘이자가 이자를 불리는 복리의 마법’을 활용할 수 있는 적절한 시기로, 긴 시간을 이용하여 최적한 시기로, 긴 시간을 이용하여 최적...',
          img: require('../../../assets/img/suggest/img2.png')
        },
        {
          group: '의료',
          title: '가구당 평균 부채는 5,994만원, 빚의 대물림 방지를 위한 준비',
          cont: '어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 길고 긴 노후를 누리기 위해 의료비와 가족생활비를...',
          img: require('../../../assets/img/suggest/script-img-1.png')
        }, {
          group: '노후',
          title: '가구당 평균 부채는 5,994만원, 빚의 대물림 방지를 위한 준비',
          cont: '40대인 고객님의 나이는 보장자산 준비와 ‘이자가 이자를 불리는 복리의 마법’을 활용할 수 있는 적절한 시기로, 긴 시간을 이용하여 최적...',
          img: require('../../../assets/img/suggest/img2.png')
        }, {
          group: '가족',
          title: '내 가족을 위한 준비, 어떤 것이 필요할까요?',
          cont: '40대에는 삶 속에 숨어있는 보이지 않는 위험 에 대해 본인은 물론 배우자의 보장자산에 대한 점검하고 배우자의 보장자산에 대한...',
          img: require('../../../assets/img/suggest/script-img-2.png')
        }
      ]
    }
  },
  methods: {
    tabClass (item) {
      switch (item.group) {
        case '가족':
          return '-pub-suggest-thumbnail__content--badge--fr-1'

        case '생활':
          return '-pub-suggest-thumbnail__content--badge--fr-2'

        case '의료':
          return '-pub-suggest-thumbnail__content--badge--fr-3'

        case '노후':
          return '-pub-suggest-thumbnail__content--badge--fr-4'
      }
    },
    selectTab (tab) {
      this.currIdx = tab
    },
    filter (item) {
      let filtered = false
      if (this.currIdx === '전체') {
        filtered = true
      } else {
        if (item.group === this.currIdx) {
          filtered = true
        }
      }
      return filtered
    }
  }
}
</script>
