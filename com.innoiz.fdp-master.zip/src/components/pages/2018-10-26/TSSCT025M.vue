<template>
  <div class="-pub-life__graph-area -pub-life__graph-area--type-2">
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-1" data-text="지출">
      <img class="-pub-life__graph-img -pub-life__graph-img--event" src="@/assets/img/life/img_red_chart_event.png" alt="그래프 이미지" />
    </div>
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-2" data-text="수입">
      <img class="-pub-life__graph-img" src="@/assets/img/life/img-blue-chart-event.png" alt="그래프 이미지" />
    </div>
    <div class="-pub-life__graph-area -pub-life__fold-content">
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-1">
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">현재</p>
        <span class="-pub-life__graph-age-text">40세</span>
      </div>
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-7">
        <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-24"></div>
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">사망</p>
      </div>
      <div class="-pub-life__guide-line -pub-life__guide-line--small" data-text="경제활동 기간"></div>
      <div class="-pub-life__area-graph -pub-life__area-graph--type-2">
        <!-- 배경이미지 삭제 <img src="@/assets/img/life/block-dot-red-area.png">-->
        <ul class="-pub-life__event-layer-area ">
          <li class="-pub-life__event-layer-item -pub-life__event-layer-item--ico-5">
            주택구입
            <a class="-pub-life__group-item-remove-button"></a>
          </li>
          <li class="-pub-life__event-layer-item -pub-life__event-layer-item--ico-3">
            자녀결혼
            <fdp-tooltip-button class="-pub-tooltip -pub-tooltip--img-button" top>
              <template slot="activator">
                <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="은퇴 크레바스 버튼">
              </template>
              <template slot="content">
                <h3 class="-pub-tooltip-layer__title">자녀 결혼자금</h3>
                <div class="-pub-tooltip-layer__content">
                  <span>
                    1명당 <span class="bold-text">6,770만원</span> (아들 9,373만원 / 딸 4,167만원)<br>
                    출처 : 삼성생명 은퇴연구소, 2016
                  </span>
                </div>
              </template>
            </fdp-tooltip-button>
            <a class="-pub-life__group-item-remove-button"></a>
          </li>
          <li class="-pub-life__event-layer-item -pub-life__event-layer-item--ico-2">
            자녀대학
            <fdp-tooltip-button class="-pub-tooltip -pub-tooltip--img-button" top>
              <template slot="activator">
                <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="은퇴 크레바스 버튼">
              </template>
              <template slot="content">
                <h3 class="-pub-tooltip-layer__title">자녀 대학자금</h3>
                <div class="-pub-tooltip-layer__content">
                  <span>
                    1명당 <span class="bold-text">2,948만원</span> (2016년 사립대 평균기준)<br>
                    출처 : 대학교육연구소, 2017
                  </span>
                </div>
              </template>
            </fdp-tooltip-button>
            <a class="-pub-life__group-item-remove-button"></a>
          </li>
        </ul>
      </div>
      <span class="-pub-life__shadow-text -pub-life__shadow-text--type-2 -pub-life__shadow-text--font-1">
        <span @click="tooltip1 = !tooltip1">가족 필요자금<br>현재 연봉의 5배</span><!-- 2018/11/13 텍스트 변경 -->
        <div class="-fdp-tooltip-button -pub-tooltip -pub-tooltip--img-button" top>
          <button type="button" class="-fdp-tooltip-button__activator" @click="tooltip1 = !tooltip1">
            <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="은퇴 크레바스 버튼">
          </button>
          <div class="-fdp-tooltip-button__content" v-show="tooltip1">
            <button type="button" class="-fdp-tooltip-button__close-button" @click="tooltip1 = false">X</button>
            <h3 class="-pub-tooltip-layer__title">가장 유고시 가족 필요자금</h3>
            <div class="-pub-tooltip-layer__content">
              현재 연봉의 5배<br> <!-- 2018/11/13 텍스트 변경 -->
              자료 출처 : 보험연구원, 2014
            </div>
          </div>
        </div>
      </span>
    </div>
    <!-- 그래프 좌측영역 분리 콘텐츠 end -->
  </div>
</template>
<script>
export default {
  props: {
    pensions: {
      type: Array,
      default: _ => [{
        checked: true,
        name: '국민연금'
      },
      {
        checked: true,
        name: '퇴직연금'
      },
      {
        checked: false,
        name: '개인연금'
      }
      ]
    },
    currentLivingPrice: {
      type: Object,
      default: _ => {}
    }
  },
  data () {
    return {
      tooltip1: false,
      isExpand: false,
      showCrevasse: true,
      showExapndTooltip: true,
      showRetirementAge: false,
      segment1: {
        items: [{
          key: '1',
          label: '65세 이전'
        },
        {
          key: '2',
          label: '65세 이후'
        }
        ],
        value: [{
          key: '1'
        }]
      }
    }
  },
  computed: {
    hasPensionsCount () {
      return this.pensions.filter(pension => pension.checked).length
    }
  },
  methods: {
    changeRetirementAge () {
      this.showCrevasse = this.segment1.value[0].key === '1'
      this.showRetirementAge = false
    }
  }
}
</script>
