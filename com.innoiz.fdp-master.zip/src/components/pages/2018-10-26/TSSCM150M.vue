<template>
  <section class="-pub-customer-register">
    <div class="-pub-customer-register__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">고객등록동의</span>
      </h1>
      <div class="-pub-customer__authtype-segment">
        <fdp-segment-box class="-pub-segment--medium -pub-segment__container " v-model="authType" :data="authTypes"></fdp-segment-box>
      </div>
    </div>
    <div class="-pub-customer-register__qr-code">
        <span class="-pub-qr-text-1">고객님께서 직접하는 안전한 정보제공</span>
        <div class="-pub-qr-img">
            <img src="@/assets/img/qr - area.png" alt="">
        </div>
        <span class="-pub-qr-text-2">※ 고객님 휴대폰으로 QR코드를 스캔해주세요</span>
    </div>
  </section>
</template>
<script>
export default {
  data () {
    return {
      authTypes: [{
        key: '1',
        label: '휴대폰/카드'
      },
      {
        key: '2',
        label: 'QR코드'
      },
      {
        key: '3',
        label: '지류'
      }],
      authType: []
    }
  },
  created () {
    this.authType.push(this.authTypes[1])
  }
}
</script>
