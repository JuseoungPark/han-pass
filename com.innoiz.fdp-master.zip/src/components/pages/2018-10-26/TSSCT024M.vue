<template>
  <div class="-pub-life__graph-area -pub-life__graph-area--type-2">
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-3" data-text="지출">
      <img class="-pub-life__graph-img" src="@/assets/img/life/img_red_chart_2.png" alt="그래프 이미지" />
    </div>
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-2" data-text="수입">
      <img class="-pub-life__graph-img" src="@/assets/img/life/img-blue-chart.png" alt="그래프 이미지" />
    </div>
    <div class="-pub-life__graph-area -pub-life__fold-content">
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-1">
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">현재</p>
        <span class="-pub-life__graph-age-text">40세</span>
      </div>
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-4 -pub-life__graph-timeline-item--no-line">
        <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-5">
          <a class="-pub-life__group-item-remove-button"></a>
        </div>
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">주택구입</p>
      </div>
      <div class="-pub-life__graph-timeline-item" :style="{ left: '906px' }">
        <a>
          <span class="-pub-life__graph-timeline-symbol -pub-life__graph-timeline-symbol--update"></span>
          <p class="-pub-life__graph-time-text">은퇴</p>
        </a>
      </div>
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-6 -pub-life__graph-timeline-item--no-line">
        <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-7">
          <a class="-pub-life__group-item-remove-button"></a>
        </div>
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">여가취미</p>
      </div>
      <div class="-pub-life__guide-line -pub-life__guide-line--default" data-text="경제활동 기간"></div>
      <div class="-pub-life__guide-line -pub-life__guide-line--right" data-text="노후생활 기간"></div>
      <div class="-pub-life__area-graph">
        <img src="@/assets/img/life/img-red-line-area.png">
      </div>
      <span class="-pub-life__shadow-text -pub-life__shadow-text--type-1">
        <span @click="tooltip1 = !tooltip1">의료비<br>월평균 470,000 만원</span>
        <div class="-fdp-tooltip-button -pub-tooltip -pub-tooltip--img-button" top>
          <button type="button" class="-fdp-tooltip-button__activator" @click="tooltip1 = !tooltip1">
            <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="툴팁 버튼">
          </button>
          <div class="-fdp-tooltip-button__content" v-show="tooltip1">
            <button type="button" class="-fdp-tooltip-button__close-button" @click="tooltip1 = false">X</button>
            <h3 class="-pub-tooltip-layer__title">평생 의료비</h3>
            <div class="-pub-tooltip-layer__content">
              직접의료비, 요양병원, 간병비 포함<br>
              자료출처 : 삼성생명 은퇴연구소, 2016
            </div>
          </div>
        </div>
      </span>
      <span class="-pub-life__fixed-text -pub-life__fixed-text--type-1">생활필요자금</span>
    </div>
    <!-- 그래프 좌측영역 분리 콘텐츠 end -->
  </div>
</template>
<script>
export default {
  props: {
    pensions: {
      type: Array,
      default: _ => [{
        checked: true,
        name: '국민연금'
      },
      {
        checked: true,
        name: '퇴직연금'
      },
      {
        checked: false,
        name: '개인연금'
      }
      ]
    },
    currentLivingPrice: {
      type: Object,
      default: _ => {}
    }
  },
  data () {
    return {
      tooltip1: false,
      isExpand: false,
      showCrevasse: true,
      showExapndTooltip: true,
      showRetirementAge: false,
      segment1: {
        items: [{
          key: '1',
          label: '65세 이전'
        },
        {
          key: '2',
          label: '65세 이후'
        }
        ],
        value: [{
          key: '1'
        }]
      }
    }
  },
  computed: {
    hasPensionsCount () {
      return this.pensions.filter(pension => pension.checked).length
    }
  },
  methods: {
    changeRetirementAge () {
      this.showCrevasse = this.segment1.value[0].key === '1'
      this.showRetirementAge = false
    }
  }
}
</script>
