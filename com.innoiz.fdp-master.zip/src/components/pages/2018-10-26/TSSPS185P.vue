<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="수익자 상이 동의" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup__profit--agreement">
            <div class="-pub-electronic-signature__step-title -pub-electronic-signature__step-title--contractor">
                <label class="-pub-badge-tag -pub-electronic-signature__tag--profit">수익자</label><span v-if="selectedData.length===1">이주명</span><!-- 수익자가 한명일 경우 -->
                <fdp-select v-model="selectedValue" :option-list="selectedData" placeholder="고객명 선택" v-else></fdp-select><!-- 수익자가 여러명 일 경우 -->
            </div>
            <div v-show="isOpenContractor">
                <div class="-pub-electronic-signature__container--agreement">
                    <!-- 친권자 정보 : 수익자가 미성년일 경우 start -->
                    <div v-if="selectedValue.isMinor">
                        <h2 class="-pub-customer-register__step-title">친권자 정보</h2>
                        <div class="-pub-electronic-signature__step-parent">
                            <label class="name">성명</label><fdp-validator name="tsscps185p-validator-1" display-name="이름" v-model="inputName" :rules="'required'">
                                <fdp-text-field class="pub-text-field" v-model="inputName" placeholder="입력하세요"></fdp-text-field>
                            </fdp-validator>
                            <label class="birthday">생년월일</label><fdp-validator name="tsscps185p-validator-2" display-name="생년월일" v-model="inputBirthday" :rules="'required'">
                                <fdp-text-field class="pub-text-field en" v-model="inputBirthday" placeholder="000000 - 0"></fdp-text-field>
                                <span class="masking">XXXXXX</span>
                            </fdp-validator>
                        </div>
                    </div>
                    <!-- 친권자 정보 : 수익자가 미성년일 경우 end -->
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">본인인증 동의서</h2>
                    <!-- step sub title end -->

                    <!-- 동의 항목 list : 친권자 정보가 있을 때 ul에 class 추가 -pub-electronic-signature__step--agreement--height -->
                    <ul class="-pub-electronic-signature__step--agreement" :class="selectedValue.isMinor?'-pub-electronic-signature__step--agreement--height':''">
                        <li class="-pub-electronic-signature__step--agree-all" :class="{'-pub-electronic-signature__step--active': cardOne.isAllAgree}">
                            <span class="-pub-text">본인인증 동의에 관한 사항</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.isAllAgree" @click.native="onSelectAgreeAll(1)">전체동의</fdp-checkbox>
                        </li>
                        <!-- -pub-accordion-open 아코디언 펼쳐짐 -->
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[0].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[0].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="1">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[0].opened=!requiredAgreementContent[0].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[0].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[1].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[1].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="2">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[1].opened=!requiredAgreementContent[1].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[1].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[2].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[2].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="3">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[2].opened=!requiredAgreementContent[2].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[2].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item -pub-accordion__item__sub" :class="{'-pub-accordion-open': requiredAgreementContent[3].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[3].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="4">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[3].opened=!requiredAgreementContent[3].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[3].content}}
                                </span>
                            </div>
                            <div class="-pub-accordion__sub-content">
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="phone">질병·상해정보 처리</fdp-checkbox>
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="text">주민등록번호·외국인등록번호 처리</fdp-checkbox>
                            </div>
                        </li>
                    </ul>
                    <!-- 동의 항목 list end -->
                </div>
                <!-- 계약자 본인인증 동의서 화면 end -->

                <!-- 계약자 신원확인 및 본인인증 화면 -->
                <!-- 좌측 본인인증 동의 전체 체크 시 영역 활성화됨. -pub-electronic-signature__container--id-verification--disabled 를 넣어주면 비활성화 -->
                <!-- fdp 컴포넌트에 disable 속성이 있는 것들은 개별처리 ex) dp-segment-box, fdp-text-field, fdp-checkbox -->
                <div class="-pub-electronic-signature__container--id-verification" :class="{'-pub-electronic-signature__container--id-verification--disabled' : !cardOne.isAllAgree}">
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">본인인증</h2>
                    <!-- step sub title end -->
                    <div class="-pub-customer-register__container">
                        <!-- 인증방식 -->
                        <div class=" -pub-electronic-signature-form__row -pub-electronic-signature-form__row--auth-type">
                            <div class="-pub-electronic-signature-form__header">인증방식</div>
                            <div class="-pub-electronic-signature-form__content">
                                <fdp-segment-box class="-pub-segment__container -pub-segment--medium" v-model="authType1" :data="authTypes" :disabled="!cardOne.isAllAgree" essential></fdp-segment-box>
                            </div>
                        </div>
                        <!-- 인증방식 end -->
                        <TSSPS122D v-if="authType1[0].key === '1'" :disabled="!cardOne.isAllAgree"></TSSPS122D>
                        <TSSPS123D v-else :disabled="!cardOne.isAllAgree"></TSSPS123D>
                    </div>
                </div>
                <!-- 계약자 신원확인 및 본인인증 화면 end -->
            </div>

        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                 <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--guide -pub-bottom-nav__item--centered">
                    모든 수익자 동의가 완료되어야 확인버튼이 활성화됩니다.
                </li>
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--small -pub-bottom-nav__item">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <!--전체 동의 대상에 동의 완료 후에만 확인 버튼 활성화(disabled 제거) -->
                    <button class="-pub-button -pub-button--small -pub-bottom-nav__item -pub-button--reverse" :disabled="!cardOne.isAllAgree">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </li>
            </ul>

        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
import TSSPS122D from '@/components/pages/2018-09-28/TSSPS122D'
import TSSPS123D from '@/components/pages/2018-09-28/TSSPS123D'

export default {
  components: {
    TSSPS122D,
    TSSPS123D
  },
  data () {
    return {
      showPopup: true,
      inputName: '',
      inputBirthday: '',
      selectedValue: { key: '이주명', label: '이주명' },
      selectedData: [{
        key: '이주명',
        label: '이주명'
      },
      {
        key: '김첫째',
        label: '김첫째',
        disabled: true
      },
      {
        key: '김둘째',
        label: '김둘째',
        isMinor: true
      },
      {
        key: '김셋째',
        label: '김셋째',
        isMinor: true
      }],
      cardOne: {
        state: '1',
        allItems: ['1', '2', '3', '4', '5', '6'],
        agreeCheckboxList: [],
        marketingCheckboxList: [],
        isAllAgree: false

      },
      cardTwo: {
        state: '2',
        allItems: ['1', '2', '3', '4'],
        agreeCheckboxList: [],
        marketingCheckboxList: [],
        isAllAgree: false

      },
      isOpenContractor: true,
      agreeCheckboxList: [],
      marketingCheckboxList: [],
      singleCheckbox1: false,
      singleCheckbox2: false,
      singleCheckbox3: false,
      singleCheckbox4: false,
      singleCheckbox5: false,
      singleCheckbox6: false,
      singleCheckbox7: false,
      singleCheckbox8: true,
      singleCheckbox9: true,
      singleCheckbox10: true,
      singleCheckbox11: true,
      singleCheckbox12: true,
      singleCheckbox13: true,
      singleCheckbox14: true,
      // [ 181029 인증방식 텍스트 수정
      authTypes: [{
        key: '1',
        label: '휴대폰'
      },
      {
        key: '2',
        label: '신용카드'
      }
      ],
      authType1: [{
        key: '1',
        label: '휴대폰'
      }],
      // 181029 인증방식 텍스트 수정 ]
      authType2: [{
        key: '2',
        label: '신용카드'
      }],
      requiredAgreementContent: [
        {
          opened: false,
          title: '1. 개인(신용)정보 수집·이용 동의에 관한 사항',
          content: `이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.
이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.`
        },
        {
          opened: false,
          title: '2. 개인(신용)정보 조회에 관한 사항',
          content: `이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다.
 또한, 법정대리인(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다.`
        },
        {
          opened: false,
          title: '3. 개인(신용)정보 등의 제공에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '4. 민감정보 및 고유식별정보 처리에 관한 사항',
          content: ``
        }
      ],
      requiredAgreementContent2: [
        {
          opened: false,
          title: '1. 개인(신용)정보 수집 · 이용 동의에 관한 사항',
          content: `이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.
이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.`
        },
        {
          opened: false,
          title: '2. 개인(신용)정보 조회에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '3. 개인(신용)정보 등의 제공에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '4. 민감정보 및 고유식별정보 처리에 관한 사항',
          content: ``
        }
      ]
    }
  },
  watch: {
    isOpenContractor (newValue) {
      if (newValue) {
        // 계약자 카드 열릴때
        if (this.cardOne.isAllAgree) {
          this.cardOne.state = '3'
        } else {
          this.cardOne.state = '1'
        }
        if (this.cardTwo.isAllAgree) {
          this.cardTwo.state = '3'
        } else {
          this.cardTwo.state = '2'
        }
      } else {
        // 피계약자 카드 열릴때
        // 계약자 동의 전이면 cardOne.state는 2(인증하기 버튼), 동의 후면 cardOne.state는 3(동의완료 텍스트)
        if (this.cardOne.isAllAgree) {
          this.cardOne.state = '3'
        } else {
          this.cardOne.state = '2'
        }
        if (this.cardTwo.isAllAgree) {
          this.cardTwo.state = '3'
        } else {
          this.cardTwo.state = '1'
        }
      }
    },
    'cardOne.agreeCheckboxList' (newValue) {
      if ((newValue.length === this.cardOne.allItems.length && !this.cardOne.isAllAgree) ||
          (newValue.length !== this.cardOne.allItems.length && this.cardOne.isAllAgree)) {
        this.cardOne.isAllAgree = !this.cardOne.isAllAgree
      }
    },
    'cardTwo.agreeCheckboxList' (newValue) {
      if ((newValue.length === this.cardTwo.allItems.length && !this.cardTwo.isAllAgree) ||
          (newValue.length !== this.cardTwo.allItems.length && this.cardTwo.isAllAgree)) {
        this.cardTwo.isAllAgree = !this.cardTwo.isAllAgree
      }
    }
  },
  methods: {
    doLater (cardNumber) {
      this.isOpenContractor = !this.isOpenContractor
      if (cardNumber === 1) {

      } else {

      }
    },
    doCertify (cardNumber) {
      this.isOpenContractor = !this.isOpenContractor
    },
    onSelectAgreeAll (cardNumber) {
      if (cardNumber === 1) {
        this.cardOne.agreeCheckboxList = this.cardOne.isAllAgree ? this.cardOne.allItems : []
      } else {
        this.cardTwo.agreeCheckboxList = this.cardTwo.isAllAgree ? this.cardTwo.allItems : []
      }
    }
  }
}
</script>
