<!-- 설계청약 전자서명 탭 영역 -->
<template>
    <div class="-pub-tab-body-wrap -pub-electronic-signature-tab">
        <div class="-pub-filter-menu -pub-filter-menu--in-tab">
            <div class="-pub-filter-menu__item--right">
                <form onsubmit="return false;">
                    <fdp-select class="-pub-select -pub-select--purple -pub-filter-menu__item -pub-filter-menu__item--select detail-type-6" v-model="selectBoxValue" :option-list="selectBoxItems" ellipsis></fdp-select>
                    <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="입력하세요." v-model="searchKeyword" clearable></fdp-text-field>
                    <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                        <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                    </button>
                </form>
            </div>
            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{tableData.length}}건</div>
            <div class="-pub-radio-wrap">
                <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioTable" value="1">전자서명</fdp-radio>
                <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioTable" value="2">중단건조회</fdp-radio>
            </div>
        </div>
        <!-- 페이지 조회 input, button 검색 명수 영역 end -->
        <template v-if="radioTable==='1'">
            <!-- 전자서명 테이블 영역 -->
            <fdp-infinite class="-pub-table -pub-table--customer-service -pub-table--programmed-proposal -pub-table-1" single-select v-model="selectItems" :table-body-height="radioValue ? 762 : 896" :items="tableData">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column--checkbox"></th>
                        <th v-for="item in tableHeader1.headerItems" :key="item.title" :style="item.styleObject" :class="[{'-pub-table-column':true},{'-pub-table-column--sorting':item.sort.isSort}]" @click="sortFunc(item)">
                            <!-- sorting이 필요한 컬럼 -->
                            <span v-if="item.sort.isSort" :class="[{'-pub-table-column__text':true}, {'-pub-sorting--active':item.isActive}, {'-pub-sorting--up': item.sort.asc}, {'-pub-sorting--purple': item.isActive}]">{{item.title}}
                                <img v-if="item.sort.isSort" src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                            </span>
                            <!-- sorting이 필요 없는 컬럼 -->
                            <span v-else :class="[{'-pub-table-column__text':true}]">{{item.title}}</span>
                        </th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column--checkbox">
                        <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioValue" :value="props.item.idx"></fdp-radio>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 150px;">{{props.item.date}}</td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                        {{props.item.contractor}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                        {{props.item.insuredPerson}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--left-align" style="width: 184px;">
                        <div class="-pub-table-colmn__single-line--ellipsis -pub-colored-text--2">
                            {{props.item.item}}
                        </div>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 316px;">
                        {{props.item.no}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--right-align -pub-table-column--normal-letter" style="width: 162px;">
                        {{props.item.cost}}
                    </td>
                    <td class="-pub-table-column" style="width: 100px;">
                        {{props.item.data1}}
                    </td>
                    <td class="-pub-table-column" style="width: 130px;">
                        <template v-if="props.item.data2">
                            <button class="-pub-pp-table-column__button -pub-progress-button -pub-colored-text--1">{{props.item.data2}}</button>
                        </template>
                    </td>
                    <td class="-pub-table-column" style="width: 156px;">
                        <template v-if="props.item.step === '재처리'">
                            <button class="-pub-pp-table-column__button -pub-progress-button -pub-colored-text--1">{{props.item.step}}</button>
                        </template>
                        <template v-else>
                            <span>{{props.item.step}}</span>
                        </template>
                    </td>
                </template>
                <!-- no data 화면 -->
                <template slot="emptyView" v-if="searchRes==='1'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">진행중인 가입설계 건이 없습니다.</div>
                    </div>
                </template>
                <!-- 검색결과 없을때 화면 -->
                <template slot="emptyView" v-if="searchRes==='2'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                    </div>
                </template>
            </fdp-infinite>
            <!-- 전자서명 테이블 영역 end -->
        </template>
        <!-- 페이지 조회 input, button 검색 명수 영역 end -->
        <template v-else>
            <!-- 중단건조회 테이블 영역 -->
            <fdp-infinite class="-pub-table -pub-table--customer-service -pub-table--programmed-proposal -pub-table-2" v-model="selectItems2" :table-body-height="896" :items="tableData2">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th v-for="item in tableHeader2.headerItems" :key="item.title" :style="item.styleObject" :class="[{'-pub-table-column':true},{'-pub-table-column--sorting':item.sort.isSort}]" @click="sortFunc(item)">
                            <!-- sorting이 필요한 컬럼 -->
                            <span v-if="item.sort.isSort" :class="[{'-pub-table-column__text':true}, {'-pub-sorting--active':item.isActive}, {'-pub-sorting--up': item.sort.asc}, {'-pub-sorting--purple': item.isActive}]">{{item.title}}
                                <img v-if="item.sort.isSort" src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                            </span>
                            <!-- sorting이 필요 없는 컬럼 -->
                            <span v-else :class="[{'-pub-table-column__text':true}]">{{item.title}}</span>
                        </th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 150px;">{{props.item.date}}</td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                        {{props.item.contractor}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                        {{props.item.insuredPerson}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--left-align" style="width: 184px;">
                        <div class="-pub-table-colmn__single-line--ellipsis -pub-colored-text--2">
                            {{props.item.item}}
                        </div>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 316px;">
                        {{props.item.no}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--right-align -pub-table-column--normal-letter" style="width: 162px;">
                        {{props.item.cost}}
                    </td>
                    <td class="-pub-table-column" style="width: 178px;">
                        <template v-if="props.item.data3">
                            <button class="-pub-pp-table-column__button -pub-progress-button -pub-colored-text--1 -pub-button--full">{{props.item.data3}}</button>
                        </template>
                    </td>
                    <td class="-pub-table-column" style="width: 224px;">
                        <span>{{props.item.data4}}</span>
                    </td>
                </template>
                <!-- no data 화면 -->
                <template slot="emptyView" v-if="searchRes==='1'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">진행중인 가입설계 건이 없습니다.</div>
                    </div>
                </template>
                <!-- 검색결과 없을때 화면 -->
                <template slot="emptyView" v-if="searchRes==='2'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                    </div>
                </template>
            </fdp-infinite>
            <!-- 중단건조회 테이블 영역 end -->
        </template>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="radioValue" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">계약서류발송</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
</template>
<script>
import { viewMemberMocks } from '@/components/mock/TSSPS213D.mock'
import FdpRadio from '../../../lib/fdp/components/fdpRadio/fdpRadio'

export default {
  components: {
    FdpRadio
  },
  computed: {
  },
  data () {
    return {
      selectBoxValue: {
        key: '1',
        label: '고객명'
      },
      selectBoxItems: [{
        key: '1',
        label: '고객명'
      },
      {
        key: '2',
        label: '상품명'
      },
      {
        key: '3',
        label: '영수증번호'
      }],
      tableData: Object.assign([], viewMemberMocks),
      tableData2: Object.assign([], viewMemberMocks),
      mockHeader: [],
      searchKeyword: '',
      searchRes: '',
      radioValue: '',
      radioTable: '1',
      selectItems: [],
      selectItems2: [],
      tableHeader1: {
        lastVisitColumn: '0',
        // fdp-infinite 헤더 관리
        headerItems: [
          {idx: 0, title: '청약일', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '150px'}},
          {idx: 1, title: '계약자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 2, title: '피보험자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 3, title: '상품명', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '184px'}},
          {idx: 4, title: '영수증번호', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '316px'}},
          {idx: 5, title: '보험료(원)', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '162px'}},
          {idx: 6, title: '교부방식', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '100px'}},
          {idx: 7, title: '청약관리', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '130px'}},
          {idx: 8, title: '진행현황', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '156px'}}
        ]
      },
      tableHeader2: {
        lastVisitColumn: '0',
        // fdp-infinite 헤더 관리
        headerItems: [
          {idx: 0, title: '청약일', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '150px'}},
          {idx: 1, title: '계약자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 2, title: '피보험자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 3, title: '상품명', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '184px'}},
          {idx: 4, title: '영수증번호', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '316px'}},
          {idx: 5, title: '보험료(원)', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '162px'}},
          {idx: 6, title: '청약관리', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '178px'}},
          {idx: 7, title: '진행현황', isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '224px'}}
        ]
      }
    }
  },
  watch: {
    selectItems () {
      if (this.selectItems) {
        this.radioValue = this.selectItems.idx
      }
    },
    radioTable () {
      if (this.radioTable === '2') {
        this.selectItems = []
        this.radioValue = ''
      }
    }
  },
  methods: {
    // 소팅 처리
    sortFunc (item) {
      let data = ''

      if (item.sort.isSort) {
        if (this.radioTable === '1') {
          this.tableHeader1.headerItems[this.tableHeader1.lastVisitColumn].isActive = false
          this.tableHeader1.lastVisitColumn = item.idx
          data = this.tableData
        } else {
          this.tableHeader2.headerItems[this.tableHeader2.lastVisitColumn].isActive = false
          this.tableHeader2.lastVisitColumn = item.idx
          data = this.tableData2
        }
        // 선택 컬럼 active, 마지막 선택 컬럼 inactive

        item.isActive = true
        item.sort.asc = !item.sort.asc

        // Mockup 데이터
        // let data = this.tableData

        if (item.title.localeCompare('청약일') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.date.localeCompare(b.date)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.date.localeCompare(a.date)
              }
            )
          }
        } else if (item.title.localeCompare('계약자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.contractor.localeCompare(b.contractor)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.contractor.localeCompare(a.contractor)
              }
            )
          }
        } else if (item.title.localeCompare('피보험자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.insuredPerson.localeCompare(b.insuredPerson)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.insuredPerson.localeCompare(a.insuredPerson)
              }
            )
          }
        } else {}
      }
    },
    onSearch () { // 검색어 2: 검색결과 없음, 1: 진행건 없음
      let searchData = ''
      if (this.searchKeyword === '') {
        this.searchRes = ''
        searchData = Object.assign([], viewMemberMocks)
      } else if (this.searchKeyword === '1') {
        this.searchRes = '1'
        searchData = []
      } else {
        this.searchRes = '2'
        searchData = []
      }

      if (this.radioTable === '1') {
        this.tableData = searchData
      } else {
        this.tableData2 = searchData
      }
    }
  }
}
</script>
