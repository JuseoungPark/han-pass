<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="표준모델선택" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-consulting-popup__standard">
                <div class="-pub-consulting-popup__standard--header">
                    <fdp-radio class="-pub-radio" v-model="radioStrValue" value="표준형">표준형</fdp-radio>
                    <fdp-radio class="-pub-radio" v-model="radioStrValue" value="컨설턴트 선택형">컨설턴트 선택형</fdp-radio>
                </div>
                <div class="-pub-consulting-popup__standard--dec">
                    단위: 만원
                </div>
                <!-- 표준형 start -->
                <div class="-pub-consulting-popup__standard--content" v-show="radioStrValue === '표준형'">
                    <table class="-pub-consulting-popup__standard--table-header">
                        <colgroup>
                            <col width="876px" />
                            <col width="220px" />
                        </colgroup>
                        <thead>
                            <tr>
                                <th>보장구분</th>
                                <th>표준모델</th>
                            </tr>
                        </thead>
                    </table>
                    <div class="-pub-table-body__scroll">
                        <table class="-pub-consulting-popup__standard--table-body" v-for="(row, index) in mockData" :key="index">
                            <colgroup>
                                <col width="270px" />
                                <col width="313px" />
                                <col width="243px" />
                                <col width="228px" />
                            </colgroup>
                            <!-- 대분류 : 중분류 : 소분류 - 1 : N : N 반복될떄 대분류 텍스트 반복되는 문제수정 -->
                            <tbody>
                              <template v-for="(column, index2) in row.columns" >
                                <template v-for="(data, index3) in column.data">
                                    <tr :key="'' + index + index2 + index3">
                                        <td class="align-left td-left-padding" v-if="index2 === 0 && index3 === 0" :rowspan="calcTotalLength(row.columns)">{{row.title}}</td>
                                        <td class="align-left" v-if="index3 === 0" :rowspan="column.data.length">{{column.title}}</td>
                                        <td><span class="align-left">{{data.type}}</span></td>
                                        <td><span class="align-right -pub-normal-letter"><fdp-text-field v-model="data.requireAmount" mask="won" readonly></fdp-text-field></span></td>
                                    </tr>
                                </template>
                              </template>
                              <!-- 대분류 : 중분류 : 소분류 - 1 : N : N 반복될떄 대분류 텍스트 반복되는 문제수정 end -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- 표준형 end -->
                <!-- 컨설턴트 선택형 start -->
                <div class="-pub-consulting-popup__standard--content" v-show="radioStrValue === '컨설턴트 선택형'">
                    <table class="-pub-consulting-popup__standard--table-header">
                        <colgroup>
                            <col width="876px" />
                            <col width="220px" />
                        </colgroup>
                        <thead>
                            <tr>
                                <th>보장구분</th>
                                <th>표준모델</th>
                            </tr>
                        </thead>
                    </table>
                    <div class="-pub-table-body__scroll">
                        <table class="-pub-consulting-popup__standard--table-body -pub-consultent__choice" v-for="(row, index) in mockData" :key="index">
                            <colgroup>
                                <col width="270px" />
                                <col width="313px" />
                                <col width="243px" />
                                <col width="228px" />
                            </colgroup>
                            <!-- 대분류 : 중분류 : 소분류 - 1 : N : N 반복될떄 대분류 텍스트 반복되는 문제수정 -->
                            <tbody>
                              <template v-for="(column, index2) in row.columns" >
                                <template v-for="(data, index3) in column.data">
                                    <tr :key="'' + index + index2 + index3">
                                        <td class="align-left td-left-padding" v-if="index2 === 0 && index3 === 0" :rowspan="calcTotalLength(row.columns)" >{{row.title}}</td>
                                        <td class="align-left" v-if="index3 === 0" :rowspan="column.data.length" >{{column.title}}</td>
                                        <td><span class="align-left">{{data.type}}</span></td>
                                        <td>
                                            <span class="align-right">
                                                <fdp-validator :name="'tssct009p-validator' + index + '-' + index2 + '-' + index3" v-model="data.requireAmount" :display-name="data.type" :rules="'required'">
                                                    <fdp-text-field v-model="data.requireAmount" virtual alignRight mask="won"></fdp-text-field>
                                                </fdp-validator>
                                            </span>
                                        </td>
                                    </tr>
                                </template>
                              </template>
                            </tbody>
                            <!-- 대분류 : 중분류 : 소분류 - 1 : N : N 반복될떄 대분류 텍스트 반복되는 문제수정 end -->
                        </table>
                    </div>
                </div>
                <!-- 컨설턴트 선택형 end -->
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
                <div class="-pub-bottom-nav">
                    <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                        <button type="button" class="-pub-button" @click="showPopup = !showPopup">취소</button><button type="button" class="-pub-button -pub-button--reverse">확인</button>
                    </div>
                </div>
            </fdp-bottom-bar>
        </div>
    </fdp-popup>
</template>
<script>
import { mockData } from '@/components/mock/TSSCT009P.mock'

export default {
  data () {
    return {
      showPopup: true,
      defaultUsage: '',
      radioStrValue: '표준형',
      Name: '',
      mockData: Array.prototype.slice.call(mockData)
    }
  },
  methods: {
    calcTotalLength (arr = []) {
      return arr.reduce((previous, current) => previous + current.data.length, 0)
    }
  }
}

</script>
