<template>
    <section class="-pub-customer-register -pub-tsscm101m">
        <div class="-pub-customer-register__header">
            <h1 class="-pub-customer-register__title">
                <a class="-pub-customer-register__button -pub-customer-register__button--back">
                    <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
                </a>
                <span class="-pub-customer-register__text--parent-bottom">고객등록동의</span>
            </h1>
            <div class="-pub-customer__authtype-segment">
                <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="authType" :data="authTypes"></fdp-segment-box>
            </div>
            <fdp-stepper class="-pub-stepper -pub-customer-register__stepper" v-model="currentStep" :space="22" clickable>
                <fdp-step :step="1" :current="currentStep"></fdp-step>
                <fdp-step :step="2" :current="currentStep"></fdp-step>
            </fdp-stepper>
        </div>
        <div class="-pub-customer-register__content">
            <!-- step1 content -->
            <section class="-pub-customer-register__step-content -pub-step-1">
                <div class="-pub-customer-register__step-content--customer-form">
                    <form class="-pub-form -pub-customer-register-form -pub-customer-register-form--parent">
                        <!-- step sub title -->
                        <h2 class="-pub-customer-register__step-title">고객정보 입력</h2>
                        <!-- step sub title end -->
                        <!-- form delete button -->
                        <!--<a class="-pub-customer-register-form__button -pub-customer-register-form__button--delete -pub-button--close"></a>-->
                        <!-- form delete button end -->
                        <div class="-pub-customer-register__container">
                            <!-- 고객명 입력영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    고객명
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <!-- <fdp-validator name="tsscm101m-validator-1" display-name="고객명신규기존" v-model="customerType" :rules="'required'"> -->
                                        <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item -pub-customer-register-form__segment--customer"
                                         v-model="customerType" :data="customerTypes" essential></fdp-segment-box>
                                    <!-- </fdp-validator> -->
                                    <fdp-validator name="tsscm101m-validator-1" display-name="고객명" v-model="formInputs.customerName" :rules="'required'">
                                        <!-- 신규고객일때 -->
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--name"
                                         v-model="formInputs.customerName" placeholder="입력해주세요." v-if="true"></fdp-text-field>
                                         <!-- 기존고객일때 -->
                                         <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--name"
                                         v-model="formInputs.customerName" placeholder="입력해주세요." fixedIcon v-else></fdp-text-field>
                                    </fdp-validator>
                                    <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox" v-model="checkboxs.isForeigner">외국인</fdp-checkbox>
                                </div>
                            </div>
                            <!-- 고객명 입력영역 end -->
                            <!-- 동의 유형 입력 영역-->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    동의유형선택
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <fdp-validator name="tsscm101m-validator-2" display-name="동의유형선택" v-model="checkboxs.agreeType" :rules="'required'">
                                        <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox -pub-checkbox--consulting"
                                            v-model="checkboxs.agreeType" value="1">필수컨설팅</fdp-checkbox>
                                        <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox" v-model="checkboxs.agreeType"
                                            value="2">마케팅</fdp-checkbox>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 동의 유형 입력 영역 end -->
                            <!-- 주민등록번호 or 외국인 주민등록번호 입력 영역-->
                            <div class="-pub-customer-register-form__row">
                                <!-- 국내 주민등록번호 케이스 -->
                                <div class="-pub-customer-register-form__header -pub-customer-register-form__content--layer-1" v-if="!checkboxs.isForeigner">
                                    주민등록번호
                                    <span class="-pub-required"></span>
                                </div>
                                <!-- 국내 주민등록번호 케이스 end -->
                                <!-- 외국인등록번호 케이스 -->
                                <div class="-pub-customer-register-form__header -pub-customer-register-form__content--layer-1" v-else>
                                    외국인등록번호
                                    <span class="-pub-required"></span>
                                    <fdp-tooltip-button class="-pub-tooltip-button -pub-foreigner">
                                        <template slot="activator">
                                            <img class="tooltip-icon-img" src="@/assets/img/components/btn_info_gray.png" alt="주민등록번호 툴팁">
                                        </template>
                                        <template slot="content">
                                            <img src="@/assets/img/customer/social_number_tooltip_content.png" alt="외국인 주민등록번호 입력 가이드" />
                                        </template>
                                    </fdp-tooltip-button>
                                </div>
                                <!-- 외국인등록번호 케이스 end -->
                                <div class="-pub-customer-register-form__content">
                                    <fdp-validator name="tsscm101m-validator-3" display-name="주민등록번호" v-model="combinedSocialNumber" :rules="socialNumberRules">
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--social"
                                            v-model="formInputs.socialNumbers[0]" placeholder="000000"></fdp-text-field>
                                        <span class="-pub-customer-register-form__item -pub-customer-register-form__dash"></span>
                                        <!-- 기본케이스 주민번호 뒷자리 입력 field -->
                                        <template v-if="checkboxs.agreeTypeSub === false">
                                            <fdp-text-field :class="[{'-pub-customer-register-form__item':true}, {'-pub-customer-register-form__input':true}, {'-pub-customer-register-form__input--social':true}, {'-pub-customer-register-form__input--invalid':!tempCustomer}]"
                                                v-model="formInputs.socialNumbers[1]" placeholder="000000"></fdp-text-field>
                                        </template>
                                        <!-- 주민번호 뒷자리 입력 field end -->
                                    </fdp-validator>
                                    <!-- 마케팅만 체크시에 남/여 segment-box와 확보여부 체크박스 케이스 마크업 -->
                                    <template v-if="checkboxs.agreeType.length === 1 && checkboxs.agreeType[0] === '2'">
                                        <fdp-segment-box v-show="checkboxs.agreeTypeSub === true" class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item -pub-customer-register-form__segment -pub-customer-register-form__segment--gender"
                                            v-model="gender" :data="genders" essential></fdp-segment-box>
                                        <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox -pub-chk-uncertain" v-model="checkboxs.agreeTypeSub">미확보</fdp-checkbox>
                                    </template>
                                    <!-- 마케팅만 체크시에 남/여 segment-box와 확보여부 체크박스 케이스 마크업 end -->
                                </div>
                                <!-- [ 181113 버튼추가 -->
                                <button type="button" class="-pub-customer-register-form__item -pub-button -pub-button--light -pub-serial-no-lookup-button"><span>일련번호 조회</span></button>
                                <!-- 181113 버튼추가 ] -->
                            </div>
                            <!-- 휴대폰번호 입력영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    휴대폰번호
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-2">
                                    <fdp-validator name="tsscm101m-validator-4" display-name="휴대폰번호" v-model="formInputs.phoneNumber" :rules="'required'">
                                        <fdp-select class="-pub-customer-register-form__item -pub-customer-register-form__select -pub-customer-register-form__select--phone"
                                            v-model="selectValues.phoneFirstNumber" :option-list="phoneItems"></fdp-select>
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--phone"
                                            v-model="formInputs.phoneNumber" placeholder="0000-0000" mask="phone"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 휴대폰번호 입력영역 end -->
                            <!-- 이메일 입력영역  -->
                            <div class="-pub-customer-register-form__row">
                                <!-- [ 181031 필수표시 및 validator 주석처리 -->
                                <div class="-pub-customer-register-form__header">
                                    이메일
                                    <!-- <span class="-pub-required"></span> -->
                                </div>
                                <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-3">
                                    <!-- <fdp-validator name="tsscm101m-validator-5" display-name="이메일" v-model="combinedEmail" :rules="emailRules"> -->
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--email"
                                            v-model="formInputs.email[0]" placeholder="입력해주세요."></fdp-text-field>
                                        <span class="-pub-at-sign">@</span>
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--email"
                                            v-model="formInputs.email[1]" placeholder="입력해주세요." :disabled="selectValues.emailAfterAddr.key !== '0'"></fdp-text-field>
                                        <fdp-select class="-pub-customer-register-form__item -pub-customer-register-form__select -pub-customer-register-form__select--email"
                                            v-model="selectValues.emailAfterAddr" :option-list="emailItems" ellipsis></fdp-select>
                                    <!-- </fdp-validator> -->
                                </div>
                                <!-- 181031 필수표시 및 validator 주석처리 ] -->
                            </div>
                            <!-- 이메일 입력영역 end -->
                            <!-- 직업선택영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    직업
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-4">
                                    <fdp-validator name="tsscm101m-validator-6" display-name="직업" v-model="customerJobCode" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item -pub-customer-register-form__segment -pub-customer-register-form__segment--has-select"
                                            v-model="job" :data="jobs"></fdp-segment-box>
                                        <!-- 기본상태 마크업 -->
                                        <!-- [ 181031 인라인 스타일제거 및 클래스 추가 -->
                                        <fdp-select class="-pub-customer-register-form__item -pub-customer-register-form__select -pub-customer-register-form__segment--select -pub-job-segment-select"
                                            v-model="selectValues.subjob" :option-list="subjobList" ellipsis :highlight="selectValues.subjob.key !== ''" placeholder="기타"></fdp-select>
                                        <!-- 181031 인라인 스타일제거 및 클래스 추가 ] -->
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--job"
                                            v-model="formInputs.jobsearch" fixedIcon placeholder="직업선택"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 직업선택영역 end -->
                            <!-- 주소 입력영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    주소
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <!-- <fdp-validator name="name" v-model="addrType" :rules="'required'"> -->
                                        <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item"
                                            v-model="addrType" :data="addrTypes" essential></fdp-segment-box>
                                    <!-- </fdp-validator> -->
                                    <button type="button" class="-pub-customer-register-form__item -pub-button -pub-zipcode-button"><span>우편번호</span></button>
                                    <fdp-validator name="tsscm101m-validator-7" display-name="우편번호" v-model="formInputs.zipcode" :rules="'required'">
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--zipcode"
                                            v-model="formInputs.zipcode" readonly placeholder="우편번호 버튼을 선택해주세요."></fdp-text-field>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 주소 입력영역 end -->
                            <!-- 취득경로 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    취득경로
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <!-- <fdp-validator name="name" v-model="entryPath" :rules="'required'"> -->
                                        <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item"
                                            v-model="entryPath" :data="entryPaths" essential></fdp-segment-box>
                                    <!-- </fdp-validator> -->
                                    <!-- 취득경로 segment box에서 소개일경우 나오는 소개자 입력 input 및 소개일 입력 input -->
                                    <template v-if="entryPath[0].key === '2'">
                                        <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--recommend"
                                            v-model="formInputs.recommender" fixedIcon placeholder="소개자"></fdp-text-field>
                                        <fdp-date-picker class="-pub-customer-register-form__item -pub-customer-register-form__date-picker -pub-customer-register-form__date-picker--recommend"
                                            v-model="formInputs.recommendDate" placeholder="소개일" up></fdp-date-picker>
                                    </template>
                                    <!-- 취득경로 segment box에서 소개일경우 나오는 소개자 입력 input 및 소개일 입력 end -->
                                </div>
                            </div>
                            <!-- 취득경로 end -->
                        </div>
                    </form>
                    <!-- TSSCM103D 세대원 추가 form -->
                    <form class="-pub-form -pub-customer-register-form -pub-customer-register-form--child" v-for="(child, index) in childForms" :key="index">
                        <!-- step sub title -->
                        <h2 class="-pub-customer-register__step-title">세대원 입력</h2>
                        <!-- form delete button -->
                        <a class="-pub-customer-register-form__button -pub-customer-register-form__button--delete -pub-button--close" @click="removeChildForm(index)"></a>
                        <!-- form delete button end -->
                        <!-- step sub title end -->
                        <div class="-pub-customer-register__container">
                            <!-- 고객명 입력영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    고객명
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <fdp-validator :name="'tsscm101m-validator-1' + index" display-name="고객명" v-model="child.formInputs.customerName" :rules="'required'">
                                      <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--name"
                                          v-model="child.formInputs.customerName" placeholder="입력해주세요."></fdp-text-field>
                                       <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox" v-model="child.checkboxs.isFetus">태아여부</fdp-checkbox>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 고객명 입력영역 end -->
                            <!-- 동의 유형 입력 영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    동의유형선택
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <fdp-validator :name="'tsscm101m-validator-2' + index" display-name="동의유형선택" v-model="child.checkboxs.agreeType" :rules="'required'">
                                     <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox -pub-checkbox--consulting"
                                          v-model="child.checkboxs.agreeType" value="1">필수컨설팅</fdp-checkbox>
                                      <fdp-checkbox class="-pub-customer-register-form__item -pub-checkbox" v-model="child.checkboxs.agreeType"
                                          value="2">마케팅</fdp-checkbox>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 동의 유형 입력 영역 end -->
                            <!-- 세대원 주민등록번호 입력 영역-->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header -pub-customer-register-form__content--layer-1" v-if="true">
                                    주민등록번호
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content">
                                    <fdp-validator :name="'tsscm101m-validator-3' + index" display-name="주민등록번호" v-model="socialNumbersList[index]" :rules="test(child.formInputs.socialNumbers)">
                                      <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--social"
                                           v-model="child.formInputs.socialNumbers[0]" placeholder="000000"></fdp-text-field>
                                       <span class="-pub-customer-register-form__item -pub-customer-register-form__dash"></span>
                                       <!-- 기본케이스 주민번호 뒷자리 입력 field -->
                                       <template>
                                           <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--social"
                                              v-model="child.formInputs.socialNumbers[1]" placeholder="000000" v-if="true"></fdp-text-field>
                                          <!-- 유효하지않은 경우 -pub-customer-register-form__input--invalid 클래스를 추가하여 컬러값 변경 -->
                                          <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--social -pub-customer-register-form__input--invalid"
                                              v-model="child.formInputs.socialNumbers[1]" placeholder="000000" v-if="false"></fdp-text-field>
                                        </template>
                                    </fdp-validator>
                                    <!-- 주민번호 뒷자리 입력 field end -->
                                    <!-- [ 181113 버튼추가 -->
                                    <button type="button" class="-pub-customer-register-form__item -pub-button -pub-button--light -pub-serial-no-lookup-button"><span>일련번호 조회</span></button>
                                    <!-- 181113 버튼추가 ] -->
                                </div>
                            </div>
                            <!-- 휴대폰번호 입력영역 -->
                            <div class="-pub-customer-register-form__row">
                                <!-- [ 181031 필수표시 및 validator 주석처리 -->
                                <div class="-pub-customer-register-form__header">
                                    휴대폰번호
                                    <!-- <span class="-pub-required"></span> -->
                                </div>
                                <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-2">
                                    <!-- <fdp-validator :name="'tsscm101m-validator-4' + index" display-name="휴대폰번호" v-model="child.formInputs.phoneNumber" :rules="'required'"> -->
                                      <fdp-select class="-pub-customer-register-form__item -pub-customer-register-form__select -pub-customer-register-form__select--phone"
                                          v-model="child.selectValues.phoneFirstNumber" :option-list="phoneItems"></fdp-select>
                                      <!-- [ 181031 placeholder 변경 -->
                                      <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--phone"
                                           v-model="child.formInputs.phoneNumber" placeholder="0000-0000" mask="phone"></fdp-text-field>
                                      <!-- 181031 placeholder 변경 ] -->
                                    <!-- </fdp-validator> -->
                                </div>
                                <!-- 181031 필수표시 및 validator 주석처리 ] -->
                            </div>
                            <!-- 휴대폰번호 입력영역 end -->
                            <!-- 직업선택영역 -->
                            <div class="-pub-customer-register-form__row">
                                <div class="-pub-customer-register-form__header">
                                    직업
                                    <span class="-pub-required"></span>
                                </div>
                                <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-4">
                                    <fdp-validator :name="'tsscm101m-validator-5' + index" display-name="직업" v-model="child.childJob" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item -pub-customer-register-form__segment"
                                            v-model="child.childJob" :data="childJobs"></fdp-segment-box>
                                    </fdp-validator>
                                    <fdp-text-field class="-pub-customer-register-form__item -pub-customer-register-form__input -pub-customer-register-form__input--job"
                                        v-model="child.formInputs.jobsearch" fixedIcon placeholder="기타"></fdp-text-field>
                                </div>
                            </div>
                            <!-- 직업선택영역 end -->
                        </div>
                    </form>
                    <!-- form 스크롤 콘텐츠 반복영역 end -->
                    <!-- form 추가 버튼 -->
                    <div class="-pub-customer-register-add-form">
                        <a class="-pub-customer-register-add-form__button" @click="addChildForm">
                            <img class="-pub-customer-register-add-form__icon" src="@/assets/img/components/ico_plus.png" /> 세대추가
                        </a>
                    </div>
                    <!-- form 추가 버튼 end -->
                </div>
            </section>
        </div>
        <!-- [ 101113 동의서 발행 버튼 추가로 인한 레이아웃 수정 -->
        <!-- [ 181102 bottom-bar 키보드 실행시 위로 올라가지 않도록 수정 -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default -pub-bottom-bar--full" v-show="true">
            <div class="-pub-bottom-nav">
                <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-bottom-nav__item" v-if="true">
                        <span class="-pub-button__text">동의서발행</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--next">다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼"></button>
                </div>
                <p class="-pub-customer-register__step-text">{{ '※ 정보활용동의가 완료되어야 고객카드가 생성됩니다. 5일 이내 미동의 시 본 고객정보는 자동 삭제됩니다.' }}</p>
            </div>
        </fdp-bottom-bar>
        <!-- 181102 bottom-bar 키보드 실행시 위로 올라가지 않도록 수정 ] -->
        <!-- 101113 동의서 발행 버튼 추가로 인한 레이아웃 수정 ] -->
    </section>
</template>
<script>
export default {
  methods: {
    addChildForm () {
      this.childForms.push(
        {
          childJob: [],
          checkboxs: {
            isFetus: false,
            agreeType: []
          },
          formInputs: {
            customerName: '',
            socialNumbers: ['', ''],
            phoneNumber: '',
            jobsearch: ''
          },
          selectValues: {
            phoneFirstNumber: {
              key: '010',
              label: '010'
            }
          }
        }
      )
    },
    removeChildForm (idx) {
      this.childForms.splice(idx, 1)
    },
    test (val) {
      return {
        'fdp_required': val
      }
    }
  },
  data () {
    return {
      childForms: [
        {
          childJob: [],
          checkboxs: {
            isFetus: false,
            agreeType: []
          },
          formInputs: {
            customerName: '',
            socialNumbers: ['', ''],
            phoneNumber: '',
            jobsearch: ''
          },
          selectValues: {
            phoneFirstNumber: {
              key: '010',
              label: '010'
            }
          }
        }],
      currentStep: 1,
      authTypes: [{
        key: '1',
        label: '휴대폰/카드'
      },
      {
        key: '2',
        label: 'QR코드'
      },
      {
        key: '3',
        label: '지류'
      }
      ],
      customerTypes: [{
        key: '1',
        label: '신규'
      },
      {
        key: '2',
        label: '기존'
      }
      ],
      jobs: [{
        key: '1',
        label: '총무사무원'
      },
      {
        key: '2',
        label: '학생'
      },
      {
        key: '3',
        label: '전업주부'
      }
      ],
      subjobList: [{
        key: '1',
        label: '미취학아동'
      },
      {
        key: '2',
        label: '삼성생명설계사'
      },
      {
        key: '3',
        label: '직업7'
      },
      {
        key: '4',
        label: '직업8'
      },
      {
        key: '5',
        label: '직업9'
      }
      ],
      childJobs: [{
        key: '1',
        label: '미취학아동'
      },
      {
        key: '2',
        label: '학생'
      }],
      customerType: [],
      authType: [],
      job: [],
      customerJobCode: '',
      tempCustomer: true,
      formInputs: {
        customerName: '',
        socialNumbers: ['', ''],
        phoneNumber: '',
        email: ['', ''],
        jobsearch: '',
        zipcode: '',
        recommender: '',
        recommendDate: ''
      },
      checkboxs: {
        isForeigner: false,
        isFetus: false,
        agreeType: [],
        agreeTypeSub: false
      },
      selectValues: {
        phoneFirstNumber: {
          key: '010',
          label: '010'
        },
        emailAfterAddr: {
          key: '0',
          label: '직접입력'
        },
        subjob: {
          key: '',
          label: ''
        }
      },
      phoneItems: [{
        key: '010',
        label: '010'
      },
      {
        key: '012',
        label: '011'
      },
      {
        key: '013',
        label: '012'
      },
      {
        key: '014',
        label: '013'
      },
      {
        key: '015',
        label: '014'
      },
      {
        key: '016',
        label: '015'
      }
      ],
      emailItems: [{
        key: '0',
        label: '직접입력'
      },
      {
        key: 'a.com',
        label: 'a'
      },
      {
        key: 'b.com',
        label: 'b'
      },
      {
        key: 'c.com',
        label: 'c'
      },
      {
        key: 'd.com',
        label: 'd'
      }
      ],
      addrTypes: [{
        key: '1',
        label: '자택'
      },
      {
        key: '2',
        label: '직장'
      }
      ],
      addrType: [],
      entryPaths: [{
        key: '1',
        label: '지인'
      },
      {
        key: '2',
        label: '소개'
      },
      {
        key: '3',
        label: '개척'
      },
      {
        key: '4',
        label: '기타'
      }
      ],
      entryPath: [],
      genders: [{
        key: '1',
        label: '남'
      },
      {
        key: '2',
        label: '여'
      }
      ],
      gender: []
    }
  },
  created () {
    this.authType.push(this.authTypes[0])
    this.customerType.push(this.customerTypes[0])
    this.job.push(this.jobs[0])
    this.addrType.push(this.addrTypes[0])
    this.entryPath.push(this.entryPaths[0])
    this.gender.push(this.genders[0])
  },
  computed: {
    combinedEmail () {
      return this.formInputs.email[0] + '@' + this.formInputs.email[1]
    },
    combinedSocialNumber () {
      return this.formInputs.socialNumbers[0] + '-' + this.formInputs.socialNumbers[1]
    },
    emailRules () {
      return {
        'fdp_required': this.formInputs.email
      }
    },
    socialNumberRules () {
      return {
        'fdp_required': this.formInputs.socialNumbers
      }
    },
    socialNumbersList: function () {
      return this.childForms.map(function (child) {
        return child.formInputs.socialNumbers[0] + '-' + child.formInputs.socialNumbers[1]
        // return child.formInputs.socialNumbers[0] === '' || child.formInputs.socialNumbers[1] === '' ? '' : child.formInputs.socialNumbers[0] + child.formInputs.socialNumbers[1]
      })
    }
  },
  watch: {
    job (v) {
      if (v.length > 0) {
        this.customerJobCode = v[0].key
        this.selectValues.subjob = { key: '', label: '' }
        this.formInputs.jobsearch = ''
      } else {
        if (this.selectValues.subjob.key === '' && this.formInputs.jobsearch === '') {
          this.customerJobCode = ''
        }
      }
    },
    'selectValues.subjob' (v) {
      if (v.key !== '') {
        this.customerJobCode = v.key
        this.job.splice(0, 1)
        this.formInputs.jobsearch = ''
      } else {
        if (this.job.length === 0 && this.formInputs.jobsearch === '') {
          this.customerJobCode = ''
        }
      }
    },
    'formInputs.jobsearch' (v) {
      if (v !== '') {
        this.customerJobCode = v
        this.job.splice(0, 1)
        this.selectValues.subjob = { key: '', label: '' }
      } else {
        if (this.job.length === 0 && this.selectValues.subjob.key === '') {
          this.customerJobCode = ''
        }
      }
    },
    'selectValues.emailAfterAddr' (v) {
      if (v.key !== '0') {
        this.formInputs.email[1] = v.label
      } else {
        this.formInputs.email[1] = ''
      }
    }
  }
}
</script>
