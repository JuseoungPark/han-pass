<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="정보제공동의관리" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup__info--report">
            <div class="-pub-popup__info--report-wrap">
                <!-- 2018-11-13 하단 테이블 전체 수정-->
                <h2>마케팅 연락가능 방법 (마케팅동의 보유 고객 대상)</h2>
                <table class="-pub-table -pub-table-basic">
                    <thead>
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width:248px;">전화</th>
                            <th class="-pub-table-column" style="width:248px;">문자</th>
                            <th class="-pub-table-column" style="width:248px;">이메일</th>
                            <th class="-pub-table-column" style="width:248px;">우편</th>
                        </tr>
                    </thead>
                    <tbody class="-pub-table__tbody">
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">불가</td>
                            <td class="-pub-table-column" style="width:248px;">가능</td>
                            <td class="-pub-table-column" style="width:248px;">가능</td>
                            <td class="-pub-table-column" style="width:248px;">가능</td>
                        </tr>
                    </tbody>
                </table>
                <h2>마케팅활용 동의</h2>
                <table class="-pub-table -pub-table-basic">
                    <thead>
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width:152px;">전화</th>
                            <th class="-pub-table-column" style="width:152px;">문자</th>
                            <th class="-pub-table-column" style="width:152px;">이메일</th>
                            <th class="-pub-table-column" style="width:152px;">우편</th>
                            <th class="-pub-table-column" style="width:172px;">동의시작일</th>
                            <th class="-pub-table-column" style="width:172px;">동의종료일</th>
                        </tr>
                    </thead>
                    <tbody class="-pub-table__tbody">
                        <tr>
                            <td class="-pub-table-column" style="width:152px;">동의</td>
                            <td class="-pub-table-column" style="width:152px;">동의</td>
                            <td class="-pub-table-column" style="width:152px;">동의</td>
                            <td class="-pub-table-column" style="width:152px;">동의</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:172px;">2018-05-02</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:172px;">2018-05-02</td>
                        </tr>
                    </tbody>
                </table>
                <h2>이메일을 통한 수신거부 여부</h2>
                <table class="-pub-table -pub-table-basic">
                    <thead>
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width:194px;">거부여부</th>
                            <th class="-pub-table-column" style="width:194px;">신청자ID</th>
                            <th class="-pub-table-column" style="width:194px;">처리일자</th>
                            <th class="-pub-table-column" style="width:194px;">처리자</th>
                            <th class="-pub-table-column" style="width:196px;">처리부서</th>
                        </tr>
                    </thead>
                    <tbody class="-pub-table__tbody">
                        <tr>
                            <td class="-pub-table-column" style="width:194px;">동의</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:194px;">jj10</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:194px;">2018-05-02</td>
                            <td class="-pub-table-column" style="width:194px;">전지현</td>
                            <td class="-pub-table-column" style="width:196px;">마케팅</td>
                        </tr>
                    </tbody>
                </table>
                <h2>매체별 접촉 동의</h2>
               <table class="-pub-table -pub-table-basic">
                    <thead>
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width:248px;">구분</th>
                            <th class="-pub-table-column" style="width:248px;">수신여부</th>
                            <th class="-pub-table-column" style="width:248px;">등록일자</th>
                            <th class="-pub-table-column" style="width:248px;">동의경로</th>
                        </tr>
                    </thead>
                    <tbody class="-pub-table__tbody">
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">전화</td>
                            <td class="-pub-table-column" style="width:248px;">거절</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                            <td class="-pub-table-column" style="width:248px;">U-Portal 신계약</td>
                        </tr>
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">문자</td>
                            <td class="-pub-table-column" style="width:248px;">동의</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                            <td class="-pub-table-column" style="width:248px;">U-Portal 고객관리</td>
                        </tr>
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">이메일</td>
                            <td class="-pub-table-column" style="width:248px;">동의</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                            <td class="-pub-table-column" style="width:248px;">U-Portal 고객관리</td>
                        </tr>
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">우편</td>
                            <td class="-pub-table-column" style="width:248px;">동의</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                            <td class="-pub-table-column" style="width:248px;">U-Portal 고객관리</td>
                        </tr>
                    </tbody>
                </table>
                <h2>금융권 통합 두낫콜(연락불가) 신청 여부</h2>
                <table class="-pub-table -pub-table-basic">
                    <thead>
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width:248px;">구분</th>
                            <th class="-pub-table-column" style="width:248px;">신청여부</th>
                            <th class="-pub-table-column" style="width:248px;">신청일자</th>
                            <th class="-pub-table-column" style="width:248px;">종료일자</th>
                        </tr>
                    </thead>
                    <tbody class="-pub-table__tbody">
                        <tr>
                            <td class="-pub-table-column" style="width:248px;">구분</td>
                            <td class="-pub-table-column" style="width:248px;">신청</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width:248px;">2018-05-02</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
            <div class="-pub-bottom-nav">
                <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                </div>
            </div>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true
    }
  }
}
</script>
