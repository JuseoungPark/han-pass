<template>
    <section class="-pub-customer__my-group">
        <!-- 내그룹 Start -->
        <div class="-pub-popup__edit-my-group">
           <div class="-pub-popup__content-body">
                <!-- 왼쪽 영역 start -->
                <div class="-pub-popup-content__left -pub-popup-content__left--cont"><!-- 마크업추가 20181112-->
                    <!-- 페이지 조회 input, button 검색 영역  -->
                    <div class="-pub-filter-menu">
                        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
                    </div>
                    <!-- 페이지 조회 input, button 검색 영역 end -->
                    <fdp-infinite class="-pub-table" v-model="radioSelected" single-select :items="mockData" :table-body-height="707" :tableMinWidth="800">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column--radiobox" style="width: 78px;">
                                    <!-- <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="isSelectAllOrigin" @input="selectAllItemsOrginFunc(isSelectAllOrigin)"></fdp-checkbox> -->
                                </th>
                                <th class="-pub-table-column" style="width: 246px;">그룹명</th>
                                <th class="-pub-table-column" style="width: 168px;">고객수</th>
                                <th class="-pub-table-column" style="width: 246px;">생성일자</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column--radiobox" style="width: 78px; padding-top: 5px; padding-left: 13px;">
                              <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected" :value="props.item"></fdp-radio>
                            <td class="-pub-table-column -pub-table-column--name" style="width: 246px;">{{props.item.name}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 168px;">{{props.item.num}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 246px;">{{props.item.date}}</td>
                        </template>
                        <template slot="emptyView">
                        <!-- no data 화면 -->
                            <div class="empty-table-content" v-if="this.mockDataOrigin.lengt===0">
                                <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                            </div>
                        </template>
                    </fdp-infinite>
                </div>
                <!--// 왼쪽 영역 end -->
                <!-- 오른쪽 영역 start -->
                <div class="-pub-popup-content__right -pub-popup-content__right--cont"><!-- 마크업추가 20181112-->
                    <!-- 페이지 조회 input, button 검색 영역  -->
                    <div class="-pub-filter-menu">
                        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{groupMemberView.length}}명</div>
                    </div>
                    <!-- 페이지 조회 input, button 검색 영역 end -->
                    <fdp-infinite class="-pub-table" v-model="selectDetailMember" multi-select :items="groupMemberView" :table-body-height="707" :tableMinWidth="800">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column--radiobox" style="width: 78px;padding-top: 5px;padding-left: 3px;">
                                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="isSelectAll" @input="selectAllItemsAddMemberFunc(isSelectAll)"></fdp-checkbox>
                                </th>
                                <th class="-pub-table-column" style="width: 134px;">고객명</th>
                                <th class="-pub-table-column" style="width: 218px;">생년월일</th>
                                <th class="-pub-table-column" style="width: 116px;">성별</th>
                                <th class="-pub-table-column" style="width: 172px;">고객구분</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column--radiobox" style="width: 78px;padding-top: 5px;">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="selectDetailMember" :value="props.item"></fdp-checkbox>
                            <td class="-pub-table-column -pub-table-column--name" style="width: 134px;">{{props.item.name}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 218px;">{{props.item.birth}}</td>
                            <td class="-pub-table-column" style="width: 116px;">{{props.item.gender}}</td>
                            <td class="-pub-table-column" style="width: 172px;">{{props.item.type}}</td>
                        </template>
                        <template slot="emptyView">
                            <!-- 좌측 그룹리스트에서 그룹명을 선택하세요 -->
                            <div class="empty-table-content">
                                <img src="@/assets/img/ico_hand_tap.png" class="empty-table-content__icon" />
                                <div class="empty-table-content__text">좌측 그룹리스트에서 그룹명을 선택하세요</div>
                            </div>
                        </template>
                    </fdp-infinite>
                </div>
                <!--// 오른쪽 영역 end -->
            </div>
        </div>
        <!--// 내그룹 end -->
        <!-- 고객 정보 bottom bar component-->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--centered">
                    <fdp-checkbox v-show="selectDetailMember.length>0" class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{selectDetailMember.length}}명 선택</fdp-checkbox>
                </li>
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line" :disabled="selectDetailMember.length===0">
                    <span class="-pub-button__text">문자</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line" :disabled="!hasSelectItem">
                    <span class="-pub-button__text">그룹 편집</span>
                    </button>
                    <!-- bottom nav disable attribute 추가시 disable 스타일 적용-->
                    <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
                    <span class="-pub-button__text">+새그룹 생성</span>
                    </button>
                    <!-- tooltip 메뉴 버튼 bottom bar-->
                    <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple -pub-bottom-bar-etc-tooltip"
                    v-model="currMenu" :menu-list="menuListSample"  blue top>
                    <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line" :disabled="selectDetailMember.length===0">
                    <span class="-pub-symbol--menu"></span>
                    </div>
                </fdp-tooltip-menu>
                <!-- tooltip 메뉴 버튼 end-->
                </li>
            </ul>
        </fdp-bottom-bar>
    </section>
</template>
<script>
import {
  groupMembers,
  groupList
} from '@/components/mock/TSSCM251M.mock'

export default {
  data () {
    return {
      radioSelected: {},
      currMenu: '',
      bottomBarCheck: false,
      menuListSample: [],
      mockData: Array.prototype.slice.call(groupList), // group list  data 원본
      mockDataOrigin: Array.prototype.slice.call(groupMembers), // group 별 구성원 data 원본
      groupMemberView: [], // table에 조회 될 Data
      isSelectAll: false,
      selectDetailMember: []
    }
  },
  methods: {
    filterMember (a) {
      this.groupMemberView = []
      for (let i = 0; i < this.mockDataOrigin.length; i++) {
        if (this.mockDataOrigin[i].group === a) {
          this.groupMemberView.push(this.mockDataOrigin[i])
        }
      }
    },
    selectAllItemsAddMemberFunc (state) {
      if (state) {
      // checked
        this.selectDetailMember = this.groupMemberView.slice(0)
      } else {
      // unchecked
        this.selectDetailMember.splice(0, this.groupMemberView.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectDetailMember.splice(0, this.selectDetailMember.length)
      this.isSelectAll = false
    }
  },
  watch: {
    // group 을 선택했을 때
    radioSelected () {
      if (this.radioSelected) {
        this.filterMember(this.radioSelected.key)
      }
      // 초기화 처리
      this.isSelectAll = false
      this.selectDetailMember = []
    },
    selectDetailMember () {
      if (this.selectDetailMember.length !== this.groupMemberView.length || this.selectDetailMember.length === 0) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectDetailMember.length > 0) {
        this.bottomBarCheck = true
      }
    }
  },
  computed: {
    hasSelectItem () {
      return !!Object.keys(this.radioSelected).length > 0
    }
  }
}
</script>
