<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="My플랜 저장" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--myplan">
            <ul class="-pub-popup__content--myplan-list">
                <li class="-pub-popup__content--myplan-list-item">
                    <label>상품명</label>
                    <div class="-pub-popup__content--myplan-list-item-row">
                        <p class="-pub-popup__content--myplan-list-item-txt">삼성생명NEW통합 나이에 딱 맞는 CI보험 (무배당, 보증비용부과형)</p>
                    </div>
                </li>
                <li class="-pub-popup__content--myplan-list-item">
                    <label>분류</label>
                    <div class="-pub-popup__content--myplan-list-item-row">
                        <fdp-validator name="tsspi690p-validator-1" display-name="분류" v-model="myplanType" :rules="'required'">
                            <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="myplanType" :data="myplanTypes"></fdp-segment-box>
                        </fdp-validator>
                    </div>
                </li>
                <li class="-pub-popup__content--myplan-list-item">
                    <label>플랜명</label>
                    <div class="-pub-popup__content--myplan-list-item-row">
                        <fdp-validator name="tsspi690p-validator-2" display-name="플랜명" v-model="planname" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input-myplan" v-model="planname" placeholder="입력하세요"></fdp-text-field>
                        </fdp-validator>
                    </div>
                </li>
            </ul>
            <p class="-pub-popup__content--myplan-desc">※ 상품별 최대 10개까지 플랜 저장이 가능합니다.</p>
            <div class="-pub-popup__button-area">
                <div class="-pub-popup__button-area-left">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--238">
                        <span class="-pub-button__text">My플랜 관리</span>
                    </button>
                </div>
                <div class="-pub-popup__button-area-right">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--180">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--180 -pub-button--reverse">
                        <span class="-pub-button__text" @click="save">저장</span>
                    </button>
                </div>
            </div>
            <fdp-toast ref="toast"></fdp-toast>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      planname: '',
      myplanType: [],
      myplanTypes: [{
        key: '1',
        label: '지역단'
      },
      {
        key: '2',
        label: '지점'
      },
      {
        key: '3',
        label: '개인'
      }]
    }
  },
  methods: {
    save () {
      // 성공적으로 저장 후 message display
      this.$refs.toast.makeToast(this.planname + '이 My플랜에 저장되었습니다.')
    }
  }
}
</script>
