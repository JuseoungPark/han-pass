<template>
    <section class="-pub-product-question__wrap">
        <TSSPI751D :mockQuestionData="mockQuestionData"
        :mockAnswerData="mockAnswerData"
        :answerList="answerList"
        :currentQuestion="currentQuestion"
        @changeQuestionNo="questionNo"></TSSPI751D>
        <TSSPI752D :mockAnswerData="mockAnswerData"
        :currentQuestion="currentQuestion"
        :currentAnswer="answerList[currentQuestion]"
        @getAnswer="getAnswer"
        @changeQuestionNo="questionNo"></TSSPI752D>
        <!-- 마지막 문항까지 체크한 상태에서 다른 문항으로 이동했을 경우 하단 바가 생김 -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed-top -pub-bottom-bar--full" v-show="hasAllAnswer">
            <p class="-pub-bottom-nav__txt"> ※ 적합성 진단이 완료되어야 변액보험 가입상담 및 권유가 가능합니다.</p>
            <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                <button type="button" class="-pub-button -pub-button--purple -pub-button--prev -pub-button--reverse"><img class="icon-arrow" src="@/assets/img/components/ico_arrow_prev-purple.png" alt="이전 버튼">이전</button>
                <button type="button" class="-pub-button -pub-button--purple -pub-button--next -pub-button--reverse">다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼"></button>
            </div>
        </fdp-bottom-bar>
    </section>
</template>
<script>
import TSSPI751D from '@/components/pages/2018-11-09/TSSPI751D'
import TSSPI752D from '@/components/pages/2018-11-09/TSSPI752D'
import {viewMemberMocks1} from '@/components/mock/TSSPI751D.mock'
import {viewMemberMocks2} from '@/components/mock/TSSPI752D.mock'
export default {
  components: {
    TSSPI751D,
    TSSPI752D
  },
  data () {
    return {
      mockQuestionData: Array.prototype.slice.call(viewMemberMocks1), // 질문지 데이터
      mockAnswerData: Array.prototype.slice.call(viewMemberMocks2), // 질문에 대한 선택지 데이터
      currentQuestion: 0, // 현재 선택된 질문 번호
      answerList: [ // 질문에 대한 답변 데이터 (key값만 갖고 있음)
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        []
      ]
    }
  },
  methods: {
    questionNo (idx) {
      if (idx >= this.answerList.length) {
        this.currentQuestion = this.answerList.length - 1
      } else {
        this.currentQuestion = idx
      }
    },
    getAnswer (answer) {
      if (this.mockAnswerData[this.currentQuestion].checkbox) {
        this.answerList[this.currentQuestion].splice(0, this.answerList[this.currentQuestion].length)
        for (let i = 0; i < answer.length; i++) {
          this.answerList[this.currentQuestion].push(answer[i])
        }
      }
    }
  },
  computed: {
    hasAllAnswer () {
      let count = 0

      for (let i = 0; i < this.answerList.length; i++) {
        if (this.answerList[i].length > 0) {
          count++
        } else {
          break
        }
      }

      if (count === this.answerList.length) {
        return true
      }
      return false
    }
  }
}
</script>
