<template>
    <div class="-pub-product-question__sidebar">
        <!-- 질문 0번 답변  -->
        <div v-for="data in mockAnswerData" :key="data.key" class="-pub-product-question__answer" v-if="data.key === currentQuestion">
            <div class="-pub-product-question__answer--wrap">
              <ul class="-pub-product-question__answer--list">
                  <!-- 선택한 체크박스나 라디오 버튼에 -pub-product-question__answer--list-item-focus 추가 -->
                  <li v-for="data1 in data.choice" :key="data1.key"  @click="radioClick" :class="[{'-pub-product-question__answer--list-item': true}, {'-pub-product-question__answer--list-item-focus': answer.includes(data1.key)}]">
                      <fdp-checkbox v-if="data.checkbox" class="-pub-checkbox -pub-checkbox--purple" v-model="answer" :value="data1.key">{{data1.label}}</fdp-checkbox>
                      <fdp-radio v-else class="-pub-radio -pub-radio--purple" v-model="radioAnswer" :value="data1.key" @click="radioClick">{{data1.label}}</fdp-radio>
                  </li>
              </ul>
              <div class="btn-area-center">
                  <button v-if="mockAnswerData[currentQuestion].checkbox" type="button" class="-pub-button -pub-button--purple" @click="setAnswer">
                      <span class="-pub-button__text">확인</span>
                  </button>
              </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  props: {
    mockAnswerData: {
      type: Array,
      default: _ => []
    },
    currentQuestion: {
      type: Number,
      default: _ => 0
    },
    currentAnswer: {
      type: Array,
      default: _ => []
    }
  },
  data () {
    return {
      answer: this.currentAnswer,
      radioAnswer: this.currentAnswer[0] ? this.currentAnswer[0] : ''
    }
  },
  watch: {
    currentQuestion (val) {
    },
    currentAnswer (newValue) {
      this.answer = newValue
      this.radioAnswer = newValue[0]
    }
  },
  methods: {
    setAnswer () {
      this.$emit('getAnswer', this.answer)
      this.$emit('changeQuestionNo', this.currentQuestion + 1)
    },
    radioClick () {
      if (!this.mockAnswerData[this.currentQuestion].checkbox) {
        this.answer.splice(0, this.answer.length)
        this.answer.push(this.radioAnswer)
        this.setAnswer()
      }
    }
  }
}
</script>
