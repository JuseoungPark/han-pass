<template>
    <div>
      <fdp-text-field v-model="item.goals" placeholder="" class="-pub-input" :readonly="item.section === '합계'"></fdp-text-field>
    </div>
</template>

<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col']
}
</script>
<style>
.-pub-input {
  margin-top: -8px;
  width: 234px;
  height: 64px;
  border: 1px solid #bdc3d6;

}
.-fdp-text-field__input {
  text-align: right;
  letter-spacing: normal;
}
</style>
