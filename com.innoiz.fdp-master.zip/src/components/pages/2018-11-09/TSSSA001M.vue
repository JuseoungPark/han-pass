<template>
    <section class="-pub-activity-infomation">
        <div class="-pub-customer-register__header -pub-activity-header">
            <h1 class="-pub-customer-register__title">
                <a class="-pub-customer-register__button -pub-customer-register__button--back">
                    <img src="@/assets/img/components/ico-arrow-back.png" @click="goBack" alt="뒤로가기">
                </a>
                <span class="-pub-customer-register__text--parent-bottom">{{isSearch?'검색결과':'안내자료'}}</span>
            </h1>
            <div class="-pub-activiy-serach-wrap">
                <fdp-date-picker class="-pub-date-picker -pub-date-picker--thin-line -pub-date-start" v-model="startDate"></fdp-date-picker>
                <span class="-pub-filter-detail__item separator-tilde"></span>
                <fdp-date-picker class="-pub-date-picker -pub-date-picker--thin-line -pub-date-end" v-model="endDate"></fdp-date-picker>
                <fdp-text-field class="-pub-text-field--purple -pub-input-1" @keyup.enter="search" v-model="searchKeyword" placeholder="자료명" clearable></fdp-text-field>
                <button type="button" class="-pub-button -pub-search-button" @click="search"><img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회</button>
            </div>
        </div>
        <!-- 안내자료 기본화면 -->
        <div v-if="!isSearch">
            <TSSSA001D></TSSSA001D>
            <!-- 안내자료 홈 -->
            <div class="-pub-activity-info-home-content">
                <!-- no-data 인 경우 -pub-no-data 추가 -->
                <div class="-pub-activity-info__category" :class="myList.length===0?'-pub-no-data':''">
                    <div class="-pub-tit-wrap">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_sel.png" alt="" @click="testParam('my')" v-if="isMyFav">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_nor.png" alt="" @click="testParam('my')" v-else>
                        <span class="-pub-tit">내가 사용한 자료</span>
                        <img class="-pub-ico-go" src="@/assets/img/ico_go.png" alt="">
                    </div>
                    <!-- data 가 있는 경우 528, 없는 경우 124-->
                    <fdp-list horizontal class="-fdp-list-page__list" :list-data="myList" :list-height="myList.length>0? '528' : '124'">
                        <template slot="emptyView">
                            <div class="-fdp-list-page__empty-content -pub-no-data-wrap">
                                <span>데이터가 존재하지 않습니다.</span>
                            </div>
                        </template>
                        <template slot="default" slot-scope="props">
                            <div class="-fdp-list-page__item">
                                <div class="-pub-activity-card-item">
                                    <!-- 정사이즈 이미지 -->
                                    <div class="-pub-card-thumbnail" v-if="props.item.imgType==='1'">
                                        <img src="@/assets/img/img_1.png" class="" />
                                    </div>
                                      <!-- 세로로 이미지가 긴 경우 -pub-card-thumbnail--height -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--height" v-if="props.item.imgType==='2'">
                                        <img src="@/assets/img/img_2.png" class="" />
                                    </div>
                                    <!-- 가로로 긴 이미지의 경우 -pub-card-thumbnail--crop -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--crop" v-if="props.item.imgType==='3'">
                                        <img src="@/assets/img/img_3.png" class="" />
                                    </div>
                                    <!-- 이미지가 없으면 pass -->
                                    <div class="-pub-activity-card-item__info">
                                        <label class="-pub-badge-tag -pub-badge-tag--category">{{props.item.cat}}</label>
                                        <label class="-pub-badge-tag -pub-badge-tag--hot" v-if="props.item.isHot">HOT</label>
                                        <span class="-pub-card-tit">{{props.item.tit}}</span>
                                        <span class="-pub-date">{{props.item.date}}</span>
                                        <span class="-pub-line"></span>
                                        <span class="-pub-views">조회 {{props.item.views}}</span>
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model="props.item.chk" @input="clickCheck"></fdp-checkbox>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </fdp-list>
                </div>
                <!-- no-data 인 경우 -pub-no-data 추가 -->
                <div class="-pub-activity-info__category" :class="popularList.length===0?'-pub-no-data':''">
                    <div class="-pub-tit-wrap">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_sel.png" alt="" @click="testParam('pop')" v-if="isPopFav">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_nor.png" alt="" @click="testParam('pop')" v-else>
                        <span class="-pub-tit">인기자료</span>
                        <img class="-pub-ico-go" src="@/assets/img/ico_go.png" alt="">
                    </div>
                    <!-- data 가 있는 경우 528, 없는 경우 124-->
                    <fdp-list horizontal class="-fdp-list-page__list" :list-data="popularList" :list-height="popularList.length>0? '528' : '124'">
                        <template slot="emptyView">
                            <div class="-fdp-list-page__empty-content -pub-no-data-wrap">
                                <span>데이터가 존재하지 않습니다.</span>
                            </div>
                        </template>
                        <template slot="default" slot-scope="props">
                            <div class="-fdp-list-page__item">
                                <div class="-pub-activity-card-item">
                                    <!-- 정사이즈 이미지 -->
                                    <div class="-pub-card-thumbnail" v-if="props.item.imgType==='1'">
                                        <img src="@/assets/img/img_1.png" class="" />
                                    </div>
                                      <!-- 세로로 이미지가 긴 경우 -pub-card-thumbnail--height -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--height" v-if="props.item.imgType==='2'">
                                        <img src="@/assets/img/img_2.png" class="" />
                                    </div>
                                    <!-- 가로로 긴 이미지의 경우 -pub-card-thumbnail--crop -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--crop" v-if="props.item.imgType==='3'">
                                        <img src="@/assets/img/img_3.png" class="" />
                                    </div>
                                    <!-- 이미지가 없으면 pass -->
                                    <div class="-pub-activity-card-item__info">
                                        <label class="-pub-badge-tag -pub-badge-tag--category">{{props.item.cat}}</label>
                                        <label class="-pub-badge-tag -pub-badge-tag--hot" v-if="props.item.isHot">HOT</label>
                                        <span class="-pub-card-tit">{{props.item.tit}}</span>
                                        <span class="-pub-date">{{props.item.date}}</span>
                                        <span class="-pub-line"></span>
                                        <span class="-pub-views">조회 {{props.item.views}}</span>
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model="props.item.chk" @input="clickCheck"></fdp-checkbox>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </fdp-list>
                </div>
                <!-- no-data 인 경우 -pub-no-data 추가 -->
                <div class="-pub-activity-info__category" :class="recentList.length===0?'-pub-no-data':''">
                    <div class="-pub-tit-wrap">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_sel.png" alt="" @click="testParam('rec')" v-if="isRecFav">
                        <img class="-pub-ico-star" src="@/assets/img/btn_bookmark_nor.png" alt="" @click="testParam('rec')" v-else>
                        <span class="-pub-tit">최신자료</span>
                        <img class="-pub-ico-go" src="@/assets/img/ico_go.png" alt="">
                    </div>
                    <!-- data 가 있는 경우 528, 없는 경우 124-->
                    <fdp-list horizontal class="-fdp-list-page__list" :list-data="recentList" :list-height="recentList.length>0? '528' : '124'">
                        <template slot="emptyView">
                            <div class="-fdp-list-page__empty-content -pub-no-data-wrap">
                                <span>데이터가 존재하지 않습니다.</span>
                            </div>
                        </template>
                        <template slot="default" slot-scope="props">
                            <div class="-fdp-list-page__item">
                                <div class="-pub-activity-card-item">
                                    <!-- 정사이즈 이미지 -->
                                    <div class="-pub-card-thumbnail" v-if="props.item.imgType==='1'">
                                        <img src="@/assets/img/img_1.png" class="" />
                                    </div>
                                      <!-- 세로로 이미지가 긴 경우 -pub-card-thumbnail--height -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--height" v-if="props.item.imgType==='2'">
                                        <img src="@/assets/img/img_2.png" class="" />
                                    </div>
                                    <!-- 가로로 긴 이미지의 경우 -pub-card-thumbnail--crop -->
                                    <div class="-pub-card-thumbnail -pub-card-thumbnail--crop" v-if="props.item.imgType==='3'">
                                        <img src="@/assets/img/img_3.png" class="" />
                                    </div>
                                    <!-- 이미지가 없으면 pass -->
                                    <div class="-pub-activity-card-item__info">
                                        <label class="-pub-badge-tag -pub-badge-tag--category">{{props.item.cat}}</label>
                                        <label class="-pub-badge-tag -pub-badge-tag--hot" v-if="props.item.isHot">HOT</label>
                                        <span class="-pub-card-tit">{{props.item.tit}}</span>
                                        <span class="-pub-date">{{props.item.date}}</span>
                                        <span class="-pub-line"></span>
                                        <span class="-pub-views">조회 {{props.item.views}}</span>
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model="props.item.chk" @input="clickCheck"></fdp-checkbox>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </fdp-list>
                </div>
            </div>
        </div>
        <!-- TSSSA007M_검색결과 -->
        <TSSSA007M :searchKeyword="childKeyword" :bottomCnt="chkCnt" @search-count="searchCount" v-else></TSSSA007M>
        <!-- 체크박스 선택시 나오는 bottom bar component -->
        <!-- 안내고객 서치결과가 아닌 경우 -pub-battom-bar--info 추가 -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default" :class="isSearch?'':'-pub-battom-bar--info'" v-show="chkCnt>0">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="chkCnt>0">
                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" @input="cancleAll" isIconCheckbox v-model="bottomBarCheck">{{chkCnt}}건 선택</fdp-checkbox>
                </li>
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item">
                        <span class="-pub-button__text">상세보기</span>
                    </button>
                    <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple"
                        v-model="currMenu" :menu-list="menuListSample" blue top>
                        <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
                            <span class="-pub-symbol--menu"></span>
                        </div>
                    </fdp-tooltip-menu>
                </li>
            </ul>
        </fdp-bottom-bar>
        <!--체크박스 선택시 나오는 bottom bar component end -->
    </section>
</template>
<script>
import { infoListMocks } from '@/components/mock/TSSAM007M.mock'
import TSSSA001D from '@/components/pages/2018-11-09/TSSSA001D'
import TSSSA007M from '@/components/pages/2018-11-09/TSSSA007M'
export default {
  components: {
    TSSSA001D,
    TSSSA007M
  },
  data () {
    return {
      isSearch: false,
      isMyFav: false,
      isPopFav: false,
      isRecFav: false,
      startDate: '',
      endDate: '',
      searchKeyword: '',
      childKeyword: '',
      cardTypes: [{
        test: '1'
      }],
      check: false,
      bottomBarCheck: false,
      currMenu: '',
      menuListSample: [
        { label: '고객 세일즈북 추가', key: '1' },
        { label: 'My 세일즈북 추가', key: '2' },
        { label: '인쇄', key: '3' },
        { label: '이메일발송', key: '4' },
        { label: 'SMS 전송', key: '5' }
      ],
      listAll: Array.prototype.slice.call(infoListMocks),
      myList: Array.prototype.slice.call(infoListMocks).splice(0, 7),
      popularList: Array.prototype.slice.call(infoListMocks).splice(7, 8),
      recentList: Array.prototype.slice.call(infoListMocks).splice(15, 7),
      searchList: [],
      catList: [
        {catNm: '상품안내자료'},
        {catNm: 'DM'},
        {catNm: '친숙'},
        {catNm: '뉴스통계'},
        {catNm: '동영상자료'},
        {catNm: '라이브러리'}
      ],
      chkCnt: 0,
      selectedTab: ''
    }
  },
  methods: {
    search () {
      if (this.searchKeyword === '1' || this.searchKeyword === '2' || this.searchKeyword === '3') {
        this.isSearch = true
        this.chkCnt = 0
        for (let i = 0; i < this.myList.length; i++) {
          if (this.myList[i].chk) this.myList[i].chk = false
        }
        for (let i = 0; i < this.popularList.length; i++) {
          if (this.popularList[i].chk) this.popularList[i].chk = false
        }
        for (let i = 0; i < this.recentList.length; i++) {
          if (this.recentList[i].chk) this.recentList[i].chk = false
        }
      } else {
        this.goBack()
      }
      this.childKeyword = this.searchKeyword
    },
    goBack () {
      this.isSearch = false
      this.searchKeyword = ''
      this.chkCnt = 0
      for (let i = 0; i < this.myList.length; i++) {
        if (this.myList[i].chk) this.myList[i].chk = false
      }
      for (let i = 0; i < this.popularList.length; i++) {
        if (this.popularList[i].chk) this.popularList[i].chk = false
      }
      for (let i = 0; i < this.recentList.length; i++) {
        if (this.recentList[i].chk) this.recentList[i].chk = false
      }
    },
    chkCard (v) {
      if (v) {
        this.chkCnt++
      } else {
        this.chkCnt--
      }
    },
    getCnt (v) {
      let cnt = 0
      for (let i = 0; i < this.searchList.length; i++) {
        if (this.searchList[i].cat === v) cnt++
      }
      return cnt
    },
    getClass (v) {
      if (v === this.selectedTab) {
        return 'active'
      } else {
        return ''
      }
    },
    selectTab (v) {
      this.selectedTab = v
    },
    clickCheck () {
      this.chkCnt = 0
      for (let i = 0; i < this.myList.length; i++) {
        if (this.myList[i].chk) this.chkCnt++
      }
      for (let i = 0; i < this.popularList.length; i++) {
        if (this.popularList[i].chk) this.chkCnt++
      }
      for (let i = 0; i < this.recentList.length; i++) {
        if (this.recentList[i].chk) this.chkCnt++
      }
    },
    cancleAll () {
      this.chkCnt = 0
      for (let i = 0; i < this.myList.length; i++) {
        if (this.myList[i].chk) this.myList[i].chk = false
      }
      for (let i = 0; i < this.popularList.length; i++) {
        if (this.popularList[i].chk) this.popularList[i].chk = false
      }
      for (let i = 0; i < this.recentList.length; i++) {
        if (this.recentList[i].chk) this.recentList[i].chk = false
      }
    },
    searchCount (v) {
      this.chkCnt = v
    },
    testParam (v) {
      switch (v) {
        case 'my':
          this.isMyFav = !this.isMyFav
          if (this.isMyFav) {
            this.myList = []
          } else {
            this.myList = Array.prototype.slice.call(infoListMocks).splice(0, 2)
          }
          break
        case 'pop':
          this.isPopFav = !this.isPopFav
          if (this.isPopFav) {
            this.popularList = []
          } else {
            this.popularList = Array.prototype.slice.call(infoListMocks).splice(2, 3)
          }
          break
        case 'rec':
          this.isRecFav = !this.isRecFav
          if (this.isRecFav) {
            this.recentList = []
          } else {
            this.recentList = Array.prototype.slice.call(infoListMocks).splice(5, 2)
          }
          break
      }
    }
  },
  watch: {
    chkCnt () {
      if (this.chkCnt > 0) {
        this.bottomBarCheck = true
      } else {
        this.bottomBarCheck = false
      }
    }
  }
}
</script>
