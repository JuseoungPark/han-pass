<template>
    <section>
        <!-- 심사정보 기본 start -->
        <div class="-pub-product__info">
             <div class="-pub-product__info--title">
                <h2>심사 정보 입력</h2>
            </div>
            <div class="-pub-product__form">
                <form>
                    <ul class="-pub-product__form--list">
                        <!-- 계약자 -->
                        <li class="-pub-product__form--list-item" v-for="(party, idx) in partyList" :key="idx">
                            <div class="-pub-product__form--list-person">
                                <label class="-pub-badge-tag" :class="getRoleClass(party.role)">{{party.role}}{{party.role==="자녀"?party.num:''}}</label>
                                <strong class="name">{{party.name}}</strong>
                                <span class="age"  v-if="!(isOrg && party.role==='계약자')">{{party.age}}세</span>
                            </div>
                            <!-- 단체 계약자 -->
                            <div class="-pub-product__form--list-row" v-if="isOrg && party.role==='계약자'">
                                <div class="-pub-product__form--list-column">
                                    <label>사업자 <span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi800d-validator-1'+idx" display-name="사업자" v-model="party.corp.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--216" v-model="party.corp" :option-list="corpItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                            <!-- 개인 계약자 -->
                            <div class="-pub-product__form--list-row" v-else>
                                <div class="-pub-product__form--list-column">
                                     <label>주민등록번호</label>
                                     <div class="num">{{party.ssno}}</div>
                                </div>
                                <div class="-pub-product__form--list-column">
                                    <label>국적<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi800d-validator-2'+idx" display-name="국적" v-model="party.nation.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="party.nation" :option-list="nationItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column">
                                    <label>직업<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi800d-validator-3'+idx" display-name="직업" v-model="party.job" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-input--256" v-model="party.job" fixedIcon placeholder="검색하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                 <div class="-pub-product__form--list-column">
                                    <label>차종<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi800d-validator-4'+idx" display-name="차종" v-model="party.carType.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--256" v-model="party.carType" :option-list="carItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                        </li>
                    </ul>
                </form>
            </div>
         </div>
         <!-- 심사정보 기본 end -->
    </section>
</template>
<script>
export default {
  props: {
    partyList: {
      type: Array, Object
    },
    isOrg: {
      type: Boolean
    }
  },
  data () {
    return {
      nationItems: [{
        key: '내국인',
        label: '내국인'
      },
      {
        key: '외국인',
        label: '외국인'
      },
      {
        key: '주민착오',
        label: '주민착오'
      }],
      carItems: [{
        key: '승용차',
        label: '승용차'
      },
      {
        key: '중형승합차',
        label: '중형승합차'
      }],
      corpItems: [{
        key: '법인사업자',
        label: '법인사업자'
      },
      {
        key: '개인사업자',
        label: '개인사업자'
      }]
    }
  },
  methods: {
    getRoleClass (v) {
      switch (v) {
        case '계약자':
          return '-pub-product__form__tag--contractor'
        case '주피':
          return '-pub-product__form__tag--beneficiary'
        case '종피':
          return '-pub-product__form__tag--insured-person'
        case '자녀':
          return '-pub-product__form__tag--child-person'
      }
    }
  }
}
</script>
