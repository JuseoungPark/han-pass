<template>
    <section class="-pub-activity-search">
        <div class="-pub-searched-item-list-wrap">
            <ul class="-pub-searched-item-list">
                <li>
                    <span>총 <strong>{{searchList.length}}</strong>건</span>
                </li>
                <!-- isActive 의 값을 바꾸면 active 로 변경됩니다. -->
                <li v-for="(cat, idx) in catList" :key="idx" :class="getClass(idx)" @click="selectTab(idx)">
                    <span>{{cat.catNm}} <strong>{{getCnt(cat.catNm)}}</strong></span>
                </li>
            </ul>
        </div>
        <!-- <div class="-pub-searched-content-wrap" @scroll="handleScroll" ref="searchArea"> -->
        <div class="-pub-searched-content-wrap" ref="searchArea">
            <!-- 검색결과 없을때 화면 -->
            <div class="empty-content" v-if="searchList.length===0">
                <img src="@/assets/img/components/ico_no_search_result.png" class="empty-content__icon" />
                <div class="empty-content__text">'상품자료'에 대한 검색결과가 없습니다.</div>
            </div>
            <div v-else>
                <div class="-pub-activity-info__category" v-for="(cat, idx) in catList" :key="idx">
                    <div class="-pub-tit-wrap">
                        <span class="-pub-tit">{{cat.catNm}} <strong>{{getCnt(cat.catNm)}}</strong></span>
                    </div>
                    <fdp-list horizontal class="-fdp-list-page__list" :list-data="getList(idx)" :list-height="getList(idx).length>0? '528' : '32'">
                        <template slot="emptyView">
                            <div class="-fdp-list-page__empty-content"></div>
                        </template>
                        <template slot="default" slot-scope="props">
                            <div class="-fdp-list-page__item">
                                <div class="-pub-activity-card-item">
                                    <!-- 정사이즈 이미지 -->
                                    <div class="-pub-card-thumbnail">
                                        <img src="@/assets/img/img_1.png" class="" />
                                    </div>
                                      <!-- 세로로 이미지가 긴 경우 -pub-card-thumbnail--height -->
                                    <!-- <div class="-pub-card-thumbnail -pub-card-thumbnail--height">
                                        <img src="@/assets/img/img_2.png" class="" />
                                    </div> -->
                                    <!-- 가로로 긴 이미지의 경우 -pub-card-thumbnail--crop -->
                                    <!-- <div class="-pub-card-thumbnail -pub-card-thumbnail--crop">
                                        <img src="@/assets/img/img_3.png" class="" />
                                    </div> -->
                                    <!-- 이미지가 없으면 pass -->
                                    <div class="-pub-activity-card-item__info">
                                        <span class="-pub-card-tit">{{props.item.tit}}</span>
                                        <span class="-pub-date">{{props.item.date}}</span>
                                        <span class="-pub-line"></span>
                                        <span class="-pub-views">조회 {{props.item.views}}</span>
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model="props.item.chk" @input="chkCard"></fdp-checkbox>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </fdp-list>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
import {
  infoListMocks
} from '@/components/mock/TSSAM007M.mock'
export default {
  props: {
    bottomCnt: {
      type: [String, Number]
    },
    searchKeyword: {
      type: [String, Number]
    }
  },
  data () {
    return {
      startDate: '',
      endDate: '',
      check: false,
      bottomBarCheck: true,
      currMenu: '',
      menuListSample: [
        { label: '고객 세일즈북 추가', key: '1' },
        { label: 'My 세일즈북 추가', key: '2' },
        { label: '인쇄', key: '3' },
        { label: '이메일발송', key: '4' },
        { label: 'SMS 전송', key: '5' }
      ],
      searchList: Array.prototype.slice.call(infoListMocks),
      list1: [],
      list2: [],
      list3: [],
      list4: [],
      list5: [],
      list6: [],
      checkedList: [],
      catList: [
        {catNm: '상품안내자료'},
        {catNm: 'DM'},
        {catNm: '친숙'},
        {catNm: '뉴스통계'},
        {catNm: '동영상자료'},
        {catNm: '라이브러리'}
      ],
      chkCnt: 0,
      selectedTab: '',
      scrollPos: []
    }
  },
  mounted () {
    // // scroll event listener 추가
    // this.$refs.searchArea.addEventListener('scroll', this.handleScroll)

    // // tab 별 scroll 위치 계산
    // for (let i = 0; i < this.catList.length; i++) {
    //   let cv = 0
    //   if (this.getCnt(this.catList[i].catNm) > 0) {
    //     if (this.scrollPos.length > 0) cv = this.scrollPos[this.scrollPos.length - 1].height
    //     this.scrollPos.push({height: cv + 528}) // 내용이 있는경우
    //   } else {
    //     this.scrollPos.push({height: cv + 32}) // 내용이 있는경우
    //   }
    // }
    // Test 관련 1: 자료 있음, 2: 자료 없음, 3: 아래 자료 전부 닫힘
    if (this.searchKeyword === '1') {
      this.searchList = Array.prototype.slice.call(infoListMocks)
      for (let i = 0; i < this.catList.length; i++) {
        for (let j = 0; j < this.searchList.length; j++) {
          if (this.catList[i].catNm === this.searchList[j].cat) {
            if (i === 0) this.list1.push(this.searchList[j])
            if (i === 1) this.list2.push(this.searchList[j])
            if (i === 2) this.list3.push(this.searchList[j])
            if (i === 3) this.list4.push(this.searchList[j])
            if (i === 4) this.list5.push(this.searchList[j])
            if (i === 5) this.list6.push(this.searchList[j])
          }
        }
      }
    } else if (this.searchKeyword === '2') {
      this.searchList = []
      this.list1 = []
      this.list2 = []
      this.list3 = []
      this.list4 = []
      this.list5 = []
      this.list6 = []
    } else if (this.searchKeyword === '3') {
      this.searchList = Array.prototype.slice.call(infoListMocks)
      for (let i = 0; i < this.catList.length; i++) {
        for (let j = 0; j < this.searchList.length; j++) {
          if (this.catList[i].catNm === this.searchList[j].cat) {
            if (i === 0) this.list1.push(this.searchList[j])
          }
        }
      }
      this.list2 = []
      this.list3 = []
      this.list4 = []
      this.list5 = []
      this.list6 = []
    }
  },
  methods: {
    chkCard (v) { // 카드 체크 시 부모로 체크릐스트 전달
      if (v) {
        this.chkCnt++
      } else {
        this.chkCnt--
      }
      this.$emit('search-count', this.chkCnt)
    },
    getCnt (v) { // 카테고리 별 건 수 체크
      let cnt = 0
      for (let i = 0; i < this.searchList.length; i++) {
        if (this.searchList[i].cat === v) cnt++
      }
      return cnt
    },
    getClass (v) { // 선택된 카테고리 활성화
      if (v === this.selectedTab) {
        return 'active'
      } else {
        return ''
      }
    },
    selectTab (v) { // 선택 시 스크롤 이동
      this.selectedTab = v
      if (v === 0) {
        this.$refs.searchArea.scrollTop = 0
      } else {
        this.$refs.searchArea.scrollTop = this.scrollPos[v - 1].height + 112
      }
    },
    getList (v) { // fdp list mapping 용도
      switch (v) {
        case 0:
          return this.list1
        case 1:
          return this.list2
        case 2:
          return this.list3
        case 3:
          return this.list4
        case 4:
          return this.list5
        case 5:
          return this.list6
      }
    }
    // handleScroll (event) { // 스크롤 된 영역에 따른 활성화 탭
    //   if (this.$refs.searchArea.scrollTop > 0 && this.$refs.searchArea.scrollTop < this.scrollPos[0].height) {
    //     this.selectTab(0)
    //   } else if (this.$refs.searchArea.scrollTop > this.scrollPos[0].height && this.$refs.searchArea.scrollTop < this.scrollPos[1].height) {
    //     this.selectTab(1)
    //   } else if (this.$refs.searchArea.scrollTop > this.scrollPos[1].height && this.$refs.searchArea.scrollTop < this.scrollPos[2].height) {
    //     this.selectTab(2)
    //   } else if (this.$refs.searchArea.scrollTop > this.scrollPos[2].height && this.$refs.searchArea.scrollTop < this.scrollPos[3].height) {
    //     this.selectTab(3)
    //   } else if (this.$refs.searchArea.scrollTop > this.scrollPos[3].height && this.$refs.searchArea.scrollTop < this.scrollPos[4].height) {
    //     this.selectTab(4)
    //   } else if (this.$refs.searchArea.scrollTop > this.scrollPos[4].height) {
    //     this.selectTab(5)
    //   }
    // }
  },
  watch: {
    bottomCnt () { // 부모로 부터 받아옴.
      this.chkCnt = this.bottomCnt
    },
    searchKeyword () { // test 자료 세팅.
      if (this.searchKeyword === '1') {
        this.searchList = Array.prototype.slice.call(infoListMocks)
        for (let i = 0; i < this.catList.length; i++) {
          for (let j = 0; j < this.searchList.length; j++) {
            if (this.catList[i].catNm === this.searchList[j].cat) {
              if (i === 0) this.list1.push(this.searchList[j])
              if (i === 1) this.list2.push(this.searchList[j])
              if (i === 2) this.list3.push(this.searchList[j])
              if (i === 3) this.list4.push(this.searchList[j])
              if (i === 4) this.list5.push(this.searchList[j])
              if (i === 5) this.list6.push(this.searchList[j])
            }
          }
        }
      } else if (this.searchKeyword === '2') {
        this.searchList = []
        this.list1 = []
        this.list2 = []
        this.list3 = []
        this.list4 = []
        this.list5 = []
        this.list6 = []
      } else if (this.searchKeyword === '3') {
        this.searchList = Array.prototype.slice.call(infoListMocks)
        for (let i = 0; i < this.catList.length; i++) {
          for (let j = 0; j < this.searchList.length; j++) {
            if (this.catList[i].catNm === this.searchList[j].cat) {
              if (i === 0) this.list1.push(this.searchList[j])
            }
          }
        }
        this.list2 = []
        this.list3 = []
        this.list4 = []
        this.list5 = []
        this.list6 = []
      }
    }
  }
}
</script>
