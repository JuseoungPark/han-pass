<template>
    <section>
        <!-- 법인적합성정보 start -->
        <div class="-pub-product__info" v-if="isOrg">
            <div class="-pub-product__info--title">
                <h2>법인적합성정보</h2>
            </div>
            <div class="-pub-product__form -pub-product__corp">
                <form>
                    <ul class="-pub-product__form--list">
                        <li class="-pub-product__form--list-item">
                            <div class="-pub-product__form--list-row -pub-product__corp--list-row">
                                <div class="-pub-product__form--list-column -pub-product__corp--list-column">
                                     <label>성명</label>
                                     <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="formInput.inputEtc5" placeholder="입력하세요"></fdp-text-field>
                                </div>
                                 <div class="-pub-product__form--list-column -pub-product__corp--list-column">
                                    <label>주민등록번호</label>
                                    <div class="security-number">
                                        <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="formInput.inputNum1" placeholder="000000"></fdp-text-field>
                                        <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="formInput.inputNum2" placeholder="000000"></fdp-text-field>
                                     </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
        <!-- 법인적합성정보 end -->
        <!-- 기타정보 start -->
        <div class="-pub-product__info">
            <div class="-pub-product__info--title">
                <h2>기타정보</h2>
            </div>
            <div class="-pub-product__form -pub-product__etc">
                <form>
                    <ul class="-pub-product__form--list">
                        <li class="-pub-product__form--list-item">
                            <div class="-pub-product__form--list-row -pub-product__etc--list-row">
                                <div class="-pub-product__form--list-column -pub-product__etc--list-column">
                                     <label>선납횟수</label>
                                     <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="formInput.inputEtc1" placeholder="입력하세요" virtual></fdp-text-field>
                                </div>
                                 <div class="-pub-product__form--list-column -pub-product__etc--list-column">
                                    <label>후입금여부</label>
                                    <fdp-segment-box class="-pub-segment--small -pub-segment__container -pub-segment--purple" v-model="depositType" :data="depositTypes" essential></fdp-segment-box>
                                </div>
                                 <div class="-pub-product__form--list-column -pub-product__etc--list-column">
                                     <label>내근모집</label>
                                     <fdp-segment-box class="-pub-segment--small -pub-segment__container -pub-segment--purple" v-model="deskjobType" :data="deskjobTypes" essential></fdp-segment-box>
                                     <!-- 내근모집 예 선택시 disabled 삭제하고 placeholder="사번을 입력하세요" 추가 -->
                                     <fdp-text-field class="-pub-input--purple -pub-input--238" v-model="formInput.inputEtc2" :placeholder="deskjobType[0].key!=='1'?'사번을 입력하세요':''" :disabled="deskjobType[0].key==='1'"></fdp-text-field>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__etc--list-column">
                                     <label>직역코드</label>
                                     <fdp-text-field class="-pub-input--purple -pub-input--254" v-model="formInput.inputEtc3" placeholder="입력하세요"></fdp-text-field>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__etc--list-column">
                                     <label>단체코드</label>
                                     <fdp-text-field class="-pub-input--purple -pub-input--254" v-model="formInput.inputEtc4" placeholder="입력하세요"></fdp-text-field>
                                </div>
                            </div>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
        <!-- 기타정보 end -->
    </section>
</template>
<script>
export default {
  props: {
    isOrg: {
      type: Boolean
    }
  },
  data () {
    return {
      formInput: {
        inputEtc1: '',
        inputEtc2: '',
        inputEtc3: '',
        inputEtc4: '',
        inputEtc5: '',
        inputNum1: '',
        inputNum2: ''
      },
      depositType: [{
        key: '1',
        label: '아니오'
      }],
      depositTypes: [{
        key: '1',
        label: '아니오'
      },
      {
        key: '2',
        label: '예'
      }],
      deskjobType: [{
        key: '1',
        label: '아니오'
      }],
      deskjobTypes: [{
        key: '1',
        label: '아니오'
      },
      {
        key: '2',
        label: '예'
      }]
    }
  }
}
</script>
