<template>
    <section class="-pub-activity">
        <div class="-pub-activity__coach--input">
            <div class="-pub-page-header">
                <h3 class="-pub-page-header__title">육성코치 활동입력</h3>
            </div>
            <div class="-pub-search-fillter">
                <span class="-pub-filter-menu__label">육성코치</span>
                <fdp-select class="-pub-select" v-model="filterSelectValue" placeholder="" :option-list="filterSelectItems" :disabled="loginType!=='3'"></fdp-select>
                <span class="-pub-filter-menu__label">활동 월</span>
                <fdp-date-picker class="-pub-date-picker" v-model="targetMonth" placeholder="소개일" format="yyyy-MM"></fdp-date-picker>
                <div class="-pub-button-area">
                    <button type="submit" class="-pub-button -pub-button--purple -pub-button--light">조회</button>
                </div>
            </div>
            <div class="-pub-search-total">
                <div class="-pub-filter-menu__text">총 {{mockData.length}}명</div>
            </div>
            <div class="-pub-search-list">
                <fdp-infinite class="-pub-table" :items="mockData" :tableBodyHeight="885">
                    <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '290px' : '320px' }" v-if="loginType==='2' || loginType==='3'">육성코치명</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '280px' : '320px' }" v-if="loginType==='1' || loginType==='3'">신인명</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '220px' : '266px' }">동행일자</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '130px' : '176px' }">시간</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '130px' : '176px' }">동행횟수</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '130px' : '176px' }">적용여부</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '170px' : '216px' }">신인서명</th>
                        <th class="-pub-table-column" :style="{ width: loginType==='3' ? '170px' : '216px' }">지점장서명</th>
                    </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '290px': '320px' }" v-if="loginType==='2' || loginType==='3'">{{props.item.name}}</td>
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '280px': '320px' }" v-if="loginType==='1' || loginType==='3'"><span :class="loginType==='1'?'-pub-table-column__underline':''">{{props.item.name2}}</span></td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" :style="{ width: loginType==='3' ? '220px' : '266px' }">{{props.item.date}}</td>
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '130px' : '176px' }">{{props.item.time}}</td>
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '130px' : '176px' }">{{props.item.fellow}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" :style="{ width: loginType==='3' ? '130px' : '176px' }">{{props.item.application}}</td>
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '170px' : '216px' }">
                            <template v-if="props.item.newMemberSign === 'Y'">
                                <span class="-pub-button -pub-button-sign" v-if="loginType==='2'">서명완료</span>
                                <span v-else>서명완료</span>
                            </template>
                            <template v-else>
                                -
                            </template>
                        </td>
                        <td class="-pub-table-column" :style="{ width: loginType==='3' ? '170px' : '216px' }">
                            <template v-if="props.item.masterSign === 'Y'">
                                <span class="-pub-button -pub-button-sign"  v-if="loginType==='3'">서명완료</span>
                                <span v-else>서명완료</span>
                            </template>
                            <template v-else-if="props.item.newMemberSign === 'Y'">
                                <span class="-pub-button -pub-button-sign" v-if="loginType==='3'">서명하기</span>
                                <span v-else>서명하기</span>
                            </template>
                            <template v-else>
                                -
                            </template>
                        </td>
                    </template>
                    <template slot="emptyView" v-show="mockData.length == 0">
                        <div class="-pub-table-empty-view">
                            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                        </div>
                        <div class="-pub-table-empty-view -pub-table-empty-view--search">
                            <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                        </div>
                    </template>
                </fdp-infinite>
            </div>
        </div>
    </section>
</template>
<script>
import {
  viewMemberMocks
} from '@/components/mock/TSSAP120M.mock'
export default {
  data () {
    return {
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      emptyData: [],
      targetMonth: new Date().toISOString(),
      filterSelectValue: {
        key: '1',
        label: '전체'
      },
      filterSelectItems: [{
        key: '1',
        label: 'sample1'
      },
      {
        key: '2',
        label: 'sample2'
      }
      ],
      loginType: '3' // 1:육성코치 2:신인 3:지점장
    }
  }
}
</script>
