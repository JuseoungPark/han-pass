<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="활동추가" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup-activity">
                <div class="-pub-popup-activity__add">
                    <dl class="-pub-popup-activity__add--item-list">
                        <dt class="-pub-popup-activity__add--item-tit">신인명</dt>
                        <dd class="-pub-popup-activity__add--item-cont">김준혁</dd>
                    </dl>
                    <dl class="-pub-popup-activity__add--item-list">
                        <dt class="-pub-popup-activity__add--item-tit">동행일자</dt>
                        <dd class="-pub-popup-activity__add--item-cont">
                            <fdp-validator name="Name" v-model="targetMonth" display-name="이름" :rules="'required|min:2'">
                                <fdp-date-picker class="-pub-date-picker" v-model="targetMonth" placeholder="소개일"></fdp-date-picker>
                            </fdp-validator>
                        </dd>
                    </dl>
                    <dl class="-pub-popup-activity__add--item-list">
                        <dt class="-pub-popup-activity__add--item-tit">시간</dt>
                        <dd class="-pub-popup-activity__add--item-cont"><fdp-spin v-model="spinValue" :step="1" :max="10" :min="1"></fdp-spin></dd>
                    </dl>
                    <dl class="-pub-popup-activity__add--item-list">
                        <dt class="-pub-popup-activity__add--item-tit">동행횟수</dt>
                        <dd class="-pub-popup-activity__add--item-cont"><fdp-spin v-model="spinValue" :step="1" :max="10" :min="1"></fdp-spin></dd>
                    </dl>
                </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      Name: '',
      targetMonth: new Date().toISOString(),
      spinValue: 1
    }
  }
}
</script>
