<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="임의목표 입력" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup-activity">
                <div class="-pub-popup-activity__randomInput">
                    <div class="-pub-table-header">
                        <h4 class="-pub-table-header__tit">환산성적</h4>
                    </div>
                    <div class="-pub-popup__table">
                        <fdp-table :options="opt" :items="mockData" class="-pub-table_wrap">
                            <template slot="empty">
                                <div class="-pub-table-empty-view">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-table>
                    </div>
                    <div class="-pub-table-header">
                        <h4 class="-pub-table-header__tit">리크루팅 (건수)</h4>
                    </div>
                    <div class="-pub-popup__table">
                        <fdp-infinite class="-pub-table" v-model="selectItemsOrigin" :items="recuitingData">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column" style="width: 280px;">현재</th>
                                    <th class="-pub-table-column" style="width: 280px;">추가목표</th>
                                    <th class="-pub-table-column" style="width: 280px;">당월 누계</th>
                                </tr>
                            </template>
                            <template slot="emptyView" v-show="recuitingData.length == 0">
                                <div class="-pub-table-empty-view">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 280px;">0</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 280px;"><fdp-spin v-model="spinValue" :step="1" :max="10" :min="0"></fdp-spin></td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 280px;">0</td>
                            </template>
                        </fdp-infinite>
                    </div>
                </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
    </fdp-popup>
</template>
<script>
import cusCell from './comps/TSSAP132P-customcell'
export default {
  data () {
    return {
      showPopup: true,
      opt: columnFixed,
      mockData: [{
        section: '보장',
        goals: '1,000,850,000',
        mean: '1,000,850,000',
        meanOther: '1,000,850,000',
        month01: '1,000,850,000',
        month02: '1,000,850,000',
        month03: '1,000,850,000',
        month04: '1,000,850,000',
        month05: '1,000,850,000',
        month06: '1,000,850,000'
      },
      {
        section: '금융',
        goals: '1,000,850,000',
        mean: '1,000,850,000',
        meanOther: '1,000,850,000',
        month01: '1,000,850,000',
        month02: '1,000,850,000',
        month03: '1,000,850,000',
        month04: '1,000,850,000',
        month05: '1,000,850,000',
        month06: '1,000,850,000'
      },
      {
        section: '합계',
        type: 'sum',
        goals: '1,000,850,000',
        mean: '1,000,850,000',
        meanOther: '1,000,850,000',
        month01: '1,000,850,000',
        month02: '1,000,850,000',
        month03: '1,000,850,000',
        month04: '1,000,850,000',
        month05: '1,000,850,000',
        month06: '1,000,850,000'
      }
      ],
      recuitingData: [
        {
          now: '0',
          total: '0'
        }
      ]
    }
  }
}
var columnFixed = {
  name: 'columnFixed',
  cols: [
    {key: 'section', width: 152, name: ' ', headerStyle: {'text-align': 'center', 'border-right': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'left', 'border-right': '2px solid #e0e5ef', 'font-weight': 'bold', 'padding-left': '28px'}},
    {key: 'goals', component: cusCell, width: 270, name: '적용목표', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
    {key: 'mean', width: 254, name: '6개월 평균', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'meanOther', width: 254, name: '6개월평균\n\n*잔여일수/30', headerStyle: {'padding-right': '16px', 'text-align': 'center', 'white-space': 'pre-line', 'line-height': '20px'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month01', width: 254, name: '1월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month02', width: 254, name: '2월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month03', width: 254, name: '3월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month04', width: 254, name: '4월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month05', width: 254, name: '5월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}},
    {key: 'month06', width: 254, name: '6월', headerStyle: {'padding-right': '16px', 'text-align': 'center'}, bodyStyle: {'padding-right': '16px', 'text-align': 'right', 'letter-spacing': '0'}}
  ],
  // 컬럼 고정 여부
  availableColumnFixed: true,
  // 고정할 컬럼 수 (왼쪽부터 적용)
  howManyColumnFixed: 4,
  headerHeight: 104,
  multiSelect: true,
  tableHeight: 376,
  infinite: true
}
</script>
