<template>
    <div class="-pub-product-question__content">
        <div class="-pub-product-question__content--title">
            <h2>적합성진단 질문지</h2>
        </div>
        <div class="-pub-product-question__survey" ref="scrollWrapper">
            <div v-for="(group, idx1) in mockQuestionData" :key="idx1" class="-pub-product-question__survey--row">
                <h3>{{group.category}}</h3>
                <ul class="-pub-product-question__survey--list">
                    <!-- 포커스된 질문에  자동으로 scroll top -->
                    <!-- 포거스된 문항에 추가 -pub-product-question__survey--list-item-focus -->
                    <!-- 답변한 문항에 추가 -pub-product-question__survey--list-item-answer -->
                    <li v-for="question in group.data" :key="question.index"
                        :class="[{'-pub-product-question__survey--list-item': true},
                                 {'-pub-product-question__survey--list-item-focus': question.index === currentQuestion},
                                 {'-pub-product-question__survey--list-item-answer': answerList[question.index].length > 0}]"
                        @click="clickQuestionNo(question.index)"  ref="questionScroll">
                        <!-- 질문 -->
                        <div class="quest" ref="question">
                            <span class="num">{{question.index}}</span>
                            <p class="txt">{{question.question}}</p>
                        </div>
                        <!-- 답변 -->
                        <p class="reply" v-if="!hasMultAns(question.index)">{{ answerList[question.index].length > 0 ? question.choice[answerList[question.index] - 1].label : '' }}</p>
                        <p class="reply" v-else v-for="(number, idx2) in answerList[question.index]" :key="idx2">
                          {{question.choice[number - 1].label}}
                        </p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
<script>
import {
  createScrollAnimateInstance
} from '@/components/util/scroll-animate'
export default {
  props: {
    mockQuestionData: {
      type: Array,
      default: _ => []
    },
    mockAnswerData: {
      type: Array,
      default: _ => []
    },
    currentQuestion: {
      type: Number,
      default: _ => 0
    },
    answerList: {
      type: Array,
      default: _ => []
    }
  },
  data () {
    return {
    }
  },
  methods: {
    hasMultAns (idx) {
      if (this.mockAnswerData[idx].checkbox) {
        return true
      } else {
        return false
      }
    },
    clickQuestionNo (idx) {
      this.$emit('changeQuestionNo', idx)
    },
    moveScroll (targetPoint) {
      const scrollEl = this.$refs.scrollWrapper
      // const targetEl = this.$refs.questionScroll[this.currentQuestion]

      // 스크롤 애니메이션 인스턴스 생성 1000ms 후에 이동 이벤트 scrollAnimation 관련 scroll-animate.js 파일 참조
      const scrollXAnimate = createScrollAnimateInstance(scrollEl, 'y')
      // aguments 순서 (이동할 좌표픽셀값, 진행시간, 딜레이, 타이밍 function name, 애니메이션 끝난후 콜백 function)
      // scrollXAnimate.animate(500, 1500, 1000, 'easeInOut', _ => console.log('애니메이션 끝'))
      scrollXAnimate.animate(targetPoint, 1500, 0, 'easeInOut', _ => console.log('애니메이션 끝'))
    }
  },
  watch: {
    currentQuestion () {
      this.$nextTick(() => {
        this.moveScroll(this.$refs.questionScroll[this.currentQuestion].offsetTop - 211)
      })
    }
  }
}
</script>
