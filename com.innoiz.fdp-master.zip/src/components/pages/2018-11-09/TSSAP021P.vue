<!--
2. 고객명 :
-등록고객 미등록고객 선택시 텍스트필드 스타일이 다름
-->
<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="새일정등록" prevent-outside-close>
    <!-- 구분 영업일정 : START -->
    <div class="-fdp-popup-page__slot -pub-popup-page__schedule">
        <div class="-pub-popup__content -pub-popup__content--newplan">
            <ul class="-pub-popup__content--newplan-list" :class="isPersonal?'-pub-popup__content--newplan-list-right':''">
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item1">
                    <label class="-pub-popup__label">구분 <span class="-pub-popup__label--point">*</span></label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <fdp-validator name="tssap021p-validator-1" display-name="구분" v-model="segVal1" :rules="'required'">
                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="segVal1" :data="newplanTypes1"></fdp-segment-box>
                        </fdp-validator>
                    </div>
                </li>
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item2">
                    <label class="-pub-popup__label">고객명 <span class="-pub-popup__label--point">*</span></label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <fdp-validator  name="tssap021p-validator-2" display-name="고객구분" v-model="segVal2" :rules="'required'">
                             <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="segVal2" :data="newplanTypes2" v-show="!isPersonal"></fdp-segment-box>
                        </fdp-validator>
                        <fdp-validator  name="tssap021p-validator-3" display-name="고객명" v-model="custName" :rules="'required'">
                            <!-- 등록고객 focus시 29줄 on, 미등록고객 focus시 30줄 on -->
                            <fdp-text-field class="-pub-input--purple -pub-input-newplan"  v-model="custName" :fixedIcon="showIcon" placeholder="이름"></fdp-text-field>
                        </fdp-validator>
                    </div>
                </li>
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item3">
                    <label class="-pub-popup__label">일시 <span class="-pub-popup__label--point">*</span></label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <div class="-pub-date-time-wrap">
                            <fdp-validator  name="tssap021p-validator-10" display-name="일자" v-model="targetMonth1" :rules="'required'">
                                <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple" v-model="targetMonth1" format="yyyy-MM-dd"></fdp-date-picker>
                            </fdp-validator>
                            <fdp-validator  name="tssap021p-validator-10" display-name="시간" v-model="time1" :rules="'required'">
                                <fdp-time-picker v-model="timeValue1" format="A hh:mm" hide-clear-button v-show="!isAllDay"></fdp-time-picker>
                            </fdp-validator>
                            <span class="-pub-filter-detail__item">~</span>
                            <fdp-validator  name="tssap021p-validator-10" display-name="일자" v-model="targetMonth2" :rules="'required'">
                              <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple" v-model="targetMonth2" format="yyyy-MM-dd"></fdp-date-picker>
                            </fdp-validator>
                            <fdp-validator  name="tssap021p-validator-10" display-name="시간" v-model="time2" :rules="'required'">
                             <fdp-time-picker v-model="timeValue2" format="A hh:mm" hide-clear-button v-show="!isAllDay"></fdp-time-picker>
                            </fdp-validator>
                        </div>
                        <div class="-pub-check-wrap">
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isAllDay"></fdp-checkbox>
                        <div class="-pub-checkbox-label">종일</div>
                        </div>
                    </div>
                </li>
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item4">
                    <label class="-pub-popup__label">{{isPersonal?'장소':'만날장소'}}</label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <fdp-text-field class="-pub-input--purple -pub-input-newplan" v-model="place" placeholder="입력하세요"></fdp-text-field>
                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="segVal3" :data="newplanTypes3" v-if="!isPersonal" multi></fdp-segment-box>
                    </div>

                    <!-- validator 기능시 -->
                    <!-- <div class="-pub-popup__content--newplan-list-item-row">
                        <fdp-validator  name="tssap021p-validator-4" :display-name="isPersonal?'장소':'만날장소'" v-model="place" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input-newplan" v-model="place" placeholder="입력하세요"></fdp-text-field>
                         </fdp-validator>
                        <fdp-validator  name="tssap021p-validator-15" :display-name="isPersonal?'장소':'만날장소'" v-model="segVal3" :rules="'required'">
                            <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="segVal3" :data="newplanTypes3" v-if="!isPersonal" multi></fdp-segment-box>
                         </fdp-validator>
                    </div> -->
                </li>
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item5" v-if="!isPersonal">
                    <label class="-pub-popup__label">캠페인</label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <fdp-validator  name="tssap021p-validator-4" display-name="캠페인" v-model="campaign.key" :rules="'required'">
                        <fdp-select ellipsis class="-pub-select" v-model="campaign" :option-list="nationItems1" :disabled="segVal2.length===0" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                </li>
                <li class="-pub-popup__content--newplan-list-item -pub-popup__content--newplan-list-item6">
                    <label class="-pub-popup__label">휴대폰알림</label>
                    <div class="-pub-popup__content--newplan-list-item-row">
                        <div class="-pub-check-wrap">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
                                v-model="isUse">
                                </fdp-checkbox>
                            <div class="-pub-checkbox-label">사용</div>
                        </div>
                        <fdp-validator name="tssap021p-validator-24" display-name="알림" v-model="alramDay.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select" v-model="alramDay" :option-list="nationItems2" placeholder="선택하세요" up :disabled="!isUse"></fdp-select>
                        </fdp-validator>
                        <fdp-validator name="tssap021p-validator-25" display-name="알림시간" v-model="time3" :rules="'required'">
                         <fdp-time-picker format="A hh:mm" v-model="timeValue3"  hide-clear-button :disabled="!isUse"></fdp-time-picker>
                        </fdp-validator>

                    </div>
                </li>
            </ul>
            <div class="-pub-popup__button-area">
                <div class="-pub-popup__button-area-right">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--180">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--180 -pub-button--reverse">
                        <span class="-pub-button__text" @click="save">확인</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- 구분 영업일정 : END -->

  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      isPersonal: false,
      timeValue1: {
        A: '오전',
        hh: '02',
        mm: '00'
      },
      timeValue2: {
        A: '오전',
        hh: '02',
        mm: '00'
      },
      timeValue3: {
        A: '오전',
        hh: '02',
        mm: '00'
      },
      targetMonth1: '',
      targetMonth2: '',
      isSelectAll: false,
      selectItems: [],
      isAllDay: false,
      isUse: false,
      place: '',
      formInput: {
        inputNation1: { key: '5월 고객사랑 캠페인', label: '5월 고객사랑 캠페인' },
        inputNation2: { key: '1 일전', label: '1 일전' },
        inputNation3: { key: '당일', label: '당일' }
      },
      showPopup: true,
      custName: '',
      segVal1: [{key: '1', label: '영업일정'}],
      segVal2: [{key: '1', label: '등록고객'}],
      segVal3: [{key: '1', label: '자택'}],
      campaign: {key: '', label: ''},
      alramDay: {key: '1 일전', label: '1 일전'},
      newplanTypes1: [{
        key: '1',
        label: '영업일정'
      },
      {
        key: '2',
        label: '개인일정'
      }],
      newplanTypes2: [{
        key: '1',
        label: '등록고객'
      },
      {
        key: '2',
        label: '미등록고객'
      }],
      newplanTypes3: [{
        key: '1',
        label: '자택'
      },
      {
        key: '2',
        label: '직장'
      }],
      nationItems1: [{
        key: '5월 고객사랑 캠페인',
        label: '5월 고객사랑 캠페인'
      },
      {
        key: '6월 고객사랑 캠페인',
        label: '6월 고객사랑 캠페인'
      },
      {
        key: '7월 고객사랑 캠페인',
        label: '7월 고객사랑 캠페인'
      }],
      nationItems2: [{
        key: '1 일전',
        label: '1 일전'
      },
      {
        key: '2 일전',
        label: '2 일전'
      },
      {
        key: '3 일전',
        label: '3 일전'
      }],
      nationItems3: [{
        key: '당일',
        label: '당일'
      },
      {
        key: '당일1',
        label: '당일1'
      },
      {
        key: '당일2',
        label: '당일2'
      }]
    }
  },
  mounted () {
    this.timeValue1 = {
      A: '오후',
      hh: '02',
      mm: '00'
    }
    this.timeValue2 = {
      A: '오후',
      hh: '03',
      mm: '00'
    }
    this.timeValue3 = {
      A: '오후',
      hh: '02',
      mm: '00'
    }
  },
  methods: {
    save () {
      // 알수없음
      this.$refs.toast.makeToast(this.planname + '')
    }
  },
  watch: {
    segVal1 () {
      if (this.segVal1.length > 0) {
        if (this.segVal1[0].key === '1') {
          this.isPersonal = false
        } else {
          this.isPersonal = true
        }
      }
    }
  },
  computed: {
    time1 () {
      if (this.timeValue1.hh === '' || this.timeValue1.mm === '') {
        return ''
      } else {
        return this.timeValue1.hh
      }
    },
    time2 () {
      if (this.timeValue2.hh === '' || this.timeValue2.mm === '') {
        return ''
      } else {
        return this.timeValue2.hh
      }
    },
    time3 () {
      if (this.timeValue3.hh === '' || this.timeValue3.mm === '') {
        return ''
      } else {
        return this.timeValue3.hh
      }
    },
    showIcon () {
      if (this.segVal1.length > 0 && this.segVal1[0].key === '2') return false
      if ((this.segVal1.length > 0 && this.segVal1[0].key === '1') && (this.segVal2.length > 0 && this.segVal2[0].key === '2')) return false

      return true
    }
  }
}
</script>
