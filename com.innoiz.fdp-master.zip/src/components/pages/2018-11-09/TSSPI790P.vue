<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="전산심사" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--electronic">
            <TSSPI800D :partyList="partyList" :isOrg=isOrg></TSSPI800D>
            <TSSPI810D :partyList="partyList" :isOrg=isOrg></TSSPI810D>
            <TSSPI820D :isOrg=isOrg></TSSPI820D>
        </div>
         <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item ">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-button--210 -pub-bottom-nav__item">
                        <span class="-pub-button__text">공동모집</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-button--210 -pub-bottom-nav__item -pub-button--reverse">
                        <span class="-pub-button__text">심사실행</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
    <!-- 화면 확인용 테스트 버튼 -->
    <div class="-pub-product-btn-test">
        <a href="#" @click="isOrg=!isOrg">개인/단체화면 확인 테스트 버튼</a>
    </div>
  </fdp-popup>
</template>
<script>
import TSSPI800D from '@/components/pages/2018-11-09/TSSPI800D'
import TSSPI810D from '@/components/pages/2018-11-09/TSSPI810D'
import TSSPI820D from '@/components/pages/2018-11-09/TSSPI820D'
export default {
  components: {
    TSSPI800D,
    TSSPI810D,
    TSSPI820D
  },
  data () {
    return {
      isOrg: true, // 개인,단체 여부
      showPopup: true,
      partyList: [{ // 심사정보에 사용되는 고객정보
        role: '계약자',
        corp: {key: '법인사업자', label: '법인사업자'},
        name: '이주명',
        ssno: '701212-1212111',
        job: '공무원',
        age: '35',
        nation: {key: '내국인', label: '내국인'},
        carType: {key: '승용차', label: '승용차'}
      },
      {
        role: '주피',
        name: '이준명',
        ssno: '851212-1212111',
        job: '공무원',
        age: '32',
        nation: {key: '내국인', label: '내국인'},
        carType: {key: '승용차', label: '승용차'}
      },
      {
        role: '종피',
        name: '이종명',
        ssno: '901212-1212111',
        job: '공무원',
        age: '22',
        nation: {key: '내국인', label: '내국인'},
        carType: {key: '승용차', label: '승용차'}
      },
      {
        role: '자녀',
        num: 1,
        name: '이구명',
        ssno: '131212-1212111',
        job: '아기',
        age: '2',
        nation: {key: '내국인', label: '내국인'},
        carType: {key: '승용차', label: '승용차'}
      },
      {
        role: '자녀',
        num: 2,
        name: '이수명',
        ssno: '141212-1212111',
        job: '아기',
        age: '1',
        nation: {key: '내국인', label: '내국인'},
        carType: {key: '승용차', label: '승용차'}
      }]
    }
  }
}
</script>
