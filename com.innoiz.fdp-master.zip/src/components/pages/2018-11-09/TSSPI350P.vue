<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="가입설계 저장" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot -pub-popup-page__save">
            <!-- 세대조정 Start -->
            <div class="-pub-popup__edit-customer_save">
                <div class="-pub-popup__content-body">
                    <div class="-pub-popup-content__tit">설계명</div>
                    <div class="-pub-popup-content__con">통합유니버설종신보험3.0(무배당,보증비용부과형)_</div>
                    <fdp-validator name="name" v-model="designName" :rules="'required'">
                        <fdp-text-field v-model="designName" placeholder="5"></fdp-text-field>
                    </fdp-validator>
                </div>
                <div class="-pub-popup__content-btm">
                    <div class="-pub-popup-content__con">※ 저장은 30개까지 가능하며, 30개가 넘으면 먼저 설계한 순서대로 자동삭제됩니다.</div>
                </div>
            </div>
            <!--// 세대조정 end -->
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar -pub-bottom-bar__save">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--confirm">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>

export default {
  data () {
    return {
      designName: '',
      showPopup: true
    }
  }
}
</script>
