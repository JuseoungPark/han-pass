<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="가입설계 대상확정" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup-activity">
                <div class="-pub-popup-activity__memberDecide">
                    <div class="-pub-filter-menu">
                        <div class="-pub-filter-menu__item--right">
                            <form onsubmit="return false;">
                            <div class="-pub-filter-menu__item">
                                <span class="-pub-filter-menu__item -pub-filter-menu__label">설계기간</span>
                                <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-date-picker-first" v-model="targetMonth" placeholder="설계기간" format="yyyy-MM-dd"></fdp-date-picker>
                                <span class="-pub-filter-detail__item separator-tilde"></span>
                                <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker -pub-filter-menu__item--date-picker-top" v-model="targetMonth" placeholder="설계기간" format="yyyy-MM-dd"></fdp-date-picker>
                            </div>
                            <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                            </button>
                            </form>
                        </div>
                        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
                    </div>
                    <div class="-pub-popup__table">
                        <fdp-infinite class="-pub-table" v-model="selectItems" :items="mockData" multi-select>
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--checkbox" style="width: 78px;">
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
                                            v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                                    </th>
                                    <th class="-pub-table-column" style="width: 144px;">설계번호</th>
                                    <th class="-pub-table-column" style="width: 144px;">계약자</th>
                                    <th class="-pub-table-column" style="width: 144px;">피보험자</th>
                                    <th class="-pub-table-column" style="width: 210px;">상품명</th>
                                    <th class="-pub-table-column" style="width: 128px;">상품군</th>
                                    <th class="-pub-table-column" style="width: 144px;">보험기간</th>
                                    <th class="-pub-table-column" style="width: 170px;">납입보험료</th>
                                    <th class="-pub-table-column" style="width: 170px;">환산성적</th>
                                    <th class="-pub-table-column" style="width: 182px;">설계일자</th>
                                </tr>
                            </template>
                            <template slot="emptyView" v-show="mockData.length == 0">
                                <div class="-pub-table-empty-view">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                                <div class="-pub-table-empty-view -pub-table-empty-view--search">
                                    <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                                </div>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--checkbox" style="width: 78px;">
                                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems"
                                        :value="props.item"></fdp-checkbox>
                                </td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 144px;">{{props.item.num}}</td>
                                <td class="-pub-table-column" style="width: 144px;">{{props.item.name1}}</td>
                                <td class="-pub-table-column" style="width: 144px;">{{props.item.name2}}</td>
                                <td class="-pub-table-column -pub-align-left" style="width: 210px;">{{props.item.productName}}</td>
                                <td class="-pub-table-column" style="width: 128px;">{{props.item.productGroup}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 144px;">{{props.item.period}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 170px;">{{props.item.premium}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 170px;">{{props.item.record}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 182px;">{{props.item.date}}</td>
                            </template>
                        </fdp-infinite>
                    </div>
                </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" :page-fixed="true">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox
                        v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
                    </li>
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
    </fdp-popup>
</template>
<script>
import {
  viewMemberMocks
} from '@/components/mock/TSSAP131P.mock'
export default {
  data () {
    return {
      showPopup: true,
      targetMonth: '2017-01-01',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      isSelectAll: false,
      bottomBarCheck: false,
      selectItems: []
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      console.log(offsetTop)
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  mounted () {
    this.customerType.push(this.customerTypes[0])
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
</script>
