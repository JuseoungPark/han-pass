<!--
1. 대분류 li
- -pub-menu-el-active 으로 on off, 아이콘 제거되어야함
- -pub-menu-el-active-on 로 click 동작, 아이콘 제거 되면 안됨

2. 중분류 li
- show hide는 class="-pub-cate__submenu"에 display 처리
- 중분류 사이즈별 class name이 다름 css파일 125번째

3.소분류 li
- 소분류 사이즈별 class name이 다름 css파일 161번째

-->

<template>
    <div class="-pub-cate">
        <div class="-pub-cate-setting">
            <ul class="-pub-cate__menu">
                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el-active -pub-menu-el__01">
                    <span class="sub_menu_pos">안내자료 홈</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                 <!-- -pub-menu-el-active-on -->
                <li class="-pub-menu-el -pub-menu-el__02" :class="getClass(2)" @click="selectMenu(2)">
                    <span class="sub_menu_pos">추천자료</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">내가 사용한 자료</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">내가 사용한 자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">인기자료</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">인기자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">최신자료</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">최신자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__03" :class="getClass(3)" @click="selectMenu(3)">
                    <span class="sub_menu_pos">상품 안내자료</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">변액상품</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">보장형</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">금융형(연금/저축)</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">변액펀드</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">추천펀드</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">S펀드</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">상품별 펀드</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">시장전망</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">수익률</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">펀드도움방</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">건강</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">종신/정기</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">연금</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">저축</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">상해</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">단체</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리플렛</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">제안서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타자료</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__04" :class="getClass(4)" @click="selectMenu(4)">
                    <span class="letter-zero sub_menu_pos">DM</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">계약</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">가입시점별</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">소개</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">관심</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리크루팅</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">1건 일반고객</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">안부</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">축하</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">명절</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">인사 DM</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">택배</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">정기 DM</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">파란우체통</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">자필 DM</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">자필 DM</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__05" :class="getClass(5)" @click="selectMenu(5)">
                    <span class="sub_menu_pos">친숙</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">경제이슈</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">보험</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">생활법률</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">재테크</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">부자의 습관</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">노후</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-02">
                            <span class="sub_menu_pos">생활/문화</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">반려동물</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">20대 질환관리</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">에세이</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">스마트팁</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">운세</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">건강</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">대화의기술</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">여행</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">미즈라이프</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">삼성생명 On-Air</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">POP 표준샘플</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">캠페인</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">회사소개</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리크루팅</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__06" :class="getClass(6)" @click="selectMenu(6)">
                    <span class="sub_menu_pos">뉴스/통계</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">신문</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">굿모닝 뉴스</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">오늘의 신문</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-03">
                            <span class="sub_menu_pos">뉴스! 生老病死</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">건강</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">은퇴/노후</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">사망/재해</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">교육/가정</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">보험</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">경제/금융</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">부동산/재테크</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">실시간뉴스</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">그래픽뉴스</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">주간추천</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">행복에세이</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-02">
                            <span class="sub_menu_pos">통계! 生老病死</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">건강</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">은퇴/노후</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">사망/재해</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">교육/가정</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">보험</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">경제/금융</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">부동산/재테크</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">인포그래픽</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__07" :class="getClass(7)" @click="selectMenu(7)">
                    <span class="sub_menu_pos">동영상 자료</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">상품</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">상품</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">리크루팅</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">리크루팅</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__08" :class="getClass(8)" @click="selectMenu(8)">
                    <span class="sub_menu_pos">세일즈 북</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">My 세일즈북</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">My 세일즈북</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">고객별 세일즈북</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">고객별 세일즈북</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">추천 세일즈북</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">추천 세일즈북</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->

                <!-- 대분류 li : START -->
                <li class="-pub-menu-el -pub-menu-el__09" :class="getClass(9)" @click="selectMenu(9)">
                    <span class="sub_menu_pos">라이브러리</span>
                    <img class="-pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <!-- 중분류 li : START -->
                    <ul class="-pub-cate__submenu">
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">세일즈</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">세일즈</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active -pub-menu-sub-el-increase-01">
                            <span class="sub_menu_pos">은퇴</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">은퇴백서</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">머니인라이프</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">카드뉴스</span>
                                </li>
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                        <li class="-pub-menu-sub-el -pub-menu-sub-el-active">
                            <span class="sub_menu_pos">기타</span>
                            <!-- 소분류 li : START -->
                            <ul class="-pub-cate__submenu_last">
                                <li class="-pub-menu-sub-el_last">
                                    <span class="sub_menu_pos">기타</span>
                                </li>
                            </ul>
                            <!-- 소분류 li : END -->
                        </li>
                    </ul>
                    <!-- 중분류 li : END -->
                </li>
                <!-- 대분류 li : END -->
            </ul>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      selectedMenu: ''
    }
  },
  methods: {
    getClass (v) {
      if (v === this.selectedMenu) {
        return '-pub-menu-el-active-on'
      } else {
        return ''
      }
    },
    selectMenu (v) {
      if (this.selectedMenu === v) {
        this.selectedMenu = ''
      } else {
        this.selectedMenu = v
      }
    }
  }
}
</script>
