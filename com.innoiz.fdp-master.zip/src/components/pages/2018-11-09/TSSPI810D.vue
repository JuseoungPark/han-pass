<template>
    <section>
        <!-- 주피보험자 상해/사망 시 수익자 start -->
        <div class="-pub-product__info">
            <div class="-pub-product__info--title">
                <h2>주피보험자 상해/사망 시 수익자</h2>
                <div class="btn-area-right">
                    <!--삭제 비활성화 disabled 속성 추가 -->
                    <button type="button" class="-pub-button -pub-button--purple" @click="del">삭제</button>
                    <!--복수 추가 가능 하단 리스트 li class="-pub-product__form--list-item" 추가 -->
                    <button type="button" class="-pub-button -pub-button--purple" @click="add">추가</button>
                </div>
            </div>
            <div class="-pub-product__form -pub-product__benefit">
                <form>
                    <ul class="-pub-product__form--list">
                        <!-- 상해 시 -->
                        <li class="-pub-product__form--list-item">
                            <div class="-pub-product__form--list-person -pub-product__benefit--list-person">
                                <strong class="name blank">상해 시</strong>
                            </div>
                            <div class="-pub-product__form--list-row -pub-product__benefit--list-row">
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>성명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi810d-validator-1" display-name="성명" v-model="injuBene1.name" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="injuBene1.nameType" :option-list="beneItems" placeholder="선택하세요" @input="selectParty(injuBene1)"></fdp-select>
                                        <!-- 셀렉트 직접입력 선택시 나오는 텍스트 필드 -->
                                        <div class="num" v-if="injuBene1.nameType.key!=='직접입력'">{{injuBene1.name}}</div>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="injuBene1.name" placeholder="입력하세요" v-else></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column -pub-product__benefit--list-column-age">
                                     <label>연령<span class="-pub-required" v-if="injuBene1.nameType.key==='직접입력'"></span></label>
                                     <div class="num" v-if="injuBene1.nameType.key!=='직접입력'">{{injuBene1.age}}</div>
                                     <fdp-validator name="tsspi810d-validator-2" display-name="연령" v-model="injuBene1.age" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--98" v-model="injuBene1.age" placeholder="00"></fdp-text-field>
                                     </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                     <label>주민등록번호<span class="-pub-required" v-if="injuBene1.nameType.key==='직접입력'"></span></label>
                                     <div class="num"  v-if="injuBene1.nameType.key!=='직접입력'">{{injuBene1.ssno1 + '-' +injuBene1.ssno2}}</div>
                                      <div class="security-number"  v-else>
                                         <fdp-validator name="tsspi810d-validator-3" display-name="주민등록번호" v-model="injuBene1.ssno1" :rules="'required'">
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="injuBene1.ssno1" placeholder="000000"></fdp-text-field>
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="injuBene1.ssno2" placeholder="000000"></fdp-text-field>
                                        </fdp-validator>
                                     </div>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>지급률(%)<span class="-pub-required" v-if="injuBene1.nameType.key==='직접입력'"></span></label>
                                    <div class="num" v-if="injuBene1.nameType.key!=='직접입력'">{{injuBene1.rat}}</div>
                                     <fdp-validator name="tsspi810d-validator-4" display-name="지급률" v-model="injuBene1.rat" :rules="'required'"  v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="injuBene1.rat" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>국적<span class="-pub-required" v-if="injuBene1.nameType.key==='직접입력'"></span></label>
                                    <div class="txt" v-if="injuBene1.nameType.key!=='직접입력'">{{injuBene1.nat.key}}</div>
                                     <fdp-validator name="tsspi810d-validator-5" display-name="국적" v-model="injuBene1.nat.key" :rules="'required'"  v-else>
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="injuBene1.nat" :option-list="nationItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                        </li>
                        <!-- 사망 시 -->
                        <li class="-pub-product__form--list-item"  v-for="(bene, idx) in beneList1" :key="idx">
                            <div class="-pub-product__form--list-person -pub-product__benefit--list-person">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model="bene.chk"></fdp-checkbox><strong class="name">사망 시{{idx>0?idx+1:''}}</strong>
                            </div>
                            <div class="-pub-product__form--list-row">
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>성명<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi810d-validator-1-1'+idx" display-name="성명" v-model="bene.name" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="bene.nameType" :option-list="beneItems" placeholder="선택하세요" @input="selectParty(bene)"></fdp-select>
                                        <!-- 셀렉트 직접입력 선택시 나오는 텍스트 필드 -->
                                        <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.name}}</div>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="bene.name" placeholder="입력하세요" v-else></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column -pub-product__benefit--list-column-age">
                                     <label>연령<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                     <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.age}}</div>
                                     <fdp-validator :name="'tsspi810d-validator-1-2'+idx" display-name="연령" v-model="bene.age" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--98" v-model="bene.age" placeholder="00"></fdp-text-field>
                                     </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                     <label>주민등록번호<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                     <div class="num"  v-if="bene.nameType.key!=='직접입력'">{{bene.ssno1 + '-' +bene.ssno2}}</div>
                                     <div class="security-number" v-else>
                                         <fdp-validator :name="'tsspi810d-validator-1-3'+idx" display-name="주민등록번호" v-model="bene.ssno1" :rules="'required'">
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="bene.ssno1" placeholder="000000"></fdp-text-field>
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="bene.ssno2" placeholder="000000"></fdp-text-field>
                                        </fdp-validator>
                                     </div>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>지급률(%)<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                    <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.rat}}</div>
                                     <fdp-validator :name="'tsspi810d-validator-1-4'+idx" display-name="지급률" v-model="bene.rat" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="bene.rat" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>국적<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                    <div class="txt" v-if="bene.nameType.key!=='직접입력'">{{bene.nat.key}}</div>
                                    <fdp-validator :name="'tsspi810d-validator-1-5'+idx" display-name="국적" v-model="bene.nat.key" :rules="'required'" v-else>
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="bene.nat" :option-list="nationItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
        <!-- 주피보험자 상해/사망 시 수익자 end -->
        <!-- 종피보험자 상해/사망 시 수익자 start -->
        <div class="-pub-product__info">
            <div class="-pub-product__info--title">
                <h2>종피보험자 상해/사망 시 수익자</h2>
            </div>
            <div class="-pub-product__form -pub-product__benefit">
                <form>
                    <ul class="-pub-product__form--list">
                        <!-- 상해 시 -->
                        <li class="-pub-product__form--list-item">
                            <div class="-pub-product__form--list-person -pub-product__benefit--list-person">
                                <strong class="name blank">상해 시</strong>
                            </div>
                            <div class="-pub-product__form--list-row -pub-product__benefit--list-row">
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>성명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi810d-validator-6" display-name="성명" v-model="injuBene2.name" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="injuBene2.nameType" :option-list="beneItems" placeholder="선택하세요" @input="selectParty(injuBene2)"></fdp-select>
                                        <div class="num" v-if="injuBene2.nameType.key!=='직접입력'">{{injuBene2.name}}</div>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="injuBene2.name" placeholder="입력하세요" v-else></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column -pub-product__benefit--list-column-age">
                                     <label>연령<span class="-pub-required" v-if="injuBene2.nameType.key==='직접입력'"></span></label>
                                     <div class="num" v-if="injuBene2.nameType.key!=='직접입력'">{{injuBene2.age}}</div>
                                     <fdp-validator name="tsspi810d-validator-7" display-name="연령" v-model="injuBene2.age" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--98" v-model="injuBene2.age" placeholder="00"></fdp-text-field>
                                     </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                     <label>주민등록번호<span class="-pub-required" v-if="injuBene2.nameType.key==='직접입력'"></span></label>
                                     <div class="num"  v-if="injuBene2.nameType.key!=='직접입력'">{{injuBene2.ssno1 + '-' +injuBene2.ssno2}}</div>
                                      <div class="security-number"  v-else>
                                         <fdp-validator name="tsspi810d-validator-8" display-name="주민등록번호" v-model="injuBene2.ssno1" :rules="'required'">
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="injuBene2.ssno1" placeholder="000000"></fdp-text-field>
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="injuBene2.ssno2" placeholder="000000"></fdp-text-field>
                                        </fdp-validator>
                                     </div>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>지급률(%)<span class="-pub-required" v-if="injuBene2.nameType.key==='직접입력'"></span></label>
                                    <div class="num" v-if="injuBene2.nameType.key!=='직접입력'">{{injuBene2.rat}}</div>
                                     <fdp-validator name="tsspi810d-validator-9" display-name="지급률" v-model="injuBene2.rat" :rules="'required'"  v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="injuBene2.rat" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>국적<span class="-pub-required" v-if="injuBene2.nameType.key==='직접입력'"></span></label>
                                    <div class="txt" v-if="injuBene2.nameType.key!=='직접입력'">{{injuBene2.nat.key}}</div>
                                     <fdp-validator name="tsspi810d-validator-10" display-name="국적" v-model="injuBene2.nat.key" :rules="'required'"  v-else>
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="injuBene2.nat" :option-list="nationItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                        </li>
                        <!-- 사망 시 -->
                        <li class="-pub-product__form--list-item"  v-for="(bene, idx) in beneList2" :key="idx">
                            <div class="-pub-product__form--list-person -pub-product__benefit--list-person">
                                <strong class="name blank">사망 시</strong>
                            </div>
                            <div class="-pub-product__form--list-row">
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>성명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi810d-validator-17" display-name="성명" v-model="bene.name" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="bene.nameType" :option-list="beneItems" placeholder="선택하세요" @input="selectParty(bene)"></fdp-select>
                                        <!-- 셀렉트 직접입력 선택시 나오는 텍스트 필드 -->
                                        <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.name}}</div>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="bene.name" placeholder="입력하세요" v-else></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column -pub-product__benefit--list-column-age">
                                     <label>연령<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                     <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.age}}</div>
                                     <fdp-validator name="tsspi810d-validator-12" display-name="연령" v-model="bene.age" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--98" v-model="bene.age" placeholder="00"></fdp-text-field>
                                     </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                     <label>주민등록번호<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                     <div class="num"  v-if="bene.nameType.key!=='직접입력'">{{bene.ssno1 + '-' +bene.ssno2}}</div>
                                     <div class="security-number" v-else>
                                         <fdp-validator name="tsspi810d-validator-13" display-name="주민등록번호" v-model="bene.ssno1" :rules="'required'">
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="bene.ssno1" placeholder="000000"></fdp-text-field>
                                            <fdp-text-field class="-pub-input--purple -pub-input--186" v-model="bene.ssno2" placeholder="000000"></fdp-text-field>
                                        </fdp-validator>
                                     </div>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>지급률(%)<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                    <div class="num" v-if="bene.nameType.key!=='직접입력'">{{bene.rat}}</div>
                                     <fdp-validator name="tsspi810d-validator-14" display-name="지급률" v-model="bene.rat" :rules="'required'" v-else>
                                        <fdp-text-field class="-pub-input--purple -pub-input--164" v-model="bene.rat" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product__form--list-column -pub-product__benefit--list-column">
                                    <label>국적<span class="-pub-required" v-if="bene.nameType.key==='직접입력'"></span></label>
                                    <div class="txt" v-if="bene.nameType.key!=='직접입력'">{{bene.nat.key}}</div>
                                    <fdp-validator name="tsspi810d-validator-15" display-name="국적" v-model="bene.nat.key" :rules="'required'" v-else>
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--186" v-model="bene.nat" :option-list="nationItems" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                            </div>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
        <!-- 종피보험자 상해/사망 시 수익자 end -->
    </section>
</template>
<script>
export default {
  props: {
    partyList: {
      type: Array, Object
    },
    isOrg: {
      type: Boolean
    }
  },
  data () {
    return {
      selectedRow: [],
      injuBene1: { // 주피 상해 수익자 정보 단건
        chk: false,
        nameType: {},
        name: '',
        age: '',
        ssno1: '',
        ssno2: '',
        rat: '100',
        nat: {key: '내국인', label: '내국인'}
      },
      beneList1: [{ // 주피 사망 수익자 정보 List
        chk: false,
        nameType: {},
        name: '',
        age: '',
        ssno1: '',
        ssno2: '',
        rat: '100',
        nat: {key: '내국인', label: '내국인'}
      }],
      injuBene2: { // 주피 상해 수익자 정보 단건
        chk: false,
        nameType: {},
        name: '',
        age: '',
        ssno1: '',
        ssno2: '',
        rat: '100',
        nat: {key: '내국인', label: '내국인'}
      },
      beneList2: [{ // 주피 사망 수익자 정보 List
        chk: false,
        nameType: {},
        name: '',
        age: '',
        ssno1: '',
        ssno2: '',
        rat: '100',
        nat: {key: '내국인', label: '내국인'}
      }],
      beneItems: [
        {
          key: '직접입력',
          label: '직접입력'
        }],
      beneDeathItems: [{
        key: '상속인',
        label: '상속인'
      },
      {
        key: '피보험자',
        label: '피보험자명'
      },
      {
        key: '계약자',
        label: '계약자명'
      },
      {
        key: '직접입력',
        label: '직접입력'
      }],
      nationItems: [{
        key: '내국인',
        label: '내국인'
      },
      {
        key: '외국인',
        label: '외국인'
      },
      {
        key: '주민착오',
        label: '주민착오'
      }]
    }
  },
  mounted () {
    for (let i = this.partyList.length - 1; i >= 0; i--) {
      this.beneItems.unshift({'key': this.partyList[i].name, 'label': this.partyList[i].name})
    }
    this.injuBene1.nameType = {'key': this.beneItems[0].key, 'label': this.beneItems[0].key}
    this.selectParty(this.injuBene1)
    this.injuBene2.nameType = {'key': this.beneItems[0].key, 'label': this.beneItems[0].key}
    this.selectParty(this.injuBene2)
    this.beneList1[0].nameType = {'key': this.beneItems[0].key, 'label': this.beneItems[0].key}
    this.selectParty(this.beneList1[0])
    this.beneList2[0].nameType = {'key': this.beneItems[0].key, 'label': this.beneItems[0].key}
    this.selectParty(this.beneList2[0])
  },
  methods: {
    del () {
      if (this.beneList1.length === 1) return // 1건 남으면 삭제 불가
      for (let i = this.beneList1.length - 1; i >= 0; i--) {
        if (this.beneList1[i].chk) {
          this.beneList1.splice(i, 1)
        }
      }
    },
    add () {
      if (this.beneList1.length > 3) return // 4건 이상 추가 불가
      this.beneList1.push({
        chk: false,
        nameType: {'key': this.beneItems[0].key, 'label': this.beneItems[0].key},
        name: '',
        age: '',
        ssno1: '',
        ssno2: '',
        rat: '100',
        nat: {key: '내국인', label: '내국인'}
      })
      this.selectParty(this.beneList1[this.beneList1.length - 1])
    },
    selectParty (v) {
      let name = v.nameType.key
      for (let i = 0; i < this.partyList.length; i++) {
        if (this.partyList[i].name === name) {
          v.age = this.partyList[i].age
          v.ssno1 = this.partyList[i].ssno.substring(0, 6)
          v.ssno2 = this.partyList[i].ssno.substring(7, 14)
          v.nat = this.partyList[i].nation
          v.rat = '100'
        }
      }
      if (name === '직접입력') {
        v.age = ''
        v.ssno1 = ''
        v.ssno2 = ''
        v.nat = {'key': '내국인', 'label': '내국인'}
        v.rat = ''
      }
    }
  }
}
</script>
