<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="최근가입설계" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot -pub-popup-page__newPrt">
            <!-- 세대조정 Start -->
            <div class="-pub-popup__edit-new_prt">
                <div class="-pub-popup__content-body">
                        <div class="-pub-filter-menu__text">총 {{mockData.length}}건</div>
                        <!-- 페이지 조회 input, button 검색 영역 end -->
                        <fdp-infinite class="-pub-table" v-model="selectOrigin" single-select :items="mockData" :table-body-height="818" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">&nbsp;</th>
                                    <th class="-pub-table-column" style="width: 220px;">가입설계일</th>
                                    <th class="-pub-table-column" style="width: 794px;">설계명</th>
                                    <th class="-pub-table-column" style="width: 280px;">합계보험료(원)</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-radio class="-pub-radiobox -pub-radiobox--empty-label -pub-radiobox--purple" v-model="selectOrigin" :value="props.item"></fdp-radio>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 220px;">{{props.item.date}}</td>
                                <td class="-pub-table-column" style="width: 794px;">{{props.item.name}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 280px;">{{props.item.data}}</td>
                            </template>
                            <!-- no data 화면 -->
                            <template slot="emptyView">
                                <div class="empty-table-content" v-if="isEmptySearchKeywordOrigin">
                                    <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                </div>
            </div>
            <!--// 세대조정 end -->
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar -pub-bottom-bar__190p">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">삭제</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--confirm">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSPI900P.mock'

export default {
  data () {
    return {
      showPopup: true,
      vipGroupName: '',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      // mockData: [],
      mockDataOrigin: Array.prototype.slice.call(viewMemberMocks),
      mockAddMember: [],
      searchKeywordOrigin: '',
      searchKeywordOrigin2: '',
      isEmptySearchKeywordOrigin: true,
      selectOrigin: {},
      selectAddMember: {}
    }
  }
}
</script>
