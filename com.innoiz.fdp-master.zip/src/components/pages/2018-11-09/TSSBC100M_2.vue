<template>
    <header class="-pub-header" :class="[isToggle && !headerDisplay  ? '-pub-header--hide' : '', isToggle ? '-pub-header--toggle' : '' ]">
        <nav class="-pub-side-nav">
            <ul class="-pub-side-nav__menu">
                <li class="-pub-side-nav__item -pub-side-nav__item--home" tabindex="1" :class="[activeMenu === 1 ? '-pub-side-nav__item--active' : '']">
                    <a @click=" activeMenu === 1 ? (activeMenu = -1) : (activeMenu = 1)">
                        <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn_home_nor_2.png" />
                        <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn_home_sel_2.png" />
                    </a>
                </li>
                <!-- 신규 추가 메뉴, 연결 화면은 미정 107 line 과 같이 추가해주면 됨 2018.11.07 -->
                <li class="-pub-side-nav__item -pub-side-nav__item--home" tabindex="1" :class="[activeMenu === 7 ? '-pub-side-nav__item--active' : '']">
                    <a @click=" activeMenu === 7 ? (activeMenu = -7) : (activeMenu = 7)">
                        <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn_work_nor.png" />
                        <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn_work_sel.png" />
                    </a>
                </li>
                <li class="-pub-side-nav__item" tabindex="1" :class="[activeMenu === 2 ? '-pub-side-nav__item--active' : '']">
                    <a @click=" activeMenu === 2 ? (activeMenu = -1) : (activeMenu = 2)">고객</a>
                </li>
                <li class="-pub-side-nav__item" :class="[activeMenu === 5 ? '-pub-side-nav__item--active' : '']"
                    tabindex="1">
                    <a class="-pub-side-nav__trigger" @click=" activeMenu === 5 ? (activeMenu = -1) : (activeMenu = 5)">
                        활동
                    </a>
                </li>
                <li class="-pub-side-nav__item" tabindex="1" :class="[activeMenu === 3 ? '-pub-side-nav__item--active' : '']">
                    <a @click=" activeMenu === 3 ? (activeMenu = -1) : (activeMenu = 3)">컨설팅</a>
                </li>
                <li class="-pub-side-nav__item" tabindex="1" :class="[activeMenu === 4 ? '-pub-side-nav__item--active' : '']">
                    <a @click="activeMenu === 4 ? (activeMenu = -1) : (activeMenu = 4)">설계 청약</a>
                </li>
                <li class="-pub-side-nav__item" :class="[activeMenu === 6 ? '-pub-side-nav__item--active' : '']"
                    tabindex="1">
                    <a class="-pub-side-nav__trigger" @click=" activeMenu === 6 ? (activeMenu = -1) : (activeMenu = 6)">
                        <!--<img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-contract-nor.png" />
                        <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-contract-sel.png" />-->
                        계약
                    </a>
                    <div class="-pub-side-nav__sub-menu">
                        <div class="-pub-side-nav__sub-menu-wrap">
                            <div class="-pub-side-nav__sub-menu-col">
                                <ul class="-pub-side-nav__sub-menu-container">
                                    <li class="-pub-side-nav__sub-item -pub-side-nav__sub-item--active">계약관리</li>
                                    <li class="-pub-side-nav__sub-item">보유계약조회</li>
                                    <li class="-pub-side-nav__sub-item">계약상세조회</li>
                                    <li class="-pub-side-nav__sub-item">자동이체미이체</li>
                                    <li class="-pub-side-nav__sub-item">실효계약</li>
                                    <li class="-pub-side-nav__sub-item">휴먼보험금</li>
                                    <li class="-pub-side-nav__sub-item">우량체미계약변경</li>
                                    <li class="-pub-side-nav__sub-item">배당금안내</li>
                                    <li class="-pub-side-nav__sub-item">수금체크명세</li>
                                </ul>
                                <ul class="-pub-side-nav__sub-menu-container">
                                    <li class="-pub-side-nav__sub-item -pub-side-nav__sub-item--active">거래업무</li>
                                    <li class="-pub-side-nav__sub-item">보험거래</li>
                                    <li class="-pub-side-nav__sub-item">융자거래</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="-pub-side-nav__menu -pub-side-nav__menu--bottom">
                <li class="-pub-side-nav__item" tabindex="1">
                    <span class="-pub-side-nav__new-icon"></span>
                    <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-search-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-search-sel.png" />
                </li>
                <li class="-pub-side-nav__item -pub-side-nav__item--new" :class="[notice1 ? '-pub-side-nav__item--active' : '']"
                    tabindex="1" @click="notice1 = !notice1">
                    <span class="-pub-side-nav__new-icon"></span>
                    <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-alarm-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-alarm-sel.png" />
                </li>
                <!-- -pub-side-nav__item들중 -pub-side-nav__item--new 클래스를 추가하면 new icon이 보이게됨 -->
                <!--
                예제 마크업
                <li class="-pub-side-nav__item -pub-side-nav__item--new" tabindex="1">
                    <img class="-pub-side-nav__img" src="@/assets/img/components/btn-noti-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/components/btn-noti-sel.png" />
                    <img class="-pub-side-nav__new-icon" src="@/assets/img/components/new-badge.png"/>
                </li>
                -->
                <li class="-pub-side-nav__item" tabindex="1" @click="notice2 = !notice2" :class="[notice2 ? '-pub-side-nav__item--active' : '']">
                    <span class="-pub-side-nav__new-icon"></span>
                    <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-noti-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-noti-sel.png" />
                </li>
                <li class="-pub-side-nav__item" tabindex="1" @click="notice3 = !notice3" :class="[notice3 ? '-pub-side-nav__item--active' : '']">
                    <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-setting-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-setting-sel.png" />
                </li>
                <li class="-pub-side-nav__item" tabindex="1" @click="notice4 = !notice4" :class="[notice4 ? '-pub-side-nav__item--active' : '']">
                    <img class="-pub-side-nav__img" src="@/assets/img/side-nav/btn-open-nor.png" />
                    <img class="-pub-side-nav__img--active" src="@/assets/img/side-nav/btn-open-sel.png" />
                </li>
            </ul>
            <a class="-pub-side-nav__item -pub-side-nav__item--bottom -pub-sitemap-btn">
                <img src="@/assets/img/side-nav/btn-menu.png" alt="전체 메뉴" />
            </a>
            <TSSBC120M v-if="notice1" @close="closeNotice1"></TSSBC120M>
            <TSSBC150M v-if="notice2" @close="closeNotice2"></TSSBC150M>
            <TSSBC130M v-if="notice3" @close="closeNotice3"></TSSBC130M>
            <TSSBC140M v-if="notice4" @close="closeNotice4"></TSSBC140M>
            <TSSBC200M v-if="activeMenu === 1"></TSSBC200M>
        </nav>
        <a class="-pub-header__toggle-button" @click="headerDisplay = !headerDisplay">
            <img src="@/assets/img/side-nav/btn-drawer-menu.png" />
        </a>
    </header>
</template>
<script>
import TSSBC120M from '@/components/pages/2018-08-31/TSSBC120M'
import TSSBC150M from '@/components/pages/2018-09-14/TSSBC150M'
import TSSBC130M from '@/components/pages/2018-09-14/TSSBC130M'
import TSSBC140M from '@/components/pages/2018-10-19/TSSBC140M'
import TSSBC200M from '@/components/pages/2018-10-19/TSSBC200M'
export default {
  props: {
    isToggle: {
      type: Boolean,
      default: false
    },
    isShow: {
      type: Boolean,
      default: false
    }
  },
  components: {
    TSSBC120M,
    TSSBC150M,
    TSSBC130M,
    TSSBC140M,
    TSSBC200M
  },
  watch: {
    isShow (val) {
      this.headerDisplay = val
    }
  },
  data () {
    return {
      notice1: false,
      notice2: false,
      notice3: false,
      notice4: false,
      headerDisplay: true,
      submenu1: false,
      submenu2: false,
      activeMenu: -1
    }
  },
  methods: {
    closeNotice1 () {
      this.notice1 = false
    },
    closeNotice2 () {
      this.notice2 = false
    },
    closeNotice3 () {
      this.notice3 = false
    },
    closeNotice4 () {
      this.notice4 = false
    }
  },
  created () {
    this.headerDisplay = this.isShow
  }
}
</script>
