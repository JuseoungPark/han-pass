<template>
    <section class="-pub-activity -pub-visiblity">
        <div class="-pub-activity__month-income">
            <div class="-pub-page-header">
                <h3 class="-pub-page-header__title">당월소득예측</h3>
            </div>
            <!-- 영엽관리자용 조회 필터 -->
            <div class="-pub-search-fillter" v-show="isManager">
                <span class="-pub-filter-menu__label">조직</span>
                <fdp-select class="-pub-select" v-model="filterSelectValue01" placeholder="" :option-list="filterSelectItems01"></fdp-select>
                <fdp-select class="-pub-select" v-model="filterSelectValue02" placeholder="" :option-list="filterSelectItems02"></fdp-select>
                <fdp-select class="-pub-select" v-model="filterSelectValue03" placeholder="" :option-list="filterSelectItems03"></fdp-select>
                <span class="-pub-filter-menu__label -pub-filter-menu__label-consultant">컨설턴트</span>
                <fdp-select class="-pub-select -pub-select-consultant" v-model="filterSelectValue04" placeholder="전체" :option-list="filterSelectItems04"></fdp-select>
                <div class="-pub-button-area">
                    <button type="submit" class="-pub-button -pub-button--purple -pub-button--light" @click="search">조회</button>
                </div>
            </div>
            <!-- 영엽관리자용 조회 전 화면-->
            <div class="-pub-table-empty-view -pub-table-empty-view--touch" v-if="!isSearched && isManager">
                <div class="empty-table-content__text">컨설턴트를 선택하신 후 조회하세요</div>
            </div>
            <!-- 영엽관리자용 조회 이후 화면 및 기본 화면-->
            <div class="-pub-activity__month-income--detail" :item="memberData" v-else>
                <!-- 영엽관리자용 height-search / 기본 height-default -->
                <div class="-pub-member-info" :class="{ 'height-search' : isManager , 'height-default': !isManager }">
                    <div class="-pub-member-info__name">
                        <p class="name-text">{{memberData.name}}</p>
                        <p class="job-grade">{{memberData.grade}}</p>
                    </div>
                    <div class="-pub-member-info__detail">
                        <ul class="-pub-member-info__detail--list">
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">사업부</p>
                                <p class="detail-item-cont">{{memberData.division}}</p>
                            </li>
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">지역단</p>
                                <p class="detail-item-cont">{{memberData.area}}</p>
                            </li>
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">소속지점</p>
                                <p class="detail-item-cont">{{memberData.office}}</p>
                            </li>
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">팀</p>
                                <p class="detail-item-cont">{{memberData.team}}</p>
                            </li>
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">위촉차월</p>
                                <p class="detail-item-cont">{{memberData.entrusting}}</p>
                            </li>
                            <li class="-pub-member-info__detail--item">
                                <p class="detail-item-tit">이행보증</p>
                                <p class="detail-item-cont">{{memberData.guaranty}}</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- 영엽관리자용 height-search / 기본 height-default -->
                <div class="-pub-member-detail" :class="{ 'height-search' : isManager , 'height-default': !isManager }" ref="scroll">
                    <!-- 추가목표반영 start -->
                    <div class="-pub-member-detail__cont border-bottom" ref="upperDiv">
                        <div class="-pub-member-detail__cont--tit">
                            <h4 class="sub-tit-depth1">추가목표반영</h4>
                        </div>
                        <div class="-pub-member-detail__cont--view">
                            <div class="-pub-member-detail__cont--full">
                                <div class="-pub-member-detail__cont--full-tit">
                                    <h5 class="sub-tit-depth2">신계약 환산성적(TP)</h5>
                                </div>
                                <div class="-pub-member-detail__cont--full-table margin-bottom40">
                                    <!-- table start -->
                                    <template :item="tableData1">
                                        <table class="-pub-consulting-content__header">
                                            <colgroup>
                                                <col width="134px">
                                                <col width="290px">
                                                <col width="292px">
                                                <col width="292px">
                                                <col width="290px">
                                            </colgroup>
                                            <thead>
                                                <tr>
                                                    <th rowspan="2"></th>
                                                    <th rowspan="2" class="align-center left-padding2">현재(확정)</th>
                                                    <th colspan="2" class="align-center right-padding border-bottom">추가영업목표</th>
                                                    <th rowspan="2" class="align-center">예상(현재+추가)</th>
                                                </tr>
                                                <tr>
                                                    <th class="align-center right-padding border-right-none">가입설계</th>
                                                    <th class="align-center right-padding3">임의목표</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th class="align-left">{{tableData1.title1}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding2 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding3 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right normal-letter">{{tableData1.data1}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left">{{tableData1.title2}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding2 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding3 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right normal-letter">{{tableData1.data1}}</td>
                                                </tr>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th class="align-left">합계</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding2 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right right-padding3 normal-letter">{{tableData1.data1}}</td>
                                                    <td class="align-right normal-letter">{{tableData1.data1}}</td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </template>
                                    <!-- table end -->
                                </div>
                            </div>
                            <div class="-pub-member-detail__recruiting">
                                <div class="-pub-member-detail__cont--full-tit">
                                    <h5 class="sub-tit-depth2">리크루팅</h5>
                                </div>
                                <div class="-pub-member-detail__cont--full-table">
                                    <!-- table start -->
                                    <template :item="tableData2">
                                        <table class="-pub-consulting-content__header header-type2">
                                            <colgroup>
                                                <col width="280px">
                                                <col width="276px">
                                                <col width="277px">
                                            </colgroup>
                                            <thead>
                                                <tr>
                                                    <th class="align-center border-right">현재</th>
                                                    <th class="align-center border-right">추가(임의)</th>
                                                    <th class="align-center">합계</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="align-center border-right normal-letter">{{tableData2.data1}}</td>
                                                    <td class="align-center border-right normal-letter">{{tableData2.data2}}</td>
                                                    <td class="align-center normal-letter">{{tableData2.data3}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </template>
                                    <!-- table end -->
                                </div>
                            </div>
                            <div class="-pub-member-detail__contract">
                                <div class="-pub-member-detail__cont--full-tit">
                                    <h5 class="sub-tit-depth2">계약관리</h5>
                                </div>
                                <div class="-pub-member-detail__cont--full-table">
                                    <!-- 입금예정 start -->
                                    <span class="-pub-member-detail__cont--item">입금예정</span>
                                    <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="filter" :data="filters"></fdp-segment-box>
                                    <!-- 입금예정 end -->
                                </div>
                            </div>
                        </div>
                        <div class="-pub-button-area">
                            <button type="submit" class="-pub-button -pub-button--purple -pub-button--light">
                                가입설계 대상확정</button><button type="submit" class="-pub-button -pub-button--purple -pub-button--light">
                                임의목표 입력</button><button type="submit" class="-pub-button -pub-button--purple -pub-button--light">
                                입금예정 대상확정</button>
                                <button type="submit" class="-pub-button position-right -pub-button--reverse -pub-button--purple -pub-button--light" @click="simulation">
                                시뮬레이션</button>
                        </div>
                    </div>
                    <!-- 추가목표반영 end -->
                    <!-- 주요 Factor start -->
                    <div class="-pub-member-detail__cont">
                        <div class="-pub-member-detail__cont--tit">
                            <h4 class="sub-tit-depth1">주요 Factor</h4>
                        </div>
                        <div class="-pub-member-detail__cont--view">
                            <div class="-pub-member-detail__cont--full">
                                <div class="-pub-member-detail__cont--full-table">
                                    <!-- table start -->
                                    <template :item="tableData3">
                                        <table class="-pub-consulting-content__header header-type3">
                                            <colgroup>
                                                <col width="240px">
                                                <col width="548px">
                                                <col width="546px">
                                            </colgroup>
                                            <thead>
                                                <tr>
                                                    <th class="align-center border-right"></th>
                                                    <th class="align-center center-padding">현재</th>
                                                    <th class="align-center right-padding">추가반영</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData3.title1}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData3.data1}}</td>
                                                    <td class="align-right normal-letter">{{tableData3.data2}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData3.title2}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData3.data3}}</td>
                                                    <td class="align-right normal-letter">{{tableData3.data4}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData3.title3}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData3.data5}}</td>
                                                    <td class="align-right normal-letter">{{tableData3.data6}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData3.title4}}</th>
                                                    <td class="align-right right-padding normal-letter">{{tableData3.data7}}</td>
                                                    <td class="align-right normal-letter">{{tableData3.data8}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </template>
                                    <!-- table end -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 주요 Factor end -->
                    <!-- 예상수수료 start -->
                    <div class="-pub-member-detail__cont">
                        <div class="-pub-member-detail__cont--tit">
                            <h4 class="sub-tit-depth1">예상수수료</h4>
                        </div>
                        <div class="-pub-member-detail__cont--view">
                            <div class="-pub-member-detail__cont--full">
                                <div class="-pub-member-detail__cont--full-table">
                                    <!-- table start -->
                                    <template :item="tableData4">
                                        <table class="-pub-consulting-content__header header-type4">
                                            <colgroup>
                                                <col width="254px">
                                                <col width="302px">
                                                <col width="296px">
                                                <col width="256px">
                                                <col width="298px">
                                            </colgroup>
                                            <thead>
                                                <tr>
                                                    <th class="align-center border-right"></th>
                                                    <th class="align-center border-right"></th>
                                                    <th class="align-center">현재</th>
                                                    <th class="align-center">추가</th>
                                                    <th class="align-center">예상(현재+추가)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData4.title1}}</th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle1}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data11}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data12}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data13}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right"></th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle2}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data21}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data22}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data23}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right"></th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle3}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data31}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data32}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data33}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right">{{tableData4.title2}}</th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle4}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data41}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data42}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data43}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right"></th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle5}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data51}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data52}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data53}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right"></th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle6}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data61}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data62}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data63}}</td>
                                                </tr>
                                                <tr>
                                                    <th class="align-left border-right"></th>
                                                    <td class="align-left subTitle left-padding border-right">{{tableData4.subTitle7}}</td>
                                                    <td class="align-right normal-letter">{{tableData4.data71}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data72}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data73}}</td>
                                                </tr>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th class="align-left border-right" colspan="2">합계</th>
                                                    <td class="align-right normal-letter">{{tableData4.data81}}</td>
                                                    <td class="align-right right-padding-none normal-letter">{{tableData4.data82}}</td>
                                                    <td class="align-right right-padding-last normal-letter">{{tableData4.data83}}</td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </template>
                                    <!-- table end -->
                                </div>
                            </div>
                        </div>
                        <div class="-pub-activity-dec">
                            <ul class="-pub-activity-dec__list">
                                <li class="-pub-activity-dec__list--item">※ 리크루팅 보너스는 신팀장수수료 감안없이 일반 리크루팅 보너스로 예측함</li>
                                <li class="-pub-activity-dec__list--item">※ 산출 결과는 소득 예측을 위한 참고용이며, 실제 지급되는 수수료와 차이가 있을 수 있음</li>
                            </ul>
                        </div>
                    </div>
                    <!-- 예상수수료 end -->
                </div>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  data () {
    return {
      isSearched: false,
      filterSelectValue01: {
        key: '1',
        label: '사업단'
      },
      filterSelectItems01: [{
        key: '1',
        label: '사업단'
      },
      {
        key: '2',
        label: '사업단2'
      }
      ],
      filterSelectValue02: {
        key: '1',
        label: '강서사업단'
      },
      filterSelectItems02: [{
        key: '1',
        label: '강서사업단'
      },
      {
        key: '2',
        label: '강서사업단2'
      }
      ],
      filterSelectValue03: {
        key: '1',
        label: '목동타워지점'
      },
      filterSelectItems03: [{
        key: '1',
        label: '목동타워지점'
      },
      {
        key: '2',
        label: '목동타워지점2'
      }
      ],
      filterSelectValue04: {
        key: '1',
        label: '김삼성성(0001364571)'
      },
      filterSelectItems04: [{
        key: '1',
        label: '김삼성성(0001364571)'
      },
      {
        key: '2',
        label: '김삼성성(0001364571)2'
      }
      ],
      memberData: {
        name: '김삼성성 FC',
        grade: '프로',
        division: '강남',
        area: '테헤란로',
        office: '삼성',
        team: '2',
        entrusting: 'BD',
        guaranty: 'Y'
      },
      tableData1: {
        title1: '보장환산',
        title2: '금융환산',
        data1: '1,540,000,000'
      },
      tableData2: {
        data1: '11',
        data2: '99',
        data3: '99'
      },
      tableData3: {
        title1: '유효성적2',
        title2: '유지율 (2~13회)',
        title3: '유지율(2~19회)',
        title4: '리쿠르팅 35만 이상',
        data1: '1,000,000,000',
        data2: '1,000,000,000',
        data3: '98%',
        data4: '92%',
        data5: '92%',
        data6: '92%',
        data7: '0',
        data8: '0'
      },
      tableData4: {
        title1: '비례',
        title2: '비비례 성과',
        subTitle1: '신계약(조회분)',
        subTitle2: '신계약(분급분)',
        subTitle3: '계약관리(유지)',
        subTitle4: '생산보너스',
        subTitle5: '정예화보너스',
        subTitle6: '리크루팅',
        subTitle7: '신인수수료',
        data11: '1,000,000,000',
        data12: '1,000,000,000',
        data13: '1,000,000,000',
        data21: '0',
        data22: '0',
        data23: '0',
        data31: '1,000,000,000',
        data32: '1,000,000,000',
        data33: '1,000,000,000',
        data41: '1,000,000,000',
        data42: '1,000,000,000',
        data43: '1,000,000,000',
        data51: '0',
        data52: '0',
        data53: '0',
        data61: '1,000,000,000',
        data62: '1,000,000,000',
        data63: '1,000,000,000',
        data71: '1,000,000,000',
        data72: '1,000,000,000',
        data73: '1,000,000,000',
        data81: '1,000,000,000',
        data82: '1,000,000,000',
        data83: '1,000,000,000'
      },
      filter: [{
        key: '1',
        label: '반영'
      }],
      filters: [{
        key: '1',
        label: '반영'
      },
      {
        key: '2',
        label: '미반영'
      }
      ],
      isManager: false // 관리자 접속 여부,
    }
  },
  methods: {
    simulation () {
      this.$refs.scroll.scrollTop = this.$refs.upperDiv.scrollHeight + 38 // 상단 길이 + top margin
    },
    search () {
      // 검색로직
      this.isSearched = true
    }
  }
}
</script>
