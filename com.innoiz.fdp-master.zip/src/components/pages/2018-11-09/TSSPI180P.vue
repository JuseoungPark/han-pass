<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="단체명입력" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--team">
            <div class="-pub-popup__content--team-title">
                <label>단체명</label>
                <fdp-validator name="tsspi180p-validator-1" display-name="단체명" v-model="teamname" :rules="'required'">
                    <fdp-text-field class="-pub-input--purple -pub-input-term" v-model="teamname" placeholder="입력하세요"></fdp-text-field>
                </fdp-validator>
            </div>
            <div class="-pub-popup__button-area">
                <button type="button" class="-pub-button -pub-button--purple -pub-button--180">
                    <span class="-pub-button__text">취소</span>
                </button><button type="button" class="-pub-button -pub-button--purple -pub-button--180 -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      teamname: ''
    }
  }
}
</script>
