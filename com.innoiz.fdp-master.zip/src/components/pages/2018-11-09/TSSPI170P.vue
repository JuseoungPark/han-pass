<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="제안대상 선택" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--offer">
            <p class="-pub-popup__content--offer-txt">아래 예시와 같이 상품명 앞에 추가기재가 가능합니다.<br>제안대상을 선택 해 주시기 바랍니다.<br>예) 직장인을 위한 삼성생명 비즈니스연금보험1.4(무배당)</p>
            <div class="-pub-popup__content--offer-list">
                <fdp-validator name="tsspi170p-validator-1" v-model="radioSelected.key" :rules="'required'">
                    <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected" value="1">직장인을 위한</fdp-radio>
                    <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected" value="2">CEO를 위한</fdp-radio>
                    <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected" value="3">기본상품명 (추가기재 없음)</fdp-radio>
                </fdp-validator>
            </div>
            <!-- 상단에 라디오 버튼 선택 하면 확인 버튼 disabled 삭제 -->
            <div class="-pub-popup__button-area">
                <button type="button" class="-pub-button -pub-button--purple -pub-button--180">
                    <span class="-pub-button__text">취소</span>
                </button><button type="button" class="-pub-button -pub-button--purple -pub-button--180 -pub-button--reverse" :disabled="radioSelected==''">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      radioSelected: ''
    }
  }
}
</script>
