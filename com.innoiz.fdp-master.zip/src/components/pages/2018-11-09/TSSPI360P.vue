<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="합계보험료 설계" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup-pi360p">
                <div>
                    <dl class="-pub-guidance">
                        <dt>보험료 설계 안내</dt>
                        <dd>
                            현재 설계하신 조건으로 납입가능한 합계보험료 범위는<br>
                            1,800원 ~ 2,500원 입니다.<br>
                            (만기환급률 0%~100%[단, 15년만기 및 20년만기는 80%] 이내, 10원단위)<br><br>

                            단, 적립계약 보험료는 1,000원 이상이어야 합니다.<br>
                            1,000원 이상 설계불가능시 보장계약 및 특약을 재설계하거나, 납입가능한 최소 합계보험료(1,800원,적립계약 [미포함]과 동일)를 입력하시기 바랍니다.
                        </dd>
                    </dl>
                    <div class="-pub-input-row">
                        <span class="-pub-text-1">합계보험료 입력</span>
                        <fdp-validator name="tsspi360p-validator-1" v-model="totalpremiums" display-name="합계보험료" :rules="'required'">
                            <fdp-text-field class="-pub-text-field--purple" v-model="totalpremiums" virtual></fdp-text-field>
                        </fdp-validator>
                        <span class="-pub-unit">원</span>
                        <button type="button" class="-pub-button" @click="input">입력</button>
                    </div>
                    <div class="-pub-text-box-1">
                        <div class="-pub-box-row">
                            <label class="-pub-tit">보장계약</label>
                            <span class="-pub-desc">{{prem1}} 원</span>
                        </div>
                        <div class="-pub-box-row">
                            <label class="-pub-tit">적립계약</label>
                            <span class="-pub-desc">{{prem2}} 원</span>
                        </div>
                        <div class="-pub-box-row">
                            <label class="-pub-tit">납면계약</label>
                            <span class="-pub-desc">{{prem3}} 원</span>
                        </div>
                        <div class="-pub-box-row">
                            <label class="-pub-tit">특약보험료(계)</label>
                            <span class="-pub-desc">{{prem4}} 원</span>
                        </div>
                        <div class="-pub-box-row">
                            <label class="-pub-tit">만기환급률</label>
                            <span class="-pub-desc">{{rat1}}%</span>
                        </div>
                    </div>
                    <span class="-pub-text-2">※ 보험가입 이후 공시이율 및 갱신보험료 변동 등으로 인하여, 만기환급률은 예상치와 달라질 수 있습니다.</span>
                </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
                <div class="-pub-bottom-nav">
                    <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                        <button type="button" class="-pub-button -pub-button--purple">취소</button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                    </div>
                </div>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
        </fdp-popup>
    </template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      totalpremiums: '',
      prem1: '0',
      prem2: '0',
      prem3: '0',
      prem4: '0',
      rat1: 0
    }
  },
  methods: {
    input () {
      this.prem1 = '1,888,000'
      this.prem2 = '1,888,000'
      this.prem3 = '1,888,000'
      this.prem4 = '1,888,000'
      this.rat1 = 20
    }
  }
}
</script>
