<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="연금지급형태" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 케이스별 보여 주기 링크 테스트 : 추후 삭제 바랍니다-->
            <div class="-pub-case-test">
              <span>CASE TEST</span>
              <ul>
                  <li @click="chg(1)">1</li>
                  <li @click="chg(2)">2</li>
                  <li @click="chg(3)">3</li>
                  <li @click="chg(4)">4</li>
                  <li @click="chg(5)">5</li>
              </ul>
            </div>
            <!-- -->
            <div class="-pub-popup__content -pub-popup-annuityGive">
                <!-- 연금지급형태 start -->
                <div class="-pub-popup-annuityGive__type" v-if="isFirst">
                    <div class="-pub-popup-annuityGive__type01">
                        <span class="-pub-popup-annuityGive__type01--label">연금지급형태</span>
                        <fdp-validator name="validator" v-model="filterSelectValue1" :rules="'required'">
                            <fdp-select class="-pub-select" v-model="filterSelectValue1" placeholder="선택하세요" :option-list="filterSelectItems1"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__dec">
                        ※ 5년납 이상이고 인당 합산 월납보험료가15만원 이하인 경우, 10년이상 유지시 비과세됩니다.<br>
                        단, 5년납 미만 또는 인당 합산 월납보험료가150만원을 초과하는 경우, 계약자가 가입한 ‘관련세법에서<br>
                        정하는 계약’과 이 계약의 합산 보험료가 1억원을 초과시에는 <span class="point">23년 이내</span> 보증지급기간만<br>
                        「종신형연금보험계약」에 해당하여 비과세됩니다.<br>
                        (자세한 사항은 소득세법시행령 제25조 및 상품설명서 참조)
                    </div>
                </div>
                <!-- 연금지급형태 end -->
                 <!-- 연금지급형태 - 안내문구 없는 버젼 start -->
                 <div class="-pub-popup-annuityGive__type" v-if="isSecond">
                    <div class="-pub-popup-annuityGive__type01">
                        <span class="-pub-popup-annuityGive__type01--label">연금지급형태</span>
                        <!-- case01 -->
                        <fdp-validator name="validator" v-model="filterSelectValue2" :rules="'required'" v-if="true">
                            <fdp-select class="-pub-select" v-model="filterSelectValue2" placeholder="선택하세요" :option-list="filterSelectItems2"></fdp-select>
                        </fdp-validator>
                        <!-- case02 -->
                        <fdp-validator name="validator" v-model="filterSelectValue22" :rules="'required'" v-if="false">
                            <fdp-select class="-pub-select" v-model="filterSelectValue22" placeholder="선택하세요" :option-list="filterSelectItems22"></fdp-select>
                        </fdp-validator>
                        <!-- case03 -->
                        <fdp-validator name="validator" v-model="filterSelectValue23" :rules="'required'" v-if="false">
                            <fdp-select class="-pub-select" v-model="filterSelectValue23" placeholder="선택하세요" :option-list="filterSelectItems23"></fdp-select>
                        </fdp-validator>
                    </div>
                </div>
                <!-- 연금지급형태 - 안내문구 없는 버젼 end -->
                <!-- 연금지급형태(실적배당형연금 연금전환) start -->
                <div class="-pub-popup-annuityGive__type" v-if="isThird">
                    <div class="-pub-popup-annuityGive__type02">
                        <span class="-pub-popup-annuityGive__type02--label">연금지급형태</span>
                        <fdp-validator name="validator" v-model="filterSelectValue1" :rules="'required'">
                            <fdp-select class="-pub-select" v-model="filterSelectValue1" placeholder="선택하세요" :option-list="filterSelectItems1"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__type02 -pub-margin-bottom">
                        <span class="-pub-popup-annuityGive__type02--label">실적배당형 연금전환 예시선택</span>
                        <fdp-validator name="validator" v-model="filterSelectValue3" :rules="'required'">
                            <fdp-select class="-pub-select" v-model="filterSelectValue3" placeholder="선택하세요" :option-list="filterSelectItems3"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__dec">
                        ※ 5년납 이상이고 인당 합산 월납보험료가15만원 이하인 경우, 10년이상 유지시 비과세됩니다.<br>
                        단, 5년납 미만 또는 인당 합산 월납보험료가150만원을 초과하는 경우, 계약자가 가입한 ‘관련세법에서<br>
                        정하는 계약’과 이 계약의 합산 보험료가 1억원을 초과시에는 <span class="point">23년 이내</span> 보증지급기간만<br>
                        「종신형연금보험계약」에 해당하여 비과세됩니다.<br>
                        (자세한 사항은 소득세법시행령 제25조 및 상품설명서 참조)
                    </div>
                </div>
                <!-- 연금지급형태(실적배당형연금 연금전환) end -->
                <!-- 연금지급형태(연생) start -->
                <div class="-pub-popup-annuityGive__type" v-if="isFourth">
                    <div class="-pub-popup-annuityGive__type03">
                        <span class="-pub-popup-annuityGive__type03--label">연금지급형태</span>
                        <fdp-validator name="validator" v-model="filterSelectValue4" :rules="'required'">
                            <fdp-select class="-pub-select" v-model="filterSelectValue4" placeholder="선택하세요" :option-list="filterSelectItems4"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__type03">
                        <span class="-pub-popup-annuityGive__type03--label -pub-padding-top4">보증지급기간</span>
                        <fdp-validator name="validator" v-model="filterSelectValue5" :rules="'required'">
                            <fdp-select class="-pub-select -pub-normal-letter" v-model="filterSelectValue5" placeholder="선택하세요" :option-list="filterSelectItems5"></fdp-select>
                        </fdp-validator><span class="percent">100%</span>
                    </div>
                </div>
                <!-- 연금지급형태(연생) end -->
                <!-- 연금지급형태(브릿지연금형) start -->
                <div class="-pub-popup-annuityGive__type" v-if="isFifth">
                    <div class="-pub-popup-annuityGive__type04">
                        <span class="-pub-popup-annuityGive__type04--label">연금지급형태</span>
                        <fdp-validator name="validator" v-model="filterSelectValue6" :rules="'required'">
                            <fdp-select class="-pub-select" v-model="filterSelectValue6" placeholder="선택하세요" :option-list="filterSelectItems6"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__type04">
                        <span class="-pub-popup-annuityGive__type04--label -pub-padding-top4">보증지급기간</span>
                        <fdp-validator name="validator" v-model="filterSelectValue7" :rules="'required'">
                            <fdp-select class="-pub-select -pub-normal-letter" v-model="filterSelectValue7" placeholder="선택하세요" :option-list="filterSelectItems7"></fdp-select>
                        </fdp-validator><span class="percent">100%</span>
                    </div>
                    <div class="-pub-popup-annuityGive__type04 -pub-border-top">
                        <span class="-pub-popup-annuityGive__type04--label">브릿지기간</span>
                        <fdp-validator name="validator" v-model="filterSelectValue8" :rules="'required'">
                            <fdp-select class="-pub-select -pub-normal-letter" v-model="filterSelectValue8" placeholder="선택하세요" :option-list="filterSelectItems8"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__type04">
                        <span class="-pub-popup-annuityGive__type04--label -pub-padding-top4">집중배수</span>
                        <fdp-validator name="validator" v-model="filterSelectValue9" :rules="'required'">
                            <fdp-select class="-pub-select -pub-normal-letter" v-model="filterSelectValue9" placeholder="선택하세요" :option-list="filterSelectItems9"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-popup-annuityGive__dec -pub-margin-top">
                        <dl class="-pub-popup-annuityGive__dec--list">
                            <dt class="-pub-popup-annuityGive__dec--list-tit">[상속연금형의 경우]</dt>
                            <dd class="-pub-popup-annuityGive__dec--list-item">
                                - 인당 합산보험료 1억 초과인 경우에는 과세됩니다.
                            </dd>
                        </dl>
                        <dl class="-pub-popup-annuityGive__dec--list">
                            <dt class="-pub-popup-annuityGive__dec--list-tit">[확정기간연금형의 경우]</dt>
                            <dd class="-pub-popup-annuityGive__dec--list-item">
                                - 보험료 수준에 관계없이 과세됩니다.
                            </dd>
                        </dl>
                        <dl class="-pub-popup-annuityGive__dec--list">
                            <dt class="-pub-popup-annuityGive__dec--list-tit">[종신연금형의 경우]</dt>
                            <dd class="-pub-popup-annuityGive__dec--list-item">
                                - 인당 합산보험료 1억 이하인 경우에는 비과세되나, 인당 합산보험료 1억 초과시에는 <span class="point">46년 이내</span><br>
                                <span class="-pub-left-padding">보증지급기간만「종신형연금보험계약」요건에 충족되어 비과세될 수 있습니다. 단, 브릿지연금형 선택시</span><br>
                                <span class="-pub-left-padding">브릿지횟수와 집중배수 선택에 따라 과세될 수 있습니다.</span>
                            </dd>
                        </dl>
                        ※ 인당 합산보험료: 계약자가 가입한 전체 금융기관의 보험/공제계약 중 관련세법에서 정하는 계약과 이<br>
                        보험의 합산 보험료 기준
                    </div>
                </div>
               <!-- 연금지급형태(브릿지연금형) end -->
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
                <div class="-pub-bottom-nav">
                    <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                        <button type="button" class="-pub-button -pub-button--purple">취소</button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                    </div>
                </div>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
        </fdp-popup>
    </template>
<script>
export default {
  data () {
    return {
      isFirst: true,
      isSecond: false,
      isThird: false,
      isFourth: false,
      isFifth: false,
      showPopup: true,
      filterSelectValue1: {
        key: '',
        label: ''
      },
      filterSelectValue2: {
        key: '',
        label: ''
      },
      filterSelectValue22: {
        key: '',
        label: ''
      },
      filterSelectValue23: {
        key: '',
        label: ''
      },
      filterSelectValue3: {
        key: '',
        label: ''
      },
      filterSelectValue4: {
        key: '',
        label: ''
      },
      filterSelectValue5: {
        key: '',
        label: ''
      },
      filterSelectValue6: {
        key: '',
        label: ''
      },
      filterSelectValue7: {
        key: '',
        label: ''
      },
      filterSelectValue8: {
        key: '',
        label: ''
      },
      filterSelectValue9: {
        key: '',
        label: ''
      },
      filterSelectItems1: [{
        key: '1',
        label: '종신형 10회'
      },
      {
        key: '2',
        label: '종신형 11회'
      },
      {
        key: '3',
        label: '종신형 12회'
      },
      {
        key: '4',
        label: '종신형 13회'
      },
      {
        key: '4',
        label: '종신형 14회'
      }],
      filterSelectItems2: [{
        key: '1',
        label: '종신형 10년'
      },
      {
        key: '2',
        label: '종신형 20년'
      },
      {
        key: '3',
        label: '종신형 30년'
      },
      {
        key: '4',
        label: '종신형 100세'
      }],
      filterSelectItems22: [{
        key: '1',
        label: '실적배당종신연금'
      }],
      filterSelectItems23: [{
        key: '1',
        label: '종신형 10회'
      },
      {
        key: '2',
        label: '종신형 11회'
      },
      {
        key: '3',
        label: '종신형 12회'
      },
      {
        key: '4',
        label: '종신형 13회'
      },
      {
        key: '4',
        label: '종신형 14회'
      }],
      filterSelectItems3: [{
        key: '1',
        label: '실적배당형 연금(최대100세 지급)'
      },
      {
        key: '2',
        label: '실적배당형 종신연금(종신 지급)'
      }],
      filterSelectItems4: [{
        key: '1',
        label: '종신연생 20%'
      },
      {
        key: '2',
        label: '종신연생 60%'
      },
      {
        key: '3',
        label: '종신연생 70%'
      },
      {
        key: '4',
        label: '종신연생 100%'
      }],
      filterSelectItems5: [{
        key: '1',
        label: '10회'
      },
      {
        key: '2',
        label: '11회'
      },
      {
        key: '3',
        label: '12회'
      },
      {
        key: '4',
        label: '13회'
      }],
      filterSelectItems6: [{
        key: '1',
        label: '종신형'
      },
      {
        key: '2',
        label: '종신브릿지형'
      }],
      filterSelectItems7: [{
        key: '1',
        label: '10년'
      },
      {
        key: '2',
        label: '11년'
      },
      {
        key: '3',
        label: '12년'
      },
      {
        key: '4',
        label: '13년'
      }],
      filterSelectItems8: [{
        key: '1',
        label: '5년'
      },
      {
        key: '2',
        label: '6년'
      },
      {
        key: '3',
        label: '7년'
      },
      {
        key: '4',
        label: '8년'
      }],
      filterSelectItems9: [{
        key: '1',
        label: '2배'
      },
      {
        key: '2',
        label: '3배'
      },
      {
        key: '3',
        label: '4배'
      },
      {
        key: '4',
        label: '5배'
      }]
    }
  },
  methods: {
    chg (v) {
      this.isFirst = false
      this.isSecond = false
      this.isThird = false
      this.isFourth = false
      this.isFifth = false
      switch (v) {
        case 1:
          this.isFirst = true
          break
        case 2:
          this.isSecond = true
          break
        case 3:
          this.isThird = true
          break
        case 4:
          this.isFourth = true
          break
        case 5:
          this.isFifth = true
          break
      }
    }
  }
}
</script>
