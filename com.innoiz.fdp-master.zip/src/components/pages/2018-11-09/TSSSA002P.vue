<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="My 세일즈북 추가" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup-activity">
                <div class="-pub-popup-activity__mySalesBookAdd" ref="newGroupWindow">
                    <div class="-pub-confirm__content">
                        <div class="-pub-confirm__desc">
                            <span>
                                자료를 선택한 그룹에 스크랩합니다.
                            </span>
                        </div>
                        <!-- 그룹 추가 -->
                        <div class="-pup-group" ref="scroll">
                            <div class="-pup-group__list">
                                <ul>
                                    <li v-for="group in groupList" :key = group.idx
                                    :class="currentGrpIdx === group.idx ? '-pup-group__list--item on' : '-pup-group__list--item'"
                                    @click="groupClick(group.idx)">
                                    <span>{{group.groupName}}</span></li>
                                </ul>
                                <div class="-pup-group__add-account">
                                    <div class="-pub-account-info">
                                        <!-- 그룹 추가 입력 폼 -->
                                        <div v-if="newGroupReq === true" class="-pub-group-account-form" >
                                            <span class="-pup-group-form__title">새로운 그룹 추가</span>
                                            <button type="button" class="-pub__button--close" @click="closeNewGroupReq">
                                                <img src="@/assets/img/components/btn_close_light.png" alt="close">
                                            </button>
                                            <ul>
                                                <fdp-form-wrapper scope="regist" @validate-all="validateBeforeSubmit">
                                                    <li class="-pub-create-account-form__item">
                                                        <label>스크랩명</label>
                                                        <fdp-validator name="name" v-model="name" :rules="'required'" scope="regist">
                                                            <fdp-text-field v-model="name" placeholder="입력하세요"></fdp-text-field>
                                                        </fdp-validator>
                                                    </li>
                                                    <li class="-pub-create-account-form__item">
                                                        <button type="submit" class="-pub-button -pub-button--purple -pub-button--confirm">
                                                            <span class="-pub-button__text">확인</span>
                                                        </button>
                                                    </li>
                                                </fdp-form-wrapper>
                                            </ul>
                                        </div>
                                        <!--// 그룹 추가 입력 폼 end -->
                                    </div>
                                    <button type="button" v-if="newGroupReq === false" class="-pub-button -pub-button__add-account" @click="clickNewGroupReq">
                                        <span>새로운 그룹 추가</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <!--// 그룹 추가 end -->
                    </div>
                </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      name: '',
      groupList: [
        {
          groupName: '그룹 1',
          idx: 1
        },
        {
          groupName: '그룹 2',
          idx: 2
        },
        {
          groupName: '그룹 3',
          idx: 3
        }
      ],
      currentGrpIdx: 1,
      newGroupReq: false
    }
  },
  methods: {
    groupClick (idx) { // 현재 선택된 그룹 index 변경
      this.currentGrpIdx = idx
    },
    clickNewGroupReq () { // 새로운 그룹 추가 버튼 클릭
      this.newGroupReq = true

      // this.newGroupReq이 true 된 후(그룹 추가 창이 열린 이후) 아래 코드 수행됨
      this.$nextTick(() => {
        var element = this.$refs.newGroupWindow
        // var top = element.offsetTop // 특정 ref의 y축 위쪽 위치 정보
        var top = element.clientHeight
        // this.$refs.scroll.scrollTop = top
        element.scrollTop = top
      })
    },
    closeNewGroupReq () { // 새로운 그룹 추가 창 닫기
      this.newGroupReq = false
      this.name = ''
    },
    addNewGoup () {
      let newGroup = {
        groupName: this.name,
        idx: this.groupList.length + 1
      }

      this.groupList.push(newGroup)

      this.currentGrpIdx = newGroup.idx
      this.newGroupReq = false
      this.name = ''
    },
    validateBeforeSubmit (result) {
      if (result) {
        this.addNewGoup()
      }
    }
  }
}
</script>
