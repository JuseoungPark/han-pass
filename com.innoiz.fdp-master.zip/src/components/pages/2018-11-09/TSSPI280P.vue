<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="할증지수조회" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__product">
        <div class="-pub-popup__content -pub-popup__content--extracharge">
            <div class="-pub-popup__content--extracharge-wrap" :class="isVirtual?'-pub-popup__content--extracharge-wrap-imagine':''">
                <div class="-pub-popup__content--extracharge-title">
                    <h2>주피보험자</h2>
                    <div class="extra"  v-if="!isVirtual">할증</div>
                </div>
                <div class="-pub-popup__content--extracharge-box">
                    <div class="-pub-popup__content--extracharge-box-inner">
                        <strong class="tit">사망</strong>
                        <div class="num" :class="formInput.input1>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input1}}</span>
                            <fdp-validator name="tsspi170p-validator-1" display-name="사망" v-model="formInput.input1" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input1" ></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">CI</strong>
                        <div class="num" :class="formInput.input2>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input2}}</span>
                            <fdp-validator name="tsspi170p-validator-2" display-name="CI" v-model="formInput.input2" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input2"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">LTC</strong>
                        <div class="num" :class="formInput.input3>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input3}}</span>
                            <fdp-validator name="tsspi170p-validator-3" display-name="LTC" v-model="formInput.input3" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input3"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">종합입원</strong>
                        <div class="num" :class="formInput.input4>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input4}}</span>
                            <fdp-validator name="tsspi170p-validator-4" display-name="종합입원" v-model="formInput.input4" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input4"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">질병입원</strong>
                        <div class="num" :class="formInput.input5>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input5}}</span>
                            <fdp-validator name="tsspi170p-validator-5" display-name="질병입원" v-model="formInput.input5" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input5"></fdp-text-field>
                            </fdp-validator>
                        </div>
                    </div>
                    <div class="-pub-popup__content--extracharge-box-inner">
                        <strong class="tit">입원</strong>
                        <div class="num" :class="formInput.input6>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input6}}</span>
                            <fdp-validator name="tsspi170p-validator-6" display-name="입원" v-model="formInput.input6" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input6"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">고도장해</strong>
                        <div class="num" :class="formInput.input7>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input7}}</span>
                            <fdp-validator name="tsspi170p-validator-7" display-name="고도장해" v-model="formInput.input7" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input7"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">뇌출혈</strong>
                        <div class="num" :class="formInput.input8>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input8}}</span>
                            <fdp-validator name="tsspi170p-validator-8" display-name="뇌출혈" v-model="formInput.input8" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input8"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">심근경색</strong>
                        <div class="num" :class="formInput.input9>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input9}}</span>
                            <fdp-validator name="tsspi170p-validator-9" display-name="심근경색" v-model="formInput.input9" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input9"></fdp-text-field>
                            </fdp-validator>
                        </div>
                    </div>
                </div>
                <div class="-pub-popup__content--extracharge-title">
                    <h2>종피보험자</h2>
                </div>
                <div class="-pub-popup__content--extracharge-box">
                    <div class="-pub-popup__content--extracharge-box-inner">
                        <strong class="tit">사망</strong>
                        <div class="num" :class="formInput.input10>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input10}}</span>
                            <fdp-validator name="tsspi170p-validator-10" display-name="사망" v-model="formInput.input10" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input10"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">CI</strong>
                        <div class="num" :class="formInput.input11>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input11}}</span>
                            <fdp-validator name="tsspi170p-validator-11" display-name="CI" v-model="formInput.input11" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input11"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">LTC</strong>
                        <div class="num" :class="formInput.input12>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input12}}</span>
                            <fdp-validator name="tsspi170p-validator-12" display-name="LTC" v-model="formInput.input12" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input12"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">종합입원</strong>
                        <div class="num" :class="formInput.input13>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input13}}</span>
                            <fdp-validator name="tsspi170p-validator-13" display-name="종합입원" v-model="formInput.input13" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input13"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">질병입원</strong>
                        <div class="num" :class="formInput.input14>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input14}}</span>
                            <fdp-validator name="tsspi170p-validator-14" display-name="질병입원" v-model="formInput.input14" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input14"></fdp-text-field>
                            </fdp-validator>
                        </div>
                    </div>
                    <div class="-pub-popup__content--extracharge-box-inner">
                        <strong class="tit">입원</strong>
                        <div class="num" :class="formInput.input15>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input15}}</span>
                            <fdp-validator name="tsspi170p-validator-15" display-name="입원" v-model="formInput.input15" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input15"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">고도장해</strong>
                        <div class="num" :class="formInput.input16>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input16}}</span>
                            <fdp-validator name="tsspi170p-validator-16" display-name="고도장해" v-model="formInput.input16" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input16"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">뇌출혈</strong>
                        <div class="num" :class="formInput.input17>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input17}}</span>
                            <fdp-validator name="tsspi170p-validator-17" display-name="뇌출혈" v-model="formInput.input17" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input17"></fdp-text-field>
                            </fdp-validator>
                        </div>
                        <strong class="tit">심근경색</strong>
                        <div class="num" :class="formInput.input18>=150?'extra':''">
                            <span v-if="!isVirtual">{{formInput.input18}}</span>
                            <fdp-validator name="tsspi170p-validator-18" display-name="심근경색" v-model="formInput.input18" :rules="'required'" v-else>
                                <fdp-text-field class="-pub-input--purple" v-model="formInput.input18"></fdp-text-field>
                            </fdp-validator>
                        </div>
                    </div>
                </div>
                <p class="desc">※ 표준체의 할증지수는 100으로 표기됩니다.</p>
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <!-- 가상고객일 경우에만 취소버튼 추가 -->
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item" v-if="isVirtual">
                        <div class="-pub-button__text">취소</div>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                        <div class="-pub-button__text">확인</div>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
    <!-- 화면 확인용 테스트 버튼 -->
    <div class="-pub-product-btn-test">
        <a href="#" @click="isVirtual=!isVirtual">일반/가상화면 확인 테스트 버튼</a>
    </div>
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      isVirtual: false,
      formInput: {
        input1: '100',
        input2: '150',
        input3: '150',
        input4: '100',
        input5: '100',
        input6: '100',
        input7: '100',
        input8: '100',
        input9: '100',
        input10: '100',
        input11: '150',
        input12: '150',
        input13: '100',
        input14: '100',
        input15: '100',
        input16: '100',
        input17: '100',
        input18: '100'
      }
    }
  },
  watch: {
    isVirtual () {
      if (this.isVirtual) {
        this.formInput.input1 = ''
        this.formInput.input2 = ''
        this.formInput.input3 = ''
        this.formInput.input4 = ''
        this.formInput.input5 = ''
        this.formInput.input6 = ''
        this.formInput.input7 = ''
        this.formInput.input8 = ''
        this.formInput.input9 = ''
        this.formInput.input10 = ''
        this.formInput.input11 = ''
        this.formInput.input12 = ''
        this.formInput.input13 = ''
        this.formInput.input14 = ''
        this.formInput.input15 = ''
        this.formInput.input16 = ''
        this.formInput.input17 = ''
        this.formInput.input18 = ''
      } else {
        this.formInput.input1 = '100'
        this.formInput.input2 = '150'
        this.formInput.input3 = '150'
        this.formInput.input4 = '100'
        this.formInput.input5 = '100'
        this.formInput.input6 = '100'
        this.formInput.input7 = '100'
        this.formInput.input8 = '100'
        this.formInput.input9 = '100'
        this.formInput.input10 = '100'
        this.formInput.input11 = '150'
        this.formInput.input12 = '150'
        this.formInput.input13 = '100'
        this.formInput.input14 = '100'
        this.formInput.input15 = '100'
        this.formInput.input16 = '100'
        this.formInput.input17 = '100'
        this.formInput.input18 = '100'
      }
    }

  },
  methods: {
    isExtra () {
      return true
    }
  }
}
</script>
