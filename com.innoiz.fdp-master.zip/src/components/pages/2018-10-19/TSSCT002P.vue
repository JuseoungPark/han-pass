<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="인쇄/이메일 발송" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__consulting--detail-email">
                <div class="-pub-popup__consulting--detail-email-head">
                    <h3 class="-pub-popup__consulting--detail-email-head-tit">첨부 목록</h3>
                    <p class="-pub-popup__consulting--detail-email-head-txt">[본인] 계약현황분석. pdf 외 3건</p>
                </div>
                <ul class="-pub-popup__consulting--detail-email-list">
                  <li class="-pub-popup__consulting--detail-email-list-item1">
                    <label>받는 사람<span class="-pub-ico-check">*</span></label>
                    <div class="checkbox-wrap">
                        <fdp-validator name="tssct002p-validator-1" display-name="받는 사람" v-model="mailTo" :rules="'required'">
                            <fdp-text-field class="pub-text-field" v-model="mailTo"></fdp-text-field>
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="checkbox1">변경된 메일주소 고객정보에 반영</fdp-checkbox>
                        </fdp-validator>
                    </div>
                  </li>
                  <li class="-pub-popup__consulting--detail-email-list-item2">
                    <label>메일 제목<span class="-pub-ico-check">*</span></label>
                    <div class="checkbox-wrap">
                        <fdp-validator name="tssct002p-validator-2" display-name="메일 제목" v-model="mailTitle" :rules="'required'">
                            <fdp-text-field class="pub-text-field" v-model="mailTitle" placeholder="입력해주세요."></fdp-text-field>
                        </fdp-validator>
                       </div>
                  </li>
                  <li class="-pub-popup__consulting--detail-email-list-item3">
                    <label>본문내용</label>
                    <div class="checkbox-wrap">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="checkbox2" value="1">고객명 자동삽입</fdp-checkbox>
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="checkbox2" value="2">서명사용</fdp-checkbox>
                    </div>
                  </li>
                </ul>
                <div class="-pub-popup__consulting--detail-email-message">
                  <textarea v-model="mailText"></textarea>
              </div>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">발송</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      checkbox1: true,
      checkbox2: ['1', '2'],
      mailTo: '"이주명" <mail@mail.com>',
      mailTitle: '',
      mailCont: '',
      mailText: '더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더'

    }
  }
}
</script>
