<template>
        <section>
            <fdp-popup class="-pub-popup" v-model="showPopup" title="건강검진처 안내" :prevent-outside-close="true">
                <!-- slot 원하는 내용 -->
                <div class="-fdp-popup-page__slot">
                    <div class="-pub-popup__content -pub-popup__healthcheckinfo">
                        <div class="-pub-popup__healthcheckinfo--tit01">이용 가능 종합 병원</div>
                        <fdp-infinite class="-pub-table" v-model="selected" :items="itemsList">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column" style="width: 80px;">지역</th>
                                    <th class="-pub-table-column" style="width: 314px;">병원 이름</th>
                                    <th class="-pub-table-column" style="width: 694px;">병원 주소</th>
                                    <th class="-pub-table-column" style="width: 242px;">병원 연락처</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column -pub-table-column--name" style="width: 80px;">{{props.item.area}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 314px;">{{props.item.hospital}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 694px;">{{props.item.address}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 242px;">{{props.item.phone}}</td>
                            </template>
                            <!-- no data 화면 -->
                            <template slot="emptyView">
                                <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                        <div class="-pub-popup__healthcheckinfo--tit02">이용 가능 제휴 병원</div>
                        <fdp-infinite class="-pub-table -pub-table-second" v-model="selected" :items="itemsList2">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column" style="width: 80px;">지역</th>
                                    <th class="-pub-table-column" style="width: 314px;">병원 이름</th>
                                    <th class="-pub-table-column" style="width: 694px;">병원 주소</th>
                                    <th class="-pub-table-column" style="width: 242px;">병원 연락처</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column -pub-table-column--name" style="width: 80px;">{{props.item.area}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 314px;">{{props.item.hospital}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 694px;">{{props.item.address}}</td>
                                <td class="-pub-table-column -pub-table-column--left-align" style="width: 242px;">{{props.item.phone}}</td>
                            </template>
                            <!-- no data 화면 -->
                            <template slot="emptyView">
                                <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                    </div>
                </div>
                <!-- slot 끝 -->
            </fdp-popup>
        </section>
    </template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      selected: {},
      itemsList: [
        {
          area: '서울',
          hospital: '삼성서울병원 건강의학센터',
          address: '서울특별시 강남구 알현로 81',
          phone: '02-3410-1000'
        },
        {
          area: '서울',
          hospital: '강북삼성병원 종합검진센터',
          address: '서울특별시 중구 세종대로 67 삼성본관 지하1층',
          phone: '02-1599-8113'
        },
        {
          area: '서울',
          hospital: '서울대학교병원 강남센터',
          address: '서울특별시 강남구 테헤란로 152 강남파이낸스센터 38~40층',
          phone: '02-2112-5500'
        },
        {
          area: '서울',
          hospital: '서울아산병원 건강증진센터',
          address: '서울특별시 송파구 올림픽로 43길 88 (풍납동)',
          phone: '02-3010-4910'
        },
        {
          area: '서울',
          hospital: '세브란스 체크업',
          address: '서울특별시 중구 통일로 10 연세재단 세브란스빌딩 4~5층',
          phone: '1588-7757'
        },
        {
          area: '경기',
          hospital: '강북삼성병원 수원의원',
          address: '경기도 용인시 기흥구 흥덕1로 13 IT빌리지식산업센터 A동 37~40층',
          phone: '031-8092-8800'
        },
        {
          area: '강원',
          hospital: '강릉아산병원 건강의학센터',
          address: '강원도 강릉시 사천면 방동길 38',
          phone: '033-610-4000'
        },
        {
          area: '충북',
          hospital: '충북대학교병원 건강증진센터',
          address: '충청북도 청주시 서원구 1순환로 776 (계산동)',
          phone: '043-209-6566'
        },
        {
          area: '대구',
          hospital: '강북대학교병원 건강증진센터',
          address: '대구광역시 중구 을덕로 130',
          phone: '053-200-0000'
        },
        {
          area: '부산',
          hospital: '부산대학교병원 건강증진센터',
          address: '부산광역시 서구 구덕로 179',
          phone: '051-240-7890'
        },
        {
          area: '울산',
          hospital: '울산대학교병원 건강증진센터',
          address: '울산광역시 동구 방어진 순환도로 877  (전하동)',
          phone: '052-250-8300'
        },
        {
          area: '전북',
          hospital: '전북대학교병원 건강증진센터',
          address: '전라북도 전주시 덕진구 건지로 20',
          phone: '063-250-1882~3, 2804'
        }
      ],
      itemsList2: [
        {
          area: '서울',
          hospital: '한국외학연구소(여의도)',
          address: '서울특별시 영등포구 국제금융로2길 24',
          phone: '02-368-6114'
        },
        {
          area: '서울',
          hospital: '한국의학연구소(광화문)',
          address: '서울특별시 종로구 세종대로 23길 54',
          phone: '02-3702-9000'
        },
        {
          area: '서울',
          hospital: '우리한헬스케어',
          address: '서울특별시 중구 청계천로 100 시그니처 타워 서관 2층',
          phone: '02-750-0000'
        },
        {
          area: '서울',
          hospital: '한신 메디피아',
          address: '서울특별시 서초구 잠원로 94 한신메디피아',
          phone: '1588-3778'
        },
        {
          area: '서울',
          hospital: '녹십자 아이메드',
          address: '서울시 서초구 서초대로 38길 12 미래스타시티타워1 (4~5층)',
          phone: '1644-0808'
        },
        {
          area: '경기',
          hospital: '한국의학연구소(강남)',
          address: '서울특별시 강남구 테헤란로 411',
          phone: '02-3496-3300'
        },
        {
          area: '강원',
          hospital: '비에비스나무병원',
          address: '서울특별시 강남구 논현로 627',
          phone: '1577-7502'
        },
        {
          area: '충북',
          hospital: '을지병원',
          address: '서울특별시 노원구 한글비석로 68 (하계2봉)',
          phone: '02-970-8181~2'
        }
      ]
    }
  }
}
</script>
