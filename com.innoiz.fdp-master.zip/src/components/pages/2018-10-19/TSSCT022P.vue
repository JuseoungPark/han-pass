<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="세부보장내용" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup -pub-consulting-popup--type-5">
        <div class="-pub-consulting-popup__default-info -pub-consulting-popup__default-info--fixed -pub-consulting-popup__default-info--no-padding-bottom">
          <div class="-pub-consulting-popup__active-content">
            <h3 class="-pub-consulting-popup__title -pub-consulting-popup__title--type-4">
              보장내역
              <div class="-pub-consulting-popup__unit">단위: 원</div>
            </h3>
            <!-- 2018/11/13 표 3열 → 2열로 수정 -->
            <table class="-pub-native-table">
              <thead>
                <tr>
                  <th class="-pub-table-column">보장급부</th>
                  <th class="-pub-table-column">보장금액</th>
                </tr>
              </thead>
            </table>
            <div class="-pub-table-scroll-container">
              <table class="-pub-native-table -pub-native-table--body">
                <tbody>
                  <tr v-for="(row, i) in mockData" :key="i">
                    <td class="-pub-table-column align-center">{{row.label}}</td>
                    <td class="-pub-table-column normal-letter align-right">{{row.value}}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- 2018/11/13 표 3열 → 2열로 수정 end -->
          </div>
        </div>
      </div>
      <div class="-pub-bottom-bar">
        <div class="-pub-confirm__content--right">
          <button type="button" class="-pub-button -pub-button--reverse" @click="showPopup = !showPopup">
            <span class="-pub-button__text">확인</span>
          </button>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  mockDataSub
} from '@/components/mock/TSSCT022P.mock'
export default {
  data () {
    return {
      showSelectContent: true,
      showPopup: true,
      isIntial: true,
      name: '',
      selectItems: [],
      mockData: Array.prototype.slice.call(mockDataSub),
      // mockData: [],
      date1: '2017-01',
      searchKeyword: '207,130',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },
      segment1: {
        items: [{
          key: '1',
          label: '생명보험'
        },
        {
          key: '2',
          label: '손해보험'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment2: {
        items: [{
          key: '1',
          label: '일반'
        },
        {
          key: '2',
          label: '유니버셜'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment3: {
        items: [{
          key: '1',
          label: '주피'
        },
        {
          key: '2',
          label: '종피'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      select1: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '교보생명'
        }]
      },
      select2: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '이주명'
        }]
      },
      select3: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '월납'
        }]
      }
    }
  },
  computed: {
    isSelectAll () {
      return this.selectItems.length > 0
    }
  },
  methods: {
    selectAllItemsFunc (isSelectAll) {
      this.selectItems = isSelectAll ? [] : Array.prototype.slice.call(this.mockData)
    }
  }

}
</script>
