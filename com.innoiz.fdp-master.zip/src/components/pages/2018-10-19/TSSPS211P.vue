<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="전자서명완료 재처리" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup-ps211p">
            <div>
                <dl class="-pub-row">
                    <dt>상품명</dt>
                    <dd class="-pub-product-name">통합유니버설종신보험3.0(무배당통합유니버설종신보험3.0(무배당통합유니버설종신보험3.0(무배당통합유니버설종신보험3.0(무배당통합유니버설종신보험3.0(무배당...</dd>
                </dl>
                <dl class="-pub-row">
                    <dt>계약자</dt>
                    <dd>박부영</dd>
                </dl>
                <dl class="-pub-row">
                    <dt>청약일</dt>
                    <dd class="-pub-normal-letter">2016-07-24</dd>
                </dl>
                <ul>
                    <li class="-pub-header-wrap">
                        <ul>
                            <li>1단계<br>
                                (전자문서보관)</li>
                            <li>2단계<br>
                                (신계약정보전송)</li>
                            <li>3단계<br>
                                (주임메일)</li>
                            <li>4단계<br>
                                (서류이메일)</li>
                            <li>5단계<br>
                                (메세지전송)</li>
                        </ul>
                    </li>
                    <li class="-pub-body-wrap">
                        <ul>
                            <li v-for="level in levelCompletion" :key="level.step">
                                <span v-if="level.completion">Y</span>
                                <button v-else type="button" class="-pub-button -pub-button--small -pub-retry">재시도</button>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <div class="-pub-popup__button-area -pub-popup__button-area--shadow">
            <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                <span class="-pub-button__text">확인</span>
            </button>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      levelCompletion: [
        {
          step: '1',
          completion: true
        },
        {
          step: '2',
          completion: true
        },
        {
          step: '3',
          completion: true
        },
        {
          step: '4',
          completion: false
        },
        {
          step: '5',
          completion: true
        }
      ]
    }
  }
}
</script>
