<template>
    <div class="-pub-complete-tssps182d">
        <div class="-pub-ico-complete-wrap">
            <img class="-pub-ico-complete" src="@/assets/img/ico_complete.gif" alt="">
            <span>전자서명이<br>완료되었습니다.</span>
        </div>
        <hr>
        <span class="-pub-text-1">"통합유니버설종신보험3.0(무배당,보증비용부과형)" 전자서명이 완료되었습니다.<br>
                삼성생명을 믿고 선택해주신 고객님께 다시 한 번 깊이 감사드리며, <br>
                고객님께 최상의 서비스를 제공할 수 있도록 항상 노력하겠습니다.</span>
        <span class="-pub-text-2">※ 전자서명 계약서류는 고객님의 이메일로 발송되며 당사 홈페이지에서도 확인하실 수 있습니다.</span>
        <span class="-pub-text-2">※ 계약서류의 서면 교부 요청 시 5영업일 이내에 수령하실 수 있습니다.</span>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--full" v-show="true" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--medium -pub-button--reverse -pub-bottom-nav__item">
                        <span class="-pub-button__text">완료</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
</template>
<script>

</script>
