<template>
    <section class="-pub-complete-page">
              <!-- test를 위한 radio button -->
        <div style="position: absolute; top: 50px; left: 50%; border: 1px solid red; padding: 20px 0 20px 20px;">
            test:
            <fdp-radio v-model="test" value="1" style="width: 70px; margin-left: 20px;">1</fdp-radio>
            <fdp-radio v-model="test" value="2" style="width: 70px;">2</fdp-radio>
            <fdp-radio v-model="test" value="3" style="width: 70px;">3</fdp-radio>
            <fdp-radio v-model="test" value="4" style="width: 70px;">4</fdp-radio>
            <fdp-radio v-model="test" value="5" style="width: 70px;">5</fdp-radio>
            <fdp-radio v-model="test" value="6" style="width: 70px;">6</fdp-radio>
        </div>
        <!-- test를 위한 radio button -->
        <TSSPS182D v-if="test==='5'"></TSSPS182D>
        <TSSPS183D v-else-if="test==='6'"></TSSPS183D>
        <TSSPS181D :test="test" v-else></TSSPS181D>
    </section>
</template>
<script>
import TSSPS181D from '@/components/pages/2018-10-19/TSSPS181D'
import TSSPS182D from '@/components/pages/2018-10-19/TSSPS182D'
import TSSPS183D from '@/components/pages/2018-10-19/TSSPS183D'

export default {
  components: {
    TSSPS181D,
    TSSPS182D,
    TSSPS183D
  },
  data () {
    return {
      test: '1'
    }
  }
}
</script>
