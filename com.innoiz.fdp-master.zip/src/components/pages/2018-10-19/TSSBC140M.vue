<template>
    <div class="-pub-header-content -pub-header-content__openview">
       <div class="-pub-header-content__openview--wrap">
            <div class="-pub-header-content__openview--wrap-tit">
                <h1>열린화면 바로가기</h1>
                <!-- 2018-11-16 닫기 버튼 추가-->
                <a href="#" class="btn-close" @click="closeContent">
                    <img src="@/assets/img/components/btn_close.png" alt="닫기">
                </a>
            </div>
            <ul class="-pub-header-content__openview--wrap-list">
                <!-- 현재 보고 있는 화면 li에  class="-pub-header-content__openview--wrap-list-item--active" 추가 -->
                <li v-for="(screen, idx) in openedScreen" :key="idx" :class="[{'-pub-header-content__openview--wrap-list-item':true}, {'-pub-header-content__openview--wrap-list-item--active':idx===0}]">
                    <a href="#" class="txt">{{screen.name}}</a>
                    <a href="#" class="btn-close" @click="deleteScreen(idx)">
                        <img src="@/assets/img/components/btn_close_light.png" alt="닫기">
                    </a>
                </li>
            </ul>
       </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      openedScreen: [
        {
          name: '고객등록동의'
        },
        {
          name: '프리미엄 고객사랑 서비스  바로가기'
        },
        {
          name: '전체 고객목록'
        },
        {
          name: '주간활동 현황'
        },
        {
          name: '고객접촉정보'
        },
        {
          name: '고객등록동의'
        },
        {
          name: '전체 고객목록'
        },
        {
          name: '프리미엄 고객사랑 서비스 바로가기'
        }
      ]
    }
  },
  methods: {
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    },
    deleteScreen (idx) {
      this.openedScreen.splice(idx, 1)
    },
    closeContent () {
      this.$emit('close')
    }
  }
}
</script>
