<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="인쇄/이메일 발송" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__consulting--detail-print">
                <div class="-pub-popup__consulting--detail-print-list">
                    <div class="-pub-popup__consulting--detail-print-list-way">
                        <h3 class="-pub-popup__consulting--detail-print-list-way-tit">발송방식 선택</h3>
                        <div class="-pub-popup__consulting--detail-print-list-way-spend">
                            <fdp-validator name="tssct001p_validator-1" v-model="radioValue1" display-name="발송방식" :rules="'required'">
                                <fdp-radio v-model="radioValue1" class="-pub-radio" value="1">인쇄</fdp-radio>
                                <!--disabled 일때(이메일 선택 시) disabled 속성 추가  / validator 체크 시 class="error 추가"-->
                                <fdp-select v-model="selectedValue1" :option-list="selectedData1" placeholder="인쇄컬러 선택" :disabled="radioValue1==='2'"></fdp-select>
                                <fdp-radio v-model="radioValue1" class="-pub-radio" value="2">이메일</fdp-radio>
                            </fdp-validator>
                        </div>
                    </div>
                    <div class="-pub-popup__consulting--detail-print-list-way">
                        <h3 class="-pub-popup__consulting--detail-print-list-way-tit">보기방식 선택</h3>
                        <div class="-pub-popup__consulting--detail-print-list-way-view">
                            <fdp-validator name="tssct001p_validator-2" v-model="radioValue2" display-name="보기방식" :rules="'required'">
                                <fdp-radio v-model="radioValue2" class="-pub-radio" value="1">세로형</fdp-radio>
                                <fdp-radio v-model="radioValue2" class="-pub-radio" value="2">가로형</fdp-radio>
                            </fdp-validator>
                        </div>
                    </div>
                    <div class="-pub-popup__consulting--detail-print-list-way">
                        <h3 class="-pub-popup__consulting--detail-print-list-way-tit">서류 선택</h3>
                        <div class="-pub-popup__consulting--detail-print-list-way-paper">
                            <p class="total">총 {{this.tableData.length}}건</p>
                            <div class="name">
                                <strong class="tit">고객명</strong>
                                <fdp-select v-model="selectedValue2" :option-list="selectedData2" placeholder="고객명 선택"></fdp-select>
                            </div>
                        </div>
                    </div>
                </div>
               <fdp-infinite class="-pub-table -pub-table-blue" :items="tableData"  multi-select v-model="selectItems">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column -pub-table-column--checkbox" style="width:78px;">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                            </th>
                            <th class="-pub-table-column" style="width:200px;">고객명</th>
                            <th class="-pub-table-column" style="width:776px;">목록명</th>
                        </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column--checkbox" style="width:78px">
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="selectItems" :value="props.item"></fdp-checkbox>
                        </td>
                        <td class="-pub-table-column" style="width:200px"><strong>{{props.item.id}}</strong></td>
                        <td class="-pub-table-column -pub-table-column--left-align" style="width:776px">{{props.item.name}}</td>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView">
                        <div class="-pub-table-empty-view -pub-table-empty-view—search">
                            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                        </div>
                    </template>
                </fdp-infinite>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
                        <fdp-checkbox class="-pub-checkbox -pub-check-label" v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}건 선택</fdp-checkbox>
                    </li>
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <!--disabled 일때 disabled 속성 추가 -->
                        <button class="-pub-button -pub-button--small -pub-bottom-nav__item -pub-button--reverse" :disabled="mockCheckCount === 0">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  mounted () {
    this.copyData = this.tableData.slice(0)
  },
  data () {
    return {
      showPopup: true,
      radioValue1: '1',
      radioValue2: '1',
      bottomBarCheck: true,
      isSelectAll: false,
      selectItems: [],
      copyData: [],
      selectedValue1: { key: '양면컬러', label: '양면컬러' },
      selectedData1: [{
        key: '양면컬러',
        label: '양면컬러'
      },
      {
        key: '단면컬러',
        label: '단면컬러'
      },
      {
        key: '양면흑백',
        label: '양면흑백'
      },
      {
        key: '단면흑백',
        label: '단면흑백'
      }],
      selectedValue2: { key: '전체 세대원', label: '전체 세대원' },
      selectedData2: [{
        key: '전체 세대원',
        label: '전체 세대원'
      },
      {
        key: '일반 세대원',
        label: '일반 세대원'
      }],
      tableData: [{
        id: '김남편1',
        name: '계약현황분석1'
      },
      {
        id: '이남편2',
        name: '보장자산요약2'
      },
      {
        id: '조남편3',
        name: '상품별 보장내역분석3'
      },
      {
        id: '박남편4',
        name: '설계 전 기간별 보장내역 분석4'
      },
      {
        id: '서남편5',
        name: '계약현황분석5'
      },
      {
        id: '남남편6',
        name: '보장자산요약6'
      },
      {
        id: '북남편7',
        name: '상품별 보장내역분석7'
      },
      {
        id: '아남편8',
        name: '설계 전 기간별 보장내역 분석8'
      }]
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    }
  },
  methods: {
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.tableData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.tableData.length) {
        this.isSelectAll = false
      } else {
        if (this.tableData.length !== 0) {
          this.isSelectAll = true
        }
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    },
    // empty view 확인 용도
    selectedValue2 () {
      if (this.selectedValue2.key === '전체 세대원') {
        this.tableData = this.copyData.slice(0)
      } else {
        this.tableData = []
      }

      this.cancelSeletItemsFunc()
    }
  }
}
</script>
