<template>
    <section class="-pub-container__customer--home">
       <div class="-pub-container__customer--home-wrap">
           <div class="-pub-container__customer--home-wrap-header">
               <div class="search">
                   <a href="#">고객명을 입력하세요.</a>
               </div>
               <div class="btn-area-right">
                   <a href="#" class="btn-white">고객참여이벤트</a>
                   <a href="#" class="btn-white"><span class="ico-plus">신규 고객등록</span></a>
               </div>
           </div>
           <div class="-pub-container__customer--home-wrap-mylife">
               <h2>내 인생 미리 그려보기</h2>
               <ul class="-pub-container__customer--home-wrap-mylife-list">
                   <li class="-pub-container__customer--home-wrap-mylife-list-item">
                       <a href="#">
                            <img src="@/assets/img/img_family_type_1_blue.png" alt="">
                            <span class="txt">1인 가구</span>
                        </a>
                   </li>
                   <li class="-pub-container__customer--home-wrap-mylife-list-item">
                       <a href="#">
                            <img src="@/assets/img/img_family_type_2_blue.png" alt="">
                            <span class="txt">한 부모 + 자녀</span>
                        </a>
                   </li>
                   <li class="-pub-container__customer--home-wrap-mylife-list-item">
                       <a href="#">
                            <img src="@/assets/img/img_family_type_3_blue.png" alt="">
                            <span class="txt">부부 가구</span>
                        </a>
                   </li>
                   <li class="-pub-container__customer--home-wrap-mylife-list-item">
                       <a href="#">
                            <img src="@/assets/img/img_family_type_4_blue.png" alt="">
                            <span class="txt">부모 + 자녀</span>
                        </a>
                   </li>
               </ul>
           </div>
       </div>
   </section>
</template>
<script>
export default {
  methods: {
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    }
  }
}
</script>
