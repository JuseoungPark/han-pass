<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="계약서류발송" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup-send-insurance-doc">
            <div>
                <div class="-pub-validator-group-1">
                    <label>발행방식</label>
                    <!-- <fdp-validator name="name5" v-model="returnData1" :rules="'required'"> -->
                        <fdp-segment-box class="-pub-segment--purple -pub-segment--large -pub-segment__container" essential v-model="returnData1" :data="segmentData1"></fdp-segment-box>
                    <!-- </fdp-validator> -->
                </div>
                <span class="-pub-text-1">다음과 같은 계약서류를 발송합니다.</span>
                <div class="-pub-text-box-1">
                    <span>{{returnData1[0].key==='333'?'계약자보관용청약서':(isVariable?'변액운용설명서':'보험약관 / 계약자보관용청약서 등')}}</span>
                </div>
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
            <div class="-pub-bottom-nav">
                <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                    <button type="button" class="-pub-button -pub-button--purple">취소</button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                </div>
            </div>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      isVariable: false, // 변액보험 여부
      segmentData1: [{
        'key': '111',
        'label': '모바일'
      },
      {
        'key': '222',
        'label': '이메일'
      },
      {
        'key': '333',
        'label': '지점인쇄'
      }],
      returnData1: [{
        'key': '111',
        'label': '모바일'
      }]
    }
  }
}
</script>
