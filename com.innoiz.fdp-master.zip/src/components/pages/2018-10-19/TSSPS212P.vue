<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="청약진행현황조회(전자청약)" prevent-outside-close>
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content -pub-popup-ps212p">
            <div class="-pub-row">
                <dl>
                    <dt>계약자</dt>
                    <dd>김삼성</dd>
                </dl>
                <img class="-pub-step-img" :src="contractImg" alt="" @click="testValue">
            </div>
            <div class="-pub-row">
                <dl>
                    <dt>피보험자</dt>
                    <dd>김둘째</dd>
                </dl>
                <img class="-pub-step-img" :src="InsuredImg" alt="">
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
            <div class="-pub-bottom-nav">
                <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                </div>
            </div>
        </fdp-bottom-bar>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      currentContractStat: '3', // 계약자 상태값
      currentInsuredStat: '2' // 피보험자 상태값
    }
  },
  computed: {
    contractImg () {
      let imgPath = ''
      switch (this.currentContractStat) {
        case '2' :
          imgPath = require('../../../assets/img/img_subscription_step_2.png')
          break
        case '3' :
          imgPath = require('../../../assets/img/img_subscription_step_3.png')
          break
        case '4' :
          imgPath = require('../../../assets/img/img_subscription_step_4.png')
          break
        case '5' :
          imgPath = require('../../../assets/img/img_subscription_step_5.png')
          break
        case '6' :
          imgPath = require('../../../assets/img/img_subscription_step_6.png')
          break
        case '7' :
          imgPath = require('../../../assets/img/img_subscription_step_7.png')
          break
        default :
          imgPath = require('../../../assets/img/img_subscription_step_1.png')
          break
      }
      return imgPath
    },
    InsuredImg () {
      let imgPath = ''
      switch (this.currentInsuredStat) {
        case '2' :
          imgPath = require('../../../assets/img/img_subscription_step_2.png')
          break
        case '3' :
          imgPath = require('../../../assets/img/img_subscription_step_3.png')
          break
        case '4' :
          imgPath = require('../../../assets/img/img_subscription_step_4.png')
          break
        case '5' :
          imgPath = require('../../../assets/img/img_subscription_step_5.png')
          break
        case '6' :
          imgPath = require('../../../assets/img/img_subscription_step_6.png')
          break
        case '7' :
          imgPath = require('../../../assets/img/img_subscription_step_7.png')
          break
        case '1' :
          imgPath = require('../../../assets/img/img_subscription_step_1.png')
          break
      }
      return imgPath
    }
  },
  methods: {
  }
}
</script>
