<template>
  <section class="-pub-suggest-detail">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <span class="-pub-suggest-detail__badge -pub-suggest-detail__badge--fr-4"><span class="-pub-suggest-detail__badge-label">노후</span></span>
        {{suggestScript.title}}
      </h2>
      <div class="-pub-page-header__content">
        <a class="-pub-page-header__button -pub-page-header__button--close">X</a>
      </div>
    </div>
    <div class="-pub-suggest-detail__content">
      <article class="-pub-suggest-detail__description">{{suggestScript.description}}</article>
      <section class="-pub-suggest-detail__slide-container">
        <fdp-carousel :number-of-page="suggestScript.imageList.length">
          <template v-for="(info, index) in suggestScript.imageList" :slot="index + 1">
            <div class="-pub-suggest-detail__slide-item" :key="index"><img class="-pub-suggest-detail__slide-img" :src="info.src" alt=""></div>
          </template>
        </fdp-carousel>

      </section>
    </div>
    <!-- 기계약 영역 -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full"
      v-show="true">
      <div class="-pub-bottom-nav">
        <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered"><button class="-pub-button -pub-button--medium -pub-bottom-nav__item">전체보기</button></div>
        <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered">
        </div>
        <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
          <button class="-pub-button -pub-button--prev -pub-button--reverse">
            <img class="icon-arrow" src="@/assets/img/components/ico-arrow-prev-blue.png" alt="이전 버튼">
            이전
          </button><button class="-pub-button -pub-button--next">
            다음
            <img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼">
          </button>
        </div>
      </div>
    </fdp-bottom-bar>
  </section>
</template>
<script>
export default {
  components: {},
  watch: {},
  computed: {},
  data () {
    return {
      suggestScript: {
        title: '점점 다가오는 "은퇴 후의 삶"',
        imageList: [
          { src: require('@/assets/img/suggest/script-img-1.png') },
          { src: require('@/assets/img/suggest/script-img-2.png') },
          { src: require('@/assets/img/suggest/script-img-1.png') }
        ],
        description: `어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다.
최소한 소득의 10% 이상은 노후를 위해 투자하십시오!

어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다.
최소한 소득의 10% 이상은 노후를 위해 투자하십시오!
어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다. 최소한 소득의 10% 이상은 노후를 위해 투자하십시오!

어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다.
최소한 소득의 10% 이상은 노후를 위해 투자하십시오! 어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다. 최소한 소득의 10% 이상은 노후를 위해 투자하십시오! 어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다.
최소한 소득의 10% 이상은 노후를 위해 투자하십시오! 어떻게 준비하고 계신가요? 준비할 기간은 점점 짧아지고, 수명은 점점 길어지고 ...길고 긴 노후를 누리기 위한 준비, 더 이상 지체하면 안됩니다. 최소한 소득의 10% 이상은 노후를 위해 투자하십시오!`

      }
    }
  },
  methods: {}
}
</script>
