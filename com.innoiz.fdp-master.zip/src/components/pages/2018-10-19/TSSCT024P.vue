<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="가상고객 라이프분석 저장" prevent-outside-close>
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__consulting--detail-life">
                <div class="-pub-popup__consulting--detail-life-list">
                    <dl class="-pub-popup__consulting--detail-life-list-item">
                        <dt>가족유형</dt>
                        <dd>부부+자녀</dd>
                    </dl>
                    <dl class="-pub-popup__consulting--detail-life-list-item">
                        <dt>저장명</dt>
                        <dd>
                            <fdp-validator name="tssct001p_save" display-name="저장명" v-model="defaultField" :rules="'required'">
                                <fdp-text-field class="-pub-text-field" v-model="defaultField"></fdp-text-field>
                            </fdp-validator>
                        </dd>
                    </dl>
                </div>
                 <div class="-pub-popup__button-area">
                    <button type="button" class="-pub-button -pub-button--180">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--180 -pub-button--reverse">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      defaultField: ''
    }
  },
  mounted () {
    // getMonth : 0부터 11까지 return 되므로 +1 함.
    this.defaultField = new Date().getFullYear().toString().substring(2) + (new Date().getMonth() + 1) +
    new Date().getDate() + '_' + new Date().getHours() + new Date().getMinutes()
  }
}
</script>
