<template>
  <section>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="동의서 양식 발행" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-fdp-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__consent--print">
                <dl class="-pub-popup__consent--print-list">
                    <dt class="-pub-popup__consent--print-list-label">동의서 유형</dt>
                    <dd class="-pub-popup__consent--print-list-item">
                        <!-- <fdp-validator name="Name" v-model="agreeValues" :rules="'required'"> -->
                        <fdp-segment-box v-model="agreeValues" :data="agree" class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--blue" essential></fdp-segment-box>
                        <!-- </fdp-validator> -->
                    </dd>
                </dl>
                <dl class="-pub-popup__consent--print-list">
                    <dt class="-pub-popup__consent--print-list-label">구분</dt>
                    <dd class="-pub-popup__consent--print-list-item">
                        <!-- <fdp-validator name="Name" v-model="divisionValues" :rules="'required'"> -->
                        <fdp-segment-box v-model="divisionValues" :data="division" class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--blue" essential @click="clickDivision"></fdp-segment-box>
                        <!-- </fdp-validator> -->
                    </dd>
                </dl>
                <!-- 구분에서 고객선택을 클릭했을 때 나오는 리스트-->
                <dl class="-pub-popup__consent--print-list" v-show="divisionValues[0].key === '2'">
                    <dt class="-pub-popup__consent--print-list-label">대상</dt>
                    <dd class="-pub-popup__consent--print-list-item">
                        <!-- <fdp-validator name="Name" v-model="customernameValues" :rules="'required'"> -->
                        <fdp-text-field v-model="customernameValues" placeholder="고객명" fixedIcon></fdp-text-field>
                        <!-- </fdp-validator> -->
                    </dd>
                </dl>
                <ul class="-pub-popup__consent--print-divisionlist" v-show="divisionValues[0].key === '2'">
                    <li class="-pub-popup__consent--print-divisionitem" @click="clickChk1"><!-- 체크박스를 선택했을 경우 -pub-checkbox-slct 가 없어져야 함-->
                        <fdp-checkbox v-model="chk1" :class="[{'-pub-checkbox':true}, {'-pub-checkbox-slct':!chk1}]">세대원1</fdp-checkbox>
                        <!-- <fdp-validator name="Name" v-model="selectGroups.values.group1" :rules="'required'"> -->
                            <fdp-select v-model="selectGroups.values.group1" :option-list="selectGroups.group1" placeholder="세대원명" class="-pub-select"></fdp-select><!-- :disabled="chk1===false" -->
                        <!-- </fdp-validator> -->
                    </li>
                    <li class="-pub-popup__consent--print-divisionitem" @click="clickChk2"><!-- 체크박스를 선택했을 경우 -pub-checkbox-slct 가 없어져야 함-->
                        <fdp-checkbox v-model="chk2" :class="[{'-pub-checkbox':true}, {'-pub-checkbox-slct':!chk2}]">세대원2</fdp-checkbox>
                        <!-- <fdp-validator name="Name" v-model="selectGroups.values.group2" :rules="'required'"> -->
                            <fdp-select v-model="selectGroups.values.group2" :option-list="selectGroups.group2" placeholder="세대원명" class="-pub-select"></fdp-select><!--  :disabled="chk2===false" -->
                        <!-- </fdp-validator> -->
                    </li>
                    <li class="-pub-popup__consent--print-divisionitem" @click="clickChk3"><!-- 체크박스를 선택했을 경우 -pub-checkbox-slct 가 없어져야 함-->
                        <fdp-checkbox v-model="chk3" :class="[{'-pub-checkbox':true}, {'-pub-checkbox-slct':!chk3}]">세대원3</fdp-checkbox>
                        <!-- <fdp-validator name="Name" v-model="selectGroups.values.group3" :rules="'required'"> -->
                            <fdp-select v-model="selectGroups.values.group3" :option-list="selectGroups.group3" placeholder="세대원명" class="-pub-select"></fdp-select> <!--  :disabled="chk3===false" -->
                        <!-- </fdp-validator> -->
                    </li>
                </ul>
            </div>
            <div class="-pub-popup__button-area -pub-popup__button-area--shadow -pub-popup__shadow--absolute">
                <button type="button" class="-pub-button -pub-button--180" @click="showPopup = !showPopup">
                    <span class="-pub-button__text">취소</span>
                </button>
                <button type="button" class="-pub-button -pub-button--180 -pub-button--reverse" @click="showPopup = !showPopup" :disabled="divisionValues[0].key === '2' && !showPrint">
                    <span class="-pub-button__text">인쇄</span>
                </button>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
  </section>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      Name: '',
      chk1: false,
      chk2: false,
      chk3: false,
      showPrint: false,
      selectedValue: '',
      customernameValues: '',
      agreeValues: [
        {
          key: '1',
          label: '필수컨설팅'
        }
      ],
      agree: [
        {
          key: '1',
          label: '필수컨설팅'
        },
        {
          key: '2',
          label: '마케팅'
        }
      ],
      divisionValues: [
        {
          key: '1',
          label: '고객 미선택'
        }
      ],
      division: [
        {
          key: '1',
          label: '고객 미선택'
        },
        {
          key: '2',
          label: '고객 선택'
        }
      ],
      selectGroups: {
        group1: [{
          key: '1',
          label: '김아들'
        }],
        group2: [{
          key: '1',
          label: '김아들'
        },
        {
          key: '2',
          label: '김아들'
        },
        {
          key: '3',
          label: '김아들'
        }],
        group3: [{
          key: '1',
          label: '김아들'
        },
        {
          key: '2',
          label: '김아들'
        }
        ],
        values: {
          group1: {
            key: '',
            label: ''
          },
          group2: {
            key: '',
            label: ''
          },
          group3: {
            key: '',
            label: ''
          }
        }
      }
    }
  },
  methods: {
    clickChk1 () {
      if (this.chk1 === false) {
        this.selectGroups.values.group1 = { key: '', label: '' }
      }
    },
    clickChk2 () {
      if (this.chk2 === false) {
        this.selectGroups.values.group2 = { key: '', label: '' }
      }
    },
    clickChk3 () {
      if (this.chk3 === false) {
        this.selectGroups.values.group3 = { key: '', label: '' }
      }
    },
    clickDivision () {
      if (this.divisionValues[0].key === '1') {
        this.chk1 = false
        this.chk2 = false
        this.chk3 = false
        this.selectGroups.values.group1 = { key: '', label: '' }
        this.selectGroups.values.group2 = { key: '', label: '' }
        this.selectGroups.values.group3 = { key: '', label: '' }
      }
    }
  },
  watch: {
    'selectGroups.values.group1' () {
      this.showPrint = false

      if (this.selectGroups.values.group1.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group2.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group3.key !== '') {
        this.showPrint = true
      }
    },
    'selectGroups.values.group2' () {
      this.showPrint = false

      if (this.selectGroups.values.group1.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group2.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group3.key !== '') {
        this.showPrint = true
      }
    },
    'selectGroups.values.group3' () {
      this.showPrint = false

      if (this.selectGroups.values.group1.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group2.key !== '') {
        this.showPrint = true
      }
      if (this.selectGroups.values.group3.key !== '') {
        this.showPrint = true
      }
    }
  }
}
</script>
