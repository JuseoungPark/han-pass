<!--
1.
-->
<template>
  <section class="-pub-gnb-systemNotice">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">시스템공지</span>
      </h2>
    </div>

    <div class="-pub-page-content">
      <div class="-pub-page-content--left">
        <div class="-pub-filter-menu -pub-filter-menu--in-tab">
          <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{tableData.length}}건</div>
          <div class="-pub-filter-menu__item--right">
              <form>
                  <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="제목명" @keyup.enter.stop="onSearch" v-model="searchKeyword" clearable></fdp-text-field>
                  <button type="button" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                      <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                  </button>
              </form>
          </div>
        </div>
        <fdp-infinite v-model="tableMgmt.selectItems" :headers="mockHeader" singleSelect :items="tableData" :tableHederHeight="68" :tableBodyHeight="988" :tableMinWidth="790">
          <template slot="header">
            <colgroup>
              <col width="588px"><col width="202px">
            </colgroup>
            <tr>
              <th>제목명</th>
              <th @click="sortFunc(sortType)">
                <span class="-pub-sorting--purple">공지일자</span>
                <a class="-pub-sorting--purple--ico">
                  <img src="@/assets/img/components/btn_table_sorting_down_purple.png" alt="icon" v-if="sortType">
                  <img src="@/assets/img/components/btn_table_sorting_up_purple.png" alt="icon" v-else>
                </a>
              </th>
            </tr>
          </template>
          <template slot-scope="props">
            <colgroup>
              <col width="588px"><col width="202px">
            </colgroup>
            <!-- td에 class="-fdp-infinite__tbody-ico" 삽입시 new icon 생성  -->
            <td style="text-align: left;" :class="[props.item.isNewRecord ? '-fdp-infinite__tbody-ico' : '']">{{props.item.title}}</td>
            <td>{{props.item.effDateStart}}</td>
          </template>
          <!--검색결과 존재하지 않을때 주석 해제-->
          <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                  <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
              </div>
          </template>
        </fdp-infinite>
      </div>

      <!-- 데이터가 존재하지 않을때 주석 해제 -->
      <div class="-pub-page-content--right" v-if="this.tableData.length>0 && detailContent===''">
        <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
        </div>
      </div>

      <div class="-pub-page-content--right" v-if="this.tableData.length>0 && detailContent!==''">
        <div class="-pub-filter-header">
          <div class="-pub-filter-header__left">
            <span>작성자</span>
            <span>{{writer}}</span>
          </div>
          <div class="-pub-filter-header__right">{{period}}</div>
        </div>
        <div class="-pub-filter-title">{{detailTitle}}</div>
        <div class="-pub-filter-data">{{detailContent}}</div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: _ => ''
    },
    subTitle: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      inputDate: '2018-06',
      searchKeyword: '',
      defaultValue: '',
      placeholderValue: '',
      selectedValue: { key: '10', label: '10' },
      disabledValue: '',
      multiCheckbox: false,
      writer: '',
      period: '',
      detailTitle: '',
      detailContent: '',
      sortType: true,
      pageItems: [
        { key: '10', label: '10' },
        { key: '20', label: '20' },
        { key: '30', label: '30' }
      ],
      mockHeader: [],
      idxGenerate2: 0,
      showLoadingStatus2: false,
      // 차단 테이블 관리 데이터
      tableMgmt: {
        startDate: '', // 테이블 기간 조회(시작)
        endDate: '', // 테이블 기간 조  회(끝)
        selectItems: {}
      },
      tableData: [],
      // Mockup 테이블 데이터
      originData: [
        {
          idx: 1,
          title: '7/18 (월) To do List',
          effDateStart: '2018-04-30',
          isNewRecord: true,
          period: '2017-03-01~2017-03-22',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행2'
        },
        {
          idx: 2,
          title: '7월 4주차 프로모션 공지',
          effDateStart: '2017-07-23',
          period: '2017-08-01 ~ 2017-08-02',
          writer: '지점장2',
          detailContent: ''
        },
        {
          idx: 3,
          title: '7월 특차마감 프로모션 안내',
          effDateStart: '2017-01-03',
          period: '2017-09-01 ~ 2017-11-02',
          writer: '지점장3',
          detailContent: '- 생.타.종. 가입 설계서 발행4'
        },
        {
          idx: 4,
          title: '팀별 동행일정 안내',
          effDateStart: '2017-11-25',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장4',
          detailContent: '- 생.타.종. 가입 설계서 발행'
        },
        {
          idx: 5,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행'
        },
        {
          idx: 6,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행'
        },
        {
          idx: 7,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행'
        },
        {
          idx: 8,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행3'
        },
        {
          idx: 9,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행4'
        },
        {
          idx: 10,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행5'
        },
        {
          idx: 11,
          title: '특차마감 프로모션 안내',
          effDateStart: '2017-12-12',
          period: '2017-06-01 ~ 2017-08-02',
          writer: '지점장',
          detailContent: '- 생.타.종. 가입 설계서 발행5'
        }
      ]
    }
  },
  methods: {
    onSearch () {
      this.tableData = []
      this.tableMgmt.selectItems = {}
      if (this.searchKeyword !== '') {
        for (let i = 0; i < this.originData.length; i++) {
          if (this.originData[i].title.indexOf(this.searchKeyword) > -1) {
            this.tableData.push(this.originData[i])
          }
        }
      } else {
        this.tableData = this.originData.slice(0)
      }
      if (this.tableData.length > 0) {
        this.tableMgmt.selectItems = this.tableData[0]
      } else {
        this.writer = ''
        this.period = ''
        this.detailTitle = ''
        this.detailContent = ''
      }
    },
    sortFunc (type) {
      // Mockup 데이터
      let data = this.tableData
      if (type) {
        data.sort(
          function (a, b) {
            return a.effDateStart.localeCompare(b.effDateStart)
          })
      } else {
        data.sort(
          function (a, b) {
            return b.effDateStart.localeCompare(a.effDateStart)
          })
      }
      this.sortType = !this.sortType
      this.tableMgmt.selectItems = this.tableData[0]
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    'tableMgmt.selectItems' () {
      let selectItem = {}
      selectItem = this.tableMgmt.selectItems
      if (selectItem) {
        this.writer = selectItem.writer
        this.period = selectItem.period
        this.detailTitle = selectItem.title
        this.detailContent = selectItem.detailContent
      }
    }
  },
  mounted () {
    this.tableData = this.originData.slice(0)
    this.tableMgmt.selectItems = this.tableData[0]
  }
}
</script>
