<template>
    <section>
        <fdp-popup class="-pub-popup" v-model="showPopup" title="가상고객 라이프분석 불러오기" :prevent-outside-close="true">
            <!-- slot 원하는 내용 -->
            <div class="-fdp-popup-page__slot">
                <div class="-pub-popup__content -pub-popup-consulting">
                    <fdp-infinite class="-pub-table" v-model="radioSelected" :items="itemsList" single-select>
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                                <th class="-pub-table-column" style="width: 162px;"  @click="sortFunc">
                                    <!-- sorting 활성화: -pub-sorting—active, 내림차순: defalt, 오름차순: -pub-sorting—up, 파란색: default, 보라색: -pub-sorting—purple -->
                                    <span class="-pub-table-column__text -pub-sorting—active -pub-sorting—up">
                                        분석일<img src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                                    </span>
                                </th>
                                <th class="-pub-table-column" style="width: 172px;">가족유형</th>
                                <th class="-pub-table-column" style="width: 190px;">저장명</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column--radiobox" style="width: 78px;">
                                <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item"></fdp-radio>
                            </td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 162px;">{{props.item.date}}</td>
                            <td class="-pub-table-column" style="width: 172px;">{{props.item.familytype}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 190px;">{{props.item.dataname}}</td>
                        </template>
                        <!-- no data 화면 -->
                        <template slot="emptyView" v-if="searchRes==='1'">
                            <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                            </div>
                        </template>
                    </fdp-infinite>
                </div>
                <div class="-pub-popup__button-area -pub-popup__button-area--shadow">
                    <button type="button" class="-pub-button -pub-button--180" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--180 -pub-button--reverse" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!-- slot 끝 -->
        </fdp-popup>
    </section>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      radioSelected: {},
      searchRes: 1,
      itemsList: [
        {
          date: '2017-04-30',
          familytype: '1인가족',
          dataname: '180830_1130'
        },
        {
          date: '2017-07-23',
          familytype: '부부+자녀',
          dataname: '180830_1130'
        },
        {
          date: '2017-07-23',
          familytype: '부부가족',
          dataname: '180830_1130'
        },
        {
          date: '2017-01-03',
          familytype: '1인가족',
          dataname: '180830_1130'
        },
        {
          date: '2017-01-03',
          familytype: '1인가족',
          dataname: '180830_1130'
        },
        {
          date: '2017-01-03',
          familytype: '1인가족',
          dataname: '180830_1130'
        }
      ]
    }
  },
  methods: {
    sortFunc () {
      // 디자인은 sort가 있는것으로 보이지만 기획서에는 기재된 것이 없음.
      // 추후 필요시 개발 필요
    }
  }
}
</script>
