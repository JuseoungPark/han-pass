<template>
    <div class="-pub-complete-tssps181d">

        <div class="-pub-ico-complete-wrap">
            <img class="-pub-ico-complete" src="@/assets/img/ico_complete.gif" alt="">
            <span v-if="test==='1'">신계약체결이<br>완료되었습니다.</span>
            <span v-if="test==='2'">제 1회 보험료 이체 신청이<br>완료되었습니다.</span>
            <span v-if="test==='3'">청약접수가<br>완료되었습니다. </span>
            <span class="-pub-complete-txt" v-if="test==='4'">전자서명이<br>완료되었습니다.</span>
            <div class="-pub-select-wrap" v-if="test==='4'">
                <span>서비스콜 통화시간(선택)</span>
                <fdp-select class="-pub-select" v-model="select1.value" :option-list="select1.items" placeholder="선택하세요"></fdp-select>
            </div>
        </div>
        <hr>

        <template v-if="test==='1'">
            <span class="-pub-text-1">삼성생명을 믿고 선택해주신 고객님께 다시 한 번 깊이 감사드리며,<br>
                고객님께 최상의 서비스를 제공할 수 있도록 항상 노력하겠습니다.</span>
            <div class="-pub-complete-step__wrap">
                <img class="-pub-complete-step__img" src="@/assets/img/img_complete_step_3.png" alt="">
                <span class="-pub-text-3">이체가 완료되었습니다.</span>
            </div>
        </template>

        <template v-if="test==='2'">
            <span class="-pub-text-1">삼성생명을 믿고 선택해주신 고객님께 다시 한 번 깊이 감사드리며,<br>
                고객님께 최상의 서비스를 제공할 수 있도록 항상 노력하겠습니다.</span>
            <div class="-pub-complete-step__wrap">
                <img class="-pub-complete-step__img" src="@/assets/img/img_complete_step_2.png" alt="">
                <button type="button" class="-pub-button -pub-button--light -pub-btn -pub-btn-transfer-result">이체결과 확인</button>
                <button type="button" class="-pub-btn-text-later">
                    <img src="@/assets/img/btn_text_later.png" alt="">
                </button>
            </div>
        </template>

        <template v-if="test==='3'">
            <span class="-pub-text-1">삼성생명을 믿고 선택해주신 고객님께 다시 한 번 깊이 감사드리며,<br>
                고객님께 최상의 서비스를 제공할 수 있도록 항상 노력하겠습니다.<br><br>
                보험료이체를 진행하여 신계약 체결을 완료하세요.</span>
            <div class="-pub-complete-step__wrap">
                <img class="-pub-complete-step__img" src="@/assets/img/img_complete_step_2.png" alt="">
                <button type="button" class="-pub-button -pub-button--light -pub-button--reverse -pub-btn -pub-btn-first-premium">초회보험료 <span>140,420원</span> 이체</button>
                <button type="button" class="-pub-btn-text-later">
                    <img src="@/assets/img/btn_text_later.png" alt="">
                </button>
            </div>
        </template>

        <template v-if="test==='4'">
            <span class="-pub-text-1">"통합유니버설종신보험3.0(무배당,보증비용부과형)" 전자서명이 완료되었습니다.<br>
                계약자의 휴대폰으로 발송된 보험계약서류를 확인해주세요.<br><br>
                지금 바로 접수와 보험료이체를 진행하여 신계약 체결을 완료하세요.</span>
            <div class="-pub-complete-step__wrap">
                <img class="-pub-complete-step__img" src="@/assets/img/img_complete_step_1.png" alt="">
                <button type="button" class="-pub-button -pub-button--light -pub-button--reverse -pub-btn -pub-btn-submission">청약 접수</button>
                <button type="button" class="-pub-btn-text-later">
                    <img src="@/assets/img/btn_text_later.png" alt="">
                </button>
            </div>
            <span class="-pub-text-2">※ 세금우대 신청을 원하시는 경우 지점에서 접수하셔야 합니다.</span>
        </template>

        <span class="-pub-text-2">※ 전자서명 계약서류는 고객님의 이메일로 발송되며 당사 홈페이지에서도 확인하실 수 있습니다.</span>
        <span class="-pub-text-2">※ 계약서류의 서면 교부 요청 시 5영업일 이내에 수령하실 수 있습니다.</span>

        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--full" v-show="test==='1'" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--medium -pub-button--reverse -pub-bottom-nav__item">
                        <span class="-pub-button__text">완료</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
</template>
<script>
export default {
  data () {
    return {
      select1: {
        value: {
          key: '',
          label: ''
        },
        items: [{
          key: '1',
          label: '00:00 ~ 01:00'
        },
        {
          key: '2',
          label: '01:00 ~ 02:00'
        },
        {
          key: '3',
          label: '02:00 ~ 03:00'
        }]
      }
    }
  },
  props: {
    test: {
      default: '1'
    }
  }
}
</script>
