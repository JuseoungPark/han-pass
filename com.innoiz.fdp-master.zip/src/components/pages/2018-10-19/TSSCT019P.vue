<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="세대요약형" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup -pub-consulting-popup--type-4">
        <div class="-pub-consulting-popup__default-info -pub-consulting-popup__default-info--fixed -pub-consulting-popup__default-info--no-padding-bottom">
          <div class="-pub-consulting-popup__default-content">
            <div class="-pub-consulting-popup__product-info -pub-consulting-popup__product-info--type-2">
              <h4 class="-pub-consulting-popup__product-name">가족 보유계약 현황</h4>
              <span class="-pub-consulting-popup__customer-info"><span class="-pub-serapetor-line normal-letter">2017.06.16
                  기준</span></span>
            </div>
            <div class="-pub-consulting-popup__contract-right-align">
              <div class="-pub-consulting-popup__contract-info">
                <p class="-pub-consulting-popup__contract-title">보유계약</p>
                <span class="-pub-consulting-popup__contract-value"><span class="bold-text">1</span>건</span>
              </div>
              <div class="-pub-consulting-popup__contract-info">
                <p class="-pub-consulting-popup__contract-title">월납입</p>
                <span class="-pub-consulting-popup__contract-value"><span class="bold-text">270,010</span>원</span>
              </div>
              <div class="-pub-consulting-popup__contract-info">
                <p class="-pub-consulting-popup__contract-title">총납입</p>
                <span class="-pub-consulting-popup__contract-value"><span class="bold-text">746,080</span>원</span>
              </div>
            </div>
          </div>
          <div class="-pub-consulting-popup__active-content">
            <h3 class="-pub-consulting-popup__title -pub-consulting-popup__title--type-5 ">
              <fdp-checkbox style="position:absolute; left: 0; top: 0; font-weight: normal;" class="-pub-checkbox"
                isIconCheckbox v-model="hideColumn">가족수 5명미만</fdp-checkbox>
              <div class="-pub-consulting-popup__unit">단위 : 만원</div>
            </h3>
            <table class="-pub-native-table">
              <thead>
                <tr>
                  <th class="-pub-table-column align-center" style="width: 366px;padding-right: 80px;">보장구분</th>
                  <th class="-pub-table-column">표준모델</th>
                  <th class="-pub-table-column">김하늘</th>
                  <th class="-pub-table-column">김남편</th>
                  <th class="-pub-table-column">{{hideColumn ? '-' : '김첫째'}}</th>
                  <th class="-pub-table-column">{{hideColumn ? '-' : '김둘째'}}</th>
                  <th class="-pub-table-column">{{hideColumn ? '-' : '김셋째'}}</th>
                </tr>
              </thead>
            </table>
            <div class="-pub-table-scroll-container">
              <table class="-pub-native-table -pub-native-table--body -pub-native-table--merge-row">
                <template v-for="(data, index) in tableData">
                  <tbody v-for="(column, index2) in data.columns" :key="'' + index + index2">
                    <tr v-for="(row, index3) in column.data" :key="'' + index + index2 + index3">
                      <td class="-pub-table-column" style="width: 200px;" v-if="index3 === 0" :rowspan="column.data.length">{{data.title}}</td>
                      <td class="-pub-table-column" style="width: 208px;">{{row.type}}</td>
                      <td class="-pub-table-column align-right normal-letter">10,000</td>
                      <td class="-pub-table-column align-right normal-letter">23,472</td>
                      <td class="-pub-table-column align-right normal-letter">5,033</td>
                      <td class="-pub-table-column align-right normal-letter">{{hideColumn ? '' : '5,033'}}</td>
                      <td class="-pub-table-column align-right normal-letter">{{hideColumn ? '' : '2,000'}}</td>
                      <td class="-pub-table-column align-right normal-letter">{{hideColumn ? '' : '5,033'}}</td>
                    </tr>
                  </tbody>
                </template>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  tableData
} from '@/components/mock/TSSCT019P.mock'
export default {
  data () {
    return {
      showSelectContent: true,
      showPopup: true,
      hideColumn: true,
      tableData: Array.prototype.slice.call(tableData)
    }
  },
  computed: {},
  methods: {}

}
</script>
