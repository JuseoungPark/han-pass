<template>
    <div class="-pub-content-scroll"><!-- -pub-fdp-list__empty-view 데이터가 없을 경우 클래스 추가 --><!-- 목업 추가 20181113 -->
        <div>
            <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="mockData" :list-height="877" ref="targetFdpList">
                <template slot="emptyView"><!-- 목업 변경 20181113 -->
                  <div class="-pub-table-empty-view">
                      <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                  </div>
                </template>
                <template slot="default" slot-scope="props">
                    <div class="-pub-accordion-container" v-for="(mock, index2) in props.item.data" :key="'b' + index2">
                        <div class="-pub-accordion-line">
                            <span class="-pub-accordion-line__text">{{mock.date}}</span>
                        </div>
                        <div class="-pub-accordion" :class="[mock.expand ? '-pub-accordion--expanded' : '']" >
                            <div class="-pub-accordion__title">
                                <div class="-pub-accordion__text -pub-accordion__text--type4">
                                    <div class="-pub-table-colmn__single-line--ellipsis">{{mock.type}}</div>
                                </div>
                                <div class="-pub-accordion__text -pub-accordion__text--campaign-category">
                                    <span class="-pub-table-colmn__single-line--ellipsis">{{mock.campaign_category}}</span>
                                </div>
                                <div class="-pub-accordion__text -pub-accordion__text--campaign-name">
                                    <div class="-pub-table-colmn__single-line--ellipsis">{{mock.campaign_name}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 년도 표시-->
                    <!-- <div class="-pub-accordion-container -pub-accordion-container--year">
                        <div class="-pub-accordion-line -pub-accordion-line--year">
                            <span class="-pub-accordion-line__text -pub-accordion-line__text--year">{{props.item.year}}</span>
                        </div>
                        <div class="-pub-accordion--empty"></div>
                    </div> -->
                </template>
            </fdp-list>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      mockData: [
        {
          year: 2017,
          data: [{
            date: '07.16',
            type: '캠페인',
            campaign_category: '세미나',
            campaign_name: '6월 소외고객 비대면 터치 캠페인'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '선물서비스',
            campaign_name: '사차유량고객리스트'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          },
          {
            date: '07.16',
            type: '캠페인',
            campaign_category: '시장개혁',
            campaign_name: '6~7월 핵심 필수 터치 고객'
          }
          ]
        },
        {
          year: 2016,
          data: [{
            date: '07.16',
            type: '고객참여',
            campaign_category: '현장행사',
            campaign_name: '지역단 골프 세미나 참여'
          },
          {
            date: '07.16',
            type: '고객참여',
            campaign_category: '현장행사',
            campaign_name: '지역단 골프 세미나 참여'
          }
          ]
        }
      ]
    }
  }
}
</script>
