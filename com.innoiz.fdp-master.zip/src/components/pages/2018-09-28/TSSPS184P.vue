<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="청약접수" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 청약접수 start -->
            <div class="-pub-offer-wrap">
                <div class="-pub-offer-input__form">
                    <dl class="-pub-offer-input__form--list -pub-offer-list01">
                        <dt class="-pub-offer-input__form--list-item-txt">신분증 진위여부 확인<span class="-pub-ico-check">*</span></dt>
                        <dd class="-pub-offer-input__form--list-item-cont">
                            <button type="button" class="-pub-button -pub-button--light -pub-button-offer" @click="exeApp" :disabled="isActive">
                                <span class="-pub-button__text">앱 실행하기</span>
                            </button>
                            <span class="-pub-check__ok" v-if="isActive">확인되었습니다.</span>
                        </dd>
                    </dl>
                    <dl class="-pub-offer-input__form--list -pub-offer-list02">
                        <dt class="-pub-offer-input__form--list-item-txt">친권자 연락처</dt>
                        <dd class="-pub-offer-input__form--list-item-cont">
                            <dl class="-pub-offer-input__form--list -pub-offer-deth01">
                                <dt class="-pub-offer-input__form--list-item-txt-name">성명<span class="-pub-ico-check">*</span></dt>
                                <dd class="-pub-offer-input__form--list-item-cont-name-input">
                                    <fdp-validator name="tssps184p-validator-1" v-model="name" display-name="성명" :rules="'required'">
                                        <input type="text" v-model="name" placeholder="입력하세요" class="-pub-form-input -pub-normal-letter" clearable/>
                                    </fdp-validator>
                                </dd>
                                <dt class="-pub-offer-input__form--list-item-txt-phone">휴대폰번호<span class="-pub-ico-check">*</span></dt>
                                <dd class="-pub-offer-input__form--list-item-cont-phone-input">
                                    <fdp-validator name="tssps184p-validator-2" v-model="phone" display-name="휴대폰번호" :rules="'required'">
                                        <input type="text" v-model="phone" placeholder="000-0000-0000" class="-pub-form-input -pub-normal-letter" clearable />
                                    </fdp-validator>
                                </dd>
                            </dl>
                            <dl class="-pub-offer-input__form--list -pub-offer-deth02">
                                <dt class="-pub-offer-input__form--list-item-txt-name">성명</dt>
                                <dd class="-pub-offer-input__form--list-item-cont-name-input">
                                    <input type="text" v-model="name1" placeholder="입력하세요" class="-pub-form-input -pub-normal-letter" clearable/>
                                </dd>
                                <dt class="-pub-offer-input__form--list-item-txt-phone">휴대폰번호</dt>
                                <dd class="-pub-offer-input__form--list-item-cont-phone-input">
                                    <input type="text" v-model="phone1" placeholder="000-0000-0000" class="-pub-form-input -pub-normal-letter" clearable />
                                </dd>
                            </dl>
                        </dd>
                    </dl>
                    <dl class="-pub-offer-input__form--list -pub-offer-list03">
                        <dt class="-pub-offer-input__form--list-item-txt">가상계좌 채번<span class="-pub-ico-check">*</span></dt>
                        <dd class="-pub-offer-input__form--list-item-cont">
                            <button type="button" class="-pub-button -pub-button--light -pub-button-offer" @click="exeVirtualAccount" :disabled="isSuccess">
                                <span class="-pub-button__text">신청하기</span>
                            </button>
                            <span class="-pub-check__ok" v-if="isSuccess">완료되었습니다.</span>
                        </dd>
                    </dl>
                    <dl class="-pub-offer-input__form--list -pub-offer-list04">
                        <dt class="-pub-offer-input__form--list-item-txt">수익자 동의<span class="-pub-ico-check">*</span></dt>
                        <dd class="-pub-offer-input__form--list-item-cont">
                            <button type="button" class="-pub-button -pub-button--light -pub-button-offer" @click="getAgreement" :disabled="isGet">
                                <span class="-pub-button__text">동의하기</span>
                            </button>
                            <span class="-pub-check__ok" v-if="isGet">완료되었습니다.</span>
                        </dd>
                    </dl>
                </div>
            </div>
            <!-- 청약접수 end -->
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--reverse" :disabled="isComplete">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      name: '',
      phone: '',
      name1: '',
      phone1: '',
      isActive: false,
      isSuccess: false,
      isGet: false
    }
  },
  methods: {
    exeApp () {
      this.isActive = !this.isActive
    },
    exeVirtualAccount () {
      this.isSuccess = !this.isSuccess
    },
    getAgreement () {
      this.isGet = !this.isGet
    }
  },
  computed: { // 필수값 기입 완료 시 활성화 처리
    isComplete () {
      if (this.isActive && this.isSuccess && this.isGet && this.name.length > 0 && this.phone.length > 0) { return false } else return true
    }
  }
}
</script>
