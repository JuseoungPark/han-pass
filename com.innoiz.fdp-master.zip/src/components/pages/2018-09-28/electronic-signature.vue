<template>
  <section class="-pub-customer-register -pub-electronic-signature">
    <div class="-pub-customer-register__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">전자서명</span>
      </h1>
      <fdp-stepper class="-pub-stepper -pub-electronic-signature__stepper" v-model="currentStep" :space="22" clickable>
          <fdp-step :step="1" :current="currentStep"></fdp-step>
          <fdp-step :step="2" :current="currentStep"></fdp-step>
          <fdp-step :step="3" :current="currentStep"></fdp-step>
      </fdp-stepper>
    </div>
    <div class="-pub-customer-register__content">
        <component :is="currentView" @move="moveEvent"></component>
    </div>
  </section>
</template>
<script>
import TSSPS121D from '@/components/pages/2018-09-28/TSSPS121D'
import TSSPS131D from '@/components/pages/2018-09-28/TSSPS131D'
import TSSPS141D from '@/components/pages/2018-09-28/TSSPS141D'

export default {
  components: {
    TSSPS121D,
    TSSPS131D,
    TSSPS141D
  },
  data () {
    return {
      currentStep: 1,
      currentView: '',
      viewList: [null, TSSPS121D, TSSPS131D, TSSPS141D, null],
      setpList: [
        {
          key: '1',
          status: 'done'
        },
        {
          key: '2',
          status: 'done'
        },
        {
          key: '3',
          status: ''
        }
      ],
      currentContent: {}
    }
  },
  mounted () {
    this.currentView = this.viewList[this.currentStep]
  },
  watch: {
    currentStep (newValue) {
      this.currentView = this.viewList[newValue]
    }
  },
  methods: {
    changeComponent (component) {
      this.currentContent = component
    },
    moveEvent (target) {
      if (target === 'previous') {
        this.currentStep--
      } else if (target === 'next') {
        this.currentStep++
      }
    }
  }
}
</script>
