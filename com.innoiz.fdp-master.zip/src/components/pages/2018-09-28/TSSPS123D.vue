<template>
    <!-- 비활성화시 fdp 컴포넌트에 disable 속성이 있는 것들은 개별처리 ex) dp-segment-box, fdp-text-field, fdp-checkbox -->
    <!-- 카드 인증 양식 -->
    <section>
        <!-- 툴팁 -->
        <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__row--card-auth-guide">
            <span>본인 명의의 체크,신용카드 정보로 인증을 진행합니다.<br>카드사 정책은 우측 도움말 버튼을 눌러 확인하세요</span>
            <fdp-tooltip-button class="-pub-tooltip-button">
                <template slot="activator">
                    <img class="tooltip-icon-img" src="@/assets/img/components/btn_info_gray.png" alt="주민등록번호 툴팁">
                </template>
                <template slot="content">
                    <h1>입력하신 정보는 본인확인을 목적으로 서울신용평가정보㈜에 제공되며,<br>저장되지 않습니다. 신용카드 본인 인증의 모든 절차는
                        무료입니다.</h1>
                    <h3>
                        <span>이용가능카드</span>
                        삼성, 엘지, 외환, 롯데, 신한, 하나, 축협(농협), 광주은행, 우리(평화),<br>
                        신세계(한미), 제주은행, 부산은행
                    </h3>
                </template>
            </fdp-tooltip-button>
        </div>
        <!-- 툴팁 end -->
        <!-- 카드번호 -->
        <div class="-pub-electronic-signature-form__row">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">카드번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tssps123d-validator-1" display-name="카드번호" v-model="cardCheck" :rules="'required'">
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo1" placeholder="0000" mask="####" :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo2" placeholder="0000" mask="####" :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo3" placeholder="0000" password mask="####" noIcon :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo4" placeholder="0000" password mask="####" noIcon :disabled="disabled"></fdp-text-field>
                </fdp-validator>
            </div>
        </div>
        <!-- 카드번호 end -->
        <!-- 유효기간 -->
        <div class="-pub-electronic-signature-form__row">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">유효기간</div>
            <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-4">
                <fdp-validator name="tssps123d-validator-2" display-name="유효기간" v-model="monthType.key" :rules="'required'">
                    <fdp-select class="-pub-electronic-signature-form__select--month" v-model="monthType" :option-list="monthTypes" placeholder="월" :disabled="disabled"></fdp-select>
                    <fdp-select class="-pub-electronic-signature-form__select--year" v-model="yearType" :option-list="yearTypes" placeholder="년" :disabled="disabled"></fdp-select>
                </fdp-validator>
            </div>
        </div>
        <!-- 유효기간 end -->
        <!-- 비밀번호 -->
        <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__row--pw" v-if="true">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">비밀번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tssps123d-validator-3" display-name="비밀번호" v-model="pw" :rules="'required'">
                    <fdp-text-field class="-pub-electronic-signature-form__input--pw" v-model="pw" placeholder="00" password mask="##" noIcon :disabled="disabled"></fdp-text-field>
                    <span class="-pub-electronic-signature-form__asterisk">**</span>
                </fdp-validator>
                <button type="button" class="-pub-button -pub-zipcode-button -pub-certno-button -pub-certno-confirm-button" @click="() => {authConfirm = true}" v-if="!authConfirm && !disabled" :disabled="disabled">인증확인</button>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--complete" v-else-if="!disabled">인증되었습니다.</span>
            </div>
        </div>
        <!-- 비밀번호 end -->
    </section>
    <!-- 카드 인증 양식 end -->
</template>
<script>
export default {
  props: {
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      authConfirm: false,
      cardNo1: '4330',
      cardNo2: '4330',
      cardNo3: '1234',
      cardNo4: '1234',
      monthTypes: [{
        key: '1',
        label: '1월'
      },
      {
        key: '2',
        label: '2월'
      },
      {
        key: '3',
        label: '3월'
      },
      {
        key: '4',
        label: '4월'
      }
      ],
      monthType: {
        key: '1',
        label: '1월'
      },
      yearTypes: [{
        key: '1',
        label: '18년'
      },
      {
        key: '2',
        label: '19년'
      },
      {
        key: '3',
        label: '20년'
      },
      {
        key: '4',
        label: '21년'
      }
      ],
      yearType: {
        key: '1',
        label: '18년'
      },
      pw: '11'
    }
  },
  computed: {
    cardCheck () {
      return this.cardNo1 !== '' && this.cardNo2 !== '' && this.cardNo3 !== '' && this.cardNo4 !== '' ? '1' : ''
    }
  }
}
</script>
