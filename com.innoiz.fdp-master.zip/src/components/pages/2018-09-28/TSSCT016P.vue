<template>
    <!-- 고객등록시 고객조회 팝업 start -->
    <fdp-popup class="-pub-annuity-add" v-model="showPopup" title="다른연금 추가하기">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-annuity-add_wrap">
                <div class="-pub-annuity-add_wrap--top">
                    <ul>
                        <li class="-pub-annuity-add_wrap--top-row01">
                            <label>희망 월 생활비</label>
                            <fdp-validator name="tssct016p-validator-1" display-name="희망 월 생활비" v-model="hopeamount" :rules="'required'">
                                <fdp-text-field v-model="hopeamount" clearable></fdp-text-field>
                            </fdp-validator><span>만원</span>
                        </li>
                        <li class="-pub-annuity-add_wrap--top-row02">
                            <label>연금정보<span class="-pub-ico-check">*</span></label>
                                <fdp-radio v-model="radioStrValue" class="-pub-radio" value="연금액 계산하기">연금액 계산하기</fdp-radio>
                                <fdp-radio v-model="radioStrValue" class="-pub-radio" value="직접입력하기">직접입력하기</fdp-radio>
                        </li>
                    </ul>
                    <div class="-pub-annuity-add_wrap--top-right">
                        <button type="button" class="-pub-button -pub-button--light -pub-button-auto" @click="autoInput">
                            <span class="-pub-button__text">자동입력하기</span>
                        </button>
                    </div>
                </div>
                <div class="-pub-annuity-add_wrap--cont">
                    <table class="-pub-annuity-add_wrap--cont-table">
                        <colgroup>
                            <col width="302px">
                            <col width="406px">
                            <col width="388px">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>구분</th>
                                <th>수령연령</th>
                                <th>월연금액</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>타사연금</td>
                                <td class="-pub-age01">
                                    <fdp-validator name="tssct016p-validator-2" display-name="수령연령" v-model="endage" :rules="'required'">
                                        <fdp-text-field v-model="endage" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-age">세</span>
                                    <span class="-pub-wave">~</span>
                                    <fdp-validator name="tssct016p-validator-3" display-name="수령연령" v-model="endage2" :rules="'required'">
                                        <fdp-text-field v-model="endage2" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-age-last">세</span>
                                </td>
                                <td class="-pub-money01">
                                    <fdp-validator name="tssct016p-validator-4" display-name="월연금액" v-model="earnings" :rules="'required'">
                                        <fdp-text-field v-model="earnings" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-money">만원</span>
                                </td>
                            </tr>
                            <tr>
                                <td>국민연금</td>
                                <td class="-pub-age02">
                                    <fdp-validator name="tssct016p-validator-5" display-name="수령연령" v-model="endage3" :rules="'required'">
                                        <fdp-text-field v-model="endage3" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-age">세</span>
                                    <span class="-pub-wave">~</span>
                                </td>
                                <td class="-pub-money02">
                                    <fdp-validator name="tssct016p-validator-6" display-name="월연금액" v-model="earnings2" :rules="'required'">
                                        <fdp-text-field v-model="earnings2" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-money">만원</span>
                                </td>
                            </tr>
                            <tr>
                                <td>퇴직연금</td>
                                <td class="-pub-age03">
                                    <fdp-validator name="tssct016p-validator-7" display-name="수령연령" v-model="endage4" :rules="'required'">
                                        <fdp-text-field v-model="endage4" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-age">세</span>
                                    <span class="-pub-wave">~</span>
                                </td>
                                <td class="-pub-money03">
                                    <fdp-validator name="tssct016p-validator-8" display-name="월연금액" v-model="earnings3" :rules="'required'">
                                        <fdp-text-field v-model="earnings3" clearable></fdp-text-field>
                                    </fdp-validator><span class="-pub-money">만원</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <span class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-guide-text align-left">※ 통합연금포털에 가입하시면 고객님의 연금액을 확인하실 수 있습니다.</span>
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                    <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
<!-- 고객등록시 고객조회 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: ''
      },
      hopeamount: '',
      radioSelected: '',
      radioStrValue: '직접입력하기',
      showPopup: true,
      endage: '',
      endage2: '',
      endage3: '',
      endage4: '',
      earnings: '',
      earnings2: '',
      earnings3: ''
    }
  },
  methods: {
    autoInput () {

    }
  }
}
</script>
