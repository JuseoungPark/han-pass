<template>
    <!-- 고객등록시 고객조회 팝업 start -->
    <fdp-popup class="-pub-confirm -pub-confirm-type-6 -pub-customer-search" v-model="showPopup" title="고객검색">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-confirm__content -pub-confirm__content--left">
                <div class="-pub-confirm__content--left -pub-confirm__content--main-pop">
                <!-- 페이지 조회 input, button 검색 건 영역  -->
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{searchResult.length}}건</div>
                <div class="-pub-filter-menu">
                    <div class="-pub-filter-menu__item--right">
                        <fdp-text-field class="-pub-filter-menu__item -pub-search-input"
                            placeholder="고객명" v-model="searchKeywordAddMember" clearable style="width: 286px; height: 56px;"></fdp-text-field>
                        <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="clickSearchKeyword">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon"
                                alt="조회">조회
                        </button>
                    </div>
                </div>
                <!-- 페이지 조회 input, button 검색 명수 영역 end  -->
                <fdp-infinite class="-pub-table -pub-table-blue" v-model="radioSelected" single-select :items="searchResult">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                            <th class="-pub-table-column" style="width: 172px;">고객명</th>
                            <th class="-pub-table-column" style="width: 230px;">주민등록번호(앞)</th>
                            <th class="-pub-table-column" style="width: 130px;">성별</th>
                            <th class="-pub-table-column" style="width: 130px;">주고객</th>
                            <th class="-pub-table-column" style="width: 130px;">관계</th>
                            <th class="-pub-table-column" style="width: 130px;">고객구분</th>
                            <th class="-pub-table-column" style="width: 262px;">연락처</th>
                        </tr>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView">
                        <div class="empty-table-content">
                            <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text"><!-- 검색 전 문구 : 고객명 입력 후 검색해 주세요. --><!-- 검색 결과가 없는 경우 문구 : 입력된 고객은 등록되어 있지 않습니다.--></div>
                            <div class="empty-table-content__text" v-if="isEmptySearchKeyword"> 고객명 입력 후 검색해 주세요. </div>
                            <div class="empty-table-content__text" v-else> 입력된 고객은 등록되어 있지 않습니다. </div>
                        </div>
                    </template>
                    <template slot-scope="props" v-if="!isEmptySearchKeyword">
                        <td class="-pub-table-column--radiobox" style="width: 78px; padding-left: 22px;padding-top: 5px;">
                            <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item"></fdp-radio>
                        </td>
                        <td class="-pub-table-column -pub-table-column--name" style="width: 172px;">{{props.item.name}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 230px;">{{props.item.jumin}}</td>
                        <td class="-pub-table-column" style="width: 130px;">{{props.item.gender}}</td>
                        <td class="-pub-table-column" style="width: 130px;">{{props.item.maincustomer}}</td>
                        <td class="-pub-table-column" style="width: 130px;">{{props.item.conectivity}}</td>
                        <td class="-pub-table-column" style="width: 130px;">{{props.item.customervalue}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 262px;">{{props.item.phone}}</td>
                    </template>
                </fdp-infinite>
                </div>
            </div>
           <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--reverse"> <!-- :disabled="radioSelected.length === 0"-->
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
<!-- 고객등록시 고객조회 팝업 end -->
</template>
<script>
import mockData from '@/components/mock/TSSCM212P.mock'
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: '',
        password: '',
        masking: '',
        fixedIcon: '',
        tableBodyHeight: 296,
        disabled: 'text not editable',
        readonly: 'text not editable'
      },
      radioSelected: [],
      searchKeywordAddMember: '',
      searchKeyword: '',
      isEmptySearchKeyword: true,
      searchResult: [],
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData),
      mockHeader: []
    }
  },
  methods: {
    clickSearchKeyword () {
      this.searchKeyword = this.searchKeywordAddMember
    }
  },
  watch: {
    // 고객명을 '이주명'으로 검색 시 검색결과 나오게 설정
    searchKeyword () {
      if (this.searchKeyword === '') {
        this.isEmptySearchKeyword = true
        this.searchResult = []
      } else if (this.searchKeyword === '이주명') {
        this.isEmptySearchKeyword = false
        this.searchResult = this.mockData
      } else {
        this.isEmptySearchKeyword = false
        this.searchResult = []
      }
    }
  }
}
</script>
