<template>
    <!-- 비활성화시 fdp 컴포넌트에 disable 속성이 있는 것들은 개별처리 ex) dp-segment-box, fdp-text-field, fdp-checkbox -->
    <!-- 휴대전화 인증 양식 -->
    <section>
        <!-- 본인확인 서비스 이용 동의 -->
        <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__row--id-use-agreement">
            <fdp-checkbox class="-pub-checkbox" v-model="singleCheckbox1" :disabled="disabled"></fdp-checkbox>
            <span>본인확인 서비스 이용 동의</span>
        </div>
        <!-- 본인확인 서비스 이용 동의 end -->
        <!-- 휴대폰번호 -->
        <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__row--mobile-number">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">휴대폰번호</div>
            <div class="-pub-customer-register-form__content -pub-customer-register-form__content--layer-4">
                <fdp-validator name="tssps122d-validator-1" v-model="mobileNumber" display-name="휴대폰번호" :rules="'required'">
                    <!-- 181029 ellipsis 옵션추가 -->
                    <fdp-select class="-pub-electronic-signature-form__select--telecom" v-model="telecomType" :option-list="telecomTypes" :disabled="disabled" ellipsis>
                    </fdp-select><fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--mobile-number" v-model="mobileNumber" placeholder="000-0000-0000" :disabled="disabled"></fdp-text-field>
                </fdp-validator>
                <button type="button" class="-pub-button -pub-zipcode-button -pub-certno-button" :disabled="disabled" v-if="isBeforeSend" @click="onSend">인증번호 전송</button>
                <button type="button" class="-pub-button -pub-zipcode-button -pub-certno-button" :disabled="disabled" v-else @click="onReSend">인증번호 재전송</button>
            </div>
        </div>
        <!-- 휴대폰번호 end -->
        <!-- 인증번호 -->
        <div class=" -pub-electronic-signature-form__row -pub-electronic-signature-form__row--certification-number">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">인증번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tssps122d-validator-2" v-model="authNumber" display-name="인증번호" :rules="'required'" hide-error>
                  <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--certification-number" placeholder="인증번호 입력" v-model="authNumber" :disabled="disabled"></fdp-text-field>
                </fdp-validator>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--complete" v-if="authNumber.length > 2 && authNumber.length <= 3">인증되었습니다.</span>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--error" v-if="authNumber.length > 3 && authNumber.length <= 4">인증번호 오류입니다.</span>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--guide" v-if="!isBeforeSend">인증번호 만료까지 <strong>2:56</strong></span>
            </div>
        </div>
        <!-- 인증번호 end -->
        <div class=" -pub-electronic-signature-form__row -pub-electronic-signature-form__row--cert-no-guide">
            <span>인증번호가 도착하지 않은 경우 아래와 같이 조치 부탁드립니<br>다. 휴대폰 스팸번호 분류 확인<br>NICE 인증 고객센터 문의</span>
            <!-- 2018-10-26 전화번호 수정 -->
            <span class="-pub-button--service-center">1600-1522</span>
            <span class="-pub-button--service-center-dim">1600-1522</span>
        </div>
    </section>
    <!-- 휴대전화 인증 양식 end -->
</template>
<script>
export default {
  props: {
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      isBeforeSend: true,
      singleCheckbox1: false,
      // [ 181029 휴대폰사업자 선택 목록 수정
      telecomTypes: [{
        key: '1',
        label: 'SKT'
      },
      {
        key: '2',
        label: 'KT'
      },
      {
        key: '3',
        label: 'LG U+'
      },
      {
        key: '4',
        label: 'SKT (알뜰폰)'
      },
      {
        key: '5',
        label: 'KT (알뜰폰)'
      },
      {
        key: '6',
        label: 'LG U+ (알뜰폰)'
      },
      {
        key: '7',
        label: '알뜰폰 확인하기'
      }
      ],
      telecomType: {
        key: '1',
        label: 'SKT'
      },
      // 181029 휴대폰사업자 선택 목록 수정 ]
      mobileNumber: '',
      authNumber: ''
    }
  },
  methods: {
    onSend () {
      this.isBeforeSend = false
    },
    onReSend () {
      this.isBeforeSend = true
    }
  }
}
</script>
