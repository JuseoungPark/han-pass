<template>
    <!-- step1 -->
    <section class="-pub-electronic-signature__step-content">
        <!-- 계약자 폼양식 -->
        <form class="-pub-form -pub-customer-register-form -pub-electronic-signature-form--contractor">
            <div class="-pub-electronic-signature__step-title -pub-electronic-signature__step-title--contractor" :class="cardOne.state === '3' ? '-pub-completed' : ''">
                <label class="-pub-badge-tag -pub-electronic-signature__tag--contractor">계약자</label><span>이주명</span>
                <!-- 동의 완료시 v-if true로 전환시 등의완료 아이콘 나타남 -->
                <span class="-pub-electronic-signature__completed" v-if="cardOne.state === '3'">동의완료</span>
                <button type="button" class="-pub-button -pub-button--light -pub-button-later" v-if="cardOne.state === '1'" @click="doLater(1)">나중에 하기</button>
                <button type="button" class="-pub-button -pub-button--light -pub-button-later" v-if="cardOne.state === '2'" @click="doCertify(1)">인증하기</button>
            </div>
            <!-- 계약자 본인인증 동의서 화면 template tag true로 전환시 동의서 및 본인인증 form 나타남 -->
            <div v-show="isOpenContractor">
                <div class="-pub-electronic-signature__container--agreement">
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">본인인증 동의서</h2>
                    <!-- step sub title end -->

                    <!-- 동의 항목 list -->
                    <ul class="-pub-electronic-signature__step--agreement">
                        <li class="-pub-electronic-signature__step--agree-all" :class="{'-pub-electronic-signature__step--active': cardOne.isAllAgree}">
                            <span class="-pub-text -pub-customer-register-form__item">본인인증 동의에 관한 사항</span><fdp-checkbox class="-pub-checkbox -pub-customer-register-form__item" v-model="cardOne.isAllAgree" @click.native="onSelectAgreeAll(1)">전체동의</fdp-checkbox>
                        </li>
                        <!-- -pub-accordion-open 아코디언 펼쳐짐 -->
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[0].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[0].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="1">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[0].opened=!requiredAgreementContent[0].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[0].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[1].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[1].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="2">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[1].opened=!requiredAgreementContent[1].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[1].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[2].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[2].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="3">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[2].opened=!requiredAgreementContent[2].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[2].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item -pub-accordion__item__sub" :class="{'-pub-accordion-open': requiredAgreementContent[3].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[3].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="4">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[3].opened=!requiredAgreementContent[3].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[3].content}}
                                </span>
                            </div>
                            <div class="-pub-accordion__sub-content">
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="phone">질병·상해정보 처리</fdp-checkbox>
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="text">주민등록번호·외국인등록번호 처리</fdp-checkbox>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[4].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[4].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="5">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[4].opened=!requiredAgreementContent[4].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[4].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[5].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent[5].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardOne.agreeCheckboxList" value="6">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[5].opened=!requiredAgreementContent[5].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent[5].content}}
                                </span>
                            </div>
                        </li>
                    </ul>
                    <!-- 동의 항목 list end -->
                </div>
                <!-- 계약자 본인인증 동의서 화면 end -->

                <!-- 계약자 신원확인 및 본인인증 화면 -->
                <!-- 좌측 본인인증 동의 전체 체크 시 영역 활성화됨. -pub-electronic-signature__container--id-verification--disabled 를 넣어주면 비활성화 -->
                <!-- fdp 컴포넌트에 disable 속성이 있는 것들은 개별처리 ex) dp-segment-box, fdp-text-field, fdp-checkbox -->
                <div class="-pub-electronic-signature__container--id-verification" :class="{'-pub-electronic-signature__container--id-verification--disabled' : !cardOne.isAllAgree}">
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">신원확인 및 본인인증</h2>
                    <!-- step sub title end -->
                    <div class="-pub-customer-register__container">
                        <!-- 인증방식 -->
                        <div class=" -pub-electronic-signature-form__row -pub-electronic-signature-form__row--auth-type">
                            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">인증방식</div>
                            <div class="-pub-customer-register-form__content">
                                <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item" v-model="authType1" :data="authTypes" :disabled="!cardOne.isAllAgree" essential></fdp-segment-box>
                            </div>
                        </div>
                        <!-- 인증방식 end -->
                        <TSSPS122D v-if="authType1[0].key === '1'" :disabled="!cardOne.isAllAgree"></TSSPS122D>
                        <TSSPS123D v-else :disabled="!cardOne.isAllAgree"></TSSPS123D>
                    </div>
                </div>
                <!-- 계약자 신원확인 및 본인인증 화면 end -->
            </div>
        </form>
        <!-- 계약자 폼양식 end -->

        <!-- 피보험자 폼양식 -->
        <form class="-pub-form -pub-customer-register-form -pub-electronic-signature-form--insured-person">

            <div class="-pub-electronic-signature__step-title -pub-electronic-signature__step-title--contractor" :class="cardTwo.state === '3' ? '-pub-completed' : ''">
                <label class="-pub-badge-tag -pub-electronic-signature__tag--insured-person">피보험자</label><span>김서현</span>
                <!-- 동의 완료시 v-if true로 전환시 등의완료 아이콘 나타남 -->
                <span class="-pub-electronic-signature__completed" v-if="cardTwo.state === '3'">동의완료</span>
                <button type="button" class="-pub-button -pub-button--light -pub-button-later" v-if="cardTwo.state === '1'" @click="doLater(2)">나중에 하기</button>
                <button type="button" class="-pub-button -pub-button--light -pub-button-later" v-if="cardTwo.state === '2'" @click="doCertify(2)">인증하기</button>
            </div>

            <!-- 피보험자 본인인증 동의서 화면 template tag true로 전환시 동의서 및 본인인증 form 나타남 -->
            <div v-show="!isOpenContractor">
                <div class="-pub-electronic-signature__container--agreement">
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">본인인증 동의서</h2>
                    <!-- step sub title end -->

                    <!-- 동의 항목 list -->
                    <ul class="-pub-electronic-signature__step--agreement">
                        <!-- 모두 확인 동의시 -pub-electronic-signature__step--active 추가 -->
                        <li class="-pub-electronic-signature__step--agree-all" :class="{'-pub-electronic-signature__step--active': cardTwo.isAllAgree}">
                            <span class="-pub-text -pub-customer-register-form__item">본인인증 동의에 관한 사항</span><fdp-checkbox class="-pub-checkbox -pub-customer-register-form__item" v-model="cardTwo.isAllAgree" @click.native="onSelectAgreeAll(2)">전체동의</fdp-checkbox>
                        </li>
                        <!-- -pub-accordion-open 아코디언 펼쳐짐 -->
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent2[0].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent2[0].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardTwo.agreeCheckboxList" value="1">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent2[0].opened=!requiredAgreementContent2[0].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent2[0].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item " :class="{'-pub-accordion-open': requiredAgreementContent2[1].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent2[1].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardTwo.agreeCheckboxList" value="2">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent2[1].opened=!requiredAgreementContent2[1].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>전문내용 영역<br><br>
                                {{requiredAgreementContent2[1].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent2[2].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent2[2].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardTwo.agreeCheckboxList" value="3">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent2[2].opened=!requiredAgreementContent2[2].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>
                                    전문내용 영역<br><br>
                                    {{requiredAgreementContent2[2].content}}
                                </span>
                            </div>
                        </li>
                        <li class="-pub-accordion__item -pub-accordion__item__sub" :class="{'-pub-accordion-open': requiredAgreementContent2[3].opened}">
                            <div class="-pub-accordion__header">
                                <span class="-pub-text">{{requiredAgreementContent2[3].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="cardTwo.agreeCheckboxList" value="4">동의함</fdp-checkbox>
                                <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent2[3].opened=!requiredAgreementContent2[3].opened}">
                            </div>
                            <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>전문내용 영역<br><br>
                                {{requiredAgreementContent2[3].content}}
                                </span>
                            </div>
                            <div class="-pub-accordion__sub-content">
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="phone">질병·상해정보 처리</fdp-checkbox>
                                <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="text">주민등록번호·외국인등록번호 처리</fdp-checkbox>
                            </div>
                        </li>
                    </ul>
                    <!-- 동의 항목 list end -->
                </div>
                <!-- 피보험자 본인인증 동의서 화면 end -->

                <!-- 피보험자 신원확인 및 본인인증 화면 -->
                <div class="-pub-electronic-signature__container--id-verification" :class="{'-pub-electronic-signature__container--id-verification--disabled' : !cardTwo.isAllAgree}">
                    <!-- step sub title -->
                    <h2 class="-pub-customer-register__step-title">신원확인 및 본인인증</h2>
                    <!-- step sub title end -->
                    <div class="-pub-customer-register__container">
                        <!-- 인증방식 -->
                        <div class=" -pub-electronic-signature-form__row -pub-electronic-signature-form__row--auth-type">
                            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">인증방식</div>
                            <div class="-pub-customer-register-form__content">
                                <fdp-segment-box class="-pub-segment__container -pub-segment--medium -pub-customer-register-form__item" v-model="authType2" :data="authTypes" :disabled="!cardTwo.isAllAgree"></fdp-segment-box>
                            </div>
                        </div>
                        <!-- 인증방식 end -->
                        <TSSPS122D v-if="authType2[0].key === '1'" :disabled="!cardTwo.isAllAgree"></TSSPS122D>
                        <TSSPS123D v-else :disabled="!cardTwo.isAllAgree"></TSSPS123D>
                    </div>
                </div>
                <!-- 피보험자 신원확인 및 본인인증 화면 end -->
            </div>
        </form>
        <!-- 피보험자 폼양식 -->
    </section>
</template>
<script>
import TSSPS122D from '@/components/pages/2018-09-28/TSSPS122D'
import TSSPS123D from '@/components/pages/2018-09-28/TSSPS123D'

export default {
  components: {
    TSSPS122D,
    TSSPS123D
  },
  data () {
    return {
      cardOne: {
        state: '1',
        allItems: ['1', '2', '3', '4', '5', '6'],
        agreeCheckboxList: [],
        marketingCheckboxList: [],
        isAllAgree: false

      },
      cardTwo: {
        state: '2',
        allItems: ['1', '2', '3', '4'],
        agreeCheckboxList: [],
        marketingCheckboxList: [],
        isAllAgree: false

      },
      isOpenContractor: true,
      agreeCheckboxList: [],
      marketingCheckboxList: [],
      singleCheckbox1: false,
      singleCheckbox2: false,
      singleCheckbox3: false,
      singleCheckbox4: false,
      singleCheckbox5: false,
      singleCheckbox6: false,
      singleCheckbox7: false,
      singleCheckbox8: true,
      singleCheckbox9: true,
      singleCheckbox10: true,
      singleCheckbox11: true,
      singleCheckbox12: true,
      singleCheckbox13: true,
      singleCheckbox14: true,
      // [ 181029 인증방식 텍스트 수정
      authTypes: [{
        key: '1',
        label: '휴대폰'
      },
      {
        key: '2',
        label: '신용카드'
      }],
      authType1: [{
        key: '1',
        label: '휴대폰'
      }],
      // 181029 인증방식 텍스트 수정 ]
      authType2: [{
        key: '2',
        label: '신용카드'
      }],
      requiredAgreementContent: [
        {
          opened: false,
          title: '1. 개인(신용)정보 수집 · 이용 동의에 관한 사항',
          content: `이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.
이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.`
        },
        {
          opened: false,
          title: '2. 개인(신용)정보 조회에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '3. 개인(신용)정보 등의 제공에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '4. 민감정보 및 고유식별정보 처리에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '5. 전자적 방법에 의한 계약체결 동의',
          content: ``
        },
        {
          opened: false,
          title: '6. 전자적 방법에 의한 보험계약서류 수령동의',
          content: ``
        }
      ],
      requiredAgreementContent2: [
        {
          opened: false,
          title: '1. 개인(신용)정보 수집 · 이용 동의에 관한 사항',
          content: `이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.
이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI),
휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보
정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며,
이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인
(부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수
있는지도 함께 안내합니다.`
        },
        {
          opened: false,
          title: '2. 개인(신용)정보 조회에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '3. 개인(신용)정보 등의 제공에 관한 사항',
          content: ``
        },
        {
          opened: false,
          title: '4. 민감정보 및 고유식별정보 처리에 관한 사항',
          content: ``
        }
      ]
    }
  },
  watch: {
    isOpenContractor (newValue) {
      if (newValue) {
        // 계약자 카드 열릴때
        if (this.cardOne.isAllAgree) {
          this.cardOne.state = '3'
        } else {
          this.cardOne.state = '1'
        }
        if (this.cardTwo.isAllAgree) {
          this.cardTwo.state = '3'
        } else {
          this.cardTwo.state = '2'
        }
      } else {
        // 피계약자 카드 열릴때
        // 계약자 동의 전이면 cardOne.state는 2(인증하기 버튼), 동의 후면 cardOne.state는 3(동의완료 텍스트)
        if (this.cardOne.isAllAgree) {
          this.cardOne.state = '3'
        } else {
          this.cardOne.state = '2'
        }
        if (this.cardTwo.isAllAgree) {
          this.cardTwo.state = '3'
        } else {
          this.cardTwo.state = '1'
        }
      }
    },
    'cardOne.agreeCheckboxList' (newValue) {
      if ((newValue.length === this.cardOne.allItems.length && !this.cardOne.isAllAgree) ||
          (newValue.length !== this.cardOne.allItems.length && this.cardOne.isAllAgree)) {
        this.cardOne.isAllAgree = !this.cardOne.isAllAgree
      }
    },
    'cardTwo.agreeCheckboxList' (newValue) {
      if ((newValue.length === this.cardTwo.allItems.length && !this.cardTwo.isAllAgree) ||
          (newValue.length !== this.cardTwo.allItems.length && this.cardTwo.isAllAgree)) {
        this.cardTwo.isAllAgree = !this.cardTwo.isAllAgree
      }
    }
  },
  methods: {
    doLater (cardNumber) {
      this.isOpenContractor = !this.isOpenContractor
      if (cardNumber === 1) {

      } else {

      }
    },
    doCertify (cardNumber) {
      this.isOpenContractor = !this.isOpenContractor
    },
    onSelectAgreeAll (cardNumber) {
      if (cardNumber === 1) {
        this.cardOne.agreeCheckboxList = this.cardOne.isAllAgree ? this.cardOne.allItems : []
      } else {
        this.cardTwo.agreeCheckboxList = this.cardTwo.isAllAgree ? this.cardTwo.allItems : []
      }
    }
  }
}
</script>
