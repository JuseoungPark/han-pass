<template>
    <section class="-pub-electronic-signature__step-content">
        <form class="-pub-form -pub-customer-register-form">
            <div class="-pub-account-info">
                <div class="-pub-account-info__setting">
                    <span class="-pub-setting__info--title">계좌선택</span>
                    <div class="-pub-scroll" ref="leftScroll">
                        <div v-for="accountItem in accountList" :key="accountItem.index" class="-pub-account-box"
                        :class="accountItem.index === currentAccountIdx ? '-pub-account-selected' : ''"
                        @click="accountClick(accountItem.index)">
                            <span class="-pub-bank-name">{{accountItem.bankLabel}}</span>
                            <span class="-pub-account-no">{{accountItem.accountNo}}</span>
                            <span class="-pub-account-owner">{{accountItem.accountOwner}}</span>
                        </div>
                        <div v-if="newAccountReq === true" class="-pub-create-account-form" ref="newAccountScroll">
                            <span class="-pub-create-account-form__title">새로운 계좌 추가</span>
                            <button type="button" class="-pub__button--close"  @click="closeNewAccountReq">
                                <img src="@/assets/img/components/btn_close_light.png" alt="close">
                            </button>
                            <ul>
                                <li class="-pub-create-account-form__item">
                                    <label>금융기관</label>
                                    <fdp-validator name="tssps141d-validator-1" display-name="금융기관" v-model="bankSelect.key" :rules="'required'">
                                        <fdp-select v-model="bankSelect" :option-list="bankList"></fdp-select>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-create-account-form__item -pub-normal-letter">
                                    <label>계좌번호</label>
                                    <fdp-validator name="tssps141d-validator-2" display-name="계좌번호" v-model="accontNo" :rules="'required'">
                                        <fdp-text-field v-model="accontNo"></fdp-text-field>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-create-account-form__item">
                                    <label>예금주</label>
                                    <fdp-validator name="tssps141d-validator-3" display-name="예금주" v-model="accountOwner" :rules="'required'">
                                        <fdp-text-field v-model="accountOwner" disabled></fdp-text-field>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-create-account-form__item">
                                    <label>생년월일</label>
                                    <fdp-validator name="tssps141d-validator-4" display-name="생년월일" v-model="returnDate" :rules="'required'">
                                        <fdp-date-picker class="-pub-date-picker" v-model="returnDate" disabled></fdp-date-picker>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-create-account-form__item">
                                    <button type="button" class="-pub-button -pub-button--light" @click="addnewAccount">확인</button>
                                </li>
                            </ul>
                            <span class="-pub-create-account-form__notice">※ 기업은행 평생계좌는 실시간 출금이체가 불가능<br>
합니다. 타 계좌를 입력하여 주시기 바랍니다.</span>
                        </div>
                        <button type="button" class="-pub-button -pub-button__add-account" @click="openNewAccountReq">
                            <span>새로운 계좌 추가</span>
                        </button>
                    </div>
                </div>
                <div class="-pub-account-info__setting">
                    <span class="-pub-setting__info--title">자동이체 및 실시간 출금이체 신청</span>
                    <div class="-pub-scroll">
                        <div class="-pub-account__transfer-setting">
                            <div class="-pub-account__transfer-setting--tit">
                                <span>제 1회 (부활)</span>
                                <span>보험료 실시간 출금이체</span>
                            </div>
                            <div class="-pub-account__transfer-setting--cont">
                                <div class="-pub-account__transfer-setting--cont__row">
                                    <label>신청여부</label>
                                    <fdp-validator name="tssps141d-validator-5" display-name="신청여부" v-model="returnData55" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--large -pub-segment__container" v-model="returnData55" :data="segmentData55"></fdp-segment-box>
                                    </fdp-validator>
                                    <!-- <fdp-checkbox class="-pub-checkbox -pub-check-label" v-model="checkValue" value="aaa">확인, 동의합니다.</fdp-checkbox> -->
                                </div>
                            </div>
                        </div>
                        <div class="-pub-account__transfer-setting">
                            <div class="-pub-account__transfer-setting--tit">
                                <span>제 2회 이후</span>
                                <span>보험료 자동이체 및 실시간 출금 이체</span>
                            </div>
                            <div class="-pub-account__transfer-setting--cont">
                                <div class="-pub-account__transfer-setting--cont__row">
                                    <label>신청여부</label>
                                    <fdp-validator name="tssps141d-validator-6" display-name="신청여부" v-model="returnData5" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--large -pub-segment__container" v-model="returnData5" :data="segmentData5"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-account__transfer-setting--cont__row">
                                    <label>이체 대상</label>
                                    <fdp-validator name="tssps141d-validator-7" display-name="이체 대상" v-model="returnData6" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--large -pub-segment__container" v-model="returnData6" :data="segmentData6"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-account__transfer-setting--cont__row">
                                    <label>이체 희망일</label>
                                    <fdp-validator name="tssps141d-validator-8" display-name="이체 희망일" v-model="returnData7" :rules="'required'">
                                            <fdp-segment-box class="-pub-segment--xsmall -pub-segment__container" v-model="returnData7" :data="segmentData7"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </div>
                        </div>
                        <span class="-pub-account__transfer-setting--additional-info">실시간 출금이체란 예금주가 전화, 방문 등의 방법으로 보험료(이자) 이체를 신청하는<br>
                            경우 실시간으로 출금이체하는 것을 말합니다. 다만 2회 이후 보험료는 계약자와<br>
                            예금주가 같은 경우에만 가능합니다.</span>
                        <div class="-pub-account__transfer-setting -pub-box" v-if="true">
                            <div class="-pub-account__transfer-setting--cont -pub-account__transfer-setting--cont02">
                                <div class="-pub-account__transfer-setting--cont__row">
                                    <label>분할·배당·연금/휴면 보험금<br>
                                            자동 송금 신청</label>
                                    <fdp-validator name="tssps141d-validator-9" display-name="자동 송금 신청" v-model="returnData8" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--medium -pub-segment__container" v-model="returnData8" :data="segmentData8"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </div>
                        </div>
                        <span class="-pub-account__transfer-setting--additional-info -pub-margin40" v-if="true">계약자에게 지급된(분할·배당·연금/휴면보험금) 금액 발생시 별도 통보 없이 신청하신<br>
                        자동이체 계좌로 입금됩니다. 다만, 계약자와 예금주가 같은 경우에만 가능합니다.<br>
                        단, 보험계약 약관 등에 따라 별도의 신청(연금지급개시신청 등)이나<br>
                        청구가 필요한 경우에는 자동송금이 불가합니다.</span>
                    </div>
                </div>
            </div>
            <!-- 이전, 다음 버튼 bottom bar -->
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full" v-show="true">
                <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-account-info__bottom-text">
                    <span>실시간 출금이체 가능 금융기관: 경남·광주·국민·기업·농협·대구·부산·신한·외환·우리·우체국·전북·SC·제주·하나·씨티·삼성증권·유안타증권 ·새마을금고<br>
실시간 출금이체 불가능 금융기관: 산업·수협·축협·신협·상호저축·HSBC·도이치·평화·전 증권사(삼성증권, 유안타증권은 가능)</span>
                </div>
                <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered -pub-button--left10">
                    <button type="button" class="-pub-button -pub-button--prev -pub-button--reverse" @click="$emit('move', 'previous')"><img class="icon-arrow" src="@/assets/img/components/ico-arrow-prev-blue.png" alt="이전 버튼">이전</button><button type="button" class="-pub-button -pub-button--next" @click="$emit('move', 'next')">다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼"></button>
                </div>
            </fdp-bottom-bar>
        </form>
    </section>
</template>
<script>
export default {
  data () {
    return {
      // 계좌 리스트
      accountList: [
        {
          bankLabel: 'KB국민은행',
          bankKey: 'e',
          accountNo: '559501-12-129674',
          accountOwner: '김태희',
          birthDate: '1900-01-01',
          index: 1
        },
        {
          bankLabel: '하나은행',
          bankKey: 'b',
          accountNo: '559501-12-129674',
          accountOwner: '김태희',
          birthDate: '1900-01-01',
          index: 2
        }
      ],
      currentAccountIdx: undefined,
      newAccountReq: false,
      currentStep: 2,
      checkValue: [],
      setpList: [
        {
          key: '1',
          status: 'done'
        },
        {
          key: '2',
          status: 'done'
        },
        {
          key: '3',
          status: ''
        }
      ],
      segmentData55: [{
        'key': '111',
        'label': '실시간 출금이체'
      },
      {
        'key': '222',
        'label': '가상계좌 이체'
      }],
      returnData55: [],
      segmentData5: [{
        'key': '111',
        'label': '신청'
      },
      {
        'key': '222',
        'label': '신청안함'
      }],
      returnData5: [],
      segmentData6: [{
        'key': '111',
        'label': '보험료만'
      },
      {
        'key': '222',
        'label': '보험료+이자'
      }],
      returnData6: [],
      returnData4: [],
      segmentData7: [{
        'key': '111',
        'label': '5일'
      },
      {
        'key': '222',
        'label': '10일'
      },
      {
        'key': '333',
        'label': '15일'
      },
      {
        'key': '444',
        'label': '20일'
      },
      {
        'key': '555',
        'label': '25일'
      }],
      returnData7: [],
      segmentData8: [{
        'key': '111',
        'label': '예'
      },
      {
        'key': '222',
        'label': '아니요'
      }],
      returnData8: [],
      homeTel: '4567-7898',
      bankSelect: {
        label: '우리은행',
        key: 'a'
      },
      bankList: [{
        label: '우리은행',
        key: 'a'
      },
      {
        label: '하나은행',
        key: 'b'
      },
      {
        label: '국민',
        key: 'c'
      },
      {
        label: '신한',
        key: 'd'
      },
      {
        label: 'KB국민은행',
        key: 'e'
      }],
      accontNo: '1234-597899-1111',
      accountOwner: '김태희',
      returnDate: ''

    }
  },
  methods: {
    accountClick (idx) { // 현재 선택된 계좌 index 변경
      this.currentAccountIdx = idx
    },
    openNewAccountReq () { // 새로운 계좌 추가 버튼 클릭 시 수행
      this.newAccountReq = true

      // this.newAccountReq가 true 된 후(새로운 계좌 추가 창이 열린 이후) 아래 코드 수행됨
      this.$nextTick(() => {
        var element = this.$refs.newAccountScroll
        var top = element.offsetTop // 특정 ref의 y축 위쪽 위치 정보
        this.$refs.leftScroll.scrollTop = top
      })
    },
    closeNewAccountReq () { // 새로운 계좌 추가 창에 있는 닫기 버튼 클릭 시 수행
      this.newAccountReq = false

      this.bankSelect = this.bankList[0]
      this.accontNo = ''
      this.accountOwner = ''
    },
    addnewAccount () { // 새로운 계좌 정보 입력 후 '확인' 버튼 클릭 시 수행
      let newAccount = {
        bankLabel: this.bankSelect.label,
        bankKey: this.bankSelect.key,
        accountNo: this.accontNo,
        accountOwner: this.accountOwner,
        birthDate: this.returnDate,
        index: this.accountList.length + 1
      }

      this.accountList.push(newAccount)

      this.bankSelect = this.bankList[0]
      this.accontNo = ''
      this.accountOwner = ''

      this.newAccountReq = false
      this.currentAccountIdx = this.accountList.length
    }
  }
}
</script>
