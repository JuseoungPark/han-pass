<template>
    <!-- 고객등록시 고객조회 팝업 start -->
    <fdp-popup class="-pub-annuity-add" v-model="showPopup" title="다른연금 추가하기">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-annuity-add_wrap">
                <div class="-pub-annuity-add_wrap--top">
                    <ul>
                        <li class="-pub-annuity-add_wrap--top-row01">
                            <label>희망 월 생활비</label>
                            <fdp-text-field v-model="hopeamount" clearable></fdp-text-field>
                            <span>만원</span>
                        </li>
                        <li class="-pub-annuity-add_wrap--top-row02">
                            <label>연금정보<span class="-pub-ico-check">*</span></label>
                                <fdp-radio v-model="radioStrValue" class="-pub-radio" value="연금액 계산하기">연금액 계산하기</fdp-radio>
                                <fdp-radio v-model="radioStrValue" class="-pub-radio" value="직접입력하기">직접입력하기</fdp-radio>
                        </li>
                    </ul>
                </div>
                <div class="-pub-annuity-add_wrap--cont">
                    <div class="-pub-annuity-add_wrap--cont-left">
                        <ul>
                            <li class="-pub-annuity-add_wrap--cont-left01">
                                <label>직업</label>
                                <fdp-validator name="tssct015p-validator-2" display-name="직업" v-model="selectedValue.key" :rules="'required'">
                                        <fdp-select v-model="selectedValue" :option-list="jobList"></fdp-select>
                                </fdp-validator>
                            </li>
                            <li class="-pub-annuity-add_wrap--cont-left02">
                                <label>연소득</label>
                                <fdp-validator name="tssct015p-validator-3" display-name="연소득" v-model="earnings" :rules="'required'">
                                    <fdp-text-field v-model="earnings" clearable></fdp-text-field>
                                </fdp-validator><span>만원</span>
                            </li>
                        </ul>
                    </div>
                    <div class="-pub-annuity-add_wrap--cont-right">
                        <ul>
                            <li class="-pub-annuity-add_wrap--cont-right01">
                                <label>입사나이<br><span>(공적연금 가입연령)</span></label>
                                <fdp-validator name="tssct015p-validator-4" display-name="입사나이" v-model="startage" :rules="'required'">
                                    <fdp-text-field v-model="startage" clearable></fdp-text-field>
                                </fdp-validator><span>세</span>
                            </li>
                            <li class="-pub-annuity-add_wrap--cont-right02">
                                <label>예상 퇴직연령</label>
                                <fdp-validator name="tssct015p-validator-5" display-name="예상 퇴직연령" v-model="endage" :rules="'required'">
                                    <fdp-text-field v-model="endage" clearable></fdp-text-field>
                                </fdp-validator><span>세</span>
                            </li>
                            <li class="-pub-annuity-add_wrap--cont-right03">
                                <label>은퇴 희망연령</label>
                                <fdp-validator name="tssct015p-validator-6" display-name="은퇴 희망연령" v-model="hopeage" :rules="'required'">
                                    <fdp-text-field v-model="hopeage" clearable></fdp-text-field>
                                </fdp-validator><span>세</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <span class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-guide-text align-left">※ 통합연금포털에 가입하시면 고객님의 연금액을 확인하실 수 있습니다.</span>
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                    <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
<!-- 고객등록시 고객조회 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: ''
      },
      hopeamount: '',
      radioSelected: '',
      radioStrValue: '연금액 계산하기',
      radioTableSelected: [],
      showPopup: true,
      name1: '',
      startage: '',
      earnings: '',
      hopeage: '',
      selectedValue: { key: '01', label: '직장인' },
      jobList: [{
        key: '1',
        label: '직장인1'
      },
      {
        key: '2',
        label: '직장인2'
      }
      ]
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.id.toString()
      }
    }
  }
}
</script>
