<template>
  <section class="-pub-life__fold-area" :class="{'-pub-life__fold-area--expanded' : isExpand }">
    <!-- 선 그래프 이미지 -->
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-1" data-text="지출">
      <!-- selectbox 선택값에 따라 변경되는 그래프 -->
      <!-- 일반 은퇴자 그래프케이스 -->
      <template v-if="true">
        <template v-if="currentLivingPrice.key === '2'">
          <img class="-pub-life__graph-img" src="@/assets/img/life/img-red-chart-3.png" alt="그래프 이미지" />
        </template>
        <template v-else-if="currentLivingPrice.key === '3'">
          <img class="-pub-life__graph-img" src="@/assets/img/life/img-red-chart-4.png" alt="그래프 이미지" />
        </template>
        <template v-else-if="currentLivingPrice.key === '4'">
          <img class="-pub-life__graph-img" src="@/assets/img/life/img-red-chart-5.png" alt="그래프 이미지" />
        </template>
        <template v-else-if="currentLivingPrice.key === '5'">
          <img class="-pub-life__graph-img" src="@/assets/img/life/img-red-chart-6.png" alt="그래프 이미지" />
        </template>
        <template v-else>
          <img class="-pub-life__graph-img" src="@/assets/img/life/img_red_chart_2.png" alt="그래프 이미지" />
        </template>
      </template>
      <!-- 일반 은퇴자 그래프케이스 end -->
      <!-- selectbox 선택값에 따라 변경되는 그래프 end -->
    </div>
    <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-2" data-text="수입">
      <img v-if="showCrevasse" class="-pub-life__graph-img" src="@/assets/img/life/img-blue-chart.png" alt="그래프 이미지" />
      <img v-else class="-pub-life__graph-img" src="@/assets/img/life/img-blue-chart-b.png" alt="그래프 이미지" />
    </div>
    <!-- 그래프 좌측영역 분리 콘텐츠 -->
    <div class="-pub-life__graph-area -pub-life__fold-content">
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-1">
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">현재</p>
        <span class="-pub-life__graph-age-text">40세</span>
      </div>
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-4 -pub-life__graph-timeline-item--no-line">
        <!-- 아이콘 호출방식 변경 18/10/25 -->
        <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-5">
        <!-- / -->
          <a class="-pub-life__group-item-remove-button"></a>
        </div>
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">주택구입</p>
      </div>
      <div class="-pub-life__guide-line" data-text="경제활동 기간" :class="{'-pub-life__guide-line--show-crevasse': isExpand && showCrevasse, '-pub-life__guide-line--hide-crevasse': isExpand && !showCrevasse }"></div>
      <div class="-pub-life__fold-shadow-container" v-show="!isExpand">
        <div class="-pub-life__fold-shadow" @click="isExpand = !isExpand"></div>
        <div class="-fdp-tooltip-button -pub-tooltip" top v-show="showExapndTooltip">
          <div class="-fdp-tooltip-button__content">
            <button class="-fdp-tooltip-button__close-button" @click="showExapndTooltip = false">X</button>
            <span>접힌영역을<br>터치해보세요.</span>
          </div>
        </div>
      </div>
      <template v-if="isExpand">
        <div class="-pub-life__graph-timeline-item" v-show="isExpand" :style="{ left: showCrevasse ? '906px' : '1167px' }">
          <a @click="showRetirementAge = true">
            <span class="-pub-life__graph-timeline-symbol  -pub-life__graph-timeline-symbol--update"></span>
            <p class="-pub-life__graph-time-text">은퇴</p>
          </a>
          <div class="-pub-tooltip-layer" v-show="showRetirementAge">
            <a class="-pub-button--close-light -pub-tooltip-layer__close-button" @click="showRetirementAge = false"></a>
            <h3 class="-pub-tooltip-layer__title">은퇴시기 설정</h3>
            <div class="-pub-tooltip-layer__content">
              <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                v-model="segment1.value" :data="segment1.items" :essential="true"></fdp-segment-box><button class="-pub-button -pub-button--light -pub-life__create-button"
                @click="changeRetirementAge()">확인</button>
            </div>
          </div>
        </div>
      </template>
    </div>
    <!-- 그래프 좌측영역 분리 콘텐츠 end -->
    <!-- 그래프 우측영역 분리 콘텐츠 -->
    <div class="-pub-life__graph-area -pub-life__fold-content--sub">
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-3 -pub-life__graph-timeline-item--no-line"
        v-show="showCrevasse">
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">연금수령</p>
      </div>
      <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-5 -pub-life__graph-timeline-item--no-line">
        <!-- 아이콘 호출방식 변경 18/10/25 -->
        <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-7">
        <!-- / -->
          <a class="-pub-life__group-item-remove-button"></a>
        </div>
        <span class="-pub-life__graph-timeline-symbol"></span>
        <p class="-pub-life__graph-time-text">여가취미</p>
      </div>
      <!-- 노후자금 텍스트는 항상존재 <p class="required-price-area" v-if="!(isExpand && showCrevasse)">-->
      <p class="required-price-area">
        <template v-if="currentLivingPrice.key === '1'">
          노후필요자금 7억
        </template>
        <template v-else-if="currentLivingPrice.key === '2'">
          노후필요자금 9.6억
        </template>
        <template v-else-if="currentLivingPrice.key === '3'">
          노후필요자금 14.4억
        </template>
        <template v-else>
          노후필요자금 19.2억
        </template>
        <fdp-tooltip-button class="-pub-tooltip -pub-tooltip--img-button" top>
          <template slot="activator">
            <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="은퇴 크레바스 버튼">
          </template>
          <template slot="content">
            <h3 class="-pub-tooltip-layer__title">노후 필요자금</h3>
            <div class="-pub-tooltip-layer__content">
              월 평균 145만원, 은퇴이후 40년 가정시, 현재가치 기준<br>
              자료 출처 : 국민연금연구원
            </div>
          </template>
        </fdp-tooltip-button>
      </p>
      <div class="-pub-life__guide-line" data-text="노후생활 기간" :class="isExpand ? '-pub-life__guide-line--show-expand' : ''"></div>
      <ul class="-pub-life-has-pensions">
        <li class="-pub-life-has-pensions__item" v-for="(item, index) in pensions" :key="index" :class="{'-pub-life-has-pensions__item--checked' : hasPensionsCount > index}">
          {{item.name}}
        </li>
      </ul>
    </div>
    <div class="-pub-life__crevasse" v-if="isExpand && showCrevasse">
      <p class="-pub-life__crevasse-text">은퇴<br>크레바스</p>
      <fdp-tooltip-button class="-pub-tooltip" top>
        <template slot="activator">
          <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="은퇴 크레바스 버튼">
        </template>
        <template slot="content">
          <h4 class="-pub-life__crevasse-title">은퇴 크레바스란 ?</h4>
          <p class="-pub-life__crevasse-desc">50대 중반에 직장에서 은퇴해 60대에 국민연금 등<br>공적연금을 수령할때까지의 공백기간을 의미합니다.</p>
        </template>
      </fdp-tooltip-button>
    </div>
    <!-- 그래프 우측영역 분리 콘텐츠 end -->
  </section>
</template>
<script>
export default {
  props: {
    pensions: {
      type: Array,
      default: _ => [{
        checked: true,
        name: '국민연금'
      },
      {
        checked: true,
        name: '퇴직연금'
      },
      {
        checked: false,
        name: '개인연금'
      }
      ]
    },
    currentLivingPrice: {
      type: Object,
      default: _ => {}
    }
  },
  data () {
    return {
      isExpand: false,
      showCrevasse: true,
      showExapndTooltip: true,
      showRetirementAge: false,
      segment1: {
        items: [{
          key: '1',
          label: '65세 이전'
        },
        {
          key: '2',
          label: '65세 이후'
        }
        ],
        value: [{
          key: '1'
        }]
      }
    }
  },
  computed: {
    hasPensionsCount () {
      return this.pensions.filter(pension => pension.checked).length
    }
  },
  methods: {
    changeRetirementAge () {
      this.showCrevasse = this.segment1.value[0].key === '1'
      this.showRetirementAge = false
    }
  }
}
</script>
