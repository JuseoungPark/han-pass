<template>
  <section class="-pub-customer-list">
    <!-- 페이지 헤더 영역 -->
    <div class="-pub-customer-list__header">
      <div class="-pub-customer-list__title-wrap">
        <h1 class="-pub-customer-list__title">
          <span class="-pub-title__text">{{title}}</span>
        </h1>
        <fdp-tooltip-button class="-pub-tooltip">
          <template slot="activator">
            <img class="-pub-tooltip__icon" src="@/assets/img/components/ico_info_gray.png" alt="툴팁" />
          </template>
          <template slot="content">
            <div>empty</div>
          </template>
        </fdp-tooltip-button>
      </div>
      <ul class="-pub-header__menu">
        <!-- 고객등록 동의 표시영역 -->
        <li class="-pub-header__item">
          <span class="-pub-customer-list__header-button">
            <img class="-pub-customer-list__header-button-icon" src="@/assets/img/customer/ico-customer.png" alt="정보">
            <span class="-pub-label__text">고객등록동의</span>
          </span>
        </li>
        <!-- 고객등록 동의 표시영역 end -->
      </ul>
    </div>
    <!-- 페이지 헤더 영역 end -->
    <div class="-pub-page-container">
      <!-- draw 콘텐츠 영역 -->
      <fdp-bottom-drawer >
        <div slot="drawerHeader">
          <!-- 페이지 서브 메뉴 영역 -->
          <customer-submenu :sub-menus="subMenus" :intialIndex="getIndex" @changeItem="changeMenu"></customer-submenu>
        </div>
        <!-- 페이지 서브 메뉴 영역 end -->
        <div slot="drawerBody" style="height: 100%">
          <div class="-pub-page-container__wrapper -pub-contents-tab">
            <template>
              <component :is="currentMenu.component"></component>
            </template>
          </div>
        </div>
      </fdp-bottom-drawer>
    </div>
  </section>
</template>
<script>
import {
  subMenus
} from '@/components/mock/customer-list.mock'

import CustomerSubmenu from '@/components/pages/2018-09-07/customer.submenu'

import TSSPS110M from '@/components/pages/2018-09-28/TSSPS110M'
import TSSCM203M from '@/components/pages/2018-08-22/TSSCM203M'
import TSSCM322M from '@/components/pages/2018-08-22/TSSCM322M'
import TSSCM324M from '@/components/pages/2018-08-22/TSSCM324M'
import TSSCM304M from '@/components/pages/2018-08-22/TSSCM304M'
import TSSCM132M from '@/components/pages/2018-09-07/TSSCM132M'
import TSSCM217M from '@/components/pages/2018-09-07/TSSCM217M'
import TSSCM216M from '@/components/pages/2018-09-14/TSSCM216M'
import TSSCM317M from '@/components/pages/2018-09-14/TSSCM317M'
import TSSCM310D from '@/components/pages/2018-09-21/TSSCM310D'
import TSSCM313M from '@/components/pages/2018-10-05/TSSCM313M'
import TSSCM301M from '@/components/pages/2018-10-12/TSSCM301M'
import TSSCM215M from '@/components/pages/2018-10-19/TSSCM215M'
import TSSCM251M from '@/components/pages/2018-10-26/TSSCM251M'

export default {
  components: {
    CustomerSubmenu,
    TSSPS110M,
    TSSCM203M,
    TSSCM322M,
    TSSCM304M,
    TSSCM324M,
    TSSCM132M,
    TSSCM217M,
    TSSCM216M,
    TSSCM317M,
    TSSCM310D,
    TSSCM313M,
    TSSCM301M,
    TSSCM215M,
    TSSCM251M
  },
  data () {
    return {
      title: '고객',
      currentMenu: {},
      subMenus: Array.prototype.slice.call(subMenus)
    }
  },
  methods: {
    onSizeChange (size) {},
    changeMenu (currentMenu) {
      console.log(currentMenu)
      this.currentMenu = currentMenu
    },
    getIndex (item, index) {
      return item.active
    }
  },
  computed: {}
}
</script>
