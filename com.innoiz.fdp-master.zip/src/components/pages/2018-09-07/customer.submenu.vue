<template>
  <div class="-pub-sub-menu-container">
    <ul class="-pub-sub-menu">
      <li v-for="(subMenu, idx) in subMenus"
          :key="idx"
          :class="[{ '-pub-sub-menu__item--active' : idx === selectItemIdx }]"
          @click="changeIdx(idx)"
          tabindex="1"
          class="-pub-sub-menu__item"
          >{{subMenu.name}}</li>
    </ul>
    <div class="-pub-sub-menu-container__gradation"></div>
  </div>
</template>
<script>
export default {
  props: {
    subMenus: {
      type: Array,
      default: _ => []
    },
    intialIndex: {
      type: [Number, Function],
      default: _ => 0
    }
  },
  data () {
    return {
      // intial value!
      selectItemIdx: -1
    }
  },
  computed: {
    currentItem () {
      return (this.subMenus[this.selectItemIdx] && this.subMenus[this.selectItemIdx]) || {}
    }
  },
  methods: {
    changeIdx (idx) {
      console.log('select idx : ', idx)
      if (this.selectItemIdx !== idx) {
        this.selectItemIdx = idx
        this.$emit('changeItem', Object.assign({}, this.currentItem))
      }
    }
  },
  created () {
    const intialIdx = typeof this.intialIndex === 'function' ? Array.prototype.findIndex.call(this.subMenus, this.intialIndex)
      : this.intialIndex
    this.changeIdx(intialIdx)
  }
}
</script>
