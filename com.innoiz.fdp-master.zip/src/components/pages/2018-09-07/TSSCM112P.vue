<template>
  <!-- 고객등록시 고객조회 팝업 start -->
  <fdp-popup class="-pub-confirm -pub-confirm-type-6" v-model="showPopup" title="고객조회">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-confirm__content -pub-confirm__content--left">
            <div class="-pub-confirm__content--left -pub-confirm__content--main-pop">
              <!-- 페이지 조회 input, button 검색 건 영역  -->
              <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
              <div class="-pub-filter-menu">
                <div class="-pub-filter-menu__item--right">
                  <form onsubmit="return false;">
                      <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
                    <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                        <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                    </button>
                  </form>
                </div>
              </div>
              <!-- 페이지 조회 input, button 검색 명수 영역 end  -->
              <fdp-infinite class="-pub-table -pub-table-blue -pop-customer" v-model="radioTableSelected" single-select :items="mockData">
                <template slot="header">
                  <tr class="-pub-table__header">
                    <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                    <th class="-pub-table-column" style="width: 140px;">고객명</th>
                    <th class="-pub-table-column" style="width: 212px;">생년월일</th>
                    <th class="-pub-table-column" style="width: 120px;">연령</th>
                    <th class="-pub-table-column" style="width: 120px;">관계</th>
                    <th class="-pub-table-column" style="width: 210px;">필수컨설팅동의</th>
                    <th class="-pub-table-column" style="width: 188px;">마케팅 동의</th>
                    <th class="-pub-table-column" style="width: 224px;">고객카드 여부</th>
                  </tr>
                </template>
                <template slot-scope="props">
                  <div class="empty-table-content" style="display:none;">
                      검색결과가 존재하지 않습니다.
                  </div>
                 <td class="-pub-table-column--radiobox" style="width: 78px;">
                      <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item.id.toString()"></fdp-radio>
                  </td>
                  <td class="-pub-table-column -pub-table-column--name" style="width: 140px;">{{props.item.name}}</td>
                  <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 212px;">{{props.item.birthDay}}</td>
                  <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 120px;">{{props.item.age}}</td>
                  <td class="-pub-table-column" style="width: 120px;">{{props.item.me}}</td>
                  <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 210px;">
                    <template v-if="props.item.consulting">
                      Y
                    </template>
                    <template v-else>
                      N
                    </template>
                  </td>
                  <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 188px;">
                    <template v-if="props.item.marketing">
                      Y
                    </template>
                    <template v-else>
                      N
                    </template>
                  </td>
                  <td class="-pub-table-column" style="width: 224px;">{{props.item.hasCustomerCard}}</td>
                </template>
              </fdp-infinite>
            </div>
        </div>
        <!-- 하단 버튼 고정 start -->
        <div class="-pub-bottom-bar">
          <div class="-pub-confirm__content--right">
            <button type="button" class="-pub-button" @click="showPopup = !showPopup">
              <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--reverse" disabled="disabled">
              <span class="-pub-button__text">확인</span>
            </button>
          </div>
        </div>
        <!--// 하단 버튼 고정 end -->
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
  <!-- 고객등록시 고객조회 팝업 end -->
</template>
<script>
import mockData from '@/components/mock/TSSCM112P.mock'
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: '',
        password: '',
        masking: '',
        fixedIcon: '',
        disabled: 'text not editable',
        readonly: 'text not editable'
      },
      radioSelected: '',
      radioTableSelected: [],
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData),
      mockHeader: []
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.id.toString()
      }
    }
  }
}
</script>
