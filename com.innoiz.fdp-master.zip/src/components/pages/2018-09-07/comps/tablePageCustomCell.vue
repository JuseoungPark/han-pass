<template>
    <div :class="myClass">
        <template v-if="item.agreeItem === '마케팅'">
            <span class="btm-border">{{item.agreeItem}}</span>
        </template>
        <template v-else>
            {{item.agreeItem}}
        </template>
    </div>
</template>

<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col']
}
</script>

<style scoped>
.btm-border {
  display: inline-block;
  line-height: 30px;
  border-bottom: 1px solid #222
}
</style>
