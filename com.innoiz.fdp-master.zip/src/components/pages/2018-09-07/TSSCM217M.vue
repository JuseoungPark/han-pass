<template>
  <div>
    <!-- 페이지 서브 메뉴 영역 end -->
    <div class="-pub-contents">
      <!-- 페이지 조회 input, button 검색 명수 영역  -->
      <div class="-pub-filter-menu -pub-filter-menu__margintop"><!-- 20181101 마크업 추가 -pub-filter-menu__margintop -->
        <div class="-pub-filter-menu__item--clear">
            <div class="-pub-filter-detail__item -pub-filter-detail__title -pub-title-customer">대상고객</div>
            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple -pub-segment--targetCustomer" v-model="targetCustomerValues"
            :essential="true"
            :data="targetCustomer"></fdp-segment-box>
        </div>
        <!-- 임직원 전용 상세조회 버튼 -->
        <div class="-pub-filter-menu__item--right " v-if="true">
          <form onsubmit="return false;">
            <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
            <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
              <span>상세조회</span>
              <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
            </a>
            <!-- 상세조회 버튼영역 end -->
          </form>
        </div>
        <!-- 임직원 전용 상세조회 버튼 end -->
        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
      </div>
      <!-- 페이지 조회 input, button 검색 명수 영역 end -->
      <!-- 임직원 전용 상세조회 영역 -->
      <template v-if="isDetailSearch" >
        <div class="-pub-filter-detail__scroll">
          <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
            <template v-if="true">
                <li class="-pub-filter-detail__area" >
                  <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
                  <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                    :option-list="selectGroups.group1"></fdp-select>
                  <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
                    :option-list="selectGroups.group2"></fdp-select>
                  <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
                    :option-list="selectGroups.group3"></fdp-select>
                </li>
                <li class="-pub-filter-detail__area">
                  <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
                  <!-- 마크업 변경 detail-type-4 => detail-type-5 20181018 -->
                  <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4"
                    placeholder="담당 컨설턴트"></fdp-select>
                </li>
                <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                      <span class="-pub-button__text">조회</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                      <span class="-pub-button__text">초기화</span>
                    </button>
                  </li>
            </template>
          </ul>
        </div>
      </template>
      <!-- 임직원 전용 상세조회 영역 end -->
      <!-- 고객 관련 정보 데이터 테이블 영역 -->
      <div :class="hasSelectItem ? '-pub-table-height__onBottom7' : '-pub-table-height__offBottom7'">
      <fdp-infinite class="-pub-table" v-model="selectItems" multi-select :items="mockData" :table-body-height="hasSelectItem ? 780 : 780">
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-table-column--checkbox">
              <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
            </th>
            <th class="-pub-table-column -pub-table-column--sorting" style="width: 124px; height:100px;">고객명</th>
            <th class="-pub-table-column -pub-table-column--sorting" style="width: 148px;">생년월일</th>
            <th class="-pub-table-column -pub-table-column--sorting" style="width: 98px;">성별</th>
            <th class="-pub-table-column" style="width: 172px;">고객구분</th>
            <th class="-pub-table-column" style="width: 240px;">연락처</th><!-- 20181019 수정 -->
            <th class="-pub-table-column" style="width: 210px;">필수컨설팅동의<br/>종료예정일</th>
            <th class="-pub-table-column" style="width: 210px;">마케팅동의<br/>종료예정일</th>
            <th class="-pub-table-column" style="width: 210px;">마케팅동의<br/>최종처리일</th>
          </tr>
        </template>
        <template slot-scope="props">
          <td class="-pub-table-column--checkbox">
            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems"
              :value="props.item"></fdp-checkbox>
          </td>
          <td class="-pub-table-column -pub-table-column--name" style="width: 124px;">{{props.item.name}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 148px;">{{props.item.birthDay}}</td>
          <td class="-pub-table-column" style="width: 98px;">{{props.item.gender}}</td>
          <td class="-pub-table-column" style="width: 172px;">{{props.item.customer}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 240px;">{{props.item.phone}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 210px;">{{props.item.consultingEndDate}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 210px;">{{props.item.marketingEndDate}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 210px;">{{props.item.marketingFinalDate}}</td>
        </template>
        <template slot="emptyView">
          <div class="empty-table-content">
            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon"  />
            <div class="empty-table-content__text">데이터가 존재하지 않습니다.<!-- 검색결과가 존재하지 않습니다. --></div>
          </div>
        </template>
      </fdp-infinite>
    </div>
    </div>
    <!-- 고객 관련 정보 데이터 테이블 영역 end -->
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component-->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="hasSelectItem" :page-fixed="true">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--guide -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
        </li>
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">문자</span>
          </button>
          <!-- bottom nav disable attribute 추가시 disable 스타일 적용-->
          <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">내 그룹에 추가</span>
          </button>
          <!-- tooltip 메뉴 버튼 bottom bar-->
          <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple"
          v-model="currMenu" :menu-list="menuListSample" blue top>
          <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
            <span class="-pub-symbol--menu"></span>
          </div>
        </fdp-tooltip-menu>
        <!-- tooltip 메뉴 버튼 end-->
        </li>
      </ul>
    </fdp-bottom-bar>
  </div>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM217M.mock'
export default {
  data () {
    return {
      title: '고객',
      bottomBarCheck: false,
      menuListSample: [],
      modals: {
        confirm1: false,
        confirm2: false
      },
      targetMonth: '',
      isDetailSearch: false,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      targetCustomerValues: [{
        key: '2',
        label: '필수컨설팅 동의 1개월 전'
      }],
      targetCustomer: [{
        key: '1',
        label: '전체'
      },
      {
        key: '2',
        label: '필수컨설팅 동의 1개월 전'
      },
      {
        key: '3',
        label: '동의 종료 예정'
      }
      ],
      searchKeyword: '',
      selectedValue: '',
      selectItems: [],
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '',
            label: ''
          }
        }
      },
      isSelectAll: false
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
</script>
