<template>
  <!-- 보험서류발송 start -->
  <fdp-popup class="-pub-popup" v-model="showPopup" title="급여공제 동의" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content">
            <div class="-pub-popup-salary-deduction-agreement">
                <span class="-pub-text-1">고객사랑 방문서비스 물품 신청 시<br>
아래 일부 비용을 부담하는 것에 동의합니다.<br>
동의하지 않을 경우 신청할 수 없습니다.</span>
                <div class="-pub-text-box-1">
                    <span>공제 대상 고객유형<br>
가치 : 5000원 / 준가치 : 3000원</span>
                </div>
                <span class="-pub-text-2">동의하시겠습니까?</span>
            </div>
            <div class="-pub-popup__button-area">
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
                    <span class="-pub-button__text">취소</span>
                </button>
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                    <span class="-pub-button__text">동의</span>
                </button>
            </div>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
  <!-- 보험서류발송 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      showPopup: true
    }
  }
}
</script>
