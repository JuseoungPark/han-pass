<template>
  <div class="-pub-content-scroll"><!-- -pub-fdp-list__empty-view 데이터가 없을 경우 클래스 추가 --><!-- 목업 추가 20181113 --><!-- 목업 변경 20181113 -->
    <div>
        <!-- <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="mockData" :list-height="877" ref="targetFdpList">
          <template slot="emptyView">
            <div class="-pub-table-empty-view">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
            </div>
          </template>
          <template slot="default" slot-scope="props">
              <div class="-pub-accordion-container" v-for="(mock, index2) in props.item.data" :key="'b' + index2">
                  <div class="-pub-accordion-line">
                      <span class="-pub-accordion-line__text">{{mock.date}}</span>
                  </div>
                  <div class="-pub-accordion -pub-accordion--fixed" :class="[mock.expand ? '-pub-accordion--expanded' : '']">
                      <div class="-pub-accordion__title">
                          <div class="-pub-accordion__text -pub-accordion__text--type -pub-accordion__text--vary ">{{mock.type}}</div>
                          <div class="-pub-accordion__text -pub-accordion__text--apply-type">{{mock.applyType}}</div>
                          <div class="-pub-accordion__text -pub-accordion__text--id -pub-accordion__text--right">{{mock.itemName}}</div>
                      </div>
                  </div>
              </div>
              <div class="-pub-accordion-container -pub-accordion-container--year">
                  <div class="-pub-accordion-line -pub-accordion-line--year">
                      <span class="-pub-accordion-line__text -pub-accordion-line__text--year">{{props.item.year}}</span>
                  </div>
                  <div class="-pub-accordion--empty"></div>
              </div>
          </template>
      </fdp-list> -->
      <template tag="div" v-for=" (year, idx) in mockData">
        <div class="-pub-accordion-container" v-for=" (mock, index2) in year.data" :key="'b' + idx + index2">
          <div class="-pub-accordion-line">
            <span class="-pub-accordion-line__text">{{mock.date}}</span>
          </div>
          <div class="-pub-accordion -pub-accordion--fixed" :class="[mock.expand ? '-pub-accordion--expanded' : '']">
            <div class="-pub-accordion__title">
              <div class="-pub-accordion__text -pub-accordion__text--type -pub-accordion__text--vary ">{{mock.type}}</div>
              <div class="-pub-accordion__text -pub-accordion__text--apply-type">{{mock.applyType}}</div>
              <div class="-pub-accordion__text -pub-accordion__text--id -pub-accordion__text--right">{{mock.itemName}}</div>
            </div>
          </div>
        </div>
        <div class="-pub-accordion-container -pub-accordion-container--year" :key="idx">
          <div class="-pub-accordion-line -pub-accordion-line--year">
            <span class="-pub-accordion-line__text -pub-accordion-line__text--year ">{{year.year}}</span>
          </div>
          <div class="-pub-accordion--empty"></div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      mockData: [
        {
          year: 2017,
          data: [{
            date: '07.16',
            type: '비대면',
            applyType: 'DM',
            itemName: ''
          }]
        },
        {
          year: 2016,
          data: [{
            date: '06.16',
            type: '컨설팅',
            applyType: '가설',
            itemName: '암보험(갱신형,무배당) 처음부터 끝까지)'
          },
          {
            date: '06.10',
            applyType: '청약서',
            type: '컨설팅',
            itemName: 'New 나이에 딱 맞는 변액 CI 보험 (무배당)'
          },
          {
            date: '05.11',
            applyType: '필수컨설팅',
            type: '동의',
            itemName: '동의대상 : 본인 이주명, 자녀 김하늘'
          }
          ]
        },
        {
          year: 2015,
          data: []
        },
        {
          year: 2014,
          data: [{
            date: '06.10',
            type: '동의',
            applyType: '마케팅',
            itemName: '동의대상 : 본인 이주명'
          },
          {
            date: '04.15',
            applyType: '신청',
            type: '프리미엄 고객사랑 서비스',
            itemName: 'New 나이에 딱 맞는 번액 CI보험 (무배당)'
          }
          ]
        }
      ]
    }
  }
}

</script>

<style>

</style>
