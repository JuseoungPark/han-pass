<template>
<div>
  <!-- 페이지 서브 메뉴 영역 end -->
  <div class="-pub-contents">
      <!-- 페이지 조회 input, button 검색 명수 영역  -->
      <div class="-pub-filter-menu -pub-filter-menu__margintop"><!-- -pub-filter-menu__margintop 마크업 추가 20181101-->
        <div class="-pub-filter-menu__item--right">
          <form onsubmit="return false;">
            <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
            <button type="submit" class="-pub-search-button -pub-filter-menu__item">
              <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
            </button>
            <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
            <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
              <span>상세조회</span>
              <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
            </a>
            <!-- 상세조회 버튼영역 end -->
          </form>
        </div>
        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
      </div>
      <!-- 페이지 조회 input, button 검색 명수 영역 end -->
      <!-- 상세조회 영역 -->
      <template v-if="isDetailSearch" >
        <div class="-pub-filter-detail__scroll">
          <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
          <!-- 임직원일 경우에만 보이는 상세조회 field -->
          <template v-if="true">
            <li class="-pub-filter-detail__area">
              <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                :option-list="selectGroups.group1"></fdp-select>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
                :option-list="selectGroups.group2"></fdp-select>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
                :option-list="selectGroups.group3"></fdp-select>
            </li>
            <li class="-pub-filter-detail__area">
              <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
              <!-- 마크업 변경 detail-type-4 => detail-type-5 20181018 -->
              <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4"
                placeholder="담당 컨설턴트"></fdp-select>
            </li>
          </template>
          <!-- 임직원일 경우에만 보이는 상세조회 field end -->
          <!-- 정보활용동의 현황 상세조회 FC field -->
          <li class="-pub-filter-detail__area">
            <div class="-pub-filter-detail__item -pub-filter-detail__title">승인 상태</div>
            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="segmentfields.confirmStatusValues"
            :essential="true"
            :data="segmentfields.confirmStatus"></fdp-segment-box>
          </li>
          <li class="-pub-filter-detail__area">
            <div class="-pub-filter-detail__item -pub-filter-detail__title">동의 경로</div>
            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple -pub-segment--agreeRoute" v-model="segmentfields.agreeRouteValues"
            :data="segmentfields.agreeRoute" :itemPerLine="6" :essential="true"></fdp-segment-box>
          </li>
          <li class="-pub-filter-detail__area">
            <div class="-pub-filter-detail__item -pub-filter-detail__title">조회 기간</div>
            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple -pub-segment--searchDate " v-model="segmentfields.searchDateValues"
              :data="segmentfields.searchDate" :essential="true"></fdp-segment-box>
              <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item -pub-filter-detail__item--date-picker"
                    v-model="targetMonth" placeholder="소개일" format="yyyy-MM-dd"></fdp-date-picker>
                    <span class="-pub-filter-detail__item separator-tilde"></span>
                    <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item -pub-filter-detail__item--date-picker"
                    v-model="targetMonth" placeholder="소개일" format="yyyy-MM-dd"></fdp-date-picker>
          </li>
          <li class="-pub-filter-detail__area">
              <div class="-pub-filter-detail__item -pub-filter-detail__title">동의 항목</div>
              <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple -pub-segment--agreeItem" v-model="segmentfields.agreeItemValues"
              :data="segmentfields.agreeItem" :essential="true"></fdp-segment-box>
          </li>
        </ul>
        <!-- 정보활용동의 현황 상세조회 FC field end-->
        </div>
       <div class="-pub-filter-detail__bottom">
          <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
              <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
                  <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                    <span class="-pub-button__text">조회</span>
                  </button>
                  <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                    <span class="-pub-button__text">초기화</span>
                  </button>
                </li>
           </ul>
       </div>
      </template>
      <!-- 정보활용동의 현황 상세조회 FC  -->
    </div>
    <!-- 마크업 추가 20181031 -->
    <div :class="hasSelectItem ? '-pub-table-height__onBottom6' : '-pub-table-height__offBottom6'">
      <fdp-table :options="opt" v-model="selectItems" multi-select :items="mockData" @input="onInputMultiSelect" @headerCheckbox="onClickHeaderCheckbox" class="-pub-table_wrap -pub-last">
          <template slot="empty">
              <div class="-pub-table-empty-view">
                  <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                </div>
              <div class="-pub-table-empty-view -pub-table-empty-view--search">
                <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
              </div>
          </template>
      </fdp-table>
    </div>
    <!-- 고객 관련 정보 데이터 테이블 영역 end -->
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component-->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="hasSelectItem" :page-fixed="true">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--centered">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
        </li>
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">문자</span>
          </button>
          <!-- bottom nav disable attribute 추가시 disable 스타일 적용-->
          <button type="button" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">내 그룹에 추가</span>
          </button>
          <!-- tooltip 메뉴 버튼 bottom bar-->
          <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple"
          v-model="currMenu" :menu-list="menuListSample" blue top>
          <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
            <span class="-pub-symbol--menu"></span>
          </div>
        </fdp-tooltip-menu>
        <!-- tooltip 메뉴 버튼 end-->
        </li>
      </ul>
    </fdp-bottom-bar>
  </div>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM132M.mock'

// fdp-table-header에 checkbox 적용하기 위하여 import
import cellCheckbox from './comps/tableCellFdpCheckbox'
import cusCell from './comps/tablePageCustomCell'
export default {
  data () {
    return {
      title: '고객',
      opt: columnFixed,
      targetMonth1: '',
      targetMonth2: '',
      isDetailSearch: false,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      selectItems: [],
      isSelectAll: false,
      bottomBarCheck: false,
      showDefaultModal1: false,
      showDefaultModal2: false,
      segmentfields: {
        confirmStatusValues: [{
          key: '1',
          label: '전체'
        }],
        confirmStatus: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '승인완료'
        },
        {
          key: '3',
          label: '승인취소'
        }
        ],
        agreeRouteValues: [{
          key: '1',
          label: '전체'
        }],
        agreeRoute: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '동의서'
        },
        {
          key: '3',
          label: '휴대폰'
        },
        {
          key: '4',
          label: '신용카드'
        },
        {
          key: '5',
          label: '휴대폰 사랑On'
        },
        {
          key: '6',
          label: '동의서 스마트CRM'
        },
        {
          key: '7',
          label: '휴대폰 스마트CRM'
        },
        {
          key: '8',
          label: '신용카드 스마트CRM'
        }
        ],
        searchDateValues: [{
          key: '1',
          label: '승인일'
        }],
        searchDate: [{
          key: '1',
          label: '승인일'
        },
        {
          key: '2',
          label: '유효시작일'
        }
        ],
        agreeItemValues: [{
          key: '1',
          label: '전체'
        }],
        agreeItem: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '필수컨설팅'
        },
        {
          key: '3',
          label: '마케팅'
        },
        {
          key: '4',
          label: '보험상담'
        },
        {
          key: '5',
          label: '실존조회'
        },
        {
          key: '6',
          label: '전환설계'
        },
        {
          key: '7',
          label: '비교안내문'
        }
        ]
      },
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '1',
            label: '김안범(000012312)'
          }
        }
      }
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return this.selectItems.length > 0
    },
    disabledTableStartDate () {
      return {
        from: new Date(this.targetMonth2),
        to: null
      }
    },
    disabledTableEndDate () {
      return {
        from: null,
        to: new Date(this.targetMonth1)
      }
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }
      return offsetTop
    },
    onDefaultModal1 () {
      this.showDefaultModal1 = !this.showDefaultModal1
    },
    onDefaultModal2 () {
      this.showDefaultModal2 = !this.showDefaultModal2
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // table header checkbox 선택 시 처리
    onClickHeaderCheckbox () {
      let checkCnt = 0
      let checkedBool = false
      for (var key in this.mockData) {
        if (this.mockData[key].ck) checkCnt++
      }
      checkedBool = this.mockData.length !== checkCnt
      this.selectItems.splice(0, this.selectItems.length)

      for (key in this.mockData) {
        if (checkedBool) {
          this.selectItems.push(this.mockData[key])
        }
        this.mockData[key].ck = checkedBool
      }
    },
    // bottom-bar checkbox 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.onInputMultiSelect(this.selectItems)
    },
    // table row 선택 시 처리
    onInputMultiSelect (v) {
      for (var key in this.mockData) {
        this.mockData[key].ck = false
      }
      let that = this
      v.map((vv) => {
        for (var key in this.mockData) {
          if (that.mockData[key] === vv) {
            that.mockData[key].ck = vv.idx
          }
        }
      })
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
// fdp-table에서 fixed column을 사용하기 위한 option
var columnFixed = {
  name: 'columnFixed',
  cols: [
    {key: 'idx', component: cellCheckbox, type: 'checkbox', width: 78, name: '', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
    {key: 'name', width: 172, name: '고객명', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'font-weight': 'bold'}},
    {key: 'birthDay', type: 'date', width: 190, name: '생년월일', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'mainCustomer', width: 172, name: '주고객명', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'font-weight': 'bold'}},
    {key: 'connection', width: 140, name: '관계', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'agreeRoute', width: 268, name: '동의 경로', type: 'code', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'agreeItem', component: cusCell, width: 172, name: '동의 항목', type: 'code', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'marketing', width: 300, name: '마케팅동의 연락방식', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'confirmName', width: 172, name: '승인자', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'confirmDate', width: 190, name: '승인일', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'endDate', width: 190, name: '종료일', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}}
  ],
  // 컬럼 고정 여부
  availableColumnFixed: true,
  // 고정할 컬럼 수 (왼쪽부터 적용)
  howManyColumnFixed: 2,
  headerHeight: 72, // 수정 20181101
  multiSelect: true,
  tableHeight: 808,
  infinite: true
}
</script>
