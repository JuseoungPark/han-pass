<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--sticky-scroll" :class="{ '-pub-consulting-content--scrolled-y' : isPositionYScrolled, '-pub-consulting-content--scrolled-x': isPositionXScrolled }">
    <div class="-pub-consulting-content__scroll-view" :class="[{'-pub-consulting-content__scroll-view--scroll' : contentValue === '기간별'} ]">
      <div class="-pub-consulting-content__fixed">
        <div class="-pub-consulting-content__wrapper">
          <p class="-pub-consulting-content__unit">
            <span v-if="contentValue === '기간별'">단위:만원</span>
          </p>
          <table class="-pub-consulting-content__header" v-for="(row, index) in tableHeaderMock" :key="index">
            <colgroup>
              <col width="128px" />
              <col width="188px" />
            </colgroup>
            <thead>
              <tr>
                <th>{{row.title}}</th>
                <td>보장급부</td>
              </tr>
            </thead>
            <tbody v-for="(column, index2) in row.columns" :key="'' + index + index2">
              <template v-for="(data, index3) in column.data">
                <tr :key="'' + index + index2 + index3">
                  <td class="align-left" v-if="index3 === 0" :rowspan="column.data.length">{{column.title}}</td>
                  <!-- 추가정보가 연결된 급부의 경우, 다음 class를 추가함. 아래 예시 참조 -pub-consulting-content__line-text-->
                  <td><span class="align-center -pub-consulting-content__line-text">{{data.type}}</span></td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <div class="-pub-consulting-content__scroll">
        <template v-if="contentValue === '상품별'">
          <section class="-pub-product-card__container">
            <div class="-pub-consulting-content__data">
              <p class="-pub-consulting-content__unit">단위:만원</p>
              <table class="-pub-consulting-content__header" v-for="(row, index) in tableHeaderMock" :key="index">
                <colgroup>
                  <col width="130px" />
                  <col width="130px" />
                  <col width="140px" />
                </colgroup>
                <thead>
                  <tr>
                    <td class="align-center">총금액</td>
                    <td class="align-center">필요금액</td>
                    <td class="align-center">과부족</td>
                  </tr>
                </thead>
                <tbody v-for="(column, index2) in row.columns" :key="'' + index + index2">
                  <template v-for="(data, index3) in column.data">
                    <tr :key="'' + index + index2 + index3">
                      <td class="align-right normal-letter bold-text">{{data.amount}}</td>
                      <td class="align-right normal-letter">{{data.requireAmount}}</td>
                      <td class="align-right normal-letter" :class="isInteger(data.overAmount) ? 'is-integer' : 'is-negative'">{{data.overAmount}}</td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
            <article class="-pub-product-card__item" v-for="(item, i) in productList" :key="i" :class="{'-pub-product-card__item--point': item.isRecommendProduct }">
              <div class="-pub-product-card__title-area">
                <a class="-pub-product-card__remove-button" v-if="item.canDelete" @click="remove(item, i)"></a>
                <h2 class="-pub-product-card__title">{{item.name}}</h2>
                <div class="-pub-product-card__sub-content">
                  <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                    <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                    <span class="-pub-product-card__badge-label" v-else>자사</span>

                    <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                    <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                  </span>
                  <div class="-pub-product-card__month-text normal-letter"><span class="sub-text">월</span> <span class="bold-text">{{item.monthPrice}}
                      원</span>
                  </div>
                </div>
              </div>
              <div class="-pub-product-card__content-area">
                <ul class="-pub-product-card__column" v-for="(detailList, j) in item.details" :key="j">
                  <li v-for="(price, k) in detailList" class="-pub-product-card__row normal-letter" :key="k">
                    <template v-if="typeof price ==='string'">
                      <span class="-pub-product-card__row-value--normal">{{price}}</span>
                    </template>
                    <template v-else>
                      <ul class="-pub-product-card__row-value-list">
                        <li class="-pub-product-card__row-value-item" v-for="(item, i2) in price" :key="i2">
                          <span class="-pub-product-card__row-text--number">{{item.value}}</span>
                          <span class="-pub-product-card__row-text--percentage">{{item.percentage}}%</span>
                        </li>
                      </ul>
                    </template>
                  </li>
                </ul>
              </div>
            </article>
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
          </section>
        </template>
        <template v-else-if="contentValue === '기간별'">
          <div class="-pub-product-graph -pub-product-graph--fix-position">
            <!-- 그래프 head영역 -->
            <div class="-pub-product-graph__head-container ">
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>31</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>60</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>70</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>80</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>100</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered">종신</div>
              </div>
            </div>
            <!-- 그래프 head영역 end -->
            <!-- 그래프 body 영역 -->
            <div class="-pub-product-graph__body" v-for="(blockGroup, index) in blockData" :key="index">
              <div class="-pub-product-graph__row" v-for="(blockRow, index2) in blockGroup" :key="index2">
                <div class="-pub-data-block">
                  <div class="-pub-data-block__item"
                       v-for="(data, index3) in blockRow"
                       :key="index3"
                       :class="['-pub-data-block__item--size-' + data.blockSize, '-pub-data-block__item--light-' + (data.blockColorLevel || index3 + 1),{'-pub-data-block__item--empty' : data.isEmpty}]">
                    <p class="-pub-data-block__text" >
                      <template v-if="isAfter">
                        <span class="-pub-data-block__after-text" v-if="index3 === 0">설계전<br>후</span>
                        <span class="-pub-data-block__after-text -pub-data-block__after-text--price">{{data.price}}<span class="-pub-data-block__after-price">{{data.afterPrice || 0}}</span></span>
                      </template>
                      <template v-else>
                        <span class="-pub-data-block__single-before-text">{{data.price}}</span>
                      </template>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- 그래프 body 영역 end -->
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import { createScrollTickInstance } from '@/components/util/scroll-raf-tick'
export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      isEmpty: false,
      tableData: [],
      // 설계후 그래프 전/후 flag
      isAfter: false,
      blockData: [
        [
          [ { price: '333,500' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '1,500', blockSize: 2 } ],
          [ { price: '2,000', afterPrice: '3,450' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '1,500', blockSize: 2 } ]
        ],
        [
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '1,500', blockSize: 2 } ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' } ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '1,500', blockSize: 2 } ],
          [ { price: '3,500' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { price: '3,000' }, { price: '2,500' }, { price: '2,000' }, {price: '1,500'}, {price: '1,000'} ]
        ],
        [
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ],
          [ { price: '3,500' }, { blockSize: 2, price: '2,500' }, { price: '2,000' }, { price: '1,500' }, {price: '1,000'} ]
        ]
      ],
      tableHeaderMock: [
        {
          title: '가족보장',
          columns: [
            {
              title: '사망',
              data: [
                {
                  type: '암사망',
                  amount: '555,555',
                  requireAmount: '555,555',
                  overAmount: '-500,000'
                },
                {
                  type: '일반사망',
                  amount: '55,871',
                  requireAmount: '10,000',
                  overAmount: '+450,871'
                },
                {
                  type: '교통재해',
                  amount: '70,971',
                  requireAmount: '10,000',
                  overAmount: '+60,971'
                },
                {
                  type: '교통재해',
                  amount: '5,000',
                  requireAmount: '10,000',
                  overAmount: '-5,000'
                }
              ]
            },
            {
              title: '사망2',
              data: [{
                type: '암사망',
                amount: '555,555',
                requireAmount: '555,555',
                overAmount: '-500,000'
              },
              {
                type: '일반사망',
                amount: '55,871',
                requireAmount: '10,000',
                overAmount: '+450,871'
              },
              {
                type: '교통재해',
                amount: '70,971',
                requireAmount: '10,000',
                overAmount: '+60,971'
              },
              {
                type: '교통재해',
                amount: '5,000',
                requireAmount: '10,000',
                overAmount: '0'
              }
              ]
            }
          ]
        },
        {
          title: '생활보장',
          columns: [{
            title: '재해 장애',
            data: [{
              type: '장해율 100%',
              amount: '10,000',
              requireAmount: '1,000',
              overAmount: '+9,000'
            },
            {
              type: '장해율 70%',
              amount: '10,000',
              requireAmount: '800',
              overAmount: '+2,000'
            },
            {
              type: '장해율 30%',
              amount: '10,000',
              requireAmount: '700',
              overAmount: '+2,000'
            },
            {
              type: '장해1급',
              amount: '10,000',
              requireAmount: '600',
              overAmount: '+2,000'
            },
            {
              type: '장해2급',
              amount: '10,000',
              requireAmount: '800',
              overAmount: '-5,000'
            },
            {
              type: '장해5급',
              amount: '10,000',
              requireAmount: '900',
              overAmount: '-5,000'
            }
            ]
          }]
        },
        {
          title: '의료보장',
          columnTitle: '의료 실손',
          columns: [{
            title: '의료 실손',
            data: [{
              type: '질병입원의료비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '+2,000'
            },
            {
              type: '질병통원의료비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '+2,000'
            },
            {
              type: '질병처방조재비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '+2,000'
            },
            {
              type: '상해입원의료비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '+2,000'
            },
            {
              type: '상해통원의료비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '-5,000'
            },
            {
              type: '상해처방조재비',
              amount: '10,000',
              requireAmount: '5,000',
              overAmount: '-5,000'
            }
            ]
          }]
        }
      ],
      productList: [{
        name: '노블리에종신보험(보증비...',
        monthPrice: '50,000',
        color: 'green',
        isOtherProduct: true,
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: '생활자금 받는 변액종신보...',
        monthPrice: '230,000',
        color: 'pink',
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: '나에게 딱맞는 CI보험',
        monthPrice: '50,000',
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: '퍼펙트UP통합보험12.0(...',
        monthPrice: '50,000',
        isOtherProduct: true,
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: 'LTC변액종신보험',
        monthPrice: '50,000',
        color: 'green',
        isOtherProduct: true,
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: '노블리에종신보험(보증비...',
        monthPrice: '230,000',
        color: 'pink',
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: '플러스정기보험',
        monthPrice: '000,000,000',
        color: 'green',
        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      },
      {
        name: 'cyan card case',
        monthPrice: '000,000,000',
        color: 'cyan',

        details: [
          ['10,000', '10,000', '15,000', '15,000', '10,000', '10,000', '15,000', '15,000'],
          ['10,000', '10,000', '15,000', '15,000', '15,000', '-'],
          ['-', '10,000', '-', '5,000', '15,000', '-']
        ]
      }
      ],
      scrollTop: 0,
      scrollLeft: 0
    }
  },
  watch: {
    isEmpty (val) {
      if (val) {
        this.tableData = [].concat(this.tableDataCopy)
      } else {
        this.tableData = []
      }
    },
    isPositionYScrolled (val) {
      val ? this.$emit('onScroll', true) : this.$emit('onScroll', false)
    }
  },
  methods: {
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    getVerticalScrollEl () {
      // 스크롤 컨테이너 엘리먼트 반환
      return this.$el
    }
  },
  computed: {
    isPositionYScrolled () {
      return this.scrollTop > 0
    },
    isPositionXScrolled () {
      return this.scrollLeft > 0
    }

  },
  mounted () {
    const scrollEl = this.getVerticalScrollEl()
    if (!scrollEl) return false

    // 스크롤 이벤트 requestAnimationFrame 호출 주기마다 감지 scroll-raf-tick.js 파일참조
    createScrollTickInstance(scrollEl, (event, scrollTop, scrollLeft) => {
      this.scrollTop = scrollTop
      this.scrollLeft = scrollLeft
    })
  }
}
</script>
