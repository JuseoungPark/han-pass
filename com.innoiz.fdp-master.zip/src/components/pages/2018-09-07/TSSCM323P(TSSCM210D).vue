  <template>
  <div>
    <!-- TSSCM323P -->
    <article class="-pub-name-ui" style="margin-left: 200px">
      <a class="-pub-name-ui__close-button"><img src="@/assets/img/btn_close_dark.png" alt="name-ui 팝업 닫기"></a>
      <div class="-pub-name-ui__info">
        <div class="-pub-name-ui-card__title -pub-container">
          <h2 class="-pub-container__item">{{member.name}}</h2>
        </div>
        <div class="-pub-name-ui__swipe-content">
          <div class="-pub-name-ui__new-customer-info">
            <div class="-pub-name-ui__new-customer-title">생년월일</div>
            <div class="-pub-name-ui__new-customer-value">{{member.birthDay}}</div>
          </div>
          <div class="-pub-name-ui__new-customer-info">
            <div class="-pub-name-ui__new-customer-title">성별</div>
            <div class="-pub-name-ui__new-customer-value">{{member.gender}}</div>
          </div>
          <div class="-pub-name-ui__new-customer-guide">
            등록된 고객이 아닙니다.<br>
            고객카드 자동 생성을 클릭하면, 해당 고객은 보험상담<br>
            동의처리 없이 고객카드 생성이 바로 됩니다.
          </div>
        </div>
      </div>
      <ul class="-pub-name-ui-tab">
        <li class="-pub-name-ui-tab__button"  tabindex="1">
          고객카드 생성
        </li>
      </ul>
    </article>
    <!-- TSSCM206P -->
    <article class="-pub-name-ui" style="margin-left: 200px">
      <a class="-pub-name-ui__close-button"><img src="@/assets/img/btn_close_dark.png" alt="name-ui 팝업 닫기"></a>
      <div class="-pub-name-ui__info">
        <div class="-pub-name-ui-card__title -pub-container">
          <h2 class="-pub-container__item">{{member.name}}</h2>
          <div class="-pub-container__item -pub-name-ui-card__info">
            <span>{{member.phone}}</span><br>
            <span class="-pub-name-ui-card__title--grey">{{member.socialNumberFirst}} (보험 {{member.age}}세) {{member.gender}}</span>
          </div>
          <div class="-pub-container -pub-container__item--right">
            <a class="-pub-container__item -pub-round-button">
              <img src="@/assets/img/name-ui/btn-name-meetinghome-nor.png" alt="customer info">
            </a>
            <a class="-pub-container__item -pub-round-button">
              <img src="@/assets/img/name-ui/btn-name-customer-nor.png" alt="customer info">
            </a>
          </div>
        </div>
        <div class="-pub-name-ui__swipe-content">
          <fdp-carousel :number-of-page="2">
              <template slot="1">
                <h4 class="-pub-recent-activity">최근 활동</h4>
                <p class="-pub-recent-history" v-for="(history, index) in member.historys" :key="index">
                  <span>{{history.data1}}</span><span>{{history.data2}}</span>
                </p>
                <h4 class="-pub-customer-event">고객이벤트</h4>
                <ul class="-pub-name-ui-events">
                  <li v-for="(event, index) in member.events" :key="index" class="-pub-name-ui-events__item">{{event.title}}</li>
                </ul>
              </template>
              <template slot="2">
                <div class="-pub-name-ui-contact">
                  <h4 class="-pub-name-ui__contact-count">보유계약 N건</h4>
                  <a class="-pub-name-ui__contact-view-button" title="전체보기">
                    <img src="@/assets/img/name-ui/btn-all-view-gray.png" />
                  </a>
                  <ul class="-pub-name-ui-contact__list">
                    <li class="-pub-name-ui-contact__list-item">
                      <div class="-pub-name-ui-contact-title-area">
                        <!-- 두개의 tag를 한개의 tag로 변경 및 높이 고정 (180920 박현주 요청) -->
                        <p class="-pub-name-ui-contact-product-name">통합유니버설종신 보험 3.0(무) 통합유니버설종 보통합유니버설종 보</p>
                      </div>
                      <p class="-pub-name-ui-contact__info">
                        <span class="-pub-name-ui-contact__status">정상</span>
                        <span class="-pub-name-ui-contact__month-amount">월900,022,500원</span>
                      </p>
                    </li>
                    <li class="-pub-name-ui-contact__list-item">
                      <div class="-pub-name-ui-contact-title-area">
                        <!-- 두개의 tag를 한개의 tag로 변경 및 높이 고정 (180920 박현주 요청) -->
                        <p class="-pub-name-ui-contact-product-name">통합유니버설종신 보험 3.0(무) 통합유니버설종 보통합유니버설종 보</p>
                      </div>
                      <p class="-pub-name-ui-contact__info">
                        <span class="-pub-name-ui-contact__status">정상</span>
                        <span class="-pub-name-ui-contact__month-amount">월900,022,500원</span>
                      </p>
                    </li>
                  </ul>
                </div>
              </template>
          </fdp-carousel>
        </div>
      </div>
      <ul class="-pub-name-ui-tab">
        <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'message' }" @click="currMenu = 'message'">
          <img src="@/assets/img/name-ui/ico_tab_message.png" alt="calendar today">
        </li>
        <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'memo'}" @click="currMenu = 'memo'">
          <img src="@/assets/img/name-ui/ico-tab-memo.png" alt="Message">
        </li>
      </ul>
      <div class="-pub-name-ui-tab__content" >
        <template v-if="currMenu === 'memo'">
          <!-- TSSCM210D -->
          <div class="-pub-name-ui-tab__text-area-container">
            <h4 class="-pub-name-ui-tab__content-title">메모</h4>
            <!-- [ 181113 문구추가 -->
            <span class="-pub-name-ui-tab__content-notice">※ 개인정보(주민번호, 연락처, 계좌 等) 입력이 불가하며,<br>
메모 內 개인정보 유출시 모든 책임은 담당 컨설턴트에게 있습니다. </span>
            <!-- 181113 문구추가 ] -->
            <textarea class="-pub-name-ui-tab__text-area -pub-name-ui-tab__text-area--memo" v-model="memoText" :readonly="memoSave" ></textarea>
          </div>
          <div class="-pub-name-ui-tab__button-area -pub-coustomer-detail__button">
              <button class="-pub-button -pub-button--purple" type="button" v-if="!memoSave">취소</button>
              <button class="-pub-button -pub-button--purple -pub-button--reverse" type="button" @click="memoSave = true" v-if="!memoSave">저장</button>
              <button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--check" type="button" @click="memoSave = false; currMenu = ''" v-if="memoSave"><i class="check-icon"></i></button>
          </div>
        </template>
        <template v-else-if="currMenu === 'message'">
            <TSSCM260D @changeTab="setCurrMenu"></TSSCM260D>
        </template>
      </div>
    </article>
  </div>
</template>

<script>
import TSSCM260D from '@/components/pages/2018-09-14/TSSCM260D'

export default {
  components: {
    TSSCM260D
  },
  data () {
    return {
      currMenu: '',
      msgSend: false,
      memoSave: false,
      memoText: '아들 2명 보험 가입 예정',
      member: {
        name: '김종신',
        age: '52',
        job: '사무총무원',
        phone: '010-1234-1234',
        birthDay: '1989-07-07',
        socialNumberFirst: '1967-02-14',
        gender: '여',
        events: [{
          title: '납입완료(당월)'
        },
        {
          title: '계약월도래'
        },
        {
          title: '만기도래(당월)'
        }],
        historys: [{
          data1: '2주 전',
          data2: '사고 보험금 접수'
        }]
      }
    }
  },
  methods: {
    setCurrMenu (val) {
      this.currMenu = val
    }
  }
}

</script>
