<template>
<!-- 전자서명 팝업 start -->
<fdp-popup class="-pub-confirm -pub-confirm-type-8" v-model="showPopup" title="FATCA/CRS 본인확인서(개인용)" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <fdp-form-wrapper scope="regist" @validate-all="validateBeforeSubmit">
        <div class="-pub-confirm__content">
            <!-- FATCA/CRS 본인확인서(개인용)  -->
            <div class="-pub-confirm__desc">
                <span>
                    본 확인서는 상호주의에 따른 정기적인 금융정보의 교환을 위한 조세조약의 이행과 관련하여 「국세조세조정에 관한 법률」 제31조 및<br />
                    같은 법 시행령 47조에 의거한 「정기 금융정보 자동교환을 위한 조세조약 이행규정」에 의하여 작성이 요구되는 필수서식입니다.
                </span>
            </div>
            <div class="-pub-indentify-content -pub-contractor-info">
                <div class="-pub-indentify-content__left">
                    <div class="-pub-indentify__info--title">다음 해당란에 체크해주시기 바랍니다.  ① 또는 ②는<br> 중복 선택이 가능합니다.
                    </div>
                    <ul class="-pub-indentify__item--list">
                        <li class="-pub-indentify__item -pub-indentify__item01 ">
                            <label class="-pub-indentify__item--label">① 미국 거주자</label>
                            <fdp-validator scope="regist" name="foreignUsa" v-model="segmentfields.foreignUsaValues" :rules="'required'" display-name="미국 거주자">
                                <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--blue" v-model="segmentfields.foreignUsaValues"
                                    :data="segmentfields.foreignUsa">
                                </fdp-segment-box>
                            </fdp-validator>
                        </li>
                        <!-- 미국 거주자 일 경우 나오는 선택 사항 -->
                        <li class="-pub-indentify__item -pub-indentify__item02" v-if="segmentfields.foreignUsaValues[0] && segmentfields.foreignUsaValues[0].key==2">
                            <div class="-pub-select-box">
                                <fdp-validator scope="regist" name="foreignUsaCheck" v-model="radioStrValue" :rules="'required'" display-name="미국 거주자">
                                    <fdp-radio v-model="radioStrValue" class="-pub-radio" value="미국 시민권자(이중 국적자 포함)">미국 시민권자<br>(이중 국적자 포함)</fdp-radio>
                                    <fdp-radio v-model="radioStrValue" class="-pub-radio" value="미국 영주권자">미국 영주권자</fdp-radio>
                                    <fdp-radio v-model="radioStrValue" class="-pub-radio" value="미국세법상 미국거주자">미국세법상<br>미국거주자</fdp-radio>
                                </fdp-validator>
                            </div>
                        </li>
                        <!--// 미국 거주자 일 경우 나오는 선택 사항 end -->
                        <li class="-pub-indentify__item -pub-indentify__item03" :class="segmentfields.foreignUsaValues[0] && segmentfields.foreignUsaValues[0].key==2 ? '' : '-pub-btm-mrg' ">
                            <label class="-pub-indentify__item--label">② 한국, 미국 이외의 조세목적상<span class="txt-row">해외 거주자</span></label>
                            <fdp-validator scope="regist" name="foreign" v-model="segmentfields.foreignValues" :rules="'required'" display-name="해외 거주자">
                                <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--blue" v-model="segmentfields.foreignValues"
                                    :data="segmentfields.foreign">
                                </fdp-segment-box>
                            </fdp-validator>
                        </li>
                    </ul>
                    <div class="-pub-indentify__info--title -pub-indentify__info--title-mt50">위에서 ① 또는 ②에 표기한 경우 영문성명, 영문주소, 조세목적상<br>거주지국 및 납세자번호(TIN, Taxpayer Identification Number)를<br>기재해 주시기 바랍니다.
                    </div>
                    <ul>
                        <li class="-pub-indentify__item -pub-indentify__item04">
                            <label class="-pub-indentify__item--label">영문성명</label>
                            <fdp-validator scope="regist" name="englishName" v-model="sumName" :rules="'required'" display-name="영문성명">
                                <fdp-text-field v-model="engName1" placeholder="성(Sur Name)" style="margin-right:12px; width:262px;"></fdp-text-field>
                                <fdp-text-field v-model="engName2" placeholder="명(Given Name)" style="width:262px;"></fdp-text-field>
                            </fdp-validator>
                        </li>
                        <li class="-pub-indentify__item -pub-indentify__item05">
                            <label class="-pub-indentify__item--label">영문주소<br/>(현재 거주주소)</label>
                            <fdp-validator scope="regist" name="englishAddress" v-model="engAdress1" :rules="'required'" display-name="영문주소">
                                <fdp-text-field v-model="engAdress1" placeholder="입력하세요" style="width:538px;"></fdp-text-field>
                            </fdp-validator>
                        </li>
                    </ul>
                </div>
                <div class="-pub-indentify-content__right">
                    <div class="-pub-indentify__info--title">
                        납세자 정보
                    </div>
                    <!-- 납세자 정보 form -->
                    <div class="-pub-indentify__info--scroll">
                        <div v-for="(nation, idx) in nationList" :key="nation.index" class="-pub-indentify__info--detailBox">
                            <div v-if="idx !== 0" class="-pub-detailBox__close" @click="clickCloseNation(idx)"></div>
                            <ul>
                                <li class="-pub-indentify__item">
                                    <label class="-pub-indentify__item--label--left">조세목적상 거주지 국가 (영문)</label>
                                    <fdp-validator scope="regist" :name="'residence' + nation.index" v-model="nation.addr" :rules="'required'" display-name="조세목적상 거주지 국가">
                                        <fdp-text-field v-model="nation.addr" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-indentify__item">
                                    <label class="-pub-indentify__item--label--left">납세자번호 (TIN: SSN 또는 ITIN)</label>
                                    <fdp-validator scope="regist" :name="'taxpayer-number' + nation.index" :value="checkTaxpayerInfo(nation.tin, nation.tinOmitValList)" :rules="'required'"  display-name="납세자번호">
                                        <fdp-text-field v-model="nation.tin" placeholder="입력하세요" @input="checkTinOmitValList(idx, arguments[0])"></fdp-text-field>
                                    </fdp-validator>
                                </li>
                                <li class="-pub-indentify__item">
                                    <label class="-pub-indentify__item--label--left">납세자번호 미기재 사유 (미국은 미제출 불가)</label>
                                    <fdp-checkbox v-model="nation.tinOmitValList" value="발급국가"  :disabled="nation.tin.length>0">발급국가</fdp-checkbox>
                                    <fdp-checkbox v-model="nation.tinOmitValList" value="미요구 국가"  :disabled="nation.tin.length>0">미요구 국가</fdp-checkbox>
                                    <fdp-checkbox v-model="nation.tinOmitValList" value="미취득"  :disabled="nation.tin.length>0">미취득</fdp-checkbox>
                                </li>
                                <!-- 납세자번호 미취득 일 경우 나오는 선택 사항 -->
                                <!-- checkInputVisible : 미취득일 때만 활성화 되도록 설정 -->
                                <li class="-pub-indentify__item" v-if="checkInputVisible(nation)">
                                    <fdp-validator scope="regist" name="reason" v-model="nation.tinOmitText" :rules="'required'" display-name="미취득 사유">
                                        <fdp-text-field v-model="nation.tinOmitText" placeholder="미취득 사유를 입력하세요" style="width:500px;" :disabled="nation.tin.length>0"></fdp-text-field>
                                    </fdp-validator>
                                </li>
                                <!--// 미국 거주자 일 경우 나오는 선택 사항 end -->
                            </ul>
                        </div>

                        <!-- 납세자 정보 form end -->

                        <div class="-pub-indentify__btn">
                            <button type="button"  class="-pub-button -pub-button--add" @click="addNation">
                                <span class="-pub-button__text">국가 추가</span>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
            <!-- FATCA/CRS 본인확인서(개인용) end -->
        </div>
        <!-- 하단 버튼 고정 start -->
        <div class="-pub-bottom-bar">
            <div class="-pub-confirm__content--right">
                <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                <span class="-pub-button__text">취소</span>
                </button><button type="button" class="-pub-button -pub-button--reverse" disabled>
                <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
        <!--// 하단 버튼 고정 end -->
        </fdp-form-wrapper>
    </div>
    <!-- slot 끝 -->
</fdp-popup>
<!-- 전자서명 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      returnData1: '',
      returnData2: '',
      engName1: '',
      engName2: '',
      engAdress1: '',
      engAdress2: '',
      engAdress3: '',
      tin1: '',
      tin2: '',
      radioStrValue: '',
      index: 0,
      multiCheckbox: [],
      nationList: [
        {
          label: '',
          addr: '',
          tin: '',
          tinOmitValList: [],
          tinOmitText: '',
          index: 0
        }
      ],
      segmentfields: {
        foreignUsaValues: [
          {
            key: '1',
            label: '아니오'
          }
        ],
        foreignUsa: [
          {
            key: '1',
            label: '아니오'
          },
          {
            key: '2',
            label: '예'
          }
        ],
        foreignValues: [
          {
            key: '1',
            label: '아니오'
          }
        ],
        foreign: [
          {
            key: '1',
            label: '아니오'
          },
          {
            key: '2',
            label: '예'
          }
        ]
      }
    }
  },
  computed: {
    sumName () {
      return this.engName1 + this.engName2
    }
  },
  methods: {
    validateBeforeSubmit (result) {
      if (result) {
        // 에러 없으니 후속 로직
      } else {
        // 에러 있으니 Stop
      }
    },
    checkTaxpayerInfo (tin, tinOmitList) {
      return tin.length > 0 || tinOmitList.length > 0 ? '1' : ''
    },
    checkTinOmitValList (idx, inputValue) {
      if (inputValue.length !== 0 && this.nationList[idx]) {
        this.nationList[idx].tinOmitValList.splice(0, this.nationList[idx].tinOmitValList.length)
        this.nationList[idx].tinOmitText = ''
      }
    },
    addNation () { // 국가 추가 버튼 클릭 시 수행
      let newNation = {
        label: '',
        addr: '',
        tin: '',
        tinOmitValList: [],
        tinOmitText: '',
        index: ++this.index
      }
      this.nationList.push(newNation)
    },
    checkInputVisible: function (nation) { // 미취득 일 때만 활성화 조건
      if (!nation.tinOmitValList) return false
      for (let i = 0; i < nation.tinOmitValList.length; i++) {
        if (nation.tinOmitValList[i] === '미취득') return true
      }
      return false
    },
    clickCloseNation (idx) {
      this.nationList.splice(idx, 1)
    }
  }
}
</script>
