<template>
  <section class="-pub-customer-register -pub-electronic-signature">
    <div class="-pub-customer-register__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">전자서명</span>
      </h1>
      <!-- stepper component 기반 버튼 틀 (-pub-customer-register__stepper 클래스는 -pub-customer-register 내부에 의존하고있기때문에 제외하고 사용해야합니다.) -->
        <div class="-pub-electronic-signature__stepper -pub-stepper__container">
          <!-- step item 상태는 current와 complete 상태가 존재합니다.  -pub-stepper__item--complete 클래스추가시 내부 텍스트가 check 아이콘으로 변경되며, current시에는 배경색과 글자색이 active color로 변경됩니다.-->
          <a class="-pub-stepper__item -pub-stepper__item--complete"><span class="-pub-stepper__text">1</span></a>
          <a class="-pub-stepper__item -pub-stepper__item--current"><span class="-pub-stepper__text">2</span></a>
          <a class="-pub-stepper__item"><span class="-pub-stepper__text">3</span></a>
          <a class="-pub-stepper__item"><span class="-pub-stepper__text">4</span></a>
        </div>
        <!-- stepper component 기반 버튼 틀 end -->
    </div>
    <div class="-pub-customer-register__content">
        <!-- step1 -->
        <section class="-pub-electronic-signature__step-content">
          <form class="-pub-form -pub-customer-register-form">

            <div class="-pub-electronic-signature__container--question">
                <div class="-pub-electronic-signature__step-title">
                    <label class="-pub-badge-tag -pub-electronic-signature__tag--insured-person">피보험자</label>
                    <span>김서현</span>
                </div>
                <ul class="-pub-electronic-signature__question--area">
                    <li v-for="(question, idx) in questionTypes" :key="idx" tabindex="1" :class="idx === 0 ? '-pub-electronic-signature__question--focus' : ''" class="-pub-electronic-signature__question">
                        <span class="-pub-electronic-signature__question--index">{{idx+1}}</span><span class="-pub-electronic-signature__question--text" v-html="question">{{question}}</span>
                    </li>
                    <li v-if="false" v-for="(question, idx) in questionTypes" :key="idx" tabindex="1" class="-pub-electronic-signature__question -pub-electronic-signature__question--focus">
                        <span class="-pub-electronic-signature__question--index">{{idx+1}}</span><span class="-pub-electronic-signature__question--text" v-html="question">{{question}}</span>
                    </li>
                </ul>
            </div>
              <div class="-pub-electronic-signature__container--answer">
                  <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__answer--yesno">
                      <div class="-pub-electronic-signature-form__content">
                          <fdp-segment-box class="-pub-segment__container "
                                           v-model="answerType1"
                                           :data="answerTypes"
                                           :item-width="'284px'"
                          ></fdp-segment-box>
                      </div>
                  </div>
                  <!-- 단순선택형영역 -->
                  <!-- 내부 설문 단순선택형 field 존재할떄 -->
                  <div class="-pub-electronic-signature-form__area" >
                      <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__answer--car">
                          <div class="-pub-electronic-signature-form__content">
                              <div class="-pub-electronic-signature-form__title"><span>차종선택</span></div>
                              <ul class="-pub-electronic-signature-form__select-grid">
                                  <li v-for="(car, idx) in carTypes" :key="idx" tabindex="1" :class="idx === 0 ? '-pub-electronic-signature-form__select--active' : ''" class="-pub-electronic-signature-form__select-grid-item"><div><span>{{car.text}}</span><span>{{car.text2}}</span></div></li>
                              </ul>
                          </div>
                      </div>
                      <div class="-pub-electronic-signature-form__row -pub-electronic-signature-form__answer--etc">
                          <div class="-pub-electronic-signature-form__content">
                              <div class="-pub-electronic-signature-form__title"><span>기타</span></div>
                              <fdp-text-field class="-pub-electronic-signature-form__item -pub-customer-register-form__input -pub-electronic-signature-form__input -pub-electronic-signature-form__input--etc"></fdp-text-field>
                          </div>
                      </div>
                  </div>
                  <!-- 내부 설문 단순선택형 field 존재할떄 end -->
                  <!-- 내부 설문 단순선택형 초기상태 -->
                  <div v-if="false" class="-pub-electronic-signature-form__area -pub-electronic-signature-form__area--empty"></div>
                  <!-- 내부 설문 단순선택형 빈영역일떄 end -->
                  <!-- 확인버튼 단순선택형 field 존재여부에 따라서 show/hide -->
                  <button type="submit" class="-sup-submit-button">확인</button>
                  <!-- 확인버튼 end -->
                  <!-- 단순선택형영역 end -->
              </div>
          </form>
        </section>
    </div>
  </section>
</template>
<script>
export default {
  data () {
    return {
      questionTypes: ['현재 운전을 하고 있습니까?',
        '최근 3개월 이내에 의사로부터 진찰 또는 검사(건강검진 포함)를 통하여<br> \n' +
              '다음과 같은 의료 행위를 받은 사실이 있습니까?',
        '최근 3개월 이내에 마약을 사용하거나 혈압강화제, 신경안정제, 수면제,<br> \n' +
              '각성제(흥분제), 진통제 등 약물을 상시 복용한 사실이 있습니까?',
        '최근 1년 이내에 의사로부터 진찰 또는 검사를 통하여<br> \n' +
              '추가검사(재검사)를 받은 사실이 있습니까?',
        '최근 5년 이내에 의사로부터 진찰 또는 검사를 통하여<br>\n' +
              '다음과 같은 의료행위를 받은 사실이 있습니까?',
        '최근 5년 이내에 아래 11대 질병으로 의사로부터 진찰 또는 검사를<br> \n' +
              '통하여 다음과 같은 의료행위를 받은 사실이 있습니까?',
        '(여성의 경우) 현재 임신중입니까?'],
      answerTypes: [
        {'key': '1', 'label': '아니요'},
        {'key': '2', 'label': '예'}
      ],
      carTypes: [
        {'key': '1', 'text': '승용차', 'text2': '영업용'},
        {'key': '2', 'text': '승합차', 'text2': '자가용'},
        {'key': '3', 'text': '승합차', 'text2': '영업용'},
        {'key': '4', 'text': '승용차', 'text2': '자가용'},
        {'key': '5', 'text': '화물차', 'text2': '영업용'},
        {'key': '6', 'text': '화물차', 'text2': '자가용'},
        {'key': '7', 'text': '오토바이', 'text2': '50cc미만 포함'},
        {'key': '8', 'text': '건설기계'},
        {'key': '9', 'text': '농기계'}
      ],
      answerType1: [],
      carType: []
    }
  },
  created () {
    // this.answerType1.push(this.answerTypes[1]);
    this.carType.push(this.carTypes[1])
  }
}
</script>
