<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--pension-1">
      <div class="-pub-consulting-content__fixed">
        <div class="-pub-consulting-content__wrapper">
          <div class="-pub-consulting-content__pension-info">
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">보유 연금상품</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">3</span>건
              </div>
            </div>
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">월납입 보험료</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">340,000</span>원
              </div>
            </div>
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">납입하신 보험료</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">36,100,000</span>원
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="-pub-consulting-content__scroll">
        <div class="-pub-consulting-content__pension-content">
          <div class="-pub-consulting-grid">
            <div class="-pub-consulting-grid__top-menu align-right">
              <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="showPension" @input="addProductRow">종신보험
                연금전환</fdp-checkbox>
            </div>
            <fdp-infinite :items="mockData" class="-pub-table" :tableBodyHeight="500" :tableHeaderHeight="126">
              <template slot="header">
                <tr class="-pub-table__header">
                  <th class="-pub-consulting-grid__column" style="width: 140px">가입회사</th>
                  <th class="-pub-consulting-grid__column" style="width: 350px">보험명</th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>55</span>세</div>
                  </th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>60</span>세</div>
                  </th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>65</span>세</div>
                  </th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>70</span>세</div>
                  </th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>75</span>세</div>
                  </th>
                  <th class="-pub-consulting-grid__column">
                    <div class="-pub-consulting-grid__column--graph-head"><span>80</span>세</div>
                  </th>
                </tr>
              </template>
              <template slot-scope="props">
                <td class="-pub-consulting-grid__column" style="width: 140px; word-break: keep-all">{{props.item.company}}</td>
                <td class="-pub-consulting-grid__column align-left" style="width: 350px">{{props.item.productName}}</td>
                <td class="-pub-consulting-grid__column -pub-consulting-grid__column--graph-data">
                  <div class="-pub-data-block">
                    <div class="-pub-data-block__item"
                         v-for="(data, index3) in graphData"
                         :key="index3"
                         :class="[
                                  '-pub-data-block__item--size-' + data.blockSize, '-pub-data-block__item--light-' + (data.blockColorLevel || index3 + 1),
                                  {'-pub-data-block__item--empty' : data.isEmpty}
                                  ]">
                      <p class="-pub-data-block__text">
                        <template>
                          <span class="-pub-data-block__single-before-text -pub-data-block__single-before-text--center">{{data.price}}</span>
                        </template>
                      </p>
                    </div>
                  </div>
                </td>
              </template>
            </fdp-infinite>
            <div class="-pub-consulting-grid__bottom-info">
              <span class="-pub-consulting-contract-info__item--price">총 月 예상연금(65세 기준) <span class="-pub-consulting-contract-info__number-text">134</span></span>
              <span class="-pub-consulting-contract-info__item--price">총 年 예상연금(65세 기준) <span class="-pub-consulting-contract-info__number-text">1,610</span></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  mockData,
  addProduct
} from '@/components/mock/TSSCT017M.mock'
export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      showPension: false,
      graphData: [ { price: '106', blockSize: 2 }, { price: '86' }, { price: '64' }, { price: '40' }, {price: '18'} ],
      mockData: Array.prototype.slice.call(mockData),
      addProduct: Object.assign({}, addProduct)
    }
  },
  watch: {},
  methods: {
    addProductRow () {
      if (this.showPension) {
        this.mockData.unshift(this.addProduct)
      } else {
        this.mockData.splice(0, 1)
      }
      this.$nextTick(() => {
        this.$refs.scroll.scrollTop = 0
      })
    }
  },
  computed: {},
  mounted () {}
}
</script>
