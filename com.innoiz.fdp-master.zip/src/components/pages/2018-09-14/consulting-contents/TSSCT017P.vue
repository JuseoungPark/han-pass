<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--pension-2">
      <div class="-pub-consulting-content__fixed">
        <div class="-pub-consulting-content__wrapper">
          <p class="-pub-consulting-content__unit">
            <fdp-checkbox style="float:left;" class="-pub-checkbox" isIconCheckbox v-model="visibleLivingCost">월 희망생활비
              있을때</fdp-checkbox>
              <span>※ 단위:만원</span>
          </p>
          <table class="-pub-consulting-content__header" v-for="(row, index) in tableHeaderMock" :key="index">
            <colgroup>
              <col width="260px" />
              <col width="150px" />
              <col width="158px" />
            </colgroup>
            <thead>
              <tr>
                <th>{{row.title}}</th>
                <td class="align-center">설계전 연금</td>
                <td class="align-center">설계후 연금</td>
              </tr>
            </thead>
            <tbody>
              <template v-for="(data, index2) in row.data">
                <tr :key="index2">
                  <td>{{data.type}}</td>
                  <td class="align-right normal-letter">{{data.before}}</td>
                  <td class="align-right bold-text normal-letter" v-html="getRangeNumberHTML(data.after)"></td>
                </tr>
              </template>
              <tr>
                <td class="align-left bold-text">월 연금액 합계</td>
                <td class="align-right normal-letter">469</td>
                <td class="align-right bold-text normal-letter" v-html="getRangeNumberHTML('508~518')"></td>
              </tr>
              <!-- 월 희망생활비 있는경우 추가데이터 -->
              <tr v-if="visibleLivingCost">
                <td class="align-left bold-text">
                  과부족
                  <p class="-pub-consulting-content__guide-text">(희망 월 생활비 1,634만원)</p>
                </td>
                <td class="align-right normal-letter" :class="isInteger('-330,000') ? '' : 'is-negative'">-330,000</td>
                <td class="align-right bold-text normal-letter" :class="isInteger('-115') ? '' : 'is-negative'" v-html="getRangeNumberHTML('-115~125')"></td>
              </tr>
              <!-- 월 희망생활비 있는경우 추가데이터 end -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="-pub-consulting-content__scroll">
          <div class="-pub-product-graph">
            <!-- 그래프 head영역 -->
            <div class="-pub-product-graph__head-container">
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>55</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>60</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>65</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>70</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>75</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>80</span>세</div>
              </div>
            </div>
            <!-- 그래프 head영역 end -->
            <!-- 그래프 body 영역 -->
            <div class="-pub-product-graph__body" v-for="(blockGroup, index) in blockData" :key="index">
              <div class="-pub-product-graph__row" v-for="(blockRow, index2) in blockGroup" :key="index2">
                <div class="-pub-data-block">
                  <div class="-pub-data-block__item -pub-data-block__item--small"
                       v-for="(data, index3) in blockRow"
                       :key="index3"
                       :class="['-pub-data-block__item--size-' + data.blockSize, '-pub-data-block__item--light-' + (data.blockColorLevel || blockRow.length - (index3 + 1) ),{'-pub-data-block__item--empty' : data.isEmpty}]">
                    <p class="-pub-data-block__text" >
                        <span class="-pub-data-block__after-text" v-if="index3 === 0">설계전<br>후</span>
                        <span v-if="data.isSingleText" class="-pub-data-block__single-before-text">{{data.price}}</span>
                        <span v-else  class="-pub-data-block__after-text -pub-data-block__after-text--price">{{data.price}}<span class="-pub-data-block__after-price">{{data.afterPrice || 0}}</span></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="-pub-product-graph__row" v-if="visibleLivingCost">
                <div class="-pub-data-block">
                  <div class="-pub-data-block__item -pub-data-block__item--small"
                       v-for="(data, index3) in livingCostGraph"
                       :key="index3"
                       :class="['-pub-data-block__item--size-' + data.blockSize, '-pub-data-block__item--light-' + (data.blockColorLevel || livingCostGraph.length - (index3 + 1) ),{'-pub-data-block__item--empty' : data.isEmpty}]">
                    <p class="-pub-data-block__text" >
                        <span class="-pub-data-block__single-before-text"><span :class="isInteger(data.price) ? '' : 'is-negative'">{{data.price}}</span></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- 그래프 body 영역 end -->
          </div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  productList
} from '@/components/mock/TSSCT019M.mock'

export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      visibleLivingCost: true,
      livingCostGraph: [ { price: '-335,000', blockColorLevel: 6 }, { price: '-333', blockColorLevel: 6 }, { price: '-121', blockColorLevel: 6 }, { price: '-99', blockColorLevel: 6 }, { price: '-100', blockColorLevel: 6 }, { price: '+20', blockColorLevel: 2 } ],
      isAfter: true,
      blockData: [
        [
          [ { price: '200,000', afterPrice: '333,500', blockSize: 4, blockColorLevel: 4 }, { price: '3,000', blockColorLevel: 5 }, { price: '2,500', blockColorLevel: 6 } ],
          [ { price: '0', blockColorLevel: 6, blockSize: 2 }, { blockColorLevel: 5, price: '212', isSingleText: true }, { blockColorLevel: 4, price: '234', isSingleText: true }, { blockColorLevel: 3, price: '258', isSingleText: true }, { blockColorLevel: 3, price: '333,500', isSingleText: true } ],
          [ { price: '116', afterPrice: '116', blockSize: 6, blockColorLevel: 6 } ],
          [ { price: '250', afterPrice: '301' }, { price: '250', afterPrice: '350' }, { price: '450', afterPrice: '513' }, { price: '480', afterPrice: '535' }, { price: '490', afterPrice: '534' }, { price: '400', afterPrice: '445' } ]
        ]
      ],
      tableData: [],
      tableHeaderMock: [{
        title: '연금',
        columnTitle: '사망',
        data: [{
          type: '개인연금',
          before: '333,000',
          after: '228,000~229,000'
        },
        {
          type: '국민연금',
          before: '333,000',
          after: '212'
        },
        {
          type: '퇴직연금',
          before: '333,000',
          after: '116'
        }
        ]
      }],
      productConfigList: [].concat(Array.prototype.slice.call(productList), Array.prototype.slice.call(productList), Array.prototype.slice.call(productList)),
      productList: Array.prototype.slice.call(productList)
    }
  },
  methods: {
    getRangeNumberHTML (numberText = '') {
      return numberText.replace('~', '<br>~')
    },
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    replaceArrowText (numberText = '') {
      return `${numberText.indexOf('-') === -1 ? '▲' : '▼'}${numberText.substring(1, numberText.length)}`
    },
    remove (item, i) { // 상품목록에서 삭제한 상품은 상품추가 및 삭제 리스트로 이동.
      this.productConfigList.push(item)
      this.productList.splice(i, 1)
      this.isVisible = true
    },
    addProduct (item, index) { // 상품추가 및 삭제 리스트의 상품 클릭 시 상품목록으로 이동.
      this.productList.push(item)
      this.productConfigList.splice(index, 1)
    }
  },
  computed: {}
}
</script>
