<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--sticky-scroll">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--pension-2">
      <div class="-pub-consulting-content__fixed">
        <div class="-pub-consulting-content__wrapper">
          <p class="-pub-consulting-content__unit">
            <fdp-checkbox style="float:left;" class="-pub-checkbox" isIconCheckbox v-model="visibleLivingCost">월 희망생활비
              있을때</fdp-checkbox><span>단위:만원</span>
          </p>
          <table class="-pub-consulting-content__header" v-for="(row, index) in tableHeaderMock" :key="index">
            <colgroup>
              <col width="260px" />
              <col width="150px" />
              <col width="158px" />
            </colgroup>
            <thead>
              <tr>
                <th>{{row.title}}</th>
                <td class="align-center">설계전 연금</td>
                <td class="align-center">설계후 연금</td>
              </tr>
            </thead>
            <tbody>
              <template v-for="(data, index2) in row.data">
                <tr :key="index2">
                  <td>{{data.type}}</td>
                  <td class="align-right normal-letter">{{data.before}}</td>
                  <td class="align-right bold-text normal-letter" v-html="getRangeNumberHTML(data.after)"></td>
                </tr>
              </template>
              <tr>
                <td class="align-left bold-text">월 연금액 합계</td>
                <td class="align-right normal-letter">469</td>
                <td class="align-right bold-text normal-letter" v-html="getRangeNumberHTML('508~518')"></td>
              </tr>
              <!-- 월 희망생활비 있는경우 추가데이터 -->
              <tr v-if="visibleLivingCost">
                <td class="align-left bold-text">
                  과부족
                  <p class="-pub-consulting-content__guide-text">(희망 월 생활비 1,634만원)</p>
                </td>
                <td class="align-right normal-letter" :class="isInteger('-330,000') ? '' : 'is-negative'">-330,000</td>
                <td class="align-right bold-text normal-letter" :class="isInteger('-115') ? '' : 'is-negative'" v-html="getRangeNumberHTML('-115~125')"></td>
              </tr>
              <!-- 월 희망생활비 있는경우 추가데이터 end -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="-pub-consulting-content__scroll">
          <section class="-pub-product-card__container">
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
            <article class="-pub-product-card__item" v-for="(item, i) in productList" :key="i" :class="{'-pub-product-card__item--point': item.isRecommendProduct }">
              <div class="-pub-product-card__title-area">
                <a class="-pub-product-card__remove-button" v-if="item.canDelete" @click="remove(item, i)"></a>
                <h2 class="-pub-product-card__title">{{item.name}}</h2>
                <div class="-pub-product-card__sub-content">
                  <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                    <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                    <span class="-pub-product-card__badge-label" v-else>자사</span>

                    <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                    <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                  </span>
                  <div class="-pub-product-card__month-text normal-letter"><span class="sub-text">월</span> <span class="bold-text">{{item.monthPrice}}
                      원</span>
                  </div>
                </div>
              </div>
              <div class="-pub-product-card__content-area">
                <ul class="-pub-product-card__column" v-for="(detailList, j) in item.details" :key="j">
                  <li v-for="(price, k) in detailList" class="-pub-product-card__row normal-letter" :key="k">
                    <template v-if="typeof price ==='string'">
                      <span class="-pub-product-card__row-value--normal">{{price}}</span>
                    </template>
                    <template v-else>
                      <ul class="-pub-product-card__row-value-list">
                        <li class="-pub-product-card__row-value-item" v-for="(item, i2) in price" :key="i2">
                          <span class="-pub-product-card__row-text--number">{{item.value}}</span>
                          <span class="-pub-product-card__row-text--percentage">{{item.percentage}}%</span>
                        </li>
                      </ul>
                    </template>
                  </li>
                  <!-- 월 희망생활비 있는경우 추가컬럼 -->
                  <li class="-pub-product-card__row" v-if="visibleLivingCost"><span class="-pub-product-card__row-value--normal">-</span></li>
                  <!-- 월 희망생활비 있는경우 추가컬럼 end -->
                </ul>
              </div>
            </article>
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
            <!-- 상품 삭제시 상품 추가 및 삭제 영역 나타남 -->
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정  -->
            <article class="-pub-product-card__item -pub-product-card__item--product-config -pub-product-card__item--transparent">
              <div class="-pub-product-card__title-area">
                <h2 class="-pub-product-card__title">상품추가 및 삭제</h2>
              </div>
              <div class="-pub-product-card__content-area">
                <ul class="-pub-product-card__column">
                  <li class="-pub-product-card__add-card" :class="{'-pub-product-card__add-card--point': item.isRecommendProduct}"
                    v-for="(item, index) in productConfigList" :key="index" @click="addProduct(item, index)">
                    <h2 class="-pub-product-card__title">{{item.name}}</h2>
                    <div class="-pub-product-card__sub-content">
                      <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                        <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                        <span class="-pub-product-card__badge-label" v-else>자사</span>

                        <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                        <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                      </span>
                      <div class="-pub-product-card__month-text normal-letter"><span class="sub-text">월</span> <span
                          class="bold-text">85,350 원</span></div>
                    </div>
                  </li>
                  <!-- 새로설계하기 버튼 -->
                  <li class="-pub-product-card__add-button" tabindex="1">
                    <img src="@/assets/img/ico-plus-2-nor.png" alt="새로설계하기" />
                    새로설계하기
                  </li>
                </ul>
              </div>
            </article>
            <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
          </section>
      </div>
    </div>
  </div>
</template>

<script>
import {
  productList,
  productConfigList
} from '@/components/mock/TSSCT019M.mock'

import {
  createScrollAnimateInstance
} from '@/components/util/scroll-animate'
export default {

  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      visibleLivingCost: true,
      tableData: [],
      tableHeaderMock: [{
        title: '연금',
        columnTitle: '사망',
        data: [{
          type: '개인연금',
          before: '333,000',
          after: '228,000~229,000'
        },
        {
          type: '국민연금',
          before: '333,000',
          after: '212'
        },
        {
          type: '퇴직연금',
          before: '333,000',
          after: '116'
        }
        ]
      }],
      productConfigList: [].concat(Array.prototype.slice.call(productConfigList), Array.prototype.slice.call(productConfigList), Array.prototype.slice.call(productConfigList)),
      productList: Array.prototype.slice.call(productList)
    }
  },
  methods: {
    getRangeNumberHTML (numberText = '') {
      return numberText.replace('~', '<br>~')
    },
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    replaceArrowText (numberText = '') {
      return `${numberText.indexOf('-') === -1 ? '▲' : '▼'}${numberText.substring(1, numberText.length)}`
    },
    remove (item, i) { // 상품목록에서 삭제한 상품은 상품추가 및 삭제 리스트로 이동.
      this.productConfigList.push(item)
      this.productList.splice(i, 1)
      this.isVisible = true
    },
    addProduct (item, index) { // 상품추가 및 삭제 리스트의 상품 클릭 시 상품목록으로 이동.
      this.productList.push(item)
      this.productConfigList.splice(index, 1)
    }
  },
  mounted () {
    const scrollEl = this.$el

    // 스크롤 애니메이션 인스턴스 생성 1000ms 후에 이동 이벤트 scrollAnimation 관련 scroll-animate.js 파일 참조
    const scrollXAnimate = createScrollAnimateInstance(scrollEl, 'x')
    // aguments 순서 (이동할 좌표픽셀값, 진행시간, 딜레이, 타이밍 function name, 애니메이션 끝난후 콜백 function)
    // scrollXAnimate.animate(500, 1500, 1000, 'easeInOut', _ => console.log('애니메이션 끝'))
    scrollXAnimate.animate(scrollEl.scrollWidth - scrollEl.clientWidth, 1500, 1000, 'easeInOut', _ => console.log('애니메이션 끝'))
  }
}
</script>
