<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding -pub-consulting-content--hide-sub-tab">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--pension-1">
      <div class="-pub-consulting-content__fixed -pub-consulting-content__fixed--no-padding">
        <h2 class="-pub-consulting-content__pension-title">
          보장현황
          <fdp-tooltip-button class="-pub-tooltip">
            <template slot="activator">
              <img class="-pub-tooltip__icon" src="@/assets/img/components/ico_info_gray.png" alt="툴팁" />
            </template>
            <template slot="content">
              <ul class="-pub-tooltip__guide-list">
                <li class="-pub-tooltip__guide-item">
                  기계약건이 모두 조회되지 않는 경우 좌측 하단의 날짜를 탭하여 정보를 업데이트하시기 바랍니다.
                  단, 계약상태가 정상이 아닌 건은 조회되지 않습니다.
                </li>
                <li class="-pub-tooltip__guide-item">
                  계약납면은 당사가 해당계약의 주보험과 전체 특약에 대해 보험료를 대납해드리는 계약이며,
                  일부납면은 납입면제처리된 일부 특약 또는 주보험에 대해 대납해 드리는 계약입니다.
                </li>
              </ul>
            </template>
          </fdp-tooltip-button>
        </h2>
        <div class="-pub-consulting-content__wrapper">
          <div class="-pub-consulting-content__pension-info -pub-consulting-content__pension-info--margin-2">
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">계약건수</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">7</span>건
              </div>
            </div>
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">월납입 보험료</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">340,000</span>원
              </div>
            </div>
            <div class="-pub-consulting-content__pension-info-item">
              <p class="-pub-consulting-content__pension-info-name">납입하신 보험료</p>
              <div class="-pub-consulting-content__pension-info-value">
                <span class="-pub-consulting-content__pension-info-text--price">7,746,080</span>원
              </div>
            </div>
            <button class="-pub-button -pub-button--light -pub-button--refresh">
              <span><img class="-pub-icon--refresh" src="@/assets/img/ico-refreshment.png" alt="" />2018-07-25 12:00</span>
            </button>
          </div>
        </div>
      </div>
      <div class="-pub-consulting-content__scroll -pub-consulting-content__scroll--no-padding-bottom">
        <ul class="-pub-life-card">
          <li class="-pub-life-card__item" :class="[mock.color ? '-pub-life-card__item--' + mock.color : '', {'-pub-life-card__item--visible': visibleIndex === index}]" v-for="(mock, index) in mockData" :key="index">
            <div class="-pub-life-card__hidden-content" @click="visibleIndex = index">{{mock.title}}</div>
            <div class="-pub-life-card__visible-content">
              <div class="-pub-life-card__info">
                <h4 class="-pub-life-card__title">{{mock.title}}</h4>
                <blockquote class="-pub-life-card__sub-title">{{mock.subTitle}}</blockquote>
                <p class="-pub-life-card__description">{{mock.description}}</p>
              </div>
              <div class="-pub-life-card__graph-container">
                <div class="-pub-graph-zone"></div>
              </div>
              <div class="-pub-consulting-grid -pub-consulting-grid--bg-2">
                <ul class="-pub-consulting-grid__head">
                  <li class="-pub-consulting-grid__row">
                    <div class="-pub-consulting-grid__column" style="width: 176px"></div>
                    <div class="-pub-consulting-grid__column" style="width: 260px">총보장자산</div>
                    <div class="-pub-consulting-grid__column" style="width: 260px">표준모델</div>
                    <div class="-pub-consulting-grid__column" style="width: 270px">과부족현황</div>
                  </li>
                </ul>
                <ul class="-pub-consulting-grid__body" ref="scroll">
                  <li class="-pub-consulting-grid__row" v-for="(item, index2) in mock.data" :key="index2">
                    <div class="-pub-consulting-grid__column bold-text" style="width: 176px;">{{item.type}}</div>
                    <div class="-pub-consulting-grid__column normal-letter align-right" style="width: 260px">{{item.amount}} 만원</div>
                    <div class="-pub-consulting-grid__column normal-letter align-right" style="width: 260px">{{item.requireAmount}} 만원</div>
                    <div class="-pub-consulting-grid__column normal-letter align-right" style="width: 270px"><span :class="isInteger(item.overAmount) ? '' : 'is-negative'">{{item.overAmount}}</span> 만원</div>
                  </li>
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      visibleIndex: 0,
      mockData: [
        {
          title: '가족보장',
          subTitle: `고객님의 준비된 가족보장은
          필요자금대비 00%입니다.`,
          color: 'green',
          description: `고객님의 의료보장 분석 결과 적정 보장자산 항목 00건, 부족 00건,
없음 00건으로 분석되었습니다.`,
          data: [{
            type: '암사망',
            amount: '555,555',
            requireAmount: '555,555',
            overAmount: '-500,000'
          },
          {
            type: '일반사망',
            amount: '55,871',
            requireAmount: '10,000',
            overAmount: '+450,871'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          }]
        },
        {
          title: '생활보장',
          subTitle: `고객님의 준비된 가족보장은
          필요자금대비 00%입니다.`,
          description: `고객님의 의료보장 분석 결과 적정 보장자산 항목 00건, 부족 00건,
없음 00건으로 분석되었습니다.`,
          data: [{
            type: '암사망',
            amount: '555,555',
            requireAmount: '555,555',
            overAmount: '-500,000'
          },
          {
            type: '일반사망',
            amount: '55,871',
            requireAmount: '10,000',
            overAmount: '+450,871'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          }]
        },
        {
          title: '의료보장',
          subTitle: `고객님의 준비된 가족보장은
          필요자금대비 00%입니다.`,
          description: `고객님의 의료보장 분석 결과 적정 보장자산 항목 00건, 부족 00건,
없음 00건으로 분석되었습니다.`,
          color: 'cyan',
          data: [{
            type: '암사망',
            amount: '555,555',
            requireAmount: '555,555',
            overAmount: '-500,000'
          },
          {
            type: '일반사망',
            amount: '55,871',
            requireAmount: '10,000',
            overAmount: '+450,871'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '교통재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          },
          {
            type: '일반재해',
            amount: '70,971',
            requireAmount: '10,000',
            overAmount: '+60,971'
          }]
        }
      ]

    }
  },
  watch: {},
  methods: {
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    replaceArrowText (numberText = '') {
      return `${numberText.indexOf('-') === -1 ? '▲' : '▼'}${numberText.substring(1, numberText.length)}`
    }
  }
}
</script>
<style>
</style>
