<template>
  <section>
    <!-- 페이지 서브 메뉴 영역 end -->
    <div class="-pub-contents">
      <!-- 페이지 조회 input, button 검색 명수 영역  -->
      <div class="-pub-filter-menu -pub-filter-menu__margintop"><!-- 20181101 마크업 추가 -pub-filter-menu__margintop -->
          <div class="-pub-filter-menu__item--right">
            <form onsubmit="return false;">
              <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
              <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
              </button>
              <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
              <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>상세조회</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
              </a>
              <!-- 상세조회 버튼영역 end -->
            </form>
          </div>
          <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
      </div>
      <!-- 페이지 조회 input, button 검색 명수 영역 end -->
      <template v-if="isDetailSearch" >
          <div class="-pub-filter-detail__scroll">
            <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
            <!-- 임직원일 경우에만 보이는 상세조회 field -->
            <template v-if="true">
              <li class="-pub-filter-detail__area">
                <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
                <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                  :option-list="selectGroups.group1"></fdp-select>
                <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
                  :option-list="selectGroups.group2"></fdp-select>
                <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
                  :option-list="selectGroups.group3"></fdp-select>
              </li>
              <li class="-pub-filter-detail__area">
                <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
                <!-- 마크업 변경 detail-type-4 => detail-type-5 20181018 -->
                <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4"
                  placeholder="담당 컨설턴트"></fdp-select>
              </li>
            </template>
            <!-- 임직원일 경우에만 보이는 상세조회 field end -->
          </ul>
          <!-- 정보활용동의 현황 상세조회 FC field end-->
          </div>
         <div class="-pub-filter-detail__bottom">
            <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
                <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                      <span class="-pub-button__text">조회</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                      <span class="-pub-button__text">초기화</span>
                    </button>
                  </li>
             </ul>
         </div>
        </template>
        <!-- 정보활용동의 현황 상세조회 FC  -->
        <div :class="hasSelectItem ? '-pub-table-height__onBottom5' : '-pub-table-height__offBottom5'">
        <fdp-infinite class="-pub-table" v-model="selectItems" multi-select :items="mockData" :table-body-height="hasSelectItem ? 788 : 788">
          <template slot="header">
            <tr class="-pub-table__header">
              <th class="-pub-table-column--checkbox">
                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
              </th>
              <th class="-pub-table-column" style="width: 204px;">고객명</th>
              <th class="-pub-table-column" style="width: 236px;">생년월일</th>
              <th class="-pub-table-column" style="width: 158px;">성별</th>
              <th class="-pub-table-column" style="width: 124px;">주고객명</th>
              <th class="-pub-table-column" style="width: 188px;">관계</th>
              <th class="-pub-table-column" style="width: 204px;">삭제예정일</th>
              <th class="-pub-table-column" style="width: 238px;">승인요청일</th>
            </tr>
          </template>
          <template slot-scope="props">
            <td class="-pub-table-column--checkbox">
              <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems"
                :value="props.item"></fdp-checkbox>
            </td>
            <td class="-pub-table-column -pub-table-column--name" style="width: 204px;">{{props.item.name}}</td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 236px;">{{props.item.birthDay}}</td>
            <td class="-pub-table-column" style="width: 158px;">{{props.item.gender}}</td>
            <td class="-pub-table-column -pub-table-column--name" style="width: 124px;">{{props.item.mainCustomer}}</td>
            <td class="-pub-table-column" style="width: 188px;">{{props.item.conectivity}}</td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 204px;">{{props.item.delectDate}}</td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 238px;">{{props.item.confirmDate}}</td>
          </template>
          <template slot="emptyView" v-show="mockData.length == 0"><!-- 마크업변경 20181113 -->
              <div class="-pub-table-empty-view">
                  <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
              <div class="-pub-table-empty-view -pub-table-empty-view--search">
                  <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
              </div>
          </template>
        </fdp-infinite>
      </div>
    </div>
    <!-- 고객 관련 정보 데이터 테이블 영역 end -->
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component (VIP 서비스 신청에서는 항상 고정)-->
     <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="!hasSelectItem" :page-fixed="true">
        <ul class="-pub-bottom-nav">
          <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--guide -pub-bottom-nav__item--centered">
              5일 이내 미동의 시 본 고객정보는 자동 삭제됩니다.
            <!--<fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="hasSelectItem">{{mockCheckCount}}명 선택</fdp-checkbox>-->
          </li>
        </ul>
      </fdp-bottom-bar>
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component-->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="hasSelectItem" :page-fixed="false">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--left-align -pub-bottom-nav__item--guide -pub-bottom-nav__item--centered">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
        </li>
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button type="button" @click="onDefaultModal()" class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">승인요청세대 삭제</span>
          </button>
        </li>
      </ul>
    </fdp-bottom-bar>
    <fdp-modal v-model="showDefaultModal" quit>
      <div class="-pub-popup__confirm">
        <div class="-pub-popup__confirm--content">
          <div class="-pub-popup__confirm--txtarea">
            선택한 고객의 세대원 중 '승인요청' 단계에 머물러 있는 모든 세대원의<br>승인요청이 삭제됩니다. 삭제신청 후 취소는 불가능합니다.<br>
            삭제하시겠습니까?
          </div>
        </div>
        <!-- 하단 버튼  start -->
        <div class="-pub-confirm__content--right">
            <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
              <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--confirm" @click="onDefaultModal()">
              <span class="-pub-button__text">확인</span>
            </button>
        </div>
       <!--// 하단 버튼  end -->
      </div>
    </fdp-modal>
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM216M.mock'
export default {
  data () {
    return {
      title: '고객',
      modals: {
        confirm1: false,
        confirm2: false
      },
      targetMonth1: '',
      targetMonth2: '',
      isDetailSearch: false,
      showDefaultModal: false,
      mockHeader: [],
      segmentfields: {
        confirmStatusValues: [{
          key: '1',
          label: '전체'
        }],
        confirmStatus: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '승인완료'
        },
        {
          key: '3',
          label: '승인취소'
        }
        ],
        agreeRouteValues: [{
          key: '1',
          label: '전체'
        }],
        agreeRoute: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '동의서'
        },
        {
          key: '3',
          label: '휴대폰'
        },
        {
          key: '4',
          label: '신용카드'
        },
        {
          key: '5',
          label: '휴대폰 사랑On'
        },
        {
          key: '6',
          label: '동의서 스마트CRM'
        },
        {
          key: '7',
          label: '휴대폰 스마트CRM'
        },
        {
          key: '8',
          label: '신용카드 스마트CRM'
        }
        ],
        searchDateValues: [{
          key: '1',
          label: '승인일'
        }],
        searchDate: [{
          key: '1',
          label: '승인일'
        },
        {
          key: '2',
          label: '유효시작일'
        }
        ],
        agreeItemValues: [{
          key: '1',
          label: '전체'
        }],
        agreeItem: [{
          key: '1',
          label: '전체'
        },
        {
          key: '2',
          label: '필수컨설팅'
        },
        {
          key: '3',
          label: '마케팅'
        },
        {
          key: '4',
          label: '보험상담'
        },
        {
          key: '5',
          label: '실존조회'
        },
        {
          key: '6',
          label: '전환설계'
        },
        {
          key: '7',
          label: '비교안내문'
        }
        ]
      },
      mockData: Array.prototype.slice.call(viewMemberMocks),
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      selectItems: [],
      isSelectAll: false,
      bottomBarCheck: false,
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '1',
            label: '김안범(000012312)'
          }
        }
      }
    }
  },
  methods: {
    onSizeChange (size) {},
    onDefaultModal () {
      this.showDefaultModal = !this.showDefaultModal
    },
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    },
    disabledTableStartDate () {
      return {
        from: new Date(this.targetMonth2),
        to: null
      }
    },
    disabledTableEndDate () {
      return {
        from: null,
        to: new Date(this.targetMonth1)
      }
    }
  },
  mounted () {},
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
</script>
