<template>
  <section class="-pub-publishing-server">
    <div class="-pub-customer-register__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">발행서버변경</span>
      </h1>
    </div>
    <div class="-pub-customer-register__content">
        <section class="-pub-section-content">
            <div class="-pub-section-left">
                <!-- 페이지 조회 input, button 검색 명수 영역  -->
                <div class="-pub-filter-menu">
                    <div class="-pub-filter-menu__item--right">
                        <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="컨설턴트 코드, 컨설턴트 명" v-model="searchKeyword" clearable></fdp-text-field>
                        <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                        <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </div>
                    <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{resultData.length}}건</div>
                </div>
                <!-- 페이지 조회 input, button 검색 명수 영역 end -->
                <!-- 컨설턴트 테이블 -->
                <fdp-infinite class="-pub-table" v-model="selectItems" single-select :items="resultData" :table-body-height="974">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column -pub-table-column--sorting" style="width: 348px;" @click="clickSortConsultantCd">
                                <!-- sorting 활성화: -pub-sorting--active, 내림차순: defalt, 오름차순: -pub-sorting--up, 파란색: default, 보라색: -pub-sorting--purple -->
                                <span :class="[{'-pub-sorting--active':true}, {'-pub-sorting--up':sortConsultantCd.isAsc}, {'-pub-sorting--purple':true}]">컨설턴트 코드
                                    <img src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                                </span>
                            </th>
                            <th class="-pub-table-column" style="width: 348px;">컨설턴트 명</th>
                        </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 348px;">{{props.item.code}}</td>
                        <td class="-pub-table-column " style="width: 348px;">{{props.item.name}}</td>
                    </template>
                    <!-- no data 화면 -->
                    <template slot="emptyView" v-if="!paramSearchKeyword">
                        <div class="empty-table-content">
                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                        </div>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView" v-else>
                        <div class="empty-table-content">
                            <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                        </div>
                    </template>
                </fdp-infinite>
            </div>
            <div class="-pub-section-right">
                <TSSBC411M :consultant-information="isClickedItem"></TSSBC411M>
            </div>
        </section>
    </div>
  </section>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSBC410M.mock'
import TSSBC411M from '@/components/pages/2018-09-14/TSSBC411M'

export default {
  components: {
    TSSBC411M
  },
  data () {
    return {
      mockData: Array.prototype.slice.call(viewMemberMocks),
      resultData: [],
      //   mockData: ''
      selectItems: null,
      searchKeyword: '',
      paramSearchKeyword: '',
      sortConsultantCd: {isAsc: true}
    }
  },
  computed: {
    isClickedItem () {
      return this.selectItems
    }
  },
  methods: {
    hasSelectItem () {
      return !!this.selectItems.length > 0
    },
    // 소팅 처리
    clickSortConsultantCd () {
      this.sortConsultantCd.isAsc = !this.sortConsultantCd.isAsc

      // Mockup 데이터
      let data = this.resultData

      if (this.sortConsultantCd.isAsc) {
        data.sort(
          function (a, b) { return a.code.localeCompare(b.code) }
        )
      } else {
        data.sort(
          function (a, b) { return b.code.localeCompare(a.code) }
        )
      }
    },
    onSearch () {
      this.paramSearchKeyword = this.searchKeyword
      if (this.searchKeyword === '1') {
        this.resultData = []
      } else {
        this.resultData = this.mockData
      }
    }
  }
}
</script>
