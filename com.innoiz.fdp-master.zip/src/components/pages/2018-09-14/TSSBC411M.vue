<template>
    <div>
        <div class="-pub-server-info-guide" v-if="isShowEmpty">
            <img src="@/assets/img/ico_hand_tap.png" alt="">
            <span>좌측에서 컨설턴트명을 선택하시면
해당 서버 정보를 볼 수 있습니다.</span>
        </div>
        <div class="-pub-server-info-detail" v-else>
            <div class="-pub-server-info__desc">
                <span class="-pub-server-info__code">{{consultantInfo.code}}</span>
                <span class="-pub-server-info__name">{{consultantInfo.name}}</span>
                <ul class="-pub-server-info__additional">
                    <li>
                        <span>조직번호</span>
                        <span>경북금융지점 (009402)</span>
                    </li>
                    <!-- 181029 발행지점 / 서버 개별 행으로 분리 start -->
                    <li>
                        <span>발행지점</span>
                        <span>부산AFC지역단(000077)</span>
                    </li>
                    <li>
                        <span>서버</span>
                        <span>100.1.1.1 (test서버)</span>
                    </li>
                    <!-- 181029 발행지점 / 서버 개별 행으로 분리 end -->
                </ul>
            </div>
            <!-- 페이지 조회 input, button 검색 명수 영역  -->
            <div class="-pub-filter-menu">
                <div class="-pub-filter-menu__item--right">
                    <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="조직명, 조직코드" v-model="searchKeyword" clearable></fdp-text-field>
                    <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="clickSearchButton">
                    <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                    </button>
                </div>
                <!-- [ 181102 클래스추가 -->
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item -pub-change-server">발행서버변경</div>
                <!-- 181102 클래스추가 ] -->
            </div>
            <!-- 페이지 조회 input, button 검색 명수 영역 end -->
            <!-- 조직 테이블 -->
            <!-- 181029 ----------------------------------------------------------------------------------------------------------- 테이블 높이 수정 -->
            <fdp-infinite class="-pub-table" v-model="selectItems" single-select :items="resultData" :table-body-height="hasSelectItem ? 560 : 694">
            <!-- 181029 ----------------------------------------------------------------------------------------------------------- 테이블 높이 수정 -->
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column -pub-table-column--sorting" style="width: 392px;" @click="clickSortGroupCd">
                            <!-- sorting 활성화: -pub-sorting--active, 내림차순: defalt, 오름차순: -pub-sorting--up, 파란색: default, 보라색: -pub-sorting--purple -->
                            <span :class="[{'-pub-sorting--active':true}, {'-pub-sorting--up':sortGroupCd.isAsc}, {'-pub-sorting--purple':true}]">조직코드
                                <img src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                            </span>
                        </th>
                        <th class="-pub-table-column" style="width: 392px;">조직명</th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 392px;">{{props.item.code}}</td>
                    <td class="-pub-table-column " style="width: 392px;">{{props.item.name}}</td>
                </template>
                <!-- no data 화면 -->
                <template slot="emptyView" v-if="searchWord === ''">
                    <div class="empty-table-content">
                        <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                        <div class="empty-table-content__text">조직명이나 조직코드로 검색하세요</div>
                    </div>
                </template>
                <!-- 검색결과 없을때 화면 -->
                <template slot="emptyView" v-else>
                    <div class="empty-table-content">
                        <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                        <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                    </div>
                </template>
            </fdp-infinite>

            <div class="-pub-server-info__bottom-bar" v-if="hasSelectItem">
                <span>발행서버</span>
                <fdp-select class="-pub-select -pub-select--purple" up v-model="serverSelect" :option-list="serverList"></fdp-select>
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                    <span class="-pub-button__text">변경</span>
                </button>
            </div>
        </div>
    </div>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSBC411M.mock'

export default {
  props: {
    consultantInformation: {
      type: Object,
      default: null
    }
  },
  data () {
    return {
      consultantInfo: this.consultantInformation,
      mockData: Array.prototype.slice.call(viewMemberMocks),
      resultData: [],
      //   mockData: '',
      searchKeyword: '',
      searchWord: '',
      selectItems: {},
      sortGroupCd: {isAsc: true},
      isShowEmpty: true,
      serverSelect: {
        label: '100.82.96.243(ntsvr009402)',
        key: 'a'
      },
      serverList: [{
        label: '100.82.96.243(ntsvr009402)',
        key: 'a'
      },
      {
        label: '100.82.96.243(ntsvr009402)',
        key: 'b'
      },
      {
        label: '100.82.96.243(ntsvr009402)',
        key: 'c'
      },
      {
        label: '100.82.96.243(ntsvr009402)',
        key: 'd'
      },
      {
        label: '100.82.96.243(ntsvr009402)',
        key: 'e'
      }]
    }
  },
  watch: {
    consultantInformation (newValue) {
      this.consultantInfo = newValue
    },
    consultantInfo () {
      if (this.consultantInfo.length === 0) {
        this.isShowEmpty = true
      } else {
        this.isShowEmpty = false
      }
    }
  },
  methods: {
    // 소팅 처리
    clickSortGroupCd () {
      this.sortGroupCd.isAsc = !this.sortGroupCd.isAsc

      // Mockup 데이터
      let data = this.resultData

      if (this.sortGroupCd.isAsc) {
        data.sort(
          function (a, b) { return a.code.localeCompare(b.code) }
        )
      } else {
        data.sort(
          function (a, b) { return b.code.localeCompare(a.code) }
        )
      }
    },
    clickSearchButton () {
      this.searchWord = this.searchKeyword
      if (this.searchKeyword === '1') {
        this.resultData = []
      } else {
        this.resultData = this.mockData
      }

      this.searchKeyword = ''
    }
  },
  computed: {
    hasSelectItem () {
      return !!this.selectItems.code
    }
  }
}
</script>
