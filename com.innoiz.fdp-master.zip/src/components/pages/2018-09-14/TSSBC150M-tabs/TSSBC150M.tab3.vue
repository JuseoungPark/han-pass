<template>
<div class="tab_03">
    <fdp-list class="-pub-header-content__body -content__tab3" :list-data="noticeData" :list-height="1104" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
      <template slot-scope="props">
        <div class="-pub-header-content__item" :class="[props.item.isNewRecord ? '-pub-header-content__item--new' : '']"  @click="openImg(props.item)">
          <a class="-pub-header-content__link">
            <span class="-pub-header-content__icon--new" v-if="props.item.isNewRecord"></span>

            <!-- 아코디언 열일때 -pub-pop-arrow--open 추가 -->
            <div class="-pub-header-content__info pop_arrow" :class="{'-pub-pop-arrow--open': props.item.isOpen }">
              <span class="-pub-header-content__info-title">{{props.item.text}}</span>
              <p class="-pub-header-content__info-data">
                <span class="-pub-header-content__badge">{{props.item.type}}</span>
                <span class="-pub-header-content__date" v-if="!props.item.isNewRecord">{{props.item.date}}</span>
                <span class="-pub-header-content__time">{{props.item.time}}</span>
              </p>
            </div>
          </a>
        </div>

        <!-- 해당 내용 하단 on 시 class="on_stky" 추가 -->
        <div class="on_content" v-show="props.item.isOpen">
            <span class="color_grey on_stky"><div>image</div></span>
        </div>
      </template>
    </fdp-list>
  </div>

</template>

<script>

export default {
  methods: {
    closeContent () {
      this.$emit('close')
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    },
    openImg (item) {
      if (item.isOpen) {
        item.isOpen = false
      } else {
        item.isOpen = true
      }
    }
  },
  data () {
    return {
      isEmpty: false,
      isLoadingStatus: false,
      noticeData: [
        {
          isNewRecord: true,
          text: `7월 특차마감 지점 프로모션 참여하세요!`,
          type: `지점`,
          time: `18:20`,
          date: `5일전`,
          isOpen: false
        },
        {
          text: `7월 특차마감 지점 프로모션 참여하세요!`,
          type: `플라자`,
          time: `18:20`,
          date: `1일전`,
          isOpen: false
        },
        {
          isNewRecord: false,
          text: `8월 특차마감 지점 프로모션 바로 참여하세요!`,
          type: `지점`,
          time: `18:20`,
          date: `1일전`,
          isOpen: false
        },
        {
          isNewRecord: true,
          text: `올 추석 특차마감 지점 프로모션 참여하세요!`,
          type: `지점`,
          time: `18:20`,
          date: `5일전`,
          isOpen: false
        },
        {
          isNewRecord: true,
          text: `1월 특차마감 지점 프로모션 참여하세요!`,
          type: `지점`,
          time: `18:20`,
          date: `5일전`,
          isOpen: false
        }
      ]
    }
  }
}
</script>
