<template>
  <div>
    <fdp-list class="-pub-header-content__body -content__tab2" :list-data="noticeData" :list-height="1104" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
      <!-- 최근 3일간 알림이 없습니다. : start -->
      <template slot="emptyView">
        <div class="empty-content">
          <p class="empty-content__text">
            시스템공지가 없습니다.
          </p>
        </div>
      </template>
      <!-- 최근 3일간 알림이 없습니다. : end -->
      <template slot-scope="props">
        <div class="-pub-header-content__item" :class="[props.item.isNewRecord ? '-pub-header-content__item--new' : '']">
          <a class="-pub-header-content__link">
            <span class="-pub-header-content__icon--new" v-if="props.item.isNewRecord"></span>
            <div class="-pub-header-content__info">
              <span class="-pub-header-content__info-title">{{props.item.text}}</span>
              <p class="-pub-header-content__info-data">
                <span class="-pub-header-content__badge">{{props.item.type}}</span>
                <span class="-pub-header-content__date" v-if="!props.item.isNewRecord">{{props.item.date}}</span>
                <span class="-pub-header-content__time">{{props.item.time}}</span>
              </p>
            </div>
          </a>
        </div>
      </template>

    </fdp-list>
  </div>
</template>

<script>

export default {
  methods: {
    closeContent () {
      this.$emit('close')
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    }
  },
  data () {
    return {
      isEmpty: false,
      isLoadingStatus: false,
      noticeData: [
        {
          isNewRecord: true,
          text: `7월 특차마감 지점 프로모션 참여하세요!`,
          type: `동의`,
          time: `18:20`,
          date: ``
        },
        {
          text: `7월 특차마감 지점 프로모션 참여하세요!`,
          type: `플라자`,
          time: `18:20`,
          date: `1일전`
        }
      ]
    }
  }
}
</script>
