<template>
  <section class="-pub-customer-register">
    <div class="-pub-customer-register__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">고객등록동의</span>
      </h1>
      <fdp-stepper class="-pub-stepper -pub-customer-register__stepper" v-model="currentStep" :space="22" clickable>
        <fdp-step :step="1" :current="currentStep"></fdp-step>
        <fdp-step :step="2" :current="currentStep"></fdp-step>
      </fdp-stepper>
    </div>
    <div class="-pub-customer-register__content">
      <!-- step2 content -->
      <section class="-pub-customer-register__step-content -pub-step-2">
          <div class="-pub-customer-register__step2-left">
            <h2 class="-pub-customer-register__step-title">개인정보 동의</h2>
            <fdp-tab-box-type class="-pub-tab-container"  @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0" ref="infoAgreeTab">
                <component :is="tabItems[currentTabIndex].tabComponent" :current-tab-sub-title="tabItems[currentTabIndex].tabSubTitle" @completed="completedTab" :tab-index="currentTabIndex"></component>
            </fdp-tab-box-type>
          </div>
          <div class="-pub-customer-register__step2-right">
            <h2 class="-pub-customer-register__step-title">고객 인증</h2>
            <!-- -pub-dimed-all 를 넣어주면 비활성화 -->
            <div class="-pub-customer-register__container" :class="{'-pub-dimed-all': isDisabled}">
                <!-- 인증방식 -->
                <div class="-pub-customer-register-form__row -pub-electronic-signature-form__row--auth-type">
                    <div class="-pub-customer-register-form__header">인증방식</div>
                    <div class="-pub-customer-register-form__content">
                        <fdp-validator name="tsscm105m_auth_type" display-name="인증방식" v-model="authType1" :rules="'required'">
                            <fdp-segment-box class="-pub-segment__container -pub-segment--medium" v-model="authType1" :data="authTypes" :disabled="isDisabled" essential></fdp-segment-box>
                        </fdp-validator>
                    </div>
                </div>
                <!-- 인증방식 end -->
                <!-- 인증방식 휴대전화 케이스 -->
                <!-- [ 181029 인증방식 텍스트 수정 -->
                <TSSCM108D v-if="authType1[0].label === '휴대폰'" :disabled="isDisabled"></TSSCM108D>
                <!-- 181029 인증방식 텍스트 수정 ] -->
                <!-- 인증방식 신용카드 케이스 -->
                <TSSCM109D v-else :disabled="isDisabled"></TSSCM109D>
            </div>
          </div>
      </section>
    </div>
    <!-- [ 181102 bottom-bar 키보드 실행시 위로 올라가지 않도록 수정 -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default -pub-bottom-bar--full" v-show="true">
        <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
            <button type="button" class="-pub-button -pub-button--prev -pub-button--reverse" @click="$emit('move', 'previous')"><img class="icon-arrow" src="@/assets/img/components/ico-arrow-prev-blue.png" alt="이전 버튼">이전</button>
        </div>
        <p class="-pub-customer-register__step-text">{{ '※ 정보활용동의가 완료되어야 고객카드가 생성됩니다. 5일 이내 미동의 시 본 고객정보는 자동 삭제됩니다.' }}</p>
    </fdp-bottom-bar>
    <!-- 181102 bottom-bar 키보드 실행시 위로 올라가지 않도록 수정 ] -->
  </section>
</template>
<script>
import FirstTabComponent from '@/components/pages/2018-09-14/TSSCM106D'
import SecondTabComponent from '@/components/pages/2018-11-02/TSSCM106D-marketing'

import TSSCM108D from '@/components/pages/2018-09-14/TSSCM108D'
import TSSCM109D from '@/components/pages/2018-09-14/TSSCM109D'

export default {
  components: {
    FirstTabComponent,
    SecondTabComponent,
    TSSCM108D,
    TSSCM109D
  },
  data () {
    return {
      isDisabled: true,
      currentStep: 2,
      currentTabIndex: 0,
      currentTabSubTitle: '(본인 김광용)',
      tabItems: [{
        'tabTitle': '필수컨설팅동의',
        'tabSubTitle': '(본인 김광용)',
        'tabComponent': 'first-tab-component',
        'checked': false
      },
      {
        'tabTitle': '마케팅동의',
        'tabSubTitle': '(본인 김광용, 자녀 김아들)',
        'tabComponent': 'second-tab-component',
        'checked': false
      }],
      // [ 181029 인증방식 텍스트 수정
      authTypes: [{
        key: '1',
        label: '휴대폰'
      },
      {
        key: '2',
        label: '신용카드'
      }],
      authType1: [{
        key: '1',
        label: '휴대폰'
      }]
      // 181029 인증방식 텍스트 수정 ]
    }
  },
  methods: {
    completedTab (tabIndex, state) {
      this.tabItems[tabIndex].checked = state
      this.isDisabled = true
      if (tabIndex === 0 && state) {
        this.$refs.infoAgreeTab.changeIdx(1)
      } else if (tabIndex === 1 && state) {
        this.isDisabled = false
      }
    },
    changeTabIdx (idx) {
      this.currentTabIndex = idx
    }
  }
}
</script>
