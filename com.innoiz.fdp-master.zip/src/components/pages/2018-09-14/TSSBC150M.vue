<template>
  <div class="-pub-header-content -pub-header-content--notice -tri-sel">
    <a class="-pub-header-content__button--close" @click="closeContent"><img src="@/assets/img/components/btn_close_light.png" alt="닫기" /></a>
    <fdp-tab-topcolor-type @change-tab-idx="changeIdx" :tab-items="tabItems" class="-pub-notice-content__tab" :default-selected-idx="0">
        <template>
          <component :is="currentTabComponent"></component>
        </template>
    </fdp-tab-topcolor-type>
  </div>
</template>
<script>
import T1 from '@/components/pages/2018-09-14/TSSBC150M-tabs/TSSBC150M.tab1'
import T2 from '@/components/pages/2018-09-14/TSSBC150M-tabs/TSSBC150M.tab2'
import T3 from '@/components/pages/2018-09-14/TSSBC150M-tabs/TSSBC150M.tab3'

export default {
  components: {
    T1,
    T2,
    T3
  },
  methods: {
    closeContent () {
      this.$emit('close')
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    },
    changeIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    }

  },
  data () {
    return {
      currentTabComponent: 'T1',
      tabItems: [{'tabTitle': '공지사항', 'tabSubTitle': '0', 'tabComponent': 'T1'}, {'tabTitle': '시스템 공지', 'tabSubTitle': '0', 'tabComponent': 'T2'}, {'tabTitle': '팝업', 'tabSubTitle': '2', 'tabComponent': 'T3'}],
      isEmpty: false,
      isLoadingStatus: false
    }
  }
}

</script>
