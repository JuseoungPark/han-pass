<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="VIP서비스 신청" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 신청정보 확인 Start -->
            <div class="-pub-popup__vip" v-if="false">
                <div class="-pub-popup__vip--subtitle">
                    <span class="tit">선택한 서비스</span>
                    <span class="tit--info">프리우나 다이아나 커피잔 세트</span>
                    <div class="-pub-popup__title--button">
                        <button type="button" class="-pub-button -pub-button__gray">
                            <span class="-pub-button__text">재선택</span>
                        </button>
                    </div>
                </div>
                <div class="-pub-popup__vip--content">
                    <div class="-pub-popup__vip--service-list">
                        <dl class="-pub-popup__vip--service-list--item item0101">
                            <dt>고객명</dt>
                            <dd>이주명</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item0102">
                            <dt class="-pub-normal-letter">SVP No.</dt>
                            <dd class="-pub-normal-letter">SVP 123456</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item0103">
                            <dt>품목명</dt>
                            <dd>프리우나 다이아나 커피잔 세트</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item0104">
                            <dt>주문자</dt>
                            <dd>이온정</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item0105">
                            <dt>지점(대리점)</dt>
                            <dd>서울특별시 송파구 신천동 123-456 삼성생명 빌딩 송파지점</dd>
                        </dl>
                    </div>
                    <div class="-pub-popup__vip--info">
                        <div class="attach-default">
                            ※ VIP서비스 이용 위해 삼성생명 및 업무 위탁사에서 필요로하는 <span class="txt-purple">FC성명, FC코드, 지점주소,
                            연락처 정보</span>를 제공.활용하는 것에 대하여 동의합니다.
                        </div>
                        <div class="attach-strong">
                            ※ 선물은 지점(대리점)으로 발송되며, 담당 컨설턴트가 고객님께 직접 전달하셔야 합니다.<br>
                            * 분실/파손 등 배송 중 사고 우려로 고객주소로 직접발송 불가
                        </div>
                        <div class="attach-strong">
                            ※ 선물은 발주 및 포장작업으로 인해 5영업일 후 지점(대리점)으로 발송됩니다.<br>
                            발송 일정을 감안하여 선물신청 바랍니다.
                        </div>
                        <div class="attach-strong">
                            ※ 상기 지점(대리점) 주소가 틀린 경우 [취소] 클릭, [신청정보 삭제하기] 클릭 후<br>
                            통합콜센터(1544-7837)로 연락하여 수정 바랍니다.
                        </div>
                    </div>
                </div>
                <!-- 하단 버튼 고정 start -->
                <div class="-pub-bottom-bar">
                    <div class="-pub-confirm__content--right">
                        <button type="button" class="-pub-button -pub-button--purple">
                            <span class="-pub-button__text">취소</span>
                        </button><button type="button" class="-pub-button -pub-button--confirm">
                            <span class="-pub-button__text">확인</span>
                        </button>
                        <!-- 신청삭제버튼 영역
                         <button type="button" class="-pub-button -pub-button--medium -pub-button--purple">
                            <span class="-pub-button__text">취소</span>
                        </button><button type="button" class="-pub-button -pub-button--medium -pub-button--confirm">
                            <span class="-pub-button__text">신청삭제</span>
                        </button>-->
                    </div>
                </div>
                <!--// 하단 버튼 고정 end -->
            </div>
            <!--// 신청정보 확인 end -->
            <!-- 건강검진 선택 start -->
            <div class="-pub-popup__vip" v-if="true">
                <div class="-pub-popup__vip--content2">
                    <div class="-pub-popup__vip--service-list">
                        <dl class="-pub-popup__vip--service-list--item item010101">
                            <dt class="-pub--item-name">고객명</dt>
                            <dd>이주명</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item010202">
                            <dt class="-pub--item-no -pup-normal-letter">SVP No.</dt>
                            <dd class="-pub-normal-letter">SVP 123456</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item010303">
                            <dt class="-pub--item-order">주문자</dt>
                            <dd>이온정</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item010404">
                            <dt class="-pub--item-region">지역선택</dt>
                            <dd>
                                <fdp-validator name="Name" v-model="defaultValue" display-name="지역선택" :rules="'required|min:2'">
                                    <fdp-select v-model="defaultValue" :option-list="regionItems" class="-pub-regionItems"></fdp-select>
                                </fdp-validator>
                            </dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item010505">
                            <dt class="-pub--item-hospital">검진처 선택</dt>
                            <dd>
                                <fdp-validator name="Name" v-model="selectedValue" display-name="검진처 선택" :rules="'required|min:2'">
                                    <fdp-select v-model="selectedValue" :option-list="hospitalItems" class="-pub-hospitalItems"></fdp-select>
                                </fdp-validator>
                                <span class="-pub-hospitalItems--status">검강검진 병원 현황</span>
                            </dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item010606">
                            <dt class="-pub--item-date">검진 희망일</dt>
                            <dd>
                                <fdp-validator name="Name" v-model="targetMonth" display-name="검진 희망일" :rules="'required|min:2'">
                                    <fdp-date-picker class="-pub-date-picker -pub-filter-detail__item--date-picker" v-model="targetMonth" placeholder="조회기간" format="yyyy-MM-dd" ></fdp-date-picker>
                                </fdp-validator>
                            </dd>
                        </dl>
                    </div>
                    <div class="-pub-popup__vip--info">
                        <div class="attach-default">
                            ※ VIP서비스 이용 위해 삼성생명 및 업무 위탁사에서 필요로하는 <span class="txt-purple">FC성명, FC코드, 지점주소,<br >
                            연락처 정보</span>를 제공.활용하는 것에 대하여 동의합니다.<br >
                            - 계약자 본인만 이용 가능(양도 불가), 별도 검진권 제공되지 않습니다. <br >
                            - 검진희망 일자 확정 : 유파트너 신청 -&gt; 신청일 +1일 이후 고객님이 해당 검진처에 연락하여 <br >
                              <span style="padding-left:160px;">희망일정 확정하셔야 합니다.</span>
                        </div>
                        <div class="attach-strong">
                            - 지원급액 : 종합병원은 등급별 차등지원 (플1 : 65만원 , 플2 : 45만원 , 골드 : 25만원 지원)<br>
                            <span style="padding-left:85px;">* 플2/골드 고객은 종합병원 검진시 추가비용 부담발생 (플2 : 20만원, 골드 40만원 수준)</span>
                        </div>
                        <div class="attach-strong">
                            - 건강검진 항목은 각 검진처로 문의바라며, VIP 검진 프로그램 이외 항목은 개인 비용부담이<br>발생합니다
                        </div>
                        <div class="attach-default">
                            ※ U-Partner 검진신청 후, 신청일+1일 이후 해당 검진처로 연락하시어 예약일정을<br>확정하셔야 합니다.
                        </div>
                    </div>
                </div>
                <!-- 하단 버튼 고정 start -->
                <div class="-pub-bottom-bar">
                    <div class="-pub-confirm__content--right">
                        <button type="button" class="-pub-button -pub-button--purple">
                            <span class="-pub-button__text">취소</span>
                        </button><button type="button" class="-pub-button -pub-button--confirm">
                            <span class="-pub-button__text">확인</span>
                        </button>
                        <!-- 신청삭제버튼 영역
                         <button type="button" class="-pub-button -pub-button--medium -pub-button--purple">
                            <span class="-pub-button__text">취소</span>
                        </button><button type="button" class="-pub-button -pub-button--medium -pub-button--confirm">
                            <span class="-pub-button__text">신청삭제</span>
                        </button>-->

                    </div>
                </div>
                <!--// 하단 버튼 고정 end -->
            </div>
            <!--// 건강검진 선택 end -->
        </div>
      <!-- slot 끝 -->
    </fdp-popup>
  </template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      name: '',
      inputDate: new Date('2018-05-05'),
      defaultValue: {key: '1', label: '서울'},
      placeholderValue: '',
      selectedValue: {key: '1', label: '[종합] 서울아산병원 건강증진센터'},
      disabledValue: '',
      regionItems: [
        { key: '1', label: '서울' },
        { key: '2', label: '경기도' },
        { key: '3', label: '충청도' }
      ],
      hospitalItems: [
        { key: '1', label: '[종합] 서울아산병원 건강증진센터' },
        { key: '2', label: '[종합] 서울대학병원' },
        { key: '3', label: '[종합] 연세세브란스병원' }
      ]
    }
  }
}
</script>
