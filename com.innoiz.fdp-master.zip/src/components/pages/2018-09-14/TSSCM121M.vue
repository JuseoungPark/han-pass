<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="세대조정" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 세대조정 Start -->
            <div class="-pub-popup-generation">
                <div class="-pub-popup-generation__header">
                    <dl>
                        <dt>세대조정형태</dt>
                        <dd>
                            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--purple" v-model="segmentDataValue" :essential="true" :data="segmentData" @click="changeSegment"></fdp-segment-box>
                        </dd>
                    </dl>
                </div>
                <div class="-pub-popup-generation__content">
                    <!-- 왼쪽 영역 start -->
                    <div class="-pub-popup-content__left">
                        <div class="-pub-popup-content__tit">현재세대</div>
                        <div class="-pub-popup__table">
                            <fdp-infinite class="-pub-table -pub-table-blue -pop-customer" v-model="selectItemsOrigin" multi-select :items="mockData">
                                <template slot="header">
                                    <tr class="-pub-table__header">
                                        <th class="-pub-table-column--radiobox" style="width: 78px;">
                                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isSelectAllOrigin"  @input="selectAllItemsOrginFunc(isSelectAllOrigin)"></fdp-checkbox>
                                        </th>
                                        <th class="-pub-table-column" style="width: 142px;">고객명</th>
                                        <th class="-pub-table-column" style="width: 168px;">생년월일</th>
                                        <th class="-pub-table-column" style="width: 204px;">주고객관계</th>
                                    </tr>
                                </template>
                                <template slot="emptyView">
                                    <div class="empty-table-content">
                                        <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon"  />
                                        <div class="empty-table-content__text">데이터가 존재하지 않습니다.<!-- 검색결과가 존재하지 않습니다. --></div>
                                    </div>

                                </template>
                                <template slot-scope="props">
                                    <td class="-pub-table-column--radiobox" style="width: 78px;">
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItemsOrigin" :value="props.item"></fdp-checkbox>
                                    <td class="-pub-table-column -pub-table-column--name" style="width: 142px;">{{props.item.name}}</td>
                                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 168px;">{{props.item.birthDay}}</td>
                                    <td class="-pub-table-column" style="width: 204px; padding-left: 5px;">
                                        <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                                        :option-list="selectGroups.group1" style="width: 140px; height: 64px;"></fdp-select>
                                    </td>
                                </template>
                            </fdp-infinite>
                        </div>
                    </div>
                    <!--// 왼쪽 영역 end -->
                    <!-- 가운데 버튼 영역 start -->
                    <div class="-pub-popup-content__center">
                        <div class="-pub-popup-content__center--button">
                            <button type="button" class="-pub-popup-button__left-arrow" @click="moveTarget"></button>
                            <button type="button" class="-pub-popup-button__right-arrow" @click="moveOrigin"></button>
                        </div>
                    </div>
                    <!--// 가운데 버튼 영역 end -->
                    <!-- 오른쪽 영역 start -->
                    <div class="-pub-popup-content__right">
                        <div class="-pub-popup-content__tit">이동세대</div>
                        <!-- 페이지 조회 영역 start -->
                        <div class="-pub-popup-content__right--search" v-if="this.segmentDataValue[0].key!=='1'">
                            <form onsubmit="return false;">
                                <!-- clearable 옵션 추가 20181026-->
                                <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" clearable placeholder="고객명" v-model="searchKeyword" style="width: 286px; height: 56px;"></fdp-text-field>
                                <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                                </button>
                            </form>
                        </div>
                        <!-- 페이지 조회 영역 end  -->
                        <div class="-pub-popup__table">
                            <fdp-infinite class="-pub-table -pub-table-blue -pop-customer" v-model="selectItemsTarget" multi-select :items="mockNew">
                                <template slot="header">
                                    <tr class="-pub-table__header">
                                        <th class="-pub-table-column--radiobox" style="width: 78px;">
                                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="isSelectAllTarget"  @input="selectAllItemsTargetFunc(isSelectAllTarget)"></fdp-checkbox>
                                        </th>
                                        <th class="-pub-table-column" style="width: 142px;">고객명</th>
                                        <th class="-pub-table-column" style="width: 168px;">생년월일</th>
                                        <th class="-pub-table-column" style="width: 204px;">주고객관계</th>
                                    </tr>
                                </template>
                                <template slot="emptyView">
                                    <div class="empty-table-content">
                                        <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon"  />
                                        <div class="empty-table-content__text"><!--데이터가 존재하지 않습니다.  -->검색결과가 존재하지 않습니다.</div>
                                    </div>
                                    <div class="empty-table-content">
                                        <img src="@/assets/img/customer/ico_hand_tap.png" class="empty-table-content__icon"  />
                                        <div class="empty-table-content__text">이동할 세대원을 좌측에서 선택해서 옮기세요.</div>
                                    </div>
                                </template>
                                <template slot-scope="props">
                                    <td class="-pub-table-column--radiobox" style="width: 78px;">
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItemsTarget" :value="props.item"></fdp-checkbox>
                                    <td class="-pub-table-column -pub-table-column--name" style="width: 142px;">{{props.item.name}}</td>
                                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 168px;">{{props.item.birthDay}}</td>
                                    <td class="-pub-table-column" style="width: 204px; padding-left: 5px;">
                                        <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                                        :option-list="selectGroups.group1" style="width: 140px; height: 64px;"></fdp-select>
                                    </td>
                                </template>
                            </fdp-infinite>
                        </div>
                    </div>
                    <!--// 오른쪽 영역 end -->
                </div>
            </div>
            <!--// 세대조정 end -->
             <!-- 하단 버튼 고정 start -->
             <div class="-pub-bottom-bar -pub-bottom-bar__generation">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--confirm">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import mockData from '@/components/mock/TSSCM121M.mock'
export default {
  data () {
    return {
      showPopup: true,
      fixedIcon: '',
      radioSelected: '',
      radioTableSelected: [],
      mockData: Array.prototype.slice.call(mockData, 0, 6), // 기본데이터
      mockDataTmp: Array.prototype.slice.call(mockData, 0, 6), // 복구용 copy본
      mockDataTmp2: Array.prototype.slice.call(mockData, 6), // 다른 세대용 데이터
      mockNew: [],
      searchKeyword: '',
      segmentDataValue: [
        {'key': '1', 'label': '단독세대 구성'}
      ],
      segmentData: [
        {'key': '1', 'label': '단독세대 구성'},
        {'key': '2', 'label': '다른 세대 세대원으로 이동'}
      ],
      selectedValue: '',
      selectItemsOrigin: [],
      selectItemsTarget: [],
      selectGroups: {
        group1: [{
          key: '1',
          label: '친척'
        }],
        group2: [{
          key: '1',
          label: '부모'
        }],
        values: {
          group1: {
            key: '1',
            label: '친척'
          },
          group2: {
            key: '1',
            label: '부모'
          }
        }
      },
      isSelectAllOrigin: false,
      isSelectAllTarget: false
    }
  },
  methods: {
    // table 전체 선택 처리 (현재세대 Table)
    selectAllItemsOrginFunc (state) {
      if (state) {
      // checked
        this.selectItemsOrigin = this.mockData.slice(0)
      } else {
      // unchecked
        this.selectItemsOrigin.splice(0, this.selectItemsOrigin.length)
      }
    },
    // table 전체 선택 처리 (이동 세대 Table)
    selectAllItemsTargetFunc (state) {
      if (state) {
      // checked
        this.selectItemsTarget = this.mockNew.slice(0)
      } else {
      // unchecked
        this.selectItemsTarget.splice(0, this.selectItemsTarget.length)
      }
    },
    // 현재 세대로 세대원 이동 처리
    moveOrigin () {
      for (var i in this.selectItemsTarget) {
        this.mockData.push(this.selectItemsTarget[i])
      }
      for (var k in this.selectItemsTarget) {
        for (var j = this.mockNew.length - 1; j >= 0; j--) {
          if (this.selectItemsTarget[k].key === this.mockNew[j].key) {
            this.mockNew.splice(j, 1)
          }
        }
      }
      this.selectItemsTarget.splice(0, this.selectItemsTarget.length)
      this.isSelectAllTarget = false
    },
    // 이동 세대로 세대원 이동 처리
    moveTarget () {
      for (var i in this.selectItemsOrigin) {
        this.mockNew.push(this.selectItemsOrigin[i])
      }
      for (var k in this.selectItemsOrigin) {
        for (var j = this.mockData.length - 1; j >= 0; j--) {
          if (this.selectItemsOrigin[k].key === this.mockData[j].key) {
            this.mockData.splice(j, 1)
          }
        }
      }
      this.selectItemsOrigin.splice(0, this.selectItemsOrigin.length)
      this.isSelectAllOrigin = false
    },
    // 세대 조정 형태에 따른 데이터 초기화
    changeSegment () {
      if (this.segmentDataValue[0].key === '1') {
        // 단독 세대 구성 선택 시, 현재 데이터 원복 및 이동세대 데이터 전체 삭제
        this.mockData.splice(0, this.mockData.length)
        this.mockData = this.mockDataTmp.slice(0)
        this.mockNew.splice(0, this.mockNew.length)
      } else {
        // 다른 세대원으로 이동 선택 시 , 현재 데이터 원복 및 이동세대 데이터 새로 로드함.
        this.mockData = this.mockDataTmp.slice(0)
        this.mockNew.splice(0, this.mockNew.length)
        this.mockNew = this.mockDataTmp2.slice(0)
      }
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리 (현재 세대)
    selectItemsOrigin () {
      if (this.selectItemsOrigin.length !== this.mockData.length || this.mockData.length === 0) {
        this.isSelectAllOrigin = false
      } else {
        this.isSelectAllOrigin = true
      }
    },
    // table내 record가 갖는 checkbox 선택 시 후처리 (이동 세대)
    selectItemsTarget () {
      if (this.selectItemsTarget.length !== this.mockNew.length || this.mockNew.length === 0) {
        this.isSelectAllTarget = false
      } else {
        this.isSelectAllTarget = true
      }
    }
  }
}
</script>
