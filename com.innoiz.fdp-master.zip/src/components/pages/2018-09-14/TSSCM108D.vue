<template>
    <!-- 인증방식 휴대전화 케이스 -->
    <div class="-pub-customer-register__step2--mobile">
        <!-- 본인확인 서비스 이용 동의 -->
        <div class="-pub-customer-register-form__row -pub-electronic-signature-form__row--id-use-agreement">
            <fdp-checkbox class="-pub-checkbox" v-model="singleCheckbox1" :disabled="disabled"></fdp-checkbox>
            <span>본인확인 서비스 이용 동의</span>
        </div>
        <!-- 본인확인 서비스 이용 동의 end -->
        <!-- 휴대폰번호 -->
        <div class="-pub-customer-register-form__row -pub-customer-register-form__row--mobile-number">
            <div class="-pub-customer-register-form__header">휴대폰번호</div>
            <!-- [ 181030 불필요한 클래스 제거 -->
            <div class="-pub-customer-register-form__content">
            <!-- 181030 불필요한 클래스 제거 ] -->
                <fdp-validator name="tsscm108d_mobile" v-model="mobileNumber" display-name="휴대폰번호" :rules="'required'">
                    <!-- [ 181029 ellipsis 옵션추가 -->
                    <fdp-select ellipsis class="-pub-customer-register-form__select--telecom" v-model="telecomType" :option-list="telecomTypes" :disabled="disabled"></fdp-select>
                    <!-- 181029 ellipsis 옵션추가 ] -->
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--mobile-number" v-model="mobileNumber" placeholder="000-0000-0000" :disabled="disabled"></fdp-text-field>
                </fdp-validator>
            </div>
        </div>
        <div class="-pub-customer-register-form__row -pub-customer-register-form__row--buttons">
            <button class="-pub-customer-register-form__item -pub-button -pub-zipcode-button -pub-certno-button" :disabled="disabled" v-if="isBeforeSend" @click="onSend">인증번호 전송</button>
            <button class="-pub-customer-register-form__item -pub-button -pub-zipcode-button -pub-certno-button" :disabled="disabled" v-else @click="onReSend">인증번호 재전송</button>
        </div>
        <!-- 휴대폰번호 end -->
        <!-- 인증번호 -->
        <div class="-pub-customer-register-form__row -pub-electronic-signature-form__row--certification-number">
            <div class="-pub-customer-register-form__header">인증번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tsscm108d_authnumber" display-name="인증번호" v-model="authNumber" :rules="'required'">
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--certification-number" v-model="authNumber" placeholder="인증번호입력" :disabled="disabled"></fdp-text-field>
                </fdp-validator>
                <!-- 아래 오류메시지와 만료시간 표시는 임시테스트용 입니다. 조건 수정 필요. -->
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--complete" v-if="authNumber.length > 2 && authNumber.length < 6">인증되었습니다.</span>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--error" v-if="authNumber.length > 5">인증번호 오류입니다.</span>
                <span class="-pub-electronic-signature-form__input--guide" v-if="!isBeforeSend && authNumber.length < 6">인증번호 만료까지 <strong>2:56</strong></span>
            </div>
        </div>
        <!-- 인증번호 end -->
        <div class="-pub-customer-register-form__row -pub-electronic-signature-form__row--cert-no-guide">
            <span>인증번호가 도착하지 않은 경우 아래와 같이 조치 부탁드립니다. 휴대폰 스팸번호 분류 확인<br>NICE 인증 고객센터 문의</span>
            <!-- 2018-10-30 전화번호 수정 -->
            <span class="-pub-button--service-center">1600-1522</span>
            <span class="-pub-button--service-center-dim">1600-1522</span>
        </div>
    </div>
</template>
<script>
export default {
  props: {
    disabled: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      singleCheckbox1: false,
      isBeforeSend: true,
      authNumber: '',
      // [ 181029 휴대폰사업자 선택 목록 수정
      telecomTypes: [{
        key: '1',
        label: 'SKT'
      },
      {
        key: '2',
        label: 'KT'
      },
      {
        key: '3',
        label: 'LG U+'
      },
      {
        key: '4',
        label: 'SKT (알뜰폰)'
      },
      {
        key: '5',
        label: 'KT (알뜰폰)'
      },
      {
        key: '6',
        label: 'LG U+ (알뜰폰)'
      },
      {
        key: '7',
        label: '알뜰폰 확인하기'
      }
      ],
      telecomType: {
        key: '1',
        label: 'SKT'
      },
      // 181029 휴대폰사업자 선택 목록 수정 ]
      mobileNumber: ''
    }
  },
  methods: {
    onSend () {
      this.isBeforeSend = false
    },
    onReSend () {
      this.isBeforeSend = true
    }
  }
}
</script>
