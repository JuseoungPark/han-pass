<template>
    <div>
        <div class="-pub-name-ui-tab__text-area-container">
            <h4 class="-pub-name-ui-tab__content-title">문자보내기</h4>
            <ul class="-pub-name-ui-tab__msg-type">
                <!-- on 붙으면 active 상태 -->
                <li class="on">SMS</li>
                <li>LMS</li>
            </ul>
            <textarea class="-pub-name-ui-tab__text-area -pub-name-ui-tab__text-area--message" v-model="msgText" placeholder="메세지를 직접 입력하거나
하단의 자동 메세지 입력 버튼을 선택하세요."></textarea>
            <span class="-pub-name-ui-tab__text--length">80/80 byte</span>
            <!-- [ 181113 문자 pre-set (상담일정) 삭제 -->
            <!-- <div class="-pub-name-ui-tab__menu-btn-area">
                <button class="-pub-button -pub-button--purple -pub-button--light" type="button" v-if="msgText.length <= 0">상담일정</button>
                <button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--light" type="button" v-else>상담일정</button>
            </div> -->
            <!-- 181113 문자 pre-set (상담일정) 삭제 ] -->
            <div class="">
                <ul class="-pub-name-ui-tab__msg-cost-area">
                    <li>
                        <span class="-pub__msg-cost--total">총금액</span>
                        <strong class="-pub__msg-cost--total-point">11<span>P</span></strong>
                    </li>
                    <li>
                        <span class="-pub__msg-cost--available">사용가능</span>
                        <span class="-pub__msg-cost--available-point">10,000P</span>
                        <button class="-pub-button -pub-button--purple -pub-button--light -pub-button-charge" type="button">충전</button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="-pub-name-ui-tab__button-area">
            <button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--send" :disabled="msgText.length <= 0" type="button" @click="msgSend = true" v-if="!msgSend">발송하기</button>
            <button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--check" type="button" @click="msgSend = false; menuClose();" v-if="msgSend"><i class="check-icon"></i></button>
        </div>
    </div>
</template>
<script>

export default {
  data () {
    return {
      msgText: '김예원 고객님의 안녕하세요, 김하늘 FC 입니다.\n' +
'고객님의 생일을 진심으로 축하드립니다.\n' +
'오늘도 행복한 하루 보내세요!',
      msgSend: false
    }
  },
  methods: {
    menuClose () {
      this.$emit('changeTab', '')
    }
  }
}
</script>
