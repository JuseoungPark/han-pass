<template>
  <!-- 진행단계 안내팝업 : start -->
  <fdp-popup class="-pub-popup -pub-popup-wrap" v-model="showPopup" title="진행단계 안내" :prevent-outside-close="true">

    <div class="-fdp-infinite__header">
      <ul class="-pub-table__header">
        <li class="-pub-table-column" style="width: 184px;">진행단계</li>
        <li class="-pub-table-column -pub-table-column--normal-letter" style="width: 260px;">표기내용</li>
        <li class="-pub-table-column" style="width: 906px;">정의</li>
      </ul>
    </div>

    <div class="-pub-popup-page__slot -pub-popup-page__1">
      <div class="-pub-popup__content">
        <table class="-pub-table -fdp-infinite__table_1" :tableBodyHeight="450">
          <tbody class="-fdp-infinite__tbody">

            <tr class="-fdp-table__body_slt">
              <td class="-pub-table-column" style="width: 184px;" rowspan="2">진단신청</td>
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">진단신청</td>
              <td class="-pub-table-column" style="width: 906px;">진단신청 전산입력을 완료한 단계</td>
            </tr>

            <tr class="-fdp-table__body_slt_1">
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">추가 진단신청</td>
              <td class="-pub-table-column" style="width: 906px;">
                <p>추가 진단신청 전산입력을 완료한 단계</p>
                <p>하단에 진단일자는 최초진단신청일자로 변동이 없으며 주가 진단서류 스캔 시<br />진단신청으로 표기 변경됩니다.</p>
              </td>
            </tr>

            <tr class="-fdp-table__body_slt">
              <td class="-pub-table-column" style="width: 184px;">진단완료</td>
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">진단완료</td>
              <td class="-pub-table-column" style="width: 906px;">
                <p>방문진단/지정의진단/서류진단(종합검진)을 통해<br />고객이 진단받은 일자를 안내하는 단계</p>
                <p>하단일자는 고객이 실제 진단받은 일자입니다.</p>
              </td>
            </tr>

            <tr class="-fdp-table__body_slt">
              <td class="-pub-table-column" style="width: 184px;" rowspan="4">진단심사</td>
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">진단심사 도착</td>
              <td class="-pub-table-column" style="width: 906px;">진단심사자에게 진단서류가 매칭되어 심사가 가능한 단계</td>
            </tr>

            <tr class="-fdp-table__body_slt_1">
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">진단심사 미결 중</td>
              <td class="-pub-table-column" style="width: 906px;">
                <p>진단 심사자가 심사 중 발생된 미결내용을 지점에 통보한 단계</p>
                <p>최종 발생된 미결내용만 팝업조회가 가능합니다.</p>
              </td>
            </tr>

            <tr class="-fdp-table__body_slt_1">
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">진단심사 미결 보완</td>
              <td class="-pub-table-column" style="width: 906px;">지점에서 미결내용을 보완하여 진단 심사자가 재심사가 가능한 단계</td>
            </tr>

            <tr class="-fdp-table__body_slt_1">
              <td class="-pub-table-column -pub-table-column--normal-letter-2" style="width: 260px;">판정완료</td>
              <td class="-pub-table-column" style="width: 906px;">진단 심사자가 판정을 완료한 상태</td>
            </tr>

          </tbody>

          <tfoot class="-fdp-infinite__footer">
            <tr class="-pub-table__footer">
              <td class="-pub-table-ftr">※고객명은 진단 신청하신 고객의 성명 입니다.</td>
              <td class="-pub-table-ftr">※조회일로부터 3개월 이내 진단 신청건에 한해 조회가 가능합니다.(3개월이 지난 진단 신청건의 추가진단은 조회불가)</td>
              <td class="-pub-table-ftr">※'언더가입설계' 동의기간 만료건의 경우 판정완료 등 팝업조회가 불가합니다.</td>
            </tr>
          </tfoot>

        </table>
      </div>
    </div>

    <div class="-pub-popup-ftr__1">
      <div class="-pub-popup-ftr__wrap">
        <a class="pop_btn_1" href="#">확인</a>
      </div>
    </div>

  </fdp-popup>
  <!-- 진행단계 안내팝업 : end -->
</template>
<script>
import mockData from '@/components/mock/TSSPS222P.mock'
export default {
  data () {
    return {
      showPopup: true,
      mockData: Object.assign({}, mockData)
    }
  }
}
</script>
