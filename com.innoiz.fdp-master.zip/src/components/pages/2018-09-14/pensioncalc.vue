<template>
  <section class="-pub-consulting">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">연금계산기</span>
      </h2>
      <div class="-pub-page-header__content">
        <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--icon -pub-page-header__button--last">
          <img src="@/assets/img/components/ico-product-design.png" alt="뒤로가기">
          <span>가입설계</span>
        </a>
        <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--gray -pub-tooltip-menu--type-3"
          v-model="currMenu2" :menu-list="menuListSample2" bottom>
          <div class="-pub-button--tooltip -pub-page-header__icon">
            <img src="@/assets/img/components/btn-gnb-consulting.png" alt="">
          </div>
        </fdp-tooltip-menu>
      </div>
    </div>
    <div class="-pub-consulting-bar">
      <h3 class="-pub-consulting-bar__title">{{currentContent.title}}</h3>
      <div class="-pub-consulting-bar__view-type">
        <fdp-radio class="-pub-radio" v-for="(name, idx) in currentRadios" v-model="contentRadioValue" :key="idx"
          :value="name">{{name}}</fdp-radio>
      </div>
      <div class="-pub-consulting-bar__month-amount" v-if="this.currentContent.title === '상품컨설팅' && this.contentRadioValue === '상품별'">
        월보험료<span class="-pub-consulting-bar__price-text ">270,010,000</span>
      </div>
      <div class="-pub-consulting-bar__month-amount -pub-consulting-bar__month-amount--replace" v-if="this.currentContent.title === '상품컨설팅' && this.contentRadioValue === '기간별'">
        월보험료<span class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--before">270,010,000</span><span
          class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--replace">270,010,000</span>
      </div>
      <div class="-pub-consulting-bar_tabs">
        <dy-tab class="-pub-consulting-tab" :nav-items="navItems" @changeItem="changeComponent"></dy-tab>
      </div>
    </div>
    <component :is="computeComponent" :content-value="contentRadioValue"></component>
    <!-- 기계약 영역 -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full"
      v-show="true">
      <div class="-pub-bottom-nav">
        <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-bottom-nav__item--icon">
          <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--type-4" v-model="currMenu"
            :menu-list="menuListSample" top>
            <div class="-pub-button -pub-button--tooltip">
              <span class="-pub-symbol--menu"></span>
            </div>
          </fdp-tooltip-menu>
        </div>
        <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered">
          <button class="-pub-button -pub-bottom-nav__item">
            다른연금 추가하기
          </button>
        </div>
        <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
          <button type="button" class="-pub-button -pub-button--reverse -pub-button--complete" v-if="currentContent.title === '상품설계 전후비교'">완료</button>
          <button v-else class="-pub-button -pub-button--next">
            다음
            <img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼">
          </button>
        </div>
      </div>
    </fdp-bottom-bar>
  </section>
</template>
<script>
import DyTab from '@/components/pages/2018-08-31/dynamic-tab'
import TSSCT017M from '@/components/pages/2018-09-14/consulting-contents/TSSCT017M'
import TSSCT018M from '@/components/pages/2018-09-14/consulting-contents/TSSCT018M'
import TSSCT019M from '@/components/pages/2018-09-14/consulting-contents/TSSCT019M'
import TSSCT017P from '@/components/pages/2018-09-14/consulting-contents/TSSCT017P'
import TSSCT020M from '@/components/pages/2018-09-21/consulting-contents/TSSCT020M'
import TSSCT021M from '@/components/pages/2018-10-26/TSSCT021M'

export default {
  components: {
    DyTab,
    TSSCT017M,
    TSSCT018M,
    TSSCT019M,
    TSSCT020M,
    TSSCT017P,
    TSSCT021M
  },
  watch: {
    currentContent (val) {
      if (val) {
        console.log(val)
        this.contentRadioValue = val.contentRadios[0]
        this.setComputeComponent(this.contentRadioValue)
      }
    },
    contentRadioValue (val) {
      this.setComputeComponent(val)
    }
  },
  computed: {
    currentRadios () {
      return (this.currentContent && this.currentContent.contentRadios) || []
    }
  },
  data () {
    return {
      name: '이주명',
      currMenu: '',
      currMenu2: '',
      contentRadioValue: '',
      computeComponent: '',
      navItems: [{
        title: '연금준비현황',
        component: ['TSSCT017M', 'TSSCT018M'],
        contentRadios: ['상품별', '기간별']
      },
      {
        title: '상품컨설팅',
        component: ['TSSCT019M', 'TSSCT017P'],
        contentRadios: ['상품별', '기간별']
      },
      {
        title: '가입설계 전후비교',
        component: ['TSSCT020M', 'TSSCT021M'],
        contentRadios: ['전후비교', '지체비용']
      }
      ],
      currentContent: {},
      menuListSample: [{
        label: '인쇄/이메일',
        key: '4'
      }],
      menuListSample2: [{
        label: '라이프분석',
        key: 'email'
      },
      {
        label: '보장분석',
        key: 'dm'
      },
      {
        label: '상속계산기',
        key: '1'
      },
      {
        label: '가족력',
        key: '2'
      }
      ]
    }
  },
  methods: {
    changeComponent (component) {
      this.currentContent = component
    },
    setComputeComponent (val) {
      const componentIndex = this.currentContent.contentRadios.findIndex(radioValue => radioValue === val)
      this.computeComponent = this.currentContent.component[componentIndex]
    }
  }
}
</script>
