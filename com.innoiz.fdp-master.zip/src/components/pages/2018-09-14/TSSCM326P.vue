<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="VIP서비스 신청" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__vip">
                <div class="-pub-popup__vip--title">
                    <span class="-pub-popup__vip--title-txt">VIP 선물 (택 1)</span>
                    <span class="-pub-popup__vip--title-dec">※ 서비스 신청 유의 사항 (실버등급 선물/검진 서비스 미제공)</span>
                </div>
                <div class="-pub-popup__vip--accordion-group -pub-scroll">
                    <fdp-infinite class="-pub-accordion-group__list" v-model="radioTableSelected" expandable :items="mockData" expand-height="616" style="height: 732px;">
                        <template slot="header">
                            <tr class="-pub-accordion-group__header">
                                <th class="-pub-accordion-group__header--title">선물명</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-accordion-group__list--item-detail">
                                <div class="-pub-selectRadio" @click.stop>
                                    <fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" :value="props.item.tit"></fdp-radio>
                                </div>
                                <div class="-pub-productImg">
                                    <span>상품이미지</span>
                                </div>
                                <div class="-pub-productTxt">
                                    <span class="-pub-productTxt__subtit">{{props.item.subtit}}</span>
                                    <span class="-pub-productTxt__tit">{{props.item.tit}}</span>
                                </div>
                                <a href="#" class="-pub-button__open" v-if="true">열기</a>
                                <a href="#" class="-pub-button__close" v-if="false">닫기</a>
                            </td>
                        </template>
                        <template slot="expand" slot-scope="props">
                            <div class="-pub-accordion-group__list--item-view">
                                    <div class="-pub-productionImg--big">
                                        <span class="imgTxt">{{props.item.tit}}</span>
                                    </div>
                                </div>
                        </template>
                    </fdp-infinite>
                </div>
                <!-- <div class="-pub-popup__vip--accordion-group">
                    <div class="-pub-accordion-group__header">
                        선물명
                    </div>
                    <div class="-pub-accordion-group__list">
                        <ul>
                            <li class="-pub-accordion-group__list--item" v-for="(item , index) in mockData" :key="index">
                                <div class="-pub-accordion-group__list--item-detail">
                                    <div class="-pub-selectRadio">
                                        <fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected"></fdp-radio>
                                    </div>
                                    <div class="-pub-productImg">
                                        <span>상품이미지</span>
                                    </div>
                                    <div class="-pub-productTxt">
                                        <span class="-pub-productTxt__subtit">{{item.subtit}}</span>
                                        <span class="-pub-productTxt__tit">{{item.tit}}</span>
                                    </div>
                                    <a href="#" class="-pub-button__open" v-if="true">열기</a>
                                    <a href="#" class="-pub-button__close" v-if="false">닫기</a>
                                </div>
                                <div class="-pub-accordion-group__list--item-view" v-if="false">
                                    <div class="-pub-productionImg--big">
                                        <span class="imgTxt">상품 큰 이미지</span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div> -->
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm" :disabled="radioSelected === ''">
                        <span class="-pub-button__text">다음</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
      <!-- slot 끝 -->
    </fdp-popup>
  </template>
<script>
import mockData from '@/components/mock/TSSCM326P.mock'
export default {
  data () {
    return {
      showPopup: true,
      radioTfValue: false,
      radioStrValue: '',
      radioSelected: '',
      radioTableSelected: [],
      mockData: Array.prototype.slice.call(mockData)
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.tit
      }
    }
  }
}
</script>
