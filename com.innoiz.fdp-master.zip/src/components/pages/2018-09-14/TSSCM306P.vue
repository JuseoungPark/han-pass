<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="프리미엄 고객사랑서비스 신청" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__vip -pub-popup-premium">
                <div class="-pub-popup__vip--content">
                    <div class="-pub-popup__vip--service-list">
                        <dl class="-pub-popup__vip--service-list--item item01">
                            <dt>고객명</dt>
                            <dd>이주명</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item02">
                            <dt>고객유형</dt>
                            <dd>본인타겟</dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item03">
                            <dt>신청번호</dt>
                            <dd>
                                <fdp-text-field v-model="defaultValue" placeholder="G702a1241" disabled="disabled" style="width:188px;"></fdp-text-field>
                                <fdp-validator name="name" v-model="defaultValue2" display-name="신청번호 뒷자리" :rules="'required'">
                                    <fdp-text-field v-model="defaultValue2" placeholder="12" style="width:76px;"></fdp-text-field>
                                </fdp-validator>
                            </dd>
                        </dl>
                        <dl class="-pub-popup__vip--service-list--item item04">
                            <dt>선물</dt>
                            <dd></dd>
                        </dl>
                    </div>
                </div>
                <div class="-pub-popup__vip--accordion-group">
                    <fdp-infinite class="-pub-accordion-group__list" v-model="radioTableSelected" expandable :items="mockData" expand-height="616">
                        <template slot="header">
                            <tr class="-pub-accordion-group__header">
                                <th class="-pub-accordion-group__header--title">선물명</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-accordion-group__list--item-detail">
                                <div class="-pub-selectRadio">
                                    <fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" :value="props.item.tit" @click.stop></fdp-radio>
                                </div>
                                <div class="-pub-productImg">
                                    <span>상품이미지</span>
                                </div>
                                <div class="-pub-productTxt">
                                    <span class="-pub-productTxt__subtit">{{props.item.subtit}}</span>
                                    <span class="-pub-productTxt__tit">{{props.item.tit}}</span>
                                </div>
                                <a href="#" class="-pub-button__open" v-if="!props.item.showExpand">열기</a>
                                <a href="#" class="-pub-button__close" v-if="props.item.showExpand">닫기</a>
                            </td>
                        </template>
                        <template slot="expand" slot-scope="props">
                            <div class="-pub-accordion-group__list--item-view">
                                <div class="-pub-productionImg--big">
                                    <span class="imgTxt">{{props.item.tit}}</span>
                                </div>
                            </div>
                        </template>
                    </fdp-infinite>
                    <div class="-pub-popup__vip--info">
                        <div class="attach-default">
                            ※ 방문전달을 위해 삼성생명 및 업무 위탁사에서 필요로 하는 FC성명, FC코드, 지점주소,<br>
                            <span class="leftpadding30">연락처 정보를 제공ㆍ활용하는 것에 대하여 동의합니다.</span><br>
                            ※ 가치/준가치/내고객추가 유형 고객은 선물 신청 시 수수료 공제가 있습니다.<br>
                            <span class="leftpadding30">(가치: 1천, 준가치: 1-2천, 추가: 3천)</span>
                        </div>
                    </div>
                </div>
                <!--
                <div class="-pub-popup__vip--accordion-group">
                    <div class="-pub-accordion-group__header">
                        선물명
                    </div>
                    <div class="-pub-accordion-group__list">
                        <ul>
                            <li class="-pub-accordion-group__list--item" v-for="(item , index) in mockData" :key="index">
                                <div class="-pub-accordion-group__list--item-detail">
                                    <div class="-pub-selectRadio">
                                        <fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected"></fdp-radio>
                                    </div>
                                    <div class="-pub-productImg">
                                        <span>상품이미지</span>
                                    </div>
                                    <div class="-pub-productTxt">
                                        <span class="-pub-productTxt__subtit">{{item.subtit}}</span>
                                        <span class="-pub-productTxt__tit">{{item.tit}}</span>
                                    </div>
                                    <a href="#" class="-pub-button__open" v-if="true">열기</a>
                                    <a href="#" class="-pub-button__close" v-if="false">닫기</a>
                                </div>
                                <div class="-pub-accordion-group__list--item-view" v-if="true">
                                    <div class="-pub-productionImg--big">
                                        <span class="imgTxt">상품 큰 이미지</span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="-pub-popup__vip--info">
                        <div class="attach-default">
                            ※ 방문전달을 위해 삼성생명 및 업무 위탁사에서 필요로 하는 FC성명, FC코드, 지점주소,<br>
                            <span class="leftpadding30">연락처 정보를 제공ㆍ활용하는 것에 대하여 동의합니다.</span><br>
                            ※ 가치/준가치/내고객추가 유형 고객은 선물 신청 시 수수료 공제가 있습니다.<br>
                            <span class="leftpadding30">(가치: 1천, 준가치: 1-2천, 추가: 3천)</span>
                        </div>
                    </div>
                </div>
                -->
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm"
                    :disabled="defaultValue2 === '' || radioSelected === ''">
                        <span class="-pub-button__text">신청</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
    </template>
<script>
import mockData from '@/components/mock/TSSCM326P.mock'
export default {
  data () {
    return {
      showPopup: true,
      name: '',
      defaultValue: '',
      defaultValue2: '',
      radioTfValue: false,
      radioStrValue: '',
      radioSelected: '',
      radioTableSelected: [],
      mockData: Array.prototype.slice.call(mockData)
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.tit
      }
    }
  }
}
</script>
