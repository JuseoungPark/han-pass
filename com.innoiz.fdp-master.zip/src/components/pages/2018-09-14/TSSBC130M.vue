<!--
버튼이 추가 되었습니다.
<a class="-pub-header-content__button--close" @click="closeContent"><img src="@/assets/img/btn_close_light.png" alt="닫기"></a>
12번째줄 확인바랍니다.

-->
<template>
  <div class="-pub-header-content--list"><!-- -pub-header-content -->
    <div class="content_wrap">
      <div class="-pub-header-content-1">
        <h1>김하늘 FC</h1>
        <a class="-pub-header-content__button--close" @click="closeContent"><img src="@/assets/img/btn_close_light.png" alt="닫기"></a>
        <div class="content1-wrap">
          <div class="content1-first">영등포지점</div>
          <div class="content1-second"><span>자문역(상무급)</span></div>
        </div>
      </div>
      <div class="-pub-header-content-2">
        <div>설정</div>
      </div>
      <div class="-pub-header-content-3">
        <div class="content3_wrap">
          <a href="#"><img src="@/assets/img/ico_on_off.png" alt="로그아웃"></a>
          <span class="logout_btn">로그아웃</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  methods: {
    closeContent () {
      this.$emit('close')
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    }
  }
}
</script>
