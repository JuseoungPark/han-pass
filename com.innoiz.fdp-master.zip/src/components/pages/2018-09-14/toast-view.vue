<template>
  <div>
    <fdp-toast class="-pub-toast" :ref="ref1"></fdp-toast>
    <fdp-toast class="-pub-toast -pub-toast--purple" :ref="ref2"></fdp-toast>
    <button class="-pub-button" style="padding: 20px 40px" @click="createToast(ref1, '부분 이메일 전송이 완료되었습니다')">파란색 토스트 호출</button>
    <button class="-pub-button -pub-button--purple" style="padding: 20px 40px" @click="createToast(ref2, '보험서류가 모바일로 발송되었습니다.')">보라색 토스트 호출</button>
  </div>

</template>

<script>
export default {
  methods: {
    createToast (ref, message = 'toast !') {
      return this.$refs[ref].makeToast(message)
    }
  },
  data () {
    return {
      ref1: 'toast1',
      ref2: 'toast2'
    }
  }
}
</script>s
