<template>
    <section class="-pub-feedback-popup">
        <!-- S 1 button -->
        <fdp-confirm class="-pub-confirm -pub-s-popup" v-model="confirm1" message="고객명을 2글자 이상 입력 후 검색해주세요." positive-button-label="확인" @on-positive="onPositive"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-s-popup" v-model="confirm2" :message="'고객명을 2글자 이상 입력 후 검색해주세요.\n고객명을 2글자 이상 입력 후 검색해주세요.\n고객명을 2글자 이상 입력 후 검색해주세요.'" positive-button-label="확인" @on-positive="onPositive"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-s-popup -pub-confirm--purple" v-model="confirm3" message="고객명을 2글자 이상 입력 후 검색해주세요." positive-button-label="확인" @on-positive="onPositive"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-s-popup -pub-confirm--purple" v-model="confirm4" :message="'고객명을 2글자 이상 입력 후 검색해주세요.\n고객명을 2글자 이상 입력 후 검색해주세요.\n고객명을 2글자 이상 입력 후 검색해주세요.'" positive-button-label="확인" @on-positive="onPositive"></fdp-confirm>

        <!-- S 2 button -->
        <fdp-confirm class="-pub-confirm" v-model="confirm5" message="인쇄하시겠습니까?" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm" v-model="confirm6" :message="'인쇄하시겠습니까?\n인쇄하시겠습니까?\n인쇄하시겠습니까?'" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm7" message="인쇄하시겠습니까?" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm8" :message="'인쇄하시겠습니까?\n인쇄하시겠습니까?\n인쇄하시겠습니까?'" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>

        <!-- M button -->
        <fdp-confirm class="-pub-confirm -pub-m-popup" v-model="confirm9" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라,
살 듣는다. 보이는 방황하였으며, 낙원을 온갖 길지 길을 광야에서 있다.
눈이 같지 그것은 가장 가진 구하기 전인 그림자는 현저하게 것이다. 꾸며
새가 속에 이성은 사막이다. 튼튼하며, 우리의 설레는 평화스러운 하는
수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이다.
꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다.
힘차게 방황하여도, 싶이 얼음 이성은 그들을 봄바람이다.
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-m-popup -pub-scroll-popup" v-model="confirm10" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라,
살 듣는다.보이는 방 황하였으며, 낙원을 온갖 길지 길을 광야에서 있다.
눈이 같지 그것은 가장 가진 구하기  전인 그림자는 현저하게 것이다.
꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설 레는 평화스러운
하는수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이다.
꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도,
싶이 얼음  이성은 그들을 봄 황금시대의 부패를 소리다.이것은 두손을
예가 품에 뜨거운지라, 살 듣는다.보이는 방 황하였으며, 낙원을 온갖
길지 길을 광야에서 있다.눈이 같지 그것은 가장 가진 구하기  전인
그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며,
우리의 설 레는 평화스러운 하는수 과실이 피어나는 운다.
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-m-popup -pub-confirm--purple" v-model="confirm11" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라,
살 듣는다. 보이는 방황하였으며, 낙원을 온갖 길지 길을 광야에서 있다.
눈이 같지 그것은 가장 가진 구하기 전인 그림자는 현저하게 것이다. 꾸며
새가 속에 이성은 사막이다. 튼튼하며, 우리의 설레는 평화스러운 하는
수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이다.
꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다.
힘차게 방황하여도, 싶이 얼음 이성은 그들을 봄바람이다.
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-m-popup -pub-scroll-popup -pub-confirm--purple" v-model="confirm12" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라,
살 듣는다.보이는 방 황하였으며, 낙원을 온갖 길지 길을 광야에서 있다.
눈이 같지 그것은 가장 가진 구하기  전인 그림자는 현저하게 것이다.
꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설 레는 평화스러운
하는수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이다.
꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도,
싶이 얼음  이성은 그들을 봄 황금시대의 부패를 소리다.이것은 두손을
예가 품에 뜨거운지라, 살 듣는다.보이는 방 황하였으며, 낙원을 온갖
길지 길을 광야에서 있다.눈이 같지 그것은 가장 가진 구하기  전인
그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며,
우리의 설 레는 평화스러운 하는수 과실이 피어나는 운다.
                </div>
            </div>
        </fdp-confirm>

        <!-- L button -->
        <fdp-confirm class="-pub-confirm -pub-l-popup" v-model="confirm13" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는다. 보이는 방
황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하기
전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설
레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서, 불
어 가장 같이,
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-l-popup -pub-scroll-popup" v-model="confirm14" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는다. 보이는 방
황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하기
전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설
레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서, 불
어 가장 같이, 황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는
다. 황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하
기 전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의
설레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서,
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-l-popup -pub-confirm--purple" v-model="confirm15" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는다. 보이는 방
황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하기
전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설
레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서, 불
어 가장 같이,
                </div>
            </div>
        </fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-l-popup -pub-scroll-popup -pub-confirm--purple" v-model="confirm16" custom negative-button-label="버튼" positive-button-label="버튼" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>
황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는다. 보이는 방
황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하기
전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의 설
레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서, 불
어 가장 같이, 황금시대의 부패를 소리다.이것은 두손을 예가 품에 뜨거운지라, 살 듣는
다. 황하였으며, 낙원을 온갖 길지 길을 광야에서 있다. 눈이 같지 그것은 가장 가진 구하
기 전인 그림자는 현저하게 것이다. 꾸며 새가 속에 이성은 사막이다. 튼튼하며, 우리의
설레는 평화스러운 하는 수 과실이 피어나는 운다. 용감하고 많이 이 그들은 동력은 것이
다. 꽃이 못할 웅대한 보라. 심장은 품고 웅대한 약동하다. 힘차게 방황하여도, 싶이 얼음
이성은 그들을 봄바람이다. 낙원을 풀이 있는 찬미를 안고, 미묘한 것이다. 뜨고, 실로 이
웅대한 듣기만 같은 무엇을 귀는 들어 아름다우냐? 열락의 무엇을 우리의 위하여서,
                </div>
            </div>
        </fdp-confirm>

        <div id="box">
            <!-- S 1 button -->
            <fdp-radio v-model="confirm1">S_1btn_blue</fdp-radio>
            <fdp-radio v-model="confirm2">S_1btn_2_blue</fdp-radio>
            <fdp-radio v-model="confirm3">S_1btn_purple</fdp-radio>
            <fdp-radio v-model="confirm4">S_1btn_2_purple</fdp-radio>

            <!-- S 2 button -->
            <fdp-radio v-model="confirm5">S_2btn_blue</fdp-radio>
            <fdp-radio v-model="confirm6">S_2btn_2_blue</fdp-radio>
            <fdp-radio v-model="confirm7">S_2btn_purple</fdp-radio>
            <fdp-radio v-model="confirm8">S_2btn_2_purple</fdp-radio>

            <!-- M button -->
            <fdp-radio v-model="confirm9">M_btn_blue</fdp-radio>
            <fdp-radio v-model="confirm10">M_btn_blue scroll</fdp-radio>
            <fdp-radio v-model="confirm11">M_btn_purple</fdp-radio>
            <fdp-radio v-model="confirm12">M_btn_purple scroll</fdp-radio>

            <!-- L button -->
            <fdp-radio v-model="confirm13">L_btn_blue</fdp-radio>
            <fdp-radio v-model="confirm14">L_btn_blue_scroll</fdp-radio>
            <fdp-radio v-model="confirm15">L_btn_purple</fdp-radio>
            <fdp-radio v-model="confirm16">L_btn_purple_scroll</fdp-radio>
        </div>
    </section>
</template>
<script>
export default {
  data () {
    return {
      confirm1: false,
      confirm2: false,
      confirm3: false,
      confirm4: false,
      confirm5: false,
      confirm6: false,
      confirm7: false,
      confirm8: false,
      confirm9: false,
      confirm10: false,
      confirm11: false,
      confirm12: false,
      confirm13: false,
      confirm14: false,
      confirm15: false,
      confirm16: false
    }
  }
}
</script>
<style scoped>
    #box {
        position: fixed;
        bottom: 100px;
        width: 100%;
        padding: 20px 100px;
        border: 1px solid gray;
    }
    .-fdp-radio {
        margin:  0 40px;
    }
</style>
