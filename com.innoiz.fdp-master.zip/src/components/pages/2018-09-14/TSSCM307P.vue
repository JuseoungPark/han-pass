<template>
    <!-- 보험서류발송 start -->
    <fdp-popup class="-pub-popup" v-model="showPopup" title="결과 입력" :prevent-outside-close="true">
      <!-- slot 원하는 내용 -->
      <div class="-pub-popup-page__slot">
          <div class="-pub-popup__content -pub-popup__vip -pub-popup-premium__result">
            <div class="-pub-popup__vip--service-list">
                <dl class="-pub-popup__vip--service-list--item">
                    <dt>고객명</dt>
                    <dd>이주명</dd>
                </dl>
                <dl class="-pub-popup__vip--service-list--item">
                    <dt>고객유형</dt>
                    <dd>본인타겟</dd>
                </dl>
                <dl class="-pub-popup__vip--service-list--item">
                    <dt>방문여부/상세</dt>
                    <dd>
                        <fdp-validator name="Name" v-model="visitValues" display-name="방문여부/상세" :rules="'required'">
                            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="visitValues" :data="visit" essential></fdp-segment-box>
                        </fdp-validator>
                        <!-- 방문 start -->
                        <div class="-pub-popup-premium__result--radio" v-if="visitValues[0].key === '1'">
                            <ul>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 1">기계약상황 확인</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 2">컨설팅(통합자산분석, 보장분석)</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 3">방문물품만 전달</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 4">보험금 청구</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 5">신상품/이벤트 소개</fdp-radio></li>
                            </ul>
                        </div>
                        <!--// 방문 end -->
                        <!-- 미방문 start -->
                        <div class="-pub-popup-premium__result--radio" v-if="visitValues[0].key === '2'">
                            <ul>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 1">고객 변심으로 방문 불가</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 2">FC 개인사정으로 미방문</fdp-radio></li>
                                <li class="-pub-popup-premium__result--radio-item"><fdp-radio class="-pub-radio -pub-radio--purple -pub-bottom-nav__item--centered" v-model="radioSelected" value="radio 3">담당FC 해촉</fdp-radio></li>
                            </ul>
                        </div>
                        <!--// 미방문 end -->
                    </dd>
                </dl>
            </div>
          </div>
          <!-- 하단 버튼 고정 start -->
          <div class="-pub-bottom-bar">
            <div class="-pub-confirm__content--right">
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
                    <span class="-pub-button__text">취소</span>
                </button>
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse"><!-- :disabled="visitValues[0].key === '1' && radioSelected === ''" -->
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
        <!--// 하단 버튼 고정 end -->
      </div>
      <!-- slot 끝 -->
    </fdp-popup>
    <!-- 보험서류발송 팝업 end -->
  </template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      visitValues: [
        {
          key: '1',
          label: '방문'
        }
      ],
      visit: [
        {
          key: '1',
          label: '방문'
        },
        {
          key: '2',
          label: '미방문'
        }
      ],
      radioTfValue: false,
      radioStrValue: '',
      radioSelected: ''
    }
  },
  watch: {
    visitValues () {
      this.radioSelected = ''
    }
  }
}
</script>
