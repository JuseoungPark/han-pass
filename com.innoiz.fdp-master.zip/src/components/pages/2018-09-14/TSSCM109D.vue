<template>
    <!-- 인증방식 신용카드 케이스 -->
    <div class="-pub-customer-register__step2--credit-card">
        <div class="-pub-customer-register-form__row -pub-customer-register-form__row--notice">
            <span>본인 명의의 체크,신용카드 정보로 인증을 진행합니다.<br>
신한/삼성(체크)/씨티 카드의 경우 카드사 정책에 따라<br>
인증서비스가 제공되지 않을 수 있습니다.</span>
        </div>
        <!-- 카드번호 -->
        <div class="-pub-customer-register-form__row " v-if="true">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">카드번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tsscm109d_card-number" display-name="카드번호" v-model="cardCheck" :rules="'required'">
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo1" placeholder="0000" mask="####" :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo2" placeholder="0000" mask="####" :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo3" placeholder="0000" password mask="####" noIcon :disabled="disabled"></fdp-text-field>
                    <span class="-pub-customer-register-form__dash"></span>
                    <fdp-text-field class="-pub-input-text__letter-spancing--normal -pub-electronic-signature-form__input--card-number" v-model="cardNo4" placeholder="0000" password mask="####" noIcon :disabled="disabled"></fdp-text-field>
                </fdp-validator>
            </div>
        </div>
        <!-- 카드번호 end -->
        <!-- 유효기간 -->
        <div class="-pub-customer-register-form__row ">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">유효기간</div>
            <!-- [ 181030 불필요한 클래스 제거 -->
            <div class="-pub-customer-register-form__content">
            <!-- 181030 불필요한 클래스 제거 ] -->
                <fdp-validator name="tsscm109d_period" display-name="유효기간" v-model="monthType.key" :rules="'required'">
                    <fdp-select class="-pub-electronic-signature-form__select--month" v-model="monthType" :option-list="monthTypes" placeholder="월" :disabled="disabled"></fdp-select>
                    <fdp-select class="-pub-electronic-signature-form__select--year" v-model="yearType" :option-list="yearTypes" placeholder="년" :disabled="disabled"></fdp-select>
                </fdp-validator>
            </div>
        </div>
        <!-- 유효기간 end -->
        <!-- 비밀번호 -->
        <div class="-pub-customer-register-form__row -pub-customer-register-form__row--pw" v-if="true">
            <div class="-pub-customer-register-form__header -pub-electronic-signature-form__header">비밀번호</div>
            <div class="-pub-customer-register-form__content">
                <fdp-validator name="tsscm109d_password" display-name="비밀번호" v-model="pw" :rules="'required'">
                    <fdp-text-field class="-pub-electronic-signature-form__input--card-number"  v-model="pw" placeholder="00" password mask="##" noIcon :disabled="disabled"></fdp-text-field>
                    <span class="-pub-electronic-signature-form__asterisk">**</span>
                </fdp-validator>
                <button class="-pub-button -pub-zipcode-button -pub-certno-button -pub-certno-confirm-button" @click="() => {authConfirm = true}" v-if="!authConfirm" :disabled="disabled">인증확인</button>
                <span class="-pub-customer-register-form__item -pub-electronic-signature-form__input--complete" v-else>인증되었습니다.</span>
            </div>
        </div>
        <!-- 비밀번호 end -->
    </div>
</template>
<script>
export default {
  props: {
    disabled: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      authConfirm: false,
      cardNo1: '4330',
      cardNo2: '4330',
      cardNo3: '1234',
      cardNo4: '1234',
      monthTypes: [{
        key: '1',
        label: '1월'
      },
      {
        key: '2',
        label: '2월'
      },
      {
        key: '3',
        label: '3월'
      },
      {
        key: '4',
        label: '4월'
      }
      ],
      monthType: {
        key: '',
        label: ''
      },
      yearTypes: [{
        key: '1',
        label: '18년'
      },
      {
        key: '2',
        label: '19년'
      },
      {
        key: '3',
        label: '20년'
      },
      {
        key: '4',
        label: '21년'
      }
      ],
      yearType: {
        key: '',
        label: ''
      },
      pw: '11'
    }
  },
  computed: {
    cardCheck () {
      return this.cardNo1 !== '' && this.cardNo2 !== '' && this.cardNo3 !== '' && this.cardNo4 !== '' ? '1' : ''
    }
  }
}
</script>
