<template>
<!-- 고객등록시 고객조회 팝업 start -->
<fdp-popup class="-pub-popup" v-model="showPopup" title="세대원 선택" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-member">
            <div class="-pub-confirm__content--left -pub-confirm__content--main-pop">
             <!-- 페이지 조회 input, button 검색 명수 영역  -->
             <div class="-pub-filter-menu">
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총{{mockData.length}}명</div>
            </div>
            <!-- 페이지 조회 input, button 검색 명수 영역 end -->
            <fdp-infinite class="-pub-table -pub-table-blue -pop-customer" v-model="radioTableSelected" single-select :items="mockData">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                        <th class="-pub-table-column" style="width: 206px;">고객명</th>
                        <th class="-pub-table-column" style="width: 174px;">생년월일</th>
                        <th class="-pub-table-column" style="width: 216px;">관계</th>
                        <th class="-pub-table-column -pub-table-column--left-align" style="width: 178px;">필수컨설팅</th>
                        <th class="-pub-table-column -pub-table-column--left-align" style="width: 142px;">마케팅</th>
                    </tr>
                </template>
                <template slot="emptyView" v-show="mockData.length == 0">
                    <div class="empty-table-content -pub-member__nodata">
                        <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon"  />
                        <div class="empty-table-content__text">데이터가 존재하지 않습니다.<!-- 검색결과가 존재하지 않습니다. --></div>
                    </div>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column--radiobox" style="width: 78px;">
                        <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item.id.toString()"></fdp-radio>
                    </td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 206px;">{{props.item.name}}</td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 174px;">{{props.item.birthDay}}</td>
                    <td class="-pub-table-column" style="width: 216px;">{{props.item.me}}</td>
                    <td class="-pub-table-column -pub-table-column--normal-letter -pub-table-column--left-align" style="width: 178px;">
                        <template v-if="props.item.consulting">
                            <span class="-pub-agree-text">D-99</span>
                        </template>
                        <template v-else>
                            N
                        </template>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter -pub-table-column--left-align" style="width: 142px;">
                        <template v-if="props.item.marketing">
                            <span class="-pub-agree-text -pub-agree-text--grey-icon">D-99+</span>
                        </template>
                        <template v-else>
                            N
                        </template>
                    </td>
                </template>
            </fdp-infinite>
            </div>
        </div>
        <!-- 하단 버튼 고정 start -->
        <div class="-pub-bottom-bar">
        <div class="-pub-confirm__content--right">
            <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--reverse" :class="radioTableSelected.length==0?'':'-pub-button--blue'" :disabled="radioTableSelected.length==0">
                <span class="-pub-button__text">확인</span>
            </button>
        </div>
        </div>
        <!--// 하단 버튼 고정 end -->
    </div>
    <!-- slot 끝 -->
</fdp-popup>
<!-- 고객등록시 고객조회 팝업 end -->
</template>
<script>
import mockData from '@/components/mock/TSSCT021P.mock'
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: '',
        password: '',
        masking: '',
        fixedIcon: '',
        disabled: 'text not editable',
        readonly: 'text not editable'
      },
      radioSelected: '',
      radioTableSelected: [],
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData),
      mockHeader: []
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.id.toString()
      }
    }
  }
}
</script>
