<template>
    <div :class="myClass">
        <div class="btm-border">{{item.applyDate}}</div>
    </div>
</template>

<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col']
}
</script>

<style scoped>
.btm-border {
  display: inline-block;
  line-height: 30px;
  border-bottom: 1px solid #222
}
</style>
