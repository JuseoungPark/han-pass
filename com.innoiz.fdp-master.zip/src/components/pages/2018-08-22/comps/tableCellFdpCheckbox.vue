<template>
    <div>
      <fdp-checkbox v-model="item.ck" :value="item[col.key]"></fdp-checkbox>
    </div>
    </template>

<script>
export default {
  name: 'cell-checkbox',
  props: ['item', 'col']
}
</script>

<style>

</style>
