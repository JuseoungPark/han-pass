<template>
  <section class="-pub-collect-money"> <!-- 마크업 추가 20181023-->
  <!-- 페이지 서브 메뉴 영역 end -->
  <div class="-pub-contents -pub-filter-menu__margintop"><!-- -pub-filter-menu__margintop 마크업 추가 20181101-->
    <!-- 페이지 조회 input, button 검색 명수 영역  -->
    <div class="-pub-filter-menu">
      <div class="-pub-filter-menu__item--right">
        <form onsubmit="return false;">
          <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
          <button type="submit" class="-pub-search-button -pub-filter-menu__item">
            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
          </button>
          <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
          <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]"
            @click="isDetailSearch = !isDetailSearch">
            <span>상세조회</span>
            <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
          </a>
          <!-- 상세조회 버튼영역 end -->
        </form>
      </div>
      <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
    </div>
    <!-- 페이지 조회 input, button 검색 명수 영역 end -->
    <!-- 상세조회 영역 -->
    <template v-if="isDetailSearch">
      <div class="-pub-filter-detail__scroll">
        <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
        <!-- 임직원일 경우에만 보이는 상세조회 field -->
        <template v-if="true">
          <li class="-pub-filter-detail__area" >
            <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
            <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
              :option-list="selectGroups.group1"></fdp-select>
            <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
              :option-list="selectGroups.group2"></fdp-select>
            <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
              :option-list="selectGroups.group3"></fdp-select>
          </li>
          <li class="-pub-filter-detail__area">
            <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
            <!-- 마크업 변경 detail-type-4 => detail-type-5 20181018 -->
            <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4"></fdp-select>
          </li>
        </template>
        <!-- 임직원일 경우에만 보이는 상세조회 field end -->
        <li class="-pub-filter-detail__area">
          <div class="-pub-filter-detail__item -pub-filter-detail__title">인수 월</div>
          <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item -pub-filter-detail__item--date-picker"
          v-model="targetMonth" placeholder="소개일" format="yyyy-MM"></fdp-date-picker>
          <span class="-pub-filter-detail__item separator-tilde"></span>
          <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item -pub-filter-detail__item--date-picker"
          v-model="targetMonth" placeholder="소개일" format="yyyy-MM"></fdp-date-picker>
        </li>
        <li class="-pub-filter-detail__area">
          <div class="-pub-filter-detail__item -pub-filter-detail__title">인수 구분</div>
          <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple" v-model="customerType"
            :data="customerTypes"></fdp-segment-box>
        </li>
      </ul>
    </div>
    <div class="-pub-filter-detail__bottom">
        <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
        <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
            <span class="-pub-button__text">조회</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
            <span class="-pub-button__text">초기화</span>
          </button>
        </li>
      </ul>
    </div>
    </template>
    <!-- 고객 관련 정보 데이터 테이블 영역 -->
    <div :class="hasSelectItem ? '-pub-table-height__onBottom6' : '-pub-table-height__offBottom6'">
    <fdp-infinite class="-pub-table" v-model="selectItems" multi-select :items="mockData" :table-body-height="hasSelectItem ? 860 : 860">
      <template slot="header">
        <tr class="-pub-table__header">
          <th class="-pub-table-column--checkbox" style="width: 78px;">
            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
            v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
          </th>
          <th class="-pub-table-column" style="width: 138px;">고객명</th>
          <th class="-pub-table-column" style="width: 182px;">고객카드</th>
          <th class="-pub-table-column" style="width: 210px;">생년월일</th>
          <th class="-pub-table-column" style="width: 146px;">성별</th>
          <th class="-pub-table-column" style="width: 204px;">계약번호</th>
          <th class="-pub-table-column" style="width: 212px;">수금 인수일</th>
          <th class="-pub-table-column" style="width: 182px;">인수 구분</th>
          <th class="-pub-table-column" style="width: 196px;">최근활동일</th>
        </tr>
      </template>
      <template slot-scope="props">
        <td class="-pub-table-column--checkbox" style="width: 78px;">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems"
            :value="props.item"></fdp-checkbox>
        </td>
        <td class="-pub-table-column -pub-table-column--name" style="width: 138px;">{{props.item.name}}</td>
        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 182px;">{{props.item.hasCustomerCard ? 'Y' : 'N'}}</td>
        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 210px;">{{props.item.birthDay}}</td>
        <td class="-pub-table-column" style="width: 146px;">{{props.item.gender}}</td>
        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 204px;">{{props.item.contractNumber}}</td>
        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 212px;">{{props.item.collect.date}}</td>
        <td class="-pub-table-column" style="width: 182px;">{{props.item.collect.type}}</td>
        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 196px;">{{props.item.recentDate}}</td>
      </template>
      <!-- 데이터 없는 화면 추가 20181023 -->
      <template slot="emptyView" v-show="mockData.length == 0">
          <div class="-pub-table-empty-view">
              <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
          </div>
          <div class="-pub-table-empty-view -pub-table-empty-view--search">
              <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
          </div>
        <!--<div class="empty-table-content">
          <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon"  />
          <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
        </div>-->
      </template>
    </fdp-infinite>
  </div>
  </div>
  <!-- 고객 관련 정보 데이터 테이블 영역 end -->
  <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
  <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="mockCheckCount > 0" :page-fixed="true">
    <ul class="-pub-bottom-nav">
      <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox
        v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
      </li>
      <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
        <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
          <span class="-pub-button__text">문자</span>
        </button>
        <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
          <span class="-pub-button__text">내 그룹에 추가</span>
        </button>
        <!-- tooltip 메뉴 버튼 bottom bar-->
        <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple" v-model="currMenu"
          :menu-list="menuListSample" blue top>
          <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
            <span class="-pub-symbol--menu"></span>
          </div>
        </fdp-tooltip-menu>
        <!-- tooltip 메뉴 버튼 end-->
      </li>
    </ul>
  </fdp-bottom-bar>
  <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM322M.mock'

export default {
  data () {
    return {
      title: '고객',
      showDefaultModal: false,
      isDetailSearch: false,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      menuListSample: [{
        label: '이메일',
        key: 'email'
      },
      {
        label: 'DM',
        key: 'dm'
      },
      {
        label: '택배',
        key: 'delivery'
      }
      ],
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      customerType: [],
      customerTypes: [{
        key: '1',
        label: '전체'
      },
      {
        key: '2',
        label: '일반'
      },
      {
        key: '3',
        label: '탈락'
      }],
      selectItems: [],
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '1',
            label: '김안범(000012312)'
          }
        }
      },
      isSelectAll: false,
      bottomBarCheck: false
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      console.log(offsetTop)
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  mounted () {
    this.customerType.push(this.customerTypes[0])
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
</script>
