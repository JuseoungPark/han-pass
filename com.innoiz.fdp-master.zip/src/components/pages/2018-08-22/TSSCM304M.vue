<template>
  <section>
    <fdp-tab-topcolor-type class="-pub-tab-container" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
      <template>
        <component :is="currentTabComponent"></component>
      </template>
    </fdp-tab-topcolor-type>
    <!-- 팝업 1 -->
    <fdp-modal class="-pub-alert" v-model="modals.alert1">
      <div class="-pub-alert__content--customer-service">
          <div class="-pub-alert__content -pub-alert__content--center -pub-alert__text--main">신청은 5명을 초과할 수 없습니다.</div>
          <div class="-pub-alert__content -pub-alert__content--center">
            <button class="-pub-button -pub-button--purple -pub-button--reverse" @click="modals.alert1 = !modals.alert1">
              <span>확인</span>
            </button>
          </div>
      </div>
    </fdp-modal>
    <!-- 팝업 2 -->
    <fdp-modal class="-pub-confirm -pub-confirm-type-1" v-model="modals.confirm1">
          <div class="-pub-confirm__content -pub-confirm__content--center -pub-confirm__text--main ">신청번호를 고객에게 발송 하시겠습니까?</div>
          <div class="-pub-confirm__content -pub-confirm__content--center -pub-confirm__text--sub">※ 사전 선물신청 동의 고객만 신청번호 <br> 발송 바랍니다.</div>
          <div class="-pub-confirm__content -pub-confirm__content--center">
            <button class="-pub-button -pub-button--purple -pub-button--confirm">
              <span class="-pub-button__text">아니오</span>
            </button><button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm">
              <span class="-pub-button__text">예</span>
            </button>
          </div>
    </fdp-modal>
    <!-- 팝업 3 -->
    <fdp-modal class="-pub-alert" v-model="modals.alert2">
        <div class="-pub-alert__content--customer-service">
            <div class="-pub-alert__content -pub-alert__content--center -pub-alert__text--main -pub-alert__text--multi-line">신청기간이 아닙니다.<br>신청기간은 월말 5 영업일 입니다.</div>
            <div class="-pub-alert__content -pub-alert__content--center">
              <button class="-pub-button -pub-button--purple -pub-button--reverse" @click="modals.alert1 = !modals.alert2">
                <span>확인</span>
              </button>
            </div>
        </div>
    </fdp-modal>
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM304M.mock'
import ServiceTabComponent from '@/components/pages/2018-08-22/tabs/TSSCM304M.tab-content'

import ServiceTabComponent2 from '@/components/pages/2018-09-21/TSSCM310D'

export default {
  components: {
    ServiceTabComponent,
    ServiceTabComponent2
  },
  data () {
    return {
      modals: {
        alert1: false,
        confirm1: false,
        alert2: false
      },
      title: '고객',
      tabItems: [{
        'tabSubTitle': '서비스신청',
        'tabButtonClass': '-pub-tab__item',
        'tabComponent': 'service-tab-component'
      },
      {
        'tabSubTitle': '활동현황',
        'tabButtonClass': '-pub-tab__item',
        'tabComponent': 'service-tab-component2'
      }
      ],
      currentTabComponent: 'service-tab-component',
      showDefaultModal: true,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      menuListSample: [{
        label: '이메일',
        key: 'email'
      },
      {
        label: 'DM',
        key: 'dm'
      },
      {
        label: '택배',
        key: 'delivery'
      }
      ],
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      customerType: [],
      customerTypes: [{
        key: '1',
        value: '전체'
      },
      {
        key: '2',
        value: '본인모집'
      },
      {
        key: '3',
        value: '타인모집'
      },
      {
        key: '4',
        value: '관심'
      },
      {
        key: '5',
        value: '임시'
      },
      {
        key: '6',
        value: '가망'
      }
      ],
      selectItems: []
    }
  },
  methods: {
    onSizeChange (size) {},
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    }
  },
  mounted () {
    this.customerType.push(this.customerTypes[0])
  }
}
</script>
