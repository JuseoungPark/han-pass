<template>
  <section class="-pub-customer-register -pub-electronic-signature-status">
    <!-- 페이지 헤더 영역 -->
    <div class="-pub-customer-register__header -pub-electronic-signature__header">
      <h1 class="-pub-customer-register__title">
        <a class="-pub-customer-register__button -pub-customer-register__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-customer-register__text--parent-bottom">진단심사현황</span>
      </h1>
      <!-- 진행 단계 안내 버튼 -->
      <button class="-pub-button__process-level">
        <img src="@/assets/img/btn-process-level.png" alt="진행단계안내">
      </button>
    </div>
    <div class="-pub-page-container__wrapper">
      <div class="-pub-contents">
        <!-- 기간 조회 input, button 검색 명수 영역  -->
        <div class="-pub-filter-menu">
          <div class="-pub-filter-menu__item--right">
            <form onsubmit="return false;">
              <span class="-pub-filter-menu__item -pub-electronic-signature__item--label-txt">기간</span>
              <fdp-date-picker class="-pub-filter-menu__item -pub-customer-register-form__date-picker -pub-date-picker__letter-spancing--normal -pub-electronic-signature-form__date-picker--term-date"></fdp-date-picker>
              <span class="-pub-filter-menu__item -pub-electronic-signature-form__Tilde">~</span>
              <fdp-date-picker class="-pub-filter-menu__item -pub-customer-register-form__date-picker -pub-date-picker__letter-spancing--normal -pub-electronic-signature-form__date-picker--term-date"></fdp-date-picker>
              <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
              </button>
            </form>
          </div>
          <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
        </div>
        <!-- 기간 조회 input, button 검색 명수 영역  -->

        <!-- 진단심사현황 데이터 테이블 영역 -->
        <fdp-infinite class="-pub-table" :items="mockData" :table-body-height="909">
          <template slot="header">
            <tr class="-pub-table__header">
              <th class="-pub-table-column -pub-table-column--sorting" style="width: 146px;">
                <!-- sorting 활성화: -pub-sorting--active, 내림차순: defalt, 오름차순: -pub-sorting--up, 파란색: default, 보라색: -pub-sorting--purple -->
                <span>고객명
                  <img src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                </span>
              </th>
              <th class="-pub-table-column" style="width: 168px;">진단종류</th>
              <th class="-pub-table-column" style="width: 200px;">병원명/업체명</th>
              <th class="-pub-table-column" style="width: 230px;">진단신청</th>
              <th class="-pub-table-column" style="width: 230px;">진단완료</th>
              <th class="-pub-table-column" style="width: 286px;">진단심사</th>
              <th class="-pub-table-column" style="width: 286px;">판정완료</th>
            </tr>
          </template>
          <template slot-scope="props">
            <td class="-pub-table-column -pub-table-column--name" style="width: 146px;">{{props.item.name}}</td>
            <td class="-pub-table-column" style="width: 168px;">{{props.item.type}}</td>
            <td class="-pub-table-column" style="width: 200px;">{{props.item.hospital}}</td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 230px;">
              <span class="-pub-status-text">{{props.item.step1Status}}</span>
              <span class="-pub-status-date">{{props.item.step1Date}}</span>
            </td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 230px;">
              <span class="-pub-status-text">{{props.item.step2Status}}</span>
              <span class="-pub-status-date">{{props.item.step2Date}}</span>
            </td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 286px;">
              <template v-if="props.item.step3">
                <span class="-pub-badge-tag -pub-status-color1">{{props.item.step3Status}}</span>
              </template>
              <template v-else>
                <span class="-pub-badge-tag -pub-status-text">{{props.item.step3Status}}</span>
              </template>
              <span class="-pub-status-date">{{props.item.step3Date}}</span>
            </td>
            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 286px;">
              <template v-if="props.item.step4">
                <span class="-pub-badge-tag -pub-status-color2">{{props.item.step4Status}}</span>
              </template>
              <template v-else>
                <span class="-pub-badge-tag -pub-status-text">{{props.item.step4Status}}</span>
              </template>
              <span class="-pub-status-date">{{props.item.step4Date}}</span>
            </td>
          </template>
        </fdp-infinite>
        <!-- 진단심사현황 데이터 테이블 영역 end -->
      </div>
    </div>
    <!-- 팝업 1 -->
    <fdp-modal class="-pub-alert" v-model="alert1">
      <div class="-pub-alert__content--customer-service">
        <div class="-pub-alert__content -pub-alert__content--center -pub-alert__text--main">최근 3개월까지 조회 가능합니다.</div>
        <div class="-pub-alert__content -pub-alert__content--center">
          <button class="-pub-button -pub-button--purple -pub-button--reverse">
            <span>확인</span>
          </button>
        </div>
      </div>
    </fdp-modal>
  </section>
</template>
<script>
import {
  viewMemberMocks
} from '@/components/mock/TSSPS220M.mock'

export default {
  data () {
    return {
      alert1: true,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks)
    }
  }
}

</script>
