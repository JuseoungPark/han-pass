<!-- 프리미엄 고객사랑서비스 서비스 신청 탭콘텐츠 영역 -->
<template>
  <section>
  <div class="-pub-contents">
    <div class="-pub-filter-menu -pub-filter-menu--in-tab">
      <div class="-pub-filter-menu__item--right">
        <form onsubmit="return false;">
          <div class="-pub-filter-menu__item">
            <span class="-pub-filter-menu__item -pub-filter-menu__label">유형</span>
            <!-- -pub-premiun-segment 마크업 추가 20181031 -->
            <fdp-segment-box class="-pub-filter-menu__item -pub-premiun-segment -pub-segment__container -pub-segment--medium -pub-segment--purple -pub-search-segment" v-model="filter" :data="filters"></fdp-segment-box>
          </div>
          <!-- -pub-premiun-select 마크업 추가 20181031 -->
          <!-- detail-type-6 마크업 추가 20181030 -->
          <fdp-select class="-pub-filter-menu__item -pub-premiun-select -pub-filter-menu__item--select detail-type-6" v-model="filterSelectValue" :option-list="filterSelectItems"></fdp-select>
          <div class="-pub-filter-menu__item">
            <span class="-pub-filter-menu__item -pub-filter-menu__label">대상 월</span>
            <!-- -pub-premiun-date-picker 마크업 추가 20181031-->
            <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker -pub-premiun-date-picker -pub-filter-menu__item--date-picker-top" v-model="targetMonth" placeholder="소개일" format="yyyy-MM"></fdp-date-picker>
          </div>
          <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명, 휴대폰번호" v-model="searchKeyword" clearable></fdp-text-field>
          <button type="submit" class="-pub-search-button -pub-filter-menu__item">
            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
          </button>
          <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
          <!-- 프리미엄 고객사랑서비스에서는 임직원일 경우에만 보임 -->
          <template v-if="false">
            <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
              <span>상세조회</span>
              <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
            </a>
          </template>
          <!-- 상세조회 버튼영역 end -->
        </form>
      </div>
      <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
    </div>
    <!-- 페이지 조회 input, button 검색 명수 영역 end -->
    <!-- 상세조회 영역 (프리미엄 고객사랑서비스에서는 임직원일 경우에만 보임) -->
    <template v-if="isDetailSearch">
      <div class="-pub-filter-detail__scroll">
      <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
        <!-- 임직원일 경우에만 보이는 상세조회 field -->
        <li class="-pub-filter-detail__area">
          <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
          <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
            :option-list="selectGroups.group1"></fdp-select>
          <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
            :option-list="selectGroups.group2"></fdp-select>
          <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
            :option-list="selectGroups.group3"></fdp-select>
        </li>
        <li class="-pub-filter-detail__area">
          <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
          <!-- 마크업 변경 detail-type-4 => detail-type-5 20181018 -->
          <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4"
            placeholder="담당 컨설턴트"></fdp-select>
        </li>
      </ul>
    </div>
    <div class="-pub-filter-detail__bottom">
      <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
        <!-- 임직원일 경우에만 보이는 상세조회 field end -->
        <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
            <span class="-pub-button__text">조회</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
            <span class="-pub-button__text">초기화</span>
          </button>
        </li>
      </ul>
    </div>
    </template>
  </div>
  <!-- 고객 관련 정보 데이터 테이블 영역 -->
  <!-- 마크업 추가 20181031 -->
  <div :class="hasSelectItem ? '-pub-table-height__onBottom3' : '-pub-table-height__offBottom3'">
    <fdp-table :options="opt" v-model="selectItems" multi-select :items="mockData" @input="onInputMultiSelect" @headerCheckbox="onClickHeaderCheckbox" class="-pub-table_wrap -pub-last">
        <template slot="empty">
            <div class="-pub-table-empty-view">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            <div class="-pub-table-empty-view -pub-table-empty-view--search">
              <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
            </div>
        </template>
    </fdp-table>
  </div>
  <!-- 고객 관련 정보 데이터 테이블 영역 end -->
   <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
   <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="mockCheckCount > 0" :page-fixed="true">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
        </li>
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">서비스 신청</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
              <span class="-pub-button__text">신청 번호 발송</span>
            </button>
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">결과 입력</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">문자</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line">
            <span class="-pub-button__text">내 그룹에 추가</span>
          </button>
          <!-- tooltip 메뉴 버튼 bottom bar-->
          <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple" v-model="currMenu"
            :menu-list="menuListSample" blue top>
            <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
              <span class="-pub-symbol--menu"></span>
            </div>
          </fdp-tooltip-menu>
          <!-- tooltip 메뉴 버튼 end-->
        </li>
      </ul>
    </fdp-bottom-bar>
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM304M.mock'
// fdp-table-header에 checkbox 적용하기 위하여 import
import cellCheckbox from '../comps/tableCellFdpCheckbox'
import cusCell from '../comps/tablePageCustomCell'
import cusCell2 from '../comps/tablePageCustomCell2'
export default {
  data () {
    return {
      opt: columnFixed,
      mockData: Object.assign([], viewMemberMocks),
      currentTabComponent: '',
      isDetailSearch: false,
      showDefaultModal: false,
      multiCheckbox: [],
      mockHeader: [],
      targetMonth: '2017-07',
      menuListSample: [{
        label: '이메일',
        key: 'email'
      },
      {
        label: 'DM',
        key: 'dm'
      },
      {
        label: '택배',
        key: 'delivery'
      }
      ],
      filterSelectValue: {
        key: '1',
        label: '선택'
      },
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '1',
            label: '김안범(000012312)'
          }
        }
      },
      filterSelectItems: [{
        key: '1',
        label: '선택'
      },
      {
        key: '2',
        label: 'sample'
      }
      ],
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      customerType: [],
      customerTypes: [{
        key: '1',
        value: '전체'
      },
      {
        key: '2',
        value: '본인모집'
      },
      {
        key: '3',
        value: '타인모집'
      },
      {
        key: '4',
        value: '관심'
      },
      {
        key: '5',
        value: '임시'
      },
      {
        key: '6',
        value: '가망'
      }
      ],
      filter: [],
      filters: [{
        key: '1',
        label: '전체'
      },
      {
        key: '2',
        label: '내고객추가'
      }
      ],
      selectItems: [],
      isSelectAll: false,
      bottomBarCheck: false
    }
  },
  mounted () {
    this.filter.push(this.filters[0])
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }
      return offsetTop
    },
    onDefaultModal1 () {
      this.showDefaultModal1 = !this.showDefaultModal1
    },
    onDefaultModal2 () {
      this.showDefaultModal2 = !this.showDefaultModal2
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // table header checkbox 선택 시 처리
    onClickHeaderCheckbox () {
      let checkCnt = 0
      let checkedBool = false
      for (var key in this.mockData) {
        if (this.mockData[key].ck) checkCnt++
      }
      checkedBool = this.mockData.length !== checkCnt
      this.selectItems.splice(0, this.selectItems.length)

      for (key in this.mockData) {
        if (checkedBool) {
          this.selectItems.push(this.mockData[key])
        }
        this.mockData[key].ck = checkedBool
      }
    },
    // bottom-bar checkbox 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.onInputMultiSelect(this.selectItems)
    },
    // table row 선택 시 처리
    onInputMultiSelect (v) {
      for (var key in this.mockData) {
        this.mockData[key].ck = false
      }
      let that = this
      v.map((vv) => {
        for (var key in this.mockData) {
          if (that.mockData[key] === vv) {
            that.mockData[key].ck = vv.idx
          }
        }
      })
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
// fdp-table에서 fixed column을 사용하기 위한 option // 수정 20181101
var columnFixed = {
  name: 'columnFixed',
  cols: [
    {key: 'idx', component: cellCheckbox, type: 'checkbox', width: 78, name: '', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
    {key: 'name', width: 172, name: '고객명', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'font-weight': 'bold'}},
    {key: 'birthDay', type: 'date', width: 190, name: '생년월일', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'type', width: 190, name: '유형', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'customerType', width: 190, name: '고객구분', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'customerGroup', width: 140, name: '고객군', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'phone', width: 240, name: '휴대폰번호', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'division', width: 30, name: '｜', headerStyle: {'color': '#bdc3d6', 'font-size': '44px', 'text-align': 'center', 'line-height': '66px', 'font-weight': 'normal'}, bodyStyle: {'text-align': 'center'}},
    {key: 'applyDate', component: cusCell, type: 'date', width: 230, name: '신청일자', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'applyItem', width: 220, name: '신청물품', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'category1', width: 30, name: '〉', headerStyle: {'color': '#aaabb7', 'font-size': '20px', 'text-align': 'center', 'line-height': '68px', 'font-weight': 'normal'}, bodyStyle: {'text-align': 'center'}},
    {key: 'applyResult', component: cusCell2, width: 310, name: '결과', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'category2', width: 30, name: '〉', headerStyle: {'color': '#aaabb7', 'font-size': '20px', 'text-align': 'center', 'line-height': '68px', 'font-weight': 'normal'}, bodyStyle: {'text-align': 'center'}},
    {key: 'applyResendDate', type: 'date', width: 300, name: '재발송 일시', headerStyle: {'text-align': 'center', 'line-height': '68px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}}
  ],
  // 컬럼 고정 여부
  availableColumnFixed: true,
  // 고정할 컬럼 수 (왼쪽부터 적용)
  howManyColumnFixed: 2,
  headerHeight: 72, // 수정 20181101
  multiSelect: true,
  tableHeight: 746,
  infinite: true
}
</script>
