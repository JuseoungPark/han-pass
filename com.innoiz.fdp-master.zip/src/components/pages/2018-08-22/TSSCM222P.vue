<template>
  <div>
      <!-- 수신고객 목록조회 팝업 (이메일전송시 팝업) -->
      <fdp-modal class="-pub-confirm -pub-confirm-type-4 -pub-customer-list__confirm" v-model="modals.list1" quit>
          <div class="-pub-confirm__header">
            <h2 class="-pub-confirm__title">수신고객목록</h2>
          </div>
          <div class="-pub-confirm__content -pub-confirm__content--left">
              <div class="-pub-confirm__content--left -pub-confirm__content--main">
                <p class="-pub-confirm__desc">선택한 N명의 고객 중 N명의 고객에게 이메일을 발송합니다.</p>
                <fdp-infinite class="-pub-table" :items="mockData" :tableBodyHeight="450">
                    <template slot="header">
                      <tr class="-pub-table__header">
                        <th class="-pub-table-column" style="width: 186px;">고객명</th>
                        <th class="-pub-table-column" style="width: 204px;">생년월일</th>
                        <th class="-pub-table-column" style="width: 186px;">수금/가망</th>
                        <th class="-pub-table-column" style="width: 168px;">마케팅 동의</th>
                        <th class="-pub-table-column" style="width: 228px;">수신가능여부</th>
                      </tr>
                    </template>
                    <template slot-scope="props">
                      <td class="-pub-table-column -pub-table-column--name" style="width: 186px;">{{props.item.name}}</td>
                      <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 204px;">{{props.item.birthDay}}</td>
                      <td class="-pub-table-column" style="width: 186px;">{{props.item.collect}}</td>
                      <td class="-pub-table-column -pub-table-column--left-center -pub-table-column--normal-letter" style="width: 168px;">
                        <template v-if="props.item.marketing">
                          <span class="-pub-agree-text -pub-agree-text--grey-icon">D-31</span>
                        </template>
                        <template v-else>
                          N
                        </template>
                      </td>

                      <td class="-pub-table-column" style="width: 228px;">
                        <template v-if="props.item.isReception">
                          <span class="point-text--pt-1">N(이메일 주소 없음)</span>
                        </template>
                        <template v-else>
                             Y
                        </template>
                      </td>
                    </template>
                  </fdp-infinite>
              </div>
          </div>
          <div class="-pub-bottom-bar">
            <div class="-pub-confirm__content--right">
              <button class="-pub-button -pub-button--purple -pub-button--confirm" @click="modals.list1 = !modals.list1">
                <span class="-pub-button__text">취소</span>
              </button><button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm">
                <span class="-pub-button__text">확인</span>
              </button>
              </div>
          </div>
      </fdp-modal>
      <!-- 수신고객 목록조회 팝업 end -->
      <!-- 수신고객 목록조회 (문자전송시 팝업) -->
      <fdp-modal class="-pub-confirm -pub-confirm-type-4 -pub-customer-list__confirm" v-model="modals.list2" quit>
          <div class="-pub-confirm__header">
            <h2 class="-pub-confirm__title">수신고객목록</h2>
          </div>
          <div class="-pub-confirm__content -pub-confirm__content--left">
              <div class="-pub-confirm__content--left -pub-confirm__content--main">
                <p class="-pub-confirm__desc">선택한 N명의 고객 중 N명의 고객에게 문자를 전송합니다.</p>
                <fdp-infinite class="-pub-table" :items="mockData" :tableBodyHeight="450">
                    <template slot="header">
                      <tr class="-pub-table__header">
                        <th class="-pub-table-column" style="width: 186px;">고객명</th>
                        <th class="-pub-table-column" style="width: 204px;">생년월일</th>
                        <th class="-pub-table-column" style="width: 186px;">수금/가망</th>
                        <th class="-pub-table-column" style="width: 168px;">마케팅 동의</th>
                        <th class="-pub-table-column" style="width: 228px;">수신가능여부</th>
                      </tr>
                    </template>
                    <template slot-scope="props">
                      <td class="-pub-table-column -pub-table-column--name" style="width: 186px;">{{props.item.name}}</td>
                      <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 204px;">{{props.item.birthDay}}</td>
                      <td class="-pub-table-column" style="width: 186px;">{{props.item.collect}}</td>
                      <td class="-pub-table-column -pub-table-column--left-center -pub-table-column--normal-letter" style="width: 168px;">
                        <template v-if="props.item.marketing">
                          <span class="-pub-agree-text -pub-agree-text--grey-icon">D-31</span>
                        </template>
                        <template v-else>
                          N
                        </template>
                      </td>

                      <td class="-pub-table-column" style="width: 228px;">
                        <template v-if="props.item.isReception">
                          <span class="point-text--pt-1">N(이메일 주소 없음)</span>
                        </template>
                        <template v-else>
                             Y
                        </template>
                      </td>
                    </template>
                  </fdp-infinite>
              </div>
          </div>
          <div class="-pub-confirm__content--right">
            <div class="-pub-bottom-bar">
              <button class="-pub-button -pub-button--purple -pub-button--confirm" @click="modals.list2 = !modals.list2">
                <span class="-pub-button__text">취소</span>
              </button><button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm">
                <span class="-pub-button__text">확인</span>
              </button>
            </div>
        </div>
      </fdp-modal>
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true" :page-fixed="true">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item" @click="modals.list1 = !modals.list1">
            <span class="-pub-button__text">수신고객 목록조회(이메일 발송시)</span>
          </button>
          <button class="-pub-button -pub-button--purple  -pub-bottom-nav__item" @click="modals.list2 = !modals.list2">
            <span class="-pub-button__text">수신고객 문자전송시</span>
          </button>
        </li>
      </ul>
    </fdp-bottom-bar>
  </div>
</template>
<script>
import mockData from '@/components/mock/TSSCM222P.mock'

export default {
  data () {
    return {
      modals: {
        list1: true,
        list2: false
      },
      mockData: Object.assign({}, mockData),
      mockHeader: []
    }
  }
}
</script>
