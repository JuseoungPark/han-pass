<template>
  <section>
    <!-- 페이지 서브 메뉴 영역 end -->
    <div class="-pub-contents">
      <!-- 페이지 조회 input, button 검색 명수 영역  -->
      <div class="-pub-filter-menu -pub-filter-menu__margintop">
        <div class="-pub-filter-menu__item--right">
          <form onsubmit="return false;">
            <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
            <button type="submit" class="-pub-search-button -pub-filter-menu__item">
              <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
            </button>
            <!-- 상세조회 버튼영역 -pub-filter-menu__detail-button--active 클래스 추가시 arrow icon 방향이 위로 회전함 -->
            <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
              <span>상세조회</span>
              <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
            </a>
            <!-- 상세조회 버튼영역 end -->
          </form>
        </div>
        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총
          {{mockData.length}}명</div>
      </div>
      <!-- 페이지 조회 input, button 검색 명수 영역 end -->
      <!-- 상세조회 영역 -->
      <template v-if="isDetailSearch">
        <div class="-pub-filter-detail__scroll">
        <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
          <!-- 임직원일 경우에만 보이는 상세조회 field -->
          <template v-if="true">
            <li class="-pub-filter-detail__area">
              <div class="-pub-filter-detail__item -pub-filter-detail__title">조직</div>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-1" v-model="selectGroups.values.group1"
                :option-list="selectGroups.group1"></fdp-select>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-2" v-model="selectGroups.values.group2"
                :option-list="selectGroups.group2"></fdp-select>
              <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select detail-type-3" v-model="selectGroups.values.group3"
                :option-list="selectGroups.group3"></fdp-select>
            </li>
            <li class="-pub-filter-detail__area">
              <div class="-pub-filter-detail__item -pub-filter-detail__title">컨설턴트</div>
              <!-- 20181018 마크업 변경 detail-type-4 => detail-type-5  -->
              <fdp-select class="-pub-select -pub-filter-menu__item--select detail-type-5" v-model="selectGroups.values.group4" :option-list="selectGroups.group4" placeholder="담당 컨설턴트"></fdp-select>
            </li>
          </template>
          <!-- 임직원일 경우에만 보이는 상세조회 field end -->
          <li class="-pub-filter-detail__area">
            <div class="-pub-filter-detail__item -pub-filter-detail__title">고객구분</div>
            <fdp-segment-box class="-pub-filter-detail__item -pub-segment__container -pub-segment--medium -pub-segment--purple"
              v-model="customerType" :data="customerTypes"></fdp-segment-box>
          </li>
          </ul>
          </div>
          <div class="-pub-filter-detail__bottom">
          <ul class="-pub-filter-detail -pub-filter-detail--multi-field">
            <li class="-pub-filter-detail__area -pub-filter-detail__area--right">
              <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                <span class="-pub-button__text">조회</span>
              </button>
              <button class="-pub-button -pub-button--purple -pub-button--medium -pub-filter-detail__item -pub-filter-detail__button">
                <span class="-pub-button__text">초기화</span>
              </button>
            </li>
          </ul>
        </div>
      </template>
      <!-- 고객 관련 정보 데이터 테이블 영역 -->
      <div :class="hasSelectItem ? '-pub-table-height__onBottom2' : '-pub-table-height__offBottom2'">
      <fdp-infinite class="-pub-table" v-model="selectItems" multi-select :items="mockData" :table-body-height="hasSelectItem ? 720 : 720"><!-- 사이즈 수정 20181031-->
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-table-column--checkbox" style="width: 78px;">
              <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
              v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
            </th>
            <th class="-pub-table-column" style="width: 134px;">고객명</th>
            <th class="-pub-table-column" style="width: 196px;">생년월일</th>
            <th class="-pub-table-column" style="width: 70px;">성별</th>
            <th class="-pub-table-column" style="width: 254px; padding-right: 50px;">휴대폰번호</th>
            <th class="-pub-table-column -pub-table-column--left-align" style="width: 146px; padding-right: 50px;">필수컨설팅</th>
            <th class="-pub-table-column -pub-table-column--left-align" style="width: 146px;">마케팅</th>
            <th class="-pub-table-column" style="width: 192px;">보험상담동의</th>
            <th class="-pub-table-column" style="width: 126px;">고객 구분</th>
            <th class="-pub-table-column" style="width: 126px;">주고객</th>
          </tr>
        </template>
        <template slot-scope="props">
          <td class="-pub-table-column--checkbox" style="width: 78px;">
            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
              v-model="selectItems" :value="props.item"></fdp-checkbox>
          </td>
          <td class="-pub-table-column -pub-table-column--name" style="width: 134px;">{{props.item.name}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 196px;">{{props.item.birthDay}}</td>
          <td class="-pub-table-column" style="width: 70px;">{{props.item.gender}}</td>
          <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 254px; padding-right: 50px;">{{props.item.phone}}</td>
          <td class="-pub-table-column -pub-table-column--left-align -pub-table-column--normal-letter" style="width: 146px; padding-right: 50px;">
            <template v-if="props.item.consulting">
              <span class="-pub-agree-text">D-99</span>
            </template>
            <template v-else>
              N
            </template>
          </td>
          <td class="-pub-table-column -pub-table-column--left-align -pub-table-column--normal-letter" style="width: 146px;">
            <template v-if="props.item.marketing">
              <span class="-pub-agree-text -pub-agree-text--grey-icon">D-99+</span>
            </template>
            <template v-else>
              N
            </template>
          </td>
          <td class="-pub-table-column" style="width: 192px;">{{props.item.agree}}</td>
          <td class="-pub-table-column" style="width: 126px;">{{props.item.customerType}}</td>
          <td class="-pub-table-column" style="width: 126px;">{{props.item.mainCustomer}}</td>
        </template>
        <!-- 데이터 없는 화면 추가 20181023 -->
        <template slot="emptyView" v-show="mockData.length == 0">
            <div class="-pub-table-empty-view">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
            </div>
            <div class="-pub-table-empty-view -pub-table-empty-view--search">
                <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
            </div>
        </template>
      </fdp-infinite>
    </div>
    </div>
    <!-- 고객 관련 정보 데이터 테이블 영역 end -->
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" :page-fixed="true">
      <ul class="-pub-bottom-nav">
        <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
          <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox
          v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
        </li>
        <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
          <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item -pub-button--disabled-line" :disabled="hasSelectItem">
            <span class="-pub-button__text">동의서 발행</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line" :disabled="!hasSelectItem">
            <span class="-pub-button__text">문자</span>
          </button>
          <button class="-pub-button -pub-button--purple -pub-bottom-nav__item -pub-button--disabled-line" :disabled="!hasSelectItem">
            <span class="-pub-button__text">내 그룹에 추가</span>
          </button>
          <!-- tooltip 메뉴 버튼 bottom bar-->
          <fdp-tooltip-menu class="-pub-bottom-nav__item -pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--purple"
            v-model="currMenu" :menu-list="menuListSample" blue top>
            <div class="-pub-button -pub-button--tooltip -pub-button--disabled-line">
              <span class="-pub-symbol--menu"></span>
            </div>
          </fdp-tooltip-menu>
          <!-- tooltip 메뉴 버튼 end-->
        </li>
      </ul>
    </fdp-bottom-bar>
    <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
    <!-- 선도개발 두번쨰 페이지 팝업창 (별도로 페이지로 구성하지않고 첫번째 페이지에서 버튼으로 열 수 있도록 반영 -->
    <fdp-modal class="-pub-confirm" v-model="showDefaultModal">
      <div class="-pub-confirm__content -pub-confirm__text--main">선택한 고객의 세대원 중 ‘승인요청’단계에 머물러있는 모든 세대원의 승인요청이 삭제됩니다.
        삭제신청 후 취소는 불가능합니다.</div>
      <div class="-pub-confirm__content -pub-confirm__text--sub">삭제하시겠습니까?</div>
      <div class="-pub-confirm__content -pub-confirm__content--right">
        <button class="-pub-button -pub-confirm__button">
          <span class="-pub-button__text">아니오</span>
        </button>
        <button class="-pub-button -pub-button--reverse -pub-confirm__button">
          <span class="-pub-button__text">예</span>
        </button>
      </div>
    </fdp-modal>
    <!-- 선도개발 두번쨰 페이지 팝업창 (별도로 페이지로 구성하지않고 첫번째 페이지에서 버튼으로 열 수 있도록 반영 end -->
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM203M.mock'

export default {
  data () {
    return {
      title: '고객',
      showDefaultModal: false,
      isDetailSearch: false,
      mockHeader: [],
      mockData: Array.prototype.slice.call(viewMemberMocks),
      menuListSample: [{
        label: '이메일',
        key: 'email'
      },
      {
        label: 'DM',
        key: 'dm'
      },
      {
        label: '택배',
        key: 'delivery'
      }
      ],
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      selectedValue: '',
      customerType: [],
      customerTypes: [{
        key: '1',
        label: '전체'
      },
      {
        key: '2',
        label: '본인모집'
      },
      {
        key: '3',
        label: '타인모집'
      },
      {
        key: '4',
        label: '관심'
      },
      {
        key: '5',
        label: '임시'
      },
      {
        key: '6',
        label: '가망'
      }
      ],
      selectItems: [],
      selectGroups: {
        group1: [{
          key: '1',
          label: '경원사업부'
        }],
        group2: [{
          key: '1',
          label: '안양평촌지역단'
        }],
        group3: [{
          key: '1',
          label: '평일지점'
        }],
        group4: [{
          key: '1',
          label: '김안범(000012312)'
        }],
        values: {
          group1: {
            key: '1',
            label: '경원사업부'
          },
          group2: {
            key: '1',
            label: '안양평촌지역단'
          },
          group3: {
            key: '1',
            label: '평일지점'
          },
          group4: {
            key: '1',
            label: '김안범(000012312)'
          }
        }
      },
      isSelectAll: false,
      bottomBarCheck: false
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      console.log(offsetTop)
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  mounted () {
    this.customerType.push(this.customerTypes[0])
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}
</script>
