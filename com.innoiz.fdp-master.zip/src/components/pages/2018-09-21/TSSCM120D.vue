<template>
    <section class="-pub-popup__detail-personal -pub-popup__content--detail-modify">
      <div class="-pub-popup__content--detail-personal">
          <!-- 기본정보 start -->
          <div class="-pub-popup__title">
              <span class="-pub-popup__title-txt">기본 정보</span>
              <div class="-pub-popup__title-button">
                  <button type="button" class="-pub-button -pub-button--gray">
                      <span class="-pub-button__text">일련번호 조회</span>
                  </button>
              </div>
          </div>
          <div class="-pub-popup__content--detail-form01">
            <!-- 간단정보 보기 영역 start -->
            <dl class="-pub-form-row__1">
              <dt class="-pub-form-title">고객명</dt>
              <dd class="-pub-form-input">김하늘</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주민등록번호</dt>
                <dd class="-pub-form-input -pub-normal-letter">890707-2*******</dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">실제생일</dt>
                <dd class="-pub-form-input -pub-normal-letter">1789-07-07(양력)</dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">취득경로</dt>
                <dd class="-pub-form-input">소개</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">소개자</dt>
                <dd class="-pub-form-input">김지연</dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">소개일</dt>
                <dd class="-pub-form-input -pub-normal-letter">2017-09-07</dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">직업</dt>
                <dd class="-pub-form-input">총무사무원</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">직장명</dt>
                <dd class="-pub-form-input">쌍용자동차</dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">세대주</dt>
                <dd class="-pub-form-input -pub-normal-letter">Y</dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">주고객명</dt>
                <dd class="-pub-form-input">김하늘</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주고객관계</dt>
                <dd class="-pub-form-input">본인</dd>
            </dl>
            <!-- 간단정보 보기 영역 end -->
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 start -->
            <dl class="-pub-form-row__1" v-if="isDetailSearch">
                <dt class="-pub-form-title">부서</dt>
                <dd class="-pub-form-input">마케팅</dd>
            </dl>
            <dl class="-pub-form-row__2" v-if="isDetailSearch">
                <dt class="-pub-form-title">직급</dt>
                <dd class="-pub-form-input">대리</dd>
            </dl>
            <dl class="-pub-form-row__3" v-if="isDetailSearch">
                <dt class="-pub-form-title">취미</dt>
                <dd class="-pub-form-input"></dd>
            </dl>
            <dl class="-pub-form-row__1" v-if="isDetailSearch">
                <dt class="-pub-form-title">자보가입</dt>
                <dd class="-pub-form-input">삼성화재</dd>
            </dl>
            <dl class="-pub-form-row__2" v-if="isDetailSearch">
                <dt class="-pub-form-title">자보만기일</dt>
                <dd class="-pub-form-input -pub-normal-letter">2017-09-07</dd>
            </dl>
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 end -->
          </div>
          <div class="-pub-detail-form__view">
             <!-- 전체보기 버튼 영역 start -->
             <!-- <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>전체보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
              </a> -->
              <!-- 전체보기 버튼영역 end -->
              <!-- 간단 정보 보기 버튼 영역 start-->
              <a class="-pub-info-wrap_expand-button" :class="[{'-pub__info--isOpen': isDetailSearch}]" @click="isDetailSearch=!isDetailSearch">
                <span>{{!isDetailSearch?'전체보기' : '간단 정보 보기'}}</span>
              </a>
              <!-- 간단 정보 보기 버튼영역 end -->
          </div>
          <!-- 기본정보 end -->
          <!-- 주소 및 연락처 start -->
          <div class="-pub-popup__title">
              <span class="-pub-popup__title-txt">주소 및 연락처</span>
              <div class="-pub-popup__title-button">
                  <button type="button" class="-pub-button -pub-button--gray">
                      <span class="-pub-button__text">주고객주소 반영</span>
                  </button>
              </div>
          </div>
          <div class="-pub-popup__content--detail-form02">
            <!-- 간단정보 보기 영역 start -->
            <dl class="-pub-form-row__1">
              <dt class="-pub-form-title">휴대폰</dt>
              <dd class="-pub-form-input -pub-normal-letter"><span class="-pub-icon-normal">정상</span>010-1123-1234</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">이메일</dt>
                <dd class="-pub-form-input -pub-normal-letter"><span class="-pub-icon-fail">발송실패</span>text000@naver.com</dd>
            </dl>
            <!-- 간단정보 보기 영역 end -->
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 start -->
            <dl class="-pub-form-row__1" v-if="isDetailSearch2">
                <dt class="-pub-form-title">자택주소</dt>
                <dd class="-pub-form-input"><span class="-pub-icon-fail">오류</span>175-89, 경기 안경기 안성시 대천동 95번지 </dd>
              </dl>
              <dl class="-pub-form-row__2" v-if="isDetailSearch2">
                  <dt class="-pub-form-title">자택전화</dt>
                  <dd class="-pub-form-input -pub-normal-letter"><span class="-pub-icon-fail">중복</span>02-1234-1234</dd>
              </dl>
              <dl class="-pub-form-row__1" v-if="isDetailSearch2">
                  <dt class="-pub-form-title">직장주소</dt>
                  <dd class="-pub-form-input"><span class="-pub-icon-fail">반송</span>32323, 대전광역시 대덕구 벚꽃길 113  </dd>
                </dl>
                <dl class="-pub-form-row__2" v-if="isDetailSearch2">
                    <dt class="-pub-form-title">직장전화</dt>
                    <dd class="-pub-form-input -pub-normal-letter"><span class="-pub-icon-fail">정상(확인불가)</span>02-1234-1234</dd>
                </dl>
                <dl class="-pub-form-row__1" v-if="isDetailSearch2">
                    <dt class="-pub-form-title">우편물수령지</dt>
                    <dd class="-pub-form-input">자택</dd>
                </dl>
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 end -->
          </div>
          <div class="-pub-detail-form__view">
             <!-- 전체보기 버튼 영역 start -->
             <!-- <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>전체보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
              </a> -->
              <!-- 전체보기 버튼영역 end -->
              <!-- 간단 정보 보기 버튼 영역 start-->
              <a class="-pub-info-wrap_expand-button" :class="[{'-pub__info--isOpen': isDetailSearch2}]" @click="isDetailSearch2=!isDetailSearch2">
                <span>{{!isDetailSearch2?'전체보기' : '간단 정보 보기'}}</span>
              </a>
              <!-- 간단 정보 보기 버튼영역 end -->
          </div>
          <!-- 주소 및 연락처 end -->
          <!-- 세대 관계 정보 start -->
          <div class="-pub-popup__title">
              <span class="-pub-popup__title-txt">세대 관계 정보</span>
          </div>
          <div class="-pub-popup__content--list-form">
              <fdp-infinite  class="-pub-table -pop-customer" v-model="selectItemsTarget" :items="mockData">
                  <template slot="header">
                      <tr class="-pub-table__header">
                          <th class="-pub-table-column" style="width: 176px;">고객명</th>
                          <th class="-pub-table-column" style="width: 128px;">세대주</th>
                          <th class="-pub-table-column" style="width: 222px;">주민등록번호</th>
                          <th class="-pub-table-column" style="width: 128px;">외국인</th>
                          <th class="-pub-table-column" style="width: 154px;">주고객관계</th>
                          <th class="-pub-table-column" style="width: 234px;">실제생일</th>
                          <th class="-pub-table-column" style="width: 154px;">직업</th>
                          <th class="-pub-table-column" style="width: 316px;">휴대폰번호</th>
                      </tr>
                  </template>
                  <template slot-scope="props">
                      <td class="-pub-table-column -pub-table-column--name" style="width: 176px;">{{props.item.name}}</td>
                      <td class="-pub-table-column" style="width: 128px;">{{props.item.data1}}</td>
                      <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 222px;">{{props.item.calories}}</td>
                      <td class="-pub-table-column" style="width: 128px;">{{props.item.data2}}</td>
                      <td class="-pub-table-column" style="width: 154px;">{{props.item.data3}}</td>
                      <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 234px;">{{props.item.data5}}</td>
                      <td class="-pub-table-column" style="width: 154px;">{{props.item.job}}</td>
                      <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 316px;">{{props.item.data4}}</td>
                  </template>
            </fdp-infinite>
          </div>
          <!-- 세대 관계 정보 end -->
          <!-- 정보활용동의 및 접촉거부 정보 start -->
          <div class="-pub-popup__title">
              <span class="-pub-popup__title-txt">정보활용동의 및 접촉거부 정보</span>
              <div class="-pub-popup__title-button">
                  <button type="button" class="-pub-button -pub-button--gray">
                      <span class="-pub-button__text">정보제공동의 관리</span>
                  </button>
              </div>
          </div>
          <div class="-pub-popup__content--detail-form01">
              <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">필수컨설팅동의</dt>
                <dd class="-pub-form-input -pub-normal-letter">Y (2017-03-25 만료)</dd>
              </dl>
              <dl class="-pub-form-row__2">
                  <dt class="-pub-form-title">마케팅동의</dt>
                  <dd class="-pub-form-input -pub-normal-letter">Y (2017-11-07 만료)</dd>
              </dl>
              <dl class="-pub-form-row__3">
                  <dt class="-pub-form-title">전환동의</dt>
                  <dd class="-pub-form-input -pub-normal-letter">N</dd>
              </dl>
              <dl class="-pub-form-row__1">
                  <dt class="-pub-form-title">보험상담동의</dt>
                  <dd class="-pub-form-input -pub-normal-letter">N (2017-03-23 만료)</dd>
              </dl>
              <dl class="-pub-form-row__2">
                  <dt class="-pub-form-title">온라인상담</dt>
                  <dd class="-pub-form-input -pub-normal-letter">N</dd>
              </dl>
              <dl class="-pub-form-row__3">
                  <dt class="-pub-form-title">두낫콜여부</dt>
                  <dd class="-pub-form-input -pub-normal-letter">N</dd>
              </dl>
              <dl class="-pub-form-row__1">
                  <dt class="-pub-form-title">접촉거부</dt>
                  <dd class="-pub-form-input">이메일</dd>
              </dl>
          </div>
          <!-- 정보활용동의 및 접촉거부 정보 end -->
          <!-- 마케팅 정보 start -->
          <div class="-pub-popup__title -pub-marketing-info">
              <span class="-pub-popup__title-txt">마케팅 정보</span>
              <div class="-pub-popup__title-button-arrow">
                  <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch3}]" @click="isDetailSearch3 = !isDetailSearch3">
                    <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                  </a>
              </div>
          </div>
          <div class="-pub-popup__content--detail-form01" v-show="isDetailSearch3">
              <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">자녀 1</dt>
                <dd class="-pub-form-input">1999년 출생 (여)</dd>
              </dl>
              <dl class="-pub-form-row__2">
                  <dt class="-pub-form-title">자녀 2</dt>
                  <dd class="-pub-form-input">1999년 출생 (여)</dd>
              </dl>
              <dl class="-pub-form-row__3">
                  <dt class="-pub-form-title">자녀 3</dt>
                  <dd class="-pub-form-input -pub-normal-letter">N</dd>
              </dl>
              <dl class="-pub-form-row__1">
                  <dt class="-pub-form-title">자녀 4</dt>
                  <dd class="-pub-form-input">1999년 출생 (여)</dd>
              </dl>
              <dl class="-pub-form-row__2">
                  <dt class="-pub-form-title">자녀 5</dt>
                  <dd class="-pub-form-input">1999년 출생 (여)</dd>
              </dl>
              <dl class="-pub-form-row__3">
                  <dt class="-pub-form-title">자녀 6</dt>
                  <dd class="-pub-form-input">1999년 출생 (여)</dd>
              </dl>
              <dl class="-pub-form-row__1">
                  <dt class="-pub-form-title">가족구성원</dt>
                  <dd class="-pub-form-input">4명</dd>
              </dl>
          </div>
          <!-- 마케팅 정보 end -->
        </div>
    </section>
  </template>
<script>
import mockData from '@/components/mock/TSSCM120D.mock'
export default {
  data: function () {
    return {
      isDetailSearch: false,
      isDetailSearch2: false,
      isDetailSearch3: false,
      selected: [],
      items: [],
      name: '',
      gender: '',
      default: '',
      clearable: '',
      password: '',
      masking: '',
      fixedIcon: '',
      disabled: 'text not editable',
      readonly: 'text not editable',
      radioTfValue: false,
      radioStrValue: '',
      radioSelected: '',
      radioTableSelected: [],
      selectItemsTarget: [],
      mockData: Array.prototype.slice.call(mockData, 0, 6),
      emailSelectValue: {
        key: '1',
        label: '직접입력'
      },
      emailSelectItems: [{
        key: '1',
        label: 'naver.com'
      },
      {
        key: '2',
        label: 'daum.net'
      }
      ],
      phoneSelectValue: {
        key: '1',
        label: '010'
      },
      phoneSelectItems: [{
        key: '1',
        label: '010'
      },
      {
        key: '2',
        label: '080'
      }
      ],
      filterSelectValue: {
        key: '1',
        label: '선택하세요'
      },
      filterSelectItems: [{
        key: '1',
        label: '소개'
      },
      {
        key: '2',
        label: '소개'
      }
      ],
      customer: {
        key: '1',
        label: '자녀'
      },
      customerItems: [{
        key: '1',
        label: '자녀'
      },
      {
        key: '2',
        label: '자녀'
      }
      ],
      filter: [
        {
          key: '1',
          label: '양력'
        }
      ],
      filters: [{
        key: '1',
        label: '양력'
      },
      {
        key: '2',
        label: '음력'
      }
      ],
      head: [
        {
          key: '1',
          label: 'N'
        }
      ],
      header: [{
        key: '1',
        label: 'N'
      },
      {
        key: '2',
        label: 'Y'
      }
      ],
      address: [
        {
          key: '1',
          label: '자택'
        }
      ],
      addresszipcode: [{
        key: '1',
        label: '자택'
      },
      {
        key: '2',
        label: '직장'
      }
      ],
      foreigner: [
        {
          key: '1',
          label: 'N'
        }
      ],
      foreignerpeople: [{
        key: '1',
        label: 'N'
      },
      {
        key: '2',
        label: 'Y'
      }
      ],
      yearSelectValue: {
        key: '1',
        label: '2010'
      },
      yearSelectItems: [{
        key: '1',
        label: '2010'
      },
      {
        key: '2',
        label: '2009'
      }
      ],
      genderpeople: [{
        key: '1',
        label: '남'
      },
      {
        key: '2',
        label: '여'
      }
      ]
    }
  },
  methods: {
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.tit
      }
    }
  }
}
</script>
