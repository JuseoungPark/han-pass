<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="타사증권입력" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup">
        <div class="-pub-consulting-popup__default-info -pub-consulting-popup__default-info--fixed -pub-consulting-popup__default-info--no-padding-bottom">
          <div class="-pub-consulting-popup__default-content">
            <div class="-pub-consulting-popup__product-info">
              <h4 class="-pub-consulting-popup__product-name">교보생명 통합유니버셜종신보험 3.0(무)</h4>
              <span class="-pub-consulting-popup__customer-info"><span class="-pub-serapetor-line">계약자 : 이주명</span><span
                  class="-pub-serapetor-line">피보험자 : 이주명(종피) </span><span class="-pub-serapetor-line normal-letter">2017-01
                  ~ 2020-01 / 2037-01</span></span>
            </div>
            <span class="-pub-consulting-popup__product-month-amount">월<span class="bold-text">32,000</span>원</span>
            <button type="button" class="-pub-button -pub-button--update -pub-consulting-popup__row-item">
              <span class="-pub-button__text">수정</span>
            </button>
          </div>
          <div class="-pub-consulting-popup__active-content">
            <h3 class="-pub-consulting-popup__title">특약정보</h3>
            <div class="-pub-consulting-popup__count">총 {{mockData.length}}건</div>
            <fdp-infinite class="-pub-table -pub-table--blue -pub-table--auto-height -pub-table--row-large" v-model="selectItems"
              :items="mockData">
              <template slot="header">
                <tr class="-pub-table__header">
                  <th class="-pub-table-column--checkbox">
                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                  </th>
                  <th class="-pub-table-column" style="width: 388px;">
                    <span class="-pub-table-column__text">특약명</span>
                  </th>
                  <th class="-pub-table-column" style="width: 100px;">
                    <span class="-pub-table-column__text">형태</span>
                  </th>
                  <th class="-pub-table-column" style="width: 100px;">
                    <span class="-pub-table-column__text">주종피</span>
                  </th>
                  <th class="-pub-table-column" style="width: 194px;">
                    <span class="-pub-table-column__text">가입금액(만원)</span>
                  </th>
                  <th class="-pub-table-column" style="width: 318px;">
                    <span class="-pub-table-column__text">보장만기</span>
                  </th>
                  <th class="-pub-table-column" style="width: 134px;"></th>
                </tr>
              </template>
              <template slot-scope="props">
                <td class="-pub-table-column--checkbox">
                  <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label" isIconCheckbox v-model="selectItems"
                    :value="props.item"></fdp-checkbox>
                </td>
                <td class="-pub-table-column align-left" style="width: 388px;">
                  <fdp-tooltip-button class="-pub-tooltip -pub-tooltip--table-desc">
                    <template slot="activator">
                      <span class="-pub-table-column__underline">{{props.item.name}}</span>
                    </template>
                    <template slot="content">
                      <h3 class="-pub-tooltip__title">유사암진단비란..</h3>
                      <p class="-pub-tooltip__desc">
                        상세내용상세내용상세내용상세내용상세내용상세내용
                        상세내용상세내용상세내용상세내용상세내용상세내용
                        상세내용상세내용상세내용상세내용상세내용상세내용
                      </p>
                    </template>
                  </fdp-tooltip-button>
                </td>
                <td class="-pub-table-column" style="width: 100px;">{{props.item.type}}</td>
                <td class="-pub-table-column" style="width: 100px;">{{props.item.ju}}</td>
                <td class="-pub-table-column" style="width: 194px;">
                  <fdp-validator :name="'tssct007p-validator-amount-' + props.index" display-name="가입금액" v-model="props.item.amount"
                    :rules="'required'">
                    <fdp-text-field class="-pub-text-field -pub-consulting-popup__table-field-1 normal-letter" v-model="props.item.amount" mask="won"></fdp-text-field>
                  </fdp-validator>
                </td>
                <td class="-pub-table-column -pub-table-column--time-life" style="width: 318px;">
                  <fdp-validator :name="'tssct007p-validator-maturity-' + props.index" display-name="보장만기" v-model="props.item.maturity"
                    :rules="'required'">
                    <fdp-date-picker class="-pub-date-picker -pub-consulting-popup__table-field-1" v-model="props.item.maturity"
                      format="yyyy-MM" :disabled="props.item.dateLife"></fdp-date-picker>
                  </fdp-validator>
                  <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="props.item.dateLife">종신</fdp-checkbox>
                </td>
                <td class="-pub-table-column" style="width: 134px;">
                  <button type="button" class="-pub-button -pub-button--light -pub-button--copy" @click="onCopy">복사</button>
                </td>
              </template>
              <template slot="emptyView">
                <div class="-pub-table-empty-view">데이터가 존재하지 않습니다.</div>
              </template>
            </fdp-infinite>
          </div>
        </div>
      </div>
      <div class="-pub-bottom-bar">
        <div class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="selectItems.length > 0">
          <fdp-checkbox class="-pub-checkbox -pub-check-label" isIconCheckbox v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{selectItems.length}}건
            선택</fdp-checkbox>
        </div>
        <div class="-pub-confirm__content--right">
          <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
          </button><button type="button" class="-pub-button -pub-button--reverse">
            <span class="-pub-button__text">등록</span>
          </button>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  mockData
} from '@/components/mock/TSSCT007P.mock'
export default {
  data () {
    return {
      showSelectContent: true,
      showPopup: true,
      isIntial: true,
      name: '',
      selectItems: [],
      isSelectAll: false,
      bottomBarCheck: false,
      // mockData: Array.prototype.slice.call([]),
      mockData: Array.prototype.slice.call(mockData),
      date1: '2017-01',
      date1Life: false,
      searchKeyword: '3,000',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },
      segment1: {
        items: [{
          key: '1',
          label: '생명보험'
        },
        {
          key: '2',
          label: '손해보험'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment2: {
        items: [{
          key: '1',
          label: '일반'
        },
        {
          key: '2',
          label: '유니버셜'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment3: {
        items: [{
          key: '1',
          label: '주피'
        },
        {
          key: '2',
          label: '종피'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      select1: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '교보생명'
        }]
      },
      select2: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '이주명'
        }]
      },
      select3: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '월납'
        }]
      }
    }
  },
  computed: {
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  methods: {
    selectAllItemsFunc (isSelectAll) {
      if (isSelectAll) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    },
    onCopy () {
      // 복사로직 구현
    }
  },
  watch: {
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  }
}

</script>
