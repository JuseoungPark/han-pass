<template>
  <!-- popup on : start -->
  <!-- 닫힌상태는 class:"-pub-sitemap-pop-off" -->
  <section class="-pub-sitemap-pop" :class="{'-pub-sitemap-pop-off' : !isOpen}">
    <div class="-pub-sitemap-content--right">
    <div class="-pub-side-menu-btn" @click="isOpen = !isOpen"></div>
      <div class="-pub-page-container">
          <div class="-pub-contents-pop">
              <ul class="-pub-contents__menu">
                  <li v-for="(subMenu, idx) in mockData" :key="idx" tabindex="1" :class="idx === 0 ? '-pub-first-menu--active' : ''" class="-pub-first-menu">
                      <img v-if="subMenu.isNew" class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">
                      <span>{{subMenu.label}}</span>
                      <img v-if="subMenu.isGo" class="-pub-menu__icon -pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                      <ul v-if="subMenu.menu">
                          <li v-for="(sub, idx) in subMenu.menu" :key="idx" tabindex="1" class="-pub-second-menu"><span>{{sub.label}}</span>
                              <ul v-if="sub.menu">
                                  <li v-for="(subMenu, idx) in sub.menu" :key="idx" tabindex="1" class="-pub-third-menu">
                                      <img v-if="subMenu.isNew" class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">
                                      <img v-if="subMenu.isPinOn" class="-pub-menu__icon"  @click="pinClick(idx)"  src="@/assets/img/ico_menu_pin_sel.png" alt="">
                                      <img v-else class="-pub-menu__icon"  @click="pinClick(idx)"  src="@/assets/img/ico_menu_pin_nor.png" alt="">
                                      <span class="sub_menu_pos" v-html="subMenu.label"  @click="pinClick(idx)">{{subMenu.label}}</span>
                                  </li>
                              </ul>
                          </li>
                      </ul>
                  </li>
              </ul>
          </div>
      </div>
    </div>
  </section>
  <!-- popup on : end -->
</template>
<script>
import { popMenuMocks } from '@/components/mock/TSSBC110M.mock'
export default {
  data () {
    return {
      title: '전체메뉴',
      isOpen: true,
      mockData: Array.prototype.slice.call(popMenuMocks),
      defaultUsage: {
        default: ''
      }
    }
  },
  methods: {
    pinClick (i) {
      this.mockData[0].menu[0].menu[i].isPinOn = !this.mockData[0].menu[0].menu[i].isPinOn
    }
  }
}
</script>
