<template>
  <section>
    <!-- 페이지 서브 메뉴 영역 end -->
    <div class="-pub-contents">
        <!-- 페이지 조회 input, button 검색 명수 영역  -->
        <div class="-pub-filter-menu -pub-filter-menu--in-tab"><!-- 마크업 추가 20181101 -pub-filter-menu--in-tab -->
          <div class="-pub-filter-menu__item--right">
            <form onsubmit="return false;">
              <div class="-pub-filter-menu__item">
                <span class="-pub-filter-menu__item -pub-filter-menu__label">대상 월</span>
                <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker -pub-premiun-date-picker"
                  v-model="targetMonth" format="yyyy-MM"></fdp-date-picker>
              </div>
              <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명, 휴대폰번호" v-model="searchKeyword" clearable></fdp-text-field>
              <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
              </button>
            </form>
          </div>
          <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
        </div>
        <!-- 페이지 조회 input, button 검색 명수 영역 end -->
      <!-- fdp talbe 적용 -->
      </div>
      <div :class="hasSelectItem ? '-pub-table-height__onBottom4' : '-pub-table-height__offBottom4'">
      <fdp-table :options="opt" :items="mockData" multi-select :isLoading="isLoading" @loadingData="loadingData" @input="onInputMultiSelect" @headerCheckbox="onClickHeaderCheckbox"  class="-pub-table_wrap -pub-last">
          <template slot="empty">
              <div class="-pub-table-empty-view">
                  <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                </div>
              <div class="-pub-table-empty-view -pub-table-empty-view--search">
                <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
              </div>
          </template>
      </fdp-table>
    </div>
      <!-- 고객 관련 정보 데이터 테이블 영역 end -->
      <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component-->
      <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-premium-bar -pub-bottom-bar--default -pub-bottom-bar__premium--info" :page-fixed="true">
        <ul class="-pub-bottom-bar__premium--info-group">
          <li class="-pub-bottom-bar__premium--info-group_item">
              <dl>
                <dt>제공 고객 수</dt>
                <dd>31명</dd>
              </dl>
          </li>
          <li class="-pub-bottom-bar__premium--info-group_item">
            <dl>
              <dt>총 터치</dt>
              <dd>31명 / 100%</dd>
            </dl>
          </li>
          <li class="-pub-bottom-bar__premium--info-group_item">
            <dl>
              <dt>총 신계약</dt>
              <dd>3건</dd>
            </dl>
          </li>
          <li class="-pub-bottom-bar__premium--info-group_item">
            <dl>
              <dt>대상 신계약</dt>
              <dd>0건</dd>
            </dl>
          </li>
        </ul>
      </fdp-bottom-bar>
  </section>
</template>
<script>
import {
  viewMemberMocks,
  subMenus
} from '@/components/mock/TSSCM310D.mock'

export default {
  data () {
    return {
      opt: columnFixed,
      title: '고객',
      modals: {
        confirm1: false,
        confirm2: false
      },
      menuListSample: [],
      targetMonth: '',
      isDetailSearch: false,
      mockData: Array.prototype.slice.call(viewMemberMocks),
      currMenu: '',
      subMenus: Array.prototype.slice.call(subMenus),
      searchKeyword: '',
      isSelectAll: false,
      bottomBarCheck: false
    }
  },
  methods: {
    onSizeChange (size) {},
    getTableHeight () {
      let el = this.$el.querySelector('.-pub-table')
      let offsetTop = 0
      while (el) {
        offsetTop += el.offsetTop
        el = el.offsetParent
      }

      return offsetTop
    }
  },
  computed: {},
  mounted () {}
}

// fdp-table에서 fixed column을 사용하기 위한 option
var columnFixed = {
  name: 'columnFixed',
  headerGroup: [
    [undefined, undefined, undefined, undefined, '신계약현황', '#', '활동내역', '#', '#', '#', '#', '#', undefined]
  ],
  cols: [// 사이즈가 디자인과 맞지 않아서 수정 20181019
    {key: 'name', width: 160, name: '고객명', headerStyle: {'text-align': 'center', 'height': '126px'}, bodyStyle: {'text-align': 'center', 'font-weight': '700'}},
    {key: 'customer', width: 120, name: '고객군', headerStyle: {'text-align': 'center', 'height': '126px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'type', width: 150, name: '유형', type: 'code', headerStyle: {'text-align': 'center', 'height': '126px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'applydivision', width: 190, name: '신청여부', headerStyle: {'text-align': 'center', 'height': '126px'}, bodyStyle: {'text-align': 'center'}},
    {key: 'contractdate', width: 215, name: '계약일자', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'productname', width: 250, name: '상품명', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center'}},
    {key: 'phone', width: 220, name: '전화', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'emarketing', width: 190, name: 'e마케팅', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'visit', width: 220, name: '방문', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'consent', width: 184, name: '동의서', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'hypothesis', width: 220, name: '가설', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'analysis', width: 170, name: '보장분석', headerStyle: {'text-align': 'center', 'height': '63px', 'border-top': '2px solid #e0e5ef'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
    {key: 'hpphone', width: 250, name: '휴대폰번호', headerStyle: {'text-align': 'center', 'height': '126px'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}}
  ],
  // 컬럼 고정 여부
  availableColumnFixed: true,
  // 고정할 컬럼 수 (왼쪽부터 적용)
  howManyColumnFixed: 1,
  headerHeight: 63, // 사이즈가 디자인과 맞지 않아서 수정 20181019
  tableHeight: 554,
  infinite: true
  // bodyHeight: this.selectItem ? 610 : 700 // table body height 사이즈 유동
}
</script>
