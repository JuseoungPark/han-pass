<template>
    <section>
        <div class="-pub-searched__category">
            <span class="-pub-tit">질병 <strong>{{diseaseList.length}}</strong></span>
            <div class="-pub-searched__category-disease">
                <div class="-pub-search-all__scroll---horizon" style="width: 3000px;" v-if="true">
                    <div class="-pub-searched-disease" v-for="(disease,idx) in diseaseList" :key="idx">
                        <div class="-pub-disease-tit">
                            <span class="-pub-disease-ico" v-html="getHighlightTitle(disease.title)"></span>
                            <img class="-pub-short-cut" src="@/assets/img/btn_information_purple.png" alt="바로가기">
                        </div>
                        <div class="-pub-disease-desc ">
                            <div>{{disease.desc}}</div>
                            <img class="-pub-short-cut" src="@/assets/img/btn_more.png" alt="바로가기">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  props: {
    searchKeyword: {
      type: String,
      default: ''
    },
    diseaseList: {
      type: [Array, Object],
      default: () => []

    }
  },
  data () {
    return {

    }
  },
  methods: {
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')
      return val.replace(regex, '<span class="-pub-search-color">$1</span>')
    }
  }
}
</script>
