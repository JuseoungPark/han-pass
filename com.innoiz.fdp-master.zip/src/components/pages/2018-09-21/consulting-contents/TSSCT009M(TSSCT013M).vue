<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--full">
      <template v-if="contentValue === '전후비교'">
        <div class="-pub-consulting-content__scroll">
          <section class="-pub-consulting-content__pension-content -pub-consulting-content__pension-content--type-1">
            <div class="-pub-pension-compare-graph">
              <div class="-pub-pension-compare-graph__info">
                <div class="-pub-consulting-bar__month-amount--replace">
                  월보험료<span class="-pub-consulting-bar__price-text" :class="{'-pub-consulting-bar__price-text--before': isAfter }">270,010,000</span><span v-if="isAfter" class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--replace">280,010,000</span>
                </div>
              </div>
              <div class="-pub-pension-compare-graph__content -pub-pension-compare-graph__content--no-padding">
                <ul class="-pub-pension-compare-graph__life-container">
                  <li class="-pub-pension-compare-graph__life-item">
                    <h3 class="-pub-pension-compare-graph__life-item-title -pub-pension-compare-graph__life-item-title--green">가족보장</h3>
                    <div class="-pub-pension-compare-graph__life-item-content">
                      <div class="-pub-graph-zone"></div>
                    </div>
                  </li>
                  <li class="-pub-pension-compare-graph__life-item">
                    <h3 class="-pub-pension-compare-graph__life-item-title">생활보장</h3>
                    <div class="-pub-pension-compare-graph__life-item-content">
                      <div class="-pub-graph-zone"></div>
                    </div>
                  </li>
                  <li class="-pub-pension-compare-graph__life-item">
                    <h3 class="-pub-pension-compare-graph__life-item-title -pub-pension-compare-graph__life-item-title--cyan">의료보장</h3>
                    <div class="-pub-pension-compare-graph__life-item-content">
                      <div class="-pub-graph-zone"></div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <article class="-pub-product-card__item -pub-product-card__item--full-items -pub-product-card__item--transparent">
              <div class="-pub-product-card__content-area">
                <ul class="-pub-product-card__column">
                  <li class="-pub-product-card__row-title">
                    제외한 상품 <span class="-pub-consulting-content__pension-info-text--price">{{excludeProductList.length}}</span>건
                  </li>
                  <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
                  <li class="-pub-product-card__add-card" :class="{'-pub-product-card__add-card--point': item.isRecommendProduct }"
                    v-for="(item, index) in excludeProductList" :key="index" @click="addProduct(item, index)">
                    <h2 class="-pub-product-card__title">{{item.name}}</h2>
                    <div class="-pub-product-card__sub-content">
                      <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                        <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                        <span class="-pub-product-card__badge-label" v-else>자사</span>

                        <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                        <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                      </span>
                      <div class="-pub-product-card__month-text normal-letter">
                        <span class="sub-text">월</span> <span class="bold-text">85,350 원</span></div>
                    </div>
                  </li>
                  <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
                  <li class="-pub-product-card__row-title">
                    추가한 상품 <span class="-pub-consulting-content__pension-info-text--price">{{includeProductList.length}}</span>건
                  </li>
                  <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
                  <li class="-pub-product-card__add-card" :class="{'-pub-product-card__add-card--point': item.isRecommendProduct }"
                    v-for="(item, index) in includeProductList" :key="item.name" @click="addProduct(item, index)">
                    <h2 class="-pub-product-card__title">{{item.name}}</h2>
                    <div class="-pub-product-card__sub-content">
                      <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                        <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                        <span class="-pub-product-card__badge-label" v-else>자사</span>

                        <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                        <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                      </span>
                      <div class="-pub-product-card__month-text normal-letter">
                        <span class="sub-text">월</span> <span class="bold-text">85,350 원</span>
                      </div>
                    </div>
                  </li>
                  <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
                </ul>
              </div>
            </article>
          </section>
        </div>
      </template>
      <template v-else-if="contentValue === '지체비용'">
        <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--full">
          <div class="-pub-consulting-content__scroll -pub-consulting-content__scroll--visible-shadow">
            <ul class="-pub-area" data-direction="horizontal" v-if="!isEmpty">
              <li class="-pub-card -pub-card--product-graph" v-for="(product, index) in productList2" :key="index">
                <h1 class="-pub-card__title">
                  <span class="-pub-card__title-text">{{product.name}}</span>
                  <span class="-pub-card__price">{{product.price}}<span class="-pub-card__price-unit">원</span></span>
                  <button class="-pub-card__button">가입설계</button>
                </h1>
                <section class="-pub-card__content">
                  <p class="-pub-card__amount">지체비용(총)<span class="-pub-card__price">558,558,600<span class="-pub-card__price-unit">원</span></span><span class="-pub-card__arrow">▲</span></p>
                  <div class="-pub-card__graph-area">
                    <div class="-pub-graph-zone"></div>
                  </div>
                </section>
              </li>
            </ul>
            <div class="-pub-table-empty-view" v-else>
              <div class="empty-table-content__text">상품컨설팅 단계에서 추가한 상품이 없습니다.</div>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>
<script>
import {
  productList,
  excludeProductList
} from '@/components/mock/TSSCT020M.mock'

import {
  productList2
} from '@/components/mock/TSSCT013M.mock'

export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      isEmpty: true,
      isAfter: true,
      productList: Array.prototype.slice.call(productList),
      productList2: Array.prototype.slice.call(productList2),
      excludeProductList: Array.prototype.slice.call(excludeProductList),
      includeProductList: Array.prototype.slice.call(productList)
    }
  },
  methods: {
    getRangeNumberHTML (numberText = '') {
      return numberText.replace('~', '<br>~')
    },
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    replaceArrowText (numberText = '') {
      return `${numberText.indexOf('-') === -1 ? '▲' : '▼'}${numberText.substring(1, numberText.length)}`
    },
    remove (item, i) { // 상품목록에서 삭제한 상품은 상품추가 및 삭제 리스트로 이동.
      this.productConfigList.push(item)
      this.productList.splice(i, 1)
      this.isVisible = true
    },
    addProduct (item, index) { // 상품추가 및 삭제 리스트의 상품 클릭 시 상품목록으로 이동.
      this.productList.push(item)
      this.productConfigList.splice(index, 1)
    }
  },
  computed: {}
}
</script>
