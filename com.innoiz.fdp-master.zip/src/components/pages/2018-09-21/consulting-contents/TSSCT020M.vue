<template>
  <div class="-pub-consulting-content -pub-consulting-content--bg2 -pub-consulting-content--right-no-padding">
    <div class="-pub-consulting-content__scroll-view -pub-consulting-content__scroll-view--full">
      <div class="-pub-consulting-content__scroll">
        <section class="-pub-consulting-content__pension-content -pub-consulting-content__pension-content--type-1">
          <div class="-pub-pension-compare-graph">
            <div class="-pub-pension-compare-graph__info">
              <div class="-pub-consulting-bar__month-amount--replace">
                월보험료<span class="-pub-consulting-bar__price-text" :class="{'-pub-consulting-bar__price-text--before': isAfter }">270,010,000</span><span v-if="isAfter" class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--replace">270,010,000</span>
              </div>
              <fdp-checkbox style="float:left;" class="-pub-checkbox" isIconCheckbox v-model="isAfter">설계 {{isAfter ? '후' : '전'}}</fdp-checkbox>
            </div>
            <div class="-pub-pension-compare-graph__content">
              <h2 class="-pub-pension-compare-graph__title">예상 월 수령액<span class="-pub-pension-compare-graph__unit">단위:
                  만원</span></h2>
              <div class="-pub-pension-compare-graph__wrap">
                <div class="-pub-pension-compare-graph__container">
                  <!-- 설계 전 제안전 그래프 하나일시 -->
                  <template v-if="!isAfter">
                    <!-- 그래프 항목 타이틀 영역 -->
                    <ul class="-pub-pension-compare-graph__title-area">
                      <li class="-pub-pension-compare-graph__item">
                        <p class="-pub-pension-compare-graph__item-title">제안전</p>
                      </li>
                    </ul>
                    <!-- 그래프 항목 타이틀 영역 end -->
                    <!-- 그래프 항목 내용 영역 -->
                    <ul class="-pub-pension-compare-graph__area -pub-pension-compare-graph__area--single">
                      <li class="-pub-pension-compare-graph__item">
                        <div class="-pub-graph-zone"></div>
                      </li>
                    </ul>
                    <!-- 그래프 항목 내용 영역 end -->
                  </template>
                  <!-- 설계 후 제안전, 후 둘다존재할시 -->
                  <template v-else>
                    <!-- 그래프 항목 타이틀 영역 -->
                    <ul class="-pub-pension-compare-graph__title-area">
                      <li class="-pub-pension-compare-graph__item">
                        <p class="-pub-pension-compare-graph__item-title">제안전</p>
                      </li>
                      <li class="-pub-pension-compare-graph__item">
                        <p class="-pub-pension-compare-graph__item-title">제안후</p>
                      </li>
                    </ul>
                    <!-- 그래프 항목 타이틀 영역 end -->
                    <!-- 그래프 항목 내용 영역 -->
                    <ul class="-pub-pension-compare-graph__area">
                      <li class="-pub-pension-compare-graph__item">
                        <div class="-pub-graph-zone"></div>
                      </li>
                      <li class="-pub-pension-compare-graph__item">
                        <div class="-pub-graph-zone"></div>
                      </li>
                    </ul>
                    <!-- 그래프 항목 내용 영역 end -->
                  </template>

                </div>
                <div class="-pub-pension-compare-graph__description">
                  <p class="-pub-pension-compare-graph__month-total-amount">
                    월 연금액 합계<br>
                    <span class="-pub-pension-compare-graph__price-text">469,000</span>
                    <span v-if="isAfter" class="-pub-pension-compare-graph__price-text -pub-pension-compare-graph__price-text--replace">508,000~508,000</span>
                  </p>
                  <ul class="-pub-pension-category-list">
                    <li class="-pub-pension-category-item">
                      <p class="-pub-pension-category-item__name">개인연금</p>
                      <span class="-pub-pension-compare-graph__price-text">469,000</span>
                      <span v-if="isAfter" class="-pub-pension-compare-graph__price-text -pub-pension-compare-graph__price-text--replace">508,000~508,000</span>
                    </li>
                    <li class="-pub-pension-category-item">
                      <p class="-pub-pension-category-item__name">퇴직연금</p>
                      <span class="-pub-pension-compare-graph__price-text -pub-pension-compare-graph__price-text--single">116</span>
                    </li>
                    <li class="-pub-pension-category-item">
                      <p class="-pub-pension-category-item__name">국민연금</p>
                      <span class="-pub-pension-compare-graph__price-text -pub-pension-compare-graph__price-text--single">212</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <article class="-pub-product-card__item -pub-product-card__item--full-items -pub-product-card__item--transparent">
            <div class="-pub-product-card__content-area">
              <ul class="-pub-product-card__column">
                <li class="-pub-product-card__row-title">
                  제외한 상품 <span class="-pub-consulting-content__pension-info-text--price">{{excludeProductList.length}}</span>건
                </li>
                <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
                <li class="-pub-product-card__add-card" :class="{'-pub-product-card__add-card--point': item.isRecommendProduct}"
                  v-for="(item, index) in excludeProductList" :key="index" @click="addProduct(item, index)">
                  <h2 class="-pub-product-card__title">{{item.name}}</h2>
                  <div class="-pub-product-card__sub-content">
                    <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}">
                        <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                        <span class="-pub-product-card__badge-label" v-else>자사</span>

                        <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                        <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                      </span>
                    <div class="-pub-product-card__month-text normal-letter"><span class="sub-text">월</span> <span class="bold-text">85,350 원</span></div>
                  </div>
                </li>
                <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
                <li class="-pub-product-card__row-title">
                  추가한 상품 <span class="-pub-consulting-content__pension-info-text--price">{{includeProductList.length}}</span>건
                </li>
                <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 -->
                <li class="-pub-product-card__add-card" :class="{'-pub-product-card__add-card--point': item.isRecommendProduct}"
                  v-for="(item, index) in includeProductList" :key="item.name" @click="addProduct(item, index)">
                  <h2 class="-pub-product-card__title">{{item.name}}</h2>
                  <div class="-pub-product-card__sub-content">
                    <span class="-pub-product-card__badge" :class="{'-pub-product-card__badge--blue' : !item.isOtherProduct}"
                        v-if="item.isOtherProduct || item.isRecommendProduct || item.hasProduct">
                        <span class="-pub-product-card__badge-label" v-if="item.isOtherProduct">타사</span>
                        <span class="-pub-product-card__badge-label" v-else>자사</span>

                        <span class="-pub-product-card__badge-label" v-if="item.isRecommendProduct">추천</span>
                        <span class="-pub-product-card__badge-label" v-if="item.hasProduct">보유</span>
                      </span>
                    <div class="-pub-product-card__month-text normal-letter"><span class="sub-text">월</span> <span class="bold-text">85,350 원</span></div>
                  </div>
                </li>
                <!-- 2018/10/30 컨설팅 상품 컨설팅 카드 기획 및 컬러 변경에 따른 마크업 수정 end -->
              </ul>
            </div>
          </article>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
import {
  productList,
  excludeProductList
} from '@/components/mock/TSSCT020M.mock'

export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  watch: {
    isAfter (newVal) {
      if (newVal) {
        this.productList = Array.prototype.slice.call(productList)
        this.excludeProductList = Array.prototype.slice.call(excludeProductList)
        this.includeProductList = Array.prototype.slice.call(productList)
      } else {
        this.productList = []
        this.excludeProductList = []
        this.includeProductList = []
      }
    }
  },
  data () {
    return {
      isAfter: false,
      productList: [],
      excludeProductList: [],
      includeProductList: []
    }
  },
  methods: {
    getRangeNumberHTML (numberText = '') {
      return numberText.replace('~', '<br>~')
    },
    isInteger (numberText = '') {
      return numberText.indexOf('-') === -1
    },
    replaceArrowText (numberText = '') {
      return `${numberText.indexOf('-') === -1 ? '▲' : '▼'}${numberText.substring(1, numberText.length)}`
    }
  }
}
</script>
