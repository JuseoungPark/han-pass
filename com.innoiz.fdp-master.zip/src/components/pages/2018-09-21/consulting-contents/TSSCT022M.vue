<template>
  <section class="-pub-life">
    <aside class="-pub-life__filter">
      <h2 class="-pub-life__title">인생<br>이벤트</h2>
      <div class="-pub-life__event-container">
        <ul class="-pub-life__event-scroll">
          <!-- 아이콘 호출방식 변경 18/10/25 -->
          <li class="-pub-life__event-item" v-for="(event, index) in events" :key="index" :class="[event.icon ? '-pub-life__event-item--ico-' + event.icon : '', {'-pub-life__event-item--checked': event.checked} ]"
            @click="event.checked = !event.checked">{{event.textContent}}</li>
          <!-- / -->
        </ul>
        <button class="-pub-life__event-prev-button"></button>
        <button class="-pub-life__event-next-button"></button>
      </div>
      <template v-if="!currentContent">
        <button type="button" class="-pub-button -pub-button--light -pub-button--reverse -pub-life__graph-toggle-button"
          @click="showGraph = !showGraph">{{showGraph ? '그래프숨기기' : '그래프보기'}}</button>
      </template>
      <template v-else-if="currentContent.title === '노후'">
        <div class="-pub-life__filter-menu-container">
          <div class="-pub-life__filter-menu">
            <p class="-pub-life__filter-menu-title">희망노후생활비 (월)</p>
            <fdp-select class="-pub-select -pub-life__filter-menu-select" v-model="select1.value" :option-list="select1.items"
              placeholder="보험사명"></fdp-select>
          </div>
          <div class="-pub-life__filter-menu">
            <p class="-pub-life__filter-menu-title">어떤 연금을 보유하고 계신가요?</p>
            <fdp-checkbox class="-pub-checkbox -pub-checkbox--button" v-model="item.checked" v-for="(item, index) in checkboxList"
              :key="index">{{item.name}}</fdp-checkbox>
          </div>
        </div>
      </template>
      <template v-else>
        <div style="width: 210px"></div>
      </template>
    </aside>
    <article class="-pub-life__graph-container">
      <dy-tab class="-pub-life__graph-tab" :nav-items="navItems" :is-reverse-index="true" :item-style="setTabPosition"
        :intialIndex="-1" @changeItem="changeComponent"></dy-tab>
      <div class="-pub-life__graph-content">
        <template v-if="!currentContent">
          <div class="-pub-life__graph-area">
            <!-- 템플릿 변경 18/10/25 및 아이콘추가 -->
            <template v-if="showGraph">
              <div class="-pub-life__graph-wrap -pub-life__graph-wrap--graph-1" data-text="지출">
                <img class="-pub-life__graph-img" src="@/assets/img/life/img_red_chart_2.png" alt="그래프 이미지" />
              </div>
            </template>
            <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-1">
              <span class="-pub-life__graph-timeline-symbol"></span>
              <p class="-pub-life__graph-time-text">현재</p>
              <span class="-pub-life__graph-age-text">40세</span>
            </div>
            <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-4 -pub-life__graph-timeline-item--no-line">
              <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-5">
                <a class="-pub-life__group-item-remove-button"></a>
              </div>
              <span class="-pub-life__graph-timeline-symbol"></span>
              <p class="-pub-life__graph-time-text">주택구입</p>
            </div>
            <div class="-pub-life__graph-timeline-item -pub-life__graph-timeline-item--type-6 -pub-life__graph-timeline-item--no-line">
              <div class="-pub-life__graph-timeline-icon -pub-life__graph-timeline-icon--ico-7">
                <a class="-pub-life__group-item-remove-button"></a>
              </div>
              <span class="-pub-life__graph-timeline-symbol"></span>
              <p class="-pub-life__graph-time-text">여가취미</p>
            </div>
            <!-- / -->
          </div>
        </template>
        <template v-else>
          <component :is="currentContent.component" :pensions="checkboxList" :current-living-price="select1.value"></component>
        </template>
        <a class="-pub-life__subscript-trigger">
          <img src="@/assets/img/life/btn-home-subscription.png" alt="제안스크립트 보기" />
        </a>
      </div>
    </article>
    <div class="-pub-life__bottom-bar">
      <h2 class="-pub-life__title">가족 정보</h2>
      <div class="-pub-life__group-container">
        <ul class="-pub-life__group-scroll">
          <li class="-pub-life__group-item">
            <div class="-pub-life__group-item-button -pub-button -pub-button--light -pub-page-header__button -pub-page-header__button--icon"
              @click="showConfigLayer = !showConfigLayer">
              <img src="@/assets/img/ico-lift-edit.png" alt="">
              <span>본인(100)</span>
            </div>
            <div class="-pub-tooltip-layer -pub-tooltip-layer--config" left v-show="showConfigLayer">
              <a class="-pub-button--close-light -pub-tooltip-layer__close-button" @click="showConfigLayer = !showConfigLayer"></a>
              <h3 class="-pub-tooltip-layer__title">본인 나이</h3>
              <div class="-pub-tooltip-layer__content">
                <fdp-text-field class="-pub-text-field -pub-tooltip-layer__age-config-field normal-letter" v-model="age"></fdp-text-field>
                <span class="bold-text -pub-tooltip-layer__age-config-label">세</span>
                <button class="-pub-button -pub-button--light -pub-life__create-button">확인</button>
              </div>
            </div>
          </li>
          <li class="-pub-life__group-item" v-for="(child, index) in childs" :key="index">
            <div class="-pub-life__group-item-button -pub-button -pub-button--light -pub-page-header__button -pub-page-header__button--icon"
              @click="child.showConfigLayer = !child.showConfigLayer">
              <img src="@/assets/img/ico-lift-edit.png" alt="">
              <span>{{child.type}}({{child.age}})</span>
            </div>
            <a class="-pub-life__group-item-remove-button"></a>
            <div class="-pub-tooltip-layer -pub-tooltip-layer--config" left v-show="child.showConfigLayer">
              <a class="-pub-button--close-light -pub-tooltip-layer__close-button" @click="child.showConfigLayer = !child.showConfigLayer"></a>
              <h3 class="-pub-tooltip-layer__title">{{child.type}} 나이</h3>
              <div class="-pub-tooltip-layer__content">
                <fdp-text-field class="-pub-text-field -pub-tooltip-layer__age-config-field normal-letter" v-model="child.age"></fdp-text-field>
                <span class="bold-text -pub-tooltip-layer__age-config-label">세</span>
                <button class="-pub-button -pub-button--light -pub-life__create-button">확인</button>
              </div>
            </div>
          </li>
          <li class="-pub-life__group-item">
            <div class="-pub-life__group-item-button -pub-button -pub-button--light -pub-page-header__button -pub-page-header__button--icon"
              @click="showCreateLayer = !showCreateLayer">
              <img src="@/assets/img/ico-life-plus-gray.png" alt="">
              <span>가족추가</span>
            </div>
            <div class="-pub-tooltip-layer__wrap">
              <div class="-pub-tooltip-layer -pub-tooltip-layer--add-config" left v-show="showCreateLayer">
                <a class="-pub-button--close-light -pub-tooltip-layer__close-button" @click="showCreateLayer = !showCreateLayer"></a>
                <h3 class="-pub-tooltip-layer__title">가족 추가</h3>
                <div class="-pub-tooltip-layer__content">
                  <label class="-pub-radio-button">
                    <input type="radio" value="배우자" v-model="picked">
                    <div class="-pub-button -pub-button--light -pub-radio-style">배우자</div>
                  </label><label class="-pub-radio-button">
                    <input type="radio" value="자녀" v-model="picked">
                    <div class="-pub-button -pub-button--light -pub-radio-style">자녀</div>
                  </label><button class="-pub-button -pub-button--light -pub-life__create-button">확인</button>
                </div>
              </div>
            </div>
          </li>
          <Li class="-pub-life__group-item -pub-life__group-item--radius">
            <div class="-pub-life__group-item-button">
              <img class="-pub-life__group-item-icon" src="@/assets/img/ico-life-arrow.png" />
              <span>가족 불러오기</span>
            </div>
          </Li>
          <Li class="-pub-life__group-item -pub-life__group-item--radius">
            <div class="-pub-life__group-item-button">
              <img class="-pub-life__group-item-icon" src="@/assets/img/ico-life-refreshment-gray.png" />
              <span>정보 되돌리기</span>
            </div>
          </Li>
        </ul>
      </div>
      <a class="-pub-button -pub-button--light -pub-page-header__button -pub-page-header__button--icon">
        <img src="@/assets/img/life/ico-life-refresh-blue.png" alt="초기화">
        <span>초기화</span>
      </a>
      <a class="-pub-button -pub-button--light -pub-page-header__button -pub-page-header__button--no-icon" :disabled="!showGraph && !currentContent">
        <span>저장하기</span>
      </a>
      <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--type-2" top :menu-list="menuListSample">
        <div class="-pub-button -pub-button--small -pub-button--tooltip">
          <span class="-pub-symbol--menu"></span>
        </div>
      </fdp-tooltip-menu>
    </div>
  </section>
</template>
<script>
import DyTab from '@/components/pages/2018-08-31/dynamic-tab'
import TSSCT023M from '@/components/pages/2018-09-28/TSSCT023M'
import TSSCT024M from '@/components/pages/2018-10-26/TSSCT024M'
import TSSCT025M from '@/components/pages/2018-10-26/TSSCT025M'
import TSSCT026M from '@/components/pages/2018-10-26/TSSCT026M'
import {
  events
} from '@/components/mock/TSSCT022M.mock'
export default {
  components: {
    DyTab,
    TSSCT023M,
    TSSCT024M,
    TSSCT025M,
    TSSCT026M
  },
  data () {
    return {
      events: Array.prototype.slice.call(events),
      picked: '배우자',
      age: '100',
      showCreateLayer: false,
      showConfigLayer: false,
      showGraph: true,
      childs: [{
        type: '자녀1',
        age: '100',
        showConfigLayer: false
      },
      {
        type: '자녀2',
        age: '100',
        showConfigLayer: false
      },
      {
        type: '배우자',
        age: '100',
        showConfigLayer: false
      }
      ],
      navItems: [{
        title: '노후',
        component: 'TSSCT023M'
      },
      {
        title: '의료',
        component: 'TSSCT024M'
      },
      {
        title: '가족',
        component: 'TSSCT025M'
      },
      {
        title: '생활',
        component: 'TSSCT026M'
      }
      ],
      menuListSample: [{
        label: '인쇄/이메일',
        key: 'printEmail'
      }],
      currentContent: null,
      select1: {
        value: {
          key: '1',
          label: '145만원 이하'
        },
        items: [{
          key: '1',
          label: '145만원 이하'
        },
        {
          key: '2',
          label: '145~200만원'
        },
        {
          key: '3',
          label: '200~300만원'
        },
        {
          key: '4',
          label: '300~400만원'
        },
        {
          key: '5',
          label: '400만원 초과'
        }
        ]
      },
      checkboxList: [{
        checked: false,
        name: '국민연금'
      },
      {
        checked: false,
        name: '퇴직연금'
      },
      {
        checked: false,
        name: '개인연금'
      }
      ]
    }
  },
  methods: {
    changeComponent (component) {
      this.currentContent = component
    },
    setTabPosition (index) {
      const itemPaddings = [
        60, 83, 81, 79
      ]
      const addVal = (index - 1) * 5
      return {
        top: `${index * (index === 1 ? 120 : 130 + addVal)}px`,
        'padding-top': `${itemPaddings[index] || 0}px`
      }
    }
  }
}
</script>
