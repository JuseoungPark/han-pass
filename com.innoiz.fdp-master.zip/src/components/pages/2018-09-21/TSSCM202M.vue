<template>
    <section class="-pub-customer-list">
        <!-- 페이지 헤더 영역 -->
        <div class="-pub-customer-list__header">
            <div class="-pub-customer-list__title-wrap">
                <h1 class="-pub-customer-list__title">
                <span class="-pub-title__text">{{title}}</span>
                </h1>
                <fdp-tooltip-button class="-pub-tooltip">
                    <template slot="activator">
                        <img class="-pub-tooltip__icon" src="@/assets/img/components/ico_info_gray.png" alt="툴팁" />
                    </template>
                    <template slot="content">
                        <div class="-pub-customer-tooltip-main__setting">
                            <div class="tit">고객 카드 설정하는 방법</div>
                            <ul>
                                <li class="-pub-customer-tooltip-main__setting-item">
                                    <div class="subtit">고객 카드 순서 변경</div>
                                    <div class="dec">카드를 누른 상태에서 원하는 위치로 옮기세요. </div>
                                    <div class="info-img"><img src="@/assets/img/customer/customer_tooltip_img_1.png" alt="고객 카드 순서 변경"></div>
                                </li>
                                <li class="-pub-customer-tooltip-main__setting-item">
                                    <div class="subtit">새로운 고객 카드 추가</div>
                                    <div class="dec">화면 가장 오른쪽에 있는 카드 추가 버튼을 누른 후,<br>원하는 카드를 선택하세요. (최대 5개 추가 가능)</div>
                                    <div class="info-img"><img src="@/assets/img/customer/customer_tooltip_img_2.png" alt="새로운 고객 카드 추가"></div>
                                </li>
                                <li class="-pub-customer-tooltip-main__setting-item">
                                    <div class="subtit">고객 카드 삭제</div>
                                    <div class="dec">카드의 우상단에 있는 X버튼을 누르세요.</div>
                                    <div class="info-img"><img src="@/assets/img/customer/customer_tooltip_img_3.png" alt="고객 카드 삭제"></div>
                                </li>
                            </ul>
                        </div>
                    </template>
                </fdp-tooltip-button>
            </div>
            <ul class="-pub-header__menu">
                <!-- 고객등록 동의 표시영역 -->
                <li class="-pub-header__item">
                <span class="-pub-customer-list__header-button">
                    <img class="-pub-customer-list__header-button-icon" src="@/assets/img/customer/ico-customer.png" alt="정보">
                    <span class="-pub-label__text">고객등록동의</span>
                </span>
                </li>
                <!-- 고객등록 동의 표시영역 end -->
            </ul>
        </div>
        <!-- 페이지 헤더 영역 end -->
        <div class="-pub-page-container">
            <div class="-pub-customer-main">
                <!-- 고객메뉴 첫화면 start-->
                <div class=" -pub-customer-main__contents">
                    <transition-group name="list-complete">
                    <div v-for="(card, index) in cardShowList" :key="card.title" class="-pub-customer-main__contents--card-list">
                        <template v-if="card.cardType === 'Add'">
                            <!-- 카드추가 버튼 start -->
                            <div v-if="newCard===false" class="-pub-customer-main__contents--card-add" :key="'addBtn'">
                                <button type="button" class="-pub-button -pub-button__add-card" @click="addNewCard">
                                    <span>카드추가</span>
                                </button>
                            </div>
                            <!-- 카드추가 버튼 end -->
                            <!-- 카드추가 start -->
                            <div v-else class="-pub-customer-main__contents--card-add-list" :key="'addBtnDetail'">
                                <div class="-pub-dec_info-header">
                                    <span class="-pub-title">카드 추가</span>
                                    <a href="#" class="-pub-button-close" @click="closeNewCard">창닫기</a>
                                    <span class="-pub-tit_info">홈에 추가할 고객 분류를 선택하세요.<br>(최대 5개까지 추가 가능)</span>
                                </div>
                                <div class="-pub-card-add-form">
                                    <!--  카드 추가 입력 폼 -->
                                    <transition-group name="list-complete">
                                    <ul v-for="(card, index3) in cardList" :key="index3"  @click="closeNewCard">
                                        <li class="-pub-create-account-form__item" @click="addCard(card, index3)">
                                            <span>{{card.title}}</span>
                                        </li>
                                    </ul>
                                    </transition-group>
                                    <!--// 카드 추가 입력 폼 end -->
                                </div>
                            </div>
                            <!-- 카드추가 end -->
                        </template>
                        <template v-else>
                            <div class="-pub-customer-main__contents--header">
                                <span class="-pub-title">{{card.title}}</span>
                                <a href="#" class="-pub-button-close" @click="deleteCard(card, index)">{{card.closeButton}}</a>
                                <div class="-pub-total">
                                    <span class="-pub-total-num">{{card.numberOfmember}}</span><span class="-pub-total-txt">{{card.unit}}</span>
                                </div>
                            </div>
                            <!-- 카드유형 A  start -->
                            <div v-if="card.cardType === 'A'" class="-pub-customer-main__contents--list-A">
                                <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="sampleListData"
                                    :list-height="850" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
                                    <template slot="emptyView">
                                        <div class="empty-table-content">
                                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                            <div class="empty-table-content__text">{{card.emptyMember}}</div>
                                        </div>
                                    </template>
                                    <template slot="default" slot-scope="props">
                                        <div class="-fdp-list-page__item -pub-list-page__item">
                                            <span class="-pub-list-page__item-tit">{{props.item.title}}</span>
                                            <span class="-pub-list-page__item-etc">{{props.item.etc}}</span>
                                        </div>
                                    </template>
                                </fdp-list>
                            </div>
                            <!-- 카드유형 A end -->
                            <!-- 카드유형 B  start -->
                            <div v-if="card.cardType === 'B'" class="-pub-customer-main__contents--list-B">
                                <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="sampleListData"
                                    :list-height="850" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
                                    <template slot="emptyView">
                                        <div class="empty-table-content">
                                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                            <div class="empty-table-content__text">대상 고객이 없습니다.</div>
                                        </div>
                                    </template>
                                    <template slot="default" slot-scope="props">
                                        <div class="-fdp-list-page__item -pub-list-page__item">
                                            <div class="-pub-list-page__item_row">
                                                <span class="-pub-list-page__item-name">{{props.item.name}}</span>
                                                <span class="-pub-list-page__item-birthday">{{props.item.birthday}}</span>
                                            </div>
                                            <div class="-pub-list-page__item_row"><span class="-pub-list-page__item-date">({{props.item.date}})</span><span
                                                    class="-pub-list-page__item-product">{{props.item.product}}</span></div>
                                        </div>
                                    </template>
                                </fdp-list>
                            </div>
                            <!-- 카드유형 B end -->
                            <!-- 카드유형 C  start -->
                            <div v-if="card.cardType === 'C'" class="-pub-customer-main__contents--list-C">
                                <fdp-list class="-fdp-list-page__list -pub-list-page__list" :list-data="mockData"
                                    :list-height="850" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
                                    <template slot="emptyView">
                                        <div class="empty-table-content">
                                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                            <div class="empty-table-content__text">최근 5일내 대상 고객이 없습니다.</div>
                                        </div>
                                    </template>
                                    <template slot="default" slot-scope="props">
                                        <div class="-pub-accordion-left-line">
                                            <div class="-pub-accordion-container -pub-accordion-container--day">
                                                <div class="-pub-accordion-line">
                                                    <span class="-pub-accordion-line__text -pub-accordion-line__text--day">{{props.item.day}}</span>
                                                </div>
                                                <div class="-pub-accordion--empty"></div>
                                            </div>
                                            <div class="-pub-accordion-container" v-for=" (mock, index2) in props.item.data" :key="'b' + index2">
                                                <div class="-pub-accordion">
                                                    <div class="-pub-accordion__title">
                                                        <div class="-pub-accordion__text -pub-accordion__text--type">
                                                            <span class="-pub-accordion__text--type-name">{{mock.name}}</span>
                                                            <span class="-pub-accordion__text--type-birthday">{{mock.birthday}}</span>
                                                            <!-- <span class="-pub-accordion__text--type-gender">{{mock.gender}}</span> -->
                                                        </div>
                                                        <div class="-pub-accordion__text -pub-accordion__text--item-etc-underline">{{mock.dec}}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                </fdp-list>
                            </div>
                            <!-- 카드유형 C end -->
                        </template>
                    </div>
                    </transition-group>
                </div>
                <!-- 고객메뉴 첫화면 end-->
            </div>
            <!-- draw 콘텐츠 영역 -->
            <fdp-bottom-drawer >
                <div slot="drawerHeader">
                <!-- 페이지 서브 메뉴 영역 -->
                <customer-submenu :sub-menus="subMenus" :intialIndex="getIndex" @changeItem="changeMenu"></customer-submenu>
                </div>
                <!-- 페이지 서브 메뉴 영역 end -->
                <div slot="drawerBody" style="height: 100%">
                    <div class="-pub-page-container__wrapper">
                    </div>
                </div>
            </fdp-bottom-drawer>
        </div>
    </section>
</template>
<script>
import {
  subMenus
} from '@/components/mock/customer-list.mock'

import CustomerSubmenu from '@/components/pages/2018-09-07/customer.submenu'

import TSSPS110M from '@/components/pages/2018-09-28/TSSPS110M'
import TSSCM203M from '@/components/pages/2018-08-22/TSSCM203M'
import TSSCM322M from '@/components/pages/2018-08-22/TSSCM322M'
import TSSCM324M from '@/components/pages/2018-08-22/TSSCM324M'
import TSSCM304M from '@/components/pages/2018-08-22/TSSCM304M'
import TSSCM132M from '@/components/pages/2018-09-07/TSSCM132M'
import TSSCM217M from '@/components/pages/2018-09-07/TSSCM217M'
import TSSCM216M from '@/components/pages/2018-09-14/TSSCM216M'
import TSSCM317M from '@/components/pages/2018-09-14/TSSCM317M'
import TSSCM310D from '@/components/pages/2018-09-21/TSSCM310D'

export default {
  components: {
    CustomerSubmenu,
    TSSPS110M,
    TSSCM203M,
    TSSCM322M,
    TSSCM304M,
    TSSCM324M,
    TSSCM132M,
    TSSCM217M,
    TSSCM216M,
    TSSCM317M,
    TSSCM310D
  },
  data () {
    return {
      title: '고객',
      isLoadingStatus: false,
      currentMenu: {},
      newCard: false,
      subMenus: Array.prototype.slice.call(subMenus),
      cardList: [
        {
          title: '내 그룹',
          closeButton: '창닫기',
          numberOfmember: '5',
          unit: '개',
          cardType: 'A',
          emptyMember: '내그룹이 없습니다.'
        },
        {
          title: 'VIP서비스신청',
          closeButton: '창닫기',
          numberOfmember: '6',
          unit: '명',
          cardType: 'B'
        },
        {
          title: '미승인 고객',
          closeButton: '창닫기',
          numberOfmember: '3',
          unit: '명',
          cardType: 'C'
        },
        {
          title: '관심고객',
          closeButton: '창닫기',
          numberOfmember: '2',
          unit: '명',
          cardType: 'B'
        },
        {
          title: '프리미엄 고객사랑 서비스',
          closeButton: '창닫기',
          numberOfmember: '7',
          unit: '명',
          cardType: 'B'
        },
        {
          title: '터치한 고객',
          closeButton: '창닫기',
          numberOfmember: '65',
          unit: '명',
          cardType: 'C'
        },
        {
          title: '수금인수고객',
          closeButton: '창닫기',
          numberOfmember: '22',
          unit: '명',
          cardType: 'B'
        },
        {
          title: '정보활용동의현황',
          closeButton: '창닫기',
          numberOfmember: '5',
          unit: '명',
          cardType: 'C'
        },
        {
          title: '스마트 신인 고객사랑 서비스',
          closeButton: '창닫기',
          numberOfmember: '7',
          unit: '명',
          cardType: 'B'
        },
        {
          title: '군제휴 DB 고객',
          closeButton: '창닫기',
          numberOfmember: '7',
          unit: '명',
          cardType: 'B'
        }
      ],
      cardShowList: [
        {
          title: '캠페인 고객',
          closeButton: '창닫기',
          numberOfmember: '45',
          unit: '명',
          cardType: 'A',
          emptyMember: '진행중인 캠페인이 없습니다.'
        },
        {
          title: '오늘 이벤트 고객',
          closeButton: '창닫기',
          numberOfmember: '26',
          unit: '명',
          cardType: 'A',
          emptyMember: '오늘 이벤트가 있는\n 고객이 없습니다.'
        },
        {
          title: '고객접촉정보',
          closeButton: '창닫기',
          numberOfmember: '65',
          unit: '명',
          cardType: 'C'
        },
        {
          title: '삭제예정고객',
          closeButton: '창닫기',
          numberOfmember: '6',
          unit: '명',
          cardType: 'C'
        },
        {
          title: 'Add',
          closeButton: '',
          numberOfmember: '',
          unit: '',
          cardType: 'Add'
        }
      ],
      sampleListData: [
        {
          title: '6월 소외 고객 비대면 터치 캠페인',
          name: '김바다',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        },
        {
          title: '10년이상 유지고객(장기미거래) 올터치',
          name: '김바다',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        },
        {
          title: '사차우량고객리스트',
          name: '김혜림',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        },
        {
          title: '6월 소외 고객 비대면 터치 캠페인',
          name: '김바다',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        },
        {
          title: '10년이상 유지고객(장기미거래) 올터치',
          name: '김바다',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        },
        {
          title: '사차우량고객리스트',
          name: '김혜림',
          birthday: '1967-02-14',
          gender: '여',
          etc: '배현숙 외 22명',
          date: '2018-08-11',
          dec: '감약해약처리 문의',
          product: '② 댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸댕기머리려샴푸'
        }
      ],
      mockData: [
        {
          day: '오늘',
          data: [{
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          },
          {
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          }]
        },
        {
          day: '1일전',
          data: [{
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          }
          ]
        },
        {
          day: '2일전',
          data: [{
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          },
          {
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          },
          {
            expand: false,
            name: '손주연',
            birthday: '1967-02-14',
            gender: '여',
            dec: '필수동의만료'
          }
          ]
        }
      ],
      emptyData: []
    }
  },
  methods: {
    onSizeChange (size) {},
    changeMenu (currentMenu) {
      console.log(currentMenu)
      this.currentMenu = currentMenu
    },
    getIndex (item, index) {
      return item.active
    },
    addNewCard () {
      this.newCard = true
    },
    closeNewCard () {
      this.newCard = false
    },
    deleteCard (card, idx) {
      this.cardList.push(card)
      this.cardShowList.splice(idx, 1)
    },
    addCard (card, idx) {
      if (this.cardShowList.length >= 6) {
        console.log('## 5개 이상 추가 안됌')
      } else {
        this.cardShowList.splice(this.cardShowList.length - 1, 0, card)
        this.cardList.splice(idx, 1)
      }
    },
    loadingData () {

    }
  },
  computed: {}
}
</script>
<style>
.-pub-customer-main__contents--card-list {
  transition: all 1s;
  display: inline-block;
}
.list-complete-item {
  transition: all 1s;
  display: inline-block;
  margin-right: 10px;
}
.list-complete-enter, .list-complete-leave-to
/* .list-complete-leave-active below version 2.1.8 */ {
  opacity: 0;
  /* transform: translateY(30px); */
}
.list-complete-leave-active {
  position: absolute;
}
</style>
