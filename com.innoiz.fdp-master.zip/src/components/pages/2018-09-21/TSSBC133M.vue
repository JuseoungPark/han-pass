<template>
    <section class="-pub-system-setting-notification">
        <!-- 알림 기능 off시 -pub-noit-disabled 추가 -->
        <ul class="-pub-noti__list-wrap" :class="{'-pub-noit-disabled':!toggle1}">
            <li class="-pub-noti__list">
                <label class="-pub-noti-item">알림 기능을 사용합니다.</label>
                <fdp-toggle class="-pub-toggle" v-model="toggle1"></fdp-toggle>
            </li>
            <li class="-pub-noti__list">
                <label class="-pub-noti-item">알림 유지 기간</label>
                <fdp-select class="-pub-select -pub-select--purple" v-model="selectData" :option-list="selectList" :disabled="!toggle1"></fdp-select>
                <span class="-pub-noti-span">일이 지난 알림은 알림목록에서 사라집니다.</span>
            </li>
            <li class="-pub-noti__list">
                <label class="-pub-noti-item">고객 대면 중 알림 끄기 </label>
                <fdp-toggle class="-pub-toggle" v-model="toggle2"></fdp-toggle>
            </li>
            <li class="-pub-noti__list">
                <label class="-pub-noti-item">방해금지 시간대 설정</label>
                <fdp-toggle class="-pub-toggle" v-model="toggle3"></fdp-toggle>
                <div class="-pub-noti-time-wrap">
                    <fdp-time-picker format="A hh:mm" hide-clear-button></fdp-time-picker><span class="-pub__Tilde">~</span><fdp-time-picker format="A hh:mm" hide-clear-button></fdp-time-picker>
                </div>
            </li>
        </ul>
    </section>
</template>
<script>
export default {
  data () {
    return {
      toggle1: true,
      toggle2: true,
      toggle3: true,
      selectData: {label: '3', key: '3'},
      selectList: [{
        label: '3',
        key: '1'
      },
      {
        label: '7',
        key: '2'
      },
      {
        label: '30',
        key: '3'
      }]
    }
  },
  watch: {
    toggle1: function () {
      if (!this.toggle1) {
        this.toggle2 = false
        this.toggle3 = false
      } else {
        this.toggle2 = true
        this.toggle3 = true
      }
    }
  }
}
</script>
