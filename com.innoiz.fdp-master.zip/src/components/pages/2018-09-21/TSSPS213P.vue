<template>
    <!-- 진행현황 팝업 start -->
    <fdp-popup class="-pub-popup" v-model="showPopup" title="진행현황" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -popup-scroll">
                <div class="-pub-popup-tracking-progress -pub-timeline">
                    <fdp-list class="-fdp-list-page__list" :list-data="sampleListData" :list-height="878">
                        <template slot="default" slot-scope="props">
                            <div class="-fdp-list-page__item">
                                <div class="-pub-accordion-container">
                                    <div class="-pub-accordion-line" :class="[props.item.isDone ? '-pub-timeline-complete' : '']">
                                        <span class="-pub-accordion-line__text" :class="[props.item.isStep ? '-pub-bold' : '']">{{props.item.data1}}</span>
                                    </div>
                                    <div class="-pub-accordion" :class="[props.item.isStep ? '-pub-accordion--step' : '', props.item.expand ? '-pub-accordion--expanded' : '']">
                                        <div class="-pub-accordion__title">
                                            <div class="-pub-accordion__text -pub-accordion__text--date">{{props.item.date}}</div>
                                            <div class="-pub-accordion__text -pub-accordion__text--status">{{props.item.status}}</div>
                                            <div class="-pub-accordion__text -pub-accordion__text--data -pub-table-colmn__single-line--ellipsis">{{props.item.data2}}</div>
                                            <a class="-pub-accordion__trigger" v-if="props.item.expandable" @click="props.item.expand = !props.item.expand"><img src="@/assets/img/customer/ico-arrow-down-black.png" alt=""></a>
                                        </div>
                                        <div class="-pub-accordion__content">
                                            <div class="-pub-section">
                                                <div class="-pub-accordion__text">{{props.item.data3}}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </fdp-list>
                </div>
                <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
                    <div class="-pub-bottom-nav">
                        <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                            <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                        </div>
                    </div>
                </fdp-bottom-bar>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
    <!-- 진행현황 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      sampleListData: [{
        data1: '청약접수',
        isStep: true,
        isDone: true,
        date: '2017-16-29',
        status: '',
        data2: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상',
        expandable: true,
        expand: false,
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '입금',
        isStep: true,
        isDone: true,
        date: '2017-16-29',
        status: '',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '신계약심사',
        isStep: true,
        isDone: true,
        status: '승인',
        date: '2017-16-29',
        data2: '상세내용',
        expandable: false,
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '미결1차',
        isDone: true,
        status: '',
        date: '2017-16-29',
        data2: '상세내용',
        expandable: false,
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '진단신청\n(주피)',
        isDone: true,
        status: '완료',
        date: '2017-16-29',
        data2: '상세내용',
        expandable: true,
        expand: true,
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '적부',
        isStep: true,
        isDone: true,
        status: '해당없음',
        date: '-',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '발췌',
        expandable: false,
        isDone: false,
        status: '완료',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '조사',
        expandable: false,
        isDone: false,
        status: '완료',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '결과송부',
        expandable: false,
        isDone: false,
        status: '완료',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '최종결과',
        isStep: true,
        isDone: false,
        status: '',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '서비스콜',
        isStep: true,
        isDone: false,
        status: '',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      },
      {
        data1: '증권발행',
        isStep: true,
        isDone: false,
        status: '',
        date: '2017-16-29',
        data2: '상세내용',
        data3: '상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상\n' +
                            '세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용상세내용'
      }]
    }
  }
}
</script>
