<template>
    <section>
        <div class="-pub-searched__category">
            <span class="-pub-tit">상품 <strong>{{products.length}}</strong></span>
            <div class="-pub-searched__category-goods">
                <div class="-pub-search-all__scroll---horizon" style="width: 3000px;" v-if="true">
                    <div class="-pub-searched-goods"  v-for="(product, i) in products" :key="i">
                        <div class="-pub-goods-tit">
                            <span v-html="getHighlightTitle(product.title)"></span>
                            <img class="-pub-short-cut" src="@/assets/img/btn_short_cut_purple.png" alt="바로가기">
                        </div>
                        <span class="-pub-goods-desc1">{{product.desc1}}</span>
                        <span class="-pub-goods-desc2">{{product.desc2}}</span>
                        <span class="-pub-goods-desc3">{{product.desc3}}</span>
                        <div class="-pub-leaflet-wrap">
                            <div class="-pub-leaflet">
                                <span>{{product.leaf1}}</span>
                            </div>
                            <div class="-pub-leaflet">
                                <span>{{product.leaf2}}</span>
                            </div>
                            <div class="-pub-leaflet">
                                <span>{{product.leaf3}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  props: {
    searchKeyword: {
      type: String,
      default: ''
    },
    products: {
      type: [Array, Object],
      default: () => []
    }
  },
  data () {
    return {

    }
  },
  methods: {
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')

      return val.replace(regex, '<span class="-pub-search-color">$1</span>')
    }
  }
}
</script>
