<template>
    <section>
        <div class="-pub-searched__category">
            <span class="-pub-tit">고객 <strong>{{members.length}}</strong></span>
            <div class="-pub-searched__category-customer">
                <div class="-pub-search-all__scroll---horizon" :style="styles" v-if="true">
                    <article class="-pub-name-ui" v-for="(member, i) in members" :key="i">
                        <a class="-pub-name-ui__close-button"><img src="@/assets/img/btn_close_dark.png" alt="name-ui 팝업 닫기"  @click="remove(i)"></a>
                        <div class="-pub-name-ui__info">
                            <div class="-pub-name-ui-card__title -pub-container">
                                <h2 class="-pub-container__item"><span v-html="getHighlightTitle(member.name)"></span></h2>
                                <div class="-pub-container__item -pub-name-ui-card__info">
                                    <span>{{member.phone}}</span><br>
                                    <span class="-pub-name-ui-card__title--grey">{{member.socialNumberFirst}} (보험
                                        {{member.age}}세)
                                        {{member.gender}}</span>
                                </div>
                                <div class="-pub-container -pub-container__item--right">
                                    <a class="-pub-container__item -pub-round-button">
                                        <img src="@/assets/img/name-ui/btn-name-meetinghome-nor.png" alt="customer info">
                                    </a>
                                    <a class="-pub-container__item -pub-round-button">
                                        <img src="@/assets/img/name-ui/btn-name-customer-nor.png" alt="customer info">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <ul class="-pub-name-ui-tab">
                            <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'message' }"
                                @click="currMenu = 'message'">
                                <img src="@/assets/img/name-ui/ico_tab_message.png" alt="calendar today">
                            </li>
                            <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'memo'}"
                                @click="currMenu = 'memo'">
                                <img src="@/assets/img/name-ui/ico-tab-memo.png" alt="Message">
                            </li>
                        </ul>
                    </article>
                </div>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  props: {
    searchKeyword: {
      type: String,
      default: ''
    },
    members: {
      type: [Array, Object],
      default: () => []

    }
  },
  data () {
    return {
      currMenu: ''
    }
  },
  computed: {
    styles () {
      return 'width:' + this.members.length * 730 + 'px;'
    }
  },
  methods: {
    remove: function (i) {
      this.members.splice(i, 1)
    },
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')
      return val.replace(regex, '<span class="-pub-search-color">$1</span>')
    }
  }
}
</script>
