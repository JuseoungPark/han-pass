<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="내그룹 편집" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 세대조정 Start -->
            <div class="-pub-popup__edit-my-group">
                <div class="-pub-popup__content-header">
                    <dl>
                        <dt>그룹명</dt>
                        <dd>
                            <fdp-validator name="name1" v-model="vipGroupName" :rules="'required'">
                                <fdp-text-field v-model="vipGroupName" style="width: 640px;"></fdp-text-field>
                            </fdp-validator>
                        </dd>
                    </dl>
                </div>
                <div class="-pub-popup__content-body">
                    <!-- 왼쪽 영역 start -->
                    <div class="-pub-popup-content__left">
                        <div class="-pub-popup-content__tit">전체고객</div>
                        <!-- 페이지 조회 input, button 검색 영역  -->
                        <div class="-pub-filter-menu">
                            <div class="-pub-filter-menu__item--right">
                                <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple"
                                    placeholder="고객명" v-model="searchKeywordOrigin" clearable></fdp-text-field>
                                <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                                    <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                                </button>
                            </div>
                            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총{{mockData.length}}명</div>
                        </div>
                        <!-- 페이지 조회 input, button 검색 영역 end -->
                        <fdp-infinite class="-pub-table" v-model="selectOrigin" multi-select :items="mockData" :table-body-height="530" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="isSelectAllOrigin" @input="selectAllItemsOrginFunc(isSelectAllOrigin)"></fdp-checkbox>
                                    </th>
                                    <th class="-pub-table-column" style="width: 122px;">고객명</th>
                                    <th class="-pub-table-column" style="width: 170px;">생년월일</th>
                                    <th class="-pub-table-column" style="width: 72px;">성별</th>
                                    <th class="-pub-table-column" style="width: 130px;">고객구분</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="selectOrigin" :value="props.item"></fdp-checkbox>
                                <td class="-pub-table-column -pub-table-column--name" style="width: 122px;">{{props.item.name}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 170px;">{{props.item.date}}</td>
                                <td class="-pub-table-column" style="width: 72px;">{{props.item.gander}}</td>
                                <td class="-pub-table-column" style="width: 130px;">{{props.item.data4}}</td>
                            </template>
                            <!-- no data 화면 -->
                            <template slot="emptyView">
                                <div class="empty-table-content">
                                    <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                    </div>
                    <!--// 왼쪽 영역 end -->
                    <!-- 가운데 버튼 영역 start -->
                    <div class="-pub-popup-content__center">
                        <div class="-pub-popup-content__center--button">
                            <button type="button" class="-pub-popup-button__left-arrow" @click="moveAddMember"></button>
                            <button type="button" class="-pub-popup-button__right-arrow" @click="moveOrigin"></button>
                        </div>
                    </div>
                    <!--// 가운데 버튼 영역 end -->
                    <!-- 오른쪽 영역 start -->
                    <div class="-pub-popup-content__right">
                        <div class="-pub-popup-content__tit">그룹에 추가된 고객</div>
                        <!-- 페이지 조회 input, button 검색 영역  -->
                        <div class="-pub-filter-menu">
                            <div class="-pub-filter-menu__item--right">
                                <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple"
                                    placeholder="고객명" v-model="searchKeywordAddMember" clearable style="width: 286px; height: 56px;"></fdp-text-field>
                                <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                                    <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon"
                                        alt="조회">조회
                                </button>
                            </div>
                            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총{{mockAddMember.length}}명</div>
                        </div>
                        <!-- 페이지 조회 input, button 검색 영역 end -->
                        <fdp-infinite class="-pub-table" v-model="selectAddMember" multi-select :items="mockAddMember" :table-body-height="530" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">
                                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="isSelectAllAddMember" @input="selectAllItemsAddMemberFunc(isSelectAllAddMember)"></fdp-checkbox>
                                    </th>
                                    <th class="-pub-table-column" style="width: 122px;">고객명</th>
                                    <th class="-pub-table-column" style="width: 170px;">생년월일</th>
                                    <th class="-pub-table-column" style="width: 72px;">성별</th>
                                    <th class="-pub-table-column" style="width: 130px;">고객구분</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="selectAddMember" :value="props.item"></fdp-checkbox>
                                <td class="-pub-table-column -pub-table-column--name" style="width: 122px;">{{props.item.name}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 170px;">{{props.item.date}}</td>
                                <td class="-pub-table-column" style="width: 72px;">{{props.item.gander}}</td>
                                <td class="-pub-table-column" style="width: 130px;">{{props.item.data4}}</td>
                            </template>
                            <!-- 검색결과 없을때 화면 -->
                            <template slot="emptyView">
                                <div class="empty-table-content">
                                    <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                    </div>
                    <!--// 오른쪽 영역 end -->
                </div>
            </div>
            <!--// 세대조정 end -->
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar -pub-bottom-bar__generation -pub-bottom-bar__group">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple">
                        <span class="-pub-button__text">그룹 삭제</span>
                    </button><button type="button" class="-pub-button -pub-button--purple">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--confirm">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSCM254P.mock'

export default {
  data () {
    return {
      showPopup: true,
      vipGroupName: '나의 VIP그룹',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      mockAddMember: [],
      newData: [],
      searchKeywordOrigin: '',
      searchKeywordAddMember: '',
      isSelectAllOrigin: false,
      isSelectAllAddMember: false,
      selectOrigin: [],
      selectAddMember: []
    }
  },
  methods: {
    // table 전체 선택 처리 (전체고객)
    selectAllItemsOrginFunc (state) {
      if (state) {
      // checked
        this.selectOrigin = this.mockData.slice(0)
      } else {
      // unchecked
        this.selectOrigin.splice(0, this.selectOrigin.length)
      }
    },
    // table 전체 선택 처리 (그룹에 추가된 고객)
    selectAllItemsAddMemberFunc (state) {
      if (state) {
      // checked
        this.selectAddMember = this.mockAddMember.slice(0)
      } else {
      // unchecked
        this.selectAddMember.splice(0, this.selectAddMember.length)
      }
    },
    // 전체고객에서 그룹에 추가된 고객으로 이동 처리
    moveAddMember () {
      for (var i in this.selectOrigin) {
        this.mockAddMember.push(this.selectOrigin[i])
      }
      for (var k in this.selectOrigin) {
        for (var j = this.mockData.length - 1; j >= 0; j--) {
          if (this.selectOrigin[k].key === this.mockData[j].key) {
            this.mockData.splice(j, 1)
          }
        }
      }
      this.selectOrigin.splice(0, this.selectOrigin.length)
      this.isSelectAllOrigin = false
    },
    // 그룹에 추가된 고객에서 전체고객으로 이동 처리
    moveOrigin () {
      for (var i in this.selectAddMember) {
        this.mockData.push(this.selectAddMember[i])
      }
      for (var k in this.selectAddMember) {
        for (var j = this.mockAddMember.length - 1; j >= 0; j--) {
          if (this.selectAddMember[k].key === this.mockAddMember[j].key) {
            this.mockAddMember.splice(j, 1)
          }
        }
      }
      this.selectAddMember.splice(0, this.selectAddMember.length)
      this.isSelectAllAddMember = false
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리 (현재 세대)
    selectOrigin () {
      if (this.selectOrigin.length !== this.mockData.length || this.mockData.length === 0) {
        this.isSelectAllOrigin = false
      } else {
        this.isSelectAllOrigin = true
      }
    },
    // table내 record가 갖는 checkbox 선택 시 후처리 (이동 세대)
    selectAddMember () {
      if (this.selectAddMember.length !== this.mockAddMember.length || this.mockAddMember.length === 0) {
        this.isSelectAllAddMember = false
      } else {
        this.isSelectAllAddMember = true
      }
    }
  }
}
</script>
