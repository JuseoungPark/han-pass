<template>
  <section class="-pub-system-setting">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">설정</span>
      </h2>
    </div>
      <div class="-pub-system-setting__profile">
        <h3 class="-pub-system-setting__name">김하늘 FC</h3>
        <div class="-pub-system-setting__team">삼성지역단</div>
        <div class="-pub-profile-label"><span>자문역(상무급)</span></div>
      </div>
    <fdp-tab-topcolor-type class="-pub-tab-container" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
      <component :is="currentTabComponent"></component>
    </fdp-tab-topcolor-type>

  </section>
</template>
<script>
import FirstTabComponent from '@/components/pages/2018-09-21/TSSBC131M-tab'
import SecondTabComponent from '@/components/pages/2018-09-21/TSSBC133M'
import ThirdTabComponent from '@/components/pages/2018-10-12/TSSBC134M'
export default {
  components: {
    SecondTabComponent,
    FirstTabComponent,
    ThirdTabComponent
  },
  data () {
    return {
      currentTabIndex: 0,
      currentTabComponent: 'first-tab-component',
      tabItems: [{
        'tabTitle': '개인정보',
        'tabComponent': 'first-tab-component'
      },
      // 2차 범위
      {
        'tabTitle': '개인 휴대전화 연결',
        'tabComponent': ''
      },
      {
        'tabTitle': '알림 설정',
        'tabComponent': 'second-tab-component'
      },
      {
        'tabTitle': '버전 정보',
        'tabComponent': 'third-tab-component'
      }
      ]
    }
  },
  methods: {
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    }
  }
}
</script>
