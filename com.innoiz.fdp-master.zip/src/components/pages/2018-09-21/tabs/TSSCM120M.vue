<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="상세인적사항" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__detail-personal">
                <div class="-pub-popup__tab-content">
                    <fdp-tab-topcolor-type class="-pub-tab-container" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
                        <template>
                            <component :is="currentTabComponent" :current-view="isEditable?'editMode':'searchMode'"></component>
                        </template>
                    </fdp-tab-topcolor-type>
                </div>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple -pub-button--custom" v-if="!isEditable && !isLifeAnalysis">
                        <span class="-pub-button__text">고객카드삭제</span>
                    </button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm" v-if="!isEditable && !isLifeAnalysis" @click="enterEdit">
                        <span class="-pub-button__text">수정</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--purple" v-if="isEditable && !isLifeAnalysis">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--confirm" v-if="isEditable || isLifeAnalysis" @click="doEdit">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
      <!-- slot 끝 -->
    </fdp-popup>
  </template>
<script>
import ServiceTabComponent from '@/components/pages/2018-09-21/TSSCM120D'
import Tsscm120mWrapper from '@/components/pages/2018-09-21/tabs/TSSCM120M-wrapper'
import ServiceTabComponent2 from '@/components/pages/2018-09-21/TSSCM122D'
import ServiceTabComponent3 from '@/components/pages/2018-10-26/TSSCT026P'

export default {
  components: {
    ServiceTabComponent,
    ServiceTabComponent2,
    ServiceTabComponent3,
    Tsscm120mWrapper
  },
  data () {
    return {
      isEditable: false,
      isLifeAnalysis: false,
      showPopup: true,
      title: '고객',
      tabItems: [{
        'tabSubTitle': '고객정보',
        'tabButtonClass': '-pub-tab__item',
        'tabComponent': 'tsscm120m-wrapper'
      },
      {
        'tabSubTitle': '라이프분석',
        'tabButtonClass': '-pub-tab__item',
        'tabComponent': 'service-tab-component3'
      }
      ],
      currentTabComponent: 'tsscm120m-wrapper'
    }
  },
  methods: {
    onSizeChange (size) {},
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
      this.isLifeAnalysis = idx === 1 // 현재 라이프분석 탭이면 true
    },
    enterEdit () {
      this.isEditable = !this.isEditable
    },
    doEdit () {
      // 저장 액션 후 성공하면..
      this.isEditable = !this.isEditable
    }
  }
}
</script>
