<template>
  <component :is="currentTabComponent"></component>
</template>

<script>
import ServiceComponent1 from '@/components/pages/2018-09-21/TSSCM120D'
import ServiceComponent2 from '@/components/pages/2018-09-21/TSSCM122D'
export default {
  components: {
    ServiceComponent1,
    ServiceComponent2
  },
  props: {
    currentView: {
      type: String,
      default: ''
    }
  },
  computed: {
    currentTabComponent () {
      return this.currentView === 'searchMode' ? ServiceComponent1 : this.currentView === 'editMode' ? ServiceComponent2 : null
    }
  }
}
</script>

<style>

</style>
