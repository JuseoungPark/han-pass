<template>
    <!-- 스크롤시 fixed 추가 -->
    <section class="-pub-search-all" :class="isFixed?'fixed':''">
        <div class="-pub-search-wrap" >
            <button type="button" class="-pub__button--close" v-if="!isFixed" @click="closeFixed">
                <img src="@/assets/img/components/btn_close_light.png" alt="close">
            </button>
            <div class="-pub-search-box-wrap">
                <fdp-text-field class="-pub-search-input" placeholder="고객명, 메뉴명, 상품명, 질병명" v-model="searchKeyword" clearable @keyup.enter="onSearch" @focus="() => {isFocused = true}" ref="searchTextInput"></fdp-text-field>
                <img class="-pub-search-all-icon" src="@/assets/img/btn_search_blue_dark.png" @click="onSearch" alt="search">
            </div>
            <hr>
            <div class="-pub-recent-search-wrap" v-if="!searchKeyword && !isFixed && isFocused">
                <ul class="-pub-recent-searches" >
                    <li>최근 검색어</li>
                    <li v-for="(keyword, idx) in keywords" :key="idx">
                        <span v-if="idx<3"  @click="copyKeyword(idx)">{{keyword.name}}</span>
                        <img class="-pub-search-del" src="@/assets/img/components/btn_close_light.png" @click="delKeywords(idx)" alt="del" v-if="idx<3">
                    </li>
                </ul>
                <ul class="-pub-recent-activity-customer">
                    <li>최근 활동 고객</li>
                    <li v-for="(customer, idx) in customers" :key="idx">
                        <span class="-pub-search-name" v-if="idx<3">{{customer.name}}</span>
                        <span class="-pub-search-age-gender" v-if="idx<3">{{customer.ageGender}}</span>
                        <!-- [ 181109 버튼 삭제 -->
                        <!-- <img class="-pub-search-del" src="@/assets/img/components/btn_close_light.png" @click="delCustomers(idx)" alt="del" v-if="idx<3"> -->
                        <!-- 181109 버튼 삭제 ] -->
                    </li>
                </ul>
            </div>
        </div>
        <div class="-pub-searched-item-list-wrap">
            <button type="button" class="-pub__button--close" @click="closeFixed">
                <img src="@/assets/img/components/btn_close_light.png" alt="close">
            </button>
            <div class="-pub-search-result-txt">{{searchKeyword}} 에 대한 검색 결과</div>
            <ul class="-pub-searched-item-list" :class="isInit ? '-pub-init-hidden': ''">
                <li>
                    <span>총 <strong>{{totalCnt}}</strong>건</span>
                </li>
                <!-- isActive 의 값을 바꾸면 active 로 변경됩니다. -->
                <li :class="isActive=='1'?'active':''">
                    <span>고객 <strong>{{members.length}}</strong></span>
                </li>
                 <li :class="isActive=='2'?'active':''">
                    <span>메뉴 <strong>{{menus.length}}</strong></span>
                </li>
                 <li :class="isActive=='3'?'active':''">
                    <span>상품 <strong>{{products.length}}</strong></span>
                </li>
                 <li :class="isActive=='4'?'active':''">
                    <span>질병 <strong>{{diseaseList.length}}</strong></span>
                </li>
            </ul>
        </div>
        <div class="-pub-searched-content-wrap">
            <!-- 초기 진입시 화면 -->
            <div v-if="isInit"></div>
            <!-- 검색결과 없을때 화면 -->
            <div class="empty-content" v-else-if="totalCnt===0">
                <img src="@/assets/img/components/ico_no_search_result.png" class="empty-content__icon" />
                <div class="empty-content__text">'{{resultWord}}'에 대한 검색결과가 없습니다.</div>
            </div>
            <div v-else>
                <TSSBC161D :searchKeyword="searchKeyword" :members="members"></TSSBC161D>
                <div class="-pub-searched__category" ref="tab2">
                    <span class="-pub-tit">메뉴 <strong>{{menus.length}}</strong></span>
                    <div class="-pub-searched__category-menu">
                        <div class="-pub-search-all__scroll---horizon" style="width: 3000px;">
                            <div class="-pub-searched-menu" v-for="(menu,idx) in menus" :key=idx>
                                <span v-html="getHighlightTitle(menu.title)"></span>
                                <img class="-pub-short-cut" src="@/assets/img/btn_short_cut_purple.png" alt="바로가기">
                            </div>
                        </div>
                    </div>
                </div>
                <TSSBC162D :searchKeyword="searchKeyword" :products="products"></TSSBC162D>
                <TSSBC163D :searchKeyword="searchKeyword" :diseaseList="diseaseList"></TSSBC163D>
            </div>
        </div>
    </section>
</template>
<script>
import TSSBC161D from '@/components/pages/2018-09-21/TSSBC161D'
import TSSBC162D from '@/components/pages/2018-09-21/TSSBC162D'
import TSSBC163D from '@/components/pages/2018-09-21/TSSBC163D'

export default {
  components: {
    TSSBC161D,
    TSSBC162D,
    TSSBC163D
  },
  mounted () {
    this.membersTemp = this.members.slice()
    this.productsTemp = this.products.slice()
    this.diseaseListTemp = this.diseaseList.slice()
    this.menusTemp = this.menus.slice()
    this.$refs.searchTextInput.setFocus()
  },
  data () {
    return {
      isInit: true,
      isFocused: false,
      isShowEmpty: true,
      searchKeyword: '',
      resultWord: '',
      isFixed: false,
      isActive: '0',
      // [ 181109 니이-성별 에서 생년월일-성별로 변경
      customers: [{
        name: '이주명',
        ageGender: '1970-12-07 남'
      },
      {
        name: '김판곤',
        ageGender: '1978-01-05 여'
      },
      {
        name: '손주영',
        ageGender: '1987-05-05 여'
      },
      {
        name: '이여자',
        ageGender: '1987-05-05 여'
      },
      {
        name: '이주묭',
        ageGender: '1987-05-05 여'
      }],
      // 181109 니이-성별 에서 생년월일-성별로 변경 ]
      keywords: [{
        name: '암보험'
      },
      {
        name: '감기'
      },
      {
        name: '잇힝'
      },
      {
        name: '삼성생명'
      },
      {
        name: '복장'
      },
      {
        name: '암보험'
      },
      {
        name: '감기'
      },
      {
        name: '잇힝'
      },
      {
        name: '삼성생명'
      },
      {
        name: '복장'
      }],
      members: [
        {
          name: '김종신',
          age: '52',
          job: '사무총무원',
          phone: '010-1234-1234',
          birthDay: '1989-07-07',
          socialNumberFirst: '1967-02-14',
          gender: '여',
          events: [{
            title: '납입완료(당월)'
          },
          {
            title: '계약월도래'
          },
          {
            title: '만기도래(당월)'
          }
          ],
          historys: [{
            data1: '2주 전',
            data2: '사고 보험금 접수'
          }]
        },
        {
          name: '김땡신',
          age: '54',
          job: '사무총무원',
          phone: '010-1234-1234',
          birthDay: '1989-07-07',
          socialNumberFirst: '1967-02-14',
          gender: '여',
          events: [{
            title: '납입완료(당월)'
          },
          {
            title: '계약월도래'
          },
          {
            title: '만기도래(당월)'
          }
          ],
          historys: [{
            data1: '2주 전',
            data2: '사고 보험금 접수'
          }]
        },
        {
          name: '박무신',
          age: '54',
          job: '사무총무원',
          phone: '010-1234-1234',
          birthDay: '1989-07-07',
          socialNumberFirst: '1967-02-14',
          gender: '여',
          events: [{
            title: '납입완료(당월)'
          },
          {
            title: '계약월도래'
          },
          {
            title: '만기도래(당월)'
          }
          ],
          historys: [{
            data1: '2주 전',
            data2: '사고 보험금 접수'
          }]
        },
        {
          name: '강나래',
          age: '54',
          job: '사무총무원',
          phone: '010-1234-1234',
          birthDay: '1989-07-07',
          socialNumberFirst: '1967-02-14',
          gender: '여',
          events: [{
            title: '납입완료(당월)'
          },
          {
            title: '계약월도래'
          },
          {
            title: '만기도래(당월)'
          }
          ],
          historys: [{
            data1: '2주 전',
            data2: '사고 보험금 접수'
          }]
        },
        {
          name: '마동훈',
          age: '54',
          job: '사무총무원',
          phone: '010-1234-1234',
          birthDay: '1989-07-07',
          socialNumberFirst: '1967-02-14',
          gender: '여',
          events: [{
            title: '납입완료(당월)'
          },
          {
            title: '계약월도래'
          },
          {
            title: '만기도래(당월)'
          }
          ],
          historys: [{
            data1: '2주 전',
            data2: '사고 보험금 접수'
          }]
        }
      ],
      products: [{
        title: '통합유니버셜종신보험 3.0(무)',
        desc1: '나이가 증가할수록 CI/LTC 보험금의 혜택도 함께 증가!\n100세 시대 딱 맞는 필수 보험입니다.',
        desc2: '중대한 질병, 중대한 수술 및 장기요양상해 발생시, 사망보험금의 일부를 미리 지급(CI/LTC 보험금)',
        desc3: '상품 리플렛/제안서',
        leaf1: '생활자금 받는 변액 유니버설 종신',
        leaf2: '생활자금 받는 변액 유니버설 종신',
        leaf3: '생활자금 받는 변액 유니버설 종신 유니버설 종신 유니버설 종신 유니버설 종신 유니버설 종신'
      },
      {
        title: '통합우니버설중신보험 2.0(무)',
        desc1: '나이가 증가할수록 CI/LTC 보험금의 혜택도 함께 증가!\n100세 시대 딱 맞는 필수 보험입니다.',
        desc2: '중대한 질병, 중대한 수술 및 장기요양상해 발생시, 사망보험금의 일부를 미리 지급(CI/LTC 보험금)',
        desc3: '상품 리플렛/제안서',
        leaf1: '생활자금 받는 변액 유니버설 종신',
        leaf2: '생활자금 받는 변액 유니버설 종신',
        leaf3: '생활자금 받는 변액 유니버설 종신 유니버설 종신 유니버설 종신 유니버설 종신 유니버설 종신'
      }],
      diseaseList: [{
        title: '종신감기',
        desc: '200여 종 이상의 바이러스에 의해 발생하는 호흡기계의 감염 증상, 사람에게 나타나는 나타나는 나타나는 나타나는 나타나는 나타나는 나타나는'
      },
      {
        title: '이적감기',
        desc: '메르스 보다 센 감기'
      }
      ],
      menus: [{
        title: '설계 > 설계현황 > 종신전환'
      },
      {
        title: '청약 > 청약현황 > 종신청약'
      }
      ],
      membersTemp: [],
      productsTemp: [],
      diseaseListTemp: []
    }
  },
  methods: {
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')
      return val.replace(regex, '<span class="-pub-search-color">$1</span>')
    },
    delKeywords (idx) {
      this.keywords.splice(idx, 1)
    },
    delCustomers (idx) {
      this.customers.splice(idx, 1)
    },
    onSearch () {
      this.isFocused = false
      this.isInit = false
      if (this.searchKeyword === '2') {
        this.isFixed = true
        return
      }
      this.resultWord = this.searchKeyword
      if (this.searchKeyword) {
        this.members = []
        this.products = []
        this.diseaseList = []
        this.menus = []
        for (var i = 0; i < this.membersTemp.length; i++) {
          if (this.membersTemp[i]['name'].indexOf(this.searchKeyword) !== -1) {
            this.members.push(this.membersTemp[i])
          }
        }

        for (i = 0; i < this.productsTemp.length; i++) {
          if (this.productsTemp[i]['title'].indexOf(this.searchKeyword) !== -1) {
            this.products.push(this.productsTemp[i])
          }
        }

        for (i = 0; i < this.diseaseListTemp.length; i++) {
          if (this.diseaseListTemp[i]['title'].indexOf(this.searchKeyword) !== -1) {
            this.diseaseList.push(this.diseaseListTemp[i])
          }
        }

        for (i = 0; i < this.menusTemp.length; i++) {
          if (this.menusTemp[i]['title'].indexOf(this.searchKeyword) !== -1) {
            this.menus.push(this.menusTemp[i])
          }
        }
        this.addKeyword(this.searchKeyword)
      } else {
        this.members = this.membersTemp.slice()
        this.products = this.productsTemp.slice()
        this.diseaseList = this.diseaseListTemp.slice()
        this.menus = this.menusTemp.slice()
      }
    },
    addKeyword (val) {
      let addKey = []
      addKey.name = val
      this.keywords.unshift(addKey)
      if (this.keywords.length > 9) {
        this.keywords.splice(10, 1)
      }
    },
    closeFixed () {
      this.isFixed = false
    },
    copyKeyword (val) {
      this.searchKeyword = this.keywords[val].name
    }
  },
  computed: {
    totalCnt () {
      return this.members.length + this.products.length + this.diseaseList.length + this.menus.length
    }
  }
}
</script>
