<template>
  <section class="-pub-system-setting-admin">
    <!-- 알림 기능 off시 -pub-noit-disabled 추가 -->
    <div class="float-container">
      <ul class="-pub-noti__list-wrap -pub-noti__list-wrap-left" :class="{'-pub-noit-disabled':!toggle1}">
      <li class="-pub-noti__list">
        <label class="-pub-noti-item">사번</label>
        <div class="-pub-noti-item-src">
          <p class="-pub-text-area normal-letter">7169144</p>
        </div>
      </li>
      <li class="-pub-noti__list">
        <label class="-pub-noti-item">휴대폰</label>
        <div class="-pub-noti-item-src">
          <template v-if="isUpdate">
            <fdp-validator name="tssbc131m-validator-1" display-name="핸드폰 번호" v-model="defaultUsage.masking" :rules="'required'">
              <fdp-select class="-pub-select -pub-select--purple normal-letter -pub-select--phone" v-model="selectData"
                :option-list="selectList" :disabled="!toggle1"></fdp-select>
              <fdp-text-field class="normal-letter" v-model="defaultUsage.masking" mask="phone" style="width: 262px;"></fdp-text-field>
            </fdp-validator>
          </template>
          <template v-else>
            <p class="-pub-text-area normal-letter">010-1234-5678</p>
          </template>
        </div>
      </li>
      <li class="-pub-noti__list">
        <label class="-pub-noti-item">회사이메일 </label>
        <div class="-pub-noti-item-src">
          <template v-if="isUpdate">
            <fdp-validator name="tssbc131m-validator-2" display-name="이메일" v-model="defaultUsage.masking" :rules="'required'">
              <fdp-text-field v-model="defaultUsage.default" style="width: 402px;"></fdp-text-field>
              <p class="-pub-text-area -pub-text-area--email-text normal-letter">@samsung.com</p>
            </fdp-validator>
          </template>
          <template v-else>
            <p class="-pub-text-area normal-letter">theer.kim@samsung.com</p>
          </template>
        </div>
      </li>
      <li class="-pub-noti__list -pub-noti__list-1" v-if="isUpdate">
        <span class="-pub-text-area -pub-text-area--guide">* &nbsp;&nbsp;휴대폰, 회사 이메일은 수정 요청 후 담당자 확정 시 최종 반영 됩니다.</span>
      </li>
    </ul>
    <ul class="-pub-noti__list-wrap -pub-noti__list-wrap-right" :class="{'-pub-noit-disabled':!toggle1}">
      <li class="-pub-noti__list -pub-noti__list--company-addr">
        <label class="-pub-noti-item">회사주소</label>
        <div class="-pub-noti-item-src">
          <p class="-pub-noti-addr-text">123-456</p>
          <span class="-pub-noti-addr-text">서울 송파구 신천동 33길 42 삼삼빌딩 23동 10호</span>
        </div>
      </li>
      <li class="-pub-noti__list">
        <label class="-pub-noti-item">지점 전화번호</label>
        <div class="-pub-noti-item-src"><span class="-pub-text-area normal-letter">02-1234 - 5678</span></div>
      </li>
      <li class="-pub-noti__list">
        <label class="-pub-noti-item">지점 Fax</label>
        <div class="-pub-noti-item-src"><span class="-pub-text-area normal-letter">02-1234 - 5678</span></div>
      </li>
    </ul>
    </div>
    <p class="-pub-text-area" v-if="!isUpdate">*  &nbsp;&nbsp;휴대폰, 회사 이메일 수정 요청 : <span>2018.03.05 12:50</span></p>
    <div class="-pub-bottom-bar">
      <div class="-pub-confirm__content--right">
        <button type="button" class="-pub-button -pub-button--purple -pub-button--purple-reverse" v-if="isUpdate === false" @click="isUpdate = true">비밀번호 변경</button>
        <button type="button" class="-pub-button -pub-button--purple" v-if="isUpdate === true" @click="isUpdate = false">취소</button>
        <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse" v-if="isUpdate === false" @click="isUpdate = true">수정</button>
        <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--update-request" v-if="isUpdate === true" @click="isUpdate = false">수정요청</button>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  data () {
    return {
      isUpdate: false,
      defaultUsage: {
        default: '',
        clearable: '',
        password: '',
        masking: '',
        fixedIcon: '',
        disabled: 'text not editable',
        readonly: 'text not editable'
      },
      toggle1: true,
      toggle2: true,
      toggle3: true,
      selectData: {
        label: '010',
        key: '1'
      },
      selectList: [{
        label: '010',
        key: '1'
      },
      {
        label: '011',
        key: '2'
      },
      {
        label: '012',
        key: '3'
      }
      ]
    }
  },
  watch: {
    toggle1: function () {
      if (!this.toggle1) {
        this.toggle2 = false
        this.toggle3 = false
      } else {
        this.toggle2 = true
        this.toggle3 = true
      }
    }
  }
}
</script>
