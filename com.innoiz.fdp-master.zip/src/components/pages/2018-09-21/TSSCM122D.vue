<template>
    <section class="-pub-popup__detail-personal -pub-popup__content--detail-modify">
        <!--------------------------------------------------------------------------------  고객 상세인적사항_수정모드  --------------------------------------------------------------------------->
        <div class="-pub-popup__content--detail-personal">
            <!-- 기본정보 start -->
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">기본 정보</span>
                <span class="-pub-popup__title-dec">※ 필수컨설팅동의를 받은 경우만 주민등록번호 수정 가능</span>
                <div class="-pub-popup__title-button">
                    <button type="button" class="-pub-button -pub-button--gray">
                        <span class="-pub-button__text">일련번호 조회</span>
                    </button>
                </div>
            </div>
            <div class="-pub-popup__content--detail-form01 -pub-bottom-padding">
            <!-- 간단정보 보기 영역 start -->
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">고객명<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input">{{customerInfo.name}}</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주민등록번호<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input -pub-normal-letter">{{customerInfo.ssno}}</dd>
            </dl>
            <dl class="-pub-form-row__4">
                <dt class="-pub-form-title">실제생일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="customerInfo.bDate" format="yyyy-M-d"></fdp-date-picker>
                    <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment" v-model="customerInfo.bType" :data="filters" essential></fdp-segment-box>
                </dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">취득경로</dt>
                <dd class="-pub-form-input">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="customerInfo.route" :option-list="filterSelectItems"></fdp-select>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">소개자</dt>
                <dd class="-pub-form-input">
                    <fdp-text-field v-model="customerInfo.intPerson" fixedIcon></fdp-text-field>
                </dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">소개일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="customerInfo.intDate" align-right format="yyyy-M-d"></fdp-date-picker>
                </dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">직업<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="tsscm122d-validator1" display-name="직업" v-model="customerInfo.job" :rules="'required'">
                        <fdp-text-field v-model="customerInfo.job" fixedIcon placeholder="총무사무원"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">직장명</dt>
                <dd class="-pub-form-input">
                    <fdp-text-field v-model="customerInfo.officeNm" placeholder="쌍용자동차"></fdp-text-field>
                </dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">세대주</dt>
                <dd class="-pub-form-input -pub-normal-letter">{{customerInfo.repYn}}</dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">주고객명</dt>
                <dd class="-pub-form-input">{{customerInfo.repCustomer}}</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주고객관계</dt>
                <dd class="-pub-form-input">{{customerInfo.repRel}}</dd>
            </dl>
            <!-- 간단정보 보기 영역 end -->
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 start -->
            <dl class="-pub-form-row__1" v-if="isDetailModify">
                <dt class="-pub-form-title">부서</dt>
                <dd class="-pub-form-input">
                    <fdp-text-field v-model="customerInfo.detpNm"></fdp-text-field>
                </dd>
            </dl>
            <dl class="-pub-form-row__2" v-if="isDetailModify">
                <dt class="-pub-form-title">직급</dt>
                <dd class="-pub-form-input">
                    <fdp-text-field v-model="customerInfo.pos"></fdp-text-field>
                </dd>
            </dl>
            <dl class="-pub-form-row__3" v-if="isDetailModify">
                <dt class="-pub-form-title">취미</dt>
                <dd class="-pub-form-input">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="customerInfo.hobby" :option-list="filterSelectItems3" placeholder="선택하세요"></fdp-select>
                </dd>
            </dl>
            <dl class="-pub-form-row__1" v-if="isDetailModify">
                <dt class="-pub-form-title">자보가입</dt>
                <dd class="-pub-form-input">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="customerInfo.autoYn" :option-list="filterSelectItems2" placeholder="선택하세요"></fdp-select>
                </dd>
            </dl>
            <dl class="-pub-form-row__2" v-if="isDetailModify">
                <dt class="-pub-form-title">자보만기일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="customerInfo.autoEndD" format="yyyy-M-d"></fdp-date-picker>
                </dd>
            </dl>
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 end -->
            </div>
            <div class="-pub-detail-form__view">
                <!-- 전체보기 버튼 영역 start -->
                <!-- <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>전체보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                </a> -->
                <!-- 전체보기 버튼영역 end -->
                <!-- 간단 정보 보기 버튼 영역 start-->
                <a class="-pub-info-wrap_expand-button" :class="[{'-pub__info--isOpen': isDetailModify}]" @click="isDetailModify=!isDetailModify">
                    <span>{{!isDetailModify?'전체보기' : '간단 정보 보기'}}</span>
                </a>
                <!-- 간단 정보 보기 버튼영역 end -->
            </div>
            <!-- 기본정보 end -->

            <!-- // 중복된 부분 삭제 함 -->
            <!-- 기본정보 start
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">기본정보</span>
                <span class="-pub-popup__title-dec">※ 필수컨설팅동의를 받은 경우만 주민등록번호 수정 가능</span>
                <div class="-pub-popup__title-button">
                    <button type="button" class="-pub-button -pub-button--gray">
                        <span class="-pub-button__text">일련번호 조회</span>
                    </button>
                </div>
            </div>
            <div class="-pub-popup__content--detail-form01 -pub-bottom-padding">
            간단정보 보기 영역
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">고객명<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input">김하늘</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주민등록번호<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input -pub-normal-letter -pub-form-input__width">
                    <fdp-validator name="Name" v-model="defaultUsage" :rules="'required'">
                        <fdp-text-field v-model="defaultUsage" placeholder="890707" style="width: 194px;" class="-pub-normal-letter"></fdp-text-field>
                        <span class="-pub-from">-</span>
                        <fdp-text-field v-model="defaultUsage" placeholder="5779622" style="width: 194px;"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__4">
                <dt class="-pub-form-title">실제생일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-validator name="Name" v-model="inputDate" :rules="'required'">
                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="inputDate" format="yyyy-M-d"></fdp-date-picker>
                    </fdp-validator><fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment" v-model="filter" :data="filters"></fdp-segment-box>
                </dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">취득경로</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="filterSelectValue" :rules="'required'">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="filterSelectValue" :option-list="filterSelectItems"></fdp-select>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">소개자</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="fixedIcon" :rules="'required'">
                        <fdp-text-field v-model="fixedIcon" fixedIcon placeholder="김지연"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">소개일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-validator name="Name" v-model="inputDate" :rules="'required'">
                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="inputDate" format="yyyy-M-d"></fdp-date-picker>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">직업<span class="-pub-check">*</span></dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="fixedIcon" :rules="'required'">
                        <fdp-text-field v-model="fixedIcon" fixedIcon placeholder="총무사무원"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">직장명</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="defaultUsage" :rules="'required'">
                        <fdp-text-field v-model="defaultUsage" placeholder="쌍용자동차"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">세대주</dt>
                <dd class="-pub-form-input -pub-normal-letter">Y</dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">주고객명</dt>
                <dd class="-pub-form-input">김하늘</dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">주고객관계</dt>
                <dd class="-pub-form-input">본인</dd>
            </dl>
            간단정보 보기 영역 end
            전체보기 버튼을 클릭 했을때 나오는 영역 start
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">부서</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="defaultUsage" :rules="'required'">
                    <fdp-text-field v-model="defaultUsage" placeholder="마케팅"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">직급</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="defaultUsage" :rules="'required'">
                    <fdp-text-field v-model="defaultUsage" placeholder="대리"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__3">
                <dt class="-pub-form-title">취미</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="filterSelectValue" :rules="'required'">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="filterSelectValue" :option-list="filterSelectItems" placeholder="선택하세요"></fdp-select>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__1">
                <dt class="-pub-form-title">자보가입</dt>
                <dd class="-pub-form-input">
                    <fdp-validator name="Name" v-model="filterSelectValue" :rules="'required'">
                    <fdp-select class="-pub-filter-menu__item -pub-filter-menu__item--select" v-model="filterSelectValue" :option-list="filterSelectItems" placeholder="선택하세요"></fdp-select>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__2">
                <dt class="-pub-form-title">자보만기일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-validator name="Name" v-model="inputDate" rules="'required'">
                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker" v-model="inputDate" format="yyyy-M-d"></fdp-date-picker>
                    </fdp-validator>
                </dd>
            </dl>
             전체보기 버튼을 클릭 했을때 나오는 영역 end
            </div>
            <div class="-pub-detail-form__view">
                 전체보기 버튼 영역 start
                 <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>전체보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                </a>
                 전체보기 버튼영역 end
                 간단 정보 보기 버튼 영역 start
                <a class="-pub-filter-menu__item -pub-filter-menu__detail-button -pub-filter-menu__detail-button--active" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>간단 정보 보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                </a>
                간단 정보 보기 버튼영역 end
            </div>
            기본정보 end -->

            <!-- 주소 및 연락처 start -->
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">주소 및 연락처</span>
                <div class="-pub-popup__title-button">
                    <button type="button" class="-pub-button -pub-button--gray">
                        <span class="-pub-button__text">주고객주소 반영</span>
                    </button>
                </div>
            </div>
            <div class="-pub-popup__content--detail-form01 -pub-bottom-padding">
            <!-- 간단정보 보기 영역 start -->
            <dl class="-pub-form-row__4">
                <dt class="-pub-form-title">휴대폰</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-validator name="tsscm122d-validator-address-1" display-name="휴대폰" v-model="addrInfo.phoneNumber" :rules="'required'">
                        <fdp-select class="-pub-filter-menu__item -pub-filter-phone -pub-filter-menu__item--select" v-model="addrInfo.phone" :option-list="phoneSelectItems" placeholder="010">
                        </fdp-select><fdp-text-field v-model="addrInfo.phoneNumber" placeholder="0000-0000" class="-pub-phone-last"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl class="-pub-form-row__4">
                <dt class="-pub-form-title">이메일</dt>
                <dd class="-pub-form-input -pub-normal-letter">
                    <fdp-validator name="tsscm122d-validator-address-2" display-name="이메일" v-model="addrInfo.email[0]" :rules="'required'">
                        <fdp-text-field v-model="addrInfo.email[0]" placeholder="" class="-pub-email-first"></fdp-text-field>
                        <span class="-pub-from">@</span>
                        <fdp-text-field v-model="addrInfo.email[1]" placeholder="" class="-pub-email-last"></fdp-text-field>
                        <fdp-select class="-pub-filter-menu__item -pub-filter-email -pub-filter-menu__item--select" v-model="addrInfo.email[2]" :option-list="emailSelectItems" placeholder="이메일 직접입력" ellipsis></fdp-select>
                    </fdp-validator>
                </dd>
            </dl>
            <!-- 간단정보 보기 영역 end -->
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 start -->
                <dl class="-pub-form-row__4" v-if="isDetailModify2">
                    <dt class="-pub-form-title">자택주소</dt>
                    <dd class="-pub-form-input">
                        <button class="-pub-button -pub-button--purple -pub-zipcode-button"><span>우편번호</span></button>
                        <fdp-validator name="tsscm122d-validator-address-3" display-name="자택주소" v-model="addrInfo.zipcode" :rules="'required'">
                            <fdp-text-field v-model="addrInfo.zipcode" placeholder="3232, 대전광역시 대덕구 벚꽃길 113" class="-pub-zipcodeinput" disabled="disabled"></fdp-text-field>
                        </fdp-validator>
                    </dd>
                </dl>
                <dl class="-pub-form-row__4" v-if="isDetailModify2">
                    <dt class="-pub-form-title">자택전화</dt>
                    <dd class="-pub-form-input -pub-normal-letter">
                        <fdp-validator name="tsscm122d-validator-address-4" display-name="자택전화" v-model="addrInfo.tel" :rules="'required'">
                            <fdp-select class="-pub-filter-menu__item -pub-filter-phone -pub-filter-menu__item--select" v-model="addrInfo.tel" :option-list="phoneSelectItems" placeholder="02">
                            </fdp-select><fdp-text-field v-model="addrInfo.tel1" class="-pub-phone-last"></fdp-text-field>
                        </fdp-validator>
                    </dd>
                </dl>
                <dl class="-pub-form-row__4" v-if="isDetailModify2">
                    <dt class="-pub-form-title">직장주소</dt>
                    <dd class="-pub-form-input">
                        <button class="-pub-button -pub-button--purple -pub-zipcode-button"><span>우편번호</span></button>
                        <fdp-validator name="tsscm122d-validator-address-5" display-name="직장주소" v-model="addrInfo.officeAddr" :rules="'required'">
                            <fdp-text-field v-model="addrInfo.officeAddr" placeholder="3232, 대전광역시 대덕구 벚꽃길 113" class="-pub-zipcodeinput" disabled="disabled"></fdp-text-field>
                        </fdp-validator>
                    </dd>
                </dl>
                <dl class="-pub-form-row__4" v-if="isDetailModify2">
                    <dt class="-pub-form-title">직장전화</dt>
                    <dd class="-pub-form-input -pub-normal-letter">
                        <fdp-validator name="tsscm122d-validator-address-6" display-name="직장전화" v-model="addrInfo.officeTel" :rules="'required'">
                            <fdp-select class="-pub-filter-menu__item -pub-filter-phone -pub-filter-menu__item--select" v-model="addrInfo.officeTel" :option-list="phoneSelectItems" placeholder="02">
                            </fdp-select><fdp-text-field v-model="addrInfo.officeTel1"  class="-pub-phone-last"></fdp-text-field>
                        </fdp-validator>
                    </dd>
                </dl>
                <dl class="-pub-form-row__4" v-if="isDetailModify2">
                    <dt class="-pub-form-title">우편물수령지</dt>
                    <dd class="-pub-form-input">
                        <fdp-validator name="tsscm122d-validator-address-7" display-name="우편물수령지" v-model="addrInfo.postAddr.key" :rules="'required'">
                            <fdp-segment-box v-model="addrInfo.postAddr" :data="addresszipcode" class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment"></fdp-segment-box>
                        </fdp-validator>
                    </dd>
                </dl>
            <!-- 전체보기 버튼을 클릭 했을때 나오는 영역 end -->
            </div>
            <div class="-pub-detail-form__view">
                <!-- 전체보기 버튼 영역 start -->
                <!-- <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch}]" @click="isDetailSearch = !isDetailSearch">
                <span>전체보기</span>
                <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                </a> -->
                <!-- 전체보기 버튼영역 end -->
                <!-- 간단 정보 보기 버튼 영역 start-->
                <a class="-pub-info-wrap_expand-button" :class="[{'-pub__info--isOpen': isDetailModify2}]" @click="isDetailModify2=!isDetailModify2">
                    <span>{{!isDetailModify2?'전체보기' : '간단 정보 보기'}}</span>
                </a>
                <!-- 간단 정보 보기 버튼영역 end -->
            </div>
            <!-- 주소 및 연락처 end -->
            <!-- 세대 관계 정보 start -->
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">세대 관계 정보</span>
            </div>
            <div class="-pub-popup__content--list-form">
                <fdp-infinite  class="-pub-table -pop-customer" v-model="radioTableSelected" :items="mockData" single-select>
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width: 58px;">
                                <!-- <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected"></fdp-radio> -->
                            </th>
                            <th class="-pub-table-column" style="width: 120px;">고객명<span class="-pub-check">*</span></th>
                            <th class="-pub-table-column" style="width: 128px;">세대주</th>
                            <th class="-pub-table-column" style="width: 222px;">주민등록번호<span class="-pub-check">*</span></th>
                            <th class="-pub-table-column" style="width: 128px;">외국인</th>
                            <th class="-pub-table-column" style="width: 154px;">주고객관계<span class="-pub-check">*</span></th>
                            <th class="-pub-table-column" style="width: 234px;">실제생일</th>
                            <th class="-pub-table-column" style="width: 154px;">직업<span class="-pub-check">*</span></th>
                            <th class="-pub-table-column" style="width: 316px;">휴대폰번호</th>
                        </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column -pub-table-column--name" style="width: 58px;">
                            <fdp-radio class="-pub-radio -pub-radio--purple" v-model="radioSelected" :value="props.item.idx.toString()"></fdp-radio>
                        </td>
                        <td class="-pub-table-column -pub-table-column--name" style="width: 120px;">{{props.item.name}}</td>
                        <td class="-pub-table-column" style="width: 128px;">
                            <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--ny -pub-segment--purple -pub-search-segment" v-model="props.item.repYn" :data="header" v-if="props.item.baby=='N'"></fdp-segment-box>
                        </td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 222px;">{{props.item.calories}}</td>
                        <td class="-pub-table-column" style="width: 128px;">
                            <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--ny -pub-segment--purple -pub-search-segment" v-model="props.item.forienYn" :data="foreignerpeople" v-if="props.item.baby=='N'"></fdp-segment-box>
                        </td>
                        <td class="-pub-table-column" style="width: 154px;">
                            <fdp-validator :name="'tsscm122d-validator-rel-' + props.index" display-name="주고객관계" v-model="props.item.rel.key" :rules="'required'"  v-if="props.item.baby=='N'">
                                <fdp-select v-model="props.item.rel" :option-list="customerItems" class="-pub-filter-menu__item -pub-filter-menu__item--select -pub-customer-select"></fdp-select>
                            </fdp-validator>
                        </td>
                        <td class="-pub-table-column" style="width: 234px;">
                            <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-menu__item -pub-filter-menu__item--date-picker -pub-date-birthday" v-model="props.item.birth" format="yyyy-M-d"  v-if="props.item.baby=='N'"></fdp-date-picker>
                        </td>
                        <td class="-pub-table-column" style="width: 154px;">
                            <fdp-validator :name="'tsscm122d-validator-rel-job-' + props.index" display-name="직업" v-model="props.item.job" :rules="'required'" v-if="props.item.baby=='N'">
                                <fdp-text-field v-model="props.item.job" fixedIcon class="-pub-job-search"></fdp-text-field>
                            </fdp-validator>
                        </td>
                        <td class="-pub-table-column -pub-select-phone -pub-table-column--normal-letter" style="width: 316px;">
                            <fdp-select class="-pub-filter-menu__item -pub-filter-phone -pub-filter-menu__item--select" v-model="props.item.phone1" :option-list="phoneSelectItems"  v-if="props.item.baby=='N'"></fdp-select><fdp-text-field v-model="props.item.phone2" class="-pub-phone-last"  v-if="props.item.baby=='N'"></fdp-text-field>
                        </td>
                    </template>
            </fdp-infinite>
            </div>
            <div class="-pub-popup__bottom--button">
                <button type="button" class="-pub-button -pub-button--gray" :disabled="!radioSelected" @click="deleteCustomer">
                    <span class="-pub-button__text">삭제</span>
                </button><button type="button" class="-pub-button -pub-button--gray" @click="addBaby">
                    <span class="-pub-button__text">태아등재</span>
                </button><button type="button" class="-pub-button -pub-button--gray">
                    <span class="-pub-button__text">세대조정</span>
                </button>
            </div>
            <!-- 세대 관계 정보 end -->
            <!-- 정보활용동의 및 접촉거부 정보 start -->
            <div class="-pub-popup__title">
                <span class="-pub-popup__title-txt">정보활용동의 및 접촉거부 정보</span>
                <div class="-pub-popup__title-button">
                    <button type="button" class="-pub-button -pub-button--gray">
                        <span class="-pub-button__text">정보제공동의 관리</span>
                    </button>
                </div>
            </div>
            <div class="-pub-popup__content--detail-form01">
                <dl class="-pub-form-row__1">
                    <dt class="-pub-form-title">필수컨설팅동의</dt>
                    <dd class="-pub-form-input -pub-normal-letter">Y (2017-03-25 만료)</dd>
                </dl>
                <dl class="-pub-form-row__2">
                    <dt class="-pub-form-title">마케팅동의</dt>
                    <dd class="-pub-form-input -pub-normal-letter">Y (2017-11-07 만료)</dd>
                </dl>
                <dl class="-pub-form-row__3">
                    <dt class="-pub-form-title">전환동의</dt>
                    <dd class="-pub-form-input -pub-normal-letter">N</dd>
                </dl>
                <dl class="-pub-form-row__1">
                    <dt class="-pub-form-title">보험상담동의</dt>
                    <dd class="-pub-form-input -pub-normal-letter">N (2017-03-23 만료)</dd>
                </dl>
                <dl class="-pub-form-row__2">
                    <dt class="-pub-form-title">온라인상담</dt>
                    <dd class="-pub-form-input -pub-normal-letter">N</dd>
                </dl>
                <dl class="-pub-form-row__3">
                    <dt class="-pub-form-title">두낫콜여부</dt>
                    <dd class="-pub-form-input -pub-normal-letter">N</dd>
                </dl>
                <dl class="-pub-form-row__1">
                    <dt class="-pub-form-title">접촉거부</dt>
                    <dd class="-pub-form-input">이메일</dd>
                </dl>
            </div>
            <!-- 정보활용동의 및 접촉거부 정보 end -->
            <!-- 마케팅 정보 start -->
            <div class="-pub-popup__title -pub-marketing-info">
                    <span class="-pub-popup__title-txt">마케팅 정보</span>
                    <div class="-pub-popup__title-button-arrow">
                        <a class="-pub-filter-menu__item -pub-filter-menu__detail-button" :class="[{'-pub-filter-menu__detail-button--active': isDetailSearch3}]" @click="isDetailSearch3 = !isDetailSearch3">
                        <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="-pub-popup__content--detail-form02 -pub-bottom-padding" v-show="isDetailSearch3">
                    <dl class="-pub-form-row__1">
                    <dt class="-pub-form-title">자녀 1</dt>
                    <dd class="-pub-form-input">
                        <fdp-validator name="tsscm122d-validator-marketing-1" display-name="자녀 1 출생년도" v-model="yearSelectValue1.key" :rules="'required'">
                            <fdp-select class="-pub-filter-menu__item -pub-year-select -pub-filter-menu__item--select" v-model="yearSelectValue1" :option-list="yearSelectItems"></fdp-select>
                        </fdp-validator><span class="-pub-year-day">년 출생</span>
                        <fdp-validator name="tsscm122d-validator-marketing-2" display-name="자녀 1 성별" v-model="gender1" :rules="'required'">
                        <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment" v-model="gender1" :data="genderpeople"></fdp-segment-box>
                        </fdp-validator>
                    </dd>
                    </dl>
                    <dl class="-pub-form-row__2">
                        <dt class="-pub-form-title">자녀 2</dt>
                        <dd class="-pub-form-input">
                            <fdp-validator name="tsscm122d-validator-marketing-3" display-name="자녀 2 출생년도" v-model="yearSelectValue2.key" :rules="'required'">
                                <fdp-select class="-pub-filter-menu__item -pub-year-select -pub-filter-menu__item--select" v-model="yearSelectValue2" :option-list="yearSelectItems"></fdp-select>
                            </fdp-validator><span class="-pub-year-day">년 출생</span><fdp-validator name="tsscm122d-validator-marketing-4" display-name="자녀 2 성별" v-model="gender2" :rules="'required'">
                                <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment" v-model="gender2" :data="genderpeople"></fdp-segment-box>
                            </fdp-validator>
                        </dd>
                    </dl>
                    <dl class="-pub-form-row__1">
                        <dt class="-pub-form-title">자녀 3</dt>
                        <dd class="-pub-form-input">
                            <fdp-validator name="tsscm122d-validator-marketing-5" display-name="자녀 3 출생년도" v-model="yearSelectValue3.key" :rules="'required'">
                                <fdp-select class="-pub-filter-menu__item -pub-year-select -pub-filter-menu__item--select" v-model="yearSelectValue3" :option-list="yearSelectItems"></fdp-select>
                            </fdp-validator><span class="-pub-year-day">년 출생</span>
                            <fdp-validator name="tsscm122d-validator-marketing-6" display-name="자녀 3 성별" v-model="gender3" :rules="'required'">
                                <fdp-segment-box class="-pub-filter-menu__item -pub-segment__container -pub-segment--small -pub-segment--purple -pub-search-segment" v-model="gender3" :data="genderpeople"></fdp-segment-box>
                            </fdp-validator>
                        </dd>
                    </dl>
                    <dl class="-pub-form-row__1">
                        <dt class="-pub-form-title">가족구성원</dt>
                        <dd class="-pub-form-input">
                            <fdp-validator name="tsscm122d-validator-marketing-7" display-name="가족구성원" v-model="familyMember" :rules="'required'">
                                <fdp-text-field v-model="familyMember" placeholder="4" class="-pub-family-number"></fdp-text-field>
                            </fdp-validator><span class="-pub-year-day">명</span>
                        </dd>
                    </dl>
                </div>
                <!-- 마케팅 정보 end -->
        </div>
    </section>
</template>
<script>
import mockData from '@/components/mock/TSSCM120D.mock'
export default {
  data: function () {
    return {
      isDetailModify: false,
      isDetailModify2: false,
      showPopup: true,
      selected: [],
      items: [],
      customerInfo: {
        name: '김하놀',
        ssno: '890707-2*******',
        bDate: '',
        bType: [
          {
            key: '1',
            label: '양력'
          }
        ],
        route: {
          key: '2',
          label: '소개'
        },
        intPerson: '김슬기',
        intDate: '2018-09-11',
        job: '',
        officeNm: '',
        repYn: 'Y',
        repCustomer: '김하늘',
        repRel: '본인',
        detpNm: '모바일영업',
        pos: '대리',
        hobby: {
          key: '1',
          label: '없음'
        },
        autoYn: {
          key: '1',
          label: '삼성생명'
        },
        autoEndD: ''
      },
      addrInfo: {
        phone: {
          key: '010',
          label: '010'
        },
        phoneNumber: '',
        email: {
          0: '',
          1: '',
          2:
        {key: '1',
          label: 'naver.com'}
        },
        zipcode: '',
        tel: {
          key: '2',
          label: '080'
        },
        tel1: '',
        officeAddr: '',
        officeTel: {
          key: '2',
          label: '080'
        },
        officeTel1: '7771-0505',
        postAddr: [{
          key: '1',
          value: '자택'
        }]
      },
      name: '',
      gender1: [{
        key: '',
        label: ''
      }],
      gender2: [{
        key: '',
        label: ''
      }],
      gender3: [{
        key: '',
        label: ''
      }],
      default: '',
      clearable: '',
      password: '',
      masking: '',
      defaultUsage: '',
      fixedIcon: '',
      disabled: 'text not editable',
      readonly: 'text not editable',
      radioTfValue: false,
      radioStrValue: '',
      radioSelected: '',
      isDetailSearch: false,
      isDetailSearch3: false,
      radioTableSelected: [],
      mockData: Array.prototype.slice.call(mockData, 0, 6),
      emailSelectValue: {
        key: '1',
        label: '직접입력'
      },
      emailSelectItems: [
        {
          key: '1',
          label: 'navernavernavernaver.com'
        },
        {
          key: '2',
          label: 'daum.net'
        }
      ],
      phoneSelectValue: {
        key: '1',
        label: '010'
      },
      phoneSelectItems: [{
        key: '010',
        label: '010'
      },
      {
        key: '080',
        label: '080'
      }
      ],
      filterSelectValue: {
        key: '1',
        label: '선택하세요'
      },
      filterSelectItems: [{
        key: '1',
        label: '지인'
      },
      {
        key: '2',
        label: '소개'
      },
      {
        key: '3',
        label: '개척'
      },
      {
        key: '4',
        label: '기타'
      }
      ],
      filterSelectItems2: [{
        key: '1',
        label: '삼성생명'
      },
      {
        key: '2',
        label: '한화생명'
      },
      {
        key: '3',
        label: 'AIG생명'
      },
      {
        key: '4',
        label: '기타'
      }
      ],
      filterSelectItems3: [{
        key: '1',
        label: '없음'
      },
      {
        key: '2',
        label: '보험가입하기'
      },
      {
        key: '3',
        label: '해지하기'
      },
      {
        key: '4',
        label: '기타'
      }
      ],
      customer: {
        key: '1',
        label: '자녀'
      },
      customerItems: [{
        key: '1',
        label: '본인'
      },
      {
        key: '2',
        label: '자녀'
      }
      ],
      filter: [
        {
          key: '1',
          label: '양력'
        }
      ],
      filters: [{
        key: '1',
        label: '양력'
      },
      {
        key: '2',
        label: '음력'
      }
      ],
      head: [
        {
          key: '1',
          label: 'N'
        }
      ],
      header: [{
        key: '1',
        label: 'N'
      },
      {
        key: '2',
        label: 'Y'
      }
      ],
      address: [
        {
          key: '1',
          label: '자택'
        }
      ],
      addresszipcode: [{
        key: '1',
        label: '자택'
      },
      {
        key: '2',
        label: '직장'
      }
      ],
      foreigner: [
        {
          key: '1',
          label: 'N'
        }
      ],
      foreignerpeople: [{
        key: '1',
        label: 'N'
      },
      {
        key: '2',
        label: 'Y'
      }
      ],
      yearSelectValue1: {
        key: '1',
        label: '2010'
      },
      yearSelectValue2: {
        key: '1',
        label: '2010'
      },
      yearSelectValue3: {
        key: '1',
        label: '2010'
      },
      yearSelectItems: [{
        key: '1',
        label: '2010'
      },
      {
        key: '2',
        label: '2009'
      }
      ],
      genderpeople: [{
        key: '1',
        label: '남'
      },
      {
        key: '2',
        label: '여'
      }
      ],
      familyMember: ''
    }
  },
  mounted () {

  },
  methods: {
    addBaby () {
      let cnt = this.mockData.length + 1
      let addDat = {'idx': cnt, 'name': '태아', calories: '990712-******', baby: 'Y'}

      this.mockData.push(addDat)
    },
    deleteCustomer () {
      this.mockData.splice(this.radioSelected - 1, 1)
      this.radioSelected = ''
    }
  },
  watch: {
    radioTableSelected () {
    //   this.radioCheckedTableData = this.radioTableSelected.length > 0
    //   if (this.radioTableSelected instanceof Array && this.radioTableSelected.length > 0) {
    //     this.radioSelected = this.radioTableSelected[0].id.toString()
    //   }
    }
  }
}
</script>
