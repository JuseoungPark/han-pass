<template>
<div>
  <!-- 1. 전체메뉴 : START -->
  <section class="-pub-sitemap -pub-sitemap-load-file" v-if="!noData">
    <TSSBC111D></TSSBC111D>
    <div class="-pub-header -pub-header--setting">
      <h1 class="-pub-header__title -pub-header__title--setting">
          <span class="-pub-title__text">{{title}}</span><span class="-pub-title__text--desc"><img class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">&nbsp;&nbsp;*&nbsp;&nbsp;메뉴는 시스템 내부, 그 외 메뉴는 사랑 ON에서 실행됩니다.</span>
      </h1>
      <ul class="-pub-header__menu">
          <li class="-pub-header__item -pub-header__item--horizon">
              <fdp-text-field v-model="searchKeyword" class="-pub-header__input -pub-header__input--setting" placeholder="메뉴명"  @keyup.enter="onSearch" clearable></fdp-text-field>
              <button type="button" class="sp-submit-button sp-submit-button--setting sp-submit-button__icon" @click="onSearch"><img src="@/assets/img/ico_search_dark.png" alt="icon">조회</button>
          </li>
          <li class="-pub-header__item -pub-header__item--horizon"><button class="-pub-header__close"><img class="-pub-header__icon" src="@/assets/img/btn_popup_close_nor.png" alt="닫기"></button></li>
      </ul>
    </div>
    <div class="-pub-page-container -pub-page-container--setting">
        <div class="-pub-contents">
          <!-- 액티브되는 메뉴의 열에 따라 클래스가 다르게 붙어야함. (ex) -pub-active-1 부터 -pub-active-6 까지) -->
            <ul class="-pub-contents__menu -pub-active-slt -pub-active-1">
                <li v-for="(subMenu, idx) in mockData1" :key="idx" tabindex="1" :class="idx === 0 ? '-pub-first-menu--active' : ''" class="-pub-first-menu">
                    <img v-if="subMenu.isNew" class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">
                    <!-- <span>{{subMenu.label}}</span> -->
                     <span v-html="subMenu.label"></span>
                    <img v-if="subMenu.isGo" class="-pub-menu__icon -pub__icon-go" src="@/assets/img/ico_go.png" alt="">
                    <ul v-if="subMenu.menu">
                        <li v-for="(sub, idx) in subMenu.menu" :key="idx" tabindex="1" class="-pub-second-menu"><span v-html="getHighlightTitle(sub.label)">{{sub.label}}</span>
                            <ul v-if="sub.menu">
                                <li v-for="(subMenu, idx) in sub.menu" :key="idx" tabindex="1" class="-pub-third-menu">
                                    <img v-if="subMenu.isNew" class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">
                                    <img v-if="subMenu.isPinOn" class="-pub-menu__icon" alt="">
                                    <img v-if="subMenu.isPinOff" class="-pub-menu__icon" alt="">
                                    <span class="sub_menu_pos" v-html="getHighlightTitle(subMenu.label)"></span>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
  </section>
  <!-- 전체메뉴 : END -->

  <!-- 3. 전체메뉴 검색결과 없음  : START (searchMenuMocks) -->
  <section class="-pub-sitemap -pub-sitemap-search-none -pub-sitemap-load-file"  v-if="noData">
    <TSSBC111D></TSSBC111D>
    <div class="-pub-header -pub-header--setting">
      <h1 class="-pub-header__title -pub-header__title--setting">
          <span class="-pub-title__text">{{title}}</span><span class="-pub-title__text--desc"><img class="-pub-menu__icon -pub__icon-new" src="@/assets/img/icon_menu_new.png" alt="new">&nbsp;&nbsp;*&nbsp;&nbsp;메뉴는 시스템 내부, 그 외 메뉴는 사랑 ON에서 실행됩니다.</span>
      </h1>
      <ul class="-pub-header__menu">
          <li class="-pub-header__item -pub-header__item--horizon">
            <fdp-text-field v-model="searchKeyword" class="-pub-header__input -pub-header__input--setting" @keyup.enter="onSearch()" clearable></fdp-text-field>
            <button class="sp-submit-button sp-submit-button--setting sp-submit-button__icon" @click="onSearch()"><img src="@/assets/img/ico_search_dark.png" alt="icon">조회</button>
          </li>
          <li class="-pub-header__item -pub-header__item--horizon"><button class="-pub-header__close"><img class="-pub-header__icon" src="@/assets/img/btn_popup_close_nor.png" alt="닫기"></button></li>
      </ul>
    </div>
    <div class="-pub-page-container -pub-page-container--setting">
        <div class="-pub-contents">
          <div class="-pub-contents-result -pub-contents-result-bg"><img src="@/assets/img/ico_no_search_result.png" alt="검색결과 없음"></div>
          <span class="-pub-contents-result -pub-contents-result-txt">'{{resultWord}}'에 대한 검색결과가 없습니다.<br /> 검색어를 다시 확인해 주세요</span>
          <div class="-pub-contents-result -pub-contents-result-btn" @click="backSearch"><img src="@/assets/img/btn_back_gray.png" alt="돌아가기"></div>
        </div>
    </div>
  </section>
  <!-- 전체메뉴 계산 검색 : END -->
  </div>
</template>
<script>
// MOCK FILE
import { viewMenuMocks, searchMenuMocks } from '@/components/mock/TSSBC110M.mock' // 1번

// 우측 최근 사용화면
import TSSBC111D from '@/components/pages/2018-09-21/TSSBC111D'
export default {
  components: {
    TSSBC111D
  },
  mounted () {
    this.viewData = this.mockData1.slice()
  },
  data () {
    return {
      title: '전체메뉴',
      isClose: true,
      searchKeyword: '',
      resultWord: '',
      mockData1: Array.prototype.slice.call(viewMenuMocks), // 1번
      mockData2: Array.prototype.slice.call(searchMenuMocks), // 2번
      viewData: '',
      defaultUsage: {
        default: ''
      },
      tempListArr: [],
      tempList: {label: '', isGo: '', menu: []},
      tempLabel: '',
      tempLabel2: '',
      isAdd: false,
      tempMenu: [],
      tempMenu2: [],
      tempNew: true,
      tempIsgo: true,
      noData: false,
      dataSet: {label: '', isNew: false},
      dataMenuSet: {label: '', menu: []}
    }
  },
  methods: {
    onSearch () {
      this.mockData1 = this.viewData.slice()
      if (this.searchKeyword) {
        this.resultWord = this.searchKeyword
        for (var i = 0; i < this.mockData1.length; i++) {
          this.tempLabel = this.mockData1[i].label
          this.tempIsgo = this.mockData1[i].isGo

          for (var j = 0; j < this.mockData1[i].menu.length; j++) {
            this.tempLabel2 = this.mockData1[i].menu[j].label
            for (var k = 0; k < this.mockData1[i].menu[j].menu.length; k++) {
              if (this.mockData1[i].menu[j].menu[k].label.indexOf(this.searchKeyword) !== -1) {
                this.dataSet.label = this.mockData1[i].menu[j].menu[k].label
                this.dataSet.isNew = !!this.mockData1[i].menu[j].menu[k].isNew
                this.tempMenu2.push(this.dataSet)
                this.dataSet = {label: '', isNew: false}
              }
            }
            // 건져진게 있으면.. 또 생성
            if (this.tempMenu2.length > 0) {
              this.dataMenuSet.label = this.tempLabel2
              this.dataMenuSet.menu = this.tempMenu2
            }
            // this.tempMenu2.splice(0, this.tempMenu2.length)
            this.tempMenu2 = []
            if (this.dataMenuSet.label !== undefined && this.dataMenuSet.label !== '') {
              this.tempMenu.push(this.dataMenuSet)
              this.dataMenuSet = []
              this.isAdd = true
            }
          }
          if (this.isAdd) {
            let tempList = {label: '', isGo: '', menu: []}
            tempList.label = this.tempLabel
            tempList.isGo = this.tempIsgo
            tempList.menu = this.tempMenu
            this.tempListArr.push(tempList)
            this.tempMenu = []
            this.isAdd = false
          }
          this.tempLabel = ''
          this.tempIsgo = ''
        }
        if (this.tempListArr.length > 0) {
          this.mockData1 = this.tempListArr.slice()
          this.tempListArr = []
          this.noData = false
        } else {
          this.noData = true
          this.mockData1.splice(0, this.mockData1.length)
        }
      } else {
        this.mockData1 = this.viewData.slice()
        this.noData = false
      }
    },
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')
      return val.replace(regex, '<span class="-pub-search-color2">$1</span>')
    },
    backSearch () {
      this.searchKeyword = ''
      this.onSearch()
    }
  }
}
</script>
<style>
.-pub-search-color2 {
    color : #FE886A

}
</style>
