<template>
    <section class="-pub-notice-detail-page">
        <div class="-pub-customer-register__header">
            <h1 class="-pub-customer-register__title">
                <a class="-pub-customer-register__button -pub-customer-register__button--back">
                    <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
                </a>
                <span class="-pub-customer-register__text--parent-bottom">공지사항</span>
            </h1>
        </div>
        <div class="-pub-customer-register__content">
            <section class="-pub-section-content">
                <div class="-pub-section-left">
                    <!-- 페이지 조회 input, button 검색 영역  -->
                    <div class="-pub-filter-menu">
                        <div class="-pub-filter-menu__item--right">
                            <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
                            <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                                <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                            </button>
                        </div>
                        <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{resultData.length}}건</div>
                    </div>
                    <!-- 페이지 조회 input, button 검색 영역 end -->
                    <!-- 컨설턴트 테이블 -->
                    <fdp-infinite class="-pub-table" v-model="selectItems" @input="onClick" single-select :items="resultData" :table-body-height="974">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column" style="width: 110px;">구분</th>
                                <th class="-pub-table-column" style="width: 406px;">제목명</th>
                                <th class="-pub-table-column -pub-table-column--sorting" style="width: 170px;" @click="clickSortConsultantCd">
                                    <!-- sorting 활성화: -pub-sorting--active, 내림차순: defalt, 오름차순: -pub-sorting--up, 파란색: default, 보라색: -pub-sorting--purple -->
                                    <span :class="[{'-pub-sorting--active':true}, {'-pub-sorting--up':sortConsultantCd.isAsc}, {'-pub-sorting--purple':true}]">공지일자
                                    <img src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                                </span>
                                </th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column" style="width: 110px;" >{{props.item.data1}}</td>
                            <td class="-pub-table-column align-left" style="width: 406px;" ><img class="-pub-notice-item--new" src="@/assets/img/components/new-badge.png" alt="" v-if="props.item.isNew" />{{props.item.data2}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 170px;" >{{props.item.data3}}</td>
                        </template>
                        <!-- 검색결과 없을때 화면 -->
                        <template slot="emptyView" v-if="paramSearchKeyword">
                            <div class="empty-table-content">
                                <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                                <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                            </div>
                        </template>
                    </fdp-infinite>
                </div>
                <div class="-pub-section-right">
                    <!-- no data 화면 -->
                    <div class="empty-content" v-if="isShowEmpty">
                        <img src="@/assets/img/components/ico-no-result.png" class="empty-content__icon" />
                        <div class="empty-content__text">데이터가 존재하지 않습니다.</div>
                    </div>
                    <div class="-pub-notice-detail-desc" v-else>
                        <div class="-pub-writer-wrap">
                            <span>작성자</span>
                            <span>지점장</span>
                            <span>2017-03-01~2017-03-22</span>
                        </div>
                        <span class="-pub-notice-title">7/18 (월) To do List</span>
                        <fdp-toast ref="toast"></fdp-toast>
                        <ul class="-pub-attached-file-wrap">
                            <li>첨부파일 총 2건 (12.1MB)<img src="@/assets/img/btn_all_save.png" alt="모두저장" @click="download"></li>
                            <li>생.타.종 안내.pdf<img class="-pub-btn-download" src="@/assets/img/btn_download.png" alt="다운로드" @click="download"></li>
                            <li>미리썸머페스티벌 캠페인 상세 내용.pdf<img class="-pub-btn-download" src="@/assets/img/btn_download.png" alt="다운로드" @click="download"></li>
                        </ul>
                        <div class="-pub-notice-desc">
                            <span>- 생.타.종. 가입 설계서 발행<br>
                                    - 생.타.종 특공대 선발<br>
                                    - 콜로세움 JOB 설명회 초대<br>
                                    - 복합활동(카드, 증권)<br>
                                    - 미리썸머페스티벌 캠페인 사전 준비(CM)<br>
                                    - 생.타.종. 가입 설계서 발행</span>
                        </div>
                        <!-- 2차 범위 버튼 -->
                        <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-add-schedule">일정추가</button>
                        <!-- 2차 범위 버튼 -->
                    </div>
                </div>
            </section>
        </div>
    </section>

</template>
<script>
import viewMemberMocks from '@/components/mock/TSSBC151M.mock'

export default {
  data () {
    return {
      mockData: Array.prototype.slice.call(viewMemberMocks),
      resultData: Array.prototype.slice.call(viewMemberMocks),
      selectItems: null,
      searchKeyword: '',
      paramSearchKeyword: '',
      sortConsultantCd: {isAsc: true},
      isShowEmpty: true
    }
  },
  computed: {
    isClickedItem () {
      return this.selectItems
    }
  },
  methods: {
    // 소팅 처리
    clickSortConsultantCd () {
      this.sortConsultantCd.isAsc = !this.sortConsultantCd.isAsc

      // Mockup 데이터
      let data = this.resultData

      if (this.sortConsultantCd.isAsc) {
        data.sort(
          function (a, b) { return a.data3.localeCompare(b.data3) }
        )
      } else {
        data.sort(
          function (a, b) { return b.data3.localeCompare(a.data3) }
        )
      }
    },
    onSearch () {
      this.paramSearchKeyword = this.searchKeyword
      if (this.searchKeyword === '1') {
        this.resultData = []
      } else {
        this.resultData = this.mockData
      }
    },
    onClick (b) {
      this.isShowEmpty = !b.data4
    },
    download () {
      this.$refs.toast.makeToast('저장이 완료되었습니다.')
    }
  }
}
</script>
