<template>
    <section class="-pub-customer__detail--contract">
        <!-- 보유계약 start -->
        <div class="-pub-customer__detail--title">
            <span class="-pub-title">보유계약</span><span class="-pub-total">({{this.contList.length}}건)</span>
        </div>
        <div class="-pub-customer__noData" v-if="this.contList.length<2">
            <span>보유 계약이 없습니다.</span>
        </div>
        <div class="-pub-customer__contract">
            <ul class="-pub-customer__contract--item-group">
                <li class="-pub-customer__contract--item" v-for="(cont, idx) in contList" :key="idx" v-if="!showAll?idx<3:true">
                    <dl class="-pub-customer__contract--item-box">
                        <dt class="-pub-item-tit">{{cont.title}}</dt>
                        <dd class="-pub-item-cont">
                            <div :class="cont.status?'-pub-item-normal':'-pub-item-fail'">{{cont.statusNm}}</div>
                            <div class="-pub-item-number">{{cont.plcyNo}}</div>
                            <div class="-pub-item-insured">{{cont.insured}}</div>
                        </dd>
                        <dd class="-pub-item-price">월 {{cont.price}}</dd>
                    </dl>
                </li>
            </ul>
        </div>
        <div class="-pub-detail-form__view" v-if="this.contList.length>3">
            <!-- 전체보기 버튼 영역 start -->
            <a class="-pub-filter-menu__item -pub-filter-menu__detail-button -pub-filter-menu__detail-button--sub" :class="[{'-pub-filter-menu__detail-button--active': showAll}]" @click="showAll = !showAll ">
            <span>전체보기</span>
            <img class="-pub-filter-menu__icon -pub-filter-menu__icon--right" src="@/assets/img/customer/ico_arrow_down_black.png" alt="">
            </a>
            <!-- 전체보기 버튼영역 end -->
        </div>
        <!-- 보유계약 end -->
        <!-- 최근 설계한 상품 start -->
        <div class="-pub-customer__detail--title -pub-customer__product--title">
            <span class="-pub-title">최근 설계한 상품</span><span class="-pub-total">({{this.prdList.length}}건)</span>
            <div class="-pub-popup__title-button">
                <button type="button" class="-pub-button -pub-button--purple">
                    <span class="-pub-button__text">가입설계</span>
                </button>
            </div>
        </div>
        <div class="-pub-customer__noData" v-if="this.prdList.length<1">
            <span>최근 설계한 상품이 없습니다.</span>
        </div>
        <div class="-pub-customer__product" v-else>
            <ul class="-pub-customer__product--item-group" >
                <li class="-pub-customer__product--item" v-for="(prd, idx) in prdList" :key="idx">
                    <dl class="-pub-customer__product--item-box">
                        <dt class="-pub-item-tit">{{prd.title}}</dt>
                        <dd class="-pub-item-date">{{prd.date}}</dd>
                        <dd class="-pub-item-price">{{prd.price}}</dd>
                    </dl>
                </li>
            </ul>
        </div>
        <!-- 최근 설계한 상품 end -->
        <!-- 컨설팅 start -->
        <div class="-pub-customer__detail--title">
            <span class="-pub-title">컨설팅</span>
        </div>
        <!-- <div class="-pub-customer__noData" v-if="this.consultList.length<1">
            <span>컨설팅 내역이 없습니다.</span>
        </div> -->
        <!-- <div class="-pub-customer__consulting" v-else>
            <ul class="-pub-customer__consulting--item-group">
                <li class="-pub-customer__consulting--item" v-for="(consult, idx) in consultList" :key="idx">
                    <span class="-pub-item-family">{{consult.title}}</span><span class="-pub-item-number">{{consult.no}}</span><span class="-pub-item-persent">%</span>
                </li>
            </ul>
        </div> -->
        <!-- 20181030 기획변경으로 인한 수정-->
        <div class="-pub-customer__consulting">
            <ul class="-pub-customer__consulting--item-group">
                <li class="-pub-customer__consulting--item life-analysis">
                    <span class="life-tit">라이프분석</span>
                    <span class="life-update">2017-04-30</span>
                    <!-- <div class="life-start-button">
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--light">
                            <span class="-pub-button__text">시작하기</span>
                        </button>
                    </div> -->
                </li>
                <li class="-pub-customer__consulting--item security-analysis">
                    <span class="security-tit">보장분석</span>
                    <div class="security-start-button">
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--light">
                            <span class="-pub-button__text">시작하기</span>
                        </button>
                    </div>
                </li>
            </ul>
        </div>
        <!-- 컨설팅 end -->
    </section>
</template>
<script>
export default {
  data () {
    return {
      showAll: false,
      // 데이터 있을 때 없을때 각각 주석 처리하여 확인 가능
      //   contList: [],
      //   prdList: [],
      //   consultList: [],

      contList: [{
        'title': '통합유니버셜종신보험 3.0(무)',
        'status': true,
        'statusNm': '정상',
        'plcyNo': '1111125050',
        'price': '15,000 원',
        'insured': '피보험자 : 자녀김지윤'
      },
      {
        'title': '통합유니버셜종신보험 4.0(무)',
        'status': false,
        'statusNm': '유예',
        'plcyNo': '2111125050',
        'price': '25,000 원'
      },
      {
        'title': '통합유니버셜종신보험 5.0(무)',
        'status': false,
        'statusNm': '실효',
        'plcyNo': '3111125050',
        'price': '35,000 원'
      },
      {
        'title': '통합변액유니버설CI종신보험6.0',
        'status': true,
        'statusNm': '정상',
        'plcyNo': '4111125050',
        'price': '45,000 원'
      }
      ],
      prdList: [{
        'title': '통합변액유니버설CI종신보험3.0',
        'date': '06-22 16:23',
        'price': '22,500원'
      },
      {
        'title': '통합변액유니버설CI종신보험2.0',
        'date': '09-22 12:23',
        'price': '42,500원'
      },
      {
        'title': '통합변액유니버설CI종신보험5.0',
        'date': '11-22 16:23',
        'price': '82,500원'
      },
      {
        'title': '통합변액유니버설CI종신보험6.0',
        'date': '02-22 16:23',
        'price': '72,500원'
      }
      ],
      consultList: [{
        'title': '가족',
        'no': '35'
      },
      {
        'title': '생활',
        'no': '20'
      },
      {
        'title': '의료',
        'no': '40'
      },
      {
        'title': '노후',
        'no': '10'
      }
      ]

    }
  }
}
</script>
