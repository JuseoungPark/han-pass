<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="타사증권입력" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup">
        <div class="-pub-consulting-popup__default-info" :class="{'-pub-consulting-popup__default-info--visible':showSelectContent}">
          <div class="-pub-consulting-popup__default-content">
            <h3 class="-pub-consulting-popup__title -pub-consulting-popup__row-item">보험 상품</h3>
            <p class="-pub-consulting-popup__product-name -pub-consulting-popup__row-item">{{selectItems.name}}</p>
            <button type="button" class="-pub-button -pub-button--reselection -pub-button--reselection--light -pub-consulting-popup__row-item"
              @click="showSelectContent = !showSelectContent">
              <span class="-pub-button__text">재선택</span>
            </button>
          </div>
          <div class="-pub-consulting-popup__active-content">
            <div class="-pub-consulting-popup__search-row">
              <h3 class="-pub-consulting-popup__title -pub-consulting-popup__row-item">보험 상품</h3>
              <fdp-validator name="insurance-product" display-name="보험상품" v-model="radio1.value" :rules="'required'">
                <fdp-radio class="-pub-radio -pub-consulting-popup__row-item" v-for="(name, idx) in radio1.items"
                  v-model="radio1.value" :key="idx" :value="name">{{name}}</fdp-radio>
              </fdp-validator>
            </div>
            <template v-if="radio1.value === '등록상품'">
              <div class="-pub-consulting-popup__search-row">
                <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">가입회사</div>
                <fdp-validator name="company-type" display-name="가입회사" v-model="segment1.value" :rules="'required'">
                  <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                    v-model="segment1.value" :data="segment1.items" :essential="true"></fdp-segment-box>
                </fdp-validator>
                <fdp-validator name="company-name" display-name="가입회사" v-model="select1.value.key" :rules="'required'">
                  <fdp-select class="-pub-select -pub-filter-menu__item--select select-company" v-model="select1.value"
                    :option-list="select1.items" placeholder="보험사명"></fdp-select>
                </fdp-validator>
              </div>
              <div class="-pub-consulting-popup__search-row">
                <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">상품명</div>
                <fdp-validator name="product-type" display-name="상품명" v-model="segment2.value" :rules="'required'">
                  <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                    v-model="segment2.value" :data="segment2.items" :essential="true"></fdp-segment-box>
                </fdp-validator>
                <fdp-validator name="product-name" display-name="상품명" v-model="searchKeyword" :rules="'required'">
                  <fdp-text-field class="-pub-text-field search-field" v-model="searchKeyword" placeholder="상품명"
                    clearable></fdp-text-field>
                </fdp-validator>
                <button type="button" class="-pub-search-button" @click="isIntial = false; runSearch();">
                  <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                </button>
              </div>
              <fdp-infinite class="-pub-table -pub-table--blue" v-model="selectItems" single-select :table-body-height="464"
                :items="mockData">
                <template slot="header">
                  <tr class="-pub-table__header">
                    <th class="-pub-table-column" style="width: 100%; padding:0;">
                      <span class="-pub-table-column__text">상품명</span>
                    </th>
                  </tr>
                </template>
                <template slot-scope="props">
                  <td class="-pub-table-column--checkbox">
                    <fdp-radio class="-pub-radio -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
                      v-model="selectItems" :value="props.item"></fdp-radio>
                  </td>
                  <td class="-pub-table-column align-left" style="width: 100%;" v-html="props.item.searchKeywordBindName ? props.item.searchKeywordBindName : props.item.name"></td>
                </template>
                <template slot="emptyView">
                  <div class="-pub-table-empty-view -pub-table-empty-view--fix-height" v-if="isIntial">등록하실 증권을 검색하세요.</div>
                  <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height"
                    v-else>검색결과가 존재하지 않습니다.</div>
                </template>
              </fdp-infinite>
            </template>
          </div>
        </div>
        <!-- 보험기본정보 -->
        <template v-if="radio1.value === '등록상품'">
          <div class="-pub-consulting-popup__default-info -pub-consulting-popup__default-info--sub" :class="{'-pub-consulting-popup__default-info--visible': !showSelectContent}">
            <div class="-pub-consulting-popup__default-content -pub-consulting-popup__default-info--bordered-top">
              <h3 class="-pub-consulting-popup__title -pub-consulting-popup__row-item">보험 기본 정보</h3>
            </div>
            <div class="-pub-consulting-popup__active-content">
              <h3 class="-pub-consulting-popup__title -pub-consulting-popup__search-row -pub-consulting-popup__row-item">보험
                기본 정보</h3>
              <div class="-pub-consulting-popup__content">
                <ul class="-pub-consulting-popup__content-item">
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">보험대상자</div>
                    <fdp-validator name="tssct005p-validator6" display-name="보험대상자" v-model="select2.value.key" :rules="'required'">
                      <fdp-select class="-pub-select -pub-filter-menu__item--select select-default" v-model="select2.value"
                        :option-list="select2.items"></fdp-select>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">피보험자구분</div>
                    <fdp-validator name="tssct005p-validator7" display-name="피보험자구분" v-model="segment3.value" :rules="'required'">
                      <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                        v-model="segment3.value" :data="segment3.items" :essential="true"></fdp-segment-box>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">계약자</div>
                    <fdp-validator name="tssct005p-validator8" display-name="계약자" v-model="contractor" :rules="'required'">
                      <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small"
                        v-model="contractor"></fdp-text-field>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">계약년월</div>
                    <fdp-validator name="tssct005p-validator9" display-name="계약년월" v-model="date1" :rules="'required'">
                      <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small"
                        minimumView="month" initialView="month" v-model="date1" format="yyyy-MM"></fdp-date-picker>
                    </fdp-validator>
                  </li>
                </ul>
                <ul class="-pub-consulting-popup__content-item -pub-consulting-popup__content-item--sub">
                  <li class="-pub-consulting-popup__search-row -pub-consulting-popup__date-area">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">만기년월</div>
                    <fdp-validator name="tssct005p-validator10" display-name="만기년월" v-model="date2" :rules="'required'">
                      <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small"
                        minimumView="month" initialView="month" v-model="date2" format="yyyy-MM" :disabled="date2Life"></fdp-date-picker>
                    </fdp-validator>
                    <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="date2Life">종신</fdp-checkbox>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">납입주기</div>
                    <fdp-validator name="tssct005p-validator11" display-name="납입주기" v-model="select3.value.key" :rules="'required'">
                      <fdp-select class="-pub-select -pub-filter-menu__item--select select-default" v-model="select3.value"
                        :option-list="select3.items"></fdp-select>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">납입완료</div>
                    <fdp-validator name="tssct005p-validator12" display-name="납입완료" v-model="date2" :rules="'required'">
                      <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small"
                        minimumView="month" initialView="month" v-model="date2" format="yyyy-MM"></fdp-date-picker>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">보험료(원)</div>
                    <fdp-validator name="tssct005p-validator13" display-name="보험료" v-model="insurance" :rules="'required'">
                      <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small normal-letter"
                        v-model="insurance" mask="won"></fdp-text-field>
                    </fdp-validator>
                  </li>
                  <li class="-pub-consulting-popup__search-row">
                    <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">예정이율(%)</div>
                    <fdp-validator name="tssct005p-validator14" display-name="예정이율" v-model="interestRate" :rules="'required'">
                      <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small normal-letter"
                        v-model="interestRate" mask="number"></fdp-text-field>
                    </fdp-validator>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </template>
        <TSSCT018P v-else></TSSCT018P>
      </div>
      <!-- 하단 버튼 고정 start -->
      <div class="-pub-bottom-bar">
        <span class="-pub-bottom-nav__item -pub-bottom-nav__item--centered  -pub-guide-text -pub-guide-text--icon align-left" v-if="radio1.value === '미등록상품'">
            정기보험 상품 입력시 특약만기가 틀릴 경우 특약만기년도를 클릭하여<br>장해/진단/수술/입원/치료 특약만기년도를 별도 체크해 주세요.
        </span>
        <div class="-pub-confirm__content--right">
          <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
          </button><button type="button" class="-pub-button -pub-button--next">
            <span class="-pub-button__text">다음</span>
            <img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼">
          </button>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  mockData
} from '@/components/mock/TSSCT005P.mock'

import TSSCT018P from '@/components/pages/2018-10-12/TSSCT018P'
export default {
  components: {
    TSSCT018P
  },
  data () {
    return {
      showSelectContent: true,
      showPopup: true,
      isIntial: true,
      name: '',
      mockDataCopy: Array.prototype.slice.call(mockData),
      date2Life: false,
      selectItems: {},
      mockData: [],
      date1: '2017-01',
      date2: '2017-03',
      date3: '2017-07',
      contractor: '이주명',
      insurance: '35,000',
      interestRate: '0',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },

      segment1: {
        items: [{
          key: '1',
          label: '생명보험'
        },
        {
          key: '2',
          label: '손해보험'
        }
        ],
        value: [{
          key: '1',
          label: '생명보험'
        }]
      },
      segment2: {
        items: [{
          key: '1',
          label: '일반'
        },
        {
          key: '2',
          label: '유니버셜'
        }
        ],
        value: [{
          key: '1',
          label: '주피'
        }]
      },
      segment3: {
        items: [{
          key: '1',
          label: '주피'
        },
        {
          key: '2',
          label: '종피'
        }
        ],
        value: [{
          key: '1',
          label: '주피'
        }]
      },
      select1: {
        value: {
          key: '1',
          label: '교보생명'
        },
        items: [{
          key: '1',
          label: '교보생명'
        }]
      },
      select2: {
        value: {
          key: '1',
          label: '이주명'
        },
        items: [{
          key: '1',
          label: '이주명'
        }]
      },
      select3: {
        value: {
          key: '1',
          label: '월납'
        },
        items: [{
          key: '1',
          label: '월납'
        }]
      },
      searchKeyword: ''
    }
  },
  methods: {
    runSearch () {
      this.mockData = this.getFilterKeyword(this.searchKeyword)
    },
    getFilterKeyword (searchKeyword = '') {
      return !searchKeyword ? this.mockDataCopy : this.mockDataCopy.reduce((pre, cur) => {
        const regExp = new RegExp(`(${searchKeyword})`)
        if (regExp.test(cur.name)) {
          pre.push(Object.assign({}, cur, {
            searchKeywordBindName: cur.name.replace(regExp,
              `<span class="search-filter-text">${searchKeyword}</span>`)
          }))
        }
        return pre
      }, [])
    }
  },
  watch: {
    selectItems (newValue) {
      if (newValue.name) {
        this.showSelectContent = false
      }
    }
  }
}
</script>
