<template>
  <section class="-pub-consulting">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">라이프분석</span>
      </h2>
      <div class="-pub-page-header__content">
        <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--icon">
          <img src="@/assets/img/components/ico-family-select.png" alt="불러오기">
          <span>불러오기</span>
        </a>
        <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--icon -pub-page-header__button--last">
          <img src="@/assets/img/customer/ico-customer.png" alt="정보제공동의">
          <span>정보제공동의</span>
        </a>
        <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--gray -pub-tooltip-menu--type-3" v-model="currMenu2" :menu-list="menuListSample2" bottom>
          <div class="-pub-button--tooltip -pub-page-header__icon">
            <img src="@/assets/img/components/btn-gnb-consulting.png" alt="">
          </div>
        </fdp-tooltip-menu>
      </div>
    </div>
    <TSSC022M></TSSC022M>
  </section>
</template>
<script>
import TSSC022M from '@/components/pages/2018-09-21/consulting-contents/TSSCT022M'

export default {
  components: {
    TSSC022M
  },
  watch: {
    currentContent (val) {
      if (val) {
        console.log(val)
        this.contentRadioValue = val.contentRadios[0]
      }
    }
  },
  computed: {
    currentRadios () {
      return (this.currentContent && this.currentContent.contentRadios) || []
    }
  },
  data () {
    return {
      currMenu2: '',
      contentRadioValue: '',
      currentContent: {},
      menuListSample: [{
        label: '인쇄/이메일',
        key: '4'
      }],
      menuListSample2: [{
        label: '보장분석',
        key: 'email'
      },
      {
        label: '연금계산기',
        key: 'dm'
      },
      {
        label: '상속계산기',
        key: '1'
      },
      {
        label: '가족력',
        key: '2'
      }]
    }
  },
  methods: {}
}
</script>
