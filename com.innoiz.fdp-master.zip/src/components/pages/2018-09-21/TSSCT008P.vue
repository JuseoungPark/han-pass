<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="타사증권입력" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup">
        <div class="-pub-consulting-popup__default-info -pub-consulting-popup__default-info--fixed">
          <div class="-pub-consulting-popup__default-content">
            <div class="-pub-consulting-popup__product-info">
              <h4 class="-pub-consulting-popup__product-name">교보생명 통합유니버셜종신보험 3.0(무)</h4>
              <span class="-pub-consulting-popup__customer-info"><span class="-pub-serapetor-line">계약자 : 이주명</span><span class="-pub-serapetor-line">피보험자 : 이주명(종피) </span><span class="-pub-serapetor-line normal-letter">2017-01 ~ 2020-01 / 2037-01</span></span>
            </div>
            <span class="-pub-consulting-popup__product-month-amount">월<span class="bold-text">32,000</span>원</span>
            <button type="button" class="-pub-button -pub-button--update -pub-consulting-popup__row-item">
              <span class="-pub-button__text">수정</span>
            </button>
          </div>
          <div class="-pub-consulting-popup__active-content">
            <h3 class="-pub-consulting-popup__title -pub-consulting-popup__title--type-2">
              보장내역
              <div class="-pub-consulting-popup__unit">단위: 만원</div>
            </h3>
            <ul class="-pub-consulting-popup__grid">
              <li class="-pub-consulting-popup__column" v-for="(column, index) in mockData" :key="index">
                <ul class="-pub-consulting-popup__group" v-for="(group, index2) in column" :key="'a' + index + index2">
                  <li class="-pub-consulting-popup__head">
                    {{group.category}}
                  </li>
                  <li class="-pub-consulting-popup__row" v-for="(data, index3) in group.data" :key="'b' + index + index2 + index3">
                    <div class="-pub-consulting-popup__grid-title">{{data.label}}</div>
                    <fdp-validator :name="'tssct008p-validator' + index + '-' + index3" v-model="data.value" :rules="'required'" :display-name="data.label">
                      <fdp-text-field class="-pub-text-field -pub-consulting-popup__table-field-2 normal-letter" v-model="data.value" mask="won" placeholder="0"></fdp-text-field>
                    </fdp-validator>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="-pub-bottom-bar">
        <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-guide-text align-left" >
          ※ 입원보장과 통원치료는 천원단위까지 입력 가능합니다. 예)2만 5천원 = 2.5<br>
          ※ 타사 실손의료보험 보장내역의 입원, 통원, 처방조제비란에는 각각 항목별 보장한도 금액을 입력 하시기 바랍니다.
        </div>
        <div class="-pub-confirm__content--right">
          <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
          </button><button type="button" class="-pub-button -pub-button--reverse">
            <span class="-pub-button__text">등록</span>
          </button>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  mockData
} from '@/components/mock/TSSCT008P.mock'
export default {
  data () {
    return {
      showSelectContent: true,
      showPopup: true,
      isIntial: true,
      name: '',
      selectItems: [],
      mockData: Array.prototype.slice.call(mockData),
      // mockData: [],
      date1: '2017-01',
      searchKeyword: '207,130',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },
      segment1: {
        items: [{
          key: '1',
          label: '생명보험'
        },
        {
          key: '2',
          label: '손해보험'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment2: {
        items: [{
          key: '1',
          label: '일반'
        },
        {
          key: '2',
          label: '유니버셜'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      segment3: {
        items: [{
          key: '1',
          label: '주피'
        },
        {
          key: '2',
          label: '종피'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      select1: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '교보생명'
        }]
      },
      select2: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '이주명'
        }]
      },
      select3: {
        value: {
          key: '1'
        },
        items: [{
          key: '1',
          label: '월납'
        }]
      }
    }
  },
  computed: {
    isSelectAll () {
      return this.selectItems.length > 0
    }
  },
  methods: {
    selectAllItemsFunc (isSelectAll) {
      this.selectItems = isSelectAll ? [] : Array.prototype.slice.call(this.mockData)
    }
  }

}
</script>
