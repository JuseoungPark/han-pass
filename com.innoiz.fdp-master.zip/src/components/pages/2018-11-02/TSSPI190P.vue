<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="고객선택" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <!-- 세대조정 Start -->
            <div class="-pub-popup__edit-customer_slt">
                <div class="-pub-popup__content-body">
                    <!-- 왼쪽 영역 start -->
                    <div class="-pub-popup-content__left">
                        <div class="-pub-popup-content__tit">세대 선택</div>
                        <!-- 페이지 조회 input, button 검색 영역  -->
                        <div class="-pub-filter-menu">
                            <div class="-pub-filter-menu__item--right">
                                <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple"
                                    placeholder="고객명" v-model="searchKeywordOrigin" clearable @keyup.enter="clickSearchKeywordOrigin"></fdp-text-field>
                                <button type="button" class="-pub-search-button -pub-filter-menu__item" @click="clickSearchKeywordOrigin">
                                    <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                                </button>
                            </div>
                            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}명</div>
                        </div>
                        <!-- 페이지 조회 input, button 검색 영역 end -->
                        <fdp-infinite class="-pub-table" v-model="selectOrigin" single-select :items="mockData" :table-body-height="580" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">&nbsp;</th>
                                    <th class="-pub-table-column" style="width: 122px;">고객명</th>
                                    <th class="-pub-table-column" style="width: 100px;">나이</th>
                                    <th class="-pub-table-column" style="width: 172px;">생년월일</th>
                                    <th class="-pub-table-column" style="width: 100px;">성별</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-radio class="-pub-radiobox -pub-radiobox--empty-label -pub-radiobox--purple" v-model="selectOrigin" :value="props.item"></fdp-radio>
                                <td class="-pub-table-column -pub-table-column--name" style="width: 122px;">{{props.item.name}}</td>
                                <td class="-pub-table-column" style="width: 100px;">{{props.item.data4}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 172px;">{{props.item.date}}</td>
                                <td class="-pub-table-column" style="width: 100px;">{{props.item.gander}}</td>
                            </template>
                            <template slot="emptyView">
                            <!-- no data 화면 -->
                                <div class="empty-table-content" v-if="isEmptySearchKeywordOrigin">
                                    <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">고객명 입력 후 검색해 주세요.</div>
                                </div>
                            <!-- 검색결과 없을때 화면 -->
                                <div class="empty-table-content" v-else>
                                    <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                    </div>
                    <!--// 왼쪽 영역 end -->
                    <!-- 오른쪽 영역 start -->
                    <div class="-pub-popup-content__right">
                        <div class="-pub-popup-content__tit">주피보험자 선택</div>
                        <!-- 페이지 조회 input, button 검색 영역  -->
                        <div class="-pub-filter-menu">
                            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockAddMember.length}}명</div>
                        </div>
                        <!-- 페이지 조회 input, button 검색 영역 end -->
                        <fdp-infinite class="-pub-table" v-model="selectAddMember" single-select :items="mockAddMember" :table-body-height="530" :tableMinWidth="452">
                            <template slot="header">
                                <tr class="-pub-table__header">
                                    <th class="-pub-table-column--radiobox" style="width: 78px;">&nbsp;</th>
                                    <th class="-pub-table-column" style="width: 122px;">고객명</th>
                                    <th class="-pub-table-column" style="width: 100px;">나이</th>
                                    <th class="-pub-table-column" style="width: 172px;">생년월일</th>
                                    <th class="-pub-table-column" style="width: 100px;">성별</th>
                                </tr>
                            </template>
                            <template slot-scope="props">
                                <td class="-pub-table-column--radiobox" style="width: 78px;">
                                    <fdp-radio class="-pub-radiobox -pub-radiobox--empty-label -pub-radiobox--purple" v-model="selectAddMember" :value="props.item"></fdp-radio>
                                <td class="-pub-table-column -pub-table-column--name" style="width: 122px;">{{props.item.name}}</td>
                                <td class="-pub-table-column" style="width: 100px;">{{props.item.data4}}</td>
                                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 172px;">{{props.item.date}}</td>
                                <td class="-pub-table-column" style="width: 100px;">{{props.item.gander}}</td>
                            </template>
                            <template slot="emptyView">
                                <!-- 좌측 영역에서 세대를 먼저 선택하세요 -->
                                <div class="empty-table-content" v-if="hasMockData && !isEmptySearchKeywordAddMember"><!-- v-if="!isEmptySearchKeywordAddMember" -->
                                    <img src="@/assets/img/ico_hand_tap.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">좌측 영역에서 세대를 먼저 선택하세요</div>
                                </div>
                                <!-- 검색결과 없을때 화면 -->
                                <div class="empty-table-content" v-else>
                                    <img src="@/assets/img/ico_no_result@3x.png" class="empty-table-content__icon" />
                                    <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                                </div>
                            </template>
                        </fdp-infinite>
                    </div>
                    <!--// 오른쪽 영역 end -->
                </div>
            </div>
            <!--// 세대조정 end -->
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar -pub-bottom-bar__190p">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button -pub-button--purple" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button>
                    <button type="button" class="-pub-button -pub-button--confirm" :disabled="!hasAddMemberKey">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSPI190P.mock'

export default {
  data () {
    return {
      showPopup: true,
      vipGroupName: '',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      mockDataOrigin: Array.prototype.slice.call(viewMemberMocks),
      mockAddMember: [],
      mockAddMemberData: [
        {
          key: 1,
          name: '김바다',
          data4: '49',
          date: '1987-01-03',
          gander: '남'
        },
        {
          key: 2,
          name: '안종하',
          data4: '57',
          date: '1990-02-07',
          gander: '여'
        },
        {
          key: 3,
          name: '김밤담',
          data4: '50',
          date: '1972-11-25',
          gander: '남'
        }
      ],
      searchKeywordOrigin: '',
      searchKeywordOrigin2: '',
      isEmptySearchKeywordOrigin: true,
      isEmptySearchKeywordAddMember: false,
      selectOrigin: {},
      selectAddMember: {}
    }
  },
  methods: {
    clickSearchKeywordOrigin () {
      this.searchKeywordOrigin2 = this.searchKeywordOrigin
      if (this.searchKeywordOrigin2 !== '김바') {
        this.selectOrigin = {}
      }
    }
  },
  watch: {
    // table내 record가 갖는 radiobox 선택 시 후처리 (현재 세대)
    selectOrigin () {
      this.selectAddMember = {}

      if (this.selectOrigin.key === 2) {
        this.mockAddMember.splice(0, this.mockAddMember.length)
        this.isEmptySearchKeywordAddMember = true
      } else if (this.selectOrigin.key) {
        if (!this.hasAddMember) {
          for (let i = 0; i < this.mockAddMemberData.length; i++) {
            this.mockAddMember.push(this.mockAddMemberData[i])
          }
        }
        this.isEmptySearchKeywordAddMember = false
      } else {
        this.mockAddMember.splice(0, this.mockAddMember.length)
        this.isEmptySearchKeywordAddMember = false
      }
    },
    // 고객명으로 검색 시 검색결과 나오게 설정
    searchKeywordOrigin2 () {
      if (this.searchKeywordOrigin2 === '김다') {
        this.isEmptySearchKeywordOrigin = false
        this.mockData = []
      } else if (this.searchKeywordOrigin2 === '김바') {
        this.isEmptySearchKeywordOrigin = false
        this.mockData = this.mockDataOrigin
      } else {
        this.isEmptySearchKeywordOrigin = true
        this.mockData = []
      }
    }
  },
  computed: {
    hasMockData () {
      return !!this.mockData.length > 0
    },
    hasAddMember () {
      return !!this.mockAddMember.length > 0
    },
    hasAddMemberKey () {
      return !!Object.keys(this.selectAddMember).length > 0
    }
  }
}
</script>
