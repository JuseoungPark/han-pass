<template>
    <section class="-pub-product-suitability__wrap">
        <div class="-pub-product-suitability__content">
            <h2>고객정보 입력</h2>
            <dl class="-pub-product-suitability__customer -pub-product-suitability__customer-name">
                <dt>고객명</dt>
                <dd>
                    <fdp-validator name="tsspi720-validator-1" display-name="고객명" v-model="customerTypingName" :rules="'required'">
                        <fdp-text-field class="-pub-input--purple -pub-product-suitability__customer-input" v-model="customerTypingName" @keyup.enter="enterName()" fixedIcon placeholder="입력해주세요"></fdp-text-field>
                    </fdp-validator>
                </dd>
            </dl>
            <dl v-show="hasCustomerName" class="-pub-product-suitability__customer -pub-product-suitability__customer-phone">
                <dt>휴대폰번호</dt>
                <dd><span class="num">010-1234-5678</span></dd>
            </dl>
            <dl v-show="hasCustomerName" class="-pub-product-suitability__customer -pub-product-suitability__customer-email">
                <dt>이메일</dt>
                <dd>
                    <span class="en">abcdef@naver.com</span>
                    <p class="txt">※ 이메일 주소가 틀리거나 없는 경우에는 계약서류 및 작성된 전자문서를 이메일로 받으실 수 없습니다.</p>
                </dd>
            </dl>
            <div class="-pub-product-suitability__term">
                <h2>위험성향(적합성) 진단</h2>
                <ul class="-pub-product-suitability__term-list">
                    <li>위험성향진단 설문을 하시면 고객님의 위험성향에 맞는 변액보험 가입상담 및 권유가 가능합니다.</li>
                    <li>· 변액보험 가입을 희망하는 경우 위험성향진단을 해주셔야 합니다.</li>
                    <li>· 고객님의 위험성향에 따라 가입 가능한 변액보험 상품이 제한될 수 있으며, 위험성향에 맞지 않는 상품에 가입하실 경우 별도의 확인절차가 필요합니다.</li>
                    <li>· 잘못된 답변 또는 불성실한 답변은 고객님에게 적합하지 않은 상품을 추천하게 되는 결과를 가져올 수 있으니 신중한 답변을 부탁드립니다.</li>
                </ul>
                <h2>위험성향진단 질문지란?</h2>
                <ul class="-pub-product-suitability__term-list">
                    <li>
                        고객님의 위험성향을 파악하여 적합한 보험상품을 권유하기 위한 기초자료 이며, 고객님을 위한 보호장치입니다.<br>위험성향진단절차는 보험업법 제 95조 3항 및 생명보험협회 변액보험 계약 권유준칙에 근거하고 있으며 모든 생명보험회사가 시행하고 있는 제도입니다.
                    </li>
                </ul>
                <div class="btn-area-right">
                    <button type="button" class="-pub-button -pub-product-suitability__term-button"><span>위험성향 및 상품분류</span></button>
                </div>
            </div>
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed-top -pub-bottom-bar--full" v-show="true">
            <p class="-pub-bottom-nav__txt"> ※ 적합성 진단이 완료되어야 변액보험 가입상담 및 권유가 가능합니다.</p>
            <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                <button type="button" class="-pub-button -pub-button--purple -pub-button--next -pub-button--reverse">다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png" alt="다음 버튼"></button>
            </div>
        </fdp-bottom-bar>
    </section>
</template>
<script>
export default {
  data () {
    return {
      customerName: '',
      customerTypingName: ''
    }
  },
  // 고객명에 값 넣고 enter 누르면 고객명 검색된것처럼 처리
  methods: {
    enterName () {
      this.customerName = this.customerTypingName
    }
  },
  // 고객명 검색 후 휴대폰과 이메일 보이게 처리
  computed: {
    hasCustomerName () {
      return !!this.customerName.length > 0
    }
  }
}
</script>
