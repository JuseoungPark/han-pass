<template>
    <!-- 고객선택 start -->
    <div class="-pub-product-join__content">
        <div class="-pub-product-join__content--title">
            <h2>고객 선택</h2>
            <div class="-pub-product-join__content--segment">
                <fdp-segment-box class="-pub-segment--medium -pub-segment__container -pub-segment--purple" v-model="planType" :data="planTypes" essential></fdp-segment-box>
            </div>
        </div>
        <div class="-pub-product-join__form">
            <!-- 일반고객 segment content start -->
            <form v-if="planType[0].key==='1'">
                <ul class="-pub-product-join__form--list">
                    <!-- 주피 start -->
                    <li class="-pub-product-join__form--list-item -pub-product-join__form--list-grade">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--beneficiary">주피</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>고객명<span class="-pub-required"></span></label>
                                        <fdp-validator name="tsspi190d-validator-1" display-name="고객명" v-model="formInput.beneName" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.beneName" fixedIcon @keyup.enter="searchCustomer" placeholder="검색하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>직업<span class="-pub-required"></span></label>
                                    <fdp-text-field  class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.beneJob" disabled></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>차량<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-2" display-name="차량" v-model="formInput.beneCar.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.beneCar" :option-list="carItems1" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종상해<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.beneSgrade" readonly></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종일반<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.beneNgrade" readonly></fdp-text-field>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- 주피 end -->
                    <!-- 계약자 start -->
                    <li class="-pub-product-join__form--list-item">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--contractor">계약자</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>고객명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-3" display-name="고객명" v-model="formInput.contName.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.contName" :option-list="houseHoldList" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                    <button type="button" class="-pub-button -pub-product-join__form--list-column-button"><span>단체명</span></button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- 계약자 end -->
                    <!-- 종피 start -->
                    <li class="-pub-product-join__form--list-item -pub-product-join__form--list-grade">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--insured-person">종피</label>
                        </div>
                            <div class="-pub-product-join__form--list-inner">
                                <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>고객명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-4" display-name="고객명" v-model="formInput.insurSelectName.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.insurSelectName" :option-list="houseHoldList" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>직업<span class="-pub-required"></span></label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.insurJob" disabled></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>차량<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-5" display-name="차량" v-model="formInput.insurCar.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.insurCar" :option-list="carItems2" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종상해<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.insurSgrade" readonly></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종일반<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.insurNgrade" readonly></fdp-text-field>
                                </div>
                            </div>
                            </div>
                    </li>
                    <!-- 계약자 end -->
                    <!-- 자녀 start -->
                    <li class="-pub-product-join__form--list-item">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--child-person">자녀</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>자녀1</label>
                                    <fdp-select up ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.selectchild1" :option-list="houseHoldList" placeholder="선택하세요"></fdp-select>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>자녀2</label>
                                    <fdp-select up ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.selectchild2" :option-list="houseHoldList" placeholder="선택하세요"></fdp-select>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>자녀3</label>
                                    <fdp-select up ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.selectchild3" :option-list="houseHoldList" placeholder="선택하세요"></fdp-select>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- 자녀 end -->
                </ul>
            </form>
            <!-- 일반고객 segment content end -->
            <!-- 가상고객 segment content start -->
            <form v-else>
                <ul class="-pub-product-join__form--list">
                    <!-- 주피 start -->
                    <li class="-pub-product-join__form--list-item -pub-product-join__form--list-grade">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--beneficiary">주피</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                        <label>고객명<span class="-pub-required"></span></label>
                                        <fdp-validator name="tsspi190d-validator-6" display-name="고객명" v-model="formInput.beneName" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.beneName" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>직업<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-7" display-name="직업" v-model="formInput.beneJob" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.beneJob" fixedIcon placeholder="검색하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>차량<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-8" display-name="차량" v-model="formInput.beneCar.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.beneCar" :option-list="carItems1" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종상해<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.beneSgrade" readonly></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종일반<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.beneNgrade" readonly></fdp-text-field>
                                </div>
                            </div>
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-age">
                                    <label>연령<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-9" display-name="연령" v-model="formInput.beneAge" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.beneAge" placeholder="00"></fdp-text-field><span class="txt">세</span>
                                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item" placeholder="1999-01-01" @selected="calcBirth('bene')" v-model="formInput.beneDate" align-left format="yyyy-MM-dd" :disabled="formInput.beneAge!=='' && formInput.beneDate===''"></fdp-date-picker>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>성별<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-10" display-name="성별" v-model="formInput.beneGenderType" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--small -pub-segment__container -pub-segment--purple" v-model="formInput.beneGenderType" :data="genderTypes" essential></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- 주피 end -->
                    <!-- 종피 start -->
                    <li class="-pub-product-join__form--list-item -pub-product-join__form--list-grade">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--insured-person">종피</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>고객명<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-11" display-name="고객명" v-model="formInput.insurName" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.insurName" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>직업<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-12" display-name="직업" v-model="formInput.insurJob" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.insurJob" fixedIcon placeholder="검색하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>차량<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-13" display-name="차량" v-model="formInput.insurCar.key" :rules="'required'">
                                        <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-product-join__form--list-column-select" v-model="formInput.insurCar" :option-list="carItems2" placeholder="선택하세요"></fdp-select>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종상해<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.insurSgrade" readonly></fdp-text-field>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-grade">
                                    <label>최종일반<br>위험등급</label>
                                    <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-grade-input" v-model="formInput.insurNgrade" readonly></fdp-text-field>
                                </div>
                            </div>
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-age">
                                    <label>연령<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-14" display-name="연령" v-model="formInput.insurAge" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="formInput.insurAge" placeholder="00"></fdp-text-field><span class="txt">세</span>
                                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item" placeholder="1999-01-01" @selected="calcBirth('insur')" v-model="formInput.insurDate" align-left format="yyyy-MM-dd" :disabled="formInput.insurAge!=='' && formInput.insurDate===''"></fdp-date-picker>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>성별<span class="-pub-required"></span></label>
                                    <fdp-validator name="tsspi190d-validator-15" display-name="성별" v-model="formInput.insurGenderType" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--small -pub-segment__container -pub-segment--purple" v-model="formInput.insurGenderType" :data="genderTypes" essential></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- 종피 end -->
                    <!-- 자녀 start -->
                    <li class="-pub-product-join__form--list-item" v-for="(child, idx) in formInput.children" :key="idx">
                        <div class="-pub-product-join__form--list-title">
                            <label class="-pub-badge-tag -pub-product-join__tag--child-person">자녀{{idx+1}}</label>
                        </div>
                        <div class="-pub-product-join__form--list-inner">
                            <div class="-pub-product-join__form--list-row">
                                <div class="-pub-product-join__form--list-column">
                                    <label>고객명<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi190d-validator-16'+idx" display-name="고객명" v-model="child.childName" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="child.childName" placeholder="입력하세요"></fdp-text-field>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column -pub-product-join__form--list-column-age">
                                    <label>연령<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi190d-validator-17'+idx" display-name="연령" v-model="child.childAge" :rules="'required'">
                                        <fdp-text-field class="-pub-input--purple -pub-product-join__form--list-column-input" v-model="child.childAge" placeholder="00"></fdp-text-field><span class="txt">세</span>
                                        <fdp-date-picker class="-pub-date-picker -pub-date-picker--purple -pub-filter-detail__item" placeholder="1999-01-01" @selected="calcChildBirth(child)" v-model="child.childDate" align-left format="yyyy-MM-dd" :disabled="child.childAge!=='' && child.childDate===''"></fdp-date-picker>
                                    </fdp-validator>
                                </div>
                                <div class="-pub-product-join__form--list-column">
                                    <label>성별<span class="-pub-required"></span></label>
                                    <fdp-validator :name="'tsspi190d-validator-18'+idx" display-name="성별" v-model="child.childGenderType" :rules="'required'">
                                        <fdp-segment-box class="-pub-segment--small -pub-segment__container -pub-segment--purple" v-model="child.childGenderType" :data="genderTypes"></fdp-segment-box>
                                    </fdp-validator>
                                </div>
                            </div>
                        </div>
                        <!-- 닫기 버튼 클릭하면 자녀 삭제 -->
                        <a href="#" class="btn-close">
                            <img src="@/assets/img/components/btn_close_light.png" alt="닫기" @click="removeChild(idx)">
                        </a>
                    </li>
                    <!-- 자녀 end -->
                </ul>
                <!-- 가상고객에서 자녀추가 버튼 클릭 시 자녀3까지 추가 가능 -->
                <div class="-pub-button-center">
                    <button type="button" class="-pub-button -pub-button--add" @click="addChild">자녀 추가</button>
                </div>
            </form>
            <!-- 가상고객 segment content end -->
        </div>
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed-top -pub-bottom-bar__receive" v-show="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--grade -pub-bottom-nav__item -pub-button--purple -pub-button--reverse" @click="applyInfo">
                        <span class="-pub-button__text">적용</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
    </div>
    <!-- 고객선택 end -->
</template>
<script>
export default {
  data () {
    return {
      planType: [{
        key: '1',
        label: '일반고객'
      }],
      planTypes: [{
        key: '1',
        label: '일반고객'
      },
      {
        key: '2',
        label: '가상고객'
      }],

      genderTypes: [{
        key: '1',
        label: '남'
      },
      {
        key: '2',
        label: '여'
      }],
      formInput: {
        beneName: '',
        beneJob: '',
        beneSgrade: '',
        beneNgrade: '',
        beneAge: '',
        beneDate: '',
        insurName: '',
        insurJob: '',
        beneGenderType: [{key: '1', label: '남'}],
        insurGenderType: [{key: '1', label: '남'}],
        insurSgrade: '',
        insurNgrade: '',
        insurAge: '',
        insurDate: '',
        childName: '',
        childAge: '',
        childDate: '',
        insurSelectName: { key: '', label: '' },
        beneCar: { key: '', label: '' },
        contName: { key: '', label: '' },
        insurCar: { key: '', label: '' },
        houseHoldList: [],
        children: [{ childName: '', childAge: '', childDate: '', childGenderType: [{key: '1', label: '남'}] }],
        selectchild1: { key: '', label: '' },
        selectchild2: { key: '', label: '' },
        selectchild3: { key: '', label: '' }
      },
      formSelect: {
      },
      carItems1: [{
        key: '비운전자',
        label: '비운전자'
      },
      {
        key: '대형승합차',
        label: '대형승합차'
      }],
      carItems2: [{
        key: '승용차',
        label: '승용차'
      },
      {
        key: '오토바이',
        label: '오토바이'
      }],
      houseHoldList: []
    }
  },
  methods: {
    // 계약자 찾기 버튼 및 enter
    searchCustomer () {
      // 기본 고객정보 load
      this.formInput.beneJob = '총무사무원'
      // 계약자 select box 구성
      this.houseHoldList = [{
        key: this.formInput.beneName,
        label: this.formInput.beneName
      },
      {
        key: '이주영',
        label: '이주영'
      },
      {
        key: '이미정',
        label: '이미정'
      },
      {
        key: '이자녀',
        label: '이자녀'
      }]
      this.formInput.contName = {
        'key': this.formInput.beneName,
        'label': this.formInput.beneName
      }
    },
    addChild () {
      if (this.formInput.children.length > 2) return
      this.formInput.children.push({ childName: '', childAge: '', childDate: '', childGenderType: [{key: '1', label: '남'}] })
    },
    removeChild (idx) {
      this.formInput.children.splice(idx, 1)
    },
    applyInfo () {
      let summary = []
      // 주피
      if (this.formInput.beneName !== '') summary.push({code: '0', codeNm: '주피', name: this.formInput.beneName, age: '남 33세'})
      if (this.planType[0].key === '1') {
        // 계약자
        if (this.formInput.contName.key !== '') summary.push({code: '1', codeNm: '계약자', name: this.formInput.contName.key, age: '남 32세'})
        // 종피
        if (this.formInput.insurSelectName.key) summary.push({code: '2', codeNm: '종피', name: this.formInput.insurSelectName.key, age: '남 31세'})
        // 자녀
        if (this.formInput.selectchild1.key !== '') summary.push({code: '3', codeNm: '자녀1', name: this.formInput.selectchild1.key, age: '남 3세'})
        if (this.formInput.selectchild2.key !== '') summary.push({code: '3', codeNm: '자녀2', name: this.formInput.selectchild2.key, age: '남 2세'})
        if (this.formInput.selectchild3.key !== '') summary.push({code: '3', codeNm: '자녀3', name: this.formInput.selectchild3.key, age: '남 1세'})
      } else {
        // 종피
        if (this.formInput.insurName !== '') summary.push({code: '2', codeNm: '종피', name: this.formInput.insurName, age: this.formInput.insurGenderType[0].label + ' ' + this.formInput.insurAge + '세'})
        for (var idx in this.formInput.children) {
          if (this.formInput.children[idx].childName !== '') summary.push({code: '3', codeNm: '자녀', name: this.formInput.children[idx].childName, age: this.formInput.children[idx].childGenderType[0].label + ' ' + this.formInput.children[idx].childAge + '세'})
        }
      }
      this.$emit('applyInfo', summary)
    },
    calcChildBirth (val) {
      val.childAge = '22'
    }
  },
  watch: {
    'formInput.beneCar' (v) {
      if (this.formInput.beneJob !== '' && v !== '') {
        this.formInput.beneSgrade = '비'
        this.formInput.beneNgrade = 'A '
      } else {
        this.formInput.beneSgrade = ''
        this.formInput.beneNgrade = ''
      }
    },
    'formInput.beneJob' (v) {
      if (this.formInput.beneCar.key !== '' && v !== '') {
        this.formInput.beneSgrade = '비'
        this.formInput.beneNgrade = 'A '
      } else {
        this.formInput.beneSgrade = ''
        this.formInput.beneNgrade = ''
      }
    },
    'formInput.insurSelectName' (v) {
      if (v.key !== '') {
        this.formInput.insurJob = '학생'
      }
    },
    'formInput.insurCar' (v) {
      if (this.formInput.insurJob !== '' && v !== '') {
        this.formInput.insurSgrade = '비'
        this.formInput.insurNgrade = 'A '
      } else {
        this.formInput.insurSgrade = ''
        this.formInput.insurNgrade = ''
      }
    },
    'formInput.insurJob' (v) {
      if (this.formInput.insurCar.key !== '' && v !== '') {
        this.formInput.insurSgrade = '비'
        this.formInput.insurNgrade = 'A '
      } else {
        this.formInput.insurSgrade = ''
        this.formInput.insurNgrade = ''
      }
    },
    planType (v) {
      this.formInput = {
        beneName: '',
        beneJob: '',
        beneSgrade: '',
        beneNgrade: '',
        beneAge: '',
        beneDate: '',
        insurJob: '',
        beneGenderType: [{key: '1', label: '남'}],
        insurGenderType: [{key: '1', label: '남'}],
        insurSgrade: '',
        insurNgrade: '',
        insurAge: '',
        insurDate: '',
        childName: '',
        childAge: '',
        childDate: '',
        insurName: '',
        insurSelectName: { key: '', label: '' },
        beneCar: { key: '', label: '' },
        contName: { key: '', label: '' },
        insurCar: { key: '', label: '' },
        children: [{ childName: '', childAge: '', childDate: '', childGenderType: [{key: '1', label: '남'}] }],
        selectchild1: { key: '', label: '' },
        selectchild2: { key: '', label: '' },
        selectchild3: { key: '', label: '' }
      }
    }
  }
}
</script>
