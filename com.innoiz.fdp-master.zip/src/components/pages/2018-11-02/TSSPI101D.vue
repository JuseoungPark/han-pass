<template>
    <section class="-pub-product-join__wrap">
        <TSSPI190D @applyInfo="completedTab" v-show="isCustomer"></TSSPI190D>
        <TSSPI230D @applyProduct="applyProduct" v-show="isProduct || isClause"></TSSPI230D>
        <!-- 특약선택 D가 추가될 위치, v-show="isCluase" isClause 조건은 위에서 추후에 빼줘야 함 -->
        <!-- 사이드바 탭 start : 데이터가 없을 때 -->
        <div class="-pub-product-join__sidebar">
            <!-- 고객선택 탭 start -->
            <!-- 선택된 탭에 div class="-pub-product-join__sidebar-tab-active" 추가 / button disabled는 삭제-->
            <div class="-pub-product-join__sidebar-tab -pub-product-join__sidebar-tab-customer" :class="isCustomer?'-pub-product-join__sidebar-tab-active':''" @click="selectTab(0)">
                <div class="-pub-button -pub-button-tab" v-if="this.custSummary.length===0">고객선택</div>
                <div class="-pub-product-join__sidebar-tab -pub-product-join__sidebar-tab-customer" v-else>
                  <ul class="-pub-product-join__sidebar-tab-customer-list">
                      <li v-for="(item, idx) in custSummary" :key="idx">
                          <fdp-tooltip-button class="-pub-tooltip-button">
                              <template slot="activator">
                                  <label :class="getCustClass(item.code)">{{item.codeNm}}</label>
                              </template>
                              <template slot="content">
                                  <strong>상령일</strong>
                                  <span class="date">2018-10-22</span>
                              </template>
                          </fdp-tooltip-button>
                          <span class="-pub-product-join__name">{{item.name}}</span>
                          <span class="-pub-product-join__age">{{item.age}}</span>
                      </li>
                  </ul>
               </div>
            </div>
            <!-- 고객선택 탭 end -->
            <!-- 상품선택 탭 start -->
            <!-- <div class="-pub-product-join__sidebar-tab -pub-product-join__sidebar-tab-product" :class="isProduct?'-pub-product-join__sidebar-tab-active':''" @click="selectTab(1)">
                <button type="button" class="-pub-button -pub-button-tab" :disabled="!isProduct">상품선택</button>
            </div> -->
             <div class="-pub-product-join__sidebar-tab -pub-product-join__sidebar-tab-product" :class="isProduct?'-pub-product-join__sidebar-tab-active':''" @click="selectTab(1)">
                <div class="-pub-button -pub-button-tab" v-if="productNm===''">상품선택</div>
                <!-- <p v-if="productNm===''"> 상품선택 </p> -->
                <div class="-pub-product-join__txt" v-else>
                    <p>{{productNm}}</p>
                </div>
            </div>
            <!-- 상품선택 탭 end -->
            <!-- 특약선택 탭 start -->
            <div class="-pub-product-join__sidebar-tab -pub-product-join__sidebar-tab-special" :class="isClause?'-pub-product-join__sidebar-tab-active':''" @click="selectTab(2)">
                <div class="-pub-button -pub-button-tab" v-if="productNm===''">특약선택</div>
                <!--기본 계약 정보 표시유형 ALL -->
                <div class="-pub-product-join__sidebar-tab-special-list" v-else>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                        <label>할증지수조회 <span class="-pub-ico-check">*</span></label>
                        <button type="button" class="-pub-button -pub-button--purple">조회</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                        <label>할증지수조회 <span class="-pub-ico-check">*</span></label>
                        <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">조회</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                        <label>보험종류 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-1" display-name="보험종류" v-model="formInput.Select1.key" :rules="'required'">
                            <fdp-select ellipsis alignRight class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select1" :option-list="Select1Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>건강체 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-2" display-name="건강체" v-model="formInput.Select2.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select2" :option-list="Select2Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>건강체(종피) <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-3" display-name="건강체(종피)" v-model="formInput.Select3.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select3" :option-list="Select3Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                        <label>의료실손조회 <span class="-pub-ico-check">*</span></label>
                        <button type="button" class="-pub-button -pub-button--purple">조회</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>의료실손조회 <span class="-pub-ico-check">*</span></label>
                         <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">조회</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>생활자금연령 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-4" display-name="생활자금연령" v-model="formInput.text1" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input--194 -pub-input--normal-letter" v-model="formInput.text1" placeholder="00"></fdp-text-field>
                            <span class="-pub-txt--age">세</span>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>의료수급권자 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-5" display-name="의료수급권자" v-model="formInput.Select4.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select4" :option-list="Select4Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>적립계약 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-6" display-name="적립계약" v-model="formInput.Select5.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select5" :option-list="Select5Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>납입주기 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-7" display-name="납입주기" v-model="formInput.Select6.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select6" :option-list="Select6Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>연금전환연령 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-8" display-name="연금전환연령" v-model="formInput.text2" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input--194 -pub-input--normal-letter" v-model="formInput.text2" placeholder="00"></fdp-text-field>
                            <span class="-pub-txt--age">세</span>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>펀드편입비율 <span class="-pub-ico-check">*</span></label>
                         <button type="button" class="-pub-button -pub-button--purple">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>펀드편입비율 <span class="-pub-ico-check">*</span></label>
                         <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>실적배당형<br>연금개시연령 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-9" display-name="실적배당형" v-model="formInput.text3" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input--194 -pub-input--normal-letter" v-model="formInput.text3" placeholder="00"></fdp-text-field>
                            <span class="-pub-txt--age">세</span>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>예상퇴직연령 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-10" display-name="예상퇴직연령" v-model="formInput.Select7.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--194 -pub-input--normal-letter" v-model="formInput.Select7" :option-list="Select7Items" placeholder="선택하세요"></fdp-select>
                            <span class="-pub-txt--age">세</span>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>임신주수 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-11" display-name="임신주수" v-model="formInput.text4" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input--234" v-model="formInput.text4" placeholder="00"></fdp-text-field>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>고액계약 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-12" display-name="고액계약" v-model="formInput.Select8.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select8" :option-list="Select8Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>연금개시연령 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-13" display-name="연금개시연령" v-model="formInput.text5" :rules="'required'">
                            <fdp-text-field class="-pub-input--purple -pub-input--194 -pub-input--normal-letter" v-model="formInput.text5" placeholder="00"></fdp-text-field>
                            <span class="-pub-txt--age">세</span>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>연금지급형태 <span class="-pub-ico-check">*</span></label>
                         <button type="button" class="-pub-button -pub-button--purple">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>연금지급형태 <span class="-pub-ico-check">*</span></label>
                         <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>연금표시기간 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-14" display-name="연금표시기간" v-model="formInput.Select9.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select9" :option-list="Select9Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>동시가입 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-15" display-name="동시가입" v-model="formInput.Select10.key" :rules="'required'">
                            <fdp-select ellipsis class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select10" :option-list="Select10Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>제안대상선택 <span class="-pub-ico-check">*</span></label>
                         <button type="button" class="-pub-button -pub-button--purple">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>제안대상선택 <span class="-pub-ico-check">*</span></label>
                         <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>지정인출신청 <span class="-pub-ico-check">*</span></label>
                         <button type="button" class="-pub-button -pub-button--purple">입력</button>
                    </div>
                    <div class="-pub-product-join__sidebar-tab-special-list-item">
                         <label>지정인출신청 <span class="-pub-ico-check">*</span></label>
                         <!-- 입력이 완료 된 팝업 : 버튼 안에 체크 표시 -pub-button--check -->
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--check">입력</button>
                    </div>
                    <!-- MYPLAN :  -pub-product-join__sidebar-tab-special-list-myplan -->
                    <div class="-pub-product-join__sidebar-tab-special-list-item -pub-product-join__sidebar-tab-special-list-myplan">
                         <label>MY 플랜 <span class="-pub-ico-check">*</span></label>
                         <fdp-validator name="tsspi101d-validator-16" display-name="MY 플랜" v-model="formInput.Select11.key" :rules="'required'">
                            <fdp-select ellipsis up class="-pub-select -pub-select--purple -pub-select--234" v-model="formInput.Select11" :option-list="Select11Items" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                </div>
            </div>
            <!-- 특약선택 탭 end -->
        </div>
        <!-- 사이드바 탭 end -->
    </section>
</template>
<script>
import TSSPI190D from '@/components/pages/2018-11-02/TSSPI190D'
import TSSPI230D from '@/components/pages/2018-11-16/TSSPI230D'
export default {
  components: {
    TSSPI190D,
    TSSPI230D
  },
  data () {
    return {
      custSummary: [],
      isCustomer: true,
      isProduct: false,
      isClause: false,
      isCustomerComplete: false,
      isProductComplete: false,
      isClauseComplete: false,
      productNm: '',
      formInput: {
        Select1: { key: '기본형', label: '기본형' },
        Select2: { key: '표준체', label: '표준체' },
        Select3: { key: '표준체(종피)', label: '표준체(종피)' },
        Select4: { key: '', label: '' },
        Select5: { key: '적립계약포함', label: '적립계약포함' },
        Select6: { key: '월납', label: '월납' },
        Select7: { key: '65', label: '65' },
        Select8: { key: '고액계약선택', label: '고액계약선택' },
        Select9: { key: '1년', label: '1년' },
        Select10: { key: '', label: '' },
        Select11: { key: '', label: '' },
        text1: '',
        text2: '',
        text3: '',
        text4: '',
        text5: ''
      },
      Select1Items: [{
        key: '기본형',
        label: '기본형'
      },
      {
        key: '5% 체증형(기본형)',
        label: '5% 체증형(기본형)'
      },
      {
        key: '4% 체증형(기본형)',
        label: '4% 체증형(기본형)'
      },
      {
        key: '3% 체증형(기본형)',
        label: '3% 체증형(기본형)'
      },
      {
        key: '5% 체증형(프라임형)',
        label: '5% 체증형(프라임형)'
      },
      {
        key: '프라임형(환급금미보증형)',
        label: '프라임형(환급금미보증형)'
      }],
      Select2Items: [{
        key: '표준체',
        label: '표준체'
      },
      {
        key: '우량체',
        label: '우량체'
      },
      {
        key: '할증체',
        label: '할증체'
      }],
      Select3Items: [{
        key: '표준체(종피)',
        label: '표준체(종피)'
      },
      {
        key: '우량체(종피)',
        label: '우량체(종피)'
      },
      {
        key: '할증체(종피)',
        label: '할증체(종피)'
      }],
      Select4Items: [{
        key: '부모님',
        label: '부모님'
      },
      {
        key: '자식',
        label: '자식'
      },
      {
        key: '형제/자매',
        label: '형제/자매'
      }],
      Select5Items: [{
        key: '포함',
        label: '포함'
      },
      {
        key: '미포함',
        label: '미포함'
      }],
      Select6Items: [{
        key: '월납',
        label: '월납'
      },
      {
        key: '일시납',
        label: '일시납'
      },
      {
        key: '3월납',
        label: '3월납'
      },
      {
        key: '6월납',
        label: '6월납'
      },
      {
        key: '연납',
        label: '연납'
      }],
      Select7Items: [{
        key: '65',
        label: '65'
      },
      {
        key: '70',
        label: '70'
      },
      {
        key: '80',
        label: '80'
      }],
      Select8Items: [{
        key: '고액할인',
        label: '고액할인'
      },
      {
        key: '고액적립',
        label: '고액적립'
      }],
      Select9Items: [{
        key: '1년',
        label: '1년'
      },
      {
        key: '2년',
        label: '2년'
      },
      {
        key: '3년',
        label: '3년'
      },
      {
        key: '4년',
        label: '4년'
      },
      {
        key: '5년',
        label: '5년'
      }],
      Select10Items: [{
        key: '가능',
        label: '가능'
      },
      {
        key: '불가능',
        label: '불가능'
      }],
      Select11Items: [{
        key: 'MY플랜1',
        label: 'MY플랜1'
      },
      {
        key: 'MY플랜2',
        label: 'MY플랜2'
      }]
    }
  },
  methods: {
    getCustClass (code) {
      switch (code) {
        case '0': // 주피
          return '-pub-badge-tag -pub-product-join__tag--beneficiary'
        case '1': // 계약자
          return '-pub-badge-tag -pub-product-join__tag--contractor'
        case '2': // 종피
          return '-pub-badge-tag -pub-product-join__tag--insured-person'
        case '3': // 자녀
          return '-pub-badge-tag -pub-product-join__tag--child-person'
      }
    },
    selectTab (tab) {
      switch (tab) {
        case 0:
          this.isCustomer = true
          this.isProduct = false
          this.isClause = false
          break
        case 1:
          if (!this.isCustomerComplete) break
          this.isCustomer = false
          this.isProduct = true
          this.isClause = false
          break
        case 2:
          if (!this.isProductComplete) break
          this.isCustomer = false
          this.isProduct = false
          this.isClause = true
          break
      }
    },
    completedTab (v) { // 고객 선택 완료 후
      this.custSummary = v
      this.isCustomerComplete = true
      this.selectTab(1)
    },
    applyProduct (v) { // 상품 선택 완료 후
      this.productNm = v
      this.isProductComplete = true
    }
  }
}
</script>
