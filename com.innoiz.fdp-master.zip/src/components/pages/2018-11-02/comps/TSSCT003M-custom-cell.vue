<template>
    <div>
        <span :style="{'line-height': 1, 'border-bottom': item.underline ? '1px solid #222' : ''} ">{{item.productName}}</span>
    </div>
</template>

<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col']
}
</script>
