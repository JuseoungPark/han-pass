<template>
    <div class="-pub-private-info-agreement">
        <span class="-pub-private-info-agreement__title">소비자 권익보호에 관한 사항</span>
        <span class="-pub-private-info-agreement__desc">보험계약 및 상담, 수익증권, 신탁, 융자, 퇴직연금과 관련된 기타 부가 서비스 및 신상품 안내등을위하시는
경우 동의해주시기 바라며, 동의하지 않더라도 계약체결이 가능하며 동의를 거부할 수 있습니다. </span>
        <div class="-pub-private-info-agreement__box">
            <div class="-pub-private-info-agreement__box--title">
                <span class="-pub-text">상품소개등을 위한 개인(신용)정보 처리 동의서 <br>
(보험상담 서비스 신청 동의 포함)</span>
                <fdp-checkbox class="-pub-checkbox" v-model="dontAgreeCheckbox" @click.native="onCancelAgreeAll">동의안함</fdp-checkbox>
                <fdp-checkbox class="-pub-checkbox -pub-check-all" v-model="isAllAgree" @click.native="onSelectAgreeAll">전체동의</fdp-checkbox>
            </div>
            <div class="-pub-private-info-agreement__box--content">
                <ul>
                    <!--  -pub-accordion-open 아코디언 펼쳐짐 -->
                    <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[0].opened}">
                        <div class="-pub-accordion__header">
                            <span class="-pub-text">{{requiredAgreementContent[0].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="agreeCheckboxList" value="1">동의함</fdp-checkbox>
                            <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[0].opened=!requiredAgreementContent[0].opened}">
                        </div>
                        <div class="-pub-accordion__body -pub-accordion-scroll">
                            <span>전문내용 영역<br><br>{{requiredAgreementContent[0].content}}</span>
                        </div>
                    </li>
                    <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[1].opened}">
                        <div class="-pub-accordion__header">
                            <span class="-pub-text">{{requiredAgreementContent[1].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="agreeCheckboxList" value="2">동의함</fdp-checkbox>
                            <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[1].opened=!requiredAgreementContent[1].opened}">
                        </div>
                        <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>전문내용 영역<br><br>{{requiredAgreementContent[1].content}}</span>
                        </div>
                    </li>
                    <li class="-pub-accordion__item" :class="{'-pub-accordion-open': requiredAgreementContent[2].opened}">
                        <div class="-pub-accordion__header">
                            <span class="-pub-text">{{requiredAgreementContent[2].title}}</span><fdp-checkbox class="-pub-checkbox" v-model="agreeCheckboxList" value="3">동의함</fdp-checkbox>
                            <img class="-pub-accordion__img" src="@/assets/img/components/ico_arrow_down.png" alt="" @click="() => {requiredAgreementContent[2].opened=!requiredAgreementContent[2].opened}">
                        </div>
                        <div class="-pub-accordion__body -pub-accordion-scroll">
                                <span>전문내용 영역<br><br>{{requiredAgreementContent[2].content}}</span>
                        </div>
                    </li>
                </ul>
                <div class="-pub-marketing-invitation-method">
                    <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="phone">전화</fdp-checkbox>
                    <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="text">문자</fdp-checkbox>
                    <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="letter">우편</fdp-checkbox>
                    <fdp-checkbox class="-pub-checkbox" v-model="marketingCheckboxList" value="email">이메일</fdp-checkbox>
                </div>
            </div>
        </div>
        <div class="-pub-private-info-agreement__trade">
            <label>당사와 거래여부 체크</label>
            <fdp-validator name="tsscm106d_trade" v-model="segmentType1" display-name="당사와 거래여부" :rules="'required'">
                <fdp-segment-box class="-pub-segment__container -pub-segment--medium" v-model="segmentType1" :data="segmentTypes1"></fdp-segment-box>
            </fdp-validator>
        </div>
        <div class="-pub-private-info-agreement__period">
            <label>개인(신용)정보 보유이용기간</label>
            <fdp-validator name="tsscm106d_period" v-model="segmentType2" display-name="개인(신용)정보 보유이용기간" :rules="'required'" v-if="segmentType1.length > 0">
                <fdp-segment-box class="-pub-segment__container -pub-segment--small" v-model="segmentType2" :data="segmentTypes2"></fdp-segment-box>
            </fdp-validator>
        </div>
    </div>
</template>
<script>
export default {
  props: {
    tabIndex: {
      type: Number,
      default: 0
    }
  },
  data () {
    return {
      isAllAgree: false,
      dontAgreeCheckbox: false,
      agreeCheckboxList: [],
      allItems: ['1', '2', '3'],
      marketingCheckboxList: [],
      completed2: false,
      segmentTypes1: [
        {
          key: '1',
          label: '거래'
        },
        {
          key: '2',
          label: '미거래'
        }
      ],
      segmentType1: [],
      segmentTypes2: [],
      segmentTwoYears: [
        {
          key: '1',
          label: '1년'
        },
        {
          key: '2',
          label: '2년'
        }
      ],
      segmentFiveYears: [
        {
          key: '1',
          label: '1년'
        },
        {
          key: '2',
          label: '2년'
        },
        {
          key: '3',
          label: '3년'
        },
        {
          key: '4',
          label: '4년'
        },
        {
          key: '5',
          label: '5년'
        }
      ],
      segmentType2: [],
      requiredAgreementContent: [
        {
          opened: false,
          title: '1. 개인(신용)정보 수집 · 이용 동의',
          content: '이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인 (부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다. 이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인 (부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다.'
        },
        {
          opened: false,
          title: '2. 개인(신용)정보 조회 동의',
          content: '이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인 (부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다. 이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인 (부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다.'
        },
        {
          opened: false,
          title: '3. 마케팅 권유 방식 선택 (전체)',
          content: '이름, 생년월일, 성별, 중복가입확인정보(DI), 암호화된 동일인 식별정보(CI), 휴대전화번호 및 통신사(휴대전화 인증 시), 내/외국인 정보정보주체로서 이용자는 자신의 개인정보에 대해 어떤 권리를 가지고 있으며, 이를 어떤 방법과 절차로 행사할 수 있는지를 알려드립니다. 또한, 법정대리인 (부모 등)이 만14세 미만 아동의 개인정보 보호를 위해 어떤 권리를 행사할 수 있는지도 함께 안내합니다.'
        }
      ]
    }
  },
  watch: {
    isAllAgree (newValue) {
      if (this.tabIndex === 1) {
        this.$emit('is-agree-all', newValue)
      }
    },
    segmentType1 (newValue) {
      this.segmentType2.splice(0, 1)

      if (newValue[0] && newValue[0].label === '거래') {
        this.segmentTypes2 = this.segmentFiveYears
      } else if (newValue[0] && newValue[0].label === '미거래') {
        this.segmentTypes2 = this.segmentTwoYears
      }
    },
    completed (newValue) {
      this.$emit('completed', this.tabIndex, newValue)
    },
    agreeCheckboxList (newValue) {
      if ((newValue.length === this.allItems.length && !this.isAllAgree) ||
          (newValue.length !== this.allItems.length && this.isAllAgree)) {
        this.isAllAgree = !this.isAllAgree
      }
    }
  },
  methods: {
    onSelectAgreeAll () {
      this.dontAgreeCheckbox = this.dontAgreeCheckbox ? !this.dontAgreeCheckbox : this.dontAgreeCheckbox
      this.agreeCheckboxList = this.isAllAgree ? this.allItems : []
    },
    onCancelAgreeAll () {
      this.agreeCheckboxList = []
      this.marketingCheckboxList = []
    }
  },
  computed: {
    completed () {
      return this.isAllAgree && this.segmentType1.length > 0 && this.segmentType2.length > 0
    }
  }
}
</script>
