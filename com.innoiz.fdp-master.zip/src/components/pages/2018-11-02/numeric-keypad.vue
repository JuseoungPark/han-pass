<template>
    <div class="test">
        <fdp-text-field class="" placeholder="입력하시오" v-model="num" virtual></fdp-text-field>
    </div>
</template>
<style>
    .test {
        padding: 100px 0;
    }
    .-fdp-text-field {
        display: block;
        width: 300px;
        margin: 0 auto;
    }
</style>
<script>
export default {
  data () {
    return {
      num: ''
    }
  }
}
</script>
