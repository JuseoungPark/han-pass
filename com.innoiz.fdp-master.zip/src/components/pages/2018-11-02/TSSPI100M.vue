<template>
    <section class="-pub-product-join">
        <h1 class="-pub-product-join__title">
            <a class="-pub-product-join__button--back">
                <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
            </a>
            <span class="-pub-product-join__text--parent-bottom">개인가입설계</span>
        </h1>
        <TSSPI101D></TSSPI101D>
    </section>
</template>
<script>
import TSSPI101D from '@/components/pages/2018-11-02/TSSPI101D'

export default {
  components: {
    TSSPI101D
  },
  data () {
    return {
    }
  }
}
</script>
