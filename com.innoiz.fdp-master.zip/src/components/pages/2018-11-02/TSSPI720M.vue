<template>
    <section class="-pub-product-suitability">
        <div class="-pub-product-suitability__header">
            <h1 class="-pub-product-suitability__title">
                <a class="-pub-product-suitability__button--back">
                    <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
                </a>
                <span class="-pub-product-join__text--parent-bottom">적합성 진단</span>
            </h1>
            <fdp-stepper class="-pub-stepper -pub-product-suitability__stepper" v-model="currentStep" :space="22" clickable>
                <fdp-step :step="1" :current="currentStep"></fdp-step>
                <fdp-step :step="2" :current="currentStep"></fdp-step>
                <fdp-step :step="3" :current="currentStep"></fdp-step>
                <fdp-step :step="4" :current="currentStep"></fdp-step>
            </fdp-stepper>
        </div>
        <TSSPI720D v-if="currentStep === 1"></TSSPI720D>
        <TSSPI750D v-else></TSSPI750D>
    </section>
</template>
<script>
import TSSPI720D from '@/components/pages/2018-11-02/TSSPI720D'
import TSSPI750D from '@/components/pages/2018-11-09/TSSPI750D'
export default {
  components: {
    TSSPI720D,
    TSSPI750D
  },
  data () {
    return {
      currentStep: 1
    }
  }
}
</script>
