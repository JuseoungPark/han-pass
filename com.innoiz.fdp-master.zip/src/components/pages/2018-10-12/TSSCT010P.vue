<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="기간별 보장금액" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup -pub-consulting-popup--type-2">
        <section class="-pub-consulting-popup__graph-content">
          <div class="-pub-consulting-popup__graph-head">
            <div class="-pub-consulting-popup__title-select">
              <h1>보장구분</h1>
              <fdp-select class="-pub-select" v-model="select1.value"
                    :option-list="select1.items" placeholder="보장구분"></fdp-select>
            </div>
            <div class="-pub-product-graph__head-container">
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>31</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>60</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>70</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>80</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered"><span>100</span>세</div>
              </div>
              <div class="-pub-product-graph__head-item">
                <div class="-pub-product-graph__head-text -pub-product-graph__head-text--centered">종신</div>
              </div>
            </div>
          </div>
          <div class="-pub-consulting-popup__graph -pub-consulting-popup__graph--line-graph">
            <div class="-pub-graph-zone"></div>
          </div>
          <div class="-pub-consulting-popup__button-area">
            <button class="-pub-button -pub-button--reverse -pub-consulting-popup__button-right -pub-button--complete">확인</button>
          </div>
        </section>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      select1: {
        value: {
          key: '1',
          label: '질병입원의료비'
        },
        items: [
          {
            key: '1',
            label: '질병입원의료비'
          },
          {
            key: '2',
            label: '암사망'
          },
          {
            key: '3',
            label: '암사망'
          },
          {
            key: '4',
            label: '질병입원의료비'
          },
          {
            key: '5',
            label: '암사망'
          },
          {
            key: '6',
            label: '암사망'
          }
        ]
      }
    }
  }
}
</script>
