<template>
    <section class="-pub-search-all -pub-search-customer">
        <div class="-pub-search-wrap" >
            <button type="button" class="-pub__button--close">
                <img src="@/assets/img/components/btn_close_light.png" alt="close">
            </button>
            <div class="-pub-search-box-wrap">
                <fdp-text-field class="-pub-search-input" placeholder="고객명을 입력하세요" v-model="searchKeyword" clearable @keyup.enter="onSearch" @focus="() => {isFocused = true}" ref="searchTextInput"></fdp-text-field>
                <img class="-pub-search-all-icon" src="@/assets/img/components/ico_search_blue.png" @click="onSearch" alt="search" v-if="!searchKeyword">
            </div>
            <hr>
            <div class="-pub-recent-search-wrap" v-if="isFocused">
                <ul class="-pub-recent-activity-customer">
                    <li class="-pub-recent" v-if="!searchKeyword">최근 검색 고객</li>
                    <li v-for="(customer, idx) in customers" :key="idx" v-if="!searchKeyword">
                        <span class="-pub-search-name" v-if="idx<3">{{customer.name}}</span>
                        <span class="-pub-search-age-gender" v-if="idx<3">{{customer.birth}}</span>
                        <span class="-pub-search-mobile" v-if="idx<3">{{customer.mobile}}</span>
                        <img class="-pub-search-del" src="@/assets/img/components/btn_close_light.png" @click="delCustomers(idx)" alt="del" v-if="idx<3">
                    </li>
                    <li v-for="(customer, idx) in customerResults" :key="idx" v-if="searchKeyword">
                        <span class="-pub-search-name" v-html="getHighlightTitle(customer.name)"></span>
                        <span class="-pub-search-age-gender">{{customer.birth}}</span>
                        <span class="-pub-search-mobile">{{customer.mobile}}</span>
                    </li>
                </ul>
                <!-- 검색결과 없을때 화면 -->
                <div class="empty-content" v-if="searchRes==='2'">
                    <img src="@/assets/img/components/ico_no_search_result.png" class="empty-content__icon" />
                    <div class="empty-content__text">'{{searchKeyword}}'에 대한 검색결과가 없습니다.</div>
                </div>
            </div>
        </div>
        <div class="-pub-searched-content-wrap"></div>
    </section>
</template>
<script>

export default {
  mounted () {
    this.$refs.searchTextInput.setFocus()
  },
  data () {
    return {
      isInit: true,
      isFocused: false,
      isShowEmpty: true,
      searchKeyword: '',
      resultWord: '',
      isFixed: false,
      isActive: '0',
      customers: [{
        name: '이주명',
        birth: '1970-08-08',
        mobile: '010-1234-5678'
      },
      {
        name: '김판곤',
        birth: '1970-08-08',
        mobile: '010-1234-5678'
      },
      {
        name: '손주영',
        birth: '1970-08-08',
        mobile: '010-1234-5678'
      },
      {
        name: '이여자',
        birth: '1970-08-08',
        mobile: '010-1234-5678'
      },
      {
        name: '김이주',
        birth: '1970-08-08',
        mobile: '010-1234-5678'
      }],
      customerResults: []
    }
  },
  methods: {
    getHighlightTitle (val) {
      if (!this.searchKeyword) {
        return val
      }
      const regex = new RegExp(`(${this.searchKeyword})`, 'gi')
      return val.replace(regex, '<span class="-pub-search-color -pub-search-auto-search">$1</span>')
    },
    delCustomers (idx) {
      this.customers.splice(idx, 1)
    },
    onSearch () {
      this.isFocused = false
      this.isInit = false
      this.resultWord = this.searchKeyword
      // if (this.searchKeyword) {
      //   this.addKeyword(this.searchKeyword)
      // }
    },
    addKeyword (val) {
      let addKey = []
      addKey.name = val
      addKey.birth = '2018-09-02' // 고객 검색 결과가 있다면 생일 세팅
      addKey.mobile = '010-111-1111' // 고객 검색 결과가 있다면 전화번호 세팅
      this.customers.unshift(addKey)
      if (this.customers.length > 9) {
        this.customers.splice(10, 1)
      }
    }
  },
  computed: {
    totalCnt () {
      return 0
    }
  },
  watch: {
    searchKeyword () {
      this.customerResults = []
      if (this.searchKeyword) {
        for (let i = 0; i < this.customers.length; i++) {
          if (this.customers[i].name.indexOf(this.searchKeyword) > -1) {
            this.customerResults.push(this.customers[i])
          }
        }
        if (this.customerResults.length === 0) this.searchRes = '2'
        else this.searchRes = '1'
      } else {
        this.searchRes = '1'
      }
    }
  }
}
</script>
