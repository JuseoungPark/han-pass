<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="고객접촉정보 수신 설정" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__receive--set">
                <p class="txt">제외할 항목을 선택하세요</p>
                <div class="sort">
                    <strong class="tit">분류</strong>
                    <fdp-select v-model="totalValue" :option-list="sortItems" placeholder="전체"></fdp-select>
                </div>
                <!-- 2018-10-18  :tableBodyHeight 높이 값 수정-->
                <fdp-infinite class="-pub-table" :items="tableData"  multi-select v-model="selectItems" :tableBodyHeight="592">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column-pub-table-column--checkbox" style="width:78px">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                            </th>
                            <th class="-pub-table-column" style="width:224px;">접촉ID</th>
                            <th class="-pub-table-column" style="width:562px;">접촉ID명</th>
                        </tr>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column--checkbox" style="width:78px">
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" v-model="selectItems" :value="props.item"></fdp-checkbox>
                        </td>
                        <td class="-pub-table-column" style="width:224px"><span class="en">{{props.item.id}}</span></td>
                        <td class="-pub-table-column -pub-table-column--left-align" style="width:562px">{{props.item.name}}</td>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView">
                        <div class="-pub-table-empty-view -pub-table-empty-view—search">
                            <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                        </div>
                    </template>
                </fdp-infinite>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar__receive">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered"  @click="cancelSeletItemsFunc"  v-show="selectItems.length>0">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" v-model="bottomBarCheck">{{selectItems.length}}건 선택</fdp-checkbox>
                    </li>
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button class="-pub-button -pub-button--purple -pub-button--small -pub-bottom-nav__item -pub-button--reverse">
                            <span class="-pub-button__text">제외</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      chkSingle: false,
      bottomBarCheck: false,
      isSelectAll: false,
      searchRes: '',
      chkMulti: [],
      selectItems: [],
      totalValue: {key: '전체', label: '전체'},
      sortItems: [
        { key: '전체', label: '전체' },
        { key: '접촉ID', label: '접촉ID' },
        { key: '접촉ID명', label: '접촉ID명' }
      ],
      tableData: [
        { id: 'AA01', name: '직업변경' },
        { id: 'AA02', name: '직장명변경' },
        { id: 'AB01', name: '연락처수정' },
        { id: 'AB04', name: '전화 수신동의 변경' },
        { id: 'AB05', name: 'SMS 수신동의 변경' },
        { id: 'AB06', name: '이메일 수신동의 변경' },
        { id: 'BA01', name: '두낫콜 등록/변경1' },
        { id: 'BA03', name: '주소변경1' },
        { id: 'BA04', name: '두낫콜 등록/변경2' },
        { id: 'BA05', name: '주소변경2' },
        { id: 'BA06', name: '두낫콜 등록/변경3' },
        { id: 'BA07', name: '주소변경3' }
      ]
    // tableData: []
    }
  },
  methods: {
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.tableData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  watch: {
    selectItems () {
      if (this.selectItems.length !== this.tableData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    },
    totalValue () {
      if (this.totalValue.key === '접촉ID') {
        this.tableData = ''
      } else {
        this.tableData = [
          { id: 'AA01', name: '직업변경' },
          { id: 'AA02', name: '직장명변경' },
          { id: 'AB01', name: '연락처수정' },
          { id: 'AB04', name: '전화 수신동의 변경' },
          { id: 'AB05', name: 'SMS 수신동의 변경' },
          { id: 'AB06', name: '이메일 수신동의 변경' },
          { id: 'BA01', name: '두낫콜 등록/변경' }
        ]
      }
    }
  }
}
</script>
