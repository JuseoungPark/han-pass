<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="실손가입조회" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup -pub-consulting-popup--type-3">
        <div class="-pub-table-container -pub-table-container--popup">
          <template v-if="step === 0">
            <div class="-pub-table-empty-view -pub-table-empty-view--touch align-center">
              <div class="empty-table-content__text">실손가입현황을 조회하시려면 예약하기 버튼을 터치하세요.<br>2~3일 뒤에 결과를 확인하실 수 있습니다.</div>
            </div>
          </template>
          <template v-else-if="step === 1">
            <div class="-pub-table-empty-view -pub-table-empty-view--touch align-center">
              <div class="empty-table-content__text">생손보실손 정보조회 예약기능이 실행되었습니다.<br>결과를 확인하시겠습니까?</div>
            </div>
          </template>
          <template v-else>
            <div class="-pub-consulting-data-info">
              <span class="-pub-consulting-data-info__text -pub-consulting-data-info__text--count">총 {{ (isEmpty ? [] : tableData1).length}}건</span>
            </div>
          <fdp-infinite :items="isEmpty ? [] : tableData1" class="-pub-table -pub-table--auto-height -pub-table--max-1"
            :tableHeaderHeight="70">
            <template slot="header">
              <tr class="-pub-table__header">
                <th class="-pub-consulting-grid__column" style="width: 78px;" >구분</th>
                <th class="-pub-consulting-grid__column" style="width: 172px;">가입회사</th>
                <th class="-pub-consulting-grid__column" style="width: 142px;">보장명</th>
                <th class="-pub-consulting-grid__column" style="width: 142px;">보장유형</th>
                <th class="-pub-consulting-grid__column" style="width: 172px;">담보특성</th>
                <th class="-pub-consulting-grid__column" style="width: 172px;">가입금액</th>
                <th class="-pub-consulting-grid__column" style="width: 142px;">계약상태</th>
                <th class="-pub-consulting-grid__column" style="width: 300px;">담보별보장기간</th>
                <th class="-pub-consulting-grid__column">보험종목명</th>
              </tr>
            </template>
            <template slot-scope="props">
                <td class="-pub-consulting-grid__column" style="width: 78px;">{{props.item.idx}}</td>
                <td class="-pub-consulting-grid__column" style="width: 172px;">{{props.item.company}}</td>
                <td class="-pub-consulting-grid__column" style="width: 142px;">{{props.item.productName}}</td>
                <td class="-pub-consulting-grid__column" style="width: 142px;">{{props.item.productType}}</td>
                <td class="-pub-consulting-grid__column" style="width: 172px;">{{props.item.specificity}}</td>
                <td class="-pub-consulting-grid__column normal-letter align-right" style="width: 172px;">{{props.item.price}}</td>
                <td class="-pub-consulting-grid__column" style="width: 142px;">{{props.item.status}}</td>
                <td class="-pub-consulting-grid__column normal-letter" style="width: 300px;">{{props.item.period}}</td>
                <td class="-pub-consulting-grid__column">{{props.item.typeName}}</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            </template>
          </fdp-infinite>
          <h3 class="-pub-table-container__title">
            생손보 실손 신청내용
          </h3>
          <fdp-infinite :items="isEmpty ? [] : tableData2" class="-pub-table -pub-table--auto-height"
            :tableHeaderHeight="70">
            <template slot="header">
              <tr class="-pub-table__header">
                <th class="-pub-consulting-grid__column" style="width: 240px;">피보험자</th>
                <th class="-pub-consulting-grid__column" style="width: 252px;">정보동의일자</th>
                <th class="-pub-consulting-grid__column" style="width: 360px;">정보조회예약시간</th>
                <th class="-pub-consulting-grid__column" style="width: 360px;">정보수령시간</th>
                <th class="-pub-consulting-grid__column" style="width: 360px;">정보사용만료일</th>
              </tr>
            </template>
            <template slot-scope="props">
              <td class="-pub-consulting-grid__column" style="width: 240px;">{{props.item.customerName}}</td>
              <td class="-pub-consulting-grid__column normal-letter" style="width: 252px;">{{props.item.date1}}</td>
              <td class="-pub-consulting-grid__column normal-letter" style="width: 360px;">{{props.item.date2}}</td>
              <td class="-pub-consulting-grid__column normal-letter" style="width: 360px;">{{props.item.date3}}</td>
              <td class="-pub-consulting-grid__column normal-letter" style="width: 360px;">{{props.item.date4}}</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            </template>
          </fdp-infinite>
          <h3 class="-pub-table-container__title">
            실손 가입현황(당사 및 타사 포함)
          </h3>
          <fdp-infinite :items="isEmpty ? [] : tableData3" class="-pub-table -pub-table--auto-height"
            :tableHeaderHeight="70">
            <template slot="header">
              <tr class="-pub-table__header">
                <th class="-pub-consulting-grid__column" style="width: 106px;">종합입원</th>
                <th class="-pub-consulting-grid__column">종합통원</th>
                <th class="-pub-consulting-grid__column">질병입원</th>
                <th class="-pub-consulting-grid__column">질병통원</th>
                <th class="-pub-consulting-grid__column">상해입원</th>
                <th class="-pub-consulting-grid__column">상해통원</th>
                <th class="-pub-consulting-grid__column">특정질병</th>
                <th class="-pub-consulting-grid__column">특정상해</th>
                <th class="-pub-consulting-grid__column">소액급부</th>
                <th class="-pub-consulting-grid__column">산과실손</th>
                <th class="-pub-consulting-grid__column">도수치료</th>
                <th class="-pub-consulting-grid__column">주사료</th>
                <th class="-pub-consulting-grid__column normal-letter" style="width: 140px;">MRI/MRA</th>
              </tr>
            </template>
            <template slot-scope="props">
              <td class="-pub-consulting-grid__column" v-for="(value, index) in props.item" :key="index"
                  :style="{ width: (index === 0 ? '106px' : (index === props.item.length - 1 ? '134px' : 'auto') )  }">{{value}}</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            </template>
          </fdp-infinite>
          <h3 class="-pub-table-container__title">
            당사 실손 가입가능 여부
          </h3>
          <fdp-infinite :items="isEmpty ? [] : tableData4" class="-pub-table -pub-table--auto-height"
            :tableHeaderHeight="70">
            <template slot="header">
              <tr class="-pub-table__header">
                <th class="-pub-consulting-grid__column" style="width: 106px;">종합입원</th>
                <th class="-pub-consulting-grid__column">종합통원</th>
                <th class="-pub-consulting-grid__column">질병입원</th>
                <th class="-pub-consulting-grid__column">질병통원</th>
                <th class="-pub-consulting-grid__column">상해입원</th>
                <th class="-pub-consulting-grid__column">상해통원</th>
                <th class="-pub-consulting-grid__column">특정질병</th>
                <th class="-pub-consulting-grid__column">특정상해</th>
                <th class="-pub-consulting-grid__column">소액급부</th>
                <th class="-pub-consulting-grid__column">산과실손</th>
                <th class="-pub-consulting-grid__column">도수치료</th>
                <th class="-pub-consulting-grid__column">주사료</th>
                <th class="-pub-consulting-grid__column normal-letter" style="width: 140px;">MRI/MRA</th>
              </tr>
            </template>
            <template slot-scope="props">
              <td class="-pub-consulting-grid__column" v-for="(value, index) in props.item" :key="index"
                  :style="{ width: (index === 0 ? '106px' : (index === props.item.length - 1 ? '134px' : 'auto') )  }">{{value}}</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            </template>
          </fdp-infinite>
          <h3 class="-pub-table-container__title">
            당사 실손 가입가능 여부
          </h3>
          <fdp-infinite :items="isEmpty ? [] : tableData4" class="-pub-table -pub-table--auto-height -pub-table--empty-head"
            :tableHeaderHeight="70">
            <template slot="header">
              <tr class="-pub-table__header">
                <td></td>
              </tr>
            </template>
            <template slot-scope="props">
              <td class="-pub-consulting-grid__column align-left">실손 중복가입_당사실손 가입가능여부 확인 / 실손 기가입건 존재 - 단체실손 또는 타사소액/실효건</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
                <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
              </div>
            </template>
          </fdp-infinite>
          </template>
        </div>
      </div>
      <div class="-pub-bottom-bar">
        <div class="-pub-confirm__content -pub-confirm__content--centered">
          <fdp-checkbox class="-pub-checkbox" style="padding:20px 20px;" v-model="isEmpty">데이터 없을때</fdp-checkbox>
        </div>
        <div class="-pub-confirm__content--right">
          <template v-if="step === 0">
            <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--reverse -pub-button--default">
              <span class="-pub-button__text" @click="step = 1">예약하기</span>
            </button>
          </template>
          <template v-else-if="step === 1">
            <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--reverse -pub-button--default">
              <span class="-pub-button__text" @click="step = 2">결과보기</span>
            </button>
          </template>
          <template v-else>
            <button type="button" class="-pub-button">
            <span class="-pub-button__text">취소</span>
            </button><button type="button" class="-pub-button -pub-button--reverse -pub-button--default">
              <span class="-pub-button__text" >다시 불러오기</span>
            </button>
          </template>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import { tableData1, tableData2, tableData3, tableData4 } from '@/components/mock/TSSCT004P.mock'
export default {
  data () {
    return {
      step: 0,
      showPopup: true,
      isEmpty: false,
      tableData1: Array.prototype.slice.call(tableData1),
      tableData2: Array.prototype.slice.call(tableData2),
      tableData3: Array.prototype.slice.call(tableData3),
      tableData4: Array.prototype.slice.call(tableData4)
    }
  }
}
</script>
