<template>
  <div>
    <span :class="myClass"></span>{{item.name}}
  </div>
</template>
<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col'],
  computed: {
    myClass () {
      if (this.item.new === 'new') {
        return 'new'
      } else {
        return ''
      }
    }
  }
}
</script>

<style scoped>
  /* .new {
    position: relative;
    padding-left: 10px;
  }

  .new::before {
    content: '';
    position: absolute;
    top: 10px;
    left: 0;
    width: 30px;
    height: 30px;
    background: url('/src/assets/img/customer/home_new_badge.png');
    background-size: 100%;
    background-position: left top;
    background-repeat: no-repeat;
  } */
</style>
