<template>
    <div class="-pub-consulting-popup__fixed-content">
      <div class="-pub-consulting-popup__content">
        <ul class="-pub-consulting-popup__content-item">
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">가입 회사</div>
            <fdp-validator name="tssct018p-validator1" display-name="가입회사" v-model="contractorCompany" :rules="'required'">
              <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small" v-model="contractorCompany" placeholder="입력해주세요."></fdp-text-field>
            </fdp-validator>
          </li>
        </ul>
        <ul class="-pub-consulting-popup__content-item -pub-consulting-popup__content-item--sub">
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">상품명</div>
            <fdp-validator name="tssct018p-validator2" display-name="상품명" v-model="productName" :rules="'required'">
              <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small normal-letter"
                v-model="productName" placeholder="입력해주세요."></fdp-text-field>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">유니버설 상품</div>
            <fdp-validator name="tssct018p-validator3" display-name="유니버설 상품" v-model="segment1.value" :rules="'required'">
              <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                v-model="segment1.value" :data="segment1.items" :essential="true"></fdp-segment-box>
            </fdp-validator>
          </li>
        </ul>
      </div>
      <h3 class="-pub-consulting-popup__title -pub-consulting-popup__title--type-3">보험 기본 정보</h3>
      <div class="-pub-consulting-popup__content">
        <ul class="-pub-consulting-popup__content-item">
          <li class="-pub-consulting-popup__search-row  -pub-consulting-popup__search-row--top">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">보험대상자</div>
            <fdp-validator name="tssct018p-validator4" display-name="보험대상자" v-model="select2.value.key" :rules="'required'">
              <fdp-select class="-pub-select -pub-filter-menu__item--select select-default" v-model="select2.value"
                :option-list="select2.items"></fdp-select>
              <p class="-pub-consulting-popup__row-sub-text">본인 / 보험연령 43세 / 여자</p>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">피보험자구분</div>
            <fdp-validator name="tssct018p-validator5" display-name="피보험자구분" v-model="segment3.value" :rules="'required'">
              <fdp-segment-box class="-pub-consulting-popup__row-item -pub-consulting-popup__row-item--small -pub-segment__container -pub-segment--medium"
                v-model="segment3.value" :data="segment3.items" :essential="true"></fdp-segment-box>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">계약번호</div>
            <fdp-validator name="tssct018p-validator6" display-name="계약번호" v-model="contractorNumber" :rules="'required'">
              <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small normal-letter" v-model="contractorNumber"></fdp-text-field>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">계약자</div>
            <fdp-validator name="tssct018p-validator7" display-name="계약자" v-model="contractor" :rules="'required'">
              <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small" v-model="contractor"></fdp-text-field>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">계약년월</div>
            <fdp-validator name="tssct018p-validator8" display-name="계약년월" v-model="date1" :rules="'required'">
              <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small" minimumView="month"
                initialView="month" v-model="date1" format="yyyy-MM"></fdp-date-picker>
            </fdp-validator>
          </li>
        </ul>
        <ul class="-pub-consulting-popup__content-item -pub-consulting-popup__content-item--sub">
          <li class="-pub-consulting-popup__search-row -pub-consulting-popup__date-area">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">만기년월</div>
            <fdp-validator name="tssct018p-validator9" display-name="만기년월" v-model="date2" :rules="'required'">
              <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small" minimumView="month"
                initialView="month" v-model="date2" format="yyyy-MM" :disabled="date2Life"></fdp-date-picker>
            </fdp-validator>
            <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="date2Life">종신</fdp-checkbox>
          </li>
          <li class="-pub-consulting-popup__search-row -pub-consulting-popup__date-area">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">정기사망특약 만기년월</div>
            <fdp-validator name="tssct018p-validator10" display-name="만기년월" v-model="date3" :rules="'required'">
              <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small" minimumView="month"
                initialView="month" v-model="date3" format="yyyy-MM" :disabled="date3Life"></fdp-date-picker>
            </fdp-validator>
            <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="date3Life">종신</fdp-checkbox>
          </li>
          <li class="-pub-consulting-popup__search-row -pub-consulting-popup__date-area">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">특약만기년월</div>
            <fdp-validator name="tssct018p-validator11" display-name="만기년월" v-model="date4" :rules="'required'">
              <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small" minimumView="month"
                initialView="month" v-model="date4" format="yyyy-MM" :disabled="date4Life"></fdp-date-picker>
            </fdp-validator>
            <fdp-checkbox class="-pub-checkbox" isIconCheckbox v-model="date4Life">종신</fdp-checkbox>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">납입주기</div>
            <fdp-validator name="tssct018p-validator12" display-name="납입주기" v-model="select3.value.key" :rules="'required'">
              <fdp-select class="-pub-select -pub-filter-menu__item--select select-default" v-model="select3.value"
                :option-list="select3.items"></fdp-select>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">납입완료</div>
            <fdp-validator name="tssct018p-validator13" display-name="납입완료" v-model="date5" :rules="'required'">
              <fdp-date-picker class="-pub-date-picker search-field -pub-consulting-popup__row-item--small" minimumView="month"
                initialView="month" v-model="date5" format="yyyy-MM"></fdp-date-picker>
            </fdp-validator>
          </li>
          <li class="-pub-consulting-popup__search-row">
            <div class="-pub-consulting-popup__search-row-name -pub-consulting-popup__row-item">보험료(원)</div>
            <fdp-validator name="tssct018p-validator14" display-name="보험료" v-model="insurance" :rules="'required'">
              <fdp-text-field class="-pub-text-field search-field -pub-consulting-popup__row-item--small normal-letter"
                v-model="insurance" mask="won"></fdp-text-field>
            </fdp-validator>
          </li>
        </ul>
      </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      date1: '2017-01',
      date2: '2017-03',
      date3: '2017-07',
      date4: '2017-07',
      date5: '2017-07',
      date2Life: false,
      date3Life: false,
      date4Life: false,
      contractorNumber: '1234567890',
      contractor: '이주명',
      contractorCompany: '',
      insurance: '35,000',
      interestRate: '0',
      productName: '',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },

      segment1: {
        items: [{
          key: '1',
          label: '예'
        },
        {
          key: '2',
          label: '아니오'
        }
        ],
        value: [{
          key: '1',
          label: '생명보험'
        }]
      },
      segment2: {
        items: [{
          key: '1',
          label: '일반'
        },
        {
          key: '2',
          label: '유니버셜'
        }
        ],
        value: [{
          key: '1',
          label: '주피'
        }]
      },
      segment3: {
        items: [{
          key: '1',
          label: '주피'
        },
        {
          key: '2',
          label: '종피'
        }
        ],
        value: [{
          key: '1',
          label: '주피'
        }]
      },
      select1: {
        value: {
          key: '1',
          label: '교보생명'
        },
        items: [{
          key: '1',
          label: '교보생명'
        }]
      },
      select2: {
        value: {
          key: '1',
          label: '이주명'
        },
        items: [{
          key: '1',
          label: '이주명'
        }]
      },
      select3: {
        value: {
          key: '1',
          label: '월납'
        },
        items: [{
          key: '1',
          label: '월납'
        }]
      },
      searchKeyword: ''
    }
  }
}
</script>
