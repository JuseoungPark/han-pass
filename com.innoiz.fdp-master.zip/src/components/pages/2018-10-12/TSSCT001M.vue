<template>
    <section class="-pub-consulting -pub-with-gnb -pub-consulting-home">
        <div class="-pub-page-header -pub-page-header--bottom-bordered">
            <h2 class="-pub-page-header__title">
                <span class="-pub-page-header__text--parent-bottom">컨설팅</span>
            </h2>
            <fdp-tooltip-button class="-pub-tooltip">
                <template slot="activator">
                    <img class="-pub-tooltip__icon" src="@/assets/img/components/ico_info_gray.png" alt="툴팁" />
                </template>
                <template slot="content">
                    <div class="-pub-customer-tooltip-home">
                        <div class="-pub-text -pub-text-1">
                            필수 컨설팅동의가 완료되어야 통합보장분석 모든 단계 진행이 가능합니다.<br>
                            마케팅동의 시, 직접 입력한 상품에 한해서 통합보장분석 분석이 가능합니다.
                        </div>
                        <div class="-pub-text -pub-text-2">
                            타사보장분석 화면 진입은 가입설계에서 가능합니다.
                        </div>
                    </div>
                </template>
            </fdp-tooltip-button>

            <div class="-pub-page-header__content">
                <a class="-pub-page-header__button -pub-button -pub-button--purple -pub-button--light -pub-button--reverse -pub-page-header__button--icon">
                    <img src="@/assets/img/ico_home_life_2.png" alt="뒤로가기">
                    <span>라이프 분석</span>
                </a>
                <a class="-pub-page-header__button -pub-button -pub-button--purple -pub-button--light -pub-button--reverse -pub-page-header__button--icon">
                    <img src="@/assets/img/ico_home_analysis_2.png" alt="뒤로가기">
                    <span>보장분석</span>
                </a>
            </div>
        </div>

        <section class="-pub-list__left-side">
            <div class="-pub-filter-menu">
                <div class="-pub-filter-menu__item--right">
                    <form onsubmit="return false;">
                        <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
                        <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </form>
                </div>
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
            </div>
            <!-- 페이지 조회 input, button 검색 명수 영역 end -->
            <!-- 고객 관련 정보 데이터 테이블 영역 -->
            <fdp-infinite class="-pub-table -pub-table--customer-service " multi-select v-model="selectItems" :table-body-height="hasSelectItem ? 834 : 968" :items="mockData">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column--checkbox">
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="tableHeader.isSelectAll" @input="selectAllItemsFunc(tableHeader.isSelectAll)"></fdp-checkbox>
                        </th>
                        <th v-for="item in tableHeader.headerItems" :key="item.title" :style="item.styleObject" :class="[{'-pub-table-column':true},{'-pub-table-column--left-align':item.isAlign === 'left'},{'-pub-table-column--sorting':item.sort.isSort}]" @click="sortFunc(item)">
                            <!-- sorting이 필요한 컬럼 -->
                            <span v-if="item.sort.isSort" :class="[{'-pub-table-column__text':true}, {'-pub-sorting--active':item.isActive}, {'-pub-sorting--up': item.sort.asc}, {'-pub-sorting--purple': item.isActive}, {'-pub-table-column--normal-letter':item.isNormal}]">{{item.title}}
                                <img v-if="item.sort.isSort" src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                            </span>
                            <!-- sorting이 필요 없는 컬럼 -->
                            <span v-else :class="[{'-pub-table-column__text':true}]">{{item.title}}</span>
                        </th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column--checkbox">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems" :value="props.item"></fdp-checkbox>
                    </td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 106px;">{{props.item.data1}}</td>
                    <td class="-pub-table-column" style="width: 130px;">
                        {{props.item.data2}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--left-align -pub-table-column--normal-letter" style="width: 128px;">
                        <template v-if="props.item.data3 === '-'">
                            {{props.item.data3}}
                        </template>
                        <template v-else-if="props.item.data3 <= 30">
                            <span class="-pub-agree-text">D-{{props.item.data3}}</span>
                        </template>
                        <template v-else-if="props.item.data3 <= 99">
                            <span class="-pub-agree-text -pub-agree-text--grey-icon">D-{{props.item.data3}}</span>
                        </template>
                        <template v-else>
                            <span class="-pub-agree-text -pub-agree-text--grey-icon">D-99+</span>
                        </template>
                    </td>
                    <td class="-pub-table-column -pub-table-column--left-align -pub-table-column--normal-letter" style="width: 120px;">
                        <template v-if="props.item.data4 === '-'">
                            {{props.item.data4}}
                        </template>
                        <template v-else-if="props.item.data4 <= 30">
                            <span class="-pub-agree-text">D-{{props.item.data4}}</span>
                        </template>
                        <template v-else-if="props.item.data4 <= 99">
                            <span class="-pub-agree-text -pub-agree-text--grey-icon">D-{{props.item.data4}}</span>
                        </template>
                        <template v-else>
                            <span class="-pub-agree-text -pub-agree-text--grey-icon">D-99+</span>
                        </template>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 164px;">
                        <template v-if="props.item.data5 === '시작하기'">
                            <button class="-pub-pp-table-column__button" @click.stop="clickLife">{{props.item.data5}}</button>
                        </template>
                        <template v-else>
                            <span class="-pub-table-column__text--bottom-line">{{props.item.data5}}</span>
                        </template>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 164px;">
                        <template v-if="props.item.data6 === '시작하기'">
                            <button class="-pub-pp-table-column__button" @click.stop="clickGuarantee">{{props.item.data6}}</button>
                        </template>
                        <template v-else>
                            <span class="-pub-table-column__text--bottom-line">{{props.item.data6}}</span>
                        </template>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 190px;">
                        <template v-if="props.item.data7 === '설계하기'">
                            <button class="-pub-pp-table-column__button" @click.stop="clickNewProduct">{{props.item.data7}}</button>
                        </template>
                        <template v-else>
                            <span>{{props.item.data7}}</span>
                        </template>
                    </td>
                </template>
                <template slot="emptyView" v-if="searchRes==='1'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                    </div>
                </template>
                <template slot="emptyView" v-if="searchRes==='2'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                    </div>
                </template>
            </fdp-infinite>
            <!-- 고객 관련 정보 데이터 테이블 영역 end -->
        </section>

        <section class="-pub-card-wrap -pub-list__right-side">
          <!-- 18.10.18 최신활동고객 List 열림닫힘 수정 start -->
            <div class="-pub-customer-card__top-area"  @click="clickChk1">
                <span>최근 활동 고객 <strong>(상령일)</strong></span>
                <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model='chk1'>펼쳐보기</fdp-checkbox>
            </div>
            <fdp-list class="-fdp-list-page__list -pub-customer-card__list" :list-data="cardTypes" :list-height="hasSelectItem ? 862 : 996" @loading-data="loadingData" ref="targetFdpList">
                <template slot="default" slot-scope="props">
                    <div class="-fdp-list-page__item -pub-customer-card__item" :class="[props.item.open ? '-pub-customer-card__item--open': '']">
                        <div @click="clickName(props.item.idx)">
                            <span>{{props.item.name}}</span>
                            <span>{{props.item.date}} <strong>&nbsp;</strong>{{props.item.data}}</span>
                        </div>
                        <ul>
                            <li>
                                <span>D-30</span>
                                <span>필수건설팅</span>
                            </li>
                            <li>
                                <span>D-99+</span>
                                <span>마케팅</span>
                            </li>
                        </ul>
                        <button class="-pub-button -pub-button__life-analysis">라이프분석</button>
                    <button class="-pub-button -pub-button__assurance-analysis">보장분석</button>
                    </div>
                </template>
            </fdp-list>
            <!-- 18.10.18 최신활동고객 List 열림닫힘 수정 end -->
        </section>

        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default" v-show="mockCheckCount > 0" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0"
                    @click="cancelSeletItemsFunc">
                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck">{{mockCheckCount}}명 선택</fdp-checkbox>
                </li>
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item">
                        <span class="-pub-button__text">삭제</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
    </section>
</template>
<script>
import viewMemberMocks from '@/components/mock/TSSCT001M.mock'
export default {
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  data () {
    return {
      currMenu: '',
      currMenu2: '',
      searchKeyword: '',
      mockData: Object.assign([], viewMemberMocks),
      //   mockData: [],
      mockHeader: [],
      searchRes: '',
      tableHeader: {
        isSelectAll: false,
        lastVisitColumn: 0,
        // fdp-infinite 헤더 관리
        headerItems: [
          {idx: 0, title: '고객명', isAlign: 'left', isNormal: false, isActive: true, sort: {isSort: true, asc: false}, styleObject: {width: '109px'}},
          {idx: 1, title: '나이/성별', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '130px'}},
          {idx: 2, title: '필수컨설팅', isAlign: 'left', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '128px'}},
          {idx: 3, title: '마케팅', isAlign: 'left', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '120px'}},
          {idx: 4, title: '라이프분석', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '164px'}},
          {idx: 5, title: '보장분석', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '164px'}},
          {idx: 6, title: '최신상품설계', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '190px'}}
        ]
      },
      selectItems: [],
      bottomBarCheck: false,
      chk1: false,
      cardTypes: [{
        idx: 0,
        name: '김병은병',
        date: '(10월22일)',
        data: '10개월 전 보장분석',
        open: false
      },
      {
        idx: 1,
        name: '김병은',
        date: '(10월22일)',
        data: '1주 전 보장분석',
        open: false
      },
      {
        idx: 2,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 3,
        name: '김병은',
        date: '(10월22일)',
        data: '1년 전 보장분석',
        open: false
      },
      {
        idx: 4,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 5,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 6,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 7,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 8,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 9,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 10,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 11,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 12,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 13,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 14,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 15,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 16,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 17,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 18,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 19,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      },
      {
        idx: 20,
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석',
        open: false
      }]
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.tableHeader.isSelectAll = false
      } else {
        this.tableHeader.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  },
  methods: {
    // 소팅 처리
    sortFunc (item) {
      if (item.sort.isSort) {
        // 선택 컬럼 active, 마지막 선택 컬럼 inactive
        this.tableHeader.headerItems[this.tableHeader.lastVisitColumn].isActive = false
        this.tableHeader.lastVisitColumn = item.idx
        item.isActive = true
        item.sort.asc = !item.sort.asc

        // Mockup 데이터
        let data = this.mockData

        if (item.title.localeCompare('고객명') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.data1.localeCompare(b.data1)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.data1.localeCompare(a.data1)
              }
            )
          }
        } else if (item.title.localeCompare('라이프분석') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.data5.localeCompare(b.data5)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.data5.localeCompare(a.data5)
              }
            )
          }
        } else if (item.title.localeCompare('보장분석') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.data6.localeCompare(b.data6)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.data6.localeCompare(a.data6)
              }
            )
          }
        } else if (item.title.localeCompare('최신상품설계') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.data7.localeCompare(b.data7)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.data7.localeCompare(a.data7)
              }
            )
          }
        } else {}
      }
    },
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.tableHeader.isSelectAll = false
    },
    // 라이브분석 컬럼의 버튼 클릭
    clickLife () {

    },
    // 보장분석 컬럼의 버튼 클릭
    clickGuarantee () {

    },
    // 최신상품검색 컬럼의 버튼 클릭
    clickNewProduct () {

    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    },
    isLoadingStatus () {

    },
    onSearch () { // 검색어 2: 검색결과 없음, 1: 진행건 없음
      if (this.searchKeyword === '') {
        this.searchRes = ''
        this.mockData = Object.assign([], viewMemberMocks)
      } else if (this.searchKeyword === '1') {
        this.searchRes = '1'
        this.mockData = []
      } else {
        this.searchRes = '2'
        this.mockData = []
      }
    },
    // 18.10.18 최신활동고객 List 열림닫힘 수정 start
    clickChk1 () {
      let i
      for (i = 0; i < this.cardTypes.length; i++) {
        this.cardTypes[i].open = this.chk1
      }
    },
    clickName (idx) {
      this.cardTypes[idx].open = !this.cardTypes[idx].open
    }
    // 18.10.18 최신활동고객 List 열림닫힘 수정 end
  }
}
</script>
