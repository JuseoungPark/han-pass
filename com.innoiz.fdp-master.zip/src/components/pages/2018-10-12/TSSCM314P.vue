<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="캠페인 고객 직접 선정" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__campaign--direct">
                <div class="-pub-popup__campaign--direct-header">
                    <span class="-pub-popup__campaign--direct-text-select">캠페인</span>
                    <fdp-validator name="Name" v-model="selectGroups.values.group1.key" display-name="캠페인" :rules="'required'">
                        <fdp-select class="-pub-popup__campaign--direct-select" v-model="selectGroups.values.group1"
                        :option-list="selectGroups.group1"></fdp-select>
                    </fdp-validator>
                    <span class="-pub-popup__campaign--direct-text-move">캠페인 상세내용</span>
                </div>
                <!-- 페이지 조회 input, button 검색 명수 영역  -->
                <div class="-pub-filter-menu">
                    <div class="-pub-filter-menu__item--right">
                        <form onsubmit="return false;">
                            <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple"
                            placeholder="고객명" v-model="searchKeyword" clearable></fdp-text-field>
                            <button type="submit" class="-pub-search-button -pub-filter-menu__item">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                            </button>
                        </form>
                    </div>
                    <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총
                    {{mockData.length}}명</div>
                </div>
                <!-- 페이지 조회 input, button 검색 명수 영역 end -->
                <!-- 고객 관련 정보 데이터 테이블 영역 -->
                <fdp-infinite class="-pub-table" v-model="selectItems" multi-select :items="mockData">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column--checkbox" style="width: 78px;">
                                <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
                                v-model="isSelectAll" @input="selectAllItemsFunc(isSelectAll)"></fdp-checkbox>
                            </th>
                            <th class="-pub-table-column" style="width: 132px;">고객명</th>
                            <th class="-pub-table-column" style="width: 160px;">생년월일</th>
                            <th class="-pub-table-column" style="width: 76px;">성별</th>
                            <th class="-pub-table-column" style="width: 278px;">선정여부</th>
                            <th class="-pub-table-column" style="width: 200px;">연락처</th>
                            <th class="-pub-table-column" style="width: 150px;">고객유형</th>
                            <th class="-pub-table-column -pub-table-column--left-align" style="width: 214px;">필수컨설팅</th>
                        </tr>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView">
                        <div class="empty-table-content -pub-table-empty-view--fix-height">
                            <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text" v-if="isEmptySearchKeyword">데이터가 존재하지 않습니다. </div>
                            <div class="empty-table-content__text" v-else>검색결과가 존재하지 않습니다.</div>
                        </div>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column--checkbox" style="width: 78px;">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox
                            v-model="selectItems" :value="props.item"></fdp-checkbox>
                        </td>
                        <td class="-pub-table-column -pub-table-column--name" style="width: 132px;">{{props.item.name}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 160px;">{{props.item.birthDay}}</td>
                        <td class="-pub-table-column" style="width: 80px;">{{props.item.gender}}</td>
                        <td class="-pub-table-column" style="width: 278px;">{{props.item.choose}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 200px;">{{props.item.phone}}</td>
                        <td class="-pub-table-column" style="width: 150px;">{{props.item.customerType}}</td>
                        <td class="-pub-table-column -pub-table-column--left-align -pub-table-column--normal-letter" style="width: 214px;">
                           <template v-if="props.item.consulting === '11'">
                                <span class="-pub-agree-text">D-11</span> <!-- 디데이 설정 -->
                            </template>
                            <template v-else-if="props.item.consulting === '31'">
                                <span class="-pub-agree-text -pub-agree-text--grey-icon">D-31</span> <!--  -->
                            </template>
                            <template v-else>
                                N
                            </template>
                        </td>
                    </template>
                </fdp-infinite>
                <!-- 고객 관련 정보 데이터 테이블 영역 end -->
            </div>
            <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default" v-show="true">
                <ul class="-pub-bottom-nav">
                    <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox
                        v-model="bottomBarCheck" @input="cancelSeletItemsFunc">{{mockCheckCount}}명 선택</fdp-checkbox>
                    </li>
                    <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                        <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
                            <span class="-pub-button__text">취소</span>
                        </button>
                        <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                            <span class="-pub-button__text">확인</span>
                        </button>
                    </li>
                </ul>
            </fdp-bottom-bar>
            <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
import {
  viewMemberMocks
} from '@/components/mock/TSSCM314P.mock'

export default {
  data () {
    return {
      showPopup: true,
      returnDate: '',
      name: '',
      searchKeyword: '',
      mockData: Array.prototype.slice.call(viewMemberMocks),
      tableBodyHeight: 628,
      isSelectAll: false,
      bottomBarCheck: false,
      isEmptySearchKeyword: false,
      selectItems: [],
      selectGroups: {
        group1: [{
          key: '1',
          label: '5월 신CI보험 타겟 고객'
        }],
        values: {
          group1: {
            key: '1',
            label: '5월 신CI보험 타겟 고객'
          }
        }
      }
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    }
  },
  methods: {
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.isSelectAll = false
    }
  },
  watch: {
    // table내 record가 갖는 checkbox 선택 시 후처리
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.isSelectAll = false
      } else {
        this.isSelectAll = true
      }

      if (this.selectItems.length === 0) this.bottomBarCheck = false
      else this.bottomBarCheck = true
    }
  }
}
</script>
