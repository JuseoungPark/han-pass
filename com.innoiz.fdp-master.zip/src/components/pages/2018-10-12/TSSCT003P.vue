<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="상속세 계산하기" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
      <div class="-pub-popup -pub-consulting-popup -pub-consulting-popup--type-3">
        <section class="-pub-consulting-popup__container">
          <aside class="-pub-consulting-popup__left-form">
            <h3 class="-pub-consulting-popup__form-title">보유자산<span class="-pub-required"></span></h3>
            <ul class="-pub-consulting-popup__form-list">
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">금융자산</div>
                <fdp-validator name="tssct003p-validator1" display-name="금융자산" v-model="price1" :rules="'required'">
                  <fdp-text-field class="-pub-text-field normal-letter" v-model="price1" mask="won" placeholder="입력하세요."></fdp-text-field>
                </fdp-validator>
                <span class="-pub-consulting-popup__col-unit-text">만원</span>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">부동산</div>
                <fdp-validator name="tssct003p-validator2" display-name="부동산" v-model="price2" :rules="'required'">
                  <fdp-text-field class="-pub-text-field normal-letter" v-model="price2" mask="won" placeholder="입력하세요."></fdp-text-field>
                </fdp-validator>
                <span class="-pub-consulting-popup__col-unit-text">만원</span>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">금융채무</div>
                <fdp-validator name="tssct003p-validator3" display-name="금융채무" v-model="price3" :rules="'required'">
                  <fdp-text-field class="-pub-text-field normal-letter" v-model="price3" mask="won" placeholder="입력하세요."></fdp-text-field>
                </fdp-validator>
                <span class="-pub-consulting-popup__col-unit-text">만원</span>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">임대보증금</div>
                <fdp-validator name="tssct003p-validator4" display-name="임대보증금" v-model="price4" :rules="'required'">
                  <fdp-text-field class="-pub-text-field normal-letter" v-model="price4" mask="won" placeholder="입력하세요."></fdp-text-field>
                </fdp-validator>
                <span class="-pub-consulting-popup__col-unit-text">만원</span>
              </li>
            </ul>
            <h3 class="-pub-consulting-popup__form-title">조건설정</h3>
            <ul class="-pub-consulting-popup__form-list">
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">배우자</div>
                <fdp-segment-box class="-pub-segment__container -pub-segment--small" v-model="segment1.value" :data="segment1.items"
                  :essential="true"></fdp-segment-box>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">자녀수</div>
                <fdp-select class="-pub-select" v-model="select1.value" :option-list="select1.items" placeholder="자녀수"></fdp-select>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">금융자산상승률</div>
                <fdp-select class="-pub-select" up v-model="select2.value" :option-list="select2.items" placeholder="금융자산상승률"></fdp-select>
              </li>
              <li class="-pub-consulting-popup__form-item">
                <div class="-pub-consulting-popup__col-name">부동산상승률</div>
                <fdp-select class="-pub-select" up v-model="select3.value" :option-list="select3.items" placeholder="부동산상승률"></fdp-select>
              </li>
            </ul>
          </aside>
          <div class="-pub-consulting-popup__table-area">
            <h3 class="-pub-consulting-popup__form-title">
              예상 상속세
              <fdp-tooltip-button class="-pub-tooltip -pub-tooltip--img-button">
                <template slot="activator">
                  <img class="tooltip-icon-img" src="@/assets/img/life/ico-info-gray-2.png" alt="툴팁">
                </template>
                <template slot="content">
                  <h3 class="-pub-consulting-popup__tooltip-title">[참고사항]</h3>
                  <ul class="-pub-consulting-popup__tooltip-list">
                    <li class="-pub-consulting-popup__tooltip-item -pub-tooltip__guide-item">상속재산의 간주, 추정상속재산은 고려하지 않습니다.</li>
                    <li class="-pub-consulting-popup__tooltip-item -pub-tooltip__guide-item">장례비 공제는 최대 1,000만원으로 가정하며, 미성년, 연로자, 장애인 공제는 未 적용 하였습니다.</li>
                    <li class="-pub-consulting-popup__tooltip-item -pub-tooltip__guide-item">세대생략가산액은 고려하지 않으며, 신고세액공제는 3%(2019.1月 기준)를 적용하였습니다.</li>
                    <li class="-pub-consulting-popup__tooltip-item -pub-tooltip__guide-item">해당 내용은 참고용으로 작성된 자료로 법적인 효력이 없으니, 세금 관련사항은 전문가와<br>상의하시기 바랍니다.</li>
                  </ul>
                </template>
              </fdp-tooltip-button>
            </h3>
            <fdp-infinite :items="isAfter ? tableData1 : []" class="-pub-table"
            :tableHeaderHeight="132" :tableBodyHeight="670">
            <template slot="header">
              <tr class="-pub-table__header">
                <th class="-pub-consulting-grid__column" style="width: 224px;"></th>
                <th class="-pub-consulting-grid__column" style="width: 192px;">현재</th>
                <th class="-pub-consulting-grid__column" style="width: 192px;">
                  <div class="-pub-consulting-popup__form-item">
                    <fdp-validator name="tssct003p-validator5" display-name="나이1" v-model="age1" :rules="'required'">
                      <fdp-text-field class="-pub-text-field normal-letter" v-model="age1" mask="number"></fdp-text-field>
                    </fdp-validator>
                    <span class="-pub-consulting-popup__col-unit-text">세</span>
                  </div>
                </th>
                <th class="-pub-consulting-grid__column" style="width: 192px;">
                  <div class="-pub-consulting-popup__form-item">
                    <fdp-validator name="tssct003p-validator6" display-name="나이2" v-model="age2" :rules="'required'">
                      <fdp-text-field class="-pub-text-field normal-letter" v-model="age2" mask="number"></fdp-text-field>
                    </fdp-validator>
                    <span class="-pub-consulting-popup__col-unit-text">세</span>
                  </div>
                </th>
                <th class="-pub-consulting-grid__column" style="width: 192px;">
                  <div class="-pub-consulting-popup__form-item">
                    <fdp-validator name="tssct003p-validator7" display-name="나이3" v-model="age3" :rules="'required'">
                      <fdp-text-field class="-pub-text-field normal-letter" v-model="age3" mask="number"></fdp-text-field>
                    </fdp-validator>
                    <span class="-pub-consulting-popup__col-unit-text">세</span>
                  </div>
                </th>
              </tr>
            </template>
            <template slot-scope="props">
              <td class="-pub-consulting-grid__column align-left" style="width: 224px;">{{props.item.name}}</td>
              <td class="-pub-consulting-grid__column normal-letter align-right" >{{props.item.current}} 만원</td>
              <td class="-pub-consulting-grid__column normal-letter align-right" >{{props.item.after1}} 만원</td>
              <td class="-pub-consulting-grid__column normal-letter align-right" >{{props.item.after2}} 만원</td>
              <td class="-pub-consulting-grid__column normal-letter align-right">{{props.item.after3}} 만원</td>
            </template>
            <template slot="emptyView">
              <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                <div class="empty-table-content__text">보유자산 및 조건을 설정한 후 계산하기 버튼을 터치하세요.</div>
              </div>
            </template>
          </fdp-infinite>
          </div>
        </section>
      </div>
      <div class="-pub-bottom-bar -pub-bottom-bar--no-v-padding">
        <div class="-pub-confirm__content -pub-calc-button-area">
          <button type="button" class="-pub-button -pub-button--calc -pub-button--disabled-reverse" :disabled="!(price1 || price2 || price3 || price4)" @click="isAfter = true">
            <span>계산하기</span>
          </button>
        </div>
        <div class="-pub-confirm__content--right -pub-confirm__content--centered">
          <button type="button" class="-pub-button -pub-button--reverse -pub-button--default" :disabled="!isAfter">
            <span class="-pub-button__text">확인</span>
          </button>
        </div>
      </div>
    </div>
  </fdp-popup>
</template>
<script>
import {
  tableData1
} from '@/components/mock/TSSCT003P.mock'
export default {
  data () {
    return {
      isAfter: false,
      showPopup: true,
      isEmpty: false,
      contractor: '이주명',
      insurance: '35,000',
      interestRate: '0',
      price1: '',
      price2: '',
      price3: '',
      price4: '',
      age1: '80',
      age2: '90',
      age3: '100',
      radio1: {
        items: ['등록상품', '미등록상품'],
        value: '등록상품'
      },
      segment1: {
        items: [{
          key: '1',
          label: '없음'
        },
        {
          key: '2',
          label: '있음'
        }
        ],
        value: [{
          key: '1'
        }]
      },
      select1: {
        value: {
          key: '1',
          label: '1명'
        },
        items: [{
          key: '1',
          label: '1명'
        },
        {
          key: '2',
          label: '2명'
        },
        {
          key: '3',
          label: '3명'
        }
        ]
      },
      select2: {
        value: {
          key: '3',
          label: '3%'
        },
        items: [{
          key: '1',
          label: '1%'
        },
        {
          key: '2',
          label: '2%'
        },
        {
          key: '3',
          label: '3%'
        },
        {
          key: '4',
          label: '4%'
        },
        {
          key: '4',
          label: '5%'
        }
        ]
      },
      select3: {
        value: {
          key: '5',
          label: '5%'
        },
        items: [{
          key: '1',
          label: '1%'
        },
        {
          key: '2',
          label: '2%'
        },
        {
          key: '3',
          label: '3%'
        },
        {
          key: '4',
          label: '4%'
        },
        {
          key: '4',
          label: '5%'
        }
        ]
      },
      searchKeyword: '',
      tableData1: Array.prototype.slice.call(tableData1)
    }
  }
}
</script>
