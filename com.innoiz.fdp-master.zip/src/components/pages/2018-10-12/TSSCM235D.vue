<template>
    <div class="-pub-content-scroll"><!-- -pub-fdp-list__empty-view 데이터가 없을 경우 클래스 추가 --><!-- 목업 추가 20181113 -->
        <div>
            <fdp-list class="-fdp-list-page__list" :list-data="mockData" :list-height="877" ref="targetFdpList">
                <template slot="emptyView"><!-- 목업 변경 20181113 -->
                    <div class="-pub-table-empty-view">
                        <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                    </div>
                </template>
                <template slot="default" slot-scope="props">
                    <div class="-pub-accordion-container" v-for="(mock, index2) in props.item.data" :key="'b' + index2">
                        <div class="-pub-accordion-line">
                            <span class="-pub-accordion-line__text">{{mock.date}}</span>
                        </div>
                        <div class="-pub-accordion" :class="[mock.expand ? '-pub-accordion--expanded' : '']" >
                            <div class="-pub-accordion__title">
                                <div class="-pub-accordion__text -pub-accordion__text--type3">
                                    <div class="-pub-table-colmn__single-line--ellipsis">{{mock.type}}</div>
                                </div>
                                <div class="-pub-accordion__text -pub-accordion__text--insure-benefit -pub-accordion__text--insure-benefit-sort">
                                    <span class="-pub-table-colmn__single-line--ellipsis">{{mock.insure}}</span>원 지급
                                </div>
                                <div class="-pub-accordion__text -pub-accordion__text--id -pub-accordion__text--number -pub-accordion__text--id-right-sort">
                                    <div class="-pub-table-colmn__single-line--ellipsis">계약번호 : {{mock.id}}</div>
                                </div>
                                <a class="-pub-accordion__trigger" @click="mock.expand = !mock.expand"><img src="@/assets/img/customer/ico-arrow-down-black.png" alt=""></a>
                            </div>
                            <div class="-pub-accordion__content">
                                <div class="-pub-section" v-for="(department, index3) in mock.departments" :key="index3">
                                    <div class="-pub-accordion__text -pub-accordion__text--product">
                                        <span class="-pub-accordion__text--product-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">상품명</span>
                                        </span>
                                        <span class="-pub-accordion__text--product-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.product}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--product">
                                        <span class="-pub-accordion__text--product-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">상품명</span>
                                        </span>
                                        <span class="-pub-accordion__text--product-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.product}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--product">
                                        <span class="-pub-accordion__text--product-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">상품명</span>
                                        </span>
                                        <span class="-pub-accordion__text--product-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.product}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--divion">
                                        <span class="-pub-accordion__text--divion-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">처리부서</span>
                                        </span>
                                        <span class="-pub-accordion__text--divion-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.divion}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--charge">
                                        <span class="-pub-accordion__text--charge-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">처리자</span>
                                        </span>
                                        <span class="-pub-accordion__text--charge-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.name}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--divion">
                                        <span class="-pub-accordion__text--divion-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">처리부서</span>
                                        </span>
                                        <span class="-pub-accordion__text--divion-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.divion}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--charge">
                                        <span class="-pub-accordion__text--charge-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">처리자</span>
                                        </span>
                                        <span class="-pub-accordion__text--charge-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.name}}</span>
                                        </span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--product">
                                        <span class="-pub-accordion__text--product-tit">
                                            <span class="-pub-table-colmn__single-line--ellipsis">상품명</span>
                                        </span>
                                        <span class="-pub-accordion__text--product-name">
                                            <span class="-pub-table-colmn__single-line--ellipsis">{{department.product}}</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="-pub-accordion-container -pub-accordion-container--year">
                        <div class="-pub-accordion-line -pub-accordion-line--year">
                            <span class="-pub-accordion-line__text -pub-accordion-line__text--year">{{props.item.year}}</span>
                        </div>
                        <div class="-pub-accordion--empty"></div>
                    </div>
                </template>
            </fdp-list>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      mockData: [{
        year: 2017,
        data: [{
          expand: true,
          date: '07.16',
          type: '사고',
          insure: '15,000',
          id: '12312312312322',
          departments: [{
            product: '통합변액 유니버셜 CI 종신보험 2.0',
            divion: '0000부서',
            name: '000 김정은(123456)'
          }]
        },
        {
          expand: false,
          date: '07.16',
          type: '배당',
          insure: '11,500,000',
          id: '12312312312322',
          departments: [{
            product: '통합변액 유니버셜 CI 종신보험 2.0',
            divion: '0000부서',
            name: '000 김정은(123456)'
          }]
        },
        {
          expand: false,
          date: '07.16',
          type: '배당',
          insure: '112,300',
          id: '12312312312322',
          departments: [{
            product: '통합변액 유니버셜 CI 종신보험 2.0',
            divion: '0000부서',
            name: '000 김정은(123456)'
          }]
        }
        ]
      },
      {
        year: 2016,
        data: [{
          expand: false,
          date: '07.16',
          type: '사고',
          insure: '15,000',
          id: '12312312312322',
          departments: [{
            product: '통합변액 유니버셜 CI 종신보험 2.0',
            divion: '0000부서',
            name: '000 김정은(123456)'
          }]
        },
        {
          expand: false,
          date: '07.16',
          type: '사고',
          insure: '500,000',
          id: '12312312312322',
          departments: [{
            product: '통합변액 유니버셜 CI 종신보험 2.0',
            divion: '0000부서',
            name: '000 김정은(123456)'
          }]
        }
        ]
      }]
    }
  }
}
</script>
