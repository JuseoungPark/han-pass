<!-- 설계청약 최근설계 탭 영역 -->
<template>
    <div class="-pub-tab-body-wrap -pub-electronic-subscription">
        <div class="-pub-filter-menu -pub-filter-menu--in-tab">
            <div class="-pub-filter-menu__item--right">
                <form onsubmit="return false;">
                    <fdp-select class="-pub-select -pub-select--purple  -pub-filter-menu__item -pub-filter-menu__item--select detail-type-6" v-model="selectBoxValue" :option-list="selectBoxItems" ellipsis></fdp-select>
                    <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="입력하세요." v-model="searchKeyword" clearable></fdp-text-field>
                    <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                        <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                    </button>
                </form>
            </div>
            <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{tableData.length}}건</div>
        </div>
        <!-- 페이지 조회 input, button 검색 명수 영역 end -->
        <!-- 고객 관련 정보 데이터 테이블 영역 -->
        <fdp-infinite class="-pub-table -pub-table--customer-service -pub-table--programmed-proposal" multi-select v-model="selectItems" :table-header-height="100" :table-body-height="660" :items="tableData">
            <template slot="header">
                <tr class="-pub-table__header">
                    <th v-for="item in tableHeader.headerItems" :key="item.title" :style="item.styleObject" :class="[{'-pub-table-column':true},{'-pub-table-column--sorting':item.sort.isSort}]" @click="sortFunc(item)">
                        <!-- sorting이 필요한 컬럼 -->
                        <span v-if="item.sort.isSort" :class="[{'-pub-table-column__text':true},  {'-pub-sorting--active':item.isActive}, {'-pub-sorting--up': item.sort.asc}, {'-pub-sorting--purple': item.isActive}, {'-pub-table-column--normal-letter':item.isNormal}]">{{item.title}}
                            <img v-if="item.sort.isSort" src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                        </span>
                        <!-- sorting이 필요 없는 컬럼 -->
                        <span v-else :class="[{'-pub-table-column__text':true}, {'-pub-multi-line-header': item.isMultiLine}]" v-html="item.title">{{item.title}}</span>
                    </th>
                </tr>
            </template>
            <template slot-scope="props">
                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 150px;">{{props.item.date}}</td>
                <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                    {{props.item.contractor}}
                </td>
                <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                    {{props.item.insuredPerson}}
                </td>
                <td class="-pub-table-column -pub-table-column--name" style="width: 156px;">
                    {{props.item.insuredPerson2}}
                </td>
                <td class="-pub-table-column -pub-table-column--left-align" style="width: 184px;">
                    <div class="-pub-table-colmn__single-line--ellipsis -pub-colored-text--2">
                        {{props.item.item}}
                    </div>
                </td>
                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 316px;">
                    {{props.item.no}}
                </td>
                <td class="-pub-table-column -pub-table-column--right-align -pub-table-column--normal-letter" style="width: 162px;">
                    {{props.item.cost}}
                </td>
                <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 130px;">
                    {{props.item.date2}}
                </td>
                <td class="-pub-table-column" style="width: 156px;">
                    <span class="-pub-table-column__text--bottom-line">{{props.item.status}}</span>
                </td>
            </template>
            <!-- no data 화면 -->
            <template slot="emptyView" v-if="searchRes==='1'">
                <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                    <div class="empty-table-content__text">진행중인 가입설계 건이 없습니다.</div>
                </div>
            </template>
            <!-- 검색결과 없을때 화면 -->
            <template slot="emptyView" v-if="searchRes==='2'">
                <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                    <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                </div>
            </template>
        </fdp-infinite>
        <!-- 고객 관련 정보 데이터 테이블 영역 end -->

        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default" v-show="true" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--medium -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">새로고침</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
    </div>
</template>
<script>
import { viewMemberMocks } from '@/components/mock/TSSPS214D.mock'

export default {
  data () {
    return {
      selectBoxValue: {
        key: '1',
        label: '고객명'
      },
      selectBoxItems: [{
        key: '1',
        label: '고객명'
      },
      {
        key: '2',
        label: '상품명'
      },
      {
        key: '3',
        label: '영수증번호'
      }],
      mockData: Object.assign([], viewMemberMocks),
      tableData: Object.assign([], viewMemberMocks),
      isNotEmpty: true,
      mockHeader: [],
      searchKeyword: '',
      searchRes: '',
      selectItems: [],
      tableHeader: {
        lastVisitColumn: 0,
        // fdp-infinite 헤더 관리
        headerItems: [
          {idx: 0, title: '청약일', isNormal: false, isActive: true, sort: {isSort: true, asc: false}, styleObject: {width: '150px'}},
          {idx: 1, title: '계약자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 2, title: '피보험자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 3, title: '종피보험자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '156px'}},
          {idx: 4, title: '상품명', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '184px'}},
          {idx: 5, title: '영수증번호', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '316px'}},
          {idx: 6, title: '보험료(원)', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '162px'}},
          {idx: 7, title: '미청약시<br>삭제예정일', isMultiLine: true, isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '130px'}},
          {idx: 8, title: '진행현황', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '156px'}}
        ]
      }
    }
  },
  watch: {
    isNotEmpty (val) {
      if (val) {
        this.tableData = [].concat(this.mockData)
      } else {
        this.tableData = []
      }
    }
  },
  methods: {
    // 소팅 처리
    sortFunc (item) {
      if (item.sort.isSort) {
        // 선택 컬럼 active, 마지막 선택 컬럼 inactive
        this.tableHeader.headerItems[this.tableHeader.lastVisitColumn].isActive = false
        this.tableHeader.lastVisitColumn = item.idx
        item.isActive = true
        item.sort.asc = !item.sort.asc

        // Mockup 데이터
        let data = this.tableData

        if (item.title.localeCompare('청약일') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.date.localeCompare(b.date)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.date.localeCompare(a.date)
              }
            )
          }
        } else if (item.title.localeCompare('계약자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.contractor.localeCompare(b.contractor)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.contractor.localeCompare(a.contractor)
              }
            )
          }
        } else if (item.title.localeCompare('피보험자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.insuredPerson.localeCompare(b.insuredPerson)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.insuredPerson.localeCompare(a.insuredPerson)
              }
            )
          }
        } else if (item.title.localeCompare('종피보험자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.insuredPerson2.localeCompare(b.insuredPerson2)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.insuredPerson2.localeCompare(a.insuredPerson2)
              }
            )
          }
        } else {}
      }
    },
    onSearch () { // 검색어 2: 검색결과 없음, 1: 진행건 없음
      if (this.searchKeyword === '') {
        this.searchRes = ''
        this.tableData = this.mockData
      } else if (this.searchKeyword === '1') {
        this.searchRes = '1'
        this.tableData = []
      } else {
        this.searchRes = '2'
        this.tableData = []
      }
    }
  }
}
</script>
