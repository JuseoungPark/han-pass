<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="캠페인 상세 내용" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__campaign--detail">
                <div class="-pub-popup__campaign--detail-header">
                    <span class="-pub-popup__campaign--detail-text-select">캠페인</span>
                    <fdp-validator name="Name" v-model="selectGroups.values.group1" display-name="캠페인" :rules="'required'">
                        <fdp-select class="-pub-popup__campaign--detail-select" v-model="selectGroups.values.group1"
                        :option-list="selectGroups.group1"></fdp-select>
                    </fdp-validator>
                </div>
                <div class="-pub-popup__campaign--detail-dec">
                    <div class="-pub-popup__campaign--detail-tit">고객사랑서비스 (M2017-I02-C07)</div>
                    <div class="-pub-popup__campaign--detail-service">
                        <ol>
                            <li>1) 타겟고객상세설명: 고객사랑서비스</li>
                            <li>2) 마케팅 Tool: 선물신청</li>
                            <li>3) 주요 내용: 고객사랑서비스</li>
                            <li>4) 기타:</li>
                            <li>5) 기타:</li>
                            <li>6) 기타:</li>
                            <li>7) 기타:</li>
                            <li>8) 기타:</li>
                        </ol>
                    </div>
                </div>
                <div class="-pub-popup__campaign--detail-list">
                    <div class="-pub-popup__campaign--detail-tit">추가정보</div>
                    <div class="-pub-popup__campaign--detail-list-box">
                        <div class="-pub-popup__campaign--detail-list-left">
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">골프장</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">-</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">강사유형</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">-</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나T/O)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나T/O)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나T/O)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                        </div>
                        <div class="-pub-popup__campaign--detail-list-right">
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">행사장소명/제휴처명</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">-</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">컨설턴트참석여부</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">-</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나신청)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나신청)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                            <dl>
                                <dt class="-pub-popup__campaign--detail-list-item">인원수(세미나신청)</dt>
                                <dd class="-pub-popup__campaign--detail-list-item">0</dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
            <div class="-pub-popup__button-area -pub-popup__button-area--shadow">
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      returnDate: '',
      name: '',
      selectGroups: {
        group1: [{
          key: '1',
          label: '5월 신CI보험 타겟 고객'
        }],
        values: {
          group1: {
            key: '1',
            label: '5월 신CI보험 타겟 고객'
          }
        }
      }
    }
  }
}
</script>
