<template>
    <section class="-pub-system-setting-admin">
        <!-- 알림 기능 off시 -pub-noit-disabled 추가 -->
        <div class="float-container">
            <div class="-pub-noti__list-wrap-center">
                <div class="-pub-noti__list-tit">모바일 영업 지원 시스템</div>
                <ul>
                    <li class="-pub-noti__list">
                        <label class="-pub-noti-item">버전</label>
                        <div class="-pub-noti-item-src">
                            <p class="-pub-text-area normal-letter">1.0</p>
                        </div>
                    </li>
                    <li class="-pub-noti__list">
                        <label class="-pub-noti-item">최근 업데이트</label>
                        <div class="-pub-noti-item-src">
                            <p class="-pub-text-area normal-letter">2017.05.04</p>
                            <span class="etc">* 현재 최신버전 입니다.</span>
                        </div>
                    </li>
                    <li class="-pub-noti__list">
                        <label class="-pub-noti-item">시스템 문의</label>
                        <div class="-pub-noti-item-src">
                            <p class="-pub-text-area normal-letter">02-3114-5000</p>
                            <button type="button" class="-pub-button -pub-button--purple -pub-button--light -pub-button-setting-admin -pub-left-space">
                                <span class="-pub-button__text">전화걸기</span>
                            </button>
                        </div>
                    </li>
                    <li class="-pub-noti__list">
                        <label class="-pub-noti-item">메모리 최적화</label>
                        <div class="-pub-noti-item-src">
                            <button type="button" class="-pub-button -pub-button--purple -pub-button--light -pub-button-setting-admin" @click="startLoading">
                                <span class="-pub-button__text">실행하기</span>
                            </button>
                            <div class="-pub-dim" v-if="isShowMemory"><span class="-pub-loading"><!-- 로딩화면 --></span></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>
</template>
<script>
export default {
  data () {
    return {
      isShowMemory: false
    }
  },
  methods: {
    startLoading () {
      this.isShowMemory = true
      setTimeout(() => {
        this.isShowMemory = false
      }, 3000)
    }
  }
}
</script>
