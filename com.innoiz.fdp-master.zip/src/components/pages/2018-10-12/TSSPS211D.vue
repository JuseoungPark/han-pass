<!-- 설계청약 최근설계 탭 영역 -->
<template>
    <div class="-pub-tab-body-wrap -pub-recent-design">
        <div class="-pub-list__left-side">
            <div class="-pub-filter-menu -pub-filter-menu--in-tab">
                <div class="-pub-filter-menu__item--right">
                    <form onsubmit="return false;">
                        <fdp-select class="-pub-select -pub-select--purple -pub-filter-menu__item -pub-filter-menu__item--select detail-type-6" v-model="selectBoxValue" :option-list="selectBoxItems" ellipsis></fdp-select>
                        <fdp-text-field class="-pub-filter-menu__item -pub-search-input -pub-search-input--purple" placeholder="입력하세요." v-model="searchKeyword" clearable></fdp-text-field>
                        <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="onSearch">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </form>
                </div>
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{mockData.length}}건</div>
            </div>
            <!-- 페이지 조회 input, button 검색 명수 영역 end -->
            <!-- 고객 관련 정보 데이터 테이블 영역 -->
            <fdp-infinite class="-pub-table -pub-table--customer-service -pub-table--programmed-proposal" multi-select v-model="selectItems" :table-body-height="hasSelectItem ? 762 : 896" :items="mockData">
                <template slot="header">
                    <tr class="-pub-table__header">
                        <th class="-pub-table-column--checkbox">
                            <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="tableHeader.isSelectAll" @input="selectAllItemsFunc(tableHeader.isSelectAll)"></fdp-checkbox>
                        </th>
                        <th v-for="item in tableHeader.headerItems" :key="item.title" :style="item.styleObject" :class="[{'-pub-table-column':true},{'-pub-table-column--sorting':item.sort.isSort}]" @click="sortFunc(item)">
                            <!-- sorting이 필요한 컬럼 -->
                            <span v-if="item.sort.isSort" :class="[{'-pub-table-column__text':true}, {'-pub-sorting--active':item.isActive}, {'-pub-sorting--up': item.sort.asc}, {'-pub-sorting--purple': item.isActive}, {'-pub-table-column--normal-letter':item.isNormal}]">{{item.title}}
                                <img v-if="item.sort.isSort" src="@/assets/img/components/btn_table_sorting_down.png" class="-pub-sorting__icon" alt="sorting">
                            </span>
                            <!-- sorting이 필요 없는 컬럼 -->
                            <span v-else :class="[{'-pub-table-column__text':true}]">{{item.title}}</span>
                        </th>
                    </tr>
                </template>
                <template slot-scope="props">
                    <td class="-pub-table-column--checkbox">
                        <fdp-checkbox class="-pub-checkbox -pub-checkbox--empty-label -pub-checkbox--purple" isIconCheckbox v-model="selectItems" :value="props.item"></fdp-checkbox>
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 150px;">{{props.item.date}}</td>
                    <td class="-pub-table-column -pub-table-column--name" style="width: 136px;">
                        {{props.item.insuredPerson}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--left-align" style="width: 184px;">
                        <div class="-pub-table-colmn__single-line--ellipsis -pub-colored-text--2">
                            {{props.item.item}}
                        </div>
                    </td>
                    <td class="-pub-table-column -pub-table-column--right-align -pub-table-column--normal-letter" style="width: 162px;">
                        {{props.item.cost}}
                    </td>
                    <td class="-pub-table-column" style="width: 130px;">
                        <template v-if="props.item.aeus === 'AEUS입력'">
                            <button class="-pub-pp-table-column__button -pub-aeus-button">{{props.item.aeus}}</button>
                        </template>
                        <template v-else>
                            <span>{{props.item.aeus}}</span>
                        </template>
                    </td>
                    <td class="-pub-table-column" style="width: 100px;">
                        {{props.item.status}}
                    </td>
                    <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 160px;">
                        {{props.item.date2}}
                    </td>
                </template>
                <!-- no data 화면 -->
                <template slot="emptyView" v-if="searchRes==='1'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">진행중인 가입설계 건이 없습니다.</div>
                    </div>
                </template>
                <!-- 검색결과 없을때 화면 -->
                <template slot="emptyView" v-if="searchRes==='2'">
                    <div class="-pub-table-empty-view -pub-table-empty-view--search -pub-table-empty-view--fix-height">
                        <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                    </div>
                </template>
            </fdp-infinite>
            <!-- 고객 관련 정보 데이터 테이블 영역 end -->
        </div>

        <section class="-pub-card-wrap -pub-list__right-side">
            <div class="-pub-customer-card__top-area">
                <span>최근 활동 고객 <strong>(상령일)</strong></span>
                <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple" v-model='chk1'>펼쳐보기</fdp-checkbox>
            </div>
            <fdp-list class="-fdp-list-page__list -pub-customer-card__list" :list-data="cardTypes" :list-height="hasSelectItem ? 777 : 907" @loading-data="loadingData" ref="targetFdpList">
                <template slot="default" slot-scope="props">
                    <div class="-fdp-list-page__item -pub-customer-card__item" :class="[chk1 ? '-pub-customer-card__item--open': '']">
                        <div>
                            <span>{{props.item.name}}</span>
                            <span>{{props.item.date}} <strong>&nbsp;</strong>{{props.item.data}}</span>
                        </div>
                        <ul>
                            <li>
                                <span>D-30</span>
                                <span>필수건설팅</span>
                            </li>
                            <li>
                                <span>D-99+</span>
                                <span>마케팅</span>
                            </li>
                        </ul>
                        <button class="-pub-button -pub-button__start--inner">설계시작</button>
                    </div>
                </template>
            </fdp-list>
        </section>

        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component -->
        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--fixed-top -pub-bottom-bar--default" v-show="mockCheckCount > 0" :page-fixed="true">
            <ul class="-pub-bottom-nav">
                <li class="-pub-bottom-nav__text -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-show="mockCheckCount > 0" @click="cancelSeletItemsFunc">
                    <fdp-checkbox class="-pub-checkbox -pub-checkbox--purple -pub-check-label" isIconCheckbox v-model="bottomBarCheck">{{mockCheckCount}}명 선택</fdp-checkbox>
                </li>
                <li class="-pub-bottom-nav__item--right -pub-bottom-nav__container -pub-bottom-nav__item--centered">
                    <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item" @click="$emit('call-confirm', 'delete')">
                        <!-- confirm 창을 띄우기 위해선 부모(TSSPS210M.vue)의 로컬 변수(confirm1)의 값을 바꿔줘야 하기 때문에 emit 으로 전달 -->
                        <span class="-pub-button__text">설계삭제</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item">
                        <span class="-pub-button__text">설계비교</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">심사</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-bottom-nav__item">
                        <span class="-pub-button__text">발행</span>
                    </button>
                    <button class="-pub-button -pub-button--purple -pub-button--medium -pub-bottom-nav__item">
                        <span class="-pub-button__text">전자서명</span>
                    </button>
                </li>
            </ul>
        </fdp-bottom-bar>
        <!-- 고객 정보 체크박스 선택시 나오는 bottom bar component end -->
    </div>
</template>
<script>
import { viewMemberMocks1 } from '@/components/mock/TSSPS211D.mock'

export default {
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    },
    hasSelectItem () {
      return !!this.selectItems.length > 0
    }
  },
  data () {
    return {
      selectBoxValue: {
        key: '1',
        label: '고객명'
      },
      selectBoxItems: [{
        key: '1',
        label: '고객명'
      },
      {
        key: '2',
        label: '설계명'
      }],
      mockData: Object.assign([], viewMemberMocks1),
      isEmpty: true,
      mockHeader: [],
      searchKeyword: '',
      searchRes: false,
      selectItems: [],
      tableHeader: {
        isSelectAll: false,
        lastVisitColumn: 0,
        // fdp-infinite 헤더 관리
        headerItems: [
          {idx: 0, title: '설계일', isNormal: false, isActive: true, sort: {isSort: true, asc: true}, styleObject: {width: '150px'}},
          {idx: 1, title: '피보험자', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '136px'}},
          {idx: 2, title: '설계명', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '184px'}},
          {idx: 3, title: '보험료(원)', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '162px'}},
          {idx: 4, title: 'AEUS', isNormal: true, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '130px'}},
          {idx: 5, title: '전산심사', isNormal: false, isActive: false, sort: {isSort: false, asc: false}, styleObject: {width: '100px'}},
          {idx: 6, title: '전산심사일', isNormal: false, isActive: false, sort: {isSort: true, asc: false}, styleObject: {width: '160px'}}
        ]
      },
      bottomBarCheck: false,
      chk1: false,
      cardTypes: [{
        name: '김병은병',
        date: '(10월22일)',
        data: '10개월 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '1주 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '1년 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      },
      {
        name: '김병은',
        date: '(10월22일)',
        data: '30일 전 보장분석'
      }
      ]
    }
  },
  watch: {
    selectItems () {
      if (this.selectItems.length !== this.mockData.length) {
        this.tableHeader.isSelectAll = false
      } else {
        this.tableHeader.isSelectAll = true
      }
      if (this.selectItems.length > 0) {
        this.bottomBarCheck = true
      }
    }
  },
  methods: {
    // table 전체 선택 처리
    selectAllItemsFunc (state) {
      if (state) {
        // checked
        this.selectItems = this.mockData.slice(0)
      } else {
        // unchecked
        this.selectItems.splice(0, this.selectItems.length)
      }
    },
    // bottom-bar 해제 처리
    cancelSeletItemsFunc () {
      this.selectItems.splice(0, this.selectItems.length)
      this.tableHeader.isSelectAll = false
    },
    // 소팅 처리
    sortFunc (item) {
      if (item.sort.isSort) {
        // 선택 컬럼 active, 마지막 선택 컬럼 inactive
        this.tableHeader.headerItems[this.tableHeader.lastVisitColumn].isActive = false
        this.tableHeader.lastVisitColumn = item.idx
        item.isActive = true
        item.sort.asc = !item.sort.asc

        // Mockup 데이터
        let data = this.mockData

        if (item.title.localeCompare('설계일') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.date.localeCompare(b.date)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.date.localeCompare(a.date)
              }
            )
          }
        } else if (item.title.localeCompare('피보험자') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.insuredPerson.localeCompare(b.insuredPerson)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.insuredPerson.localeCompare(a.insuredPerson)
              }
            )
          }
        } else if (item.title.localeCompare('AEUS') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.aeus.localeCompare(b.aeus)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.aeus.localeCompare(a.aeus)
              }
            )
          }
        } else if (item.title.localeCompare('전산심사일') === 0) {
          if (item.sort.asc) {
            data.sort(
              function (a, b) {
                return a.date2.localeCompare(b.date2)
              }
            )
          } else {
            data.sort(
              function (a, b) {
                return b.date2.localeCompare(a.date2)
              }
            )
          }
        } else {}
      }
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    },
    onSearch () { // 검색어 2: 검색결과 없음, 1: 진행건 없음
      if (this.searchKeyword === '') {
        this.searchRes = ''
        this.mockData = Object.assign([], viewMemberMocks1)
      } else if (this.searchKeyword === '1') {
        this.searchRes = '1'
        this.mockData = []
      } else {
        this.searchRes = '2'
        this.mockData = []
      }
    }
  }
}
</script>
