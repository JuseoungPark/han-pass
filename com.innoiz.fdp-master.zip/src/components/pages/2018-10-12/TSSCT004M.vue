<template>
  <section class="-pub-consulting">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">보험가입 한도조회</span>
      </h2>
      <fdp-checkbox class="-pub-checkbox" style="padding:20px 20px;" v-model="isEmpty">데이터 없을때</fdp-checkbox>
      <div class="-pub-page-header__content">
        <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--last -pub-page-header__button--icon">
          <img src="@/assets/img/components/ico-product-design.png" alt="뒤로가기">
          <span>보장분석</span>
        </a>

      </div>
    </div>
    <div class="-pub-table-container">
      <h3 class="-pub-table-container__title">
        가입건수 및 월 보험료<span class="-pub-table-container__text -pub-table-container__text--date normal-letter">(2018.03.27
          기준)</span>
      </h3>
      <fdp-infinite :items="isEmpty ? [] : tableData1" class="-pub-table -pub-table--auto-height"
        :tableHeaderHeight="70">
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-consulting-grid__column" style="width: 276px;">피보험자</th>
            <th class="-pub-consulting-grid__column" style="width: 276px;">당사 및 타사합계</th>
            <th class="-pub-consulting-grid__column" style="width: 276px;">삼성생명</th>
            <th class="-pub-consulting-grid__column" style="width: 276px;">생보사</th>
            <th class="-pub-consulting-grid__column" style="width: 276px;">손보사</th>
            <th class="-pub-consulting-grid__column">공제</th>
          </tr>
        </template>
        <template slot-scope="props">
          <td class="-pub-consulting-grid__column" style="width: 276px;">{{props.item.customerName}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 276px;">{{props.item.count1}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 276px;">{{props.item.count2}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 276px;">{{props.item.count3}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 276px;">{{props.item.count4}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter">{{props.item.recoupment}}</td>
        </template>
        <template slot="emptyView">
          <div class="-pub-table-empty-view -pub-table-empty-view--min-1">
            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
          </div>
        </template>
      </fdp-infinite>
      <h3 class="-pub-table-container__title">
        보험계약 세부현황
      </h3>
      <fdp-infinite :items="isEmpty ? [] : tableData2" class="-pub-table -pub-table--auto-height"
        :tableHeaderHeight="70">
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-consulting-grid__column" style="width: 212px;">보험사</th>
            <th class="-pub-consulting-grid__column" style="width: 430px;">상품명</th>
            <th class="-pub-consulting-grid__column" style="width: 204px;">보장시작일</th>
            <th class="-pub-consulting-grid__column" style="width: 204px;">보장종료일</th>
            <th class="-pub-consulting-grid__column" style="width: 214px;">1회보험료</th>
            <th class="-pub-consulting-grid__column" style="width: 186px;">납입주기</th>
            <th class="-pub-consulting-grid__column">납입기간</th>
          </tr>
        </template>
        <template slot-scope="props">
          <td class="-pub-consulting-grid__column" style="width: 212px;">{{props.item.company}}</td>
          <td class="-pub-consulting-grid__column align-left" style="width: 430px;">
            <div class="-pub-table-colmn__single-line--ellipsis"><span class="-pub-table-column__underline">{{props.item.name}}</span></div>
          </td>
          <td class="-pub-consulting-grid__column normal-letter" style="width: 204px;">{{props.item.startDate}}</td>
          <td class="-pub-consulting-grid__column normal-letter" style="width: 204px;">{{props.item.endDate}}</td>
          <td class="-pub-consulting-grid__column normal-letter align-right" style="width: 214px;">{{props.item.amount}}</td>
          <td class="-pub-consulting-grid__column" style="width: 186px;">{{props.item.cycle}}</td>
          <td class="-pub-consulting-grid__column">{{props.item.period}}</td>
        </template>
        <template slot="emptyView">
          <div class="-pub-table-empty-view -pub-table-empty-view--min-2">
            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
          </div>
        </template>
      </fdp-infinite>
      <h3 class="-pub-table-container__title">
        보장금액 합계현황
        <span class="-pub-table-container__unit">단위: 만원</span>
      </h3>
      <fdp-infinite :items="isEmpty ? [] : tableData3" class="-pub-table -pub-table--auto-height"
        :tableHeaderHeight="70">
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-consulting-grid__column" style="width: 296px;">보장급부</th>
            <th class="-pub-consulting-grid__column" style="width: 272px;">보장금액 합계</th>
            <th class="-pub-consulting-grid__column" style="width: 272px;">삼성생명</th>
            <th class="-pub-consulting-grid__column" style="width: 272px;">생보사</th>
            <th class="-pub-consulting-grid__column" style="width: 272px;">손보사</th>
            <th class="-pub-consulting-grid__column">공제</th>
          </tr>
        </template>
        <template slot-scope="props">
          <td class="-pub-consulting-grid__column align-left" style="width: 296px;">{{props.item.name}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 272px;">{{props.item.priceTotal}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 272px;">{{props.item.price1}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 272px;">{{props.item.price2}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter" style="width: 272px;">{{props.item.price3}}</td>
          <td class="-pub-consulting-grid__column align-right normal-letter">{{props.item.recoupment}}</td>
        </template>
        <template slot="emptyView">
          <div class="-pub-table-empty-view -pub-table-empty-view--min-3">
            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
          </div>
        </template>
      </fdp-infinite>
    </div>
    <!-- 기계약 영역 -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full"
      v-show="true">
      <!-- 원하는 컴포넌트 내용 start -->
      <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-guide-text align-left middle-line-height">
        ※ 본 정보는 2006년 6월 이후 ‘제 3자 정보제공’에 동의한 보험신용정보에 한하여 신용정보원에 집적된 자료를 보여주는 것으로 보험가입현황 및 보장내용 등이 실제와<br>
        다를 수 있으므로, 자세한 사항은 해당 약관 및 증권을 참조해주시기 바랍니다. (공제 및 체신관서의 경우는 2009년 10월 이후이며, 각 회사별로 시점의 차이가 있을 수 있습니다.)
      </div>
      <!--<fdp-radio class="-pub-radio -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-model="isEmpty">데이터 존재여부</fdp-radio>-->
      <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
        <button type="button" class="-pub-button -pub-button--default">인쇄</button>
      </div>
      <!-- 원하는 컴포넌트 내용 end -->
    </fdp-bottom-bar>
  </section>
</template>
<script>
import { tableData1, tableData2, tableData3 } from '@/components/mock/TSSCT004M.mock'
export default {
  data () {
    return {
      isEmpty: false,
      tableData1: Array.prototype.slice.call(tableData1),
      tableData2: Array.prototype.slice.call(tableData2),
      tableData3: Array.prototype.slice.call(tableData3)
    }
  }
}
</script>
