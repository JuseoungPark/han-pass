<template>
    <section class="-pub-programmed-proposal">
        <section>
            <!-- 페이지 헤더 영역 -->
            <div class="-pub-customer-list__header">
                <div class="-pub-customer-list__title-wrap">
                <h1 class="-pub-customer-list__title">
                    <span class="-pub-title__text">{{title}}</span>
                </h1>
                </div>
                <ul class="-pub-header__menu">
                    <!-- 181026 TSSPS213D 전자서명 탭에서만 사용 start -->
                    <!-- 진단심사현황 버튼 -->
                    <li class="-pub-header__item">
                        <span class="-pub-customer-list__header-button">
                        <img class="-pub-customer-list__header-button-icon" src="@/assets/img/ico_diagnostic_screening.png" alt="">
                        <span class="-pub-label__text">진단심사현황</span>
                        </span>
                    </li>
                    <!-- 진단심사현황 버튼 -->
                    <li class="-pub-header__item">
                        <span class="-pub-customer-list__header-button">
                            <img class="-pub-customer-list__header-button-icon" src="@/assets/img/ico_search_document.png" alt="">
                            <span class="-pub-label__text">구비서류검색</span>
                        </span>
                    </li>
                    <!-- 181026 TSSPS213D 전자서명 탭에서만 사용 end -->
                    <!-- 설계 시작하기 버튼 -->
                    <li class="-pub-header__item">
                        <button type="button" class="-pub-customer-list__header-button -pub-button -pub-button--purple -pub-button--light -pub-button--reverse">
                            <img class="-pub-customer-list__header-button-icon" src="@/assets/img/ico_product_design.png" alt="">
                            <span class="-pub-label__text">설계 시작하기</span>
                        </button>
                    </li>
                </ul>
            </div>
            <!-- 페이지 헤더 영역 end -->
            <!-- 페이지 컨텐츠 영역 -->
            <div class="-pub-page-container__wrapper">
                <fdp-tab-topcolor-type class="-pub-tab-container"  @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
                    <template>
                        <component :is="currentTabComponent" @call-confirm="callConfirm"></component> <!-- callConfirm은 하위컴포넌트에서 부모의 confirm 관련 값을 수정하기 위한 이벤트 전달 -->
                    </template>
                </fdp-tab-topcolor-type>
            </div>
            <!-- 페이지 컨텐츠 영역 end -->
        </section>
        <!-- fdp-confirm -->
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm1" message="선택한 설계를 삭제하시겠습니까?" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm2" message="전자서명을 재전송 하시겠습니까?" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm3" message="중단된 전자서명을 이어서 하시겠습니까?" negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative"></fdp-confirm>
        <fdp-confirm class="-pub-confirm -pub-confirm--purple" v-model="confirm4" message="시간이 경과하여 전산심사를 다시 수행해야 합니다. 다시 하시겠습니까?" custom negative-button-label="아니오" positive-button-label="예" @on-positive="onPositive" @on-negative="onNegative">
            <div class="-pub-confirm-custom">
                <div>시간이 경과하여 전산심사를</div>
                <div>다시 수행해야 합니다. 다시 하시겠습니까?</div>
            </div>
        </fdp-confirm>
  </section>
</template>
<script>
import FirstTabComponent from '@/components/pages/2018-10-12/TSSPS211D'
import SecondTabComponent from '@/components/pages/2018-10-12/TSSPS212D'
import ThirdTabComponent from '@/components/pages/2018-10-26/TSSPS213D'
import FourthTabComponent from '@/components/pages/2018-10-12/TSSPS214D'
import fifthTabComponent from '@/components/pages/2018-10-12/TSSPS215D'

export default {
  components: {
    FirstTabComponent,
    SecondTabComponent,
    ThirdTabComponent,
    FourthTabComponent,
    fifthTabComponent
  },
  data () {
    return {
      title: '설계청약',
      currentTabComponent: 'first-tab-component',
      currentTabTitle: '최근설계',
      tabItems: [{
        'tabTitle': '최근설계',
        'tabComponent': 'first-tab-component'
      },
      {
        'tabTitle': '청약서발행',
        'tabComponent': 'second-tab-component'
      },
      {
        'tabTitle': '전자서명',
        'tabComponent': 'third-tab-component'
      },
      {
        'tabTitle': '전자청약',
        'tabComponent': 'fourth-tab-component'
      },
      {
        'tabTitle': '신계약진행',
        'tabComponent': 'fifth-tab-component'
      }],
      confirm1: false,
      confirm2: false,
      confirm3: false,
      confirm4: false
    }
  },
  methods: {
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    },
    beginConsultFunc () {
      alert('상세 설계 이동')
    },
    onPositive () {
      // fdpConfirm 예 버튼 클릭 시, 콜백
    },
    onNegative () {
      // fdpConfirm 아니오 버튼 클릭 시, 콜백
    },
    callConfirm (type) {
      // 하위 tab 컴포넌트에서 confirm창 호출
      if (type === 'delete') {
        this.confirm1 = true
      }
    }
  }
}
</script>
