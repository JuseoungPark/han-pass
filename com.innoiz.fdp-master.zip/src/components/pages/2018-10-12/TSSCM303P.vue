<template>
    <fdp-popup class="-pub-popup" v-model="showPopup" title="고객접촉정보상세조회" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup__data--detail">
                <div class="-pub-popup__data--detail-list">
                    <!-- 2018-11-02 수정 start -->
                    <dl class="-pub-popup__data--detail-list-item">
                        <dt>고객명</dt>
                        <dd>이정재</dd>
                    </dl>
                    <dl class="-pub-popup__data--detail-list-item">
                        <dt>이메일</dt>
                        <dd class="en">aaaaa@naver.com</dd>
                    </dl>
                    <!-- 2018-11-02 수정 end -->
                    <dl class="-pub-popup__data--detail-list-item">
                        <dt>휴대폰</dt>
                        <dd class="num">010-9459-2290</dd>
                        <dt>자택전화</dt>
                        <dd class="num">883-9459-2290</dd>
                    </dl>
                    <dl class="-pub-popup__data--detail-list-item">
                        <dt>주소</dt>
                        <dd class="line">서울 성북구 숭인로 8길 111동 111호</dd>
                    </dl>
                </div>
                <div class="-pub-popup__data--detail-dec">
                    <div class="-pub-popup__data--detail-tit">알림정보</div>
                    <div class="-pub-popup__data--detail-service">
                        고객님에게 배당금이 지급되었습니다.<br>
                        고객님에게 배당금이 지급되었습니다.<br>
                        고객님에게 배당금이 지급되었습니다.<br>
                        고객님에게 배당금이 지급되었습니다.<br>
                        상품명 : 홈닥터보험(개인만기환급형 )<br>
                        실수령액 : 60858<br>
                        계약번호 : 1506805410042
                    </div>
                </div>
            </div>
            <div class="-pub-popup__button-area -pub-popup__button-area--shadow">
                <button type="button" class="-pub-button -pub-button--210 -pub-button--purple" v-if="true && true"> <!-- 고객접촉정보 내용에 따라 구성 변경 -->
                    <span class="-pub-button__text">계약상세</span>
                </button>
                <button type="button" class="-pub-button -pub-button--210 -pub-button--purple" v-else-if="true"> <!-- 고객접촉정보 내용에 따라 구성 변경 -->
                    <span class="-pub-button__text">고객상세</span>
                </button>
                <button type="button" class="-pub-button -pub-button--210 -pub-button--purple -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
</template>
<script>
export default {
  data () {
    return {
      showPopup: true
    }
  }
}
</script>
