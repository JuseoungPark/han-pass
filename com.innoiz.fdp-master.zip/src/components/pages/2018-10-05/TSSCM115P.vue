<template>
    <!-- 알뜰폰 확인 팝업 start -->
    <fdp-popup class="-pub-popup" v-model="showPopup" title="알뜰폰 확인" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__content -pub-popup-115p">
                <div class="">
                    <span class="-pub-choose-telecom">고객의 통신사를 선택하세요.</span>
                    <fdp-infinite class="-pub-table -pub-table-blue" v-model="radioTableSelected" :tableBodyHeight="tableBodyHeight" single-select :items="mockData">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                                <th class="-pub-table-column" style="width: 200px;">통신사</th>
                                <th class="-pub-table-column" style="width: 1114px;">알뜰폰 사업자</th>
                            </tr>
                        </template>
                        <template slot-scope="props">
                            <td class="-pub-table-column--radiobox" style="width: 78px;">
                                <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item.id.toString()"></fdp-radio>
                            </td>
                            <td class="-pub-table-column" style="width: 200px;">{{props.item.name}}</td>
                            <td class="-pub-table-column " style="width: 1114px;">
                                <div>{{props.item.content}}</div>
                            </td>
                        </template>
                    </fdp-infinite>
                </div>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                        <span class="-pub-button__text">취소</span>
                    </button><button type="button" class="-pub-button -pub-button--reverse" :class="radioTableSelected.length==0?'':'-pub-button--blue'"
                        :disabled="radioTableSelected.length==0">
                        <span class="-pub-button__text">확인</span>
                    </button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
    <!-- 알뜰폰 확인 팝업 end -->
</template>
<script>
import mockData from '@/components/mock/TSSCM115P.mock'
export default {
  data () {
    return {
      tableBodyHeight: 506,
      radioSelected: '',
      radioTableSelected: [],
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData),
      mockHeader: []
    }
  },
  watch: {
    radioTableSelected () {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.id.toString()
      }
    }
  }
}
</script>
