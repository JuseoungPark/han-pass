<template>
    <!-- 보험직업조회 팝업 start -->
    <fdp-popup class="-pub-popup" v-model="showPopup" title="보험직업조회" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__jobsearch">
                <div class="-pub-popup__tab-content">
                    <fdp-tab-topcolor-type class="-pub-tab-container" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
                        <template>
                            <component :is="currentTabComponent"></component>
                        </template>
                    </fdp-tab-topcolor-type>
                </div>
            </div>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
    <!-- 보험직업조회 팝업 end -->
</template>
<script>
import ServiceTabComponent from '@/components/pages/2018-10-05/TSSCM214P-tab-direct'
import ServiceTabComponent2 from '@/components/pages/2018-10-05/TSSCM214P-tab-division'
export default {
  components: {
    ServiceTabComponent,
    ServiceTabComponent2
  },
  data () {
    return {
      showPopup: true,
      currentTabIndex: 0,
      title: '보험직업조회',
      tabItems: [{
        'tabSubTitle': '직접검색',
        'tabComponent': 'ServiceTabComponent'
      },
      {
        'tabSubTitle': '분류별보기',
        'tabComponent': 'ServiceTabComponent2'
      }
      ],
      currentTabComponent: 'ServiceTabComponent',
      currentTabComponent2: 'ServiceTabComponent2'
    }
  },
  methods: {
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    }
  }
}
</script>
