<template>
  <!-- 동행결과입력 start -->
  <fdp-popup class="-pub-popup" v-model="showPopup" title="동행결과입력" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content">
            <div class="-pub-popup-330">
                <div class="-pub-popup-row">
                    <label>고객명</label>
                    <span>김바다</span>
                </div>
                <div class="-pub-popup-row">
                    <label>동행 희망날짜 <strong>*</strong></label>
                    <fdp-validator name="tsscm330p-validator-1" display-name="동행 희망날짜" v-model="returnDate" :rules="'required|min:2'">
                        <fdp-date-picker class="-pub-date-picker" v-model="returnDate"></fdp-date-picker>
                    </fdp-validator>
                </div>
                <div class="-pub-popup-row">
                    <label class="-pub-row-2-label">내용 입력 <strong>*</strong></label>
                    <fdp-validator name="tsscm330p-validator-2" display-name="내용" v-model="text" :rules="'required'">
                        <textarea class="" v-model="text"></textarea>
                    </fdp-validator>
                </div>
            </div>
            <div class="-pub-popup__button-area">
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
                    <span class="-pub-button__text">취소</span>
                </button>
                <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
  <!-- 동행결과입력 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      returnDate: '',
      text: '더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더' +
'더미텍스트입니다 더미더미더미더미더미더미더미더미더미더미더미더미더더'
    }
  }
}
</script>
