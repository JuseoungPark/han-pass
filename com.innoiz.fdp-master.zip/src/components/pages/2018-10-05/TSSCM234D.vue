<template>
    <div class="-pub-content-scroll"><!-- -pub-fdp-list__empty-view 데이터가 없을 경우 클래스 추가 --><!-- 목업 추가 20181113 -->
        <div>
            <fdp-list class="-fdp-list-page__list" :list-data="mockData" :list-height="877" ref="targetFdpList">
                <template slot="emptyView"><!-- 목업 변경 20181113 -->
                    <div class="-pub-table-empty-view">
                        <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                    </div>
                </template>
                <template slot="default" slot-scope="props">
                    <div class="-pub-accordion-container" v-for="(mock, index2) in props.item.data" :key="'b' + index2">
                        <div class="-pub-accordion-line">
                            <span class="-pub-accordion-line__text">{{mock.date}}</span>
                        </div>
                        <div class="-pub-accordion" :class="[mock.expand ? '-pub-accordion--expanded' : '']" >
                            <div class="-pub-accordion__title">
                                <div class="-pub-accordion__text -pub-accordion__text--directory">{{mock.directory}}<img src="@/assets/img/ico_go.png" alt="">{{mock.company}}</div>
                                <div class="-pub-accordion__text -pub-accordion__text--type2">{{mock.type}}</div>
                                <div class="-pub-accordion__text -pub-accordion__text--item-name">
                                    <div class="-pub-table-colmn__single-line--ellipsis">{{mock.itemName}}</div>
                                </div>
                                <div class="-pub-accordion__text -pub-accordion__text--id -pub-accordion__text--number">계약번호 : {{mock.id}}</div>
                                <div class="-pub-accordion__text -pub-accordion__text--process-status">{{mock.process}}</div>
                                <a class="-pub-accordion__trigger" @click="mock.expand = !mock.expand"><img src="@/assets/img/customer/ico-arrow-down-black.png" alt=""></a>
                            </div>
                            <div class="-pub-accordion__content">
                                <div class="-pub-section" v-for="(department, index3) in mock.departments" :key="index3">
                                    <div class="-pub-accordion__text -pub-accordion__text--email">
                                        <span class="-pub-accordion__text--email-tit">이메일</span>
                                        <span class="-pub-accordion__text--email-url">{{department.email}}</span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--phone">
                                        <span class="-pub-accordion__text--phone-tit">자택전화</span>
                                        <span class="-pub-accordion__text--phone-num">{{department.phone}}</span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--address">
                                        <span class="-pub-accordion__text--address-tit">주소</span>
                                        <span class="-pub-accordion__text--address-txt">{{department.address}}</span>
                                    </div>
                                    <div class="-pub-accordion__text -pub-accordion__text--info">
                                        <span class="-pub-accordion__text--info-tit">알림정보</span>
                                        <span class="-pub-accordion__text--info-txt">{{department.info1}}<br>{{department.info2}}<br>{{department.info3}}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="-pub-accordion-container -pub-accordion-container--year">
                        <div class="-pub-accordion-line -pub-accordion-line--year">
                            <span class="-pub-accordion-line__text -pub-accordion-line__text--year">{{props.item.year}}</span>
                        </div>
                        <div class="-pub-accordion--empty"></div>
                    </div>
                </template>
            </fdp-list>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      mockData: [{
        year: 2017,
        data: [{
          expand: true,
          date: '07.16',
          directory: '고객',
          company: '회사',
          type: '상담',
          id: '12312312312322',
          process: '변경문의/처리',
          departments: [{
            email: 'aaaaa@naver.com',
            phone: '012-222-4444',
            address: '서울 성북구 숭인로 8길 111동 1111호',
            info1: '고객님에게 배당금이 지급되었습니다.',
            info2: '상품명:홈닥터보험(개인만기환급형)',
            info3: '실수령액 : 60858'
          }]
        },
        {
          expand: false,
          date: '07.16',
          directory: '고객',
          company: '회사',
          type: '상담',
          id: '12312312312322',
          process: '변경문의/처리',
          departments: [{
            email: 'aaaaa.naver.com',
            phone: '012-222-4444',
            address: '서울 성북구 숭인로 8길 111동 1111호',
            info1: '고객님에게 배당금이 지급되었습니다.',
            info2: '상품명:홈닥터보험(개인만기환급형)',
            info3: '실수령액 : 60858'
          }]
        },
        {
          expand: false,
          date: '07.16',
          directory: '고객',
          company: '회사',
          type: 'VOC',
          id: '12312312312322',
          process: '변경문의/처리',
          departments: [{
            email: 'aaaaa.naver.com',
            phone: '012-222-4444',
            address: '서울 성북구 숭인로 8길 111동 1111호',
            info1: '고객님에게 배당금이 지급되었습니다.',
            info2: '상품명:홈닥터보험(개인만기환급형)',
            info3: '실수령액 : 60858'
          }]
        }
        ]
      },
      {
        year: 2016,
        data: [{
          expand: false,
          date: '07.16',
          directory: '고객',
          company: '회사',
          type: '접속',
          id: '12312312312322',
          process: '변경문의/처리',
          departments: [{
            email: 'aaaaa.naver.com',
            phone: '012-222-4444',
            address: '서울 성북구 숭인로 8길 111동 1111호',
            info1: '고객님에게 배당금이 지급되었습니다.',
            info2: '상품명:홈닥터보험(개인만기환급형)',
            info3: '실수령액 : 60858'
          }]
        }
        ]
      }]
    }
  }
}
</script>
