<template>
    <section>
        <fdp-tab-topcolor-type class="-pub-tab-container" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="0">
            <template>
                <component :is="currentTabComponent"></component>
            </template>
        </fdp-tab-topcolor-type>
    </section>
</template>
<script>
import ServiceTabComponent from '@/components/pages/2018-10-05/TSSCM313M.tab-campaign'
import ServiceTabComponent2 from '@/components/pages/2018-10-05/TSSCM313M.tab-security'
export default {
  components: {
    ServiceTabComponent,
    ServiceTabComponent2
  },
  data () {
    return {
      title: '고객',
      tabItems: [{
        'tabSubTitle': '캠페인',
        'tabComponent': 'service-tab-component'
      },
      {
        'tabSubTitle': '보장내역',
        'tabComponent': 'service-tab-component2'
      }
      ],
      currentTabComponent: 'service-tab-component',
      currentTabComponent2: 'service-tab-component2'
    }
  },
  methods: {
    onSizeChange (size) {},
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    }
  },
  computed: {
    mockCheckCount () {
      return this.selectItems.length
    }
  },
  created () {
    console.log(this)
  }
}
</script>
