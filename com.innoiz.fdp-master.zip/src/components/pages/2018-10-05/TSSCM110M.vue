<template>
    <section class="-pub-tsscm110m">
        <template v-if="localStepType === '휴대폰카드'">
            <div class="-pub-ico-complete-wrap">
                <img class="-pub-ico-complete" src="@/assets/img/ico_complete.gif" alt="">
                <span>고객등록동의 처리결과는<br>아래와 같습니다.</span>
            </div>
            <ul class="-pub-custormer-register-complete-1">
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color1">본인</span>
                        </li>
                        <li class="-pub-name">
                            <span>김광용</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>40세 남자</span>
                        </li>
                        <li class="-pub-required-consulting -pub-complete">
                            <span>필수컨설팅</span>
                        </li>
                        <li class="-pub-marketting -pub-complete">
                            <span>마케팅</span>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light">라이프분석</button>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light">보장분석</button>
                        </li>
                        <li class="-pub-btn-3">
                            <button type="button" class="-pub-button -pub-button--light">상품설계</button>
                        </li>
                        <li class="-pub-btn-4">
                            <button type="button" class="-pub-button -pub-button--light">추가정보입력</button>
                        </li>
                    </ul>
                    <span class="-pub-complete-result">
                        ※ 홍길동님의 동의 신청이 완료되었습니다. 실명확인 결과, 정상입니다
                    </span>
                </li>
                <li>
                    <div class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                        <li class="-pub-required-consulting">
                            <span>필수컨설팅</span>
                        </li>
                        <li class="-pub-marketting -pub-complete">
                            <span>마케팅</span>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light">라이프분석</button>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light" disabled>보장분석</button>
                        </li>
                        <li class="-pub-btn-3">
                            <button type="button" class="-pub-button -pub-button--light">상품설계</button>
                        </li>
                    </div>
                    <span class="-pub-complete-result -pub-colored">
                        ※ 홍길동님은 실명확인 결과 명의도용 차단 요청 식별번호입니다. 해당 고객에 대한 동의 처리는 지점으로 문의하시기 바랍니다.
                    </span>
                </li>
                <li>
                    <div class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                        <li class="-pub-required-consulting">
                            <span>필수컨설팅</span>
                        </li>
                        <li class="-pub-marketting -pub-complete">
                            <span>마케팅</span>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light">라이프분석</button>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light" disabled>보장분석</button>
                        </li>
                        <li class="-pub-btn-3">
                            <button type="button" class="-pub-button -pub-button--light">상품설계</button>
                        </li>
                    </div>
                    <span class="-pub-complete-result -pub-colored">
                        ※ 홍길동님은 실명확인 결과 명의도용 차단 요청 식별번호입니다. 해당 고객에 대한 동의 처리는 지점으로 문의하시기 바랍니다.
                    </span>
                </li>
                <li>
                    <div class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                        <li class="-pub-required-consulting">
                            <span>필수컨설팅</span>
                        </li>
                        <li class="-pub-marketting -pub-complete">
                            <span>마케팅</span>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light">라이프분석</button>
                        </li>
                        <li>
                            <button type="button" class="-pub-button -pub-button--light" disabled>보장분석</button>
                        </li>
                        <li class="-pub-btn-3">
                            <button type="button" class="-pub-button -pub-button--light">상품설계</button>
                        </li>
                    </div>
                    <span class="-pub-complete-result -pub-colored">
                        ※ 홍길동님은 실명확인 결과 명의도용 차단 요청 식별번호입니다. 해당 고객에 대한 동의 처리는 지점으로 문의하시기 바랍니다.
                    </span>
                </li>
            </ul>

            <div class="-pub-call-center">
                <span>
                    NICE 실명인증은 정확한 고객정보 확인을 위해 동의Process에서 진행합니다.<br>
                    결과값의 상세한 확인은 NICE 신용평가정보 고객센터에 문의 바랍니다.
                </span>
                <!-- 2018-10-26 전화번호 수정 -->
                <span class="-pub-button--service-center">1600-1522</span>
            </div>
        </template>

        <!-- 지류 -->
        <template v-else-if="localStepType === '지류'">
            <div class="-pub-ico-complete-wrap">
                <img class="-pub-ico-complete -pub-ico-complete-2" src="@/assets/img/ico_complete.gif" alt="">
                <span>관리자 승인후<br>고객동의가 완료됩니다.</span>
            </div>
            <hr class="-pub-complete-2-line">
            <ul class="-pub-custormer-register-complete-1 -pub-custormer-register-complete-2">
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color1">본인</span>
                        </li>
                        <li class="-pub-name">
                            <span>김광용</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>40세 남자</span>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul class="-pub-complete-info">
                        <li>
                            <span class="-pub-badge-tag -pub-status-color3">자녀</span>
                        </li>
                        <li class="-pub-name">
                            <span>김아들</span>
                        </li>
                        <li class="-pub-age-gender">
                            <span>12세 남자</span>
                        </li>
                    </ul>
                </li>
            </ul>
        </template>

        <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full" v-show="true">
            <div class="-pub-bottom-nav -pub-bottom-nav__item--right">
                <button type="button" class="-pub-button -pub-bottom-nav__item -pub-btn-1" @click="tempChangePage1">고객추가등록</button>
                <button type="button" class="-pub-button -pub-button--reverse -pub-bottom-nav__item -pub-btn-2" @click="tempChangePage2">완료</button>
            </div>
        </fdp-bottom-bar>
    </section>
</template>
<script>
export default {
  name: 'tsscm110m',
  props: {
    stepType: {
      type: String,
      default: '휴대폰카드'
    }
  },
  data () {
    return {
      localStepType: this.stepType
    }
  },
  methods: {
    tempChangePage1 () {
      this.localStepType = '휴대폰카드'
    },
    tempChangePage2 () {
      this.localStepType = '지류'
    }
  }
}
</script>
