<template>
  <div class="-pub-popup-502p">

    <!-- 상세주소입력 : START -->
    <div class="-pub-popup-address-header">
      <div class="-pub-popup-address-frt">
        <h1 class="-pub-address-list__title">
            <span class="-pub-title__text">{{title}}</span>
        </h1>
        <button type="button" class="-pub-search-button" @click="$emit('re-search')">다시 검색하기</button>
      </div>
      <div class="-pub-popup-address-sec">
        <label>기본주소</label>
        <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-1" :value="param.zipcode" disabled></fdp-text-field>
        <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-2" :value="param.address" disabled></fdp-text-field>
      </div>
      <div class="-pub-popup-address-thr">
        <label>상세주소</label>
          <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-3" display-name="상세주소" placeholder="입력하세요" v-model="detailAddress"></fdp-text-field>
          <button type="button" class="-pub-search-button -pub-filter-menu__item" @click="checkAddress">주소검증</button>
      </div>
    </div>
    <!-- 상세주소입력 : END -->

    <div class="-pub-contents-wrap" v-if="resultType==='1'">
      <!-- 검증결과 여러건 검색 CASE : START -->
      <button class="-pub-popup-address-show-btn"><img src="@/assets/img/components/btn_arrow_down_nor@3x.png" alt="펼치기"></button>
      <div class="-pub-popup-address-search-01" v-if="sampleListData && sampleListData.length > 0">
        <h2 class="-pub-address-list__title">검증결과 주소가 여러 건 검색되었습니다. 찾으시는 정확한 주소지를 선택하세요.</h2>
          <fdp-list class="-fdp-list-page__list" :list-data="sampleListData" :list-height="268" :is-loading="isLoadingStatus" @loading-data="loadingData">
              <template slot="default" slot-scope="props">
                <fdp-radio v-model="radioListStrValue" :value="props.item">
                  <div class="-fdp-list-page__item">
                      <span class="-pub-list-page__item-tit">{{props.item.zipcode}}</span>
                      <span class="-pub-list-page__item-etc">{{props.item.address}}</span>
                  </div>
                </fdp-radio>
              </template>
          </fdp-list>
      </div>
      <!-- 검증결과 여러건 검색 CASE : END -->

      <!-- 변환된 주소를 선택해주세요 : START -->
      <div class="-pub-popup-address-search-02" ref="chooseAdrr">
        <h2 class="-pub-address-list__title" v-if="sampleListData && sampleListData.length > 0">변환된 주소를 선택해주세요</h2>
        <h2 class="-pub-address-list__title" v-else>검증결과 정상입니다. 변환된 주소를 선택해주세요</h2>
        <div class="-pub-popup-chg-addr">
          <div class="-pub-popup-chg-addr-01">
            <fdp-radio v-model="radioStrValue" :value="transAddress[0]">
              <div class="-pub-chg-addr-flr00">
                <label>도로명</label>
                <div class="-pub-chg-addr-flr01">
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-1" :value="transAddress[0].zipcode" disabled></fdp-text-field>
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-2" :value="transAddress[0].address" disabled></fdp-text-field>
                </div>
              </div>
              <div class="-pub-chg-addr-flr02">
                <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-3" v-model="transAddress[0].detail"></fdp-text-field>
              </div>
            </fdp-radio>
          </div>

          <div class="-pub-popup-chg-addr-02">
            <fdp-radio v-model="radioStrValue" :value="transAddress[1]">
              <div class="-pub-chg-addr-flr00">
                <label>지번</label>
                <div class="-pub-chg-addr-flr01">
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-1" :value="transAddress[1].zipcode" disabled></fdp-text-field>
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-2" :value="transAddress[1].address" disabled></fdp-text-field>
                </div>
              </div>
                <div class="-pub-chg-addr-flr02">
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-3" v-model="transAddress[1].detail"></fdp-text-field>
                </div>

            </fdp-radio>
          </div>
          <div class="-pub-popup-chg-addr-03">
            <fdp-radio v-model="radioStrValue" :value="transAddress[2]">
              <div class="-pub-chg-addr-flr00">
                <label>입력</label>
                <div class="-pub-chg-addr-flr01">
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-1" :value="transAddress[2].zipcode" disabled></fdp-text-field>
                  <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-2" :value="transAddress[2].address" disabled></fdp-text-field>
                </div>
              </div>
              <div class="-pub-chg-addr-flr02">
                <fdp-text-field class="-pub-filter-menu__item -pub-address-txt-field-3" v-model="transAddress[2].detail"></fdp-text-field>
              </div>
            </fdp-radio>
          </div>
        </div>
      </div>
      <!-- 변환된 주소를 선택해주세요 : END -->
    </div>

    <div class="-pub-contents-wrap-nonstyle" v-if="resultType==='2'">
      <div class="-pub-contents-align-center">
        <img src="@/assets/img/ico_no_result@3x.png" alt="상세주소 입력 후 주소검증을 하세요.">
        <p>상세주소 입력 후 주소검증을 하세요.</p>
      </div>
    </div>
    <div class="-pub-contents-wrap-nonstyle" v-if="resultType==='3'">
      <div class="-pub-contents-align-center">
        <img src="@/assets/img/ico_no_search_result.png" alt="검색결과가 존재하지 않습니다.">
        <p>검색결과가 존재하지 않습니다.</p>
      </div>
    </div>

  </div>
</template>
<script>
export default {
  props: {
    param: {
      type: Object,
      default: () => ({
        zipcode: '',
        address: ''
      })
    }
  },
  data: function () {
    return {
      title: '상세주소입력',
      detailAddress: '',
      showPopup: true,
      returnDate: '',
      selectedValue1: { key: '01', label: '서울' },
      selectedValue2: { key: '01', label: '송파구' },
      selectOrigin: [],
      isLoadingStatus: false,
      radioStrValue: '',
      radioListStrValue: {},
      data1: '송파구',
      data2: '송파구',
      sampleListData: [],
      resultType: '2',
      sampleListDataOrigin: [
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '(지번주소) 14210 경기 광명시 광명동 50-2번지 373-1번지'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '(지번주소) 14210 경기 광명시 광명동 50-2번지 373-1번지'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        },
        {
          zipcode: '(도로명주소) 14210 경기 광명시 광명로 966(광명동) 373-1번지',
          address: '서울 송파구 올림픽로 10다길 국민연금공단'
        }
      ],
      transAddress: [],
      transAddressOrigin: [
        {
          zipcode: '05570',
          address: '서울 송파구 올림픽로 10길',
          detail: ''
        },
        {
          zipcode: '05570',
          address: '서울 송파구 잠실동',
          detail: ''
        },
        {
          zipcode: '05570',
          address: '서울 송파구 올림픽로 10길',
          detail: ''
        }
      ],
      emptyData: []
    }
  },
  watch: {
    radioStrValue (newValue) {
      if (newValue) {
        this.$emit('button-active')
      }
    },
    // 181102 상세주소 결과 중 하나 고르면 변환된 주소 고르는 곳으로 스크롤 이동
    radioListStrValue () {
      if (this.radioListStrValue.zipcode) {
        var element = this.$refs.chooseAdrr
        var top = element.offsetTop // 특정 ref의 y축 위쪽 위치 정보
        this.$emit('scroll-move', top)
      }
    }
  },
  methods: {
    loadingData () {
      this.isLoadingStatus = true
      // 서버 통신으로 새로운 데이터 받아오는 부분 구현.
      // 서버 통신 끝나면 this.isLoadingStatus = false 로 로딩상태 변경
    },
    checkAddress () {
      this.transAddress = []
      this.sampleListData = []

      if (this.detailAddress === '1') {
        this.transAddress = this.transAddressOrigin
      } else if (this.detailAddress === '2') {
        this.sampleListData = this.sampleListDataOrigin
        this.transAddress = this.transAddressOrigin
      }

      if (this.transAddress.length > 0 && this.transAddress) { // 결과가 있다면
        this.resultType = '1'
      } else { // 결과가 없는데 검색어는 입력 했을 때
        if (this.detailAddress !== '') this.resultType = '3'
      }
      // 애초에 검색어가 입력되지 않았을 때
      if (this.detailAddress === '') this.resultType = '2'
    }
  }
}
</script>
