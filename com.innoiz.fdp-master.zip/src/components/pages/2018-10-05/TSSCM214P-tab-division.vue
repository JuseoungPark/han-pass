<template>
    <div>
        <div class="-pub-popup__jobsearch--division">
            <div class="-pub-confirm__content -pub-confirm__content--left">
                <div class="-pub-confirm__content--left -pub-confirm__content--main-pop">
                    <!-- 페이지 조회 input, button 검색 건 영역  -->
                    <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item">총 {{searchResult.length}}건</div>
                    <div class="-pub-filter-menu">
                        <div class="-pub-filter-menu__item--right">
                            <div class="-pub-filter-menu__item--category">
                                <span class="-pub-filter-menu__item--category-tit">대분류</span>
                                <fdp-validator name="tsscm214p-validator-1" display-name="대분류" v-model="select1.value.key" :rules="'required'">
                                    <fdp-select class="-pub-select -pub-filter-menu__item--select select-company" v-model="select1.value"
                                        :option-list="select1.items" placeholder="전체"></fdp-select>
                                </fdp-validator>
                                <span class="-pub-filter-menu__item--category-tit">중분류</span>
                                <fdp-validator name="tsscm214p-validator-2" display-name="중분류" v-model="select2.value.key" :rules="'required'">
                                    <fdp-select class="-pub-select -pub-filter-menu__item--select select-company" v-model="select2.value"
                                        :option-list="select2.items" placeholder="전체"></fdp-select>
                                </fdp-validator>
                            </div>
                            <div class="-pub-filter-menu__item--search">
                                <fdp-text-field class="-pub-filter-menu__item -pub-search-input"
                                    placeholder="직업" v-model="searchKeywordAddMember" @keyup.enter="clickSearchKeyword" clearable style="width: 286px; height: 56px;"></fdp-text-field>
                                <button type="submit" class="-pub-search-button -pub-filter-menu__item" @click="clickSearchKeyword">
                                    <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon"
                                        alt="조회">조회
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- 페이지 조회 input, button 검색 명수 영역 end  -->
                    <fdp-infinite class="-pub-table -pub-table-blue" v-model="radioSelected" expandable single-select :items="searchResult">
                        <template slot="header">
                            <tr class="-pub-table__header">
                                <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                                <th class="-pub-table-column" style="width: 180px;">직업코드</th>
                                <th class="-pub-table-column" style="width: 240px;">직업</th>
                                <th class="-pub-table-column" style="width: 138px;">일반</th>
                                <th class="-pub-table-column" style="width: 138px;">상해</th>
                                <th class="-pub-table-column" style="width: 138px;">입원</th>
                                <th class="-pub-table-column" style="width: 138px;">재해</th>
                                <th class="-pub-table-column" style="width: 242px;">기타</th>
                            </tr>
                        </template>
                        <!-- 검색결과 없을때 화면 -->
                        <template slot="emptyView">
                            <div class="empty-table-content -pub-table-empty-view--fix-height">
                                <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                                <div class="empty-table-content__text" v-if="isEmptySearchKeyword">직업 입력 후 검색해 주세요.</div>
                                <div class="empty-table-content__text" v-else>입력된 직업은 등록되어 있지 않습니다.</div>
                            </div>
                        </template>
                        <template slot-scope="props" v-if="!isEmptySearchKeyword">
                            <td class="-pub-table-column--radiobox" style="width: 78px; padding-left: 22px;padding-top: 5px;">
                                <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item"></fdp-radio>
                            </td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 180px;">{{props.item.jobcode}}</td>
                            <td class="-pub-table-column -pub-table-column--left-align" style="width: 240px;">{{props.item.job}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 138px;">{{props.item.normal}}</td>
                            <td class="-pub-table-column" style="width: 138px;">{{props.item.injury}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 138px;">{{props.item.admission}}</td>
                            <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 138px;">{{props.item.disaster}}</td>
                            <td class="-pub-table-column -pub-table-column--left-align" style="width: 242px;">{{props.item.etc}}</td>
                        </template>
                        <template slot="expand" slot-scope="props">
                            <div class="-pub-info__dec">
                                <ul class="-pub-info__dec--list">
                                    <li class="-pub-info__dec--item">
                                        <div class="-pub-info__dec--item-tit">합산기준</div>
                                        <div class="-pub-info__dec--item-txt">사망합산 1억 / 입원합산 2만 / 재상합산 1천만 / 트리플불가, 실손불가</div>
                                    </li>
                                    <li class="-pub-info__dec--item">
                                        <div class="-pub-info__dec--item-tit">직업설명</div>
                                        <div class="-pub-info__dec--item-txt">연안어로 작업에 속하는 여러 가지 작업을 수행하는 자</div>
                                    </li>
                                </ul>
                            </div>
                        </template>
                    </fdp-infinite>
                </div>
            </div>
        </div>
        <!-- 하단 버튼 고정 start -->
        <div class="-pub-bottom-bar">
            <div class="-pub-confirm__content--right">
                <button type="button" class="-pub-button" @click="showPopup = !showPopup">
                    <span class="-pub-button__text">취소</span>
                </button><button type="button" class="-pub-button -pub-button--reverse" :disabled="radioSelected.length === 0">
                    <span class="-pub-button__text">확인</span>
                </button>
            </div>
        </div>
        <!--// 하단 버튼 고정 end -->
    </div>
</template>
<script>
import mockData from '@/components/mock/TSSCM214P-tab-direct.mock'
export default {
  data () {
    return {
      defaultUsage: {
        default: '',
        clearable: '',
        masking: '',
        fixedIcon: '',
        tableBodyHeight: 448,
        disabled: 'text not editable',
        readonly: 'text not editable'
      },
      radioSelected: [],
      searchKeywordAddMember: '',
      searchKeyword: '',
      isEmptySearchKeyword: true,
      searchResult: [],
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData),
      mockHeader: [],
      select1: {
        value: {
          key: '1',
          label: '전체'
        },
        items: [{
          key: '1',
          label: '전체'
        }]
      },
      select2: {
        value: {
          key: '1',
          label: '전체'
        },
        items: [{
          key: '1',
          label: '전체'
        }]
      }
    }
  },
  methods: {
    clickSearchKeyword () {
      this.searchKeyword = this.searchKeywordAddMember
    }
  },
  watch: {
    // 직업을 '농부'으로 검색 시 검색결과 나오게 설정
    searchKeyword () {
      if (this.searchKeyword === '') {
        this.isEmptySearchKeyword = true
        this.searchResult = []
        this.radioSelected = []
      } else if (this.searchKeyword === '농부') {
        this.isEmptySearchKeyword = false
        this.searchResult = this.mockData
      } else {
        this.isEmptySearchKeyword = false
        this.searchResult = []
        this.radioSelected = []
      }
    }
  }
}
</script>
