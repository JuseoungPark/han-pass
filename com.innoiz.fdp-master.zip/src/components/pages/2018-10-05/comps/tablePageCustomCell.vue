<template>
    <div :class="myClass">
        <template v-if="item.consulting === 'Y'">
            <span class="-pub-agree-text">D-99</span>
        </template>
        <template v-else>
            N
        </template>
    </div>
</template>

<script>
export default {
  name: 'custom-cell',
  props: ['item', 'col'],
  computed: {
    myClass () {
      if (this.item.consulting === 'Y') { return 'consult-y' } else { return 'consult-n' }
    }
  }
}
</script>

<style scoped>
.consult-y {
    background-image: url('/src/assets/img/components/icon-y.png');
    background-size: 32px 32px;
    background-position: left 4px ;
    background-repeat: no-repeat;
    padding-left: 40px;
    line-height: 32px;
    color: #FE886A;
    font-size: 28px;
    letter-spacing: normal !important;
}
.consult-n {
    width: 180px;
    color: #222;
    font-size: 28px;
    text-align: left;
    letter-spacing: normal !important;
}
</style>
