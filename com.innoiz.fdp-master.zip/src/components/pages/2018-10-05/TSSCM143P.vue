<template>
    <!-- 마케팅동의 이력 팝업 start -->
    <fdp-popup class="-pub-popup" v-model="showPopup" title="마케팅동의 이력" :prevent-outside-close="true">
        <!-- slot 원하는 내용 -->
        <div class="-pub-popup-page__slot">
            <div class="-pub-popup__marketing">
                <div class="-pub-filter-menu__text -pub-filter-menu__text--bottom -pub-filter-menu__item--left">총 {{mockData.length}}명</div>
                <fdp-infinite class="-pub-table -pub-table-blue" :items="mockData">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column" style="width: 92px;">고객명</th>
                            <th class="-pub-table-column" style="width: 158px;">생년월일</th>
                            <th class="-pub-table-column" style="width: 270px;">승인일</th>
                            <th class="-pub-table-column" style="width: 50px;">구분</th>
                            <th class="-pub-table-column" style="width: 156px;">유효 시작일</th>
                            <th class="-pub-table-column" style="width: 156px;">유효 종료일</th>
                            <th class="-pub-table-column" style="width: 380px;">처리 경로</th>
                        </tr>
                    </template>
                    <!-- 검색결과 없을때 화면 -->
                    <template slot="emptyView">
                        <div class="empty-table-content">
                            <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
                        </div>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column -pub-table-column--name" style="width: 92px;">{{props.item.name}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 158px;">{{props.item.birthday}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 270px;">{{props.item.confirm}}</td>
                        <td class="-pub-table-column" style="width: 50px;">{{props.item.section}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 156px;">{{props.item.startday}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 156px;">{{props.item.endday}}</td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 380px;">{{props.item.process}}</td>
                    </template>
                </fdp-infinite>
            </div>
            <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default">
                <div class="-pub-bottom-nav">
                    <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
                        <button type="button" class="-pub-button -pub-button--purple -pub-button--reverse">확인</button>
                    </div>
                </div>
            </fdp-bottom-bar>
        </div>
        <!-- slot 끝 -->
    </fdp-popup>
    <!-- 마케팅동의 이력 팝업 end -->
</template>
<script>
import mockData from '@/components/mock/TSSCM143P.mock'
export default {
  data () {
    return {
      showPopup: true,
      mockData: Array.prototype.slice.call(mockData)
    }
  }
}
</script>
