<template>
  <fdp-popup class="-pub-popup" v-model="showPopup" title="주소 검색" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot -pub-popup-page__address">
        <!-- 181102 상세주소 결과 중 하나 고르면 변환된 주소 고르는 곳으로 스크롤 이동 -->
        <div class="-pub-popup__content" ref="scroll">
            <!-- TSSBC501P_주소검색 -->
            <div class="-pub-popup-501p" v-if="isNow501p">
                <div class="-pub-addr-type-wrap">
                    <fdp-radio v-model="radioStrValue" class="-pub-radio" value="1">도로명주소(도로명검색)</fdp-radio>
                    <fdp-radio v-model="radioStrValue" class="-pub-radio" value="2">지번주소(읍/면/동 검색)</fdp-radio>
                </div>
                <!-- 도로명주소(도로명검색) -->
                <div class="-pub-addr-type" v-show="radioStrValue==='1'">
                    <div class="-pub-addr-type__row">
                        <label>시/도명</label>
                        <fdp-validator class="-pub-addr__field--1" name="tssbc501p-validator-1" display-name='시/도명' v-model="selectedValue1.key" :rules="'required'">
                            <fdp-select v-model="selectedValue1" :option-list="selectedData1" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                        <label>시/군/구명</label>
                        <fdp-validator class="-pub-addr__field--2" name="tssbc501p-validator-2" display-name='시/군/구명' v-model="selectedValue2.key" :rules="'required'">
                            <fdp-select v-model="selectedValue2" :option-list="selectedData2" placeholder="선택하세요"></fdp-select>
                        </fdp-validator>
                    </div>
                    <div class="-pub-addr-type__row">
                        <label>도로명</label>
                        <fdp-validator class="-pub-addr__field--3" name="tssbc501p-validator-3" display-name='도로명' v-model="data1" :rules="'required'">
                            <fdp-text-field placeholder="지역을 선택하시고 도로명을 입력하세요. 예)테헤란로, 삼성로 10번길" v-model="data1" clearable></fdp-text-field>
                        </fdp-validator>
                        <button type="button" class="-pub-search-button" @click="searchData('road')">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </div>
                </div>
                <!-- 지번주소(읍/면/동 검색) -->
                <div class="-pub-addr-type" v-show="radioStrValue==='2'">
                    <div class="-pub-addr-type__row">
                        <label>읍/면/동</label>
                        <fdp-validator class="-pub-addr__field--3" name="tssbc501p-validator-4" display-name="읍/면/동" v-model="data2" :rules="'required'">
                            <fdp-text-field  placeholder="찾고자 하는 지역의 읍면동 이름을 입력하세요. 예)삼성동, 삼성1동" v-model="data2" clearable></fdp-text-field>
                        </fdp-validator>
                    </div>
                    <div class="-pub-addr-type__row">
                        <label>건물명</label>
                        <fdp-validator class="-pub-addr__field--3" name="tssbc501p-validator-5" display-name="건물명" v-model="data3" :rules="'required'">
                            <fdp-text-field  placeholder="입력하세요." v-model="data3" clearable></fdp-text-field>
                        </fdp-validator>
                        <button type="button" class="-pub-search-button -pub-filter-menu__item" @click="searchData('jibun')">
                            <img src="@/assets/img/customer/ico-search-dark.png" class="-pub-search-button__icon" alt="조회">조회
                        </button>
                    </div>
                </div>
                <fdp-infinite class="-pub-table -pub-table-blue" v-model="radioTableSelected" :tableBodyHeight="tableBodyHeight" single-select :items="mockData">
                    <template slot="header">
                        <tr class="-pub-table__header">
                            <th class="-pub-table-column--radiobox" style="width: 78px;"></th>
                            <th class="-pub-table-column" style="width: 260px;">우편번호</th>
                            <th class="-pub-table-column" style="width: 716px;">주소</th>
                        </tr>
                    </template>
                    <template slot="emptyView">
                        <div class="empty-table-content" v-if="resType==='1'">
                            <img src="@/assets/img/components/ico_no_search_result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">검색결과가 존재하지 않습니다.</div>
                        </div>
                        <div class="empty-table-content" v-if="resType==='0'">
                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">지역 및 도로명을 입력하신 후 조회하세요.</div>
                        </div>
                        <div class="empty-table-content" v-if="resType==='2'">
                            <img src="@/assets/img/components/ico-no-result.png" class="empty-table-content__icon" />
                            <div class="empty-table-content__text">지역을 입력하신 후 조회하세요.</div>
                        </div>
                    </template>
                    <template slot-scope="props">
                        <td class="-pub-table-column--radiobox" style="width: 78px;">
                            <fdp-radio class="-pub-radio" v-model="radioSelected" :value="props.item.id.toString()"></fdp-radio>
                        </td>
                        <td class="-pub-table-column -pub-table-column--normal-letter" style="width: 260px;">{{props.item.code}}</td>
                        <td class="-pub-table-column -pub-table-column__addr" style="width: 716px;">{{props.item.addr}}</td>
                    </template>
                </fdp-infinite>
            </div>
            <!-- TSSBC502P 우편번호 상세주소 검증 -->
            <!-- 181102 상세주소 결과 중 하나 고르면 변환된 주소 고르는 곳으로 스크롤 이동 -->
            <div v-else>
                <TSSBC502P :param="{ zipcode: '05570', address: '서울 송파구 올림픽로 10길'}"
                @re-search="isNow501p = true"
                @button-active="isDisableButton = false"
                @scroll-move="scrollMove"></TSSBC502P>
            </div>
            <!-- 하단 버튼 고정 start -->
            <div class="-pub-bottom-bar">
                <div class="-pub-confirm__content--right">
                    <button type="button" class="-pub-button">취소
                    </button><button type="button" class="-pub-button -pub-button--reverse" :disabled="isDisableButton">주소반영</button>
                </div>
            </div>
            <!--// 하단 버튼 고정 end -->
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
</template>
<script>
import mockDataOrigin from '@/components/mock/TSSBC501P.mock'
import TSSBC502P from '@/components/pages/2018-10-05/TSSBC502P.vue'

export default {
  components: {
    TSSBC502P
  },
  data () {
    return {
      isDisableButton: true,
      showPopup: true,
      isNow501p: true,
      radioStrValue: '1',
      resType: '0', // 0 : 도로명 초기상태, 1: 결과 없음, 2: 지번 초기상태
      radioTableSelected: {},
      selectedValue1: { key: '', label: '' },
      selectedValue2: { key: '', label: '' },
      selectedData1: [{
        key: '서울',
        label: '서울'
      },
      {
        key: '부산',
        label: '부산'
      }],
      selectedData2: [{
        key: '송파구',
        label: '송파구'
      },
      {
        key: '합정',
        label: '합정'
      }],
      data1: '',
      data2: '',
      data3: '',
      tableBodyHeight: '598',
      radioSelected: '',
      mockData: [],
      mockDataOrigin: Array.prototype.slice.call(mockDataOrigin)
    }
  },
  watch: {
    radioTableSelected (newValue) {
      if (this.radioTableSelected) {
        this.radioSelected = this.radioTableSelected.id.toString()
        this.isNow501p = false
      }
    },
    radioStrValue (newValue) { // 도로명, 지번 선택 시 데이터 초기화
      this.mockData = []
      this.data1 = ''
      this.data2 = ''
      this.data3 = ''
      if (newValue === '1') this.resType = '0'
      else this.resType = '2'
    }
  },
  methods: {
    searchData (type) {
      this.mockData = []
      if (type === 'road') { // 도로명일 땐 '1'을 넣으면 주소 조회되도록 가정
        if (this.data1 === '1') {
          this.mockData = this.mockDataOrigin
        } else if (this.data1 === '') { // 도로명 주소 정보 부족할 때
          this.resType = '0'
        } else { // 도로명 검색결과 없을 경우
          this.resType = '1'
        }
      } else {
        if (this.data2 === '' || this.data3 === '') { // 지번 주소 정보 부족할 때
          this.resType = '2'
        } else { // 지번 검색결과 없을 경우 (현재는 검색결과 안나옴 : empty-view 확인 용도)
          this.resType = '1'
        }
      }
    },
    // 181102 상세주소 결과 중 하나 고르면 변환된 주소 고르는 곳으로 스크롤 이동
    scrollMove (value) {
      this.$refs.scroll.scrollTop = value
    }
  }
}
</script>
