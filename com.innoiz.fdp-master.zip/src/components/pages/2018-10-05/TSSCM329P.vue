<template>
  <!-- 동행결과입력 start -->
  <fdp-popup class="-pub-popup" v-model="showPopup" title="동행신청" :prevent-outside-close="true">
    <!-- slot 원하는 내용 -->
    <div class="-pub-popup-page__slot">
        <div class="-pub-popup__content">
            <div class="-pub-popup-330 -pub-popup-329">
                <div class="-pub-popup-row">
                    <label>고객명</label>
                    <span>김바다</span>
                </div>
                <div class="-pub-popup-row">
                    <label>동행 희망날짜 <strong>*</strong></label>
                    <fdp-validator name="tsscm329p-validator-1" display-name="동행 희망날짜" v-model="returnDate" :rules="'required'">
                        <fdp-date-picker class="-pub-date-picker" v-model="returnDate"></fdp-date-picker>
                    </fdp-validator>
                </div>
                <div class="-pub-popup-row">
                    <div class="-pub-329-result">
                        <span>해당 신청 내용이 지점장과 FC님께 문자 전송됩니다.</span>
                        <span>현재 지정장님 이름과 연락처 정보는 아래와 같습니다.</span>
                        <strong>이름 : 김지점</strong>
                        <strong>전화번호 : 010-1234-5678</strong>
                        <span>※ 상기 전화번호가 공란인 경우 FC님이 수신한 문자를 지점장님께 재전송 바랍니다.</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="-pub-popup__button-area -pub-popup__button-area--shadow">
            <button type="button" class="-pub-button -pub-button--180 -pub-button--purple">
                <span class="-pub-button__text">취소</span>
            </button>
            <button type="button" class="-pub-button -pub-button--180 -pub-button--purple -pub-button--reverse">
                <span class="-pub-button__text">확인</span>
            </button>
        </div>
    </div>
    <!-- slot 끝 -->
  </fdp-popup>
  <!-- 동행결과입력 팝업 end -->
</template>
<script>
export default {
  data () {
    return {
      showPopup: true,
      returnDate: ''
    }
  }
}
</script>
