<template>
  <div class="-pub-profile__details">
    <div class="-pub-content-tabs">
      <fdp-segment-box class="-pub-segment__container -pub-segment--large -pub-segment--purple" :essential="true"
        v-model="type" :data="types"></fdp-segment-box>
    </div>
    <component :is="type[0].key"></component>
  </div>
</template>
<script>
import TSSCM237D from '@/components/pages/2018-08-31/customer-detail-content(TSSCM237D)'
import TSSCM208D from '@/components/pages/2018-09-07/customer-detail-content(TSSCM208D)'
import TSSCM234D from '@/components/pages/2018-10-05/TSSCM234D'
import TSSCM235D from '@/components/pages/2018-10-12/TSSCM235D'
import TSSCM233D from '@/components/pages/2018-10-19/TSSCM233D'
export default {
  components: {
    TSSCM237D,
    TSSCM208D,
    TSSCM234D,
    TSSCM235D,
    TSSCM233D
  },
  computed: {

  },
  data () {
    return {
      type: [{
        key: 'TSSCM237D'
      }],
      types: [{
        key: 'TSSCM237D',
        label: '계약사항변경'
      },
      {
        key: 'TSSCM208D',
        label: 'FC터치'
      },
      {
        key: 'TSSCM233D',
        label: '캠페인'
      },
      {
        key: 'TSSCM234D',
        label: '접촉'
      },
      {
        key: 'TSSCM235D',
        label: '지급'
      }
      ]

    }
  }
}

</script>
<style>
</style>
