<template>
  <div class="-pub-consulting-content" :class="{'-pub-consulting-content--right-no-padding' : contentValue === '기계약현황'}">
    <div class="-pub-consulting-contract-info">
      <span class="-pub-consulting-contract-info__item -pub-consulting-contract-info__item--count">
        총계약건수 <span class="-pub-consulting-contract-info__number-text">0</span>
      </span>
      <span class="-pub-consulting-contract-info__item -pub-consulting-contract-info__item--price">
        보험료 <span class="-pub-consulting-contract-info__number-text">0</span>
      </span>
      <span class="-pub-consulting-contract-info__item -pub-consulting-contract-info__item--price">
        납입하신 보험료 <span class="-pub-consulting-contract-info__number-text">0</span>
      </span>
    </div>
    <div class="-pub-consulting-data-info">
      <span class="-pub-consulting-data-info__text -pub-consulting-data-info__text--count">
        총 0건
      </span>
      <div class="-pub-consulting-data-info__guide" v-if="contentValue === '보장기간'">
        <span class="-pub-consulting-data-info__text -pub-consulting-data-info__text--guide">납입기간</span>
        <span class="-pub-consulting-data-info__text -pub-consulting-data-info__text--guide">보장기간</span>
      </div>
    </div>
    <template v-if="contentValue === '기계약현황'" tag="div">
      <!-- 2018/10/31 컬럼추가에 따른 FDP-infinite -> FDP-table 변경 -->
      <fdp-table :options="tableOptions" :items="tableData" v-if="true"
        class="-pub-table_wrap -pub-fixed-table">
        <template slot="empty">
          <div class="-pub-table-empty-view">
            <div class="empty-table-content__text">계약건수가 없습니다.</div>
          </div>
        </template>
      </fdp-table>
      <!-- 2018/10/31 컬럼추가에 따른 FDP-infinite -> FDP-table 변경 end -->
    </template>
    <!-- 보장기간 콘텐츠 -->
    <template v-else-if="contentValue === '보장기간'" tag="div">
      <!-- 2018/10/31 컬럼 변경에 따른 스타일 조정 -->
      <fdp-infinite :items="tableData" class="-pub-table -pub-consulting-graph-table" :tableBodyHeight="656">
        <template slot="header">
          <tr class="-pub-table__header">
            <th class="-pub-table-column -pub-table-column--empty" style="width:294px"></th>
            <th class="-pub-table-column" style="height: 122px; width: 244px;">
              <!-- 한글 텍스트일떄 span태그로 감싸면 한글전용 폰트 스타일적용 -->
              <span>31</span>세<span class="-pub-table-column__icon -pub-table-column__icon--bar"></span>
            </th>
            <th class="-pub-table-column" style="height: 122px; width: 244px;">
              <span>60</span>세<span class="-pub-table-column__icon -pub-table-column__icon--bar"></span>
            </th>
            <th class="-pub-table-column" style="height: 122px; width: 244px;">
              <span>70</span>세<span class="-pub-table-column__icon -pub-table-column__icon--bar"></span>
            </th>
            <th class="-pub-table-column" style="height: 122x; width: 244px;">
              <span>80</span>세<span class="-pub-table-column__icon -pub-table-column__icon--bar"></span>
            </th>
            <th class="-pub-table-column" style="height: 122px; width: 244px;">
              <span>100</span>세<span class="-pub-table-column__icon -pub-table-column__icon--bar"></span>
            </th>
            <th class="-pub-table-column" style="height: 122px;">
              종신
            </th>
          </tr>
        </template>
        <template slot-scope="props">
          <!--  270, 166, 120, 120, 120, 166, 166, 166, 126, 156-->
          <td class="-pub-table-column -pub-table-column--left-align" style="width:294px">
            <div class="-pub-table-colmn__single-line--ellipsis">
              <span :class="props.item.underline ? '-pub-table-column__underline': ''">{{props.item.productName}}</span>
            </div>
          </td>
          <td class="-pub-table-column"><div class="-pub-graph-zone"></div></td>
        </template>
        <template slot="emptyView">
          <div class="-pub-table-empty-view">
              <div class="empty-table-content__text">계약건수가 없습니다.</div>
          </div>
        </template>
      </fdp-infinite>
      <!-- 2018/10/31 컬럼 변경에 따른 스타일 조정 end -->
    </template>
  </div>
</template>

<script>
import { mockData } from '@/components/mock/TSSCT003M.mock'
import cusCell from '@/components/pages/2018-11-02/comps/TSSCT003M-custom-cell'
export default {
  props: {
    contentValue: {
      type: String,
      default: _ => ''
    }
  },
  data () {
    return {
      isEmpty: false,
      mockData: Array.prototype.slice.call(mockData),
      tableHeaders: [
        [{
          title: '보험명',
          titleAlign: 'center',
          rowspan: 2,
          width: 270
        },
        {
          title: '만기년월',
          titleAlign: 'left',
          rowspan: 2,
          width: 166
        },
        {
          title: '계약관계자',
          titleAlign: 'center',
          colspan: 3,
          width: 400
        },
        {
          title: '계약년월',
          titleAlign: 'center',
          rowspan: 2,
          width: 166
        },
        {
          title: '가입회사',
          titleAlign: 'center',
          rowspan: 2,
          width: 166
        },
        {
          title: '납입완료',
          titleAlign: 'center',
          rowspan: 2,
          width: 166
        },
        {
          title: '납입주기',
          titleAlign: 'center',
          rowspan: 2,
          width: 126
        },
        {
          title: '보험료',
          titleAlign: 'center',
          rowspan: 2,
          width: 156
        }
        ],
        [{
          title: '계약자',
          titleAlign: 'center',
          width: 120
        },
        {
          title: '주피',
          titleAlign: 'center',
          width: 120
        },
        {
          title: '종피',
          titleAlign: 'center',
          width: 120
        }
        ]
      ],
      tableDataCopy: [{
        underline: true,
        productName: '더좋은정기보험(무해지)',
        endDate: '2080-04',
        contractor: '이주명주',
        main: '이주명주',
        sub: '김하늘하',
        contractDate: '1997-06',
        company: '삼성생명',
        paymentDate: '2020-05',
        paymentPattern: '월납',
        totalPayment: '154,300,000',
        paymentCount: 10
      },
      {
        underline: true,
        productName: '그린행복연금보험(그린)',
        endDate: '2080-04',
        contractor: '이주명',
        main: '이주명',
        sub: '',
        contractDate: '2004-08',
        company: '교보생명',
        paymentDate: '2025-07',
        paymentPattern: '월납',
        totalPayment: '20,120',
        paymentCount: 10

      },
      {
        underline: true,
        productName: '더좋은정기보험(무해지)',
        endDate: '종신',
        contractor: '김하늘',
        main: '이주명',
        sub: '',
        contractDate: '2004-08',
        company: '삼성생명',
        paymentDate: '2025-07',
        paymentPattern: '월납',
        totalPayment: '30,000',
        paymentCount: 10
      },
      {
        productName: '리더스변액유니버셜',
        endDate: '종신',
        contractor: '김하늘',
        main: '이주명',
        sub: '이주명',
        contractDate: '2017-06',
        company: '알리안츠',
        paymentDate: '2033-05',
        paymentPattern: '월납',
        totalPayment: '154,300',
        paymentCount: 10
      },
      {
        productName: '리더스변액유니버셜',
        endDate: '2018-04',

        contractor: '이주명',
        main: '이주명',
        sub: '',
        contractDate: '2017-06',

        company: '미래에셋',
        paymentDate: '2033-05',
        paymentPattern: '월납',
        totalPayment: '20,120',
        paymentCount: 10
      },
      {
        productName: '더좋은정기보험(무해지)',
        endDate: '2018-04',

        contractor: '김하늘',
        main: '이주명',
        sub: '',
        contractDate: '2017-06',

        company: '삼성생명',
        paymentDate: '2033-05',
        paymentPattern: '월납',
        paymentCount: 10,
        totalPayment: '154,300'
      }
      ],
      tableData: []
    }
  },
  watch: {
    isEmpty (val) {
      this.changeData()
    }
  },
  computed: {

    // 2018/10/30 FDP-table Options 추가
    tableOptions () {
      // fdp-table에서 fixed column을 사용하기 위한 option
      return {
        name: 'columnFixed',
        headerGroup: [
          ['', '', '계약관계자', '#', '#', '', '']
        ],
        cols: [
          {key: 'productName', component: cusCell, width: 312, name: '보험명', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'left'}},
          {key: 'endDate', width: 186, name: '만기년월', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
          {key: 'contractor', width: 140, name: '계약자', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
          {key: 'main', width: 140, name: '주피', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
          {key: 'sub', width: 140, name: '종피', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
          {key: 'contractDate', width: 186, name: '계약년월', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
          {key: 'company', width: 186, name: '가입회사', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
          {key: 'paymentDate', width: 186, name: '납입완료', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
          {key: 'paymentPattern', width: 146, name: '납입주기', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center'}},
          {key: 'totalPayment', width: 176, name: '보험료', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'right', 'letter-spacing': '0'}},
          {key: 'paymentCount', width: 146, name: '납입횟수', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'center', 'letter-spacing': '0'}},
          {key: 'totalPayment', width: 176, name: '납입하신 보험료 계', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'right', 'letter-spacing': '0'}},
          {key: 'totalPayment', width: 178, name: '향후 납입할 보험료 계', headerStyle: {'text-align': 'center'}, bodyStyle: {'text-align': 'right', 'letter-spacing': '0'}}
        ],
        // 컬럼 고정 여부
        availableColumnFixed: true,
        // 고정할 컬럼 수 (왼쪽부터 적용)
        howManyColumnFixed: 1,
        headerHeight: 63, // 사이즈가 디자인과 맞지 않아서 수정 20181019
        multiSelect: true,
        tableHeight: 656,
        infinite: true
        // bodyheight: this.selectItem ? 680 : 812 // table body height 사이즈 유동
      }
    }
  },
  mounted () {
    this.changeData()
  },
  methods: {
    changeData () {
      if (this.isEmpty) {
        this.tableData = []
      } else {
        this.tableData = [].concat(this.tableDataCopy)
      }
    }
  }
}
</script>
