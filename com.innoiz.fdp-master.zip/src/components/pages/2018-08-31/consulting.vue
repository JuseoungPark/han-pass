<template>
  <section class="-pub-consulting">
      <div class="-pub-transform-area"  :class="{'-pub-transform-area--content-scrolled' : isContentScrolled}">
        <div class="-pub-page-header -pub-page-header--bottom-bordered">
          <h2 class="-pub-page-header__title">
            <a class="-pub-page-header__button -pub-page-header__button--back">
              <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
            </a>
            <span class="-pub-page-header__text--parent-bottom">{{name}}님 보장분석</span>
          </h2>
          <!-- 보장분석 요약보기 임시 배치 -->
          <fdp-checkbox class="-pub-checkbox" style="padding:20px 20px;" v-model="showTabContent">보장분석 요약 보기 체크박스</fdp-checkbox>
          <!-- 보장분석 요약보기 임시 배치 end -->
          <div class="-pub-page-header__content">
            <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--icon">
              <img src="@/assets/img/components/ico-family-select.png" alt="뒤로가기">
              <span>세대원 선택</span>
            </a>
            <a class="-pub-page-header__button -pub-page-header__button--bordered -pub-page-header__button--icon">
              <img src="@/assets/img/components/ico-product-design.png" alt="뒤로가기">
              <!-- 상품설계 -> 가입설계로 기획변경 2018/10/26 -->
              <span>가입설계</span>
              <!-- 상품설계 -> 가입설계로 기획변경 2018/10/26 -->
            </a>
            <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu--gray -pub-tooltip-menu--type-3"
              v-model="currMenu2" :menu-list="menuListSample2" bottom>
              <div class="-pub-button--tooltip -pub-page-header__icon">
                <img src="@/assets/img/components/btn-gnb-consulting.png" alt="">
              </div>
            </fdp-tooltip-menu>
          </div>
        </div>
        <template v-if="showTabContent">
          <div class="-pub-consulting-bar">
            <h3 class="-pub-consulting-bar__title">{{currentContent.title}}</h3>
            <div class="-pub-consulting-bar__view-type">
              <fdp-radio class="-pub-radio" v-for="(name, idx) in currentRadios" v-model="contentRadioValue" :key="idx"
                :value="name">{{name}}</fdp-radio>
            </div>
            <div class="-pub-consulting-bar__select" v-if="this.currentContent.title === '보장분석'">
              <fdp-select v-model="select1.value" :option-list="select1.items" :disabled="this.contentRadioValue === '상품별'"></fdp-select>
            </div>
            <div class="-pub-consulting-bar__month-amount" v-if="this.currentContent.title === '상품컨설팅' && this.contentRadioValue === '상품별'">
              월보험료<span class="-pub-consulting-bar__price-text ">270,010,000</span>
            </div>
            <div class="-pub-consulting-bar__month-amount -pub-consulting-bar__month-amount--replace" v-if="this.currentContent.title === '상품컨설팅' && this.contentRadioValue === '기간별'">
              월보험료<span class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--before">270,010,000</span><span
                class="-pub-consulting-bar__price-text -pub-consulting-bar__price-text--replace">270,010,000</span>
            </div>
            <div class="-pub-consulting-bar_tabs">
              <dy-tab class="-pub-consulting-tab" :nav-items="navItems" @changeItem="changeComponent"></dy-tab>
            </div>
          </div>
        </template>
    <component v-if="showTabContent" :is="currentContent.component" :content-value="contentRadioValue" @onScroll="onContentScroll"></component>
    <TSSCT005M v-else></TSSCT005M>
    </div>
    <!-- 기계약 영역 -->
    <fdp-bottom-bar class="-pub-bottom-bar -pub-bottom-bar--default -pub-bottom-bar--fixed -pub-bottom-bar--full"
      v-show="!isContentScrolled">
      <!-- 원하는 컴포넌트 내용 start -->
      <div class="-pub-bottom-nav__item -pub-bottom-nav__item--centered -pub-bottom-nav__item--icon">
        <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip -pub-tooltip-menu -pub-tooltip-menu--type-4" v-model="currMenu"
          :menu-list="menuListSample" top>
          <div class="-pub-button -pub-button--tooltip">
            <span class="-pub-symbol--menu"></span>
          </div>
        </fdp-tooltip-menu>
      </div>
      <!--<fdp-radio class="-pub-radio -pub-bottom-nav__item -pub-bottom-nav__item--centered" v-model="isEmpty">데이터 존재여부</fdp-radio>-->
      <div class="-pub-bottom-nav__item--right -pub-bottom-nav__item--centered">
        <button class="-pub-button -pub-button--prev -pub-button--reverse" v-if="showTabContent || currentContent.title === '설계후보장분석'">
          <img class="icon-arrow" src="@/assets/img/components/ico-arrow-prev-blue.png" alt="이전 버튼">
          이전
        </button><button type="button" class="-pub-button -pub-button--reverse -pub-button--complete" v-if="currentContent.title === '설계후보장분석'">완료
        </button><button type="button" class="-pub-button -pub-button--next" v-else>다음<img class="icon-arrow" src="@/assets/img/components/ico-arrow-next-white.png"
            alt="다음 버튼">
        </button>
      </div>
      <!-- 원하는 컴포넌트 내용 end -->
    </fdp-bottom-bar>
  </section>
</template>
<script>
import DyTab from '@/components/pages/2018-08-31/dynamic-tab'
import TSSCT003M from '@/components/pages/2018-08-31/consulting-contents/TSSCT003M(TSSCT010M)'
import TSSCT006M from '@/components/pages/2018-09-07/consulting-contents/TSSCT006M(TSSCT007M)'
import TSSCT008M from '@/components/pages/2018-09-14/consulting-contents/TSSCT008M(TSSCT011M)'
import TSSCT005M from '@/components/pages/2018-09-14/consulting-contents/TSSCT005M'
import TSSCT009M from '@/components/pages/2018-09-21/consulting-contents/TSSCT009M(TSSCT013M)'
export default {
  components: {
    DyTab,
    TSSCT003M,
    TSSCT006M,
    TSSCT008M,
    TSSCT005M,
    TSSCT009M
  },
  watch: {
    currentContent (val) {
      if (val) {
        console.log(val)
        this.contentRadioValue = val.contentRadios[0]
      }
    }
  },
  computed: {
    currentRadios () {
      return (this.currentContent && this.currentContent.contentRadios) || []
    }
  },
  data () {
    return {
      isContentScrolled: false,
      name: '이주명',
      currMenu: '',
      currMenu2: '',
      contentRadioValue: '',
      showTabContent: true,
      navItems: [
        {
          title: '계약현황분석',
          component: 'TSSCT003M',
          contentRadios: ['기계약현황', '보장기간']
        },
        {
          title: '보장분석',
          component: 'TSSCT006M',
          contentRadios: ['상품별', '기간별']
        },
        {
          title: '상품컨설팅',
          component: 'TSSCT008M',
          contentRadios: ['상품별', '기간별']
        },
        {
          title: '설계후보장분석',
          component: 'TSSCT009M',
          contentRadios: ['전후비교', '지체비용']
        }
      ],
      select1: {
        items: [
          { key: '1', label: '3년' }
        ],
        value: { key: '1', label: '3년' }
      },
      currentContent: {},
      menuListSample: [{
        label: '세대요약형',
        key: 'email'
      },
      {
        label: '보험가입한도조회',
        key: 'dm'
      },
      {
        label: '실손가입조회',
        key: '1'
      },
      {
        label: '타사증권입력',
        key: '2'
      },
      {
        label: '표준모델선택',
        key: '3'
      },
      {
        label: '인쇄/이메일',
        key: '4'
      }
      ],
      menuListSample2: [{
        label: '라이프분석',
        key: 'email'
      },
      {
        label: '연금계산기',
        key: 'dm'
      },
      {
        label: '상속계산기',
        key: '1'
      },
      {
        label: '가족력',
        key: '2'
      }
      ]
    }
  },
  methods: {
    changeComponent (component) {
      this.currentContent = component
    },
    onContentScroll (isScrolled) {
      this.isContentScrolled = isScrolled
    }
  }
}
</script>
