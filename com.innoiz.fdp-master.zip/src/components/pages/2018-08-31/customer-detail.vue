<template>
  <section class="-pub-customer-detail">
    <div class="-pub-page-header -pub-page-header--bottom-bordered">
      <h2 class="-pub-page-header__title">
        <a class="-pub-page-header__button -pub-page-header__button--back">
          <img src="@/assets/img/components/ico-arrow-back.png" alt="뒤로가기">
        </a>
        <span class="-pub-page-header__text--parent-bottom">고객상세</span>
      </h2>
      <div class="-pub-page-header__content">
        <fdp-tooltip-menu class="-pub-tooltip-menu -pub-tooltip" v-model="currMenu" :menu-list="menuListSample" bottom>
          <div class="-pub-button -pub-button--tooltip">
            <span class="-pub-symbol--menu"></span>
          </div>
        </fdp-tooltip-menu>
      </div>
    </div>
    <div class="customer-detail__content">
      <article class="-pub-profile -pub-profile--left">
          <div class="-pub-profile-card__title -pub-container">
            <h2 class="-pub-container__item">{{member.name}}</h2>
            <div class="-pub-container__item -pub-profile-card__info">
              <span>{{member.phone}}</span><br>
              <span class="-pub-profile-card__title--grey">{{member.socialNumberFirst}} (보험 {{member.age}}세) {{member.gender}}</span>
            </div>
            <a class="-pub-container__item--right">
                <img src="@/assets/img/btn_customer_info.png" alt="customer info">
            </a>
          </div>
          <div>
            <h4 class="-pub-recent-activity">최근 활동</h4>
            <p class="-pub-recent-history" v-for="(history, index) in member.historys" :key="index"><span>{{history.data1}}</span><span>{{history.data2}}</span></p>
            <h4 class="-pub-customer-event">고객이벤트</h4>
            <ul class="-pub-profile-events">
              <li v-for="(event, index) in member.events" :key="index" class="-pub-profile-events__item">{{event.title}}</li>
            </ul>
            <!-- <ul class="-pub-profile-quick-menu -pub-container">
              <li class="-pub-container__item -pub-profile-quick-menu__item"><img class="-pub-profile-quick-menu__icon" src="@/assets/img/ico-customer-info-message.png" alt="Message"></li>
              <li class="-pub-container__item -pub-profile-quick-menu__item"><img class="-pub-profile-quick-menu__icon" src="@/assets/img/customer/ico-customer-info-memo.png" alt="memo"></li>
            </ul> -->
            <div class="-pub-name-ui__wrap" v-pub-name-ui-tab-click-outside="toggleItemOuter">
              <ul class="-pub-name-ui-tab">
                <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'message' }" @click="currMenu = 'message'">
                  <img src="@/assets/img/name-ui/ico_tab_message.png" alt="calendar today">
                </li>
                <li class="-pub-name-ui-tab__item" :class="{'-pub-name-ui-tab__item--active': currMenu === 'memo'}" @click="currMenu = 'memo'">
                  <img src="@/assets/img/name-ui/ico-tab-memo.png" alt="Message">
                </li>
              </ul>
              <div class="-pub-name-ui-tab__content" >
                <template v-if="currMenu === 'memo'">
                  <div class="-pub-name-ui-tab__text-area-container">
                    <h4 class="-pub-name-ui-tab__content-title">메모</h4>
                    <textarea class="-pub-name-ui-tab__text-area -pub-name-ui-tab__text-area--memo" v-model="memoText" :readonly="memoSave" ></textarea>
                  </div>
                  <div class="-pub-name-ui-tab__button-area -pub-coustomer-detail__button">
                      <button class="-pub-button -pub-button--purple" type="button" v-if="!memoSave" @click="currMenu = ''">취소</button>
                      <button class="-pub-button -pub-button--purple -pub-button--reverse" type="button" @click="memoSave = true" v-if="!memoSave">저장</button>
                      <button class="-pub-button -pub-button--purple -pub-button--reverse -pub-button--check" type="button" @click="memoSave = false; currMenu = ''" v-if="memoSave"><i class="check-icon"></i></button>
                  </div>
                </template>
                <template v-else-if="currMenu === 'message'">
                    <CustomerDetailTab4 @changeTab="setCurrMenu"></CustomerDetailTab4>
                </template>
              </div>
            </div>
            <!-- 문자 보내기 end -->
            <ul class="-pub-profile-quick-menu -pub-container" v-if="!currMenu">
              <li v-for="(item, index) in member.items" :key="index" class="-pub-profile-quick-menu__item--vertical">
                  <div>
                    <span class="-pub-quick-menu__title">{{item.data1}}</span>
                    <span v-if="item.data2 === ''" class="-pub-quick-menu__null">{{item.data2}}</span>
                    <span v-else class="-pub-quick-menu__date">{{item.data2}}</span>
                  </div>
                  <div>
                    <span v-if="item.color === '1'" class="-pub-quick-menu__d-day -pub-colored-text--1">{{item.data3}}</span>
                    <span v-else class="-pub-quick-menu__d-day">{{item.data3}}</span>
                    <span v-if="item.data4 === ''" class="-pub-quick-menu__null">{{item.data4}}</span>
                    <span v-else class="-pub-quick-menu__action">{{item.data4}}</span>
                    <!---->
                  </div>
              </li>
            </ul>
          </div>
      </article>
      <div class="-pub-profile -pub-profile--detail">
        <div class="-pub-page-container__wrapper">
            <fdp-tab-topcolor-type class="-pub-tab-container -pub-tab-container--single-line" @change-tab-idx="changeTabIdx" :tab-items="tabItems" :default-selected-idx="1">
              <template>
                <component :is="currentTabComponent"></component>
              </template>
            </fdp-tab-topcolor-type>
          </div>
      </div>
    </div>
  </section>
</template>
<script>
import { member } from '@/components/mock/TSSCM237D.mock'
import CustomerDetailTab2 from '@/components/pages/2018-08-31/customer-detail-tab2'
import CustomerDetailTab3 from '@/components/pages/2018-09-21/TSSCM207M'
import CustomerDetailTab4 from '@/components/pages/2018-09-21/tabs/TSSCM207M-tab'

export default {
  components: {
    CustomerDetailTab2,
    CustomerDetailTab3,
    CustomerDetailTab4
  },
  data () {
    return {
      currMenu: '',
      member: Object.assign({}, member),
      memoText: '메세지를 직접 입력하거나 하단의 자동 메세지 입력 버튼을 선택하세요.',
      currentTabComponent: 'CustomerDetailTab2',
      memoSave: false,
      menuListSample: [
        { label: '증권 재발행', key: '증권 재발행' },
        { label: '사고보험금 신청', key: '사고보험금 신청' },
        { label: '이메일', key: '이메일' },
        { label: '택배', key: '택배' },
        { label: 'DM', key: 'DM' }
      ],
      tabItems: [
        {
          tabTitle: '계약 및 보장 분석',
          tabComponent: 'CustomerDetailTab3'
        },
        {
          tabTitle: '터치이력',
          tabComponent: 'CustomerDetailTab2'
        }
      ]
    }
  },
  methods: {
    changeTabIdx (idx) {
      this.currentTabComponent = this.tabItems[idx].tabComponent
    },
    setCurrMenu (val) {
      this.currMenu = val
    },
    toggleItemOuter () {
      this.setCurrMenu()
    }
  },
  directives: {
    'pub-name-ui-tab-click-outside': {
      bind: function (el, binding) {
        // Define Handler and cache it on the element
        const handler = (e) => {
          if ((!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },

      unbind: function (el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      }
    }
  }
}
</script>
