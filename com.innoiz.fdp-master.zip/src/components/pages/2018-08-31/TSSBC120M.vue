<template>
  <div class="-pub-header-content -pub-header-content--notice">
    <div class="-pub-header-content__head">
      <h2 class="-pub-header-content__title">알림 <span class="-pub-header-content__text--bold">8</span></h2>
      <!--<fdp-radio class="-pub-radio -pub-bottom-nav__item -pub-bottom-nav__item--centered" style="position: absolute; left: 250px; top: 20px; width: 200px;" v-model="isEmpty">데이터 존재여부</fdp-radio>-->
      <a class="-pub-header-content__button--close" @click="closeContent"><img src="@/assets/img/components/btn_close_light.png" alt="닫기" /></a>
    </div>
    <fdp-list class="-pub-header-content__body" :list-data="noticeData" :list-height="1104" :is-loading="isLoadingStatus" @loading-data="loadingData" ref="targetFdpList">
      <template slot="emptyView">
        <div class="empty-content">
          <p class="empty-content__text">
            최근 3일간 알림이 없습니다.
          </p>
        </div>
      </template>
      <template slot-scope="props">
        <div class="-pub-header-content__item" :class="[props.item.isNewRecord ? '-pub-header-content__item--new' : '']">
          <a class="-pub-header-content__link">
            <span class="-pub-header-content__icon--new" v-if="props.item.isNewRecord"></span>
            <div class="-pub-header-content__info">
              <span class="-pub-header-content__info-title">{{props.item.text}}</span>
              <p class="-pub-header-content__info-data">
                <span class="-pub-header-content__badge">{{props.item.type}}</span>
                <span class="-pub-header-content__date" v-if="!props.item.isNewRecord">{{props.item.date}}</span>
                <span class="-pub-header-content__time">{{props.item.time}}</span>
              </p>
            </div>
          </a>
        </div>
      </template>
    </fdp-list>
    <!-- <div class="-pub-header-content__body">
      <div class="empty-content" v-if="isEmpty">
        <p class="empty-content__text">
          최근 3일간 알림이 없습니다.
        </p>
      </div>
      <ul class="-pub-header-content__list -pub-header-content__list--notice" v-else>
        <li class="-pub-header-content__item" :class="[notice.isNewRecord ? '-pub-header-content__item--new' : '']" v-for="(notice, index) in noticeData" :key="index" >
          <a class="-pub-header-content__link">
            <span class="-pub-header-content__icon--new" v-if="notice.isNewRecord"></span>
            <div class="-pub-header-content__info">
              <span class="-pub-header-content__info-title">{{notice.text}}</span>
              <p class="-pub-header-content__info-data">
                <span class="-pub-header-content__badge">{{notice.type}}</span>
                <span class="-pub-header-content__date" v-if="!notice.isNewRecord">{{notice.date}}</span>
                <span class="-pub-header-content__time">{{notice.time}}</span>
              </p>
            </div>
          </a>
        </li>
      </ul>
    </div> -->
  </div>
</template>
<script>
export default {
  methods: {
    closeContent () {
      this.$emit('close')
    },
    loadingData () {
      // 추가 로드 구현 부분
      // 추가 로드 시, isLoadingStatus 상태값 관리 필요.
    }
  },
  data () {
    return {
      isEmpty: false,
      isLoadingStatus: false,
      noticeData: [
        {
          isNewRecord: true,
          text: `황성주님 고객 정보가 변동되었습니다.`,
          type: `동의`,
          time: `18:20`,
          date: ``
        },
        {
          isNewRecord: true,
          text: `고영민님 고객동의가 완료되었습니다.`,
          type: `심사`,
          time: `18:20`,
          date: ``
        },
        {
          text: `고영민님 착오보험료가 지급되었습니다.`,
          type: `플라자`,
          time: `18:20`,
          date: `1일전`
        },
        {
          text: `이동주님 고객 정보가 변경되었습니다.`,
          type: `심사`,
          time: `18:20`,
          date: `1일전`
        },
        {
          text: `고영민님 착오보험료가 지급되었습니다.`,
          type: `동의`,
          time: `18:20`,
          date: `01-20`
        },
        {
          text: `김은영님 고객 정보가 변동되었습니다.`,
          type: `플라자`,
          time: `18:20`,
          date: `01-20`
        },
        {
          text: `이주영님 고객 정보가 변경되었습니다.`,
          type: `동의`,
          time: `18:20`,
          date: `01-18`
        },
        {
          text: `김혜은님 고객 정보가 변경되었습니다.`,
          type: `동의`,
          time: `18:20`,
          date: `01-18`
        },
        {
          text: `김혜은님 고객 정보가 변경되었습니다.`,
          type: `동의`,
          time: `18:20`,
          date: `01-18`
        }
      ]
    }
  }
}
</script>
