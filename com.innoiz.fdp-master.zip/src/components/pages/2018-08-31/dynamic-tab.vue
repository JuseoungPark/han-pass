<template>
  <nav class="-pub-dy-tab">
    <ul class="-pub-dy-tab__container">
      <li class="-pub-dy-tab__item"
          v-for="(item, idx) in navItems"
          :key="idx"
          :class="[idx === selectItemIdx ? '-pub-dy-tab__item--active': '']" @click="changeIdx(idx)"
          :style="getStyle(idx)">
        {{item.title}}
      </li>
    </ul>
  </nav>
</template>
<script>
export default {
  props: {
    navItems: {
      type: Array,
      default: _ => []
    },
    intialIndex: {
      type: Number,
      default: _ => 0
    },
    isReverseIndex: {
      type: Boolean,
      default: false
    },
    itemStyle: {
      type: [Function, Object],
      default: _ => {}
    }
  },
  data () {
    return {
      // intial value!
      selectItemIdx: -1
    }
  },
  computed: {
    currentComponent () {
      return this.navItems[this.selectItemIdx]
    },
    isFunctionStyle () {
      return typeof this.itemStyle === 'function'
    }
  },
  methods: {
    changeIdx (idx) {
      if (this.selectItemIdx !== idx) {
        this.selectItemIdx = idx
        this.$emit('changeItem', Object.assign(this.currentComponent, { index: idx }))
      }
    },
    getStyle (index) {
      const styleObject = { 'z-index': this.isReverseIndex ? this.navItems.length - index : index }
      return Object.assign(styleObject, this.isFunctionStyle ? this.itemStyle(index) : this.itemStyle)
    }
  },
  mounted () {
    console.log(this.intialIndex, this.intialIndex !== this.selectItemIdx)
    this.changeIdx(this.intialIndex)
  }
}
</script>
