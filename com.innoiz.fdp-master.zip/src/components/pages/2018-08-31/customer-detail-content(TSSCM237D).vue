<template>
  <div :class="[{'-pub-content-scroll':true}, {'-pub-fdp-list__empty-view':mockData.length === 0}]">
    <div>
      <!-- 데이터 없는 화면 추가 20181113 -->
      <template v-if="mockData.length === 0">
        <div class="-pub-table-empty-view">
          <div class="empty-table-content__text">데이터가 존재하지 않습니다.</div>
        </div>
      </template>
      <template v-else v-for="(year, idx) in mockData">
        <div class="-pub-accordion-container" v-for=" (mock, index2) in year.data" :key="'b' + idx + index2">
          <div class="-pub-accordion-line">
            <span class="-pub-accordion-line__text">{{mock.date}}</span>
          </div>
          <div class="-pub-accordion" :class="[mock.expand ? '-pub-accordion--expanded' : '']" >
            <div class="-pub-accordion__title">
              <div class="-pub-accordion__text -pub-accordion__text--type">{{mock.type}}</div>
              <div class="-pub-accordion__text -pub-accordion__text--item-name">
                <div class="-pub-table-colmn__single-line--ellipsis">{{mock.itemName}}</div>
              </div>
              <div class="-pub-accordion__text -pub-accordion__text--id -pub-accordion__text--number">계약번호 : {{mock.id}}</div>
              <a class="-pub-accordion__trigger" @click="mock.expand = !mock.expand"><img src="@/assets/img/customer/ico-arrow-down-black.png" alt=""></a>
            </div>
            <div class="-pub-accordion__content">
              <div class="-pub-section" v-for="(department, index3) in mock.departments" :key="index3">
                <div class="-pub-accordion__text -pub-accordion__text--type">처리부서</div>
                <div class="-pub-accordion__text -pub-accordion__text--team-name">{{department.name}} </div>
                <div class="-pub-accordion__text -pub-accordion__text--process">처리자</div>
                <div class="-pub-accordion__text--id">000 {{department.userName}} ({{department.userId}})</div>
              </div>
            </div>
          </div>
        </div>
        <div class="-pub-accordion-container -pub-accordion-container--year" :key="idx">
          <div class="-pub-accordion-line -pub-accordion-line--year">
            <span class="-pub-accordion-line__text -pub-accordion-line__text--year ">{{year.year}}</span>
          </div>
          <div class="-pub-accordion--empty"></div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      mockData: [
        {
          year: 2016,
          data: [{
            expand: false,
            date: '07.16',
            id: '12312312312322',
            type: '수익자변경',
            itemName: 'New나이에 딱맞는 변액보험',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          },
          {
            expand: false,
            date: '06.16',
            id: '12312312312322',
            type: '감액',
            itemName: '통합변액유니버설보험',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          },
          {
            expand: false,
            date: '02.10',
            id: '12312312312322',
            type: '감액',
            itemName: '암보험(갱신형, 무배당)',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          }
          ]
        },
        {
          year: 2015,
          data: [{
            expand: false,
            date: '07.16',
            id: '12312312312322',
            type: '수익자 변경',
            itemName: '나이에 딱맞는 변액보험',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          },
          {
            expand: false,
            date: '06.16',
            id: '12312312312322',
            type: '감액',
            itemName: '통합변액유니버설보험',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          },
          {
            expand: false,
            date: '02.10',
            id: '12312312312322',
            type: '감액',
            itemName: '암보험(갱신형, 무배당)',
            departments: [{
              name: '0000부서',
              userName: '김정은',
              userId: '123456'
            }]
          }
          ]
        }
      ]
    }
  }
}
</script>

<style>

</style>
