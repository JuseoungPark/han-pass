import { error } from './error'

// passive event 지원 체크
const isSupportPassiveEvent = (win => {
  let supportsPassive = false
  try {
    var opts = Object.defineProperty({}, 'passive', {
      get: function () {
        supportsPassive = true
      }
    })
    win.addEventListener('testPassive', null, opts)
    win.removeEventListener('testPassive', null, opts)
  } catch (e) {}

  return supportsPassive
})(window)

const ScrollEventTick = class {
  /**
    * 스크롤 이벤트 발생시 호출 콜백함수
    * @callback scrollEventCallback
    * @param {Event} e - 이벤트 객체
    * @param {number} scrollTop - 엘리먼트 scrollTop 값
    * @param {number} scrollLeft - 엘리먼트 scrollLeft 값
  */

  /**
   * 스크롤 이벤트 감지 클래스
   * @param {HTMLElement} el - scroll 대상 엘리먼트
   * @param {scrollEventCallback}
   */
  constructor (el, scrollEventCallback) {
    if (!el || typeof scrollEventCallback !== 'function') {
      error('invalid parameter!')
    }
    // 스크롤 이벤트 중복호출 상태변수
    this.tick = false
    this.el = el
    // event Object
    this.e = null
    this.latestScrollTop = el.scrollTop
    this.latestScrollLeft = el.scrollLeft
    this.callback = scrollEventCallback

    this.el.addEventListener('scroll', e => this._onScroll(e), isSupportPassiveEvent ? { passive: true } : false)
    this._onScroll({ isIntial: true })
  }

  /**
   * @private
   */
  _update () {
    this.latestScrollTop = this.el.scrollTop
    this.latestScrollLeft = this.el.scrollLeft
    this.callback(this.e, this.latestScrollTop, this.latestScrollLeft)
  }
  /**
   * @private
   */
  _onScroll (e) {
    this.e = e
    this._requestTick()
  }
  /**
   * @private
   */
  _requestTick () {
    const raf = requestAnimationFrame

    if (!this.tick) {
      raf(_ => {
        this._update()
        this.tick = false
      })
      this.tick = true
    }
  }
}

export const createScrollTickInstance = function () {
  return new ScrollEventTick(...arguments)
}
