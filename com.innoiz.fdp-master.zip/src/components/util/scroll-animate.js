import { error } from './error'

const EASING = {
  // easing 함수 주소 : http://goo.gl/5HLl8
  'linear': (t, b, c, d) => {
    t /= d
    return b + c * (t)
  },
  'easeOut': (t, b, c, d) => {
    const ts = (t /= d) * t
    const tc = ts * t
    return b + c * (0.9 * tc * ts + -4.35 * ts * ts + 8.6 * tc + -8.7 * ts + 4.55 * t)
  },
  'easeInOut': (t, b, c, d) => {
    var ts = (t /= d) * t
    var tc = ts * t
    return b + c * (6 * tc * ts + -15 * ts * ts + 10 * tc)
  }
}

const ScrollAnimate = class {
  /**
   * 스크롤 애니메이션 생성자
   * @param {HTMLElement} el - scroll 대상 엘리먼트
   * @param {String} position - 스크롤 방향값 (x or y)
   */
  constructor (el = null, position = '') {
    if (!el || !position) {
      error('invalid parameter!')
    }

    this.elPosition = this._getElementPosition(el, position)

    /**
     * @private
     */
    this._isScrolling = false
    this._isCancel = false
  }
  /**
   * 생성자에서 인수로 받은 position 값에 따른 Element scrollLeft or scrollTop 값 setter getter 클로저 반환
   * @private
   * @param {HTMLElement} el - scroll 대상 엘리먼트
   * @param {String} position - 스크롤 방향값 (x or y)
   * @return {Object}
   */
  _getElementPosition (el, position) {
    return {
      setScroll: function (val) {
        position === 'x' ? (el.scrollLeft = val) : (el.scrollTop = val)
      },
      getScroll: function () {
        return position === 'x' ? (el.scrollLeft) : (el.scrollTop)
      }
    }
  }

  /**
   * 현재 스크롤 애니메이션 진행여부 상태변수값 반환
   * @return {Boolean} 스크롤 애니메이션 진행상태변수 값
   */
  isScrolling () {
    return this._isScrolling
  }
  /**
   * 스크롤 애니메이션 중단 메소드
   */
  stopAnimate () {
    if (this.isScrolling()) {
      this._isCancel = true
    }
  }
  /**
   * 애니메이션 진행 메소드
   * @param {number} to - 이동할 스크롤 좌표 픽셀값 (단위:ms)
   * @param {number} duration - 애니메이션 총 진행시간 (단위:ms)
   * @param {number} delay - 애니메이션 수행전 초기 딜레이 (단위:ms)
   * @param {String} easingName - 애니메이션 timing Function Name
   * @param {function} callback - 애니메이션 종료 후 호출 콜백
   */
  animate (to = 0, duration = 500, delay = 0, easingName = 'linear', callback = _ => {}) {
    // 1 frame value
    const INCREMENT = 1000 / 60

    let start = 0
    let change = 0
    let currentTime = 0
    this._isScrolling = true

    const a = _ => {
      currentTime += INCREMENT
      !this._isCancel && this.elPosition.setScroll(
        EASING[easingName](currentTime, start, change, duration)
      )

      if (currentTime <= duration && !this._isCancel) {
        requestAnimationFrame(a)
      } else {
        typeof callback === 'function' && callback()
        this._isScrolling = false
        this._isCancel = false
      }
    }

    setTimeout(_ => {
      requestAnimationFrame(_ => {
        start = this.elPosition.getScroll()
        change = to - start
        a()
      })
    }, delay)
  }
}

export const createScrollAnimateInstance = function () {
  return new ScrollAnimate(...arguments)
}
