export const error = (msg) => {
  throw new Error(msg)
}
