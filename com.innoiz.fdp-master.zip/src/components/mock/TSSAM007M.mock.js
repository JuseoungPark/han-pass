export const infoListMocks = [
  {
    chk: false,
    cat: 'DM',
    tit: '[보험이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '1'
  },
  {
    chk: false,
    cat: '상품안내자료',
    tit: '[DM이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '2'
  },
  {
    chk: false,
    cat: '친숙',
    tit: '온라인보험 시장, 판매금액 2012년 대비 5배가 넘는다',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '3'
  },
  {
    chk: false,
    cat: '뉴스통계',
    tit: '[뉴스통계]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '1'

  },
  {
    chk: false,
    cat: '동영상자료',
    tit: '[동영상자료]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'pop',
    imgType: '4'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '3'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '1'
  }, {
    chk: false,
    cat: 'DM',
    tit: '[보험이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '1'
  },
  {
    chk: false,
    cat: '상품안내자료',
    tit: '[DM이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '4'
  },
  {
    chk: false,
    cat: '친숙',
    tit: '온라인보험 시장, 판매금액 2012년 대비 5배가 넘는다',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '3'
  },
  {
    chk: false,
    cat: '뉴스통계',
    tit: '[뉴스통계]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '1'

  },
  {
    chk: false,
    cat: '동영상자료',
    tit: '[동영상자료]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'pop',
    imgType: '4'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '3'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '1'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[보험이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '1'
  },
  {
    chk: false,
    cat: '상품안내자료',
    tit: '[DM이야기]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'my',
    imgType: '2'
  },
  {
    chk: false,
    cat: '친숙',
    tit: '온라인보험 시장, 판매금액 2012년 대비 5배가 넘는다',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '3'
  },
  {
    chk: false,
    cat: '뉴스통계',
    tit: '[뉴스통계]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: true,
    type: 'pop',
    imgType: '1'

  },
  {
    chk: false,
    cat: '동영상자료',
    tit: '[동영상자료]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'pop',
    imgType: '4'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '3'
  },
  {
    chk: false,
    cat: 'DM',
    tit: '[라이브러리]' + '\n' + '실손보험 대수술',
    date: '1967-02-14',
    line: '',
    views: '15333',
    isHot: false,
    type: 'rec',
    imgType: '1'
  }
]
