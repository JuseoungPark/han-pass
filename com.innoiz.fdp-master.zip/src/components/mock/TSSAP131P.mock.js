export const viewMemberMocks = [
  {
    num: '100001',
    name1: '이이주명',
    name2: '이주명명',
    productName: '스마트변액연금',
    productGroup: '금융',
    period: '25',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100002',
    name1: '한현민',
    name2: '한현민',
    productName: '플래티넘VUL',
    productGroup: '보장',
    period: '20',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100003',
    name1: '김아랑',
    name2: '김아랑',
    productName: '변액유니종신',
    productGroup: '보장',
    period: '10',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100004',
    name1: '최민정',
    name2: '최민정',
    productName: '스마트변액연금',
    productGroup: '금융',
    period: '8',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100005',
    name1: '김미애',
    name2: '김미애',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '7',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100006',
    name1: '김영미',
    name2: '김영미',
    productName: '변액유니종신',
    productGroup: '보장',
    period: '5',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100007',
    name1: '서영우',
    name2: '서영우',
    productName: '스마트변액연금',
    productGroup: '보장',
    period: '13',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100008',
    name1: '이주명',
    name2: '이주명',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '12',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100009',
    name1: '이주명',
    name2: '이주명',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '12',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100010',
    name1: '이주명',
    name2: '이주명',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '12',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100011',
    name1: '이주명',
    name2: '이주명',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '12',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  },
  {
    num: '100012',
    name1: '이주명',
    name2: '이주명',
    productName: '플래티넘VUL',
    productGroup: '금융',
    period: '12',
    premium: '200,000',
    record: '200,000',
    date: '2018-04-30'
  }
]
