export const tableData1 = [
  {
    idx: 1,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  }
  /*
  {
    idx: 2,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  },
  {
    idx: 3,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  },
  {
    idx: 4,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  },
  {
    idx: 5,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  },
  {
    idx: 6,
    company: '메리츠화재',
    productName: '상해',
    productType: '상해형',
    specificity: '임원의료비',
    price: '30,000,000',
    status: '정상',
    period: '2017-04-20 18:00:37',
    typeName: '일반(손보)'
  }
  */
]

export const tableData2 = [
  {
    customerName: '기서돌',
    date1: '2017-03-22',
    date2: '2017-04-20 18:00:37',
    date3: '2017-04-20 18:00:37',
    date4: '2017-04-20 18:00:37'
  }
]
export const tableData3 = [
  [
    'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O'
  ]
]

export const tableData4 = [
  [
    'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'
  ]
]
