export const viewMemberMocks = [
  {
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    mainCustomer: '리이주명',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '한현민',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '남',
    mainCustomer: '최민정',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김아랑',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    mainCustomer: '김미애',
    conectivity: '본인',
    delectDate: '2017-06-15',
    confirmDate: '2017-06-15'
  }
]

export const subMenus = [
  {
    name: '전체 고객',
    color: 'blue'
  },
  {
    name: '캠페인 고객',
    color: 'navy'
  },
  {
    name: '프리미엄 고객사랑 서비스',
    color: 'navy'
  },
  {
    name: 'VIP 서비스 신청',
    color: 'purple'
  },
  {
    name: '고객접촉 정보',
    color: 'purple'
  },
  {
    name: '이벤트 고객',
    color: 'green'

  },
  {
    name: '수금인수고객',
    color: 'green'
  },
  {
    name: '관심고객',
    color: 'green'
  },
  {
    name: '정보동의활용현황',
    color: 'purple'
  },
  {
    name: '미승인 고객',
    color: 'purple',
    active: true
  },
  {
    name: '삭제예정 고객',
    color: 'purple'
  },
  {
    name: '내 그룹',
    color: 'purple'
  }
]
