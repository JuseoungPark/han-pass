export default [
  {
    code: '00001',
    name: '부산AFC지역단'
  },
  {
    code: '00002',
    name: '부산지역단'
  },
  {
    code: '00003',
    name: '부산법인지역단'
  },
  {
    code: '00004',
    name: '부산법인지역단'
  },
  {
    code: '00005',
    name: '부산지역단'
  },
  {
    code: '00006',
    name: '부산지역단'
  },
  {
    code: '00007',
    name: '부산AFC지역단'
  },
  {
    code: '00008',
    name: '부산AFC지역단'
  },
  {
    code: '00009',
    name: '부산AFC지역단'
  },
  {
    code: '00010',
    name: '김에스더'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  },
  {
    code: '00011',
    name: '부산AFC지역단'
  }
]
