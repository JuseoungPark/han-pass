export default [{
  name: '이주명',
  jumin: '551111',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551112',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
},
{
  name: '이주명',
  jumin: '551113',
  gender: '여자',
  maincustomer: '손평국',
  conectivity: '본인',
  customervalue: '가망',
  phone: '(핸)010-1234-1234'
}
]
