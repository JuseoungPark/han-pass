export const viewMemberMocks = [{
  name: '이주명명',
  birthDay: '1997-04-30',
  type: '만기',
  customerType: '장기미거래',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '한현민',
  birthDay: '1997-04-30',
  type: '완납',
  customerType: '만기도래',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '김아랑',
  birthDay: '1997-04-30',
  type: '내고객 추가',
  customerType: '장기미터치',
  customerGroup: 'B1',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '최민정',
  birthDay: '1997-04-30',
  type: '만기',
  customerType: '계약월도래',
  customerGroup: 'B2',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '김미애',
  birthDay: '1997-04-30',
  type: '완납',
  customerType: '신규관심',
  customerGroup: 'A',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '김영미',
  birthDay: '1997-04-30',
  type: '준가치',
  customerType: '장기미터치',
  customerGroup: 'B1',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '서영우',
  birthDay: '1997-04-30',
  type: '내고객추가',
  customerType: '계약월도래',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '차준환',
  birthDay: '1997-04-30',
  type: '완납',
  customerType: '신규관심',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '이주명',
  birthDay: '1997-04-30',
  type: '만기',
  customerType: '장기미거래',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
},
{
  name: '이주명',
  birthDay: '1997-04-30',
  type: '만기',
  customerType: '장기미거래',
  customerGroup: 'C',
  phone: '010-1234-1234',
  division: '',
  applyDate: '2017-06-02',
  applyItem: '①베개드림...',
  category1: '',
  applyResult: '2017-06-02(미방문)',
  category2: '',
  applyResendDate: '2017-06-02(1회)'
}
]

export const subMenus = [{
  name: '전체 고객',
  color: 'blue'
},
{
  name: '캠페인 고객',
  color: 'navy'
},
{
  name: '프리미엄 고객사랑 서비스',
  color: 'navy',
  active: true
},
{
  name: 'VIP 서비스 신청',
  color: 'purple'
},
{
  name: '고객접촉 정보',
  color: 'purple'
},
{
  name: '이벤트 고객',
  color: 'green'

},
{
  name: '수금인수고객',
  color: 'green'
},
{
  name: '관심고객',
  color: 'green'
},
{
  name: '정보동의활용현황',
  color: 'purple'
}
]
