export default [
  {
    id: 1,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: true,
    marketing: false
  },
  {
    id: 2,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: false,
    marketing: true
  },
  {
    id: 3,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: true,
    marketing: false
  },
  {
    id: 4,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: false,
    marketing: true
  },
  {
    id: 5,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: true,
    marketing: false
  },
  {
    id: 6,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: false,
    marketing: true
  },
  {
    id: 7,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: true,
    marketing: false
  },
  {
    id: 8,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: false,
    marketing: true
  },
  {
    id: 9,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: true,
    marketing: false
  },
  {
    id: 10,
    name: '손평국',
    birthDay: '1997-04-30',
    me: '본인',
    consulting: false,
    marketing: true
  }
]
