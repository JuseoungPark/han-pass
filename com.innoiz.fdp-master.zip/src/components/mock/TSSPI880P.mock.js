export default [
  {
    key: 1,
    name: 'acd신황',
    code: '123456789',
    name2: '어이미',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 2,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 3,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 4,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 5,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 6,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 7,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 8,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  },
  {
    key: 9,
    name: 'acxy-오창',
    code: '123456789',
    name2: '동무파',
    emp: '00',
    sel: 'Y'
  }
]
