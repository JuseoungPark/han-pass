export const groupList = [
  {
    key: '1',
    name: '나의 VIP 그룹',
    num: 10,
    date: '2018-04-30',
    gander: '남',
    data4: '본인모집'
  },
  {
    key: '2',
    name: '그룹2',
    num: 3,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '3',
    name: '그룹3',
    num: 4,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '4',
    name: '그룹4',
    num: 5,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '5',
    name: '그룹5',
    num: 6,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '6',
    name: '그룹6',
    num: 7,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '7',
    name: '그룹7',
    num: 8,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  },
  {
    key: '8',
    name: '그룹8',
    num: 6,
    date: '2018-04-30',
    gander: '남',
    data4: '타인모집'
  }
]

export const groupMembers = [
  {
    no: 1,
    group: '1',
    name: '김바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  },
  {
    no: 2,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 3,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 4,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 5,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 6,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 7,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 8,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 9,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 10,
    group: '1',
    name: '이바다',
    birth: '2017-08-01',
    gender: '남',
    type: '타인모집'
  },
  {
    no: 11,
    group: '2',
    name: '정바다',
    birth: '2017-08-01',
    gender: '여',
    type: '임시'
  }, {
    no: 12,
    group: '2',
    name: '박바다',
    birth: '2017-08-01',
    gender: '남',
    type: '관심'
  }, {
    no: 13,
    group: '2',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }, {
    no: 14,
    group: '3',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }, {
    no: 15,
    group: '4',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }, {
    no: 16,
    group: '5',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }, {
    no: 17,
    group: '6',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }, {
    no: 18,
    group: '6',
    name: '임바다',
    birth: '2017-08-01',
    gender: '여',
    type: '본인모집'
  }
]
