
export const viewMemberMocks = [
  {
    idx: 1,
    ck: false,
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    rating: 'Platinum Ⅰ',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'N',
    svipNo: 'SVIP 308310',
    status: '신청가능',
    product: '신청',
    callNumber: '02-123-1234(신청:2017-08)',
    cancelReason: ''
  },
  {
    idx: 2,
    ck: false,
    consultant: '이순원',
    name: '한현민',
    birthDay: '1997-04-30',
    rating: 'Platinum Ⅱ',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    customerType: '본인모집',
    mainCustomer: '한현민',
    status: '배송중',
    product: '정관장홍삼세트',
    callNumber: '',
    cancelReason: ''

  },
  {
    idx: 3,
    ck: false,
    consultant: '이순원',
    name: '김아랑',
    birthDay: '1997-04-30',
    rating: 'Gold',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청완료',
    product: '정관장홍삼세트',
    underline: true,
    callNumber: '02-123-1234(신청:2017-08)',
    cancelReason: ''
  },
  {
    idx: 4,
    ck: false,
    consultant: '이순원',
    name: '최민정',
    birthDay: '1997-04-30',
    rating: 'Gold',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청완료',
    product: '강북삼성병원 건강검진...',
    cancelReason: ''
  },
  {
    idx: 5,
    ck: false,
    consultant: '이순원',
    name: '김미애',
    birthDay: '1997-04-30',
    rating: 'Silver',
    phone: '010-1234-1234',
    hasCustomer: 'N',
    hasCustomerCard: 'N',
    svipNo: 'SVIP 308310',
    status: '신청불가',
    product: '강북삼성병원 건강검진...',
    cancelReason: '해당등급 주문불가'
  },
  {
    idx: 6,
    ck: false,
    consultant: '이순원',
    name: '배준호',
    birthDay: '1997-04-30',
    rating: 'Silver',
    phone: '010-1234-1234',
    hasCustomer: 'N',
    hasCustomerCard: 'N',
    svipNo: 'SVIP 308310',
    status: '신청불가',
    product: '강북삼성병원 건강검진...',
    cancelReason: '계약자 변경'
  },
  {
    idx: 7,
    ck: false,
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    rating: 'Platinum Ⅰ',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'N',
    svipNo: 'SVIP 308310',
    status: '신청가능',
    callNumber: '02-123-1234(신청:2017-08)',
    cancelReason: ''
  },
  {
    idx: 8,
    ck: false,
    consultant: '이순원',
    name: '한현민',
    birthDay: '1997-04-30',
    rating: 'Platinum Ⅱ',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    customerType: '본인모집',
    mainCustomer: '한현민',
    status: '배송중',
    product: '정관장홍삼세트',
    callNumber: '',
    cancelReason: ''
  },
  {
    idx: 9,
    ck: false,
    consultant: '이순원',
    name: '김아랑',
    birthDay: '1997-04-30',
    rating: 'Gold',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청완료',
    product: '정관장홍삼세트',
    underline: true,
    callNumber: '02-123-1234(신청:2017-08)',
    cancelReason: ''
  },
  {
    idx: 10,
    ck: false,
    consultant: '이순원',
    name: '최민정',
    birthDay: '1997-04-30',
    rating: 'Gold',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청완료',
    product: '강북삼성병원 건강검진...',
    cancelReason: ''
  },
  {
    idx: 11,
    ck: false,
    consultant: '이순원',
    name: '김미애',
    birthDay: '1997-04-30',
    rating: 'Silver',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청불가',
    product: '강북삼성병원 건강검진...',
    cancelReason: '해당등급 주문불가'
  },
  {
    idx: 12,
    ck: false,
    consultant: '이순원',
    name: '배준호',
    birthDay: '1997-04-30',
    rating: 'Silver',
    phone: '010-1234-1234',
    hasCustomer: 'Y',
    hasCustomerCard: 'Y',
    svipNo: 'SVIP 308310',
    status: '신청불가',
    product: '강북삼성병원 건강검진...',
    cancelReason: '계약자 변경'
  }
]

export const subMenus = [
  {
    name: '전체 고객',
    color: 'blue'
  },
  {
    name: '캠페인 고객',
    color: 'navy'
  },
  {
    name: '프리미엄 고객사랑 서비스',
    color: 'navy'
  },
  {
    name: 'VIP 서비스 신청',
    color: 'purple',
    active: true
  },
  {
    name: '고객접촉 정보',
    color: 'purple'
  },
  {
    name: '이벤트 고객',
    color: 'green'

  },
  {
    name: '수금인수고객',
    color: 'green'
  },
  {
    name: '관심고객',
    color: 'green'
  },
  {
    name: '정보동의활용현황',
    color: 'purple'
  }
]
