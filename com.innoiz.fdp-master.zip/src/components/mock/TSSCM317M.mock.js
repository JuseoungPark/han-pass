export const viewMemberMocks = [
  {
    idx: 1,
    ck: false,
    name: '우리이주',
    customerCard: 'Y',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '회수유예',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 2,
    ck: false,
    name: '리이주명',
    customerCard: 'Y',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '회수유예',
    recovery: 'N',
    activityDate: '2017-05-31',
    touchRank: '전략고객',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 3,
    ck: false,
    name: '리이주명',
    customerCard: 'Y',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '(핸)010-1234-1234',
    mainCustomer: '김아랑',
    conectivity: '본인',
    address: '경인 용인시 기흥구',
    application: '원거리 회수',
    recovery: 'N',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 4,
    ck: false,
    name: '리이주명',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '회수유예',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 5,
    ck: false,
    name: '우이주명',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '회수유예',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 6,
    ck: false,
    name: '우리이명',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '회수유예',
    recovery: 'N',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 7,
    ck: false,
    name: '우리이주',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 8,
    ck: false,
    name: '우리이주',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 9,
    ck: false,
    name: '우리이주',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 10,
    ck: false,
    name: '우리이주',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 11,
    ck: false,
    name: '우리이주',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'Y',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  },
  {
    idx: 12,
    ck: false,
    name: '마지막',
    customerCard: 'N',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '(핸)010-1234-1234',
    mainCustomer: '리이주명',
    conectivity: '본인',
    address: '서울 양천구',
    application: '',
    recovery: 'N',
    activityDate: '2017-05-31',
    touchRank: '최우선 공략',
    takeoverDate: '2017-06-15'
  }
]

export const subMenus = [
  {
    name: '전체 고객',
    color: 'blue'
  },
  {
    name: '캠페인 고객',
    color: 'navy'
  },
  {
    name: '프리미엄 고객사랑 서비스',
    color: 'navy'
  },
  {
    name: 'VIP 서비스 신청',
    color: 'purple'
  },
  {
    name: '고객접촉 정보',
    color: 'purple'
  },
  {
    name: '이벤트 고객',
    color: 'green'

  },
  {
    name: '수금인수고객',
    color: 'green'
  },
  {
    name: '관심고객',
    color: 'green',
    active: true
  },
  {
    name: '정보동의활용현황',
    color: 'purple'
  },
  {
    name: '미승인 고객',
    color: 'purple'
  },
  {
    name: '삭제예정 고객',
    color: 'purple'
  },
  {
    name: '내 그룹',
    color: 'purple'
  }
]
