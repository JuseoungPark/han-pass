export const member = {
  name: '이주명',
  age: '52',
  job: '사무총무원',
  phone: '010-1234-1234',
  gender: '여',
  socialNumberFirst: '1978-11-11',
  events: [{
    title: '납입완료(당월)'
  },
  {
    title: '계약월도래'
  },
  {
    title: '만기도래(당월)'
  }],
  historys: [{
    data1: '2주 전',
    data2: '사고 보험금 접수'
  }],
  items: [{
    data1: '필수 컨설팅',
    data2: '1978-11-12 만료',
    data3: 'D-6',
    color: '1',
    data4: '동의 연장'
  },
  {
    data1: '마케팅',
    data2: '1978-11-12 만료',
    data3: 'D-99+',
    color: '',
    data4: '동의 연장'
  },
  {
    data1: '마케팅',
    data2: '1978-11-12 만료',
    data3: 'D-99+',
    color: '',
    data4: '적합성 진단'
  },
  {
    data1: '상령일',
    data2: '',
    data3: '10월22일',
    color: '',
    data4: ''
  }]
}
