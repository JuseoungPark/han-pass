export const mockData = [
  [{
    category: '사망',
    data: [
      {
        label: '암사망',
        value: ''
      },
      {
        label: '일반사망',
        value: ''
      },
      {
        label: '교통재해',
        value: ''
      },
      {
        label: '일반재해',
        value: ''
      },
      {
        label: '정기사망특약',
        value: ''
      }
    ]
  },
  {
    category: '의료실손',
    data: [
      {
        label: '질병입원의료비',
        value: ''
      },
      {
        label: '질병통원의료비',
        value: ''
      },
      {
        label: '상해입원의료비',
        value: ''
      },
      {
        label: '도수치료',
        value: ''
      },
      {
        label: '주사료',
        value: ''
      },
      {
        label: 'MRI/MRA',
        value: ''
      }
    ]
  },
  {
    category: '의료실손',
    data: [
      {
        label: '암',
        value: ''
      },
      {
        label: '항암방사선',
        value: ''
      },
      {
        label: '항암약물',
        value: ''
      },
      {
        label: '재해골절진단',
        value: ''
      }
    ]
  }
  ],
  [{
    category: '장해',
    data: [
      {
        label: '장해율 100%',
        value: ''
      },
      {
        label: '장해율 80%',
        value: ''
      },
      {
        label: '장해율 70%',
        value: ''
      },
      {
        label: '장해율 3%',
        value: ''
      },
      {
        label: '장해1급',
        value: ''
      },
      {
        label: '장해2급',
        value: ''
      },
      {
        label: '장해6급',
        value: ''
      }
    ]
  },
  {
    category: '수술',
    data: [
      {
        label: '중대한수술',
        value: '6848613'
      },
      {
        label: '1~3종 (최대값)',
        value: '6848613'
      },
      {
        label: '1~5종 (최대값)',
        value: '6848613'
      },
      {
        label: '암',
        value: '6848613'
      },
      {
        label: '특정질병',
        value: '6848613'
      }
    ]
  }

  ],
  [{
    category: '진단',
    data: [
      {
        label: '고액암',
        value: '6848613'
      },
      {
        label: '특정암',
        value: '6848613'
      },
      {
        label: '일반암',
        value: '6848613'
      },
      {
        label: '뇌출혈',
        value: '6848613'
      },
      {
        label: '뇌경색',
        value: '6848613'
      },
      {
        label: '급성심근경색',
        value: '6848613'
      },
      {
        label: '기타중대한질병',
        value: '6848613'
      },
      {
        label: '두번째CI',
        value: '6848613'
      },
      {
        label: '중중도B',
        value: '6848613'
      },
      {
        label: 'LTC',
        value: '6848613'
      }
    ]
  },
  {
    category: '입원',
    data: [
      {
        label: '암 입원',
        value: '6848613'
      },
      {
        label: '재해 입원',
        value: '6848613'
      },
      {
        label: '기타 질병',
        value: '6848613'
      },
      {
        label: '1일 입원',
        value: '6848613'
      }
    ]
  }
  ]

]
