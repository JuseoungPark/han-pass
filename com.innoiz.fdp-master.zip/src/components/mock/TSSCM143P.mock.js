export default [
  {
    name: '이주명',
    birthday: '1967-06-18',
    confirm: '2017-06-15 11:52:04',
    section: '승인',
    startday: '2019-06-15',
    endday: '2017-06-15',
    process: '3430 (CRM_마케팅동의_서면)'
  },
  {
    name: '이주명',
    birthday: '1967-06-18',
    confirm: '2017-06-15 11:52:04',
    section: '승인',
    startday: '2019-06-15',
    endday: '2017-06-15',
    process: '3430 (CRM_마케팅동의_서면)'
  }
]
