export const viewMemberMocks = [{
  idx: 1,
  ck: false,
  new: 'new',
  name: '리이주명',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'Y',
  info: '신계약증권발행',
  realtime: 'Y',
  about: '신계약',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 2,
  ck: false,
  new: 'new',
  name: '한현민',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '신계약 서류검증완료',
  realtime: 'Y',
  about: '신계약',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 3,
  ck: false,
  new: 'new',
  name: '한현민',
  birthDay: '1977-04-30',
  age: '55',
  customer: '관심',
  marketing: 'N',
  info: '해약',
  realtime: 'Y',
  about: '보유계약',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 4,
  ck: false,
  new: '',
  name: '김아랑랑',
  birthDay: '1977-04-30',
  age: '55',
  customer: '타인모집',
  marketing: 'N',
  info: '배당금문의/지급',
  realtime: 'Y',
  about: '콜센터',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 5,
  ck: false,
  new: '',
  name: '김미애애',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '연락처수정',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 6,
  ck: false,
  new: '',
  name: '서영우',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '변경 정정문의/처리',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 7,
  ck: false,
  new: '',
  name: '서영우',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '변경 정정문의/처리',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 8,
  ck: false,
  new: '',
  name: '서영우',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '변경 정정문의/처리',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 9,
  ck: false,
  new: '',
  name: '서영우',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '변경 정정문의/처리',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
},
{
  idx: 10,
  ck: false,
  new: '',
  name: '서영우',
  birthDay: '1977-04-30',
  age: '55',
  customer: '본인모집',
  marketing: 'N',
  info: '변경 정정문의/처리',
  realtime: 'Y',
  about: '고객정보',
  aboutdate: '2017-05-29',
  startdate: '2017-05-30',
  touchdate: '2017-05-29'
}

]

export const subMenus = [{
  name: '전체 고객',
  color: 'blue'
},
{
  name: '캠페인 고객',
  color: 'navy'
},
{
  name: '프리미엄 고객사랑 서비스',
  color: 'navy'
},
{
  name: 'VIP 서비스 신청',
  color: 'purple'
},
{
  name: '고객접촉 정보',
  color: 'purple',
  active: true
},
{
  name: '이벤트 고객',
  color: 'green'

},
{
  name: '수금인수고객',
  color: 'green'
},
{
  name: '관심고객',
  color: 'green'
},
{
  name: '정보동의활용현황',
  color: 'purple'
}]
