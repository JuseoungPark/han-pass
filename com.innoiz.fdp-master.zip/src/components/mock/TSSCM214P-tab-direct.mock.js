export default [
  {
    jobcode: '031359',
    job: '농부',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '대학생',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: '실손불가'
  },
  {
    jobcode: '093172',
    job: '미취학아동',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '어업관련 단순노무자',
    normal: 'D',
    injury: '비',
    admission: 'A',
    disaster: 'A',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '연근해 어업 종사자',
    normal: 'A',
    injury: '비',
    admission: 'A',
    disaster: 'A',
    showExpand: false,
    etc: '각 상품 예규 참고...'
  },
  {
    jobcode: '031359',
    job: '농부',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '대학생',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: '실손불가'
  },
  {
    jobcode: '093172',
    job: '미취학아동',
    normal: 'D',
    injury: '고',
    admission: 'C',
    disaster: 'C',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '어업관련 단순노무자',
    normal: 'D',
    injury: '비',
    admission: 'A',
    disaster: 'A',
    showExpand: false,
    etc: ''
  },
  {
    jobcode: '093172',
    job: '연근해 어업 종사자',
    normal: 'A',
    injury: '비',
    admission: 'A',
    disaster: 'A',
    showExpand: false,
    etc: '각 상품 예규 참고...'
  }
]
