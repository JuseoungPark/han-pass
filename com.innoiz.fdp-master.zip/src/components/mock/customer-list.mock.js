export const subMenus = [{
  name: '전체 고객',
  component: 'TSSCM203M'
},
{
  name: '캠페인 고객',
  component: 'TSSCM313M'
},
{
  name: '프리미엄 고객사랑 서비스',
  component: 'TSSCM304M'
},
{
  name: 'VIP 서비스 신청',
  component: 'TSSCM324M'
},
{
  name: '고객접촉 정보',
  component: 'TSSCM301M'
},
{
  name: '이벤트 고객',
  component: 'TSSCM215M'
},
{
  name: '수금인수고객',
  component: 'TSSCM322M'
},
{
  name: '관심고객',
  component: 'TSSCM317M'
},
{
  name: '정보활용동의 현황',
  component: 'TSSCM132M'
},
{
  name: '미승인 고객',
  component: 'TSSCM216M'
},
{
  name: '삭제예정 고객',
  component: 'TSSCM217M'
},
{
  name: '내 그룹',
  component: 'TSSCM251M'
}
]
