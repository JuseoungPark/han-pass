export const viewMemberMocks = [
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: '11'
  },
  {
    checked: false,
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: '31'
  },
  {
    checked: false,
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '여자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: '31'
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: '11'
  },
  {
    checked: false,
    name: '서영우',
    birthDay: '1997-04-30',
    gender: '남자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '이주명',
    birthDay: '1997-04-30',
    gender: '남자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '남자',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: true
  },
  {
    checked: false,
    name: '우리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    choose: '',
    phone: '010-1234-1234',
    customerType: '본인모집',
    consulting: false
  }

]
