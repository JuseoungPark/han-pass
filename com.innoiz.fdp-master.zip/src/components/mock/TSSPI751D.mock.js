export const viewMemberMocks1 = [
  {
    category: '취약금융소비자 해당여부 확인',
    data: [
      {
        index: 0,
        question: '취약금융 소비자에 해당합니까?',
        checkbox: true,
        choice: [
          {
            key: 1,
            label: '해당사항 없음'
          },
          {
            key: 2,
            label: '해당(65세이상)'
          },
          {
            key: 3,
            label: '해당(정신지체 장애 등)'
          }
        ]
      }
    ]
  },
  {
    category: '보험가입 목적',
    data: [
      {
        index: 1,
        question: '귀하가 가입하고자 하는 금융상품은 어떤 것입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '예금 ․ 적금'
          },
          {
            key: 2,
            label: '주식 ․ 채권 등 금융투자상품'
          },
          {
            key: 3,
            label: '일반보험'
          },
          {
            key: 4,
            label: '변액보험'
          }
        ]
      },
      {
        index: 2,
        question: '귀하가 변액보험을 가입하는 목적은 무엇입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '단기 재산 증식'
          },
          {
            key: 2,
            label: '장기 저축을 통한 목돈 마련'
          },
          {
            key: 3,
            label: '노후를 위한 연금자산 마련'
          },
          {
            key: 4,
            label: '위험에 대비한 가족의 보장자산 마련'
          }
        ]
      }
    ]
  },
  {
    category: '재산 상황',
    data: [
      {
        index: 3,
        question: '귀하의 월평균 소득은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '200만원 이하'
          },
          {
            key: 2,
            label: '500만원 이하'
          },
          {
            key: 3,
            label: '1,000만원 이하'
          },
          {
            key: 4,
            label: '1,000만원 초과'
          }
        ]
      },
      {
        index: 4,
        question: '귀하의 월평균 소득에서 보험료 지출이 차지하는 비중은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '10% 미만'
          },
          {
            key: 2,
            label: '10%~20%'
          },
          {
            key: 3,
            label: '20%~30%'
          },
          {
            key: 4,
            label: '30%~50%'
          },
          {
            key: 5,
            label: '50% 이상'
          }
        ]
      },
      {
        index: 5,
        question: '귀하가 보험료 재원으로 사용할 수 있는 순자산(자산-부채)은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '1천만원 이하'
          },
          {
            key: 2,
            label: '5천만원 이하'
          },
          {
            key: 3,
            label: '1억원 이하'
          },
          {
            key: 4,
            label: '1억원 초과'
          }
        ]
      }
    ]
  },
  {
    category: '보험료 납입능력',
    data: [
      {
        index: 6,
        question: '귀하의 현재 소득, 순자산 수준에서 보험료(월납 기준)로 \n추가 납부하실 수 있는 금액은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '10만원 이하'
          },
          {
            key: 2,
            label: '10～30만원'
          },
          {
            key: 3,
            label: '30～50만원'
          },
          {
            key: 4,
            label: '50～100만원'
          },
          {
            key: 5,
            label: '100만원 초과'
          }
        ]
      },
      {
        index: 7,
        question: '퇴직 등 향후 수입원 감소 등을 감안한 귀하의 보험료 납입 가능기간은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '3년 미만'
          },
          {
            key: 2,
            label: '7년 미만'
          },
          {
            key: 3,
            label: '10년 미만'
          },
          {
            key: 4,
            label: '20년 미만'
          },
          {
            key: 5,
            label: '20년 이상'
          }
        ]
      }
    ]
  },
  {
    category: '보험계약 유지능력',
    data: [
      {
        index: 8,
        question: '귀하께서 생각하시는 보험계약의 유지기간은 어느 정도 입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '7년 미만'
          },
          {
            key: 2,
            label: '7년～10년'
          },
          {
            key: 3,
            label: '10년~20년'
          },
          {
            key: 4,
            label: '20년~30년'
          },
          {
            key: 5,
            label: '30년 초과'
          }
        ]
      },
      {
        index: 9,
        question: '자녀결혼, 주택구입 등 자금수요로 보험계약을 10년이전에 중도해지할\n가능성은 어느 정도라고 예상하십니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '30% 미만'
          },
          {
            key: 2,
            label: '30%~50%'
          },
          {
            key: 3,
            label: '50%~70%'
          },
          {
            key: 4,
            label: '70%~90%'
          },
          {
            key: 5,
            label: '90% 이상'
          }
        ]
      }
    ]
  },
  {
    category: '투자경험',
    data: [
      {
        index: 10,
        question: '귀하의 펀드, 변액보험 등 금융투자상품 투자경험기간은 어느 정도입니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '투자경험 없음'
          },
          {
            key: 2,
            label: '6개월 미만'
          },
          {
            key: 3,
            label: '1년 미만'
          },
          {
            key: 4,
            label: '2년 미만'
          },
          {
            key: 5,
            label: '2년 이상'
          }
        ]
      },
      {
        index: 11,
        question: '귀하께서 가입해보신 경험이 있는 상품을 모두 골라주세요(복수선택 가능)',
        checkbox: true,
        choice: [
          {
            key: 1,
            label: '주식(관리종목, 투자위험종목),주식형 펀드(고수익 추구), 선물옵션, ELW 등'
          },
          {
            key: 2,
            label: '주식(일반종목),주식형 펀드(시장수익률 추구),ELS/DLS(원금비보장),채권(BBB-이하) 등'
          },
          {
            key: 3,
            label: '혼합형 펀드, CP/전단채(A4~A2),채권(BBB0~BBB+),ELS(원금일부보장) 등'
          },
          {
            key: 4,
            label: '채권형 펀드, 금융채, 채권(A-이상),ELB/DLB(원금보장),CP/전단채(A2+이상) 등'
          },
          {
            key: 5,
            label: '변액보험'
          },
          {
            key: 6,
            label: '투자경험 없음'
          }
        ]
      }
    ]
  },
  {
    category: '투자 성향',
    data: [
      {
        index: 12,
        question: '귀하께서는 투자하실때 원금 보존과 투자수익률 중 어느 쪽을 중요하게 생각하십니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '원금은 반드시 보존되어야 한다'
          },
          {
            key: 2,
            label: '원금 보존을 중요하게 생각한다'
          },
          {
            key: 3,
            label: '수익률이 어느 정도 되어야 한다'
          },
          {
            key: 4,
            label: '수익률을 중요시한다'
          }
        ]
      },
      {
        index: 13,
        question: '귀하께서는 투자 상품을 가입하실 때 어느 정도의 연간 수익률을 기대하십니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '3%이내'
          },
          {
            key: 2,
            label: '7%이내'
          },
          {
            key: 3,
            label: '10%이내'
          },
          {
            key: 4,
            label: '15%이내'
          },
          {
            key: 5,
            label: '15%초과'
          }
        ]
      },
      {
        index: 14,
        question: '귀하께서는 투자 수익률을 얻기 위해 어느 정도의 손실을 감내할 수 있습니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '어떠한 경우에도 손실이 나면 안된다'
          },
          {
            key: 2,
            label: '원금 기준 10%이내는 감수할 수 있다.'
          },
          {
            key: 3,
            label: '원금 기준 20%이내는 감수할 수 있다.'
          },
          {
            key: 4,
            label: '원금 기준 30%이내는 감수할 수 있다.'
          },
          {
            key: 5,
            label: '원금 기준 40%이내는 감수할 수 있다.'
          },
          {
            key: 6,
            label: '원금 기준 50%이내는 감수할 수 있다.'
          }
        ]
      },
      {
        index: 15,
        question: '귀하께서는 특별계정 펀드내 주식이나 주식형 상품의 비중을 어느 정도로 구성하고 싶으십니까?',
        checkbox: false,
        choice: [
          {
            key: 1,
            label: '5% 미만'
          },
          {
            key: 2,
            label: '5%~10%'
          },
          {
            key: 3,
            label: '10%~20%'
          },
          {
            key: 4,
            label: '20%~50%'
          },
          {
            key: 5,
            label: '50% 이상'
          }
        ]
      }
    ]
  }
]
