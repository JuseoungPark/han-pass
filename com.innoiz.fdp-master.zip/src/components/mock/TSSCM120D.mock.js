export default [
  {
    idx: '1',
    name: '김하늘이',
    data1: 'Y',
    data2: 'Y',
    data3: '자녀',
    data4: '010-1234-5678',
    data5: '1999-09-09',
    repYn: [{
      key: '2',
      label: 'Y'
    }],
    calories: '990712-******',
    forienYn: [{
      key: '1',
      label: 'N'
    }],
    rel: {
      key: '1',
      label: '본인'
    },
    birth: '2017-09-07',
    job: '총무사무원',
    phone1: {
      key: '010',
      label: '010'
    },
    phone2: '1232-1234',
    baby: 'N'
  },
  {
    idx: '2',
    name: '김하늘삼',
    data1: 'Y',
    data2: 'Y',
    data3: '자녀',
    data4: '010-1234-5678',
    data5: '1999-09-09',
    repYn: [{
      key: '1',
      label: 'N'
    }],
    calories: '990712-******',
    forienYn: [{
      key: '1',
      label: 'N'
    }],
    rel: {
      key: '2',
      label: '자녀'
    },
    birth: '2018-01-02',
    job: '총무사무원',
    phone1: {
      key: '010',
      label: '010'
    },
    phone2: '2222-1234',
    baby: 'N'
  }
]
