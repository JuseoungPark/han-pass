export const productConfigList = [{
  name: '최저연금보증형 변액연금...',
  monthPrice: '50,000',
  canDelete: true,
  isRecommendProduct: true,
  details: [
    [
      [{
        value: 32,
        percentage: 1.5
      },
      {
        value: 36,
        percentage: 3
      },
      {
        value: 40,
        percentage: 4.5
      }
      ],
      [{
        value: 32,
        percentage: 1.5
      },
      {
        value: 36,
        percentage: 3
      },
      {
        value: 40,
        percentage: 4.5
      }
      ],
      '-',
      '-'
    ]
  ]
},
{
  name: '파워즉시연금 1.0',
  monthPrice: '67,000',
  color: 'pink',
  isRecommendProduct: true,
  canDelete: true,
  details: [
    ['32', '-', '-', '-']
  ]
},
{
  name: '파워즉시연금 1.0',
  monthPrice: '67,000',
  color: 'pink',
  isRecommendProduct: true,
  canDelete: true,
  details: [
    ['32', '-', '-', '-']
  ]
}

]

export const productList = [{
  name: '최저연금보증형 변액연금...',
  monthPrice: '50,000',
  color: 'pink',
  hasProduct: true,
  canDelete: true,
  details: [
    [
      [{
        value: 32,
        percentage: 1.5
      },
      {
        value: 36,
        percentage: 3
      },
      {
        value: 40,
        percentage: 4.5
      }
      ],
      [{
        value: 32,
        percentage: 1.5
      },
      {
        value: 36,
        percentage: 3
      },
      {
        value: 40,
        percentage: 4.5
      }
      ],
      '-',
      '-'
    ]
  ]
},
{
  name: '파워즉시연금 1.0',
  monthPrice: '67,000',
  hasProduct: true,
  canDelete: true,
  details: [
    ['32', '-', '-', '-']
  ]
},
{
  name: '국민연금',
  monthPrice: '50,000',
  hasProduct: true,
  isOtherProduct: true,
  details: [
    ['32', '212', '-', '-']
  ]
},
{
  name: '퇴직연금',
  monthPrice: '50,000',
  hasProduct: true,
  isOtherProduct: true,
  details: [
    ['32', '-', '116', '-']
  ]
}
]
