export const mockData = [
  {
    name: '유사암진단비(경계성종양)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '두번보장CI특약(갱신형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보암진단특약(갱신형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보중환자실입원특약(갱신형)(1형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '유사암진단비(경계성종양)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '두번보장CI특약(갱신형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보암진단특약(갱신형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보중환자실입원특약(갱신형)(1형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보중환자실입원특약(갱신형)(1형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  },
  {
    name: '교보중환자실입원특약(갱신형)(1형)',
    type: '기본',
    ju: '주피',
    amount: '3000',
    maturity: '',
    dateLife: false
  }
]
