export const tableData = [
  {
    title: '가족보장자산',
    columns: [
      {
        title: '사망',
        data: [{
          type: '암사망',
          amount: '555,555',
          requireAmount: '555,555',
          overAmount: '-500,000'
        },
        {
          type: '일반사망',
          amount: '55,871',
          requireAmount: '10,000',
          overAmount: '+450,871'
        },
        {
          type: '교통재해',
          amount: '70,971',
          requireAmount: '10,000',
          overAmount: '+60,971'
        },
        {
          type: '교통재해',
          amount: '5,000',
          requireAmount: '10,000',
          overAmount: '0'
        }
        ]
      }
    ]
  },
  {
    title: '생활보장자산',
    columns: [
      {
        title: '재해 장애',
        data: [
          {
            type: '장해율 100%',
            amount: '10,000',
            requireAmount: '1,000',
            overAmount: '+9,000'
          },
          {
            type: '장해율 70%',
            amount: '10,000',
            requireAmount: '800',
            overAmount: '+2,000'
          },
          {
            type: '장해율 30%',
            amount: '10,000',
            requireAmount: '700',
            overAmount: '+2,000'
          },
          {
            type: '장해1급',
            amount: '10,000',
            requireAmount: '600',
            overAmount: '+2,000'
          },
          {
            type: '장해2급',
            amount: '10,000',
            requireAmount: '800',
            overAmount: '-5,000'
          },
          {
            type: '장해5급',
            amount: '10,000',
            requireAmount: '900',
            overAmount: '-5,000'
          }
        ]
      }]
  },
  {
    title: '의료보장자산',
    columnTitle: '의료 실손',
    columns: [
      {
        title: '의료 실손',
        data: [
          {
            type: '질병입원의료비',
            amount: '10,000',
            requireAmount: '5,000',
            overAmount: '+2,000'
          },
          {
            type: '질병통원의료비',
            amount: '10,000',
            requireAmount: '5,000',
            overAmount: '+2,000'
          },
          {
            type: '질병처방조재비',
            amount: '10,000',
            requireAmount: '5,000',
            overAmount: '+2,000'
          },
          {
            type: '상해입원의료비',
            amount: '10,000',
            requireAmount: '5,000',
            overAmount: '+2,000'
          }
        ]
      }]
  }
]
