export const viewMemberMocks = [{
  idx: 1,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 2,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 3,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 4,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 5,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 6,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
},
{
  idx: 7,
  ck: false,
  name: '이주명',
  product01: '125',
  product02: '225',
  product03: '100',
  product04: '125',
  product05: '125',
  product06: '5,000',
  product07: '125',
  product08: '125',
  product09: '125',
  product10: '125'
}
]

export const subMenus = [{
  name: '전체 고객',
  color: 'blue'
},
{
  name: '캠페인 고객',
  color: 'navy',
  active: true
},
{
  name: '프리미엄 고객사랑 서비스',
  color: 'navy'
},
{
  name: 'VIP 서비스 신청',
  color: 'purple'
},
{
  name: '고객접촉 정보',
  color: 'purple'
},
{
  name: '이벤트 고객',
  color: 'green'

},
{
  name: '수금인수고객',
  color: 'green'
},
{
  name: '관심고객',
  color: 'green'
},
{
  name: '정보동의활용현황',
  color: 'purple'
}]
