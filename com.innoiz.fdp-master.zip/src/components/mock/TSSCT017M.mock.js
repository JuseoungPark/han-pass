export const mockData = [{
  company: '삼성생명',
  productName: '파워즉시연금 1.0',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '380 만원'
},
{
  company: '삼성생명',
  productName: '연금저축삼성골드연금보험(1.1)',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '240 만원'
},
{
  company: '삼성생명',
  productName: '국민연금',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '540 만원'
},
{
  company: '-',
  productName: '국민연금',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '450 만원'
},
{
  company: '-',
  productName: '국민연금',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '450 만원'
},
{
  company: '-',
  productName: '국민연금',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '450 만원'
}
]
export const addProduct = {
  company: '삼성생명 (연금전환)',
  productName: '최저연금보증형 변액연금보험',
  contactDate: '1997-06',
  year: '10년',
  amount: '100,000,000 원',
  pension: '450 만원'
}
