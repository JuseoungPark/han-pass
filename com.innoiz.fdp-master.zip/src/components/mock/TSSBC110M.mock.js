export const viewMenuMocks = [
  {
    label: '고객',
    isGo: true,
    menu: [{
      label: '고객 기본',
      menu: [
        {
          label: '고객',
          isNew: true
        }, {
          label: '고객등록동의',
          isNew: true
        }, {
          label: '전체고객목록',
          isNew: true
        }, {
          label: '캠페인고객',
          isNew: true
        }, {
          label: '프리미엄고객 <br />사랑 서비스',
          isNew: true
        }, {
          label: '스마트신인고객 <br />사랑 서비스',
          isNew: true
        }, {
          label: '군제휴DB고객',
          isNew: true
        }, {
          label: 'VIP서비스신청',
          isNew: true
        }, {
          label: '고객접촉정보',
          isNew: true
        }, {
          label: '이벤트고객',
          isNew: true
        }, {
          label: '수금인수고객',
          isNew: true
        }, {
          label: '관심고객',
          isNew: true
        }, {
          label: '정보활용동의 현황',
          isNew: true
        }, {
          label: '미승인 고객',
          isNew: true
        }, {
          label: '삭제예정고객',
          isNew: true
        }, {
          label: '내 그룹',
          isNew: true
        }, {
          label: '대출가망고객',
          isNew: false
        }, {
          label: '수익증권추천고객',
          isNew: false
        }]
    }, {
      label: '단체',
      menu: [{
        label: '단체등록/검색'
      }, {
        label: '보유단체조회'
      }, {
        label: '피보험자변경'
      }]
    }]
  },
  {
    label: '컨설팅',
    isGo: true,
    menu: [{
      label: '컨설팅',
      menu: [
        {
          label: '컨설팅',
          isNew: true
        }, {
          label: '통합자산분석',
          isNew: true
        }, {
          label: '라이프분석',
          isNew: true
        }]
    }, {
      label: '컨설팅TOOL',
      menu: [
        {
          label: '연금계산기',
          isNew: true
        }, {
          label: '상속계산기',
          isNew: true
        }, {
          label: '가족력',
          isNew: false
        }, {
          label: '건강게임',
          isNew: false
        }]
    }]
  },
  {
    label: '설계',
    isGo: true,
    menu: [{
      label: '상품설계/관리',
      menu: [
        {
          label: '개인가입설계',
          isNew: false
        }, {
          label: '설계진행현황',
          isNew: true
        }, {
          label: '청약서발행현황',
          isNew: true
        }, {
          label: '전자서명(완료)',
          isNew: true
        }, {
          label: '전자서명(진행중)',
          isNew: true
        }, {
          label: '전자청약',
          isNew: true
        }, {
          label: '신계약진행현황',
          isNew: true
        }, {
          label: '적합성진단 (모바일)',
          isNew: false
        }, {
          label: '적합성진단(지류)',
          isNew: false
        }, {
          label: 'My플랜관리',
          isNew: false
        }]
    }, {
      label: '재발행',
      menu: [
        {
          label: '상설(제안용) 재발행',
          isNew: false
        }, {
          label: '상품설명서 재발행',
          isNew: false
        }, {
          label: '비교안내문 재발행',
          isNew: false
        }, {
          label: '청약서 재발행',
          isNew: false
        }]
    }]
  },
  {
    label: '활동',
    isGo: true,
    menu: [{
      label: '활동계획',
      menu: [
        {
          label: '성공리스트'
        }, {
          label: 'E-노트'
        }, {
          label: '육성코치활동입력'
        }]
    }, {
      label: '고객안내자료',
      menu: [{
        label: '안내자료'
      }, {
        label: '변액펀드자료/동영상'
      }, {
        label: '상품제안'
      }, {
        label: '인생금융바로알기'
      }, {
        label: '상속대중화'
      }, {
        label: '알토란'
      }, {
        label: '컨설팅노트'
      }, {
        label: '상품설계플러스'
      }]
    }, {
      label: '이벤트',
      menu: [{
        label: '행복 폴폴 이벤트'
      }, {
        label: '2019 한글자운세'
      }]
    }, {
      label: '특가몰',
      menu: [{
        label: '롯데할인몰'
      }, {
        label: '에스티엠몰'
      }]
    }, {
      label: '리크루팅',
      menu: [ {
        label: '리크루팅 동영상'
      }, {
        label: '리크루팅 동영상(복합)'
      }, {
        label: '리크루팅 안내'
      }, {
        label: '리크루팅(주부用)'
      }, {
        label: '리크루팅 <br>(경력단절 주부用)'
      }, {
        label: '리크루팅 (유사세일즈用)'
      }, {
        label: '리크루팅 (有경력用)'
      }]
    }]
  },
  {
    label: '계약',
    isGo: true,
    menu: [{
      label: '계약관리',
      menu: [{
        label: '보유계약조회'
      }, {
        label: '계약상세조회'
      }, {
        label: '자동이체 미이체계약'
      }, {
        label: '실효계약'
      }, {
        label: '휴면보험금'
      }, {
        label: '우량체 미계약변경'
      }, {
        label: '배당금안내'
      }, {
        label: '수금체크 명세'
      }]
    }, {
      label: '거래업무',
      menu: [{
        label: '보험거래'
      }, {
        label: '융자거래'
      }]
    }]
  },
  {
    label: '기타',
    isGo: true,
    menu: [{
      label: ' ',
      menu: [{
        label: '태블릿역량테스트'
      }, {
        label: '교육ON'
      }, {
        label: '터치ON'
      }, {
        label: '지식ON'
      }, {
        label: '게시판 (FC새소식)'
      }, {
        label: '설문조사'
      }, {
        label: '미니암보험'
      }, {
        label: '태블릿생활백서'
      }]
    }]
  },
  {
    label: '관리자',
    menu: [{
      label: ' ',
      menu: [{
        label: '미세코칭',
        isPinOn: false
      }, {
        label: '적합성승인',
        isPinOn: false
      }, {
        label: '발행서버변경',
        isPinOff: false
      }, {
        label: '육성코치활동',
        isPinOff: false
      }]
    }]
  }
]

export const searchMenuMocks = [{
  label: '컨설팅',
  isGo: true,
  menu: [{
    label: '컨설팅TOOL',
    menu: [{
      label: '금융<span style="color:#fe886a;">계산</span>기'
    }, {
      label: '세금<span style="color:#fe886a;">계산</span>기'
    }, {
      label: '평생소득  &nbsp;<span style="color:#fe886a;">계산</span>기'
    }]
  }]
},
{
  label: '활동',
  isGo: true,
  menu: [{
    label: '활동계획',
    menu: [{
      label: '수수료 &nbsp;<span style="color:#fe886a;">계산</span>'
    }]
  }]
}]

export const popMenuMocks = [{
  label: '최근사용화면',
  menu: [{
    menu: [{
      label: '구비서류검색',
      isPinOn: true
    }, {
      label: '게시판',
      isPinOn: true
    }, {
      label: 'VIP서비스 신청',
      isPinOn: false

    }, {
      label: '프리미엄 고객 <br />사랑 서비스',
      isPinOn: false
    }, {
      label: '이달의 명세서',
      isPinOn: false
    }]
  }]
}]
