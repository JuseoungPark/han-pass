export const viewMemberMocks = [
  {
    name: '이이주명',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '일반'
    }
  },
  {
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '2017-06-12',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '일반'
    }
  },
  {
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '2017-06-12',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김영미',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '서영우',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '차준환',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '이주명',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '일반'
    }
  },
  {
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '2017-06-12',
    hasCustomerCard: true,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '일반'
    }
  },
  {
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '2017-06-12',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '김영미',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '서영우',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  },
  {
    name: '차준환',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    recentDate: '',
    hasCustomerCard: false,
    contractNumber: '123456789',
    collect: {
      date: '2017-05-31',
      type: '탈락'
    }
  }
]

export const subMenus = [{
  name: '전체 고객',
  color: 'blue'
},
{
  name: '캠페인 고객',
  color: 'navy'
},
{
  name: '프리미엄 고객사랑 서비스',
  color: 'navy'
},
{
  name: 'VIP 서비스 신청',
  color: 'purple'
},
{
  name: '고객접촉 정보',
  color: 'purple'
},
{
  name: '이벤트 고객',
  color: 'green'

},
{
  name: '수금인수고객',
  color: 'green',
  active: true
},
{
  name: '관심고객',
  color: 'green'
},
{
  name: '정보동의활용현황',
  color: 'purple'
}]
