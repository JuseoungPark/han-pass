export const viewMemberMocks = [
  {
    idx: 1,
    ck: false,
    name: '리이주명',
    birthDay: '1997-04-30',
    age: '30',
    event: '계약월 도래',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 2,
    ck: false,
    name: '한현민',
    birthDay: '1997-04-30',
    age: '63',
    event: '생일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 3,
    ck: false,
    name: '김아랑',
    birthDay: '1997-04-30',
    age: '35',
    event: '상령일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 4,
    ck: false,
    name: '최민정',
    birthDay: '1997-04-30',
    age: '44',
    event: '계약기념일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 5,
    ck: false,
    name: '김미애',
    birthDay: '1997-04-30',
    age: '47',
    event: '계약월 도래',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 6,
    ck: false,
    name: '김영미',
    birthDay: '1997-04-30',
    age: '63',
    event: '생일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 7,
    ck: false,
    name: '서영우',
    birthDay: '1997-04-30',
    age: '47',
    event: '계약월 도래',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 8,
    ck: false,
    name: '최민정',
    birthDay: '1997-04-30',
    age: '44',
    event: '계약기념일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 9,
    ck: false,
    name: '김미애',
    birthDay: '1997-04-30',
    age: '47',
    event: '계약월 도래',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 10,
    ck: false,
    name: '김영미',
    birthDay: '1997-04-30',
    age: '63',
    event: '생일',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  },
  {
    idx: 11,
    ck: false,
    name: '서영우',
    birthDay: '1997-04-30',
    age: '47',
    event: '계약월 도래',
    anniversary: '2015-05-31',
    phone: '(핸)010-1234-1234',
    active: '2015-05-31'
  }
]
