export const viewMemberMocks = [
  {
    checked: false,
    name: '리이주명',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: false,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '리이주명'
  },
  {
    checked: false,
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: false,
    marketing: false,
    agree: 'Y',
    customerType: '임시모집',
    mainCustomer: '한현민'
  },
  {
    checked: false,
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '임시',
    mainCustomer: '김아랑'
  },
  {
    checked: false,
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '가망',
    mainCustomer: '최민정'
  },
  {
    checked: false,
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '관심',
    mainCustomer: '김미애'
  },
  {
    checked: false,
    name: '김영미',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '김영미'
  },
  {
    checked: false,
    name: '서영우',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '임시모집',
    mainCustomer: '서영우'
  },
  {
    checked: false,
    name: '차준환',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '관심',
    mainCustomer: '차준환'
  },
  {
    checked: false,
    name: '이주명',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: false,
    agree: 'Y',
    customerType: '가망',
    mainCustomer: '이주명'
  },
  {
    checked: false,
    name: '한현민',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: false,
    marketing: false,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '한현민'
  },
  {
    checked: false,
    name: '김아랑',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '김아랑'
  },
  {
    checked: false,
    name: '최민정',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '최민정'
  },
  {
    checked: false,
    name: '김미애',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '김미애'
  },
  {
    checked: false,
    name: '김영미',
    birthDay: '1997-04-30',
    gender: '여',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '김영미'
  },
  {
    checked: false,
    name: '서영우',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '서영우'
  },
  {
    checked: false,
    name: '차준환',
    birthDay: '1997-04-30',
    gender: '남',
    phone: '010-1234-1234',
    consulting: true,
    marketing: true,
    agree: 'Y',
    customerType: '본인모집',
    mainCustomer: '차준환'
  }
]

export const fieldNames = {
  checked: '',
  name: '고객명',
  birthDay: '생년월일',
  age: '나이',
  event: '이벤트',
  memorialDate: '기념일',
  phone: '휴대폰번호',
  recentDate: '최근활동일'
}

export const subMenus = [{
  name: '전체 고객',
  color: 'blue',
  active: true
},
{
  name: '캠페인 고객',
  color: 'navy'
},
{
  name: '프리미엄 고객사랑 서비스',
  color: 'navy'
},
{
  name: 'VIP 서비스 신청',
  color: 'purple'
},
{
  name: '고객접촉 정보',
  color: 'purple'
},
{
  name: '이벤트 고객',
  color: 'green'

},
{
  name: '수금인수고객',
  color: 'green'
},
{
  name: '관심고객',
  color: 'green'
},
{
  name: '정보동의활용현황',
  color: 'purple'
}]
