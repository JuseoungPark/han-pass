export const viewMemberMocks = [
  {
    key: 1,
    question: '설문 테스트 1번 질문입니다.',
    choiceQuestion: true,
    choice: [
      {
        key: 1,
        label: '1번답변',
        inputText: false
      },
      {
        key: 2,
        label: '2번답변',
        inputText: false
      },
      {
        key: 3,
        label: '3번답변',
        inputText: false
      },
      {
        key: 4,
        label: '4번답변',
        inputText: true
      }
    ]
  },
  {
    key: 2,
    question: '설문 테스트 2번 질문입니다.',
    choiceQuestion: false
  },
  {
    key: 3,
    question: '설문 테스트 3번 질문입니다.',
    choiceQuestion: true,
    choice: [
      {
        key: 1,
        label: '1번답변',
        inputText: false
      },
      {
        key: 2,
        label: '2번답변',
        inputText: false
      },
      {
        key: 3,
        label: '3번답변',
        inputText: false
      },
      {
        key: 4,
        label: '4번답변',
        inputText: false
      }
    ]
  }
]
