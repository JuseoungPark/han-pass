export default [
  {
    key: 1,
    name: '김바가',
    data4: '78',
    date: '1977-04-30',
    gander: '남'
  },
  {
    key: 2,
    name: '김바나',
    data4: '54',
    date: '1956-07-23',
    gander: '여'
  },
  {
    key: 3,
    name: '김바다',
    data4: '49',
    date: '1987-01-03',
    gander: '남'
  },
  {
    key: 4,
    name: '김바라',
    data4: '57',
    date: '1990-02-07',
    gander: '여'
  },
  {
    key: 5,
    name: '김바바',
    data4: '50',
    date: '1972-11-25',
    gander: '남'
  },
  {
    key: 6,
    name: '김바라',
    data4: '59',
    date: '1977-04-30',
    gander: '남'
  },
  {
    key: 7,
    name: '김바라',
    data4: '49',
    date: '1987-01-03',
    gander: '남'
  },
  {
    key: 8,
    name: '김바사',
    data4: '49',
    date: '1987-01-03',
    gander: '남'
  },
  {
    key: 9,
    name: '김바아',
    data4: '49',
    date: '1987-01-03',
    gander: '남'
  }
]
