export const viewMemberMocks = [
  {
    name: '김삼성성(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '2017-05-17',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '홍진수(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김바다(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: ''
  },
  {
    name: '김병엽(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: ''
  },
  {
    name: '김진아(0007810650)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김준희(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: ''
  },
  {
    name: '배준호(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: ''
  },
  {
    name: '손아영(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: ''
  },
  {
    name: '손주연(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김삼성성(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '2017-05-17',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '홍진수(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김바다(0001364571)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김병엽(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김진아(0007810650)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: '',
    masterSign: ''
  },
  {
    name: '김준희(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: 'Y'
  },
  {
    name: '배준호(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: 'Y'
  },
  {
    name: '손아영(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: 'Y'
  },
  {
    name: '손주연(0007810653)',
    name2: '김삼성성(0001364571)',
    date: '1997-04-30',
    time: '5시간',
    fellow: '3회',
    application: 'Y',
    newMemberSign: 'Y',
    masterSign: 'Y'
  }
]
