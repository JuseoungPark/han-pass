export default [
  {
    id: '1',
    name: '손평국',
    birthDay: '1997-04-30',
    age: '37',
    me: '본인',
    consulting: false,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '2',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '3',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '4',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '5',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '6',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '7',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '8',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '9',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  },
  {
    id: '10',
    name: '홍길동',
    birthDay: '1997-04-30',
    age: '29',
    me: '본인',
    consulting: true,
    marketing: false,
    hasCustomerCard: '기존'
  }

]
