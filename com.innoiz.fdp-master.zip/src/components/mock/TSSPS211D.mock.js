export const viewMemberMocks1 = [{
  date: '2017-04-30',
  contractor: '이주명명',
  insuredPerson: '이주명명',
  item: '6월 소외고객 비대면6월 소외고객 비대면6월 소외고객 비대면6월 소외고객 비대면',
  cost: '123,230,000',
  aeus: '',
  status: '',
  date2: '',
  step: '설계저장 >'
},
{
  date: '2017-07-23',
  contractor: '한현민',
  insuredPerson: '한현민',
  item: '소액질병치료비특소액질병치료비특',
  cost: '123,230,000',
  aeus: '비대상',
  status: '정상',
  date2: '2017-07-23',
  step: '설계저장 >'
},
{
  date: '2017-01-03',
  contractor: '김아랑',
  insuredPerson: '김아랑',
  item: '교통재해사망특약교통재해사망특약',
  cost: '16,230,000',
  aeus: '입력',
  status: '비정상',
  date2: '2017-07-23',
  step: '상설(제안용)<br>발행 >'
},
{
  date: '2017-02-07',
  contractor: '최민정',
  insuredPerson: '최민정',
  item: '암사망특약D(무배암사망특약D(무',
  cost: '16,230,000',
  aeus: '비대상',
  status: '발행불가',
  date2: '2017-07-23',
  step: '상설(제안용)<br>발행 >'
},
{
  date: '2017-11-25',
  contractor: '김미애',
  insuredPerson: '김미애',
  item: '질병고도장애(1,2질병고도장애(1,2',
  cost: '16,230,000',
  aeus: 'AEUS입력',
  status: '정상',
  date2: '2017-07-23',
  step: '상설(제안용)<br>발행 >'
},
{
  date: '2017-12-12',
  contractor: '김영미',
  insuredPerson: '김영미',
  item: '비대항암방사선,약물항암방사선,약물',
  cost: '16,230,000',
  aeus: '비대상',
  status: '',
  date2: '2017-07-23',
  step: '설계저장 >'
},
{
  date: '2017-07-28',
  contractor: '서영우',
  insuredPerson: '서영우',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '정상',
  date2: '2017-07-23',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '정상',
  date2: '2017-07-23',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '정상',
  date2: '2017-07-23',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '',
  date2: '',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '',
  date2: '',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '',
  date2: '',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '',
  date2: '',
  step: '설계저장 >'
},
{
  date: '2017-04-30',
  contractor: '이주명',
  insuredPerson: '만기',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '입력',
  status: '',
  date2: '',
  step: '설계저장 >'
}]

export const viewMemberMocks2 = [{
  date: '2017-04-30',
  contractor: '이주명명',
  insuredPerson: '이주명명',
  item: '6월 소외고객 비대면6월 소외고객 비대면6월 소외고객 비대면6월 소외고객 비대면',
  cost: '123,230,000',
  aeus: '입력',
  step: '청약서<br>발행 >'
},
{
  date: '2017-07-23',
  contractor: '한현민',
  insuredPerson: '한현민',
  item: '소액질병치료비특소액질병치료비특',
  cost: '123,230,000',
  aeus: '비대상',
  step: '서명중단 >'
},
{
  date: '2017-01-03',
  contractor: '김아랑',
  insuredPerson: '김아랑',
  item: '교통재해사망특약교통재해사망특약',
  cost: '16,230,000',
  aeus: '입력',
  step: '계약자 서명'
},
{
  date: '2017-02-07',
  contractor: '최민정',
  insuredPerson: '최민정',
  item: '암사망특약D(무배암사망특약D(무',
  cost: '16,230,000',
  aeus: '비대상',
  step: '청약서<br>발행 >'
},
{
  date: '2017-11-25',
  contractor: '김미애',
  insuredPerson: '김미애',
  item: '질병고도장애(1,2질병고도장애(1,2',
  cost: '16,230,000',
  aeus: '입력',
  step: '전송실패 >'
},
{
  date: '2017-12-12',
  contractor: '김영미',
  insuredPerson: '김영미',
  item: '비대항암방사선,약물항암방사선,약물',
  cost: '16,230,000',
  aeus: '비대상',
  step: '전송실패 >'
},
{
  date: '2017-07-28',
  contractor: '서영우',
  insuredPerson: '서영우',
  item: '6월 소외고객 비대6월 소외고객 비대',
  cost: '16,230,000',
  aeus: '비대상',
  step: '피보험자 서명'
},
{
  date: '2017-03-18',
  contractor: '차준환',
  insuredPerson: '차준환',
  item: '트리플재해보장특약',
  cost: '230,000',
  aeus: '입력',
  step: '청약서<br>발행 >'
}]
