export const events = [
  {
    checked: false,
    textContent: '본인결혼',
    icon: '1'
  },
  {
    checked: false,
    textContent: '자녀학자금',
    icon: '2'
  },
  {
    checked: false,
    textContent: '자녀결혼',
    icon: '3'
  },
  {
    checked: false,
    textContent: '유학연수',
    icon: '4'
  },
  {
    checked: false,
    textContent: '주택구입',
    icon: '5'
  },
  {
    checked: false,
    textContent: '차량구입',
    icon: '6'
  },
  {
    checked: false,
    textContent: '여가취미',
    icon: '7'
  },
  {
    checked: false,
    textContent: '자기계발',
    icon: '8'
  },
  {
    checked: false,
    textContent: '가족생활비',
    icon: '9'
  },
  {
    checked: false,
    textContent: '간병비용',
    icon: '10'
  },
  {
    checked: false,
    textContent: '건강검진',
    icon: '11'
  },
  {
    checked: false,
    textContent: '기부',
    icon: '12'
  },
  {
    checked: false,
    textContent: '부모봉양',
    icon: '13'
  },
  {
    checked: false,
    textContent: '부채상환',
    icon: '14'
  },
  {
    checked: false,
    textContent: '비급여치료',
    icon: '15'
  },
  {
    checked: false,
    textContent: '상속/증여세',
    icon: '16'
  },
  {
    checked: false,
    textContent: '요양시설',
    icon: '17'
  },
  {
    checked: false,
    textContent: '자녀계획',
    icon: '18'
  },
  {
    checked: false,
    textContent: '자녀유학',
    icon: '19'
  },
  {
    checked: false,
    textContent: '재활치료',
    icon: '20'
  },
  {
    checked: false,
    textContent: '해외여행',
    icon: '21'
  },
  {
    checked: false,
    textContent: '형제부양',
    icon: '22'
  },
  {
    checked: false,
    textContent: '질병',
    icon: '23'
  },
  {
    checked: false,
    textContent: '사망',
    icon: '24'
  }
]
