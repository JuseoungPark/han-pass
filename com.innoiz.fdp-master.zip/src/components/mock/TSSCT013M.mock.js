export const productList2 = [
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  },
  {
    name: 'NEW통합나이에딱맞는CI보험1.0 (15년납)',
    price: '135,280'
  }
]
