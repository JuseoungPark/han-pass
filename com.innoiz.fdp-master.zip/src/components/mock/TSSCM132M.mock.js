
export const viewMemberMocks = [
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '동의서',
    agreeItem: '필수컨설팅',
    marketing: '',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '한현민',
    birthDay: '1997-04-30',
    mainCustomer: '한현민',
    connection: '본인',
    agreeRoute: '휴대폰',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '김아랑',
    birthDay: '1997-04-30',
    mainCustomer: '김아랑',
    connection: '본인',
    agreeRoute: '동의서스마트CRM',
    agreeItem: '마케팅',
    marketing: '전화,문자,이메일,우편',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '최민정',
    birthDay: '1997-04-30',
    mainCustomer: '최민정',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '김미애',
    birthDay: '1997-04-30',
    mainCustomer: '김미애',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '김영미',
    birthDay: '1997-04-30',
    mainCustomer: '김영미',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '서영우',
    birthDay: '1997-04-30',
    mainCustomer: '서영우',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '차준환',
    birthDay: '1997-04-30',
    mainCustomer: '차준환',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '이주명',
    birthDay: '1997-04-30',
    mainCustomer: '이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '리이주명',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  },
  {
    consultant: '이순원',
    name: '마지막',
    birthDay: '1997-04-30',
    mainCustomer: '리이주명',
    connection: '본인',
    agreeRoute: '신용카드스마트CRM',
    agreeItem: '마케팅',
    marketing: '이메일',
    confirmName: '최진석',
    confirmDate: '2017-06-15',
    endDate: '2017-06-15'
  }
]

export const subMenus = [
  {
    name: '전체 고객',
    color: 'blue'
  },
  {
    name: '캠페인 고객',
    color: 'navy'
  },
  {
    name: '프리미엄 고객사랑 서비스',
    color: 'navy'
  },
  {
    name: 'VIP 서비스 신청',
    color: 'purple'
  },
  {
    name: '고객접촉 정보',
    color: 'purple'
  },
  {
    name: '이벤트 고객',
    color: 'green'

  },
  {
    name: '수금인수고객',
    color: 'green'
  },
  {
    name: '관심고객',
    color: 'green'
  },
  {
    name: '정보동의활용현황',
    color: 'purple',
    active: true
  },
  {
    name: '미승인 고객',
    color: 'purple'
  },
  {
    name: '삭제예정 고객',
    color: 'purple'
  },
  {
    name: '내 그룹',
    color: 'purple'
  }
]
