export const excludeProductList = [
  {
    name: '최저연금보증형 변액연금...',
    monthPrice: '50,000',
    hasProduct: true
  },
  {
    name: '파워즉시연금 1.0',
    monthPrice: '67,000',
    hasProduct: true

  }
]

export const productList = [
  {
    name: '최저연금보증형 변액연금...',
    monthPrice: '50,000',
    isRecommendProduct: true
  },
  {
    name: '파워즉시연금 1.0',
    monthPrice: '67,000',
    isRecommendProduct: true

  }
]
