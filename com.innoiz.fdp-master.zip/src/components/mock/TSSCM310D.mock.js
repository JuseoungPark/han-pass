export const viewMemberMocks = [
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  },
  {
    name: '이주영',
    customer: 'C',
    type: '만기',
    applydivision: '신청',
    contractdate: '2017-06-01',
    productname: '암보험(갱신형, 무배당)',
    phone: '000-0000-000',
    emarketing: '2017-04-16',
    visit: '2017-04-16',
    consent: '2017-04-16',
    hypothesis: '2017-04-16',
    analysis: '2017-04-16',
    hpphone: '000-0000-0000'
  }
]

export const subMenus = [
  {
    name: '전체 고객',
    color: 'blue'
  },
  {
    name: '캠페인 고객',
    color: 'navy'
  },
  {
    name: '프리미엄 고객사랑 서비스',
    color: 'navy',
    active: true
  },
  {
    name: 'VIP 서비스 신청',
    color: 'purple'
  },
  {
    name: '고객접촉 정보',
    color: 'purple'
  },
  {
    name: '이벤트 고객',
    color: 'green'

  },
  {
    name: '수금인수고객',
    color: 'green'
  },
  {
    name: '관심고객',
    color: 'green'
  },
  {
    name: '정보동의활용현황',
    color: 'purple'
  },
  {
    name: '미승인 고객',
    color: 'purple'
  },
  {
    name: '삭제예정 고객',
    color: 'purple'
  },
  {
    name: '내 그룹',
    color: 'purple'
  }
]
