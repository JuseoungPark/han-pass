export const tableData1 = [
  {
    name: '금융자산',
    current: '62,000',
    after1: '62,000',
    after2: '62,000',
    after3: '62,000'
  },
  {
    name: '부동산',
    current: '30,000',
    after1: '30,000',
    after2: '30,000',
    after3: '30,000'
  },
  {
    name: '금융채무',
    current: '300',
    after1: '300',
    after2: '300',
    after3: '300'
  },
  {
    name: '임대보증금',
    current: '62000',
    after1: '62000',
    after2: '62000',
    after3: '62000'
  },
  {
    name: '상속과세가액',
    current: '30,000',
    after1: '30,000',
    after2: '30,000',
    after3: '30,000'
  },
  {
    name: '상속공제',
    current: '300',
    after1: '300',
    after2: '300',
    after3: '300'
  },
  {
    name: '상속과세표준',
    current: '62,000',
    after1: '62,000',
    after2: '62,000',
    after3: '62,000'
  },
  {
    name: '상속세 납부세액',
    current: '4,000',
    after1: '4,200',
    after2: '4,400',
    after3: '4,600'
  }
]
