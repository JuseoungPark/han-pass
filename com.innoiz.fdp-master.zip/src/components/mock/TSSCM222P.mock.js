export default [{
  name: '이주명주명',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: false
},
{
  name: '한현민',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: true
},
{
  name: '김아랑',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: true
},
{
  name: '최민정',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '김미애',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '김영미',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: false
},
{
  name: '서영우',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '차준환',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '이주명',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: false
},
{
  name: '한현민',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: true
},
{
  name: '김아랑',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: true
},
{
  name: '최민정',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '김미애',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '김영미',
  birthDay: '1997-04-30',
  marketing: false,
  collect: '수금',
  isReception: false
},
{
  name: '서영우',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
},
{
  name: '차준환',
  birthDay: '1997-04-30',
  marketing: true,
  collect: '수금',
  isReception: true
}
]
