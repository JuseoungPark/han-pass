export const viewMemberMocks2 = [
  {
    key: 0,
    checkbox: true,
    choice: [
      {
        key: 1,
        label: '해당사항 없음'
      },
      {
        key: 2,
        label: '해당(65세이상)'
      },
      {
        key: 3,
        label: '해당(정신지체 장애 등)'
      }
    ]
  },
  {
    key: 1,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '예금 ․ 적금'
      },
      {
        key: 2,
        label: '주식 ․ 채권 등 금융투자상품'
      },
      {
        key: 3,
        label: '일반보험'
      },
      {
        key: 4,
        label: '변액보험'
      }
    ]
  },
  {
    key: 2,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '단기 재산 증식'
      },
      {
        key: 2,
        label: '장기 저축을 통한 목돈 마련'
      },
      {
        key: 3,
        label: '노후를 위한 연금자산 마련'
      },
      {
        key: 4,
        label: '위험에 대비한 가족의 보장자산 마련'
      }
    ]
  },
  {
    key: 3,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '200만원 이하'
      },
      {
        key: 2,
        label: '500만원 이하'
      },
      {
        key: 3,
        label: '1,000만원 이하'
      },
      {
        key: 4,
        label: '1,000만원 초과'
      }
    ]
  },
  {
    key: 4,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '10% 미만'
      },
      {
        key: 2,
        label: '10%~20%'
      },
      {
        key: 3,
        label: '20%~30%'
      },
      {
        key: 4,
        label: '30%~50%'
      },
      {
        key: 5,
        label: '50% 이상'
      }
    ]
  },
  {
    key: 5,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '1천만원 이하'
      },
      {
        key: 2,
        label: '5천만원 이하'
      },
      {
        key: 3,
        label: '1억원 이하'
      },
      {
        key: 4,
        label: '1억원 초과'
      }
    ]
  },
  {
    key: 6,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '10만원 이하'
      },
      {
        key: 2,
        label: '10～30만원'
      },
      {
        key: 3,
        label: '30～50만원'
      },
      {
        key: 4,
        label: '50～100만원'
      },
      {
        key: 5,
        label: '100만원 초과'
      }
    ]
  },
  {
    key: 7,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '3년 미만'
      },
      {
        key: 2,
        label: '7년 미만'
      },
      {
        key: 3,
        label: '10년 미만'
      },
      {
        key: 4,
        label: '20년 미만'
      },
      {
        key: 5,
        label: '20년 이상'
      }
    ]
  },
  {
    key: 8,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '7년 미만'
      },
      {
        key: 2,
        label: '7년～10년'
      },
      {
        key: 3,
        label: '10년~20년'
      },
      {
        key: 4,
        label: '20년~30년'
      },
      {
        key: 5,
        label: '30년 초과'
      }
    ]
  },
  {
    key: 9,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '30% 미만'
      },
      {
        key: 2,
        label: '30%~50%'
      },
      {
        key: 3,
        label: '50%~70%'
      },
      {
        key: 4,
        label: '70%~90%'
      },
      {
        key: 5,
        label: '90% 이상'
      }
    ]
  },
  {
    key: 10,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '투자경험 없음'
      },
      {
        key: 2,
        label: '6개월 미만'
      },
      {
        key: 3,
        label: '1년 미만'
      },
      {
        key: 4,
        label: '2년 미만'
      },
      {
        key: 5,
        label: '2년 이상'
      }
    ]
  },
  {
    key: 11,
    checkbox: true,
    choice: [
      {
        key: 1,
        label: '주식(관리종목, 투자위험종목),\n주식형 펀드(고수익 추구),\n 선물옵션, ELW 등'
      },
      {
        key: 2,
        label: '주식(일반종목),\n주식형 펀드(시장수익률 추구),\nELS/DLS(원금비보장),\n채권(BBB-이하) 등'
      },
      {
        key: 3,
        label: '혼합형 펀드, CP/전단채(A4~A2),\n채권(BBB0~BBB+),\nELS(원금일부보장) 등'
      },
      {
        key: 4,
        label: '채권형 펀드, 금융채, 채권(A-이상),\nELB/DLB(원금보장),\nCP/전단채(A2+이상) 등'
      },
      {
        key: 5,
        label: '변액보험'
      },
      {
        key: 6,
        label: '투자경험 없음'
      }
    ]
  },
  {
    key: 12,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '원금은 반드시 보존되어야 한다'
      },
      {
        key: 2,
        label: '원금 보존을 중요하게 생각한다'
      },
      {
        key: 3,
        label: '수익률이 어느 정도 되어야 한다'
      },
      {
        key: 4,
        label: '수익률을 중요시한다'
      }
    ]
  },
  {
    key: 13,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '3%이내'
      },
      {
        key: 2,
        label: '7%이내'
      },
      {
        key: 3,
        label: '10%이내'
      },
      {
        key: 4,
        label: '15%이내'
      },
      {
        key: 5,
        label: '15%초과'
      }
    ]
  },
  {
    key: 14,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '어떠한 경우에도 손실이 나면 안된다'
      },
      {
        key: 2,
        label: '원금 기준 10%이내는 감수할 수 있다.'
      },
      {
        key: 3,
        label: '원금 기준 20%이내는 감수할 수 있다.'
      },
      {
        key: 4,
        label: '원금 기준 30%이내는 감수할 수 있다.'
      },
      {
        key: 5,
        label: '원금 기준 40%이내는 감수할 수 있다.'
      },
      {
        key: 6,
        label: '원금 기준 50%이내는 감수할 수 있다.'
      }
    ]
  },
  {
    key: 15,
    checkbox: false,
    choice: [
      {
        key: 1,
        label: '5% 미만'
      },
      {
        key: 2,
        label: '5%~10%'
      },
      {
        key: 3,
        label: '10%~20%'
      },
      {
        key: 4,
        label: '20%~50%'
      },
      {
        key: 5,
        label: '50% 이상'
      }
    ]
  }
]
