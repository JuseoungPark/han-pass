export const tableData1 = [{
  customerName: '동중만',
  count1: '5건 / 1,648,000원',
  count2: '1건 / 200,000원',
  count3: '2건 / 300,000원',
  count4: '2건 / 248,000원',
  recoupment: '0'
}]

export const tableData2 = [
  {
    company: '삼성생명',
    name: '삼성생명유니버설종신보험',
    startDate: '2012-01-01',
    endDate: '종신',
    amount: '200,000',
    cycle: '월납',
    period: '10년'
  },
  {
    company: '한화생명',
    name: '변액유니버설종신',
    startDate: '2012-01-01',
    endDate: '종신',
    amount: '300,000',
    cycle: '월납',
    period: '15년'
  },
  {
    company: '교보생명',
    name: '무)라이프플래닛b연금',
    startDate: '2012-01-01',
    endDate: '종신',
    amount: '30,000,000',
    cycle: '일시납',
    period: '일시납'
  },
  {
    company: '한화손해보험',
    name: '무배당한화유니버설우리가족사람보험',
    startDate: '2012-01-01',
    endDate: '2094-01-01',
    amount: '200,000',
    cycle: '월납',
    period: '10년'
  },
  {
    company: '롯데손해보험',
    name: '무배당성공시대',
    startDate: '2012-01-01',
    endDate: '2089-07-24',
    amount: '48,000',
    cycle: '월납',
    period: '10년'
  }
]

export const tableData3 = [
  {
    name: '암사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '질병사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '교통상해사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '소득보상형',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '80%이상 후유',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '질병 80%이상 후유',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '암사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '암사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '질병사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  },
  {
    name: '교통상해사망',
    priceTotal: '4,200',
    price1: '2,000',
    price2: '1,200',
    price3: '1,000',
    recoupment: '0'
  }
]
