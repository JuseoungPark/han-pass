<template>
  <div>
    <blockquote>
      주소입력창 디자인을 기반으로 작성되었습니다.
    </blockquote>
    <!-- autocomplete component markup 영역 -->
    <!-- input focus나 -pub-autocomplete--active 클래스 주입시 autocomplete 창이 보임-->
    <div class="-pub-autocomplete -pub-autocomplete-address -pub-autocomplete--active">
      <input class="-pub-autocomplete__input" type="text" autocomplete="off" />
      <ul class="-pub-autocomplete__list">
        <li class="-pub-autocomplete__item" v-for="(item , index) in autoCompleteMocks" :key="index" >
          <p class="-pub-autocomplete-address__zipcode">
            {{item.zipCode}}
          </p>
          <p class="-pub-autocomplete-address__addr-text"><span class="-pub-autocomplete-address__addr-title">도로명</span>{{item.roadAddr}}</p>
          <p class="-pub-autocomplete-address__addr-text"><span class="-pub-autocomplete-address__addr-title">지번</span>{{item.roadNumber}}</p>
        </li>
      </ul>
    </div>
    <!-- autocomplete component markup 영역 end -->
  </div>
</template>

<script>
export default {
  data () {
    return {
      autoCompleteMocks: [
        {
          zipCode: '05510',
          roadAddr: '서울특별시 송파구 올림픽로35길 77',
          roadNumber: '서울특별시 송파구 신천동 17-6'
        },
        {
          zipCode: '05510',
          roadAddr: '서울특별시 송파구 올림픽로35길 77',
          roadNumber: '서울특별시 송파구 신천동 17-6'
        },
        {
          zipCode: '05510',
          roadAddr: '서울특별시 송파구 올림픽로35길 77',
          roadNumber: '서울특별시 송파구 신천동 17-6'
        },
        {
          zipCode: '05510',
          roadAddr: '서울특별시 송파구 올림픽로35길 77',
          roadNumber: '서울특별시 송파구 신천동 17-6'
        }
      ]
    }
  }
}
</script>

<style>
  .-pub-autocomplete {
    position: relative;
    width: 80%;
    margin: auto;
  }

  .-pub-autocomplete__input {
    width: 100%;
    padding: 18px 22px;
    border: 1px solid #bdc3d6;
    font-family: inherit;
    font-size: inherit;
    letter-spacing: inherit;
  }

  .-pub-autocomplete.-pub-autocomplete--active .-pub-autocomplete__input,
  .-pub-autocomplete__input:focus {
    border: 1px solid #0971e8;
  }

  .-pub-autocomplete .-pub-autocomplete__input:focus ~ .-pub-autocomplete__list,
  .-pub-autocomplete.-pub-autocomplete--active .-pub-autocomplete__input ~ .-pub-autocomplete__list {
    display: block;
  }

  .-pub-autocomplete__list {
    display: none;
    position: absolute;
    left: 0;
    top: 100%;
    width: 100%;
    max-height: 350px;
    overflow-y: auto;
    border: 1px solid #bdc3d6;
    border-top: none;
  }

  .-pub-autocomplete__list .-pub-autocomplete__item {
    padding: 22px 22px;
    border-bottom: inherit;
  }
  .-pub-autocomplete__list .-pub-autocomplete__item:last-child {
    border: none;
  }
</style>
