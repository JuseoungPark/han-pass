<template>
  <section>
    <table class="output-list-table output-list-table-bordered">
      <colgroup>
        <col width="150px" />
        <col width="300px" />
        <col width="300px" />
        <col />
      </colgroup>
      <thead>
        <tr>
          <th>구분</th>
          <th>page ID</th>
          <th>페이지 이름</th>
          <th>비고</th>
        </tr>
      </thead>
      <tbody>
        <template v-for="(row, idx) in outputList">
            <router-link v-if="row.id" tag="tr" :to="{ name: row.routeName }" :key="idx">
                <td>{{row.title}}</td>
                <td v-html="row.id"></td>
                <td v-html="row.pageName"></td>
                <td v-html="row.note"></td>
            </router-link>
            <tr v-else tag="tr" :key="idx">
                <td colspan="4"><h3>{{row.note}}</h3></td>
            </tr>
        </template>
      </tbody>
    </table>
    <div class="contact-info">
        김효정 hyo927@innoiz.com / 010-8397-9817<br>
        윤미나 minayun@innoiz.com / 010-2591-9310<br>
        김태웅 tawon2137@innoiz.com / 010-6608-7780<br>
        김연희 shykyh@innoiz.com / 010-3887-4907<br>
        한문희 mun_1201@innoiz.com / 010-7118-7185
    </div>
  </section>
</template>
<script>
export default {
  data () {
    return {
      outputList: [
        { note: '2018-08-10' },
        {
          id: 'TSSCM101M',
          routeName: 'TSSCM101M',
          title: '고객',
          pageName: '고객등록동의',
          note: '김태웅'
        },
        {
          id: 'TSSPS151D',
          routeName: 'TSSPS151D',
          title: '전자서명',
          pageName: '전자서명_단순선택',
          note: '윤미나'
        },
        {
          id: '없음',
          routeName: 'autocomplete',
          title: '',
          pageName: 'autocomplete demo',
          note: '김태웅'
        },
        { note: '2018-08-22' },
        {
          id: 'TSSCM103D',
          routeName: 'TSSCM103D',
          title: '고객',
          pageName: '고객등록동의_세대원입력',
          note: '김태웅'
        },
        {
          id: 'TSSCM203M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '전체고객 리스트',
          note: '김태웅'
        },
        {
          id: 'TSSCM304M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스',
          note: '김태웅'
        },
        {
          id: 'TSSCM324M',
          routeName: 'customer-list',
          title: '고객',
          pageName: 'VIP 서비스 신청',
          note: '김태웅'
        },
        {
          id: 'TSSCM322M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '수금인수 고객',
          note: '김태웅'
        },
        {
          id: 'TSSCM222P',
          routeName: 'TSSCM222P',
          title: '고객',
          pageName: '수신고객목록',
          note: '김태웅'
        },
        {
          id: 'TSSPS110M',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명 본인인증 (계약자, 피보험자)<br>step1',
          note: '윤미나'
        },
        {
          id: 'TSSPS220M',
          routeName: 'TSSPS220M',
          title: '전자서명',
          pageName: '진단심사현황',
          note: '윤미나'
        },
        { note: '2018-08-31' },
        {
          id: 'TSSCM237D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세_계약변경사항이력',
          note: '김태웅'
        },
        {
          id: 'TSSPS210M<br>TSSPS211D<br>TSSPS212D',
          routeName: 'TSSPS210M',
          title: '전자서명',
          pageName: '설계/청약 홈 <br> (최근설계/청약서발행/신계약진행)',
          note: '윤미나'
        },
        {
          id: 'consulting',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통 <br> (TSSCT010M, TSSCT003M포함)',
          note: '김태웅'
        },
        {
          id: 'TSSBC120M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴(알림) <br> (TSSBC120M 포함)',
          note: '김태웅'
        },
        { note: '2018-09-07' },
        {
          id: 'TSSCT006M<br>TSSCT007M',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통 <br> -보장분석상세형(상품별)<br> -보장분석상세형(기간별)',
          note: '김태웅'
        },
        {
          id: 'TSSBC100M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴',
          note: '김태웅'
        },
        {
          id: 'TSSCM208D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세_FC터치 이력',
          note: '김태웅'
        },
        {
          id: 'TSSCM112P',
          routeName: 'TSSCM112P',
          title: '고객',
          pageName: '고객 등록_고객조회',
          note: '김효정'
        },
        {
          id: 'TSSCM132M<br> TSSCM217M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '고객 리스트 <br> -삭제예정고객조회<br> -정보활용동의 현황',
          note: '김효정'
        },
        {
          id: 'TSSPS131D <br> TSSPS141D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명_계약자관계자정보 step2<br> 전자서명_계좌 정보 입력 step3',
          note: '홀딩'
        },
        {
          id: 'TSSPS219P',
          routeName: 'TSSPS219P',
          title: '전자서명',
          pageName: '전자서명_보험서류발송',
          note: '홀딩'
        },
        {
          id: 'TSSPS132P',
          routeName: 'TSSPS132P',
          title: '전자서명',
          pageName: '전자서명_FATCA/CRS 본인확인서',
          note: '김효정'
        },
        {
          id: 'TSSCM323P<br>TSSCM210D',
          routeName: 'TSSCM323P',
          title: '업무공통',
          pageName: 'name-ui_공통(기존 고객카드 생성, 메모)',
          note: '김태웅'
        },
        {
          id: 'TSSCM305P',
          routeName: 'TSSCM305P',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스 급여공제 동의',
          note: '윤미나'
        },
        {
          id: 'TSSCM256P',
          routeName: 'TSSCM256P',
          title: '고객',
          pageName: '내 그룹에 추가',
          note: '김효정'
        },
        { note: '2018-09-14' },
        {
          id: 'TSSCM306P',
          routeName: 'TSSCM306P',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스 서비스신청',
          note: '김효정'
        },
        {
          id: 'TSSCM307P',
          routeName: 'TSSCM307P',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스 결과입력',
          note: '김효정'
        },
        {
          id: 'TSSCM216M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '미승인고객조회',
          note: '김효정'
        },
        {
          id: 'TSSCM317M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '관심고객 목록 조회',
          note: '김효정'
        },
        {
          id: 'TSSCM326P',
          routeName: 'TSSCM326P',
          title: '고객',
          pageName: 'VIP서비스 신청',
          note: '김효정'
        },
        {
          id: 'TSSCT008M<br>TSSCT011M<br>TSSCT005M',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통<br>- 상품컨설팅(상품별)<br>- 상품컨설팅(기간별)<br>- 보장분석요약',
          note: '김태웅'
        },
        {
          id: 'TSSCT017M<br>TSSCT018M<br>TSSCT019M<br>TSSCT017P',
          routeName: 'pensioncalc',
          title: '컨설팅',
          pageName: '연금계산 화면 공통<br>- 은퇴자산 준비현황(기간별)<br>- 은퇴자산 준비현황(상품별)<br>- 상품컨설팅(상품별)<br>- 상품컨설팅(기간별)',
          note: '김태웅'
        },
        {
          id: 'TSSCM327P',
          routeName: 'TSSCM327P',
          title: '고객',
          pageName: 'VIP서비스 신청정보 확인',
          note: '김효정'
        },
        {
          id: 'TSSCT021P',
          routeName: 'TSSCT021P',
          title: '컨설팅',
          pageName: '컨설팅 상세 세대원 선택',
          note: '김효정'
        },
        {
          id: 'TSSCM105M<br>TSSCM106D<br>TSSCM108D<br>TSSCM109D',
          routeName: 'TSSCM105M',
          title: '고객',
          pageName: '고객 등록_개인정보동의',
          note: '윤미나'
        },
        {
          id: 'TSSBC410M<br>TSSBC411M',
          routeName: 'TSSBC410M',
          title: '업무공통',
          pageName: '발행서버변경',
          note: '윤미나'
        },
        {
          id: 'TSSBC150M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴(공지)',
          note: '한문희'
        },
        {
          id: 'TSSPS222P',
          routeName: 'TSSPS222P',
          title: '전자서명',
          pageName: '진행단계 안내',
          note: '한문희'
        },
        {
          id: 'TSSCM121M',
          routeName: 'TSSCM121M',
          title: '고객',
          pageName: '세대조정',
          note: '한문희'
        },
        {
          id: 'TSSCM260D',
          routeName: 'TSSCM323P',
          title: '업무공통',
          pageName: 'Name UI(문자)',
          note: '윤미나'
        },
        {
          id: '토스트 메세지 예제(요청)',
          routeName: 'toast-example',
          title: '업무공통',
          pageName: '토스트 메세지',
          note: '김태웅'
        },
        {
          id: 'Feedback Popup',
          routeName: 'feedback-popup',
          title: '업무공통',
          pageName: 'Feedback Popup',
          note: '윤미나'
        },
        {
          id: 'TSSBC130M',
          routeName: 'gnb',
          title: '설정선택',
          pageName: '설정선택',
          note: '한문희'
        },
        { note: '2018-09-21' },
        {
          id: 'TSSBC110M<br>TSSBC111D',
          routeName: 'TSSBC110M',
          title: '업무공통',
          pageName: '전체메뉴<br>전체메뉴우측',
          note: '한문희'
        },
        {
          id: 'TSSBC133M',
          routeName: 'TSSBC131M',
          title: '업무공통',
          pageName: '시스템 설정_알림 설정',
          note: '윤미나'
        },
        {
          id: 'TSSBC151M',
          routeName: 'TSSBC151M',
          title: '업무공통',
          pageName: '공지사항 상세목록',
          note: '윤미나'
        },
        {
          id: 'TSSBC160M<br>TSSBC161D<br>TSSBC162D<br>TSSBC163D',
          routeName: 'TSSBC160M',
          title: '업무공통',
          pageName: '통합검색',
          note: '윤미나'
        },
        {
          id: 'TSSPS213P',
          routeName: 'TSSPS213P',
          title: '전자서명',
          pageName: '신계약진행현황상세',
          note: '윤미나'
        },
        {
          id: 'TSSCM310D',
          routeName: 'customer-list',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스 활동현황',
          note: '김효정'
        },
        {
          id: 'TSSCM120M<br>TSSCM120D<br>TSSCM122D',
          routeName: 'TSSCM120M',
          title: '고객',
          pageName: '고객 상세인적사항<br>조회모드<br>수정모드',
          note: '김효정'
        },
        {
          id: 'TSSCM207M',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세-계약 및 보장 분석',
          note: '김효정'
        },
        {
          id: 'TSSCM202M',
          routeName: 'TSSCM202M',
          title: '고객',
          pageName: '고객메뉴 첫화면',
          note: '김효정'
        },
        {
          id: 'TSSCM254P',
          routeName: 'TSSCM254P',
          title: '고객',
          pageName: '고객 추가',
          note: '윤미나'
        },
        {
          id: 'TSSCT009M',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통<br>- 설계후 보장분석(그래프)',
          note: '김태웅'
        },
        {
          id: 'TSSCT020M',
          routeName: 'pensioncalc',
          title: '컨설팅',
          pageName: '연금계산 화면 공통<br>- 설계후연금분석(전후비교)',
          note: '김태웅'
        },
        {
          id: 'TSSCT022M',
          routeName: 'life',
          title: '컨설팅',
          pageName: '라이프분석 화면 공통<br>- 가상고객 초기화면',
          note: '김태웅'
        },
        {
          id: 'TSSCT005P',
          routeName: 'TSSCT005P',
          title: '컨설팅',
          pageName: '타사증권입력(상품검색, 기본정보입력)',
          note: '김태웅'
        },
        {
          id: 'TSSCT007P',
          routeName: 'TSSCT007P',
          title: '컨설팅',
          pageName: '타사증권입력(특약정보)',
          note: '김태웅'
        },
        {
          id: 'TSSCT008P',
          routeName: 'TSSCT008P',
          title: '컨설팅',
          pageName: '타사증권입력(미등록상품_보장내역)',
          note: '김태웅'
        },
        { note: '2018-09-28' },
        {
          id: 'TSSPS110M<br>TSSPS121D<br>TSSPS122D<br>TSSPS123D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명 본인인증(계약자, 피보험자)<br>step1',
          note: '윤미나'
        },
        {
          id: 'TSSPS131D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명-계약관계자 정보 확인 step2',
          note: '윤미나'
        },
        {
          id: 'TSSPS141D<br>TSSPS142D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명-계좌 정보 입력 step3',
          note: '김효정'
        },
        {
          id: 'TSSPS132P',
          routeName: 'TSSPS132P',
          title: '전자서명',
          pageName: '전자서명-FATCA/CRS 본인 확인',
          note: '김효정'
        },
        {
          id: 'TSSPS184P',
          routeName: 'TSSPS184P',
          title: '전자서명',
          pageName: '전자서명 - 접수 전 체크사항 팝업',
          note: '김효정'
        },
        {
          id: 'TSSCM212P',
          routeName: 'TSSCM212P',
          title: '고객',
          pageName: '고객 - 고객 상세- 고객 검색',
          note: '김효정'
        },
        {
          id: 'TSSCT023M',
          routeName: 'life',
          title: '컨설팅',
          pageName: '노후 보장 라이프분석',
          note: '김태웅'
        },
        {
          id: 'TSSCT015P',
          routeName: 'TSSCT015P',
          title: '컨설팅',
          pageName: '연금추가(연금액 계산)',
          note: '김태웅'
        },
        {
          id: 'TSSCT016P',
          routeName: 'TSSCT016P',
          title: '컨설팅',
          pageName: '연금추가(연금액 직접입력)',
          note: '김태웅'
        },
        {
          id: 'TSSBC131M',
          routeName: 'TSSBC131M',
          title: '업무공통',
          pageName: '시스템 설정_개인정보',
          note: '한문희'
        },
        { note: '2018-10-05' },
        {
          id: 'TSSCM330P',
          routeName: 'TSSCM330P',
          title: '고객',
          pageName: 'VIP서비스 동행결과 입력',
          note: '윤미나'
        },
        {
          id: 'TSSCM329P',
          routeName: 'TSSCM329P',
          title: '고객',
          pageName: 'VIP서비스 동행신청',
          note: '윤미나'
        },
        {
          id: 'TSSCM110M',
          routeName: 'TSSCM110M',
          title: '고객',
          pageName: '고객 등록_동의완료',
          note: '윤미나'
        },
        {
          id: 'TSSCM234D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세-접촉 이력',
          note: '김효정'
        },
        {
          id: 'TSSCM143P',
          routeName: 'TSSCM143P',
          title: '고객',
          pageName: '마케팅동의 이력',
          note: '김효정'
        },
        {
          id: 'TSSCM214P',
          routeName: 'TSSCM214P',
          title: '고객',
          pageName: '보험직업 조회',
          note: '김효정'
        },
        {
          id: 'TSSCM313M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '캠페인 고객 조회',
          note: '김효정'
        },
        {
          id: 'TSSCM252P',
          routeName: 'TSSCM252P',
          title: '고객',
          pageName: '새 그룹 생성',
          note: '윤미나'
        },
        {
          id: 'TSSCM115P',
          routeName: 'TSSCM115P',
          title: '고객',
          pageName: '알뜰폰 확인',
          note: '윤미나'
        },
        {
          id: 'TSSBC501P<br>TSSBC502P',
          routeName: 'TSSBC501P',
          title: '업무공통',
          pageName: '주소검색<br>우편번호 상세주소 검증',
          note: '윤미나'
        },
        {
          id: 'TSSBC100M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴(수정본)',
          note: '김태웅'
        },
        {
          id: 'TSSCT008M<br>TSSCT011M<br>TSSCT005M',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통<br>- 상품컨설팅(상품별)<br>- 상품컨설팅(기간별)<br>- 보장분석요약',
          note: '김태웅<br>컨설팅 (퍼블 수정)'
        },
        {
          id: 'TSSCT017M<br>TSSCT018M<br>TSSCT019M<br>TSSCT017P',
          routeName: 'pensioncalc',
          title: '컨설팅',
          pageName: '연금계산 화면 공통<br>- 은퇴자산 준비현황(기간별)<br>- 은퇴자산 준비현황(상품별)<br>- 상품컨설팅(상품별)<br>- 상품컨설팅(기간별)',
          note: '김태웅<br>컨설팅 (퍼블 수정)'
        },
        {
          id: 'TSSCT022M',
          routeName: 'life',
          title: '컨설팅',
          pageName: '라이프분석 화면 공통<br>- 가상고객 초기화면',
          note: '김태웅<br>컨설팅 (퍼블 수정)'
        },
        { note: '2018-10-12' },
        {
          id: 'TSSPS210M<br>TSSPS211D<br>TSSPS212D<br>TSSPS214D<br>TSSPS215D',
          routeName: 'TSSPS210M',
          title: '전자서명',
          pageName: '설계청약 홈',
          note: '윤미나'
        },
        {
          id: 'TSSBC134M',
          routeName: 'TSSBC131M',
          title: '업무공통',
          pageName: '시스템 설정_버전 정보',
          note: '김효정'
        },
        {
          id: 'TSSBC201D',
          routeName: 'TSSBC201D',
          title: '업무공통',
          pageName: '고객검색결과',
          note: '윤미나'
        },
        {
          id: 'TSSCT002M',
          routeName: 'TSSCT002M',
          title: '컨설팅',
          pageName: '컨설팅홈_고객검색',
          note: '윤미나'
        },
        {
          id: 'TSSCT001M',
          routeName: 'TSSCT001M',
          title: '컨설팅',
          pageName: '컨설팅홈',
          note: '윤미나'
        },
        {
          id: 'TSSCT010P',
          routeName: 'TSSCT010P',
          title: '컨설팅',
          pageName: '기간별 보장금액(설계전)',
          note: '김태웅'
        },
        {
          id: 'TSSCT011P',
          routeName: 'TSSCT011P',
          title: '컨설팅',
          pageName: '기간별 보장금액(설계후)',
          note: '김태웅'
        },
        {
          id: 'TSSCT018P',
          routeName: 'TSSCT005P',
          title: '컨설팅',
          pageName: '타사증권입력(보험기본정보)_미등록상품<br>(TSSCT005P에 포함됨)',
          note: '김태웅'
        },
        {
          id: 'TSSCT004M',
          routeName: 'TSSCT004M',
          title: '컨설팅',
          pageName: '보험가입 한도조회',
          note: '김태웅'
        },
        {
          id: 'TSSCT004P',
          routeName: 'TSSCT004P',
          title: '컨설팅',
          pageName: '실손가입조회',
          note: '김태웅'
        },
        {
          id: 'TSSCT003P',
          routeName: 'TSSCT003P',
          title: '컨설팅',
          pageName: '상속세계산하기',
          note: '김태웅'
        },
        {
          id: 'TSSCM235D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세-지급이력',
          note: '김효정'
        },
        {
          id: 'TSSCM301M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '고객접촉정보 조회',
          note: '김효정'
        },
        {
          id: 'TSSCM314P',
          routeName: 'TSSCM314P',
          title: '고객',
          pageName: '캠페인 고객 직접 선정',
          note: '김효정'
        },
        {
          id: 'TSSCM315P',
          routeName: 'TSSCM315P',
          title: '고객',
          pageName: '캠페인 상세 내용',
          note: '김효정'
        },
        {
          id: 'TSSCM324M',
          routeName: 'customer-list',
          title: '고객',
          pageName: 'VIP 서비스 신청',
          note: '김효정<br>고객 (기존변경)'
        },
        {
          id: 'TSSCM303P',
          routeName: 'TSSCM303P',
          title: '고객',
          pageName: '고객접촉정보 상세 조회',
          note: '김연희'
        },
        {
          id: 'TSSCM302P',
          routeName: 'TSSCM302P',
          title: '고객',
          pageName: '고객접촉정보 수신 설정',
          note: '김연희'
        },
        {
          id: 'TSSBC110M',
          routeName: 'TSSBC110M',
          title: '업무공통',
          pageName: '전체메뉴<br />전체메뉴 우측',
          note: '한문희'
        },
        { note: '2018-10-19' },
        {
          id: 'TSSCT025P',
          routeName: 'TSSCT025P',
          title: '컨설팅',
          pageName: '가상고객 불러오기',
          note: '김효정'
        },
        {
          id: 'TSSCM328P',
          routeName: 'TSSCM328P',
          title: '고객',
          pageName: '건강검진 병원 현황 팝업',
          note: '김효정'
        },
        {
          id: 'TSSCM233D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세-캠페인 이력',
          note: '김효정'
        },
        {
          id: 'TSSCM123P',
          routeName: 'TSSCM123P',
          title: '고객',
          pageName: '동의서 발행',
          note: '김효정'
        },
        {
          id: 'TSSCM215M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '이벤트 고객 목록',
          note: '김효정'
        },
        {
          id: 'TSSPS219P',
          routeName: 'TSSPS219P',
          title: '전자서명',
          pageName: '보험(계약)서류발송',
          note: '윤미나'
        },
        {
          id: 'TSSPS211P',
          routeName: 'TSSPS211P',
          title: '전자서명',
          pageName: '전자서명완료 재처리 팝업',
          note: '윤미나'
        },
        {
          id: 'TSSPS212P',
          routeName: 'TSSPS212P',
          title: '전자서명',
          pageName: '전자청약 진행현황',
          note: '윤미나'
        },
        {
          id: 'TSSPS181M<br>TSSPS181D<br>TSSPS182D<br>TSSPS183D',
          routeName: 'TSSPS181M',
          title: '전자서명',
          pageName: '전자서명청약 완료',
          note: '윤미나'
        },
        {
          id: 'TSSCT023P',
          routeName: 'TSSCT023P',
          title: '컨설팅',
          pageName: '가상고객 선택',
          note: '윤미나'
        },
        {
          id: 'TSSCT024P',
          routeName: 'TSSCT024P',
          title: '컨설팅',
          pageName: '가상고객 라이프분석 저장',
          note: '김연희'
        },
        {
          id: 'TSSCT001P',
          routeName: 'TSSCT001P',
          title: '컨설팅',
          pageName: '인쇄/이메일 발송',
          note: '김연희'
        },
        {
          id: 'TSSCT002P',
          routeName: 'TSSCT002P',
          title: '컨설팅',
          pageName: '인쇄/이메일 발송(이메일작성)',
          note: '김연희'
        },
        {
          id: 'TSSBC140M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴(열린화면 바로가기)',
          note: '김연희'
        },
        {
          id: 'TSSBC200M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: '고객홈기본(GNB 포함)',
          note: '김연희'
        },
        {
          id: 'TSSCT022P',
          routeName: 'TSSCT022P',
          title: '컨설팅',
          pageName: '보험가입 한도조회(세부보장 내용)',
          note: '김태웅'
        },
        {
          id: 'TSSCT019P',
          routeName: 'TSSCT019P',
          title: '컨설팅',
          pageName: '세대요약형',
          note: '김태웅'
        },
        {
          id: 'TSSCT012M',
          routeName: 'TSSCT012M',
          title: '컨설팅',
          pageName: '제안스크립트',
          note: '김태웅'
        },
        {
          id: 'TSSBC152M',
          routeName: 'TSSBC152M',
          title: '업무공통',
          pageName: '공지사항 상세목록(시스템공지)',
          note: '한문희'
        },
        { note: '2018-10-26' },
        {
          id: 'TSSCT015M',
          routeName: 'TSSCT015M',
          title: '컨설팅',
          pageName: '제안스크립트(썸네일뷰)',
          note: '김효정'
        },
        {
          id: 'TSSCT009P',
          routeName: 'TSSCT009P',
          title: '컨설팅',
          pageName: '표준모델선택(표준형 / 컨설턴트 선택형)',
          note: '김효정'
        },
        {
          id: 'TSSCM251M',
          routeName: 'customer-list',
          title: '컨설팅',
          pageName: '내 그룹',
          note: '김효정'
        },
        {
          id: 'TSSCT024M<br>TSSCT025M<br>TSSCT026M',
          routeName: 'life',
          title: '컨설팅',
          pageName: '- 의료보장 라이프분석<br>- 가족보장 라이프분석<br>- 생활보장 라이프분석',
          note: '김태웅'
        },
        {
          id: 'TSSCT026P',
          routeName: 'TSSCM120M',
          title: '컨설팅',
          pageName: '고객 상세_라이프분석',
          note: '김효정'
        },
        {
          id: 'TSSCT013M',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통 <br> 설계후 연금분석(지체비용) ',
          note: '김태웅'
        },
        {
          id: 'TSSCT021M',
          routeName: 'pensioncalc',
          title: '컨설팅',
          pageName: '연금계산화면 공통 <br> 연금분석(지체비용)',
          note: '김태웅'
        },
        {
          id: 'TSSCM131P',
          routeName: 'TSSCM131P',
          title: '고객',
          pageName: '일련번호 조회',
          note: '김연희'
        },
        {
          id: 'TSSCM213P',
          routeName: 'TSSCM213P',
          title: '고객',
          pageName: '정보제공동의관리',
          note: '김연희'
        },
        {
          id: 'TSSBC202M',
          routeName: 'TSSBC202M',
          title: '업무공통',
          pageName: '대면고객홈',
          note: '김연희'
        },
        {
          id: 'TSSPS185P<br>TSSPS122D',
          routeName: 'TSSPS185P',
          title: '전자서명',
          pageName: '수익자 상이 동의',
          note: '김연희<br>신규<br>(퍼블수정)'
        },
        {
          id: 'TSSPS210M<br>TSSPS213D',
          routeName: 'TSSPS210M',
          title: '전자서명',
          pageName: '설계/청약 홈(전자서명)',
          note: '윤미나<br>(퍼블수정)<br>신규'
        },
        {
          id: 'TSSPS131D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '계약자관계자정보확인 step2',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSBC161D',
          routeName: 'TSSBC160M',
          title: '업무공통',
          pageName: '통합검색',
          note: '윤미나<br>(퍼블수정 - 마크업변동없음)'
        },
        {
          id: 'TSSCM206P<br>(TSSCM260D)',
          routeName: 'TSSCM323P',
          title: '고객',
          pageName: 'NameUI',
          note: '윤미나(퍼블수정)'
        },
        {
          id: 'TSSCM110M',
          routeName: 'TSSCM110M',
          title: '고객',
          pageName: '고객 등록_동의완료',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSCM101M<br>TSSCM114P<br>TSSCM118P',
          routeName: 'TSSCM101M',
          title: '고객',
          pageName: '고객 등록_휴대폰/카드',
          note: '윤미나<br>폰트업사이징(24pt->28pt)'
        },
        {
          id: 'TSSCM150M',
          routeName: 'TSSCM150M',
          title: '고객',
          pageName: '고객등록_QR코드',
          note: '윤미나'
        },
        {
          id: 'TSSBC164P',
          routeName: 'TSSBC164P',
          title: '업무공통',
          pageName: '통합검색 결과(질병 상세 정보)',
          note: '한문희'
        },
        {
          id: 'TSSBC153D',
          routeName: 'TSSBC153D',
          title: '업무공통',
          pageName: '시스템 공지',
          note: '한문희'
        },
        { note: '2018-10-30' },
        {
          id: 'TSSPS121D<br>TSSPS122D',
          routeName: 'TSSPS110M',
          title: '전자서명',
          pageName: '전자서명 본인인증 (계약자, 피보험자)<br>step1',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSPS185P<br>TSSPS122D',
          routeName: 'TSSPS185P',
          title: '전자서명',
          pageName: '수익자 상이 동의',
          note: '윤미나<br>(퍼블수정)'
        },
        { note: '2018-11-02' },
        {
          id: 'TSSPI100M<br>TSSPI101D<br>TSSPI190D',
          routeName: 'TSSPI100M',
          title: '가입설계',
          pageName: '일반/가상고객 생성',
          note: '김연희'
        },
        {
          id: 'TSSPI720M<br>TSSPI720D',
          routeName: 'TSSPI720M',
          title: '가입설계',
          pageName: '적합성진단 메인',
          note: '김연희'
        },
        {
          id: 'TSSCM303P',
          routeName: 'TSSCM303P',
          title: '고객',
          pageName: '고객접촉정보 상세 조회',
          note: '김연희<br>(퍼블수정)'
        },
        {
          id: 'TSSCM322M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '수금인수고객 목록 조회',
          note: '김효정<br>(폰트업사이징(24pt->28pt))'
        },
        {
          id: 'TSSCM222P',
          routeName: 'TSSCM222P',
          title: '고객',
          pageName: '수신고객목록 조회',
          note: '김효정<br>(폰트업사이징(24pt->28pt))'
        },
        {
          id: 'TSSCM203M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '전체 고객',
          note: '김효정<br>(폰트업사이징(24pt->28pt))'
        },
        {
          id: 'TSSCM317M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '관심고객 목록 조회',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: 'TSSCM304M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '프리미엄 고객사랑서비스',
          note: '김효정<br>(폰트업사이징(24pt->28pt))'
        },
        {
          id: 'TSSCM132M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '정보활용동의 현황',
          note: '김효정<br>(퍼블 수정)'
        },
        {
          id: 'TSSCM207M',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객 상세-계약 및 보장 분석',
          note: '김효정<br>(기획 변경)'
        },
        {
          id: 'TSSCM101M<br>TSSCM103D',
          routeName: 'TSSCM101M',
          title: '고객',
          pageName: '고객 등록_휴대폰/카드_세대원 입력',
          note: '윤미나<br>(폰트업사이징(24pt->28pt))'
        },
        {
          id: 'TSSCM105M<br>TSSCM106D<br>TSSCM106D-marketing<br>TSSCM108D',
          routeName: 'TSSCM105M',
          title: '고객',
          pageName: '개인정보동의 step2',
          note: '윤미나'
        },
        {
          id: 'TSSBC411M',
          routeName: 'TSSBC410M',
          title: '업무공통',
          pageName: '발행서버변경',
          note: '윤미나'
        },
        {
          id: 'TSSBC110M',
          routeName: 'TSSBC110M',
          title: '업무공통',
          pageName: '전체메뉴',
          note: '한문희<br>(퍼블수정)'
        },
        {
          id: 'TSSBC130M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: '설정선택',
          note: '한문희<br>(퍼블 수정)'
        },
        {
          id: 'TSSBC501P<br>TSSBC502P',
          routeName: 'TSSBC501P',
          title: '업무공통',
          pageName: '주소검색<br>우편번호 상세주소 검증',
          note: '한문희<br>(퍼블 수정)'
        },
        {
          id: 'TSSPI190P',
          routeName: 'TSSPI190P',
          title: '가입설계 상세',
          pageName: '상품설계_고객선택',
          note: '한문희'
        },
        {
          id: '컨설팅',
          routeName: 'consulting',
          title: '컨설팅',
          pageName: '컨설팅화면 공통',
          note: '김태웅 <br> 상품 카드 및 배지 컬러변경'
        },
        {
          id: '연금계산기',
          routeName: 'pensioncalc',
          title: '컨설팅',
          pageName: '연금계산 화면 공통',
          note: '김태웅 <br> 상품 카드 및 배지 컬러변경'
        },
        {
          id: '라이프분석',
          routeName: 'life',
          title: '컨설팅',
          pageName: '라이프분석 화면 공통',
          note: '김태웅 - 아이콘 크기조정'
        },
        {
          id: 'numeric-keypad',
          routeName: 'numeric-keypad',
          title: '업무공통',
          pageName: 'numeric-keypad',
          note: '김효정<br>fdp-text-field 옵션 virtual'
        },
        { note: '2018-11-09' },
        {
          id: 'TSSCM323P<br>TSSCM210D',
          routeName: 'TSSCM323P',
          title: '업무공통',
          pageName: 'name-ui_공통(기존 고객카드 생성, 메모)',
          note: '김효정<br>퍼블수정(마크업변동없음)'
        },
        {
          id: 'TSSAP120M',
          routeName: 'TSSAP120M',
          title: '활동성과',
          pageName: '육성코치활동입력',
          note: '김효정'
        },
        {
          id: 'TSSAP121P',
          routeName: 'TSSAP121P',
          title: '활동성과',
          pageName: '육성코치- 활동추가',
          note: '김효정'
        },
        {
          id: 'TSSAP130M',
          routeName: 'TSSAP130M',
          title: '활동성과',
          pageName: '당월소득예측',
          note: '김효정'
        },
        {
          id: 'TSSAP131P',
          routeName: 'TSSAP131P',
          title: '활동성과',
          pageName: '가입설계',
          note: '김효정'
        },
        {
          id: 'TSSAP132P',
          routeName: 'TSSAP132P',
          title: '활동성과',
          pageName: '임의목표',
          note: '김효정'
        },
        {
          id: 'TSSSA002P',
          routeName: 'TSSSA002P',
          title: '안내자료',
          pageName: 'My 세일즈북 추가',
          note: '김효정'
        },
        {
          id: 'TSSPI240P',
          routeName: 'TSSPI240P',
          title: '가입설계',
          pageName: '연금지급형태',
          note: '김효정'
        },
        {
          id: 'TSSPI790P<br>TSSPI800D<br>TSSPI810D<br>TSSPI820D',
          routeName: 'TSSPI790P',
          title: '가입설계',
          pageName: '전산심사 심사정보입력',
          note: '김연희'
        },
        {
          id: 'TSSPI720M<br>TSSPI750D<br>TSSPI751D<br>TSSPI752D',
          routeName: 'TSSPI720M',
          title: '가입설계',
          pageName: '적합성진단 질문지',
          note: '김연희'
        },
        {
          id: 'TSSPI180P',
          routeName: 'TSSPI180P',
          title: '가입설계',
          pageName: '단체명입력',
          note: '김연희'
        },
        {
          id: 'TSSPI690P',
          routeName: 'TSSPI690P',
          title: '가입설계',
          pageName: 'My플랜 저장하기',
          note: '김연희'
        },
        {
          id: 'TSSPI170P',
          routeName: 'TSSPI170P',
          title: '가입설계',
          pageName: '제안대상 선택',
          note: '김연희'
        },
        {
          id: 'TSSPI280P',
          routeName: 'TSSPI280P',
          title: '가입설계',
          pageName: '할증지수조회',
          note: '김연희'
        },
        {
          id: 'TSSPI360P',
          routeName: 'TSSPI360P',
          title: '가입설계',
          pageName: '보장적립 보험료설계 입력',
          note: '윤미나'
        },
        {
          id: 'TSSBC100M_2',
          routeName: 'TSSBC100M_2',
          title: '업무공통',
          pageName: 'GNB',
          note: '윤미나'
        },
        {
          id: 'TSSBC160M',
          routeName: 'TSSBC160M',
          title: '업무공통',
          pageName: '통합검색',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSSA001M<br>TSSSA001D<br>TSSSA007M',
          routeName: 'TSSSA001M',
          title: '안내자료',
          pageName: '안내자료 홈<br>메뉴<br>검색결과',
          note: '윤미나<br>한문희<br>윤미나'
        },
        {
          id: 'TSSPI350P',
          routeName: 'TSSPI350P',
          title: '가입설계',
          pageName: '설계저장',
          note: '한문희'
        },
        {
          id: 'TSSPI900P',
          routeName: 'TSSPI900P',
          title: '가입설계',
          pageName: '최근상품설계',
          note: '한문희'
        },
        {
          id: 'TSSAP021P',
          routeName: 'TSSAP021P',
          title: '활동성과',
          pageName: '새일정등록',
          note: '한문희'
        },
        { note: '2018-11-13' },
        {
          id: 'TSSCM210D',
          routeName: 'TSSCM323P',
          title: '업무공통',
          pageName: 'Name UI_메모',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSCM260D',
          routeName: 'TSSCM323P',
          title: '업무공통',
          pageName: 'Name UI(문자)',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSCM101M<br>TSSCM103D',
          routeName: 'TSSCM101M',
          title: '고객',
          pageName: '고객 등록_휴대폰/카드_세대원 입력',
          note: '윤미나<br>(퍼블수정)'
        },
        {
          id: 'TSSCM251M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '내 그룹',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: 'TSSCM213P',
          routeName: 'TSSCM213P',
          title: '고객',
          pageName: '정보제공동의내역 조회',
          note: '김연희<br>(퍼블 수정)'
        },
        { note: '2018-11-16' },
        {
          id: 'TSSCM216M',
          routeName: 'customer-list',
          title: '고객',
          pageName: '미승인고객',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: 'TSSBC131M',
          routeName: 'TSSBC131M',
          title: '업무공통',
          pageName: '로딩',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: 'TSSCM237D',
          routeName: 'customer-detail',
          title: '고객',
          pageName: '고객상세',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: '공통',
          routeName: 'customer-list',
          title: '고객',
          pageName: '고객내 팝업 bottom bar',
          note: '김효정<br>(퍼블수정)'
        },
        {
          id: 'TSSAP030M',
          routeName: 'TSSAP030M',
          title: '활동성과',
          pageName: '이벤트고객',
          note: '김효정'
        },
        {
          id: 'TSSAP031D',
          routeName: 'TSSAP031D',
          title: '활동성과',
          pageName: '생일 도래 고객',
          note: '김효정'
        },
        {
          id: 'TSSAP032D',
          routeName: 'TSSAP032D',
          title: '활동성과',
          pageName: '계약1주년 도래 고객',
          note: '김효정'
        },
        {
          id: 'TSSAP033D',
          routeName: 'TSSAP033D',
          title: '활동성과',
          pageName: '상령일 도래 고객',
          note: '김효정'
        },
        {
          id: 'TSSAP050M',
          routeName: 'TSSAP050M',
          title: '활동성과',
          pageName: '진행 중인 캠페인',
          note: '윤미나'
        },
        {
          id: 'TSSAP133P',
          routeName: 'TSSAP133P',
          title: '활동성과',
          pageName: '입금예정',
          note: '윤미나'
        },
        {
          id: 'TSSBC301P',
          routeName: 'TSSBC301P',
          title: '업무공통',
          pageName: '설문조사',
          note: '김연희'
        },
        {
          id: 'TSSPI100M<br>TSSPI101D<br>TSSPI230D',
          routeName: 'TSSPI100M',
          title: '가입설계',
          pageName: '상품선택',
          note: '김연희'
        },
        {
          id: 'TSSPI230P',
          routeName: 'TSSPI230P',
          title: '가입설계',
          pageName: '상품조회 및 선택',
          note: '김연희'
        },
        {
          id: 'TSSPI830P<br>TSSPI840D<br>TSSPI850D<br>TSSPI860D',
          routeName: 'TSSPI830P',
          title: '가입설계',
          pageName: '전산심사 결과확인',
          note: '김연희'
        },
        {
          id: 'TSSBC140M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: 'gnb 메뉴(열린화면 바로가기)',
          note: '김연희<br>(퍼블 수정)'
        },
        {
          id: 'TSSPI880P',
          routeName: 'TSSPI880P',
          title: '가입설계',
          pageName: '단체 검색',
          note: '한문희'
        },
        {
          id: 'TSSAP021P',
          routeName: 'TSSAP021P',
          title: '활동성과',
          pageName: '새일정등록',
          note: '한문희<br>(퍼블 수정)'
        },
        {
          id: 'TSSBC130M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: '설정선택',
          note: '한문희<br>(퍼블 수정)'
        },
        {
          id: 'TSSBC131M',
          routeName: 'TSSBC131M',
          title: '업무공통',
          pageName: '시스템설정',
          note: '한문희<br>(퍼블 수정)'
        },
        {
          id: 'TSSPI290P',
          routeName: 'TSSPI290P',
          title: '가입설계',
          pageName: '특약목록 보장내용',
          note: '한문희'
        },
        {
          id: 'TSSBC150M',
          routeName: 'gnb',
          title: '업무공통',
          pageName: '공지사항',
          note: '한문희<br>(퍼블 수정)'
        },
        {
        }
      ]
    }
  }
}
</script>
<style scoped>
    .contact-info {
        width: 1000px;
        margin: 30px auto 50px;
        font-size: 1.3rem;
    }
  .yun { background: greenyellow; }
  .tw { background: deepskyblue; }
  .moon { background: yellow; }
  .hyo { background: orange; }
  .hee { background: hotpink; }
  .display {
    display: block;
    padding-top: 10px;
    padding-left: 10px;
  }

  .output-list-table {
    border-spacing: 0;
    max-width: 1000px;
    min-width: 800px;
    padding-top: 2em;
    margin: 0 auto;
    border-top: 2px solid #000;
    text-align: center;
    table-layout: fixed;
    font-size: 1rem;
    letter-spacing: normal;
  }

  .output-list-table thead tr {
    height: 2em;
    border-top: 1px solid #000;
  }

  .output-list-table tbody tr td {
    border: 1px solid #000;
    cursor: pointer;
    vertical-align: middle;
  }

  .output-list-table {
    width: 100%;
    margin-bottom: 1rem;
    background-color: transparent;
  }

  .output-list-table th,
  .output-list-table td {
    padding: 0.75rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
  }

  .output-list-table thead th {
    vertical-align: bottom;
    border-bottom: 2px solid #dee2e6;
  }

  .output-list-table tbody+tbody {
    border-top: 2px solid #dee2e6;
  }

  .output-list-table .output-list-table {
    background-color: #fff;
  }

  .output-list-table-bordered {
    border: 1px solid #dee2e6;
  }

  .output-list-table-bordered th,
  .output-list-table-bordered td {
    border: 1px solid #dee2e6;
  }

  .output-list-table-bordered thead th,
  .output-list-table-bordered thead td {
    border-bottom-width: 2px;
  }

</style>
