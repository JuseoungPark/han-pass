// fdp 기본 route 정보
import IndexPage from '@/components/index'
import TSSCM101M from '@/components/pages/2018-10-26/TSSCM101M'
import PubAutoComplete from '@/components/components-pub/autocomplete'
import TSSPS151D from '@/components/pages/2018-08-10/TSSPS151D'
import TSSCM203M from '@/components/pages/2018-08-22/TSSCM203M'
import TSSCM304M from '@/components/pages/2018-08-22/TSSCM304M'
import TSSPS220M from '@/components/pages/2018-08-22/TSSPS220M'
import TSSCM324M from '@/components/pages/2018-08-22/TSSCM324M'
import TSSCM322M from '@/components/pages/2018-08-22/TSSCM322M'
import TSSCM222P from '@/components/pages/2018-08-22/TSSCM222P'
import TSSPS210M from '@/components/pages/2018-10-12/TSSPS210M'
import CustomerDetail from '@/components/pages/2018-08-31/customer-detail'
import CustomerList from '@/components/pages/2018-09-07/customer-list'
import consulting from '@/components/pages/2018-08-31/consulting'
import gnb from '@/components/pages/2018-08-31/gnb'
import TSSCM217M from '@/components/pages/2018-09-07/TSSCM217M'
import TSSCM112P from '@/components/pages/2018-09-07/TSSCM112P'
import TSSCM132M from '@/components/pages/2018-09-07/TSSCM132M'
import TSSPS132P from '@/components/pages/2018-09-07/TSSPS132P'
import TSSCM323P from '@/components/pages/2018-09-07/TSSCM323P(TSSCM210D)'
import TSSPS219P from '@/components/pages/2018-10-19/TSSPS219P'
import TSSCM305P from '@/components/pages/2018-09-07/TSSCM305P'
import TSSCM256P from '@/components/pages/2018-09-07/TSSCM256P'
import TSSCM326P from '@/components/pages/2018-09-14/TSSCM326P'
import TSSCM216M from '@/components/pages/2018-09-14/TSSCM216M'
import TSSCM306P from '@/components/pages/2018-09-14/TSSCM306P'
import TSSCM307P from '@/components/pages/2018-09-14/TSSCM307P'
import TSSCM327P from '@/components/pages/2018-09-14/TSSCM327P'
import TSSCM317M from '@/components/pages/2018-09-14/TSSCM317M'
import TSSCM318P from '@/components/pages/2018-09-14/TSSCM318P'
import TSSCM105M from '@/components/pages/2018-09-14/TSSCM105M'
import pensioncalc from '@/components/pages/2018-09-14/pensioncalc'
import TSSCM106D from '@/components/pages/2018-09-14/TSSCM106D'
import TSSCM108D from '@/components/pages/2018-09-14/TSSCM108D'
import TSSCM109D from '@/components/pages/2018-09-14/TSSCM109D'
import TSSCT021P from '@/components/pages/2018-09-14/TSSCT021P'
import TSSCM121M from '@/components/pages/2018-09-14/TSSCM121M'
import TSSPS222P from '@/components/pages/2018-09-14/TSSPS222P'
import TSSBC410M from '@/components/pages/2018-09-14/TSSBC410M'
import TSSCM260D from '@/components/pages/2018-09-14/TSSCM260D'
import ToastView from '@/components/pages/2018-09-14/toast-view'
import FeedbackPopup from '@/components/pages/2018-09-14/feedback-popup'
import TSSBC130M from '@/components/pages/2018-09-14/TSSBC130M'
import TSSBC110M from '@/components/pages/2018-09-21/TSSBC110M'
import TSSBC111D from '@/components/pages/2018-09-21/TSSBC111D'
import TSSBC131M from '@/components/pages/2018-09-21/TSSBC131M'
import TSSBC133M from '@/components/pages/2018-09-21/TSSBC133M'
import TSSBC151M from '@/components/pages/2018-09-21/TSSBC151M'
import TSSBC160M from '@/components/pages/2018-09-21/TSSBC160M'
import TSSBC161D from '@/components/pages/2018-09-21/TSSBC161D'
import TSSBC162D from '@/components/pages/2018-09-21/TSSBC162D'
import TSSBC163D from '@/components/pages/2018-09-21/TSSBC163D'
import TSSPS213P from '@/components/pages/2018-09-21/TSSPS213P'
import TSSCM310D from '@/components/pages/2018-09-21/TSSCM310D'
import TSSCM120M from '@/components/pages/2018-09-21/tabs/TSSCM120M'
import TSSCM120D from '@/components/pages/2018-09-21/TSSCM120D'
import TSSCM122D from '@/components/pages/2018-09-21/TSSCM122D'
import TSSCM202M from '@/components/pages/2018-09-21/TSSCM202M'
import TSSCM207M from '@/components/pages/2018-09-21/TSSCM207M'
import TSSCM254P from '@/components/pages/2018-09-21/TSSCM254P'
import TSSCT005P from '@/components/pages/2018-09-21/TSSCT005P'
import TSSCT007P from '@/components/pages/2018-09-21/TSSCT007P'
import TSSCT008P from '@/components/pages/2018-09-21/TSSCT008P'
import life from '@/components/pages/2018-09-21/life'
import TSSPS110M from '@/components/pages/2018-09-28/TSSPS110M'
import TSSPS131D from '@/components/pages/2018-10-26/TSSPS131D'
import TSSPS141D from '@/components/pages/2018-09-28/TSSPS141D'
import TSSPS184P from '@/components/pages/2018-09-28/TSSPS184P'
import TSSCM212P from '@/components/pages/2018-09-28/TSSCM212P'
import TSSCT015P from '@/components/pages/2018-09-28/TSSCT015P'
import TSSCT016P from '@/components/pages/2018-09-28/TSSCT016P'
import TSSCM234D from '@/components/pages/2018-10-05/TSSCM234D'
import TSSCM143P from '@/components/pages/2018-10-05/TSSCM143P'
import TSSCM214P from '@/components/pages/2018-10-05/TSSCM214P'
import TSSCM115P from '@/components/pages/2018-10-05/TSSCM115P'
import TSSCM313M from '@/components/pages/2018-10-05/TSSCM313M'
import TSSCM330P from '@/components/pages/2018-10-05/TSSCM330P'
import TSSCM329P from '@/components/pages/2018-10-05/TSSCM329P'
import TSSCM110M from '@/components/pages/2018-10-05/TSSCM110M'
import TSSCM252P from '@/components/pages/2018-10-05/TSSCM252P'
import TSSBC501P from '@/components/pages/2018-10-05/TSSBC501P'
import TSSBC502P from '@/components/pages/2018-10-05/TSSBC502P'
import TSSCT010P from '@/components/pages/2018-10-12/TSSCT010P'
import TSSCT011P from '@/components/pages/2018-10-12/TSSCT011P'
import TSSCM235D from '@/components/pages/2018-10-12/TSSCM235D'
import TSSCM301M from '@/components/pages/2018-10-12/TSSCM301M'
import TSSCM315P from '@/components/pages/2018-10-12/TSSCM315P'
import TSSCT001M from '@/components/pages/2018-10-12/TSSCT001M'
import TSSCT002M from '@/components/pages/2018-10-12/TSSCT002M'
import TSSBC201D from '@/components/pages/2018-10-12/TSSBC201D'
import TSSCT004M from '@/components/pages/2018-10-12/TSSCT004M'
import TSSCT004P from '@/components/pages/2018-10-12/TSSCT004P'
import TSSBC134M from '@/components/pages/2018-10-12/TSSBC134M'
import TSSCM314P from '@/components/pages/2018-10-12/TSSCM314P'
import TSSCM303P from '@/components/pages/2018-10-12/TSSCM303P'
import TSSCM302P from '@/components/pages/2018-10-12/TSSCM302P'
import TSSCT003P from '@/components/pages/2018-10-12/TSSCT003P'
import TSSCT022P from '@/components/pages/2018-10-19/TSSCT022P'
import TSSCT019P from '@/components/pages/2018-10-19/TSSCT019P'
import TSSCT012M from '@/components/pages/2018-10-19/TSSCT012M'
import TSSCT025P from '@/components/pages/2018-10-19/TSSCT025P'
import TSSCM328P from '@/components/pages/2018-10-19/TSSCM328P'
import TSSCM233D from '@/components/pages/2018-10-19/TSSCM233D'
import TSSCM123P from '@/components/pages/2018-10-19/TSSCM123P'
import TSSCM215M from '@/components/pages/2018-10-19/TSSCM215M'
import TSSCT024P from '@/components/pages/2018-10-19/TSSCT024P'
import TSSCT001P from '@/components/pages/2018-10-19/TSSCT001P'
import TSSCT002P from '@/components/pages/2018-10-19/TSSCT002P'
import TSSCT023P from '@/components/pages/2018-10-19/TSSCT023P'
import TSSBC140M from '@/components/pages/2018-10-19/TSSBC140M'
import TSSPS211P from '@/components/pages/2018-10-19/TSSPS211P'
import TSSPS212P from '@/components/pages/2018-10-19/TSSPS212P'
import TSSBC200M from '@/components/pages/2018-10-19/TSSBC200M'
import TSSPS181M from '@/components/pages/2018-10-19/TSSPS181M'
import TSSBC152M from '@/components/pages/2018-10-19/TSSBC152M'
import TSSCT015M from '@/components/pages/2018-10-26/TSSCT015M'
import TSSCT009P from '@/components/pages/2018-10-26/TSSCT009P'
import TSSCM251M from '@/components/pages/2018-10-26/TSSCM251M'
import TSSCT026P from '@/components/pages/2018-10-26/TSSCT026P'
import TSSCM131P from '@/components/pages/2018-10-26/TSSCM131P'
import TSSCM213P from '@/components/pages/2018-10-26/TSSCM213P'
import TSSBC202M from '@/components/pages/2018-10-26/TSSBC202M'
import TSSCM150M from '@/components/pages/2018-10-26/TSSCM150M'
import TSSBC164P from '@/components/pages/2018-10-26/TSSBC164P'
import TSSBC153D from '@/components/pages/2018-10-26/TSSBC153D'
import TSSPS185P from '@/components/pages/2018-10-26/TSSPS185P'
import TSSPI100M from '@/components/pages/2018-11-02/TSSPI100M'
import TSSPI720M from '@/components/pages/2018-11-02/TSSPI720M'
import TSSPI190P from '@/components/pages/2018-11-02/TSSPI190P'
import NumericKeypad from '@/components/pages/2018-11-02/numeric-keypad'
import TSSAP120M from '@/components/pages/2018-11-09/TSSAP120M'
import TSSAP121P from '@/components/pages/2018-11-09/TSSAP121P'
import TSSAP130M from '@/components/pages/2018-11-09/TSSAP130M'
import TSSAP131P from '@/components/pages/2018-11-09/TSSAP131P'
import TSSAP132P from '@/components/pages/2018-11-09/TSSAP132P'
import TSSSA002P from '@/components/pages/2018-11-09/TSSSA002P'
import TSSPI790P from '@/components/pages/2018-11-09/TSSPI790P'
import TSSPI180P from '@/components/pages/2018-11-09/TSSPI180P'
import TSSPI690P from '@/components/pages/2018-11-09/TSSPI690P'
import TSSPI360P from '@/components/pages/2018-11-09/TSSPI360P'
import TSSPI280P from '@/components/pages/2018-11-09/TSSPI280P'
import TSSPI240P from '@/components/pages/2018-11-09/TSSPI240P'
import TSSBC100M_2 from '@/components/pages/2018-11-09/TSSBC100M_2'
import TSSSA007M from '@/components/pages/2018-11-09/TSSSA007M'
import TSSPI350P from '@/components/pages/2018-11-09/TSSPI350P'
import TSSPI170P from '@/components/pages/2018-11-09/TSSPI170P'
import TSSPI900P from '@/components/pages/2018-11-09/TSSPI900P'
import TSSSA001D from '@/components/pages/2018-11-09/TSSSA001D'
import TSSSA001M from '@/components/pages/2018-11-09/TSSSA001M'
import TSSAP021P from '@/components/pages/2018-11-09/TSSAP021P'
import TSSAP030M from '@/components/pages/2018-11-16/TSSAP030M'
import TSSAP032D from '@/components/pages/2018-11-16/TSSAP032D'
import TSSAP033D from '@/components/pages/2018-11-16/TSSAP033D'
import TSSAP031D from '@/components/pages/2018-11-16/TSSAP031D'
import TSSBC301P from '@/components/pages/2018-11-16/TSSBC301P'
import TSSPI230D from '@/components/pages/2018-11-16/TSSPI230D'
import TSSPI230P from '@/components/pages/2018-11-16/TSSPI230P'
import TSSPI830P from '@/components/pages/2018-11-16/TSSPI830P'
import TSSPI880P from '@/components/pages/2018-11-16/TSSPI880P'
import TSSAP133P from '@/components/pages/2018-11-16/TSSAP133P'
import TSSPI290P from '@/components/pages/2018-11-16/TSSPI290P'

// 중첩 라우팅 Child 정보
import LnbRotues from './main/child/lnb.js'

// 1번 영역
var rootRoutes = [
  {
    path: '/autocomplete-demo',
    name: 'autocomplete',
    component: PubAutoComplete,
    children: []
  },
  {
    path: '/TSSCM101M',
    name: 'TSSCM101M',
    component: TSSCM101M,
    children: []
  },
  {
    path: '/TSSCM103D',
    name: 'TSSCM103D',
    component: TSSCM101M,
    children: []
  },
  {
    path: '/TSSPS151D',
    name: 'TSSPS151D',
    component: TSSPS151D,
    children: []
  },
  {
    path: '/TSSCM304M',
    name: 'TSSCM304M',
    component: TSSCM304M,
    children: []
  },
  {
    path: '/TSSCM203M',
    name: 'TSSCM203M',
    component: TSSCM203M,
    children: []
  },
  {
    path: '/TSSPS110M',
    name: 'TSSPS110M',
    component: TSSPS110M,
    children: []
  },
  {
    path: '/TSSPS220M',
    name: 'TSSPS220M',
    component: TSSPS220M,
    children: []
  },
  {
    path: '/TSSCM324M',
    name: 'TSSCM324M',
    component: TSSCM324M,
    children: []
  },
  {
    path: '/TSSCM322M',
    name: 'TSSCM322M',
    component: TSSCM322M,
    children: []
  },
  {
    path: '/TSSCM222P',
    name: 'TSSCM222P',
    component: TSSCM222P,
    children: []
  },
  {
    path: '/consulting',
    name: 'consulting',
    component: consulting,
    children: []
  },
  {
    path: '/gnb',
    name: 'gnb',
    component: gnb,
    children: []
  },
  {
    path: '/TSSPS210M',
    name: 'TSSPS210M',
    component: TSSPS210M,
    children: []
  },
  {
    path: '/customer-detail',
    name: 'customer-detail',
    component: CustomerDetail,
    children: []
  },
  {
    path: '/TSSCM217M',
    name: 'TSSCM217M',
    component: TSSCM217M,
    children: []
  },
  {
    path: '/TSSCM112P',
    name: 'TSSCM112P',
    component: TSSCM112P,
    children: []
  },
  {
    path: '/TSSCM132M',
    name: 'TSSCM132M',
    component: TSSCM132M,
    children: []
  },
  {
    path: '/customer-list',
    name: 'customer-list',
    component: CustomerList,
    children: []
  },
  {
    path: '/TSSPS131D',
    name: 'TSSPS131D',
    component: TSSPS131D,
    children: []
  },
  {
    path: '/TSSPS132P',
    name: 'TSSPS132P',
    component: TSSPS132P
  },
  {
    path: '/TSSPS141D',
    name: 'TSSPS141D',
    component: TSSPS141D,
    children: []
  },
  {
    path: '/TSSCM323P',
    name: 'TSSCM323P',
    component: TSSCM323P,
    children: []
  },
  {
    path: '/TSSPS219P',
    name: 'TSSPS219P',
    component: TSSPS219P
  },
  {
    path: '/TSSCM305P',
    name: 'TSSCM305P',
    component: TSSCM305P
  },
  {
    path: '/TSSCM256P',
    name: 'TSSCM256P',
    component: TSSCM256P
  },
  {
    path: '/TSSCM326P',
    name: 'TSSCM326P',
    component: TSSCM326P
  },
  {
    path: '/TSSCM216M',
    name: 'TSSCM216M',
    component: TSSCM216M
  },
  {
    path: '/TSSCM306P',
    name: 'TSSCM306P',
    component: TSSCM306P
  },
  {
    path: '/TSSCM307P',
    name: 'TSSCM307P',
    component: TSSCM307P
  },
  {
    path: '/TSSCM327P',
    name: 'TSSCM327P',
    component: TSSCM327P
  },
  {
    path: '/TSSCM317M',
    name: 'TSSCM317M',
    component: TSSCM317M
  },
  {
    path: '/TSSCM318P',
    name: 'TSSCM318P',
    component: TSSCM318P
  },
  {
    path: '/TSSCM105M',
    name: 'TSSCM105M',
    component: TSSCM105M
  },
  {
    path: '/pensioncalc',
    name: 'pensioncalc',
    component: pensioncalc
  },
  {
    path: '/TSSCM106D',
    name: 'TSSCM106D',
    component: TSSCM106D
  },
  {
    path: '/TSSCM108D',
    name: 'TSSCM108D',
    component: TSSCM108D
  },
  {
    path: '/TSSCM109D',
    name: 'TSSCM109D',
    component: TSSCM109D
  },
  {
    path: '/TSSCT021P',
    name: 'TSSCT021P',
    component: TSSCT021P
  },
  {
    path: '/TSSCM121M',
    name: 'TSSCM121M',
    component: TSSCM121M
  },
  {
    path: '/TSSPS222P',
    name: 'TSSPS222P',
    component: TSSPS222P
  },
  {
    path: '/TSSBC410M',
    name: 'TSSBC410M',
    component: TSSBC410M
  },
  {
    path: '/TSSCM260D',
    name: 'TSSCM260D',
    component: TSSCM260D
  },
  {
    path: '/toast-example',
    name: 'toast-example',
    component: ToastView
  },
  {
    path: '/feedback-popup',
    name: 'feedback-popup',
    component: FeedbackPopup
  },
  {
    path: '/TSSBC130M',
    name: 'TSSBC130M',
    component: TSSBC130M
  },
  {
    path: '/TSSCM310D',
    name: 'TSSCM310D',
    component: TSSCM310D
  },
  {
    path: '/TSSBC110M',
    name: 'TSSBC110M',
    component: TSSBC110M
  },
  {
    path: '/TSSBC111D',
    name: 'TSSBC111D',
    component: TSSBC111D
  },
  {
    path: '/TSSBC131M',
    name: 'TSSBC131M',
    component: TSSBC131M
  },
  {
    path: '/TSSBC133M',
    name: 'TSSBC133M',
    component: TSSBC133M
  },
  {
    path: '/TSSBC151M',
    name: 'TSSBC151M',
    component: TSSBC151M
  },
  {
    path: '/TSSBC160M',
    name: 'TSSBC160M',
    component: TSSBC160M
  },
  {
    path: '/TSSBC161D',
    name: 'TSSBC161D',
    component: TSSBC161D
  },
  {
    path: '/TSSBC162D',
    name: 'TSSBC162D',
    component: TSSBC162D
  },
  {
    path: '/TSSBC163D',
    name: 'TSSBC163D',
    component: TSSBC163D
  },
  {
    path: '/TSSPS213P',
    name: 'TSSPS213P',
    component: TSSPS213P
  },
  {
    path: '/TSSCM120M',
    name: 'TSSCM120M',
    component: TSSCM120M
  },
  {
    path: '/TSSCM120D',
    name: 'TSSCM120D',
    component: TSSCM120D
  },
  {
    path: '/TSSCM122D',
    name: 'TSSCM122D',
    component: TSSCM122D
  },
  {
    path: '/TSSCM202M',
    name: 'TSSCM202M',
    component: TSSCM202M
  },
  {
    path: '/TSSCM207M',
    name: 'TSSCM207M',
    component: TSSCM207M
  },
  {
    path: '/TSSCM254P',
    name: 'TSSCM254P',
    component: TSSCM254P
  },
  {
    path: '/life',
    name: 'life',
    component: life
  },
  {
    path: '/TSSCT005P',
    name: 'TSSCT005P',
    component: TSSCT005P
  },
  {
    path: '/TSSCT007P',
    name: 'TSSCT007P',
    component: TSSCT007P
  },
  {
    path: '/TSSCT008P',
    name: 'TSSCT008P',
    component: TSSCT008P
  },
  {
    path: '/TSSCM212P',
    name: 'TSSCM212P',
    component: TSSCM212P
  },
  {
    path: '/TSSPS184P',
    name: 'TSSPS184P',
    component: TSSPS184P
  },
  {
    path: '/TSSCT015P',
    name: 'TSSCT015P',
    component: TSSCT015P
  },
  {
    path: '/TSSCT016P',
    name: 'TSSCT016P',
    component: TSSCT016P
  },
  {
    path: '/TSSCM234D',
    name: 'TSSCM234D',
    component: TSSCM234D
  },
  {
    path: '/TSSCM143P',
    name: 'TSSCM143P',
    component: TSSCM143P
  },
  {
    path: '/TSSCM214P',
    name: 'TSSCM214P',
    component: TSSCM214P
  },
  {
    path: '/TSSCM115P',
    name: 'TSSCM115P',
    component: TSSCM115P
  },
  {
    path: '/TSSCM313M',
    name: 'TSSCM313M',
    component: TSSCM313M
  },
  {
    path: '/TSSCM330P',
    name: 'TSSCM330P',
    component: TSSCM330P
  },
  {
    path: '/TSSCM329P',
    name: 'TSSCM329P',
    component: TSSCM329P
  },
  {
    path: '/TSSCM110M',
    name: 'TSSCM110M',
    component: TSSCM110M
  },
  {
    path: '/TSSCM252P',
    name: 'TSSCM252P',
    component: TSSCM252P
  },
  {
    path: '/TSSBC501P',
    name: 'TSSBC501P',
    component: TSSBC501P
  },
  {
    path: '/TSSBC502P',
    name: 'TSSBC502P',
    component: TSSBC502P
  },
  {
    path: '/TSSCT010P',
    name: 'TSSCT010P',
    component: TSSCT010P
  },
  {
    path: '/TSSCT011P',
    name: 'TSSCT011P',
    component: TSSCT011P
  },
  {
    path: '/TSSCM235D',
    name: 'TSSCM235D',
    component: TSSCM235D
  },
  {
    path: '/TSSCM301M',
    name: 'TSSCM301M',
    component: TSSCM301M
  },
  {
    path: '/TSSCM315P',
    name: 'TSSCM315P',
    component: TSSCM315P
  },
  {
    path: '/TSSCT001M',
    name: 'TSSCT001M',
    component: TSSCT001M
  },
  {
    path: '/TSSCT002M',
    name: 'TSSCT002M',
    component: TSSCT002M
  },
  {
    path: '/TSSCM314P',
    name: 'TSSCM314P',
    component: TSSCM314P
  },
  {
    path: '/TSSBC201D',
    name: 'TSSBC201D',
    component: TSSBC201D
  },
  {
    path: '/TSSCT004M',
    name: 'TSSCT004M',
    component: TSSCT004M
  },
  {
    path: '/TSSCT004P',
    name: 'TSSCT004P',
    component: TSSCT004P
  },
  {
    path: '/TSSBC134M',
    name: 'TSSBC134M',
    component: TSSBC134M
  },
  {
    path: '/TSSCM303P',
    name: 'TSSCM303P',
    component: TSSCM303P
  },
  {
    path: '/TSSCM302P',
    name: 'TSSCM302P',
    component: TSSCM302P
  },
  {
    path: '/TSSCT003P',
    name: 'TSSCT003P',
    component: TSSCT003P
  },
  {
    path: '/TSSCT022P',
    name: 'TSSCT022P',
    component: TSSCT022P
  },
  {
    path: '/TSSCT019P',
    name: 'TSSCT019P',
    component: TSSCT019P
  },
  {
    path: '/TSSCT012M',
    name: 'TSSCT012M',
    component: TSSCT012M
  },
  {
    path: '/TSSCT025P',
    name: 'TSSCT025P',
    component: TSSCT025P
  },
  {
    path: '/TSSCM328P',
    name: 'TSSCM328P',
    component: TSSCM328P
  },
  {
    path: '/TSSCM233D',
    name: 'TSSCM233D',
    component: TSSCM233D
  },
  {
    path: '/TSSCM123P',
    name: 'TSSCM123P',
    component: TSSCM123P
  },
  {
    path: '/TSSCM215M',
    name: 'TSSCM215M',
    component: TSSCM215M
  },
  {
    path: '/TSSCT024P',
    name: 'TSSCT024P',
    component: TSSCT024P
  },
  {
    path: '/TSSCT001P',
    name: 'TSSCT001P',
    component: TSSCT001P
  },
  {
    path: '/TSSCT002P',
    name: 'TSSCT002P',
    component: TSSCT002P
  },
  {
    path: '/TSSCT023P',
    name: 'TSSCT023P',
    component: TSSCT023P
  },
  {
    path: '/TSSBC140M',
    name: 'TSSBC140M',
    component: TSSBC140M
  },
  {
    path: '/TSSPS211P',
    name: 'TSSPS211P',
    component: TSSPS211P
  },
  {
    path: '/TSSPS212P',
    name: 'TSSPS212P',
    component: TSSPS212P
  },
  {
    path: '/TSSBC200M',
    name: 'TSSBC200M',
    component: TSSBC200M
  },
  {
    path: '/TSSPS181M',
    name: 'TSSPS181M',
    component: TSSPS181M
  },
  {
    path: '/TSSBC152M',
    name: 'TSSBC152M',
    component: TSSBC152M
  },
  {
    path: '/TSSCT015M',
    name: 'TSSCT015M',
    component: TSSCT015M
  },
  {
    path: '/TSSCT009P',
    name: 'TSSCT009P',
    component: TSSCT009P
  },
  {
    path: '/TSSCM251M',
    name: 'TSSCM251M',
    component: TSSCM251M
  },
  {
    path: '/TSSCT026P',
    name: 'TSSCT026P',
    component: TSSCT026P
  },
  {
    path: '/TSSCM131P',
    name: 'TSSCM131P',
    component: TSSCM131P
  },
  {
    path: '/TSSCM213P',
    name: 'TSSCM213P',
    component: TSSCM213P
  },
  {
    path: '/TSSBC202M',
    name: 'TSSBC202M',
    component: TSSBC202M
  },
  {
    path: '/TSSCM150M',
    name: 'TSSCM150M',
    component: TSSCM150M
  },
  {
    path: '/TSSBC164P',
    name: 'TSSBC164P',
    component: TSSBC164P
  },
  {
    path: '/TSSBC153D',
    name: 'TSSBC153D',
    component: TSSBC153D
  },
  {
    path: '/TSSPS185P',
    name: 'TSSPS185P',
    component: TSSPS185P
  },
  {
    path: '/TSSPI100M',
    name: 'TSSPI100M',
    component: TSSPI100M
  },
  {
    path: '/TSSPI720M',
    name: 'TSSPI720M',
    component: TSSPI720M
  },
  {
    path: '/TSSPI190P',
    name: 'TSSPI190P',
    component: TSSPI190P
  },
  {
    path: '/numeric-keypad',
    name: 'numeric-keypad',
    component: NumericKeypad
  },
  {
    path: '/TSSAP120M',
    name: 'TSSAP120M',
    component: TSSAP120M
  },
  {
    path: '/TSSAP121P',
    name: 'TSSAP121P',
    component: TSSAP121P
  },
  {
    path: '/TSSAP130M',
    name: 'TSSAP130M',
    component: TSSAP130M
  },
  {
    path: '/TSSAP131P',
    name: 'TSSAP131P',
    component: TSSAP131P
  },
  {
    path: '/TSSAP132P',
    name: 'TSSAP132P',
    component: TSSAP132P
  },
  {
    path: '/TSSSA002P',
    name: 'TSSSA002P',
    component: TSSSA002P
  },
  {
    path: '/TSSPI790P',
    name: 'TSSPI790P',
    component: TSSPI790P
  },
  {
    path: '/TSSPI180P',
    name: 'TSSPI180P',
    component: TSSPI180P
  },
  {
    path: '/TSSPI690P',
    name: 'TSSPI690P',
    component: TSSPI690P
  },
  {
    path: '/TSSPI360P',
    name: 'TSSPI360P',
    component: TSSPI360P
  },
  {
    path: '/TSSPI280P',
    name: 'TSSPI280P',
    component: TSSPI280P
  },
  {
    path: '/TSSPI240P',
    name: 'TSSPI240P',
    component: TSSPI240P
  },
  {
    path: '/TSSBC100M_2',
    name: 'TSSBC100M_2',
    component: TSSBC100M_2
  },
  {
    path: '/TSSSA007M',
    name: 'TSSSA007M',
    component: TSSSA007M
  },
  {
    path: '/TSSPI350P',
    name: 'TSSPI350P',
    component: TSSPI350P
  },
  {
    path: '/TSSPI170P',
    name: 'TSSPI170P',
    component: TSSPI170P
  },
  {
    path: '/TSSPI900P',
    name: 'TSSPI900P',
    component: TSSPI900P
  },
  {
    path: '/TSSSA001D',
    name: 'TSSSA001D',
    component: TSSSA001D
  },
  {
    path: '/TSSSA001M',
    name: 'TSSSA001M',
    component: TSSSA001M
  },
  {
    path: '/TSSAP021P',
    name: 'TSSAP021P',
    component: TSSAP021P
  },
  {
    path: '/TSSAP030M',
    name: 'TSSAP030M',
    component: TSSAP030M
  },
  {
    path: '/TSSAP032D',
    name: 'TSSAP032D',
    component: TSSAP032D
  },
  {
    path: '/TSSAP033D',
    name: 'TSSAP033D',
    component: TSSAP033D
  },
  {
    path: '/TSSAP031D',
    name: 'TSSAP031D',
    component: TSSAP031D
  },
  {
    path: '/TSSBC301P',
    name: 'TSSBC301P',
    component: TSSBC301P
  },
  {
    path: '/TSSPI230D',
    name: 'TSSPI230D',
    component: TSSPI230D
  },
  {
    path: '/TSSPI230P',
    name: 'TSSPI230P',
    component: TSSPI230P
  },
  {
    path: '/TSSPI830P',
    name: 'TSSPI830P',
    component: TSSPI830P
  },
  {
    path: '/TSSPI880P',
    name: 'TSSPI880P',
    component: TSSPI880P
  },
  {
    path: '/TSSAP133P',
    name: 'TSSAP133P',
    component: TSSAP133P
  },
  {
    path: '/TSSPI290P',
    name: 'TSSPI290P',
    component: TSSPI290P
  },
  {
    path: '*',
    name: 'index',
    component: IndexPage
  }
]

// 2번 영역
// 배열 0번(main) 대상 child 속성에 중첩 라우팅 병합
rootRoutes[0].children = rootRoutes[0].children.concat(LnbRotues)

export default rootRoutes
