// import lnb1 from '~pages/lnb/lnb1'

const routes = [
  // {
  //   path: 'lnb/1',
  //   component: lnb1
  // }
]

export default routes
