echo "Pulling from Master"
git pull
echo "Pulled successfully from master"