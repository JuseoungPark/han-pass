# fdp-vue-template

# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev
npm start

# build for production with minification
    # stage build
    npm run stg
    # production build
    npm run prd

# build for production and view the bundle analyzer report
npm run stg --report
npm run prd --report
