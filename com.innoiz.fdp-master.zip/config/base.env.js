'use strict'

module.exports = {
    VERSION_ENV: '"v1.0"',
}